<?php echo $post->keyword->name; ?> <?php echo $post->keyword->sentences(1); ?>

<?php /**PATH /Users/buchin/Repos/shuriken-6/templates/image/title.blade.php ENDPATH**/ ?>