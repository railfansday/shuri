<?php $__env->startSection('head'); ?>
<title><?php echo e(config('export.site_name')); ?></title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('bg'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<?php if(isset($_GET['img'])): ?>
	<div class="row">
		<div class="col-md-12 text-center">
			<p><a href="<?php echo e($_GET['img']); ?>" class="btn btn-outline-primary" download="image">Download Image</a></p>
			<p><img src="<?php echo e($_GET['img']); ?>" alt="" class="img-fluid"></p>

		</div>
	</div>
	<div class="mt-3"></div>
	<?php endif; ?>

		<?php $__currentLoopData = \App\Post::whereNotNull('content')->inRandomOrder()->take(18)->get()->chunk(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chunked): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="clearfix"></div>
				<?php $__currentLoopData = $chunked; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n => $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

					<div class="posts-image">
						<div class="posts-image-content">
							<a href="<?php echo e($post->slug . '.html'); ?>">
								<img src="<?php echo e($post->keyword->images->random()->url); ?>" alt="<?php echo e($post->title); ?>" class="img-fluid" onerror="this.onerror=null;this.src='<?php echo e($post->keyword->images->random()->thumbnail); ?>';">
							</a>
							<h2><a href="<?php echo e($post->slug . '.html'); ?>">
								<?php echo e($post->title); ?>

							</a></h2>
						</div>
					</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('export.html.' .  config('export.theme') . '.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/buchin/Repos/shuriken/templates/export/html/four-mini/index.blade.php ENDPATH**/ ?>