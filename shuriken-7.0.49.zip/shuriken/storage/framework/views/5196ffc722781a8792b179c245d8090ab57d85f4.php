<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<link href="https://fonts.googleapis.com/css?family=Inter:400,600,700" rel="stylesheet">
	<style type="text/css">
*{box-sizing:border-box;margin:0;padding:0}
body,html{font-family:Inter,sans-serif;font-size:15px;background:#fff;color:#1a1a1a}
img{max-width:100%;display:block}
a{text-decoration:none;color:#1a73e8}
a:hover{text-decoration:underline}
.site-header{border-bottom:1px solid #eee;padding:16px 0;margin-bottom:0;background:#fff}
.site-header .inner{max-width:860px;margin:0 auto;padding:0 20px;display:flex;align-items:center;justify-content:space-between}
.site-header .brand{font-size:22px;font-weight:700;color:#1a1a1a}
.site-header nav a{margin-left:20px;font-size:13px;color:#555}
.container{max-width:860px;margin:0 auto;padding:20px}
.post-list-item{display:flex;gap:16px;padding:16px 0;border-bottom:1px solid #f0f0f0;align-items:flex-start}
.post-list-item:last-child{border-bottom:none}
.post-list-thumb{flex:0 0 140px;width:140px}
.post-list-thumb img{width:140px;height:100px;object-fit:cover;border-radius:4px}
.post-list-body{flex:1;min-width:0}
.post-list-title{font-size:16px;font-weight:600;color:#1a1a1a;line-height:1.4;margin-bottom:6px}
.post-list-title a{color:#1a1a1a}
.post-list-title a:hover{color:#1a73e8;text-decoration:none}
.post-list-excerpt{font-size:13px;color:#666;line-height:1.5;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}
.post-list-meta{font-size:12px;color:#999;margin-top:6px}
.site-footer{border-top:1px solid #eee;text-align:center;padding:20px 0;margin-top:20px;font-size:13px;color:#999}
.site-footer a{margin:0 10px;color:#666}
.navi{margin:12px 0}
.navi a{margin:3px 4px;font-size:13px;color:#1a73e8}
@media(max-width:600px){.post-list-thumb{flex:0 0 80px;width:80px}.post-list-thumb img{width:80px;height:60px}}
	</style>
	<?php echo $__env->yieldContent('head'); ?>
	<?php echo $__env->make('export.html._ads.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body>
	<header class="site-header">
		<div class="inner">
			<a href="index.html" class="brand"><?php echo e(config('export.site_name')); ?></a>
			<nav>
				<?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<a href="<?php echo e($page); ?>.html"><?php echo e(ucwords(str_replace('-', ' ', $page))); ?></a>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</nav>
		</div>
	</header>
	<div class="container">
		<?php echo $__env->yieldContent('header'); ?>
		<?php echo $__env->make('export.html._ads.related', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<?php echo $__env->yieldContent('content'); ?>
	</div>
	<footer class="site-footer">
		<?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<a href="<?php echo e($page); ?>.html"><?php echo e(ucwords(str_replace('-', ' ', $page))); ?></a>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</footer>
	<?php echo $__env->make('export.html._ads.bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<?php echo $__env->make('export.html._ads.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html>
<?php /**PATH /Users/buchin/Repos/shuriken/templates/export/html/seven/layout.blade.php ENDPATH**/ ?>