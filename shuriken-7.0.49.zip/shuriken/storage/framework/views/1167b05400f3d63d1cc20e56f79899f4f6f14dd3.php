<?php $__env->startSection('head'); ?>
<title><?php echo e(config('export.site_name')); ?></title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php $shuffled = collect($posts)->shuffle(); ?>


<?php if($shuffled->count() > 0): ?>
<?php $hero = $shuffled->first(); $heroImg = $hero->keyword->images->random()->toArray(); ?>
<div class="hero mb-4">
	<a href="<?php echo e($hero->slug); ?>.html">
		<img src="<?php echo e($heroImg['url']); ?>" alt="<?php echo e($heroImg['title']); ?>" onerror="this.onerror=null;this.src='<?php echo e($heroImg['thumbnail']); ?>';">
		<div class="hero-caption">
			<h2><a href="<?php echo e($hero->slug); ?>.html"><?php echo e($hero->title); ?></a></h2>
		</div>
	</a>
</div>
<?php endif; ?>


<h4 class="section-title">Latest</h4>
<div class="row">
	<?php $__currentLoopData = $shuffled->skip(1)->take(15); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<?php $image = $post->keyword->images->random()->toArray(); ?>
	<div class="col-sm-6 col-md-4">
		<div class="card">
			<a href="<?php echo e($post->slug); ?>.html">
				<img src="<?php echo e($image['thumbnail']); ?>" alt="<?php echo e($image['title']); ?>" onerror="this.onerror=null;this.src='<?php echo e($image['url']); ?>';">
			</a>
			<div class="card-body">
				<p class="card-title"><a href="<?php echo e($post->slug); ?>.html"><?php echo e($post->title); ?></a></p>
			</div>
		</div>
	</div>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('export.html.' .  config('export.theme') . '.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/buchin/Repos/shuriken-6/templates/export/html/six-dark/index.blade.php ENDPATH**/ ?>