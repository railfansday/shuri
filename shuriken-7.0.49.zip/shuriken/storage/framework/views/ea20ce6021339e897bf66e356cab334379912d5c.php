<?php $__env->startSection('head'); ?>
<title><?php echo e($post->title); ?></title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
<h1 style="font-size:26px;font-weight:700;margin-bottom:10px;"><?php echo e($post->title); ?></h1>
<div class="navi">
	<?php echo e($post->keyword->sentences(3)); ?><br>
	<?php $__currentLoopData = $post->related; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<a class="badge" style="background:#e91e8c;color:#fff;padding:3px 8px;border-radius:12px;margin:2px;" href="<?php echo e($r->slug); ?>.html"><?php echo e($r->keyword->name); ?></a>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div style="margin-top:20px;">
	<?php echo $post->content; ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('export.html.' .  config('export.theme') . '.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/buchin/Repos/shuriken-6/templates/export/html/five-mini-dark/post.blade.php ENDPATH**/ ?>