<?php $__env->startSection('head'); ?>
<title><?php echo e($post->title); ?></title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="post-content-wrap">
	<?php $image = $post->keyword->images->random()->toArray(); ?>
	<img src="<?php echo e($image['url']); ?>" alt="<?php echo e($image['title']); ?>" class="hero-image" onerror="this.onerror=null;this.src='<?php echo e($image['thumbnail']); ?>';">
	<h1><?php echo e($post->title); ?></h1>
	<div class="post-tags">
		<?php $__currentLoopData = $post->related; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<a href="<?php echo e($r->slug); ?>.html"><?php echo e($r->keyword->name); ?></a>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</div>
	<div class="post-body">
		<?php echo $post->content; ?>

	</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('export.html.' .  config('export.theme') . '.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/buchin/Repos/shuriken-6/templates/export/html/ten-mini/post.blade.php ENDPATH**/ ?>