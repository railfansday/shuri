<?php $__env->startSection('head'); ?>
<title><?php echo e(config('export.site_name')); ?></title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('bg'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<?php if(isset($_GET['img'])): ?>
	<div class="row">
		<div class="col-md-12 text-center">
			<p><a href="<?php echo e($_GET['img']); ?>" class="btn btn-outline-primary" download="image">Download Image</a></p>
			<p><img src="<?php echo e($_GET['img']); ?>" alt="" class="img-fluid"></p>

		</div>
	</div>
	<div class="mt-3"></div>
	<?php endif; ?>
	<div class="columns">
		<?php $__currentLoopData = collect($posts)->shuffle()->take(16)->chunk(4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chunked): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<?php $__currentLoopData = $chunked; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="posts-list">
						<?php
			            $image = $post->keyword->images->random()->toArray();
			            ?>
						<a href="<?php echo e($post->slug); ?>.html" target="_blank"><img alt="<?php echo e($image['title']); ?>" src="<?php echo e($image['thumbnail']); ?>" width="100%" onerror="this.onerror=null;this.src='<?php echo e($image['url']); ?>';"></a>
						<p class="text-center"><?php echo e($post->title); ?></p>
					</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('export.html.' .  config('export.theme') . '.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/buchin/Repos/shuriken/templates/export/html/two-dark/index.blade.php ENDPATH**/ ?>