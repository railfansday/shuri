<?php echo $post->ai_content; ?>

<?php if(!$post->ai_content): ?>
<?php $__currentLoopData = $keyword->images->shuffle(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if($loop->first): ?>
        <p>If you are {looking for|searching about} <?php echo e($image->title); ?> you've {came|visit} to the right {place|web|page}. We have <?php echo e($images->count()); ?> {Pics|Pictures|Images} about <?php echo e($image->title); ?> like <?php echo e($images->take(2)->pluck('title')->implode(', ')); ?> and also <?php echo e($images->shuffle()->take(1)->pluck('title')->implode(', ')); ?>. {Read more|Here you go|Here it is}:</p>
    <?php endif; ?>

    <h2><?php echo e(ucwords($image->title)); ?></h2>

    <img alt="<?php echo e($image->title); ?>" src="<?php echo e($image->url); ?>" width="100%" onerror="this.onerror=null;this.src='<?php echo e($image->thumbnail); ?>';" />

    <small><?php echo e($image->domain); ?></small>
    <p><?php echo e($image->desc); ?></p>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<p><?php echo e($keyword->sentences(3)); ?></p>
<?php else: ?>
<?php $__currentLoopData = $keyword->images->shuffle(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if(!str_contains($post->ai_content, $image->url) && !str_contains($post->ai_content, $image->thumbnail)): ?>
    <h2><?php echo e(ucwords($image->title)); ?></h2>
    <img alt="<?php echo e($image->title); ?>" src="<?php echo e($image->url); ?>" width="100%" onerror="this.onerror=null;this.src='<?php echo e($image->thumbnail); ?>';" />
    <p><?php echo e($image->desc); ?></p>
    <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<?php /**PATH /Users/buchin/Repos/shuriken/templates/image/content.blade.php ENDPATH**/ ?>