<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-KZT9SZ7"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) --><?php /**PATH /Users/buchin/Repos/shuriken/templates/export/html/_ads/body.blade.php ENDPATH**/ ?>