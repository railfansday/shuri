<?php $__env->startSection('title'); ?>
    <?php echo e($post->title); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('head'); ?>
<?php echo $post->json_ld; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('description'); ?>
    <?php echo e($post->keyword->sentences(1)); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php echo $post->content; ?>


<section>
    <article>
        <p>
            <?php if($post->previous): ?>
                <a href="<?php echo e($post->previous->slug); ?>.html"><i>&larr; <?php echo e($post->previous->title); ?></i></a>
            <?php endif; ?>

            <?php if($post->parent): ?>
                <a href="<?php echo e($post->parent->slug); ?>.html"><i><?php echo e($post->parent->title); ?></i></a>
            <?php endif; ?>

            <?php if($post->next): ?>
                <a href="<?php echo e($post->next->slug); ?>.html"><i><?php echo e($post->next->title); ?> &rarr;</i></a>
            <?php endif; ?>
        </p>
    </article>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('export.html.' .  config('export.theme') . '.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/buchin/Downloads/shuriken-6.0.1/templates/export/html/default/post.blade.php ENDPATH**/ ?>