<?php echo $post->keyword->name; ?> <?php echo $post->keyword->sentences(1); ?>

<?php /**PATH /Users/buchin/Downloads/shuriken-6.0.1/templates/image/title.blade.php ENDPATH**/ ?>