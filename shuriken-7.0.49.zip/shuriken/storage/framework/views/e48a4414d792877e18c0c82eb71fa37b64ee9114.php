<?php echo e(config('shuriken.category')); ?>

<?php /**PATH /Users/buchin/Repos/shuriken/templates/image/category.blade.php ENDPATH**/ ?>