<?php $__env->startSection('content'); ?>
<section>
    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <aside>
            <?php
            $image = $post->keyword->images->random()->toArray();
            ?>
            <a href="<?php echo e($image['url']); ?>" target="_blank"><img alt="<?php echo e($image['title']); ?>" src="<?php echo e($image['thumbnail']); ?>" width="100%" onerror="this.onerror=null;this.src='<?php echo e($image['url']); ?>';"></a>
            <h3><a href="<?php echo e($post->slug); ?>.html"><?php echo e($post->title); ?></a></h3>
        </aside>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('export.html.' .  config('export.theme') . '.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/buchin/Repos/shuriken-6/templates/export/html/default/index.blade.php ENDPATH**/ ?>