
<?php /**PATH /Users/buchin/Repos/shuriken/templates/export/html/_ads/in_article.blade.php ENDPATH**/ ?>