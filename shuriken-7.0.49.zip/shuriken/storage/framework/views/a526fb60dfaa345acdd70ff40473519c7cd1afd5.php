<?php $__env->startSection('head'); ?>
<title><?php echo e(config('export.site_name')); ?></title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="post-list">
	<?php $__currentLoopData = collect($posts)->shuffle()->take(20); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<?php $image = $post->keyword->images->random()->toArray(); ?>
	<div class="post-item">
		<a href="<?php echo e($post->slug); ?>.html" class="post-thumb">
			<img src="<?php echo e($image['url']); ?>" alt="<?php echo e($image['title']); ?>" onerror="this.onerror=null;this.src='<?php echo e($image['thumbnail']); ?>';">
		</a>
		<div class="post-info">
			<div class="post-title"><a href="<?php echo e($post->slug); ?>.html"><?php echo e($post->title); ?></a></div>
			<div class="post-excerpt"><?php echo e($post->keyword->sentences(1)); ?></div>
		</div>
	</div>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('export.html.' .  config('export.theme') . '.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/buchin/Repos/shuriken/templates/export/html/nine-dark/index.blade.php ENDPATH**/ ?>