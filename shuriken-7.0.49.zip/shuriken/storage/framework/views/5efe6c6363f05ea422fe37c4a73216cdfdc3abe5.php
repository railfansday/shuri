<?php $__env->startSection('head'); ?>
<title><?php echo e(config('export.site_name')); ?></title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="tile-grid">
	<?php $__currentLoopData = collect($posts)->shuffle()->take(24); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<?php $image = $post->keyword->images->random()->toArray(); ?>
	<div class="tile">
		<a href="<?php echo e($post->slug); ?>.html">
			<div class="tile-accent"></div>
			<img src="<?php echo e($image['url']); ?>" alt="<?php echo e($image['title']); ?>" onerror="this.onerror=null;this.src='<?php echo e($image['thumbnail']); ?>';">
			<div class="tile-overlay">
				<div class="tile-title"><?php echo e($post->title); ?></div>
			</div>
		</a>
	</div>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('export.html.' .  config('export.theme') . '.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/buchin/Repos/shuriken/templates/export/html/ten-mini/index.blade.php ENDPATH**/ ?>