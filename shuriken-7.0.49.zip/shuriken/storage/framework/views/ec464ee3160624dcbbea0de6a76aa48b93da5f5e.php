<?php $__env->startSection('head'); ?>
<title><?php echo e($post->title); ?></title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<h1 style="font-family:Merriweather,serif;font-size:26px;margin-bottom:16px;"><?php echo e($post->title); ?></h1>
<div class="navi" style="margin-bottom:20px;color:#888;font-size:13px;">
	<?php echo e($post->keyword->sentences(2)); ?>

	<div style="margin-top:8px;">
	<?php $__currentLoopData = $post->related; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<a href="<?php echo e($r->slug); ?>.html" style="background:#c0392b;color:#fff;padding:2px 10px;border-radius:10px;font-size:12px;margin:2px;display:inline-block;"><?php echo e($r->keyword->name); ?></a>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</div>
</div>
<?php echo $post->content; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('export.html.' .  config('export.theme') . '.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/buchin/Repos/shuriken-6/templates/export/html/six-dark/post.blade.php ENDPATH**/ ?>