<?php echo '<' . '?' . 'xml version="1.0" encoding="UTF-8"' . '?' . '>'; ?>

<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
    <url>
        <loc><?php echo e(config('export.base_url', 'https://domain.com')); ?>/index.html</loc>
        <lastmod><?php echo e(\Carbon\Carbon::now()->toISOString()); ?></lastmod>
    </url>
    <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <url>
            <loc><?php echo e(config('export.base_url', 'https://domain.com')); ?>/<?php echo e($page); ?>.html</loc>
            <lastmod><?php echo e(\Carbon\Carbon::now()->toISOString()); ?></lastmod>
        </url>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <url>
            <loc><?php echo e(config('export.base_url', 'https://domain.com')); ?>/<?php echo e($post->slug); ?>.html</loc>
            <lastmod><?php echo e($post->published_at->toISOString()); ?></lastmod>
        </url>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</urlset>
<?php /**PATH /Users/buchin/Repos/shuriken/templates/export/html/sitemap.blade.php ENDPATH**/ ?>