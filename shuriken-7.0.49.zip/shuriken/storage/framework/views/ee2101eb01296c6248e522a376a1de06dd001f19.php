<?php echo e($keyword->name); ?>

<?php /**PATH /Users/buchin/Repos/shuriken-6/templates/image/tags.blade.php ENDPATH**/ ?>