<?php if(!empty($post->ai_title)): ?>
<?php echo $post->ai_title; ?>

<?php else: ?>
<?php
    $suffix = $post->keyword->sentences(1);
?>
<?php if($suffix): ?>
<?php echo ucwords($post->keyword->name); ?> - <?php echo $suffix; ?>

<?php else: ?>
<?php echo ucwords($post->keyword->name); ?>

<?php endif; ?>
<?php endif; ?>
<?php /**PATH /Users/buchin/Repos/shuriken/templates/image/title.blade.php ENDPATH**/ ?>