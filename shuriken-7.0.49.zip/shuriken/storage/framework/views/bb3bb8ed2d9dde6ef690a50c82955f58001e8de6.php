<?php echo e($keyword->name); ?>

<?php /**PATH /Users/buchin/Downloads/shuriken-6.0.1/templates/image/tags.blade.php ENDPATH**/ ?>