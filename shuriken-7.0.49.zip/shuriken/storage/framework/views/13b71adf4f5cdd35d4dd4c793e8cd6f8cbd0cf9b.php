<?php echo e(config('shuriken.category')); ?>

<?php /**PATH /Users/buchin/Downloads/shuriken-6.0.1/templates/image/category.blade.php ENDPATH**/ ?>