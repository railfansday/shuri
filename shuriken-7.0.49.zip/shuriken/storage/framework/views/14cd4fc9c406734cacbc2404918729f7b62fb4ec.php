<!doctype html>
<html lang="en">
<head>
	<!-- Required meta tags -->
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<!-- Bootstrap CSS -->
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
	<link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">
	<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
	<style type="text/css">
body,html{font-family:Raleway,sans-serif;font-size:14px;font-weight:400;color:#f1f2f3;background:#111}img{max-width:100%}.header{padding-bottom:13px;margin-bottom:13px}.container{max-width:900px}.navbar{margin-bottom:25px;background:#111!important;color:#f1f2f3;border-bottom:1px solid #212121}.navbar li:hover{background:#222}.navbar .navbar-brand{margin:0 20px 0 0;font-size:28px;padding:0;line-height:24px}.row.content,.row.footer,.row.header{widthx:auto;max-widthx:100%}.row.footer{border-color:#212121;padding:30px 0;background:0 0}.content .col-sm-12{padding:0}.content .col-md-9s{margin-right:-25px}.content .col-md-3{padding-left:0}.posts-image{width:33%;display:inline-table}.posts-image-content{width:auto;margin:0 20px 25px 0;position:relative}.posts-image:nth-childs(3n) .posts-image-content{margin:0 0 25px!important}.posts-image img{width:100%;height:150px;object-fit:cover;object-position:center;margin-bottom:10px;-webkit-transition:.6s ease;transition:.6s ease}.posts-image:hover img{-webkit-transform:scale(1.08);transform:scale(1.08)}.list-group li{padding:0;background:#121212}.list-group li a{display:block;padding:8px}.widget{margin-bottom:20px}h3.widget-title{font-size:20px}a{color:#f42966;text-decoration:none}.footer{margin-top:21px;padding-top:13px;border-top:1px solid #eee}.footer a{margin:0 15px}.navi{margin:13px 0}.navi a{margin:5px 2px;font-size:95%}@media only screen and (min-width:0px) and (max-width:991px){.container{width:auto;max-width:100%}.navbar{padding:5px 0}.navbar .container{width:100%;margin:0 15px}}@media only screen and (min-width:0px) and (max-width:767px){.content .col-md-3{padding:15px}.posts-image{width:33%}.posts-image-content{margin:0 16px 25px 0}.posts-image:nth-child(3n) .posts-image-content{margin:0 0 25px}}@media only screen and (min-width:0px) and (max-width:640px){.posts-image{width:49.5%}.posts-image-content,.posts-image:nth-child(3n) .posts-image-content{margin:0 8px 25px 0}.posts-image:nth-child(2n) .posts-image-content{margin:0 0 25px 8px!important}}@media only screen and (min-width:0px) and (max-width:360px){.posts-image{width:100%}.posts-image-content,.posts-image:nth-child(2n) .posts-image-content,.posts-image:nth-child(3n) .posts-image-content{margin:0 0 25px!important}.posts-image-content img{height:auto}}
	</style>
	<?php echo $__env->yieldContent('head'); ?>
	<?php echo $__env->make('export.html._ads.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body>
	<nav class="navbar navbar-expand-lg navbar-dark bg-light ">
		<div class="container">
	  <a href="index.html" class="navbar-brand"><?php echo e(config('export.site_name')); ?></a>
	  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
		<span class="navbar-toggler-icon"></span>
	  </button>
	  <div class="collapse navbar-collapse" id="navbarSupportedContent">
		<ul class="navbar-nav ml-auto">
			<?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<li class="nav-item"><a class="nav-link" href="<?php echo e($page); ?>.html"><?php echo e(ucwords(str_replace('-', ' ', $page))); ?></a></li>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</ul>
		</div>
	  </div>
	</nav>
	<div class="container">
		<div class="row content">
			<div class="col-md-12">
				<div class="col-sm-12">

					<?php echo $__env->yieldContent('header'); ?>
					<?php echo $__env->make('export.html._ads.related', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

				</div>
				<div class="col-sm-12">
					<?php echo $__env->yieldContent('content'); ?>
				</div>
			</div>
		</div>
		<div class="row footer">
			<div class="col-md-12 text-center">
				<?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<a href="<?php echo e($page); ?>.html"><?php echo e(ucwords(str_replace('-', ' ', $page))); ?></a>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

			</div>
		</div>
	</div>
	<?php echo $__env->make('export.html._ads.bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<?php echo $__env->make('export.html._ads.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html>
<?php /**PATH /Users/buchin/Repos/shuriken/templates/export/html/two-mini-dark/layout.blade.php ENDPATH**/ ?>