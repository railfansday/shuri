<?php
use Faker\Factory;
    $default_author = Factory::create()->name;
    $site_url = 'http://' . Factory::create()->domainName . '/';
?>
<?php echo '<' . '?' . 'xml version="1.0" encoding="UTF-8"' . '?' . '>'; ?>

<rss version="2.0"
     xmlns:excerpt="http://wordpress.org/export/1.0/excerpt/"
     xmlns:content="http://purl.org/rss/1.0/modules/content/"
     xmlns:wfw="http://wellformedweb.org/CommentAPI/"
     xmlns:dc="http://purl.org/dc/elements/1.1/"
     xmlns:wp="http://wordpress.org/export/1.0/"
>

    <channel>
        <title>My Site</title>
        <link><?php echo e($site_url); ?></link>
        <description></description>
        <pubDate>Thu, 28 May 2009 16:06:40 +0000</pubDate>
        <wp:author><wp:author_id>1</wp:author_id><wp:author_login><![CDATA[admin]]></wp:author_login><wp:author_email><![CDATA[<?php echo e(Factory::create()->email); ?>]]></wp:author_email><wp:author_display_name><![CDATA[admin]]></wp:author_display_name><wp:author_first_name><![CDATA[]]></wp:author_first_name><wp:author_last_name><![CDATA[]]></wp:author_last_name></wp:author>

        <generator>http://wordpress.org/?v=2.7.1</generator>
        <language>en</language>
        <wp:wxr_version>1.0</wp:wxr_version>
        <wp:base_site_url><?php echo e($site_url); ?></wp:base_site_url>
        <wp:base_blog_url><?php echo e($site_url); ?></wp:base_blog_url>

        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $featured_image = $post->keyword->images->shuffle()->first();
                $thumbnail_id = 1000000+$post->id;
                $post = $post->setPublicationDate();
                $post->category = config('export.category');
            ?>
            <item>
                <title><![CDATA[<?php echo e($post->title); ?>]]></title>

                <link><?php echo e($site_url); ?><?php echo e($post->slug); ?>/</link>
                <pubDate><?php echo e($post->published_at->format('D, d M Y H:i:s')); ?> +0000</pubDate>

                <dc:creator><![CDATA[<?php echo e($default_author); ?>]]></dc:creator>
                <wp:postmeta>
                    <wp:meta_key>_byline</wp:meta_key>
                    <wp:meta_value><?php echo e($default_author); ?></wp:meta_value>
                </wp:postmeta>

                <category><![CDATA[<?php echo e($post->category); ?>]]></category>
                <category domain="category" nicename="<?php echo e(str($post->category)->slug()); ?>"><![CDATA[<?php echo e($post->category); ?>]]></category>

                <?php $__currentLoopData = $post->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <category domain="tag" nicename="<?php echo e(str($tag)->slug()); ?>"><![CDATA[<?php echo e($tag); ?>]]></category>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                <guid isPermaLink="false"><?php echo e($site_url); ?>?p=<?php echo e($post->id); ?></guid>
                <description></description>
                <content:encoded><![CDATA[<?php echo $post->content; ?>]]></content:encoded>
                <excerpt:encoded><![CDATA[]]></excerpt:encoded>
                <wp:post_id><?php echo e($post->id); ?></wp:post_id>
                <wp:post_date><?php echo e($post->published_at->format('Y-m-d H:i:s')); ?></wp:post_date>
                <wp:post_date_gmt><?php echo e($post->published_at->format('Y-m-d H:i:s')); ?></wp:post_date_gmt>
                <wp:comment_status>open</wp:comment_status>
                <wp:ping_status>closed</wp:ping_status>
                <wp:post_name><?php echo e($post->slug); ?></wp:post_name>

                <wp:status>publish</wp:status>
                <wp:post_parent>0</wp:post_parent>
                <wp:menu_order>0</wp:menu_order>
                <wp:post_type>post</wp:post_type>
                <wp:post_password></wp:post_password>

                <wp:postmeta>
                    <wp:meta_key>_old_id</wp:meta_key>
                    <wp:meta_value><?php echo e($post->id); ?></wp:meta_value>
                </wp:postmeta>
                <?php if(!empty($post->json_ld)): ?>
                    <wp:postmeta>
                        <wp:meta_key><![CDATA[json_ld]]></wp:meta_key>
                        <wp:meta_value><![CDATA[<?php echo $post->json_ld; ?>]]></wp:meta_value>
                    </wp:postmeta>
                <?php endif; ?>

                <wp:postmeta>
                    <wp:meta_key><![CDATA[_thumbnail_id]]></wp:meta_key>
                    <wp:meta_value><![CDATA[<?php echo e($thumbnail_id); ?>]]></wp:meta_value>
                </wp:postmeta>
            </item>

            <item>
                <title><?php echo e($post->keyword->name); ?></title>
                <link><?php echo e($site_url); ?>?attachment_id=<?php echo e($thumbnail_id); ?></link>
                <pubDate>Sun, 27 Sep 2020 19:49:11 +0000</pubDate>
                <dc:creator><![CDATA[admin]]></dc:creator>
                <guid isPermaLink="false"><?php echo e($featured_image->url); ?></guid>
                <description></description>
                <content:encoded><![CDATA[]]></content:encoded>
                <excerpt:encoded><![CDATA[]]></excerpt:encoded>
                <wp:post_id><?php echo e($thumbnail_id); ?></wp:post_id>
                <wp:post_date><![CDATA[<?php echo e($post->published_at->format('Y-m-d H:i:s')); ?>]]></wp:post_date>
                <wp:post_date_gmt><![CDATA[<?php echo e($post->published_at->format('Y-m-d H:i:s')); ?>]]></wp:post_date_gmt>
                <wp:comment_status><![CDATA[open]]></wp:comment_status>
                <wp:ping_status><![CDATA[closed]]></wp:ping_status>
                <wp:post_name><![CDATA[<?php echo e($post->keyword->name); ?>]]></wp:post_name>
                <wp:status><![CDATA[inherit]]></wp:status>
                <wp:post_parent><?php echo e($post->id); ?></wp:post_parent>
                <wp:menu_order>0</wp:menu_order>
                <wp:post_type><![CDATA[attachment]]></wp:post_type>
                <wp:post_password><![CDATA[]]></wp:post_password>
                <wp:is_sticky>0</wp:is_sticky>
                <wp:attachment_url><![CDATA[<?php echo e($featured_image->url); ?>]]></wp:attachment_url>
                <wp:postmeta>
                    <wp:meta_key><![CDATA[_wp_attached_file]]></wp:meta_key>
                    <wp:meta_value><![CDATA[<?php echo e($post->published_at->format('Y/m')); ?>/<?php echo e(str($post->keyword->name)->slug); ?>.<?php echo e($featured_image->filetype); ?>]]></wp:meta_value>
                </wp:postmeta>
            </item>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </channel>
</rss>
<?php /**PATH /Users/buchin/Repos/shuriken-6/templates/export/wordpress.blade.php ENDPATH**/ ?>