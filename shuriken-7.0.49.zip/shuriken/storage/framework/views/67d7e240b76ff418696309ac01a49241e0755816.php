---
title: "<?php echo e($post->title); ?>"
description: "<?php echo e($post->keyword->sentences(1)); ?>"
date: "<?php echo e($post->published_at->format('Y-m-d')); ?>"
categories:
- "<?php echo e(config('export.category')); ?>"
images:
- "<?php echo e($post->keyword->images->shuffle()->random()->url); ?>"
featuredImage: "<?php echo e($post->keyword->images->shuffle()->random()->url); ?>"
featured_image: "<?php echo e($post->keyword->images->shuffle()->random()->url); ?>"
image: "<?php echo e($post->keyword->images->shuffle()->random()->url); ?>"
---

<?php echo $post->markdown; ?>

<?php /**PATH /Users/buchin/Repos/shuriken/templates/export/hugo.blade.php ENDPATH**/ ?>