<?php $__env->startSection('head'); ?>
<title><?php echo e($post->title); ?></title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
<div class="article-header">
	<h1 class="article-title"><?php echo e($post->title); ?></h1>
	<div class="article-tags">
		<?php $__currentLoopData = $post->related; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<a href="<?php echo e($r->slug); ?>.html" class="tag"><?php echo e($r->keyword->name); ?></a>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="article-body">
	<?php echo $post->content; ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('export.html.' .  config('export.theme') . '.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/buchin/Repos/shuriken/templates/export/html/nine-mini/post.blade.php ENDPATH**/ ?>