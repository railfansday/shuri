<?php $__env->startSection('head'); ?>
<title><?php echo e($post->title); ?></title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
<div style="margin-bottom:20px;">
	<h1 style="font-size:24px;font-weight:700;margin-bottom:10px;"><?php echo e($post->title); ?></h1>
	<div class="navi" style="color:#888;font-size:12px;">
		<?php echo e($post->keyword->sentences(2)); ?><br>
		<div style="margin-top:8px;">
		<?php $__currentLoopData = $post->related; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<a href="<?php echo e($r->slug); ?>.html" style="background:#333;color:#ddd;padding:2px 10px;border-radius:10px;font-size:11px;margin:2px;display:inline-block;"><?php echo e($r->keyword->name); ?></a>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div style="color:#ccc;line-height:1.7;">
	<?php echo $post->content; ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('export.html.' .  config('export.theme') . '.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/buchin/Repos/shuriken-6/templates/export/html/eight-dark/post.blade.php ENDPATH**/ ?>