<?php $__env->startSection('head'); ?>
<title><?php echo e(config('export.site_name')); ?></title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="masonry">
	<?php $__currentLoopData = collect($posts)->shuffle()->take(24); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<?php $image = $post->keyword->images->random()->toArray(); ?>
		<div class="masonry-item">
			<a href="<?php echo e($post->slug); ?>.html">
				<img alt="<?php echo e($image['title']); ?>" src="<?php echo e($image['thumbnail']); ?>" onerror="this.onerror=null;this.src='<?php echo e($image['url']); ?>';">
			</a>
			<div class="caption">
				<a href="<?php echo e($post->slug); ?>.html"><?php echo e($post->title); ?></a>
			</div>
		</div>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('export.html.' .  config('export.theme') . '.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/buchin/Repos/shuriken-6/templates/export/html/five-mini-dark/index.blade.php ENDPATH**/ ?>