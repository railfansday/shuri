<?php $__env->startSection('head'); ?>
<title><?php echo e($post->title); ?></title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('bg'); ?>
<?php echo e($post->keyword->images->random()->url); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
	<h1><?php echo e($post->title); ?></h1>

	<div class="navi text-left">
        <p><?php echo e($post->keyword->sentences(3)); ?> <br>
            <?php $__currentLoopData = $post->related; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a class="badge badge-<?php echo e(collect(['primary', 'secondary', 'success', 'info', 'danger', 'warning', 'light', 'dark'])->random()); ?>" href="<?php echo e($r->slug); ?>.html"><?php echo e($r->keyword->name); ?></a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </p>
	</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php echo $post->content; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('export.html.' .  config('export.theme') . '.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/buchin/Repos/shuriken/templates/export/html/two-mini-dark/post.blade.php ENDPATH**/ ?>