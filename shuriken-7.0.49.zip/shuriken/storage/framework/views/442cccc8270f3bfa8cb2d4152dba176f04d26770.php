<?php $__env->startSection('head'); ?>
<title><?php echo e(config('export.site_name')); ?></title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="post-list">
	<?php $__currentLoopData = collect($posts)->shuffle()->take(20); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<?php $image = $post->keyword->images->random()->toArray(); ?>
	<div class="post-list-item">
		<div class="post-list-thumb">
			<a href="<?php echo e($post->slug); ?>.html">
				<img src="<?php echo e($image['thumbnail']); ?>" alt="<?php echo e($image['title']); ?>" onerror="this.onerror=null;this.src='<?php echo e($image['url']); ?>';">
			</a>
		</div>
		<div class="post-list-body">
			<div class="post-list-title">
				<a href="<?php echo e($post->slug); ?>.html"><?php echo e($post->title); ?></a>
			</div>
			<div class="post-list-excerpt"><?php echo e($post->keyword->sentences(2)); ?></div>
		</div>
	</div>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('export.html.' .  config('export.theme') . '.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/buchin/Repos/shuriken/templates/export/html/seven-mini-dark/index.blade.php ENDPATH**/ ?>