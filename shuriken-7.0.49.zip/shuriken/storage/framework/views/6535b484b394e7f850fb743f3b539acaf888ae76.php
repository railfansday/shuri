<?php $__env->startSection('head'); ?>
<title><?php echo e($post->title); ?></title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
<h1 style="font-size:26px;font-weight:700;margin-bottom:10px;line-height:1.3;"><?php echo e($post->title); ?></h1>
<div class="navi" style="color:#888;font-size:13px;margin-bottom:20px;">
	<?php echo e($post->keyword->sentences(2)); ?><br>
	<div style="margin-top:6px;">
	<?php $__currentLoopData = $post->related; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<a href="<?php echo e($r->slug); ?>.html" style="color:#1a73e8;margin-right:10px;font-size:12px;"><?php echo e($r->keyword->name); ?></a>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php echo $post->content; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('export.html.' .  config('export.theme') . '.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/buchin/Repos/shuriken-6/templates/export/html/seven-mini/post.blade.php ENDPATH**/ ?>