<?php
    $domain = 'https://' . str()->random(5) . '.blogspot.com';
?>
<?php echo '<' . '?' . 'xml version="1.0" encoding="UTF-8"' . '?' . '>'; ?>

<ns0:feed xmlns:ns0="http://www.w3.org/2005/Atom">
    <ns0:title type="html"><?php echo e($domain); ?></ns0:title>
    <ns0:generator>Blogger</ns0:generator>
    <ns0:link href="<?php echo e($domain); ?>" rel="self" type="application/atom+xml" />
    <ns0:link href="<?php echo e($domain); ?>" rel="alternate" type="text/html" />
    <ns0:updated>2016-06-10T04:33:36Z</ns0:updated>

    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
            $post = $post->setPublicationDate();
        ?>
        <ns0:entry>
            <?php $__currentLoopData = $post->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <ns0:category scheme="http://www.blogger.com/atom/ns#" term="<?php echo e($tag); ?>" />
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <ns0:category scheme="http://www.blogger.com/atom/ns#" term="<?php echo e(config('export.category')); ?>" />
            <ns0:category scheme="http://schemas.google.com/g/2005#kind" term="http://schemas.google.com/blogger/2008/kind#post" />
            <ns0:id>post-<?php echo e($post->id); ?></ns0:id>
            <ns0:author>
                <ns0:name>admin</ns0:name>
            </ns0:author>
            <ns0:content type="html"><?php echo e(str_replace("\n", ' ', $post->content)); ?>

            </ns0:content>
            <ns0:published><?php echo e($post->published_at->format('Y-m-d')); ?>T<?php echo e($post->published_at->format('H:i:s')); ?>Z</ns0:published>
            <ns0:title type="html"><?php echo e($post->title); ?></ns0:title>
            <ns0:link href="<?php echo e($domain); ?>/<?php echo e($post->id); ?>/" rel="self" type="application/atom+xml" />
            <ns0:link href="<?php echo e($domain); ?>/<?php echo e($post->id); ?>/" rel="alternate" type="text/html" />
        </ns0:entry>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</ns0:feed>
<?php /**PATH /Users/buchin/Repos/shuriken-6/templates/export/blogger.blade.php ENDPATH**/ ?>