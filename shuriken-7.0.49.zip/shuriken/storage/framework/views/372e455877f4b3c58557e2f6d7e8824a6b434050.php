<?php
    $name = Faker\Factory::create()->name;
?>
<script type="application/ld+json">
{
  "@context": "https://schema.org/",
  "@type": "Article",
  "author": {
    "@type": "Person",
    "name": "<?php echo e($name); ?>"
  },
  "headline": "<?php echo e($post->title); ?>",
  "datePublished": "<?php echo e($post->published_at->format('Y-m-d')); ?>",
  "image": "<?php echo e($post->keyword->images->shuffle()->first()->url); ?>",
  "publisher": {
    "@type": "Organization",
    "name": "<?php echo e($name); ?>",
    "logo": {
      "@type": "ImageObject",
      "url": "https://via.placeholder.com/512.png?text=<?php echo e($name[0]); ?>",
      "width": 512,
      "height": 512
    }
  }
}
</script>
<?php /**PATH /Users/buchin/Repos/shuriken-6/templates/image/json_ld.blade.php ENDPATH**/ ?>