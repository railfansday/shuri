<?php echo e(config('shuriken.category')); ?>

<?php /**PATH /Users/buchin/Repos/shuriken-6/templates/image/category.blade.php ENDPATH**/ ?>