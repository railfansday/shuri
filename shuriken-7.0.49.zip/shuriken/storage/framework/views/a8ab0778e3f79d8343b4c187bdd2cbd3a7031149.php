<?php echo e($keyword->name); ?>

<?php /**PATH /Users/buchin/Repos/shuriken/templates/image/tags.blade.php ENDPATH**/ ?>