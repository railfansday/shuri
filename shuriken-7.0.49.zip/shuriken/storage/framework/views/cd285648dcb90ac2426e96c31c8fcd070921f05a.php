<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<link href="https://fonts.googleapis.com/css?family=Inter:400,600,700" rel="stylesheet">
	<style type="text/css">
*{box-sizing:border-box;margin:0;padding:0}
body,html{font-family:Inter,sans-serif;font-size:14px;background:#0f0f0f;color:#e0e0e0}
img{max-width:100%;display:block}
a{text-decoration:none;color:#4da3ff}
a:hover{text-decoration:underline}
.site-header{border-bottom:1px solid #222;padding:14px 0;background:#161616}
.site-header .inner{max-width:640px;margin:0 auto;padding:0 20px;display:flex;align-items:center;justify-content:space-between}
.site-header .brand{font-size:20px;font-weight:700;color:#f1f2f3}
.site-header nav a{margin-left:16px;font-size:12px;color:#888}
.container{max-width:640px;margin:0 auto;padding:20px}
.post-list-item{display:flex;gap:12px;padding:14px 0;border-bottom:1px solid #1e1e1e;align-items:flex-start}
.post-list-item:last-child{border-bottom:none}
.post-list-thumb{flex:0 0 100px;width:100px}
.post-list-thumb img{width:100px;height:72px;object-fit:cover;border-radius:3px}
.post-list-body{flex:1;min-width:0}
.post-list-title{font-size:14px;font-weight:600;color:#e0e0e0;line-height:1.4;margin-bottom:5px}
.post-list-title a{color:#e0e0e0}
.post-list-title a:hover{color:#4da3ff;text-decoration:none}
.post-list-excerpt{font-size:12px;color:#777;line-height:1.5;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}
.site-footer{border-top:1px solid #1e1e1e;text-align:center;padding:18px 0;margin-top:20px;font-size:12px;color:#555}
.site-footer a{margin:0 8px;color:#666}
.navi{margin:10px 0}
.navi a{margin:3px 4px;font-size:12px;color:#4da3ff}
@media(max-width:480px){.post-list-thumb{flex:0 0 70px;width:70px}.post-list-thumb img{width:70px;height:50px}}
	</style>
	<?php echo $__env->yieldContent('head'); ?>
	<?php echo $__env->make('export.html._ads.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body>
	<header class="site-header">
		<div class="inner">
			<a href="index.html" class="brand"><?php echo e(config('export.site_name')); ?></a>
			<nav>
				<?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<a href="<?php echo e($page); ?>.html"><?php echo e(ucwords(str_replace('-', ' ', $page))); ?></a>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</nav>
		</div>
	</header>
	<div class="container">
		<?php echo $__env->yieldContent('header'); ?>
		<?php echo $__env->make('export.html._ads.related', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<?php echo $__env->yieldContent('content'); ?>
	</div>
	<footer class="site-footer">
		<?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<a href="<?php echo e($page); ?>.html"><?php echo e(ucwords(str_replace('-', ' ', $page))); ?></a>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</footer>
	<?php echo $__env->make('export.html._ads.bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<?php echo $__env->make('export.html._ads.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html>
<?php /**PATH /Users/buchin/Repos/shuriken/templates/export/html/seven-mini-dark/layout.blade.php ENDPATH**/ ?>