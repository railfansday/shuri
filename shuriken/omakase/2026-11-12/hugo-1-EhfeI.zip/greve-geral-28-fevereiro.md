---
title: "Greve Geral 28 Fevereiro - Metro do porto &quot;fortemente condicionado&quot; no dia da greve geral"
description: "Pré-aviso de greve a 28 fevereiro"
date: "2026-02-13"
categories:
- "Uncategorized"
images:
- "https://www.cm-barreiro.pt/wp-content/uploads/2025/02/GREVE-28_FEV_1920x650px.jpg"
featuredImage: "https://cpers.com.br/wp-content/uploads/2017/04/olar.jpg"
featured_image: "https://www.padrejoao.com.br/wp-content/uploads/2017/04/28-GREVE-GERAL-e1499885048772.png"
image: "https://sindviarios.org.br/wp-content/uploads/2025/02/02-25-greve.jpg"
---

If you are looking for 28 de abril de 2017 – Partido Verde you've visit to the right page. We have 35 Images about 28 de abril de 2017 – Partido Verde like Pré-Aviso de Greve a 28 fevereiro - Portal Institucional, Pré-Aviso de Greve a 28 fevereiro - Portal Institucional and also Boletim de GREVE 44: informações da Assembleia Geral de 28/5 | SINTFUB. Read more:

28 De Abril De 2017 – Partido Verde
-----------------------------------

 ![28 de abril de 2017 – Partido Verde](https://pv.org.br/wp-content/uploads/2017/04/greve-geral.png) <small>pv.org.br</small>28 de abril de 2017 – Partido Verde

Pré-Aviso De Greve A 28 Fevereiro - Portal Institucional
--------------------------------------------------------

 ![Pré-Aviso de Greve a 28 fevereiro - Portal Institucional](https://www.cm-barreiro.pt/wp-content/uploads/2025/02/GREVE-28_FEV_1920x650px.jpg) <small>www.cm-barreiro.pt</small>Pré-Aviso de Greve a 28 fevereiro - Portal Institucional

Manifestação Em Frente Ao Parlamento Resultou Em Seis Detidos: Tudo Sobre A Greve Geral
---------------------------------------------------------------------------------------

 ![Manifestação em frente ao Parlamento resultou em seis detidos: tudo sobre a greve geral](https://cdn.sabado.pt/images/2025-12/img_1320x742uu2025-12-11-15-03-48-752830.jpg) <small>www.sabado.pt</small>Manifestação em frente ao Parlamento resultou em seis detidos: tudo sobre a greve geral ...

CGTP Convoca Manifestação Nacional Para 28 De Fevereiro Contra Alterações à Lei Laboral - JN
--------------------------------------------------------------------------------------------

 ![CGTP convoca manifestação nacional para 28 de fevereiro contra alterações à lei laboral - JN](https://staticx.noticiasilimitadas.pt/jn/image.webp?brand=jn&type=generate&guid=3fd6eed8-2090-4448-ad92-3a9aa1d79a6f&w=3840) <small>www.jn.pt</small>CGTP convoca manifestação nacional para 28 de fevereiro contra alterações à lei laboral - JN

Classe Trabalhadora Do Brasil Prepara Greve Geral Para 28 De Abril - FENAJ
--------------------------------------------------------------------------

 ![Classe trabalhadora do Brasil prepara greve geral para 28 de abril - FENAJ](https://fenaj.org.br/wp-content/uploads/2017/04/Chamada-greve-geral.jpg) <small>fenaj.org.br</small>Classe trabalhadora do Brasil prepara greve geral para 28 de abril - FENAJ

Pré-Aviso De Greve – 17 De Abril De 2026 – AE António Correia De Oliveira
-------------------------------------------------------------------------

 ![Pré-Aviso de Greve – 17 de abril de 2026 – AE António Correia de Oliveira](https://www.acoliveira.pt/wp-content/uploads/2026/04/7e9f6ec4-4873-4685-897b-30c62aab02d6.png) <small>www.acoliveira.pt</small>Pré-Aviso de Greve – 17 de abril de 2026 – AE António Correia de Oliveira

Greve Geral Juntou Centenas Nos Aliados. Governo Fala Em Adesão "inexpressiva" - JPN
------------------------------------------------------------------------------------

 ![Greve Geral juntou centenas nos Aliados. Governo fala em adesão "inexpressiva" - JPN](https://www.jpn.up.pt/wp-content/uploads/2025/12/greve_geral9.jpg) <small>www.jpn.up.pt</small>Greve Geral juntou centenas nos Aliados. Governo fala em adesão "inexpressiva" - JPN

Os Motivos Da Greve Geral Desta Sexta (28/04) | Exame
-----------------------------------------------------

 ![Os motivos da greve geral desta sexta (28/04) | Exame](https://classic.exame.com/wp-content/uploads/2017/04/2017-04-28t064720z_349775655_rc16e3612540_rtrmadp_3_brazil-politics-protests-e1493372557676.jpg) <small>exame.com</small>Os motivos da greve geral desta sexta (28/04) | Exame

Greve Geral Na Argentina: Governo Monta Postos De Controle, Mas Não Evita Protestos E Multidão
----------------------------------------------------------------------------------------------

 ![Greve geral na Argentina: governo monta postos de controle, mas não evita protestos e multidão](https://s2-oglobo.glbimg.com/V7Y8UJwANx11oJDI3S06BJ3H-IY=/1600x0/smart/filters:strip_icc()/i.s3.glbimg.com/v1/AUTH_da025474c0c44edd99332dddb09cabe8/internal_photos/bs/2024/7/b/SCOa79QxybJ0mnPp3zDg/afp-20240124-34gp483-v1-highres-argentinapoliticseconomynationalstrike.jpg) <small>oglobo.globo.com</small>Greve geral na Argentina: governo monta postos de controle, mas não evita protestos e multidão ...

Metro Do Porto "fortemente Condicionado" No Dia Da Greve Geral - JPN
--------------------------------------------------------------------

 ![Metro do Porto "fortemente condicionado" no dia da greve geral - JPN](https://www.jpn.up.pt/wp-content/uploads/2025/12/greve_geral1-1152x759.jpg) <small>www.jpn.up.pt</small>Metro do Porto "fortemente condicionado" no dia da greve geral - JPN

Dia 28 é GREVE GERAL No Brasil : SINDASPI-SC
--------------------------------------------

 ![Dia 28 é GREVE GERAL no Brasil : SINDASPI-SC](https://www.sindaspisc.org.br/uploads/sindaspisc/blog/2019/06/GREVEGERAL.jpg) <small>www.sindaspisc.org.br</small>Dia 28 é GREVE GERAL no Brasil : SINDASPI-SC

Greve Geral Dia 28/04 – Sinecol
-------------------------------

 ![Greve Geral Dia 28/04 – Sinecol](https://sinecol.com.br/wp-content/uploads/2017/04/Greve-Geral.jpg) <small>sinecol.com.br</small>Greve Geral Dia 28/04 – Sinecol

Pré-Aviso De Greve A 28 Fevereiro - Portal Institucional
--------------------------------------------------------

 ![Pré-Aviso de Greve a 28 fevereiro - Portal Institucional](https://www.cm-barreiro.pt/wp-content/uploads/2025/02/GREVE-28_FEV_1920px.jpg?x14808) <small>www.cm-barreiro.pt</small>Pré-Aviso de Greve a 28 fevereiro - Portal Institucional

Balanço Da Greve Geral - CGTP-IN
--------------------------------

 ![Balanço da Greve Geral - CGTP-IN](https://www.cgtp.pt/images/images/2025/11/gg_banner2025.jpg) <small>www.cgtp.pt</small>Balanço da Greve Geral - CGTP-IN

Dia 28 - Greve Geral - Fotos: Carol Ferraz
------------------------------------------

 ![Dia 28 - Greve Geral - Fotos: Carol Ferraz](https://cpers.com.br/wp-content/uploads/2017/04/greve-geral.png) <small>cpers.com.br</small>Dia 28 - Greve Geral - Fotos: Carol Ferraz

Greve Geral Dia 28 Contra Retirada Dos Seus Direitos. Vamos Parar O Brasil. Reaja! | Sindicato
----------------------------------------------------------------------------------------------

 ![Greve Geral dia 28 contra retirada dos seus direitos. Vamos parar o Brasil. Reaja! | Sindicato](https://spbancarios.com.br/sites/default/files/styles/max_1300x1300/public/destaques/site-dia-28.png?itok=0BVsoqIw) <small>spbancarios.com.br</small>Greve Geral dia 28 contra retirada dos seus direitos. Vamos parar o Brasil. Reaja! | Sindicato ...

Dia 28 De Abril, É GREVE GERAL!
-------------------------------

 ![Dia 28 de abril, É GREVE GERAL!](https://cpers.com.br/wp-content/uploads/2017/04/olar.jpg) <small>cpers.com.br</small>Dia 28 de abril, É GREVE GERAL!

Greve Geral Paralisa Portugal Contra Precarização De Direitos
-------------------------------------------------------------

 ![Greve geral paralisa Portugal contra precarização de direitos](https://pcdob.org.br/wp-content/uploads/2025/12/Ruas-de-Lisboa-foram-tomadas-por-trabalhadores-durante-a-greve-geral-Rafael-Medeiros-Esquerda.jpg) <small>pcdob.org.br</small>Greve geral paralisa Portugal contra precarização de direitos

Mauricio Grabois
----------------

 ![Mauricio Grabois](https://grabois.org.br/wp-content/uploads/2021/11/1493066827.jpg) <small>grabois.org.br</small>Mauricio Grabois

Greve Geral Dia 28 De Abril De 2017 - SINDICOM
----------------------------------------------

 ![Greve Geral dia 28 de abril de 2017 - SINDICOM](http://sindicomdf.com.br/portal/wp-content/uploads/2017/04/18010432_1088047484633047_1398416190145067997_n.jpg) <small>sindicomdf.com.br</small>Greve Geral dia 28 de abril de 2017 - SINDICOM

Trabalhadores Do Brasil Preparam Greve Geral Dia 28 De Abril - FECESC
---------------------------------------------------------------------

 ![Trabalhadores do Brasil preparam Greve Geral dia 28 de abril - FECESC](https://www.fecesc.org.br/siteprincipal/wp-content/uploads/2017/04/BANNER_SITE-greve_geral.jpg) <small>www.fecesc.org.br</small>Trabalhadores do Brasil preparam Greve Geral dia 28 de abril - FECESC

15 Minutos: Impacto Da Greve Geral Já Se Começou A Sentir No Setor Dos Transportes - SIC Notícias
-------------------------------------------------------------------------------------------------

 ![15 minutos: impacto da greve geral já se começou a sentir no setor dos transportes - SIC Notícias](https://images.impresa.pt/sicnot/2025-12-12-greve-geral-045a9380/1.91x1?wm=true&outputFormat=jpeg) <small>sicnoticias.pt</small>15 minutos: impacto da greve geral já se começou a sentir no setor dos transportes - SIC Notícias

Imprensa Internacional Destaca Brasil; BBC Vê 1ª Greve Geral Em Mais De 2 Décadas - Pequenas
--------------------------------------------------------------------------------------------

 ![Imprensa internacional destaca Brasil; BBC vê 1ª greve geral em mais de 2 décadas - Pequenas](https://s2.glbimg.com/ZUv7xxUmP55dYzk4H9ue63xjTm0=/940x523/e.glbimg.com/og/ed/f/original/2017/04/28/33337301181_5a55568819_k.jpg) <small>revistapegn.globo.com</small>Imprensa internacional destaca Brasil; BBC vê 1ª greve geral em mais de 2 décadas - Pequenas ...

CET-SP Entra Em Greve A Partir Do Dia 28 De Fevereiro
-----------------------------------------------------

 ![CET-SP entra em greve a partir do dia 28 de fevereiro](https://sindviarios.org.br/wp-content/uploads/2025/02/02-25-greve.jpg) <small>sindviarios.org.br</small>CET-SP entra em greve a partir do dia 28 de fevereiro

Pré-Aviso De Greve - Sexta-feira - 28 De Fevereiro De 2025 - Assistentes Operacionais - AETSM
---------------------------------------------------------------------------------------------

 ![Pré-Aviso de Greve - Sexta-feira - 28 de fevereiro de 2025 - Assistentes Operacionais - AETSM](https://aetsm.pt/wp-content/uploads/2025/02/greve.jpg) <small>aetsm.pt</small>Pré-Aviso de Greve - Sexta-feira - 28 de fevereiro de 2025 - Assistentes Operacionais - AETSM

GREVE GERAL | Trabalhadores Das Autarquias E Sector Empresarial Rejeitam “pacote Laboral”
-----------------------------------------------------------------------------------------

 ![GREVE GERAL | Trabalhadores das autarquias e sector empresarial rejeitam “pacote laboral”](https://www.stal.pt/images/2025/Manif_GreveGeral.jpg) <small>www.stal.pt</small>GREVE GERAL | Trabalhadores das autarquias e sector empresarial rejeitam “pacote laboral”

STIU - Notícias
---------------

 ![STIU - Notícias](https://urbanitarios.org.br/uploads/noticias/cache/600-600-resize/af-praguinhas-9cm-campanha-greve-geral-28-de-abril.jpg) <small>urbanitarios.org.br</small>STIU - Notícias

Boletim De GREVE 44: Informações Da Assembleia Geral De 28/5 | SINTFUB
----------------------------------------------------------------------

 ![Boletim de GREVE 44: informações da Assembleia Geral de 28/5 | SINTFUB](https://www.sintfub.org.br/wp-content/uploads/2024/05/Boletim-de-GREVE-44_2-scaled.jpg) <small>sintfub.org.br</small>Boletim de GREVE 44: informações da Assembleia Geral de 28/5 | SINTFUB

Plataformas: NF Divulga Orientações E Documentos Para A Greve Geral Do Dia 28 - SindipetroNF
--------------------------------------------------------------------------------------------

 ![Plataformas: NF divulga orientações e documentos para a Greve Geral do dia 28 - SindipetroNF](https://sindipetronf.org.br/wp-content/uploads/2017/04/aec733b6b90d52cd1bc758538278b0ef.jpg) <small>sindipetronf.org.br</small>Plataformas: NF divulga orientações e documentos para a Greve Geral do dia 28 - SindipetroNF

Diário Da Greve Geral - CGTP-IN
-------------------------------

 ![Diário da Greve Geral - CGTP-IN](https://www.cgtp.pt/images/images/2025/12/diario_gg/diario-banner.jpg) <small>www.cgtp.pt</small>Diário da Greve Geral - CGTP-IN

A Catraca 🇧🇷 On Twitter: "Professores Da Rede Estadual Aprovam Greve Geral A Patir Do Dia 27 De
-----------------------------------------------------------------------------------------------

 ![A Catraca 🇧🇷 on Twitter: "Professores da rede estadual aprovam greve geral a patir do dia 27 de](https://pbs.twimg.com/media/Fpc4U1oWAAAMqFI.jpg) <small>twitter.com</small>A Catraca 🇧🇷 on Twitter: "Professores da rede estadual aprovam greve geral a patir do dia 27 de ...

Greve Geral - 28/04 - Confira O Local E Horário Nos Municípios - Deputado Federal Padre João
--------------------------------------------------------------------------------------------

 ![Greve Geral - 28/04 - confira o local e horário nos municípios - Deputado Federal Padre João](https://www.padrejoao.com.br/wp-content/uploads/2017/04/28-GREVE-GERAL-e1499885048772.png) <small>www.padrejoao.com.br</small>Greve Geral - 28/04 - confira o local e horário nos municípios - Deputado Federal Padre João

Greve Geral | Ações E Dados
---------------------------

 ![Greve Geral | Ações e dados](https://spzn.pt/uploads/noticias/big_1765534268_2581_SPZN_2025_site_novo_(29).png) <small>spzn.pt</small>Greve Geral | Ações e dados

Coordenação Da CSP-Conlutas Aprova Ações Para A Greve Geral Em 28 De Abril – ADUFPB
-----------------------------------------------------------------------------------

 ![Coordenação da CSP-Conlutas aprova ações para a Greve Geral em 28 de abril – ADUFPB](https://www.adufpb.org.br/site/wp-content/uploads/2017/04/greve-geral-28.03-2.jpg) <small>www.adufpb.org.br</small>Coordenação da CSP-Conlutas aprova ações para a Greve Geral em 28 de abril – ADUFPB

Boletim De GREVE 44: Informações Da Assembleia Geral De 28/5 | SINTFUB
----------------------------------------------------------------------

 ![Boletim de GREVE 44: informações da Assembleia Geral de 28/5 | SINTFUB](https://sintfub.org.br/wp-content/uploads/2024/05/Boletim-de-GREVE-44_1-scaled.jpg) <small>sintfub.org.br</small>Boletim de GREVE 44: informações da Assembleia Geral de 28/5 | SINTFUB

Pré-aviso de greve a 28 fevereiro. Greve geral dia 28/04 – sinecol. Dia 28 de abril, é greve geral!
