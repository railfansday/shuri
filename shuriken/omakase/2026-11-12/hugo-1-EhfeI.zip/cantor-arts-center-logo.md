---
title: "Cantor Arts Center Logo - cantor arts center: museum highlights tour"
description: "Visitor guidelines"
date: "2026-02-02"
categories:
- "Uncategorized"
images:
- "https://media.licdn.com/dms/image/v2/D4E0BAQEGyYxl5g4Msw/company-logo_200_200/company-logo_200_200/0/1704827086024?e=2147483647&amp;v=beta&amp;t=H4O2IHT2WVkYM7pum4nWfMu5-vTQFs1k4itHB5iJzvQ"
featuredImage: "https://priorperformingartscenter.holycross.edu/wp-content/uploads/Cantor-Art-Gallery.jpg"
featured_image: "https://museum.stanford.edu/sites/default/files/images/2021-07/hello-cantor.jpg"
image: "https://museum.stanford.edu/sites/default/files/styles/1_1_xs/public/images/2017-10/cantor-logo.png?itok=v8UGrS4y"
---

If you are looking for Tour of Cantor Arts Center Museum - Stanford University you've visit to the right web. We have 35 Pictures about Tour of Cantor Arts Center Museum - Stanford University like Associate Curator of European Art - Call For Curators, Search Term | Cantor Arts Center and also Cantor Arts Center at Stanford University | Stanford CA. Here you go:

Tour Of Cantor Arts Center Museum - Stanford University
-------------------------------------------------------

 ![Tour of Cantor Arts Center Museum - Stanford University](https://localist-images.azureedge.net/photos/45847000983264/square_300@2x/90462d5a0ea3d90013baed348d013328502219b1.jpg) <small>events.stanford.edu</small>Tour of Cantor Arts Center Museum - Stanford University

Cantor Arts Center At Stanford University
-----------------------------------------

 ![Cantor Arts Center at Stanford University](https://www.paintingsbefore1800.com/PaintingsAA/assets/images/img-20221111-140441-2000x802.jpg) <small>www.paintingsbefore1800.com</small>Cantor Arts Center at Stanford University

Resources For Visitors To Campus - Stanford Arts
------------------------------------------------

 ![Resources for Visitors to Campus - Stanford Arts](https://arts.stanford.edu/wp-content/uploads/bb-plugin/cache/20191220_Cantor_OYYO-6508-square.jpg) <small>arts.stanford.edu</small>Resources for Visitors to Campus - Stanford Arts

Cantor Arts Center - All You SHOULD Know Before Going 2026 (with Reviews)
-------------------------------------------------------------------------

 ![Cantor Arts Center - All You SHOULD Know Before Going 2026 (with Reviews)](https://dynamic-media-cdn.tripadvisor.com/media/photo-o/1a/56/91/e6/front-of-cantor-arts.jpg?w=1400&h=1400&s=1) <small>www.tripadvisor.com</small>Cantor Arts Center - All You SHOULD Know Before Going 2026 (with Reviews)

Stanford’s Cantor Arts Center Adds Over 100 New Works Of Asian American Art | NextShark.com
-------------------------------------------------------------------------------------------

 ![Stanford’s Cantor Arts Center adds over 100 new works of Asian American art | NextShark.com](https://data.nextshark.com/wp-content/uploads/2023/12/Cantor-Arts-Center.jpg) <small>nextshark.com</small>Stanford’s Cantor Arts Center adds over 100 new works of Asian American art | NextShark.com

Extended Hours | Cantor Arts Center
-----------------------------------

 ![Extended Hours | Cantor Arts Center](https://museum.stanford.edu/sites/default/files/images/2024-08/eh-hero.jpeg) <small>museum.stanford.edu</small>Extended Hours | Cantor Arts Center

Search Term | Cantor Arts Center
--------------------------------

 ![Search Term | Cantor Arts Center](https://museum.stanford.edu/sites/default/files/styles/1_1_xs/public/images/2017-10/cantor-logo.png?itok=v8UGrS4y) <small>museum.stanford.edu</small>Search Term | Cantor Arts Center

Cantor Arts Center: Museum Highlights Tour - Stanford University
----------------------------------------------------------------

 ![Cantor Arts Center: Museum Highlights Tour - Stanford University](https://localist-images.azureedge.net/photos/43102446909786/square_300@2x/1282e8aaa20664704040acc93334bfadd477991c.jpg) <small>events.stanford.edu</small>Cantor Arts Center: Museum Highlights Tour - Stanford University

Cantor Arts Center Photos And Premium High Res Pictures - Getty Images
----------------------------------------------------------------------

 ![Cantor Arts Center Photos and Premium High Res Pictures - Getty Images](https://media.gettyimages.com/id/598748816/photo/sign-for-cantor-arts-center-formerly-the-leland-stanford-junior-museum-anderson-collection-and.jpg?s=612x612&w=gi&k=20&c=p7S_sA9xZ2j1EtN5kJ2lPZsAPpCvmzBaOUZFTJwRQR8=) <small>www.gettyimages.ie</small>Cantor Arts Center Photos and Premium High Res Pictures - Getty Images

Corporate Partner Spotlight | Manny Cantor Center
-------------------------------------------------

 ![Corporate Partner Spotlight | Manny Cantor Center](https://static.wixstatic.com/media/ad1a3e_96432110c4514b779504e6c634b20eb9~mv2.png/v1/fill/w_245,h_176,al_c,lg_1,q_85/ad1a3e_96432110c4514b779504e6c634b20eb9~mv2.png) <small>www.nyul.org</small>Corporate Partner Spotlight | Manny Cantor Center

Press Release: Announcement | Cantor Arts Center
------------------------------------------------

 ![Press Release: Announcement | Cantor Arts Center](https://museum.stanford.edu/sites/default/files/styles/1_1_md/public/images/2020-09/virtual-tour-intro-image-logo.png?itok=z1TuGMs2) <small>museum.stanford.edu</small>Press Release: Announcement | Cantor Arts Center

The Cantor Arts Center &amp; Anderson Collection
------------------------------------------------

 ![The Cantor Arts Center & Anderson Collection](https://www.eventbrite.com/organizer-profile/_next/image/?url=https:%2F%2Fimg.evbuc.com%2Fhttps%253A%252F%252Fcdn.evbuc.com%252Fimages%252F113346371%252F294974074263%252F1%252Foriginal.20201002-000508%3Fw%3D2000%26auto%3Dformat%252Ccompress%26q%3D75%26sharp%3D10%26rect%3D29%252C0%252C356%252C356%26s%3D84b6c68ee9bfa3cc1e782165bf4a9c97&w=1880&q=75) <small>www.eventbrite.com</small>The Cantor Arts Center &amp; Anderson Collection

Calendar Genre: Visual Arts | Prior Performing Arts Center
----------------------------------------------------------

 ![Calendar Genre: Visual Arts | Prior Performing Arts Center](https://priorperformingartscenter.holycross.edu/wp-content/uploads/Cantor-Art-Gallery.jpg) <small>priorperformingartscenter.holycross.edu</small>Calendar Genre: Visual Arts | Prior Performing Arts Center

Cantor Arts Center At Stanford University | Stanford CA
-------------------------------------------------------

 ![Cantor Arts Center at Stanford University | Stanford CA](https://lookaside.fbsbx.com/lookaside/crawler/media/?media_id=100063453287604) <small>www.facebook.com</small>Cantor Arts Center at Stanford University | Stanford CA

Cantor Arts Center Photos And Premium High Res Pictures - Getty Images
----------------------------------------------------------------------

 ![Cantor Arts Center Photos and Premium High Res Pictures - Getty Images](https://media.gettyimages.com/id/598748694/photo/signage-at-entrance-to-cantor-arts-center-formerly-the-leland-stanford-junior-museum-with-full.jpg?s=612x612&w=gi&k=20&c=0onH0O89QEGcSt5Ci_OpbFu0t5V6hSGXJMZ0U9dKO38=) <small>www.gettyimages.ie</small>Cantor Arts Center Photos and Premium High Res Pictures - Getty Images

IMU UR2 Symposium | Cantor Arts Center
--------------------------------------

 ![IMU UR2 Symposium | Cantor Arts Center](https://museum.stanford.edu/sites/default/files/images/2022-09/1st-row-logos-symposium.png) <small>museum.stanford.edu</small>IMU UR2 Symposium | Cantor Arts Center

Assistant Curator For Special Projects - Cantor Arts Center
-----------------------------------------------------------

 ![Assistant Curator for Special Projects - Cantor Arts Center](https://callforcurators.com/wp-content/uploads/2012/11/cantorartcenter.jpg) <small>callforcurators.com</small>Assistant Curator for Special Projects - Cantor Arts Center

Update On Cantor's Interim Leadership | Cantor Arts Center Press Releases
-------------------------------------------------------------------------

 ![Update on Cantor's Interim Leadership | Cantor Arts Center Press Releases](https://museum.stanford.edu/sites/default/files/styles/width_constrained_md/public/images/2017-11/5-press-release-cantoridentity-argb.jpg?itok=ax6DnGne) <small>museum.stanford.edu</small>Update on Cantor's Interim Leadership | Cantor Arts Center Press Releases

Associate Curator Of European Art - Call For Curators
-----------------------------------------------------

 ![Associate Curator of European Art - Call For Curators](https://callforcurators.com/wp-content/uploads/2019/03/cantor-art-center.jpg) <small>callforcurators.com</small>Associate Curator of European Art - Call For Curators

Adventures In Weseland: Cantor Arts Center
------------------------------------------

 ![Adventures in Weseland: Cantor Arts Center](https://1.bp.blogspot.com/-X7zjg-jQmzA/XmowB1SU3rI/AAAAAAAAl1g/LVUotU4ZMlMVsAJhCM1f_rDFfwwzjxbVgCLcBGAsYHQ/w1200-h630-p-k-no-nu/20191012_122825.jpg) <small>csuhpat1.blogspot.com</small>Adventures in Weseland: Cantor Arts Center

Free Summer Adventures In And Around Stanford
---------------------------------------------

 ![Free summer adventures in and around Stanford](https://stanforddaily.com/wp-content/uploads/2018/07/Cantor_Arts_Center_sign.jpg) <small>stanforddaily.com</small>Free summer adventures in and around Stanford

Visitor Guidelines | Cantor Arts Center
---------------------------------------

 ![Visitor Guidelines | Cantor Arts Center](https://museum.stanford.edu/themes/custom/cantor/assets/images/optimized/identity-ldpi.png) <small>museum.stanford.edu</small>Visitor Guidelines | Cantor Arts Center

Cantor Arts Center - Stanford University
----------------------------------------

 ![Cantor Arts Center - Stanford University](https://localist-images.azureedge.net/photos/39183653332271/square_300@2x/27f55fd46d828d18149e63d3559d9acf3ffbdf0c.jpg) <small>events.stanford.edu</small>Cantor Arts Center - Stanford University

Visit | Cantor Arts Center
--------------------------

 ![Visit | Cantor Arts Center](https://museum.stanford.edu/sites/default/files/images/2020-04/cover.png) <small>museum.stanford.edu</small>Visit | Cantor Arts Center

Hello, Cantor | Cantor Arts Center
----------------------------------

 ![Hello, Cantor | Cantor Arts Center](https://museum.stanford.edu/sites/default/files/images/2021-07/hello-cantor.jpg) <small>museum.stanford.edu</small>Hello, Cantor | Cantor Arts Center

Cantor Arts Center Open To Returning Cultural Objects To Native American Tribes
-------------------------------------------------------------------------------

 ![Cantor Arts Center open to returning cultural objects to Native American tribes](https://stanforddaily.com/wp-content/uploads/2020/08/cantor-copy.png) <small>stanforddaily.com</small>Cantor Arts Center open to returning cultural objects to Native American tribes

Cantor Arts Center - Wikipedia
------------------------------

 ![Cantor Arts Center - Wikipedia](https://upload.wikimedia.org/wikipedia/commons/thumb/3/37/Cantor_Art_Center_%2B_Anderson_Collection_logo_Stanford_2024.png/500px-Cantor_Art_Center_%2B_Anderson_Collection_logo_Stanford_2024.png) <small>en.wikipedia.org</small>Cantor Arts Center - Wikipedia

El Anatsui | Cantor Arts Center
-------------------------------

 ![El Anatsui | Cantor Arts Center](https://elanatsui.art/cms/2019/04/Iris-B.-Gerald-Cantor-Center-for-Visual-Arts-Stanford-University-California-Photo-courtesy-Sothebys-Museum-Network-720x720.jpg) <small>elanatsui.art</small>El Anatsui | Cantor Arts Center

Cantor Arts Center At Stanford University | San José Museum Of Art
------------------------------------------------------------------

 ![Cantor Arts Center at Stanford University | San José Museum of Art](https://sjmusart.org/sites/default/files/nt-partner-pg-cac.jpg) <small>sjmusart.org</small>Cantor Arts Center at Stanford University | San José Museum of Art

Cantor Arts Center: Defining The Contemporary Museum Experience
---------------------------------------------------------------

 ![Cantor Arts Center: Defining the contemporary museum experience](https://stanforddaily.com/wp-content/uploads/2019/07/IMG_2096.jpg) <small>stanforddaily.com</small>Cantor Arts Center: Defining the contemporary museum experience

Cantor Arts Center - El Prado Hotel
-----------------------------------

 ![Cantor Arts Center - El Prado Hotel](https://image-tc.galaxy.tf/wijpeg-8cofgcf9lgxqts3ay5d3i606e/adobestock-284253985-editorial-use-only_wide.jpg?crop=0%2C84%2C1600%2C900&width=1100) <small>www.elpradopaloalto.com</small>Cantor Arts Center - El Prado Hotel

Cantor Arts Center At Stanford University In Stanford | AskArtera
-----------------------------------------------------------------

 ![Cantor Arts Center at Stanford University in Stanford | AskArtera](https://d2w8kbdekdi1gv.cloudfront.net/eyJidWNrZXQiOiAiYXJ0ZXJhLWltYWdlcy1idWNrZXQiLCAia2V5IjogInByb2ZpbGVzLzU2ZTFhZDI2LTg0YWQtNDExMC1iMzEwLTAzNzViMTEyNjU5MC81NmUxYWQyNi04NGFkLTQxMTAtYjMxMC0wMzc1YjExMjY1OTBfcHJvZmlsZV9waWN0dXJlLmpwZyIsICJlZGl0cyI6IHsicmVzaXplIjogeyJ3aWR0aCI6IDE5MjAsICJoZWlnaHQiOiAxOTIwLCAiZml0IjogImluc2lkZSJ9fX0=) <small>www.artera.ae</small>Cantor Arts Center at Stanford University in Stanford | AskArtera

Cantorartscenter | Instagram, Facebook | Linktree
-------------------------------------------------

 ![cantorartscenter | Instagram, Facebook | Linktree](https://linktr.ee/og/image/cantorartscenter.jpg) <small>linktr.ee</small>cantorartscenter | Instagram, Facebook | Linktree

Cantor Center | LinkedIn
------------------------

 ![Cantor Center | LinkedIn](https://media.licdn.com/dms/image/v2/D4E0BAQEGyYxl5g4Msw/company-logo_200_200/company-logo_200_200/0/1704827086024?e=2147483647&v=beta&t=H4O2IHT2WVkYM7pum4nWfMu5-vTQFs1k4itHB5iJzvQ) <small>www.linkedin.com</small>Cantor Center | LinkedIn

Cantor Arts Center - Stanford University
----------------------------------------

 ![Cantor Arts Center - Stanford University](https://localist-images.azureedge.net/photos/41032210167233/square_300@2x/960b7b7690505dda8ee03ba824b8f1763ac82d09.jpg) <small>events.stanford.edu</small>Cantor Arts Center - Stanford University

Free summer adventures in and around stanford. Adventures in weseland: cantor arts center. Cantor arts center
