---
title: "Greve Geral 12 Dezembro 2025 - Lutar pela segurança no emprego de todos é aderir à greve geral!"
description: "11 de dezembro. portugal terá a sua primeira greve geral em 12 anos contra o pacote laboral"
date: "2025-12-07"
categories:
- "Uncategorized"
images:
- "https://static.wixstatic.com/media/d0f32c_9ff1199ee2c34418af0094a43c516733~mv2.png/v1/fill/w_940,h_788,al_c,q_90,enc_avif,quality_auto/d0f32c_9ff1199ee2c34418af0094a43c516733~mv2.png"
featuredImage: "https://www.cgtp.pt/images/images/2025/12/diario_gg/diario-banner.jpg"
featured_image: "https://sinapsa.pt/wp-content/uploads/2025/12/Info_Sindical_53_Dezembro_2025_Greve_Geral.jpg"
image: "https://spzn.pt/uploads/noticias/big_1763717239_6728_SPZN_2025_site_novo_(17).png"
---

If you are looking for FAQ: Os direitos dos docentes em dia de Greve Geral - 11/12/2025 you've came to the right web. We have 35 Images about FAQ: Os direitos dos docentes em dia de Greve Geral - 11/12/2025 like UGT vai reunir-se com ministra do Trabalho mas avisa que "é impossível negociar" sozinha a, Depois da Greve Geral, mais uma paralisação marcada para 12 de dezembro | A Bola and also Agrupamento de Escolas de Mira - Pré - aviso de greve para os dias 11 e 12 de dezembro de 2025. Here you go:

FAQ: Os Direitos Dos Docentes Em Dia De Greve Geral - 11/12/2025
----------------------------------------------------------------

 ![FAQ: Os direitos dos docentes em dia de Greve Geral - 11/12/2025](https://static.wixstatic.com/media/d0f32c_9ff1199ee2c34418af0094a43c516733~mv2.png/v1/fill/w_940,h_788,al_c,q_90,enc_avif,quality_auto/d0f32c_9ff1199ee2c34418af0094a43c516733~mv2.png) <small>www.sprc.pt</small>FAQ: Os direitos dos docentes em dia de Greve Geral - 11/12/2025

Greve Geral Deverá Ter Impacto Inferior A 0,1% Do PIB – ECO
-----------------------------------------------------------

 ![Greve geral deverá ter impacto inferior a 0,1% do PIB – ECO](https://eco.imgix.net/uploads/2025/12/cropped-46141990-scaled.jpg) <small>eco.sapo.pt</small>Greve geral deverá ter impacto inferior a 0,1% do PIB – ECO

Informações E Esclarecimentos Sobre A Greve A Todo O Trabalho Associado às Provas-Ensaio 2025
---------------------------------------------------------------------------------------------

 ![Informações e esclarecimentos sobre a greve a todo o trabalho associado às Provas-Ensaio 2025](https://stop-sindicato.pt/wp-content/uploads/2025/02/S.TO_.P.-Capa-Info-Greve-Provas-Ensaio-2025-768x337.png) <small>stop-sindicato.pt</small>Informações e esclarecimentos sobre a greve a todo o trabalho associado às Provas-Ensaio 2025 ...

PRÉ-AVISO DE GREVE 11 E 12 De Dezembro De 2025 – Agrupamento De Escolas De Miranda Do Corvo
-------------------------------------------------------------------------------------------

 ![PRÉ-AVISO DE GREVE 11 e 12 de Dezembro de 2025 – Agrupamento de Escolas de Miranda do Corvo](https://aemc.edu.pt/wp-content/uploads/2025/12/2025_12_04_17_24_12_Greve_11_12_2025_Word.png) <small>aemc.edu.pt</small>PRÉ-AVISO DE GREVE 11 e 12 de Dezembro de 2025 – Agrupamento de Escolas de Miranda do Corvo

Greve Geral Vista Das Ruas: Manhã Cinzenta, Autocarros Vazios E Um País Que Abrandou O Passo
--------------------------------------------------------------------------------------------

 ![Greve geral vista das ruas: manhã cinzenta, autocarros vazios e um país que abrandou o passo](https://images.impresa.pt/expresso/2025-12-11-fox_greve_geral_0018.jpg-6e16cd12-1) <small>expresso.pt</small>Greve geral vista das ruas: manhã cinzenta, autocarros vazios e um país que abrandou o passo ...

GREVE GERAL – Dia 11 De Dezembro | Sincomar - Sindicato De Capitães E Oficiais Da Marinha Mercante
--------------------------------------------------------------------------------------------------

 ![GREVE GERAL – Dia 11 de Dezembro | Sincomar - Sindicato de Capitães e Oficiais da Marinha Mercante](https://sincomar.pt/wp-content/uploads/2025/12/2-cartaz-GREVE-GERAL-UGT-final.jpg) <small>sincomar.pt</small>GREVE GERAL – Dia 11 de Dezembro | Sincomar - Sindicato de Capitães e Oficiais da Marinha Mercante

15 Minutos: Impacto Da Greve Geral Já Se Começou A Sentir No Setor Dos Transportes - SIC Notícias
-------------------------------------------------------------------------------------------------

 ![15 minutos: impacto da greve geral já se começou a sentir no setor dos transportes - SIC Notícias](https://images.impresa.pt/sicnot/2025-12-12-greve-geral-045a9380/1.91x1?wm=true&outputFormat=jpeg) <small>sicnoticias.pt</small>15 minutos: impacto da greve geral já se começou a sentir no setor dos transportes - SIC Notícias

Balanço Da Greve Geral - CGTP-IN
--------------------------------

 ![Balanço da Greve Geral - CGTP-IN](https://www.cgtp.pt/images/images/2025/11/gg_banner2025.jpg) <small>www.cgtp.pt</small>Balanço da Greve Geral - CGTP-IN

Motivos Da Adesão à Greve Geral De 11 De Dezembro De 2025
---------------------------------------------------------

 ![Motivos da adesão à Greve Geral de 11 de dezembro de 2025](https://spzn.pt/uploads/noticias/big_1763717239_6728_SPZN_2025_site_novo_(17).png) <small>spzn.pt</small>Motivos da adesão à Greve Geral de 11 de dezembro de 2025

Greve Geral Paralisa Transportes, Saúde E Educação No Porto - Expresso
----------------------------------------------------------------------

 ![Greve geral paralisa transportes, saúde e educação no Porto - Expresso](https://images.impresa.pt/expresso/2025-12-11-rds_15_greve-geral-2025-manifestacao-porto_rds_4314.jpg-f75ffda9/original) <small>expresso.pt</small>Greve geral paralisa transportes, saúde e educação no Porto - Expresso

Depois Da Greve Geral, Mais Uma Paralisação Marcada Para 12 De Dezembro | A Bola
--------------------------------------------------------------------------------

 ![Depois da Greve Geral, mais uma paralisação marcada para 12 de dezembro | A Bola](https://sportal365images.com/process/smp-images-production/abola.pt/09122025/6efc249f-1534-4fe0-94ae-f9c29c518ecd.webp?operations=scale(860:574)) <small>www.abola.pt</small>Depois da Greve Geral, mais uma paralisação marcada para 12 de dezembro | A Bola

Visão | A Greve Geral
---------------------

 ![Visão | A greve geral](https://images.trustinnews.pt/uploads/sites/5/2025/12/251210_DOC.20251117.46046239.JSG9_-1-1600x1067.jpg) <small>visao.pt</small>Visão | A greve geral

🔴 Ao Minuto: Foi Assim A Greve Geral De 11 De Dezembro De 2025 - Renascença
---------------------------------------------------------------------------

 ![🔴 Ao minuto: Foi assim a greve geral de 11 de dezembro de 2025 - Renascença](https://images.rr.pt/geve-geral-de-11-de-dezembro-de-2025-na-assembleia-da-republica-foto-ricardo-fortunato-rr-31311c45c_socialshare.jpg) <small>rr.pt</small>🔴 Ao minuto: Foi assim a greve geral de 11 de dezembro de 2025 - Renascença

Sindicatos Independentes Aderem à Greve Geral Pela Primeira Vez E Juntam-se à UGT E CGTP - Expresso
---------------------------------------------------------------------------------------------------

 ![Sindicatos independentes aderem à greve geral pela primeira vez e juntam-se à UGT e CGTP - Expresso](https://images.impresa.pt/expresso/2025-11-27-greve-geral-anuncio-para-a-realizacao-de-greve-a-11-de-dezembro-marques-pombal--9b289114/original) <small>expresso.pt</small>Sindicatos independentes aderem à greve geral pela primeira vez e juntam-se à UGT e CGTP - Expresso

Agrupamento De Escolas De Mira - Pré - Aviso De Greve Para Os Dias 11 E 12 De Dezembro De 2025
----------------------------------------------------------------------------------------------

 ![Agrupamento de Escolas de Mira - Pré - aviso de greve para os dias 11 e 12 de dezembro de 2025](https://www.escolasdemira.pt/images/PR-_AVISO_DE_GREVE_para_os_dias_11_e_12_de_dezembro_de_2025.png) <small>www.escolasdemira.pt</small>Agrupamento de Escolas de Mira - Pré - aviso de greve para os dias 11 e 12 de dezembro de 2025

Greve Geral. Metro De Lisboa Prevê Paralisação Do Serviço E Encerramento Das Estações – ECO
-------------------------------------------------------------------------------------------

 ![Greve Geral. Metro de Lisboa prevê paralisação do serviço e encerramento das estações – ECO](https://eco.imgix.net/uploads/2025/12/thumb-1.jpg) <small>eco.sapo.pt</small>Greve Geral. Metro de Lisboa prevê paralisação do serviço e encerramento das estações – ECO

A GREVE GERAL
-------------

 ![A GREVE GERAL](https://duaslinhas.pt/wp-content/uploads/2025/12/greve-geral-capa-1024x576.png) <small>duaslinhas.pt</small>A GREVE GERAL

Lutar Pela Segurança No Emprego De Todos é Aderir à Greve Geral! - SINAPSA
--------------------------------------------------------------------------

 ![Lutar pela segurança no Emprego de todos é aderir à Greve Geral! - SINAPSA](https://sinapsa.pt/wp-content/uploads/2025/12/Info_Sindical_53_Dezembro_2025_Greve_Geral.jpg) <small>sinapsa.pt</small>Lutar pela segurança no Emprego de todos é aderir à Greve Geral! - SINAPSA

UGT Vai Reunir-se Com Ministra Do Trabalho Mas Avisa Que "é Impossível Negociar" Sozinha A
------------------------------------------------------------------------------------------

 ![UGT vai reunir-se com ministra do Trabalho mas avisa que "é impossível negociar" sozinha a](https://img.iol.pt/image/id/693b2a1ad34e3caad84c47e9/1024.jpg) <small>cnnportugal.iol.pt</small>UGT vai reunir-se com ministra do Trabalho mas avisa que "é impossível negociar" sozinha a ...

Sindicatos Fazem Pré-aviso De Greve Para Aeroportos No Final De Ano – ECO
-------------------------------------------------------------------------

 ![Sindicatos fazem pré-aviso de greve para aeroportos no final de ano – ECO](https://eco.imgix.net/uploads/2025/12/montengro-greve.jpg) <small>eco.sapo.pt</small>Sindicatos fazem pré-aviso de greve para aeroportos no final de ano – ECO

SDP Sul
-------

 ![SDP Sul](https://sdpsul.com/storage/publicacao/imagem_563_6929dba6ddf62.jpeg) <small>sdpsul.com</small>SDP Sul

Aviso Prévio De Greves - 11 E 12 De Dezembro 2025
-------------------------------------------------

 ![Aviso Prévio de Greves - 11 e 12 de dezembro 2025](https://aefernandopessoafeira.pt/images/noticias/2025/aviso-previo-de-greve/aviso-previo-de-greve.jpg) <small>aefernandopessoafeira.pt</small>Aviso Prévio de Greves - 11 e 12 de dezembro 2025

Greve Geral Pára País 12 Anos Depois - Sociedade - Correio Da Manhã
-------------------------------------------------------------------

 ![Greve geral pára País 12 anos depois - Sociedade - Correio da Manhã](https://cdn.cmjornal.pt/images/2025-12/img_1500x1000uu2025-12-10-22-06-51-2253721.jpg) <small>www.cmjornal.pt</small>Greve geral pára País 12 anos depois - Sociedade - Correio da Manhã

📹 Esta Quinta-feira Há Greve Geral. Sabe Porquê? – ECO
------------------------------------------------------

 ![📹 Esta quinta-feira há greve geral. Sabe porquê? – ECO](https://eco.imgix.net/uploads/2025/11/cropped-doc2025110845998234acot9063.jpg) <small>eco.sapo.pt</small>📹 Esta quinta-feira há greve geral. Sabe porquê? – ECO

Agora é GREVE GERAL!
--------------------

 ![Agora é GREVE GERAL!](https://jundiagora.com.br/wp-content/uploads/2023/01/greve-geral.jpg) <small>jundiagora.com.br</small>Agora é GREVE GERAL!

Diário Da Greve Geral - CGTP-IN
-------------------------------

 ![Diário da Greve Geral - CGTP-IN](https://www.cgtp.pt/images/images/2025/12/diario_gg/diario-banner.jpg) <small>www.cgtp.pt</small>Diário da Greve Geral - CGTP-IN

CGIL: Greve Geral No Dia 12 De Dezembro Para Protestar Contra A Lei Orçamental - Rádio Miróbriga
------------------------------------------------------------------------------------------------

 ![CGIL: greve geral no dia 12 de dezembro para protestar contra a lei orçamental - Rádio Miróbriga](https://www.radiom24.pt/wp-content/uploads/2025/11/CGIL-greve-geral-no-dia-12-de-dezembro-para-protestar-2048x1366.jpg) <small>www.radiom24.pt</small>CGIL: greve geral no dia 12 de dezembro para protestar contra a lei orçamental - Rádio Miróbriga

Pré-Aviso De Greve 11 E 12 De Dezembro
--------------------------------------

 ![Pré-Aviso de Greve 11 e 12 de dezembro](https://static.wixstatic.com/media/1029eb_a6db1017a2334a9abf146e02d7454c28~mv2.png/v1/fill/w_770,h_395,al_c,lg_1,q_85/1029eb_a6db1017a2334a9abf146e02d7454c28~mv2.png) <small>www.aecadaval.com</small>Pré-Aviso de Greve 11 e 12 de dezembro

Entre O Dever De Informar E A Adesão è Greve, Sindicato Dos Jornalistas Faz Balanço
-----------------------------------------------------------------------------------

 ![Entre o dever de informar e a adesão è greve, Sindicato dos Jornalistas faz balanço](https://eco.imgix.net/uploads/2025/12/cropped-greve-geral03.jpg) <small>eco.sapo.pt</small>Entre o dever de informar e a adesão è greve, Sindicato dos Jornalistas faz balanço ...

Há Muitas Razões Para Aderir à Greve Geral - SINAPSA
----------------------------------------------------

 ![Há muitas razões para aderir à Greve Geral - SINAPSA](https://sinapsa.pt/wp-content/uploads/2025/11/Info_Sindical_51_Novembro_2025_Greve_Geral_Site_2.jpg) <small>sinapsa.pt</small>Há muitas razões para aderir à Greve Geral - SINAPSA

11 De Dezembro. Portugal Terá A Sua Primeira Greve Geral Em 12 Anos Contra O Pacote Laboral
-------------------------------------------------------------------------------------------

 ![11 de Dezembro. Portugal terá a sua primeira Greve Geral em 12 anos contra o pacote laboral](https://www.esquerdadiario.com.br/IMG/logo/imagem_do_whatsapp_de_2025-11-18_a_s_20.02_31_2e7bdf41.jpg?1763508227) <small>www.esquerdadiario.com.br</small>11 de Dezembro. Portugal terá a sua primeira Greve Geral em 12 anos contra o pacote laboral ...

Portugal: Greve Geral - CIG: Confederación Intersindical Galega
---------------------------------------------------------------

 ![Portugal: Greve geral - CIG: Confederación Intersindical Galega](https://www.cig.gal/assets/images/0/20251212_greve.PT-c79520e0.jpg) <small>www.cig.gal</small>Portugal: Greve geral - CIG: Confederación Intersindical Galega

A Greve Geral De 11 De Dezembro Em 38 Imagens – Observador
----------------------------------------------------------

 ![A greve geral de 11 de dezembro em 38 imagens – Observador](https://bordalo.observador.pt/v2/q:60/rs:fill:1440/c:4096:2730:nowe:0:0/plain/https://s3.observador.pt/wp-content/uploads/2025/12/11173246/dventura-greve-geral-11dez-43-scaled.jpg) <small>observador.pt</small>A greve geral de 11 de dezembro em 38 imagens – Observador

Trabalhadores Mobilizam-se Para A Greve Geral Nos Açores – Rádio Lumena
-----------------------------------------------------------------------

 ![Trabalhadores mobilizam-se para a Greve Geral nos Açores – Rádio Lumena](https://radiolumena.com/wp-content/uploads/2025/12/GreveGeralCGTP_11dez25_.jpg) <small>radiolumena.com</small>Trabalhadores mobilizam-se para a Greve Geral nos Açores – Rádio Lumena

GREVE GERAL | 11 DEZEMBRO 2025 - ATE
------------------------------------

 ![GREVE GERAL | 11 DEZEMBRO 2025 - ATE](https://www.ate.pt/wp-content/uploads/2025/12/Greve-geral-11.12.jpg) <small>www.ate.pt</small>GREVE GERAL | 11 DEZEMBRO 2025 - ATE

Cgil: greve geral no dia 12 de dezembro para protestar contra a lei orçamental. Pré-aviso de greve 11 e 12 de dezembro de 2025 – agrupamento de escolas de miranda do corvo. A greve geral
