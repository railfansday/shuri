---
title: "Greve Geral 11 Dezembro Quem Tem Direito - Category:general strike 11 december 2025 (portugal)"
description: "A greve geral de 11 de dezembro em 38 imagens – observador"
date: "2026-11-02"
categories:
- "Uncategorized"
images:
- "https://www.fertagus.pt/portals/0/FTG-Greve-Geral-web-1253x886.jpg"
featuredImage: "https://ogimg.infoglobo.com.br/in/2920985-315-96f/FT1086A/Manifestante-no-Centro-de-Lisboa-na-primeira-greve-geral-em-mais-de-duas-decadasFrancisco-LeongAFP.jpg"
featured_image: "https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA1Q3P3K.img?w=860&amp;h=471&amp;m=4&amp;q=87"
image: "https://cdn.sabado.pt/images/2025-12/img_980x653uu2025-12-22-09-03-14-753915.jpg"
---

If you are looking for FNSTFPS adere à Greve Geral de 11 de Dezembro - CGTP-IN you've came to the right place. We have 35 Pics about FNSTFPS adere à Greve Geral de 11 de Dezembro - CGTP-IN like SPN - Fenprof — Adesão histórica à greve geral, SINDEP - Greve Geral 11 de dezembro and also Greve geral paralisa Portugal contra precarização de direitos. Read more:

FNSTFPS Adere à Greve Geral De 11 De Dezembro - CGTP-IN
-------------------------------------------------------

 ![FNSTFPS adere à Greve Geral de 11 de Dezembro - CGTP-IN](https://www.cgtp.pt/images/accao-e-luta/2025/54910179541_10702918c8_c.jpg) <small>www.cgtp.pt</small>FNSTFPS adere à Greve Geral de 11 de Dezembro - CGTP-IN

Greve Geral De 11 De Dezembro Em Portugal: Razões Para Participar
-----------------------------------------------------------------

 ![Greve Geral de 11 de dezembro em Portugal: razões para participar](https://sabiasque.pt/images/stories/2025/trabalho/20251209-greve-geral-11-dezembro-320x480.jpg) <small>sabiasque.pt</small>Greve Geral de 11 de dezembro em Portugal: razões para participar

A Greve Geral De 11 De Dezembro Em 38 Imagens – Observador
----------------------------------------------------------

 ![A greve geral de 11 de dezembro em 38 imagens – Observador](https://bordalo.observador.pt/v2/q:60/rs:fill:1440/c:4096:2730:nowe:0:0/plain/https://s3.observador.pt/wp-content/uploads/2025/12/11173246/dventura-greve-geral-11dez-43-scaled.jpg) <small>observador.pt</small>A greve geral de 11 de dezembro em 38 imagens – Observador

Agrupamento De Escolas De Mira - Pré - Aviso De Greve Para Os Dias 11 E 12 De Dezembro De 2025
----------------------------------------------------------------------------------------------

 ![Agrupamento de Escolas de Mira - Pré - aviso de greve para os dias 11 e 12 de dezembro de 2025](https://www.escolasdemira.pt/images/PR-_AVISO_DE_GREVE_para_os_dias_11_e_12_de_dezembro_de_2025.png) <small>www.escolasdemira.pt</small>Agrupamento de Escolas de Mira - Pré - aviso de greve para os dias 11 e 12 de dezembro de 2025

Greve Geral Paralisa Portugal Contra Precarização De Direitos
-------------------------------------------------------------

 ![Greve geral paralisa Portugal contra precarização de direitos](https://pcdob.org.br/wp-content/uploads/2025/12/Ruas-de-Lisboa-foram-tomadas-por-trabalhadores-durante-a-greve-geral-Rafael-Medeiros-Esquerda.jpg) <small>pcdob.org.br</small>Greve geral paralisa Portugal contra precarização de direitos

Greves Gerais? "Os Trabalhadores Unem-se Quando A Ofensiva é Grande"
--------------------------------------------------------------------

 ![Greves gerais? "Os trabalhadores unem-se quando a ofensiva é grande"](https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA24x2oz.img?w=768&h=432&m=6) <small>www.msn.com</small>Greves gerais? "Os trabalhadores unem-se quando a ofensiva é grande"

UGT Avança Para Greve Geral A 11 De Dezembro
--------------------------------------------

 ![UGT avança para greve geral a 11 de dezembro](https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA1Q3P3K.img?w=860&h=471&m=4&q=87) <small>www.msn.com</small>UGT avança para greve geral a 11 de dezembro

Motivos Da Adesão à Greve Geral De 11 De Dezembro De 2025
---------------------------------------------------------

 ![Motivos da adesão à Greve Geral de 11 de dezembro de 2025](https://spzn.pt/uploads/noticias/big_1763717239_6728_SPZN_2025_site_novo_(17).png) <small>spzn.pt</small>Motivos da adesão à Greve Geral de 11 de dezembro de 2025

GREVE GERAL | 11 DEZEMBRO 2025 - ATE
------------------------------------

 ![GREVE GERAL | 11 DEZEMBRO 2025 - ATE](https://www.ate.pt/wp-content/uploads/2025/12/Greve-geral-11.12.jpg) <small>www.ate.pt</small>GREVE GERAL | 11 DEZEMBRO 2025 - ATE

CIL Apoia A Greve Geral Do Próximo Dia 11 De Dezembro - CGTP-IN
---------------------------------------------------------------

 ![CIL apoia a Greve Geral do próximo dia 11 de Dezembro - CGTP-IN](https://www.cgtp.pt/images/accao-e-luta/2025/54909309207_62b0afa28f_o1.jpg) <small>www.cgtp.pt</small>CIL apoia a Greve Geral do próximo dia 11 de Dezembro - CGTP-IN

TCB | Pré-aviso De Greve A 11 De Dezembro - Portal Institucional
----------------------------------------------------------------

 ![TCB | Pré-aviso de greve a 11 de dezembro - Portal Institucional](https://www.cm-barreiro.pt/wp-content/uploads/2025/12/GREVE-11_DEZEMBRO_1920px-1536x920.jpg) <small>www.cm-barreiro.pt</small>TCB | Pré-aviso de greve a 11 de dezembro - Portal Institucional

Maioria Dos Portugueses Diz Que Greve Geral Foi Justificada - Portugal - SÁBADO
-------------------------------------------------------------------------------

 ![Maioria dos portugueses diz que greve geral foi justificada - Portugal - SÁBADO](https://cdn.sabado.pt/images/2025-12/img_980x653uu2025-12-22-09-03-14-753915.jpg) <small>www.sabado.pt</small>Maioria dos portugueses diz que greve geral foi justificada - Portugal - SÁBADO

VISEU - Esclarecimento E Mobilização Para A Greve Geral Marcada Para 11 De Dezembro - CGTP-IN
---------------------------------------------------------------------------------------------

 ![VISEU - Esclarecimento e mobilização para a Greve Geral marcada para 11 de Dezembro - CGTP-IN](https://www.cgtp.pt/images/accao-e-luta/2025/gg.jpg) <small>www.cgtp.pt</small>VISEU - Esclarecimento e mobilização para a Greve Geral marcada para 11 de Dezembro - CGTP-IN

SINDEP - Greve Geral 11 De Dezembro
-----------------------------------

 ![SINDEP - Greve Geral 11 de dezembro](https://sindep.pt/images/cartaz_GREVE_GERAL_UGT.jpg) <small>sindep.pt</small>SINDEP - Greve Geral 11 de dezembro

SPN - ESI — Participação Expressiva Na Greve Geral (11/dez)
-----------------------------------------------------------

 ![SPN - ESI — Participação expressiva na greve geral (11/dez)](https://www.spn.pt/Media/Default/_Profiles/ee10172b/dadfb8d0/ESI — Greve Geral (cartaz).jpg?v=639008760992974253) <small>www.spn.pt</small>SPN - ESI — Participação expressiva na greve geral (11/dez)

Informações | Greve Geral De 11 Dezembro
----------------------------------------

 ![Informações | Greve Geral de 11 dezembro](https://fne.pt/uploads/noticias/big_1764325137_7603_InfoGreve.jpeg) <small>fne.pt</small>Informações | Greve Geral de 11 dezembro

Greve Histórica Em Portugal: Três Milhões Cruzam Os Braços Em Protesto Contra Medidas De
----------------------------------------------------------------------------------------

 ![Greve histórica em Portugal: três milhões cruzam os braços em protesto contra medidas de](https://ogimg.infoglobo.com.br/in/2920985-315-96f/FT1086A/Manifestante-no-Centro-de-Lisboa-na-primeira-greve-geral-em-mais-de-duas-decadasFrancisco-LeongAFP.jpg) <small>oglobo.globo.com</small>Greve histórica em Portugal: três milhões cruzam os braços em protesto contra medidas de ...

Pré-Aviso De Greve 11 E 12 De Dezembro
--------------------------------------

 ![Pré-Aviso de Greve 11 e 12 de dezembro](https://static.wixstatic.com/media/1029eb_b4cf39036f744ea9833c234b7b4b5af5~mv2.jpg/v1/fill/w_980,h_1386,al_c,q_85,usm_0.66_1.00_0.01,enc_avif,quality_auto/1029eb_b4cf39036f744ea9833c234b7b4b5af5~mv2.jpg) <small>www.aecadaval.com</small>Pré-Aviso de Greve 11 e 12 de dezembro

Greve Geral Contra Pacote Laboral A 11 De Dezembro (vídeo) – RTP Madeira
------------------------------------------------------------------------

 ![Greve geral contra pacote laboral a 11 de dezembro (vídeo) – RTP Madeira](https://madeira.rtp.pt/wp-content/uploads/2025/11/DOC.20251108.45998234.ACOT9063-scaled.jpg) <small>madeira.rtp.pt</small>Greve geral contra pacote laboral a 11 de dezembro (vídeo) – RTP Madeira

A Greve Geral De 11 De Dezembro Em 38 Imagens – Observador
----------------------------------------------------------

 ![A greve geral de 11 de dezembro em 38 imagens – Observador](https://bordalo.observador.pt/v2/q:60/rs:fill:1440/c:4096:2730:nowe:0:0/plain/https://s3.observador.pt/wp-content/uploads/2025/12/11090822/dventura-greve-geral-11dez-8-scaled.jpg) <small>observador.pt</small>A greve geral de 11 de dezembro em 38 imagens – Observador

A Greve Geral De 11 De Dezembro Em 38 Imagens – Observador
----------------------------------------------------------

 ![A greve geral de 11 de dezembro em 38 imagens – Observador](https://bordalo.observador.pt/v2/q:60/rs:fill:1440/c:4096:2730:nowe:0:0/plain/https://s3.observador.pt/wp-content/uploads/2025/12/11173228/dventura-greve-geral-11dez-41-scaled.jpg) <small>observador.pt</small>A greve geral de 11 de dezembro em 38 imagens – Observador

FAQ: Os Direitos Dos Docentes Em Dia De Greve Geral - 11/12/2025
----------------------------------------------------------------

 ![FAQ: Os direitos dos docentes em dia de Greve Geral - 11/12/2025](https://static.wixstatic.com/media/d0f32c_9ff1199ee2c34418af0094a43c516733~mv2.png/v1/fill/w_940,h_788,al_c,q_90,enc_avif,quality_auto/d0f32c_9ff1199ee2c34418af0094a43c516733~mv2.png) <small>www.sprc.pt</small>FAQ: Os direitos dos docentes em dia de Greve Geral - 11/12/2025

Fertagus &gt; Fertagus (pt) &gt; Viajar &gt; Comunicados E Campanhas &gt; Greve Geral 11 De Dezembro De 2025
------------------------------------------------------------------------------------------------------------

 ![Fertagus > Fertagus (pt) > Viajar > Comunicados e Campanhas > Greve Geral 11 de dezembro de 2025](https://www.fertagus.pt/portals/0/FTG-Greve-Geral-web-1253x886.jpg) <small>www.fertagus.pt</small>Fertagus &gt; Fertagus (pt) &gt; Viajar &gt; Comunicados e Campanhas &gt; Greve Geral 11 de dezembro de 2025

TCB | Pré-aviso De Greve A 11 De Dezembro - Portal Institucional
----------------------------------------------------------------

 ![TCB | Pré-aviso de greve a 11 de dezembro - Portal Institucional](https://www.cm-barreiro.pt/wp-content/uploads/2025/12/GREVE-11_DEZEMBRO_650px.png) <small>www.cm-barreiro.pt</small>TCB | Pré-aviso de greve a 11 de dezembro - Portal Institucional

De Quem é O Meu Trabalho? - By Diogo Augusto - Fragmentos
---------------------------------------------------------

 ![De quem é o meu trabalho? - by Diogo Augusto - Fragmentos](https://substackcdn.com/image/fetch/$s_!XXAX!,f_auto,q_auto:good,fl_progressive:steep/https://substack-post-media.s3.amazonaws.com/public/images/d17e3e84-ae0f-4705-ad40-6923a8e44676_6000x4000.jpeg) <small>osfragmentos.substack.com</small>De quem é o meu trabalho? - by Diogo Augusto - Fragmentos

SPGL - Greve Geral | 11 De Dezembro De 2025 (Piquetes, Concentrações E Manifestações)
-------------------------------------------------------------------------------------

 ![SPGL - Greve Geral | 11 de dezembro de 2025 (Piquetes, Concentrações e Manifestações)](https://www.spgl.pt/Media/Default/_Profiles/722d2b7d/68bcf4e1/IMG_2694.JPG?v=639010778412646835) <small>www.spgl.pt</small>SPGL - Greve Geral | 11 de dezembro de 2025 (Piquetes, Concentrações e Manifestações)

GREVE GERAL DIA 11 DEZEMBRO DE 2025 | FESAHT
--------------------------------------------

 ![GREVE GERAL DIA 11 DEZEMBRO DE 2025 | FESAHT](https://sindicatos.cgtp.pt/fesaht/wp-content/blogs.dir/52/files/sites/52/2025/12/11-DEZ-faz-greve-e-sai-a-Rua.jpg) <small>sindicatos.cgtp.pt</small>GREVE GERAL DIA 11 DEZEMBRO DE 2025 | FESAHT

Fesete Vai Aderir à Greve Geral De 11 De Dezembro - Portugal - SÁBADO
---------------------------------------------------------------------

 ![Fesete vai aderir à greve geral de 11 de dezembro - Portugal - SÁBADO](https://cdn.sabado.pt/images/2013-05/img_1920x1080uu2013-05-30-19-15-03-73602.jpg) <small>www.sabado.pt</small>Fesete vai aderir à greve geral de 11 de dezembro - Portugal - SÁBADO

Category:General Strike 11 December 2025 (Portugal) - Wikimedia Commons
-----------------------------------------------------------------------

 ![Category:General strike 11 December 2025 (Portugal) - Wikimedia Commons](https://upload.wikimedia.org/wikipedia/commons/thumb/d/d1/Convocatórias_nas_ruas_sobre_a_Greve_Geral_de_7_de_dezembro_2025%2C_em_Portugal_07.jpg/960px-Convocatórias_nas_ruas_sobre_a_Greve_Geral_de_7_de_dezembro_2025%2C_em_Portugal_07.jpg) <small>commons.wikimedia.org</small>Category:General strike 11 December 2025 (Portugal) - Wikimedia Commons

SPN - Fenprof — Adesão Histórica à Greve Geral
----------------------------------------------

 ![SPN - Fenprof — Adesão histórica à greve geral](https://www.spn.pt/Media/Default/Info/68000/500/60/7/grevegeral11dez_cartaz.jpg) <small>www.spn.pt</small>SPN - Fenprof — Adesão histórica à greve geral

Concentrações E Manifestações No Dia 11 De Dezembro - CGTP-IN
-------------------------------------------------------------

 ![Concentrações e Manifestações no dia 11 de Dezembro - CGTP-IN](https://www.cgtp.pt/images/images/2025/12/CONCNETRACOES.jpg) <small>www.cgtp.pt</small>Concentrações e Manifestações no dia 11 de Dezembro - CGTP-IN

Mais De 50 Sindicatos Aderem à Greve Geral Marcada Para 11 De Dezembro
----------------------------------------------------------------------

 ![Mais de 50 sindicatos aderem à greve geral marcada para 11 de dezembro](https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA1QBjfX.img?w=1200&h=800&m=4&q=70) <small>www.msn.com</small>Mais de 50 sindicatos aderem à greve geral marcada para 11 de dezembro

Perguntas E Respostas Sobre A Greve Geral De 11 De Dezembro - SBC - Sindicato Nacional Dos
------------------------------------------------------------------------------------------

 ![Perguntas e respostas sobre a Greve Geral de 11 de dezembro - SBC - Sindicato Nacional dos](https://www.sibace.pt/wp-content/uploads/2025/11/greve-2-1170-x-400.png) <small>www.sibace.pt</small>Perguntas e respostas sobre a Greve Geral de 11 de dezembro - SBC - Sindicato Nacional dos ...

Greve Geral: Quem Pode Aderir, O Que Muda No Salário E O Que Vai Estar A Funcionar - JN
---------------------------------------------------------------------------------------

 ![Greve geral: quem pode aderir, o que muda no salário e o que vai estar a funcionar - JN](https://staticx.noticiasilimitadas.pt/jn/image.webp?brand=jn&type=generate&guid=4a9e034d-f191-4476-908a-d05d2af1a846&w=3840) <small>www.jn.pt</small>Greve geral: quem pode aderir, o que muda no salário e o que vai estar a funcionar - JN

Pré-Aviso De Greve 11 E 12 De Dezembro
--------------------------------------

 ![Pré-Aviso de Greve 11 e 12 de dezembro](https://static.wixstatic.com/media/1029eb_a6db1017a2334a9abf146e02d7454c28~mv2.png/v1/fill/w_770,h_395,al_c,lg_1,q_85/1029eb_a6db1017a2334a9abf146e02d7454c28~mv2.png) <small>www.aecadaval.com</small>Pré-Aviso de Greve 11 e 12 de dezembro

Faq: os direitos dos docentes em dia de greve geral. Greve histórica em portugal: três milhões cruzam os braços em protesto contra medidas de. Mais de 50 sindicatos aderem à greve geral marcada para 11 de dezembro
