---
title: "Greve Geral 2026 Maio - Aviso prévio de greve trabalhadores não docentes 5 junho 2026 – stts"
description: "Pré-avisos de greves de 2 e 3 de março 2023"
date: "2026-04-25"
categories:
- "Uncategorized"
images:
- "https://www.adufpb.org.br/site/wp-content/uploads/2024/05/2024.05.29-assembleia-de-greve.jpeg"
featuredImage: "https://www.stts.pt/wp-content/uploads/2026/05/Imagem1.png"
featured_image: "https://www.cgtp.pt/images/images/2017/05/cartaz_steffas_greve26.jpg"
image: "https://fne.pt/uploads/rte/cartaz_greve_manif_2e3marco2023.jpeg"
---

If you are searching about Adesão expressiva na greve geral e centrais sindicais demarcam-se da marcha do 1º de Maio you've visit to the right web. We have 35 Pictures about Adesão expressiva na greve geral e centrais sindicais demarcam-se da marcha do 1º de Maio like SPN - Greve Geral com forte expressão nos professores (3/jun), 1.º de Maio: CGTP e UGT esperam milhares nas ruas para lutar contra o pacote laboral - com a and also CGTP convoca greve geral para 3 de junho - Sociedade - Correio da Manhã. Here it is:

Adesão Expressiva Na Greve Geral E Centrais Sindicais Demarcam-se Da Marcha Do 1º De Maio
-----------------------------------------------------------------------------------------

 ![Adesão expressiva na greve geral e centrais sindicais demarcam-se da marcha do 1º de Maio](https://angola24horas.com/media/k2/items/cache/5556c0206b0f8d02b62cc0dc88c5a241_L.jpg) <small>angola24horas.com</small>Adesão expressiva na greve geral e centrais sindicais demarcam-se da marcha do 1º de Maio ...

Pré-Aviso De Greve – 17 De Abril De 2026 – AE António Correia De Oliveira
-------------------------------------------------------------------------

 ![Pré-Aviso de Greve – 17 de abril de 2026 – AE António Correia de Oliveira](https://www.acoliveira.pt/wp-content/uploads/2026/04/7e9f6ec4-4873-4685-897b-30c62aab02d6.png) <small>www.acoliveira.pt</small>Pré-Aviso de Greve – 17 de abril de 2026 – AE António Correia de Oliveira

AVISO PRÉVIO DE GREVE GREVE DA SAÚDE 4 E 5 Maio 2026 – STTS
-----------------------------------------------------------

 ![AVISO PRÉVIO DE GREVE GREVE DA SAÚDE 4 e 5 maio 2026 – STTS](https://www.stts.pt/wp-content/uploads/2026/05/Imagem1-210x136.png) <small>www.stts.pt</small>AVISO PRÉVIO DE GREVE GREVE DA SAÚDE 4 e 5 maio 2026 – STTS

1.º De Maio: CGTP E UGT Esperam Milhares Nas Ruas Para Lutar Contra O Pacote Laboral - Com A
--------------------------------------------------------------------------------------------

 ![1.º de Maio: CGTP e UGT esperam milhares nas ruas para lutar contra o pacote laboral - com a](https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA229qJs.img?w=1920&h=1080&m=4&q=75) <small>www.msn.com</small>1.º de Maio: CGTP e UGT esperam milhares nas ruas para lutar contra o pacote laboral - com a ...

Sintracon Pode Decretar Greve A Partir Do Dia 20 - Agência Sindical
-------------------------------------------------------------------

 ![Sintracon pode decretar greve a partir do dia 20 - Agência Sindical](https://agenciasindical.com.br/wp-content/uploads/2026/05/Sintracon-Card-Greve-Geral-2026-696x464.webp) <small>agenciasindical.com.br</small>Sintracon pode decretar greve a partir do dia 20 - Agência Sindical

GREVE GERAL - 3 JUNHO 2026 | Resolução - CGTP-IN
------------------------------------------------

 ![GREVE GERAL - 3 JUNHO 2026 | Resolução - CGTP-IN](https://www.cgtp.pt/images/images/2026/06/resolucao_grevegeral.jpg) <small>www.cgtp.pt</small>GREVE GERAL - 3 JUNHO 2026 | Resolução - CGTP-IN

GREVE GERAL - 3 JUNHO 2026 | Resolução - CGTP-IN
------------------------------------------------

 ![GREVE GERAL - 3 JUNHO 2026 | Resolução - CGTP-IN](https://www.cgtp.pt/images/images/2026/06/tiago-greve-geral.jpg) <small>www.cgtp.pt</small>GREVE GERAL - 3 JUNHO 2026 | Resolução - CGTP-IN

LusaVideo: 1.º Maio: CGTP Apela Para Adesão à Greve Geral De 03 De Junho Contra Pacote Laboral
----------------------------------------------------------------------------------------------

 ![LusaVideo: 1.º Maio: CGTP apela para adesão à greve geral de 03 de junho contra pacote laboral](https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA22bEFp.img?w=720&h=395&m=4&q=90) <small>www.msn.com</small>LusaVideo: 1.º Maio: CGTP apela para adesão à greve geral de 03 de junho contra pacote laboral ...

SPN - Greve Geral Com Forte Expressão Nos Professores (3/jun)
-------------------------------------------------------------

 ![SPN - Greve Geral com forte expressão nos professores (3/jun)](https://www.spn.pt/Media/Default/_Profiles/ee10172b/b4faa2e3/Fenprof — Greve Geral.jpg?v=639147783077642453) <small>www.spn.pt</small>SPN - Greve Geral com forte expressão nos professores (3/jun)

Trabalhadores Do Sector Da Defesa Mobilizam-se Para Greve De 26 De Maio - CGTP-IN
---------------------------------------------------------------------------------

 ![Trabalhadores do sector da defesa mobilizam-se para greve de 26 de Maio - CGTP-IN](https://www.cgtp.pt/images/images/2017/05/cartaz_steffas_greve26.jpg) <small>www.cgtp.pt</small>Trabalhadores do sector da defesa mobilizam-se para greve de 26 de Maio - CGTP-IN

Greve Geral Da Educação: FAEC, Presente! – FAEC – Faculdade De Educação E Ciências Integradas De
------------------------------------------------------------------------------------------------

 ![Greve geral da educação: FAEC, presente! – FAEC – Faculdade de Educação e Ciências Integradas de](https://www.uece.br/faecwp/wp-content/uploads/sites/39/2019/05/maio113.png) <small>www.uece.br</small>Greve geral da educação: FAEC, presente! – FAEC – Faculdade de Educação e Ciências Integradas de ...

AVISO PRÉVIO DE GREVE GREVE DA SAÚDE 4 E 5 Maio 2026 – STTS
-----------------------------------------------------------

 ![AVISO PRÉVIO DE GREVE GREVE DA SAÚDE 4 e 5 maio 2026 – STTS](https://www.stts.pt/wp-content/uploads/2026/04/CAPA-1.png) <small>www.stts.pt</small>AVISO PRÉVIO DE GREVE GREVE DA SAÚDE 4 e 5 maio 2026 – STTS

SPGL - Professores, Educadores E Investigadores Na Greve Geral | 3 De Junho 2026
--------------------------------------------------------------------------------

 ![SPGL - Professores, educadores e investigadores na Greve Geral | 3 de junho 2026](https://www.spgl.pt/Media/Default/_Profiles/7494e02c/a9d870bd/Flyer Greve Geral_page-0001.jpg?v=639147970016913172) <small>www.spgl.pt</small>SPGL - Professores, educadores e investigadores na Greve Geral | 3 de junho 2026

SPGL - Greve Geral | Comunicado Aos Pais E Encarregados De Educação
-------------------------------------------------------------------

 ![SPGL - Greve Geral | Comunicado Aos Pais e Encarregados de Educação](https://www.spgl.pt/Media/Default/_Profiles/7494e02c/a0ff4022/comunicado enc educacao GREVE_page-0001.jpg?v=638993179488068030) <small>www.spgl.pt</small>SPGL - Greve Geral | Comunicado Aos Pais e Encarregados de Educação

GREVE GERAL – 11 DEZEMBRO 2025 – SINDETELCO
-------------------------------------------

 ![GREVE GERAL – 11 DEZEMBRO 2025 – SINDETELCO](https://www.sindetelco.pt/wp-content/uploads/2025/11/Sem-titulo-1-727x1024.jpg) <small>www.sindetelco.pt</small>GREVE GERAL – 11 DEZEMBRO 2025 – SINDETELCO

Greve Geral Histórica Em Portugal Paralisa Transportes, Fecha Escolas E Pressiona Hospitais
-------------------------------------------------------------------------------------------

 ![Greve geral histórica em Portugal paralisa transportes, fecha escolas e pressiona hospitais](https://p2.trrsf.com/image/fget/cf/1200/630/middle/images.terra.com/2025/12/11/greve-ubj4bs8ccokh.png) <small>www.terra.com.br</small>Greve geral histórica em Portugal paralisa transportes, fecha escolas e pressiona hospitais

Pré-Aviso De Greve Dos TCB A 1 Maio - Portal Institucional
----------------------------------------------------------

 ![Pré-Aviso de Greve dos TCB a 1 maio - Portal Institucional](https://www.cm-barreiro.pt/wp-content/uploads/2026/04/POST-GERAL-GREVE_850px.png?x97784) <small>www.cm-barreiro.pt</small>Pré-Aviso de Greve dos TCB a 1 maio - Portal Institucional

Dados Recolhidos Até às 19h20 Demonstram Que A Greve Geral Parou O País - CGTP-IN
---------------------------------------------------------------------------------

 ![Dados recolhidos até às 19h20 demonstram que a Greve Geral parou o país - CGTP-IN](https://cgtp.pt/images/images/2026/06/Captura de ecra 2026-06-03 120926.png#joomlaImage:/local-images/images/2026/06/Captura de ecra 2026-06-03 120926.png?width=1162&height=610) <small>www.cgtp.pt</small>Dados recolhidos até às 19h20 demonstram que a Greve Geral parou o país - CGTP-IN

Pré-aviso De Greve - Agrupamento De Escolas De Águeda
-----------------------------------------------------

 ![Pré-aviso de Greve - Agrupamento de Escolas de Águeda](https://aeagueda.pt/wp-content/uploads/2025/05/Aviso_GREVE_de_-16-de-Maio_-2025-1.png) <small>aeagueda.pt</small>Pré-aviso de Greve - Agrupamento de Escolas de Águeda

SINDEP - Greve Geral 11 De Dezembro
-----------------------------------

 ![SINDEP - Greve Geral 11 de dezembro](https://sindep.pt/images/cartaz_GREVE_GERAL_UGT.jpg) <small>sindep.pt</small>SINDEP - Greve Geral 11 de dezembro

AVISO PRÉVIO DE GREVE TRABALHADORES NÃO DOCENTES 5 JUNHO 2026 – STTS
--------------------------------------------------------------------

 ![AVISO PRÉVIO DE GREVE TRABALHADORES NÃO DOCENTES 5 JUNHO 2026 – STTS](https://www.stts.pt/wp-content/uploads/2026/05/Imagem1.png) <small>www.stts.pt</small>AVISO PRÉVIO DE GREVE TRABALHADORES NÃO DOCENTES 5 JUNHO 2026 – STTS

Assembleia Geral De Greve | 14 De Maio De 2026
----------------------------------------------

 ![Assembleia Geral de Greve | 14 de maio de 2026](https://static.wixstatic.com/media/427e8e_7fb874f2f9154241b3deb3ed2358155d~mv2.png/v1/fill/w_980,h_490,al_c,q_90,usm_0.66_1.00_0.01,enc_avif,quality_auto/427e8e_7fb874f2f9154241b3deb3ed2358155d~mv2.png) <small>www.sintetufu.org</small>Assembleia Geral de Greve | 14 de maio de 2026

Greve Nacional Da Educação: Conheça Os Locais De Concentração Das Mobilizações - CNTE-CUT
-----------------------------------------------------------------------------------------

 ![Greve Nacional da Educação: conheça os locais de concentração das mobilizações - CNTE-CUT](https://cnte.org.br/img/cache/ogimage/system/uploads/news/448c74b2610cb39f7bcd442287922a0a/cover/greve-geral-15-de-maio-post-patrocinado-final.jpg) <small>cnte.org.br</small>Greve Nacional da Educação: conheça os locais de concentração das mobilizações - CNTE-CUT

Aviso | Greves Em Junho De 2026 – AE António Correia De Oliveira
----------------------------------------------------------------

 ![Aviso | Greves em junho de 2026 – AE António Correia de Oliveira](https://www.acoliveira.pt/wp-content/uploads/2026/05/ChatGPT-Image-31_05_2026-22_43_43.png) <small>www.acoliveira.pt</small>Aviso | Greves em junho de 2026 – AE António Correia de Oliveira

AVISO PRÉVIO DE GREVE GERAL 3 JUNHO 2026 – STTS
-----------------------------------------------

 ![AVISO PRÉVIO DE GREVE GERAL 3 JUNHO 2026 – STTS](https://www.stts.pt/wp-content/uploads/2026/05/123654-1024x871.jpg) <small>www.stts.pt</small>AVISO PRÉVIO DE GREVE GERAL 3 JUNHO 2026 – STTS

MAIO É FESTA! MAIO É LUTA! GREVE GERAL - 3 DE JUNHO — União Dos Sindicatos De Lisboa - USL/CGTP-IN
--------------------------------------------------------------------------------------------------

 ![MAIO É FESTA! MAIO É LUTA! GREVE GERAL - 3 DE JUNHO — União dos Sindicatos de Lisboa - USL/CGTP-IN](https://uniaolisboa-cgtp.pt/images/stories/uniao_imgs/2026/202605/IMG_4310.jpeg) <small>uniaolisboa-cgtp.pt</small>MAIO É FESTA! MAIO É LUTA! GREVE GERAL - 3 DE JUNHO — União dos Sindicatos de Lisboa - USL/CGTP-IN

CGTP Convoca Greve Geral Para 3 De Junho - Sociedade - Correio Da Manhã
-----------------------------------------------------------------------

 ![CGTP convoca greve geral para 3 de junho - Sociedade - Correio da Manhã](https://cdn.cmjornal.pt/images/2025-12/img_1500x1000uu2025-12-11-14-37-03-2253844.jpg) <small>www.cmjornal.pt</small>CGTP convoca greve geral para 3 de junho - Sociedade - Correio da Manhã

AVISO PRÉVIO DE GREVE TRABALHADORES ADMINISTRAÇÃO PÚBLICA 16 DE MAIO 2025 – STTS
--------------------------------------------------------------------------------

 ![AVISO PRÉVIO DE GREVE TRABALHADORES ADMINISTRAÇÃO PÚBLICA 16 DE MAIO 2025 – STTS](https://www.stts.pt/wp-content/uploads/2025/05/CAPA-972x1024.jpg) <small>www.stts.pt</small>AVISO PRÉVIO DE GREVE TRABALHADORES ADMINISTRAÇÃO PÚBLICA 16 DE MAIO 2025 – STTS

Greve Geral | Ações E Dados
---------------------------

 ![Greve Geral | Ações e dados](https://fne.pt/uploads/noticias/big_1765451399_8584_Design_sem_nome.png) <small>fne.pt</small>Greve Geral | Ações e dados

Assembleia Geral Docente Para Discutir Deflagração De Greve Na UFPB Será Nesta Quarta-feira (29
-----------------------------------------------------------------------------------------------

 ![Assembleia geral docente para discutir deflagração de greve na UFPB será nesta quarta-feira (29](https://www.adufpb.org.br/site/wp-content/uploads/2024/05/2024.05.29-assembleia-de-greve.jpeg) <small>www.adufpb.org.br</small>Assembleia geral docente para discutir deflagração de greve na UFPB será nesta quarta-feira (29 ...

Aviso Prévio De Greve Administração Pública – Setor Público Empresarial – IPSS 23 DE MARÇO DE
---------------------------------------------------------------------------------------------

 ![Aviso prévio de greve Administração Pública – Setor Público Empresarial – IPSS 23 DE MARÇO DE](https://www.stts.pt/wp-content/uploads/2026/03/CAPA.png) <small>www.stts.pt</small>Aviso prévio de greve Administração Pública – Setor Público Empresarial – IPSS 23 DE MARÇO DE ...

Greve Geral - 3 De Junho De 2026 | Concentrações - CGTP-IN
----------------------------------------------------------

 ![Greve Geral - 3 de Junho de 2026 | Concentrações - CGTP-IN](https://www.cgtp.pt/images/images/2026/05/CONCENTRACOES-GG.jpg) <small>www.cgtp.pt</small>Greve Geral - 3 de Junho de 2026 | Concentrações - CGTP-IN

Pré-avisos De Greves De 2 E 3 De Março 2023
-------------------------------------------

 ![Pré-avisos de Greves de 2 e 3 de março 2023](https://fne.pt/uploads/rte/cartaz_greve_manif_2e3marco2023.jpeg) <small>fne.pt</small>Pré-avisos de Greves de 2 e 3 de março 2023

Greve Geral Em Lisboa A 3 De Junho: O Que Pára Na Cidade
--------------------------------------------------------

 ![Greve geral em Lisboa a 3 de Junho: o que pára na cidade](https://media.timeout.com/images/106411166/1536/864/image.jpg) <small>www.timeout.pt</small>Greve geral em Lisboa a 3 de Junho: o que pára na cidade

Greve Geral – Ibase
-------------------

 ![greve geral – Ibase](https://ibase.br/wp-content/uploads/2017/04/greve-geral.jpg) <small>ibase.br</small>greve geral – Ibase

Assembleia geral de greve. Sintracon pode decretar greve a partir do dia 20. Greve geral
