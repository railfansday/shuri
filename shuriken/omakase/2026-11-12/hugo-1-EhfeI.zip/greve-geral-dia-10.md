---
title: "Greve Geral Dia 10 - Greve geral dos trabalhadores acontece no próximo dia 10"
description: "Balanço da greve geral de 10/dez/02"
date: "2026-10-16"
categories:
- "Uncategorized"
images:
- "https://image.jimcdn.com/app/cms/image/transf/dimension=4000x3000:format=jpg/path/s3820655f8d987127/image/i4ba186dc42d4f07e/version/1778075119/3-junho-greve-geral-contra-o-pacote-laboral.jpg"
featuredImage: "https://trabalhadores-unidos.pt/wp-content/uploads/2025/12/capa-todos-gg.png"
featured_image: "https://www.stml.pt/wp-content/uploads/2025/12/GREVE-GERAL-2-752x1024.jpg"
image: "https://www.jpn.up.pt/wp-content/uploads/2025/12/greve_geral8.jpg"
---

If you are looking for Greve Geral: Escolas Fechadas, Transportes Parados e Impacto Nacional you've came to the right web. We have 35 Pics about Greve Geral: Escolas Fechadas, Transportes Parados e Impacto Nacional like Greve Geral dos trabalhadores acontece no próximo dia 10 - Seeb, Assembleia Geral Docente no dia 10 decidirá sobre adesão à greve geral - Andes UFRGS and also 15 minutos: impacto da greve geral já se começou a sentir no setor dos transportes - SIC Notícias. Here you go:

Greve Geral: Escolas Fechadas, Transportes Parados E Impacto Nacional
---------------------------------------------------------------------

 ![Greve Geral: Escolas Fechadas, Transportes Parados e Impacto Nacional](https://media.assettype.com/dn%2F2025-12-11%2F9hy4apil%2Fgreve-geral.jpg?w=768&auto=format%2Ccompress) <small>www.dn.pt</small>Greve Geral: Escolas Fechadas, Transportes Parados e Impacto Nacional

SINDEP - Greve Geral 11 De Dezembro
-----------------------------------

 ![SINDEP - Greve Geral 11 de dezembro](https://sindep.pt/images/cartaz_GREVE_GERAL_UGT.jpg) <small>sindep.pt</small>SINDEP - Greve Geral 11 de dezembro

3 JUNHO | GREVE GERAL CONTRA O PACOTE LABORAL - Sindicato Dos Trabalhadores Do Comércio
---------------------------------------------------------------------------------------

 ![3 JUNHO | GREVE GERAL CONTRA O PACOTE LABORAL - Sindicato dos Trabalhadores do Comércio](https://image.jimcdn.com/app/cms/image/transf/dimension=4000x3000:format=jpg/path/s3820655f8d987127/image/i4ba186dc42d4f07e/version/1778075119/3-junho-greve-geral-contra-o-pacote-laboral.jpg) <small>www.cesp.pt</small>3 JUNHO | GREVE GERAL CONTRA O PACOTE LABORAL - Sindicato dos Trabalhadores do Comércio ...

Greve Geral Juntou Centenas Nos Aliados. Governo Fala Em Adesão "inexpressiva" - JPN
------------------------------------------------------------------------------------

 ![Greve Geral juntou centenas nos Aliados. Governo fala em adesão "inexpressiva" - JPN](https://www.jpn.up.pt/wp-content/uploads/2025/12/greve_geral9.jpg) <small>www.jpn.up.pt</small>Greve Geral juntou centenas nos Aliados. Governo fala em adesão "inexpressiva" - JPN

Centrais Chamam Greve Geral Para 10 De Novembro | SINDISAN: Na Luta Pelos Trabalhadores
---------------------------------------------------------------------------------------

 ![Centrais chamam Greve Geral para 10 de novembro | SINDISAN: Na Luta pelos Trabalhadores](https://sindisan.org.br/oanokush/2017/12/greve-geral-muro-550x445.jpg) <small>sindisan.org.br</small>Centrais chamam Greve Geral para 10 de novembro | SINDISAN: Na Luta pelos Trabalhadores

SPN - Fenprof — Adesão Histórica à Greve Geral
----------------------------------------------

 ![SPN - Fenprof — Adesão histórica à greve geral](https://www.spn.pt/Media/Default/Info/68000/500/60/7/grevegeral11dez_cartaz.jpg) <small>www.spn.pt</small>SPN - Fenprof — Adesão histórica à greve geral

No 10º Dia De Greve, Médicos Vão Ao Legislativo - Sindmédico | Sindicato Dos Médicos Do Distrito
------------------------------------------------------------------------------------------------

 ![No 10º dia de greve, médicos vão ao Legislativo - Sindmédico | Sindicato dos Médicos do Distrito](https://www.sindmedico.com.br/wp-content/uploads/2024/09/2024-09-13-10-dia-de-greve-interno-1.jpeg) <small>www.sindmedico.com.br</small>No 10º dia de greve, médicos vão ao Legislativo - Sindmédico | Sindicato dos Médicos do Distrito ...

Todos à Greve Geral – 11 Dez. • Trabalhadores Unidos
----------------------------------------------------

 ![Todos à Greve Geral – 11 Dez. • Trabalhadores Unidos](https://trabalhadores-unidos.pt/wp-content/uploads/2025/12/capa-todos-gg.png) <small>trabalhadores-unidos.pt</small>Todos à Greve Geral – 11 Dez. • Trabalhadores Unidos

Eurodreams De 17 De Novembro De 2025
------------------------------------

 ![Eurodreams de 17 de novembro de 2025](https://jornaldemafra.pt/wp-content/uploads/2025/12/greve-geral.webp) <small>jornaldemafra.pt</small>Eurodreams de 17 de novembro de 2025

Plenária Dia 10 | Reta Final Da Greve Geral - Sindsep-DF
--------------------------------------------------------

 ![Plenária dia 10 | Reta final da Greve Geral - Sindsep-DF](https://sindsep-df.com.br/wp-content/uploads/2019/06/greve.jpeg) <small>sindsep-df.com.br</small>Plenária dia 10 | Reta final da Greve Geral - Sindsep-DF

FAQ: Os Direitos Dos Docentes Em Dia De Greve Geral - 11/12/2025
----------------------------------------------------------------

 ![FAQ: Os direitos dos docentes em dia de Greve Geral - 11/12/2025](https://static.wixstatic.com/media/d0f32c_9ff1199ee2c34418af0094a43c516733~mv2.png/v1/fill/w_940,h_788,al_c,q_90,enc_avif,quality_auto/d0f32c_9ff1199ee2c34418af0094a43c516733~mv2.png) <small>www.sprc.pt</small>FAQ: Os direitos dos docentes em dia de Greve Geral - 11/12/2025

SPN - Greve Geral (10/dez/2002)
-------------------------------

 ![SPN - Greve Geral (10/dez/2002)](https://www.spn.pt/Media/Default/_Profiles/5f2efba9/49dd7175/greve10dez2002.jpg?v=638628900774651037) <small>www.spn.pt</small>SPN - Greve Geral (10/dez/2002)

Greve Geral Dos Trabalhadores Acontece No Próximo Dia 10 - Seeb
---------------------------------------------------------------

 ![Greve Geral dos trabalhadores acontece no próximo dia 10 - Seeb](https://seeb.org.br/wp-content/uploads/2017/11/Greve-Geral-MINI.jpg) <small>seeb.org.br</small>Greve Geral dos trabalhadores acontece no próximo dia 10 - Seeb

Greve Geral Dos Trabalhadores Acontece No Próximo Dia 10 - Seeb
---------------------------------------------------------------

 ![Greve Geral dos trabalhadores acontece no próximo dia 10 - Seeb](https://seeb.org.br/wp-content/uploads/2017/11/Greve-Geral.jpg) <small>seeb.org.br</small>Greve Geral dos trabalhadores acontece no próximo dia 10 - Seeb

Pré-Aviso De Greve – 24-10-2025 (atualização) - Agrupamento De Escolas Da Lousã
-------------------------------------------------------------------------------

 ![Pré-Aviso de Greve – 24-10-2025 (atualização) - Agrupamento de Escolas da Lousã](https://escolas.aglousa.com/wp-content/uploads/2019/06/greve.png) <small>escolas.aglousa.com</small>Pré-Aviso de Greve – 24-10-2025 (atualização) - Agrupamento de Escolas da Lousã

Mapa QZP Carenciados De 2025/26 – Despacho N.º 11200-A/2025 – Apoio à Deslocação – Sindicato S.TO.P.
----------------------------------------------------------------------------------------------------

 ![Mapa QZP carenciados de 2025/26 – Despacho n.º 11200-A/2025 – Apoio à deslocação – Sindicato S.TO.P.](https://stop-sindicato.pt/wp-content/uploads/2025/11/S.TO_.P.-Cartaz-Greve-Geral-Educacao-11Dez2025_x1000-768x1086.png) <small>stop-sindicato.pt</small>Mapa QZP carenciados de 2025/26 – Despacho n.º 11200-A/2025 – Apoio à deslocação – Sindicato S.TO.P.

10 Motivos Pela GREVE GERAL - STIC-BH MARRETA
---------------------------------------------

 ![10 motivos pela GREVE GERAL - STIC-BH MARRETA](https://sticbh.org.br/wp-content/uploads/2019/04/GREVE-GERAL-A5.jpg) <small>sticbh.org.br</small>10 motivos pela GREVE GERAL - STIC-BH MARRETA

15 Minutos: Impacto Da Greve Geral Já Se Começou A Sentir No Setor Dos Transportes - SIC Notícias
-------------------------------------------------------------------------------------------------

 ![15 minutos: impacto da greve geral já se começou a sentir no setor dos transportes - SIC Notícias](https://images.impresa.pt/sicnot/2025-12-12-greve-geral-045a9380/1.91x1?wm=true&outputFormat=jpeg) <small>sicnoticias.pt</small>15 minutos: impacto da greve geral já se começou a sentir no setor dos transportes - SIC Notícias

Greve Geral Vista Das Ruas: Manhã Cinzenta, Autocarros Vazios E Um País Que Abrandou O Passo
--------------------------------------------------------------------------------------------

 ![Greve geral vista das ruas: manhã cinzenta, autocarros vazios e um país que abrandou o passo](https://images.impresa.pt/expresso/2025-12-11-fox_greve_geral_0018.jpg-6e16cd12-1) <small>expresso.pt</small>Greve geral vista das ruas: manhã cinzenta, autocarros vazios e um país que abrandou o passo ...

Assembleia Geral Docente No Dia 10 Decidirá Sobre Adesão à Greve Geral - Andes UFRGS
------------------------------------------------------------------------------------

 ![Assembleia Geral Docente no dia 10 decidirá sobre adesão à greve geral - Andes UFRGS](https://andesufrgs.org.br/wp-content/uploads/2019/06/ag1006_certo-768x751.webp) <small>andesufrgs.org.br</small>Assembleia Geral Docente no dia 10 decidirá sobre adesão à greve geral - Andes UFRGS

DIA 14 DE JUNHO: ORIENTAÇÕES PARA ATUAÇÃO NA GREVE GERAL – SindJustiça Ceará
----------------------------------------------------------------------------

 ![DIA 14 DE JUNHO: ORIENTAÇÕES PARA ATUAÇÃO NA GREVE GERAL – SindJustiça Ceará](https://sindjusticaceara.org.br/wp-content/uploads/2019/06/CARTAZ-GREVE-GERAL.jpg) <small>sindjusticaceara.org.br</small>DIA 14 DE JUNHO: ORIENTAÇÕES PARA ATUAÇÃO NA GREVE GERAL – SindJustiça Ceará

Greve Geral No Brasil: O Impacto E Relevância De 2023 – Bacana Notícias
-----------------------------------------------------------------------

 ![Greve Geral no Brasil: O Impacto e Relevância de 2023 – Bacana Notícias](https://bacana.news/wp-content/uploads/2025/10/greve-geral-7-905x613.jpeg) <small>bacana.news</small>Greve Geral no Brasil: O Impacto e Relevância de 2023 – Bacana Notícias

Motivos Da Adesão à Greve Geral De 11 De Dezembro De 2025
---------------------------------------------------------

 ![Motivos da adesão à Greve Geral de 11 de dezembro de 2025](https://spzn.pt/uploads/noticias/big_1763717239_6728_SPZN_2025_site_novo_(17).png) <small>spzn.pt</small>Motivos da adesão à Greve Geral de 11 de dezembro de 2025

Balanço Da Greve Geral De 10/Dez/02
-----------------------------------

 ![Balanço da Greve Geral de 10/Dez/02](http://www.resistir.info/portugal/imagens/cartaz_gg.jpg) <small>www.resistir.info</small>Balanço da Greve Geral de 10/Dez/02

Greve Geral Juntou Centenas Nos Aliados. Governo Fala Em Adesão "inexpressiva" - JPN
------------------------------------------------------------------------------------

 ![Greve Geral juntou centenas nos Aliados. Governo fala em adesão "inexpressiva" - JPN](https://www.jpn.up.pt/wp-content/uploads/2025/12/greve_geral8.jpg) <small>www.jpn.up.pt</small>Greve Geral juntou centenas nos Aliados. Governo fala em adesão "inexpressiva" - JPN

A Plataforma Já Marchavas Apoia A Greve Geral De 11 De Dezembro – Já Marchavas
------------------------------------------------------------------------------

 ![A Plataforma Já Marchavas apoia a Greve Geral de 11 de Dezembro – Já Marchavas](https://jamarchavas.pt/wp-content/uploads/2025/12/greve-geral-2025-1.jpg) <small>jamarchavas.pt</small>A Plataforma Já Marchavas apoia a Greve Geral de 11 de Dezembro – Já Marchavas

Metro Do Porto "fortemente Condicionado" No Dia Da Greve Geral - JPN
--------------------------------------------------------------------

 ![Metro do Porto "fortemente condicionado" no dia da greve geral - JPN](https://www.jpn.up.pt/wp-content/uploads/2025/12/greve_geral1-1152x759.jpg) <small>www.jpn.up.pt</small>Metro do Porto "fortemente condicionado" no dia da greve geral - JPN

Greve Geral Deverá Ter Impacto Inferior A 0,1% Do PIB – ECO
-----------------------------------------------------------

 ![Greve geral deverá ter impacto inferior a 0,1% do PIB – ECO](https://eco.imgix.net/uploads/2025/12/cropped-46141990-scaled.jpg) <small>eco.sapo.pt</small>Greve geral deverá ter impacto inferior a 0,1% do PIB – ECO

Greve Geral: Saiba Quais São Os Serviços Mínimos Já Decretados - SIC Notícias
-----------------------------------------------------------------------------

 ![Greve geral: saiba quais são os serviços mínimos já decretados - SIC Notícias](https://images.impresa.pt/sicnot/2025-11-17-cgtp-pre-aviso-greve-82e19fc3-1/16x9/mw-1200) <small>sicnoticias.pt</small>Greve geral: saiba quais são os serviços mínimos já decretados - SIC Notícias

Greve Geral. Não Vai Poder Circular De Carro Nestas Ruas De Lisboa Devido à Manifestação - CNN
----------------------------------------------------------------------------------------------

 ![Greve geral. Não vai poder circular de carro nestas ruas de Lisboa devido à manifestação - CNN](https://img.iol.pt/image/id/13741284/1024.jpg) <small>cnnportugal.iol.pt</small>Greve geral. Não vai poder circular de carro nestas ruas de Lisboa devido à manifestação - CNN ...

SindicarioNET - Sexta-feira é Dia De Greve Geral No Brasil
----------------------------------------------------------

 ![SindicarioNET - Sexta-feira é dia de Greve Geral no Brasil](https://www.seebcgms.org.br/media/media_arquivos/greve-geral-interna.png) <small>www.seebcgms.org.br</small>SindicarioNET - Sexta-feira é dia de Greve Geral no Brasil

Greve Geral é Nesta Sexta-feira. Vamos Parar O Brasil | Sindicato Dos Metalúrgicos De São José
----------------------------------------------------------------------------------------------

 ![Greve Geral é nesta sexta-feira. Vamos parar o Brasil | Sindicato dos Metalúrgicos de São José](https://www.sindmetalsjc.org.br/arquivo/thumb/noticias/265a42832d9ee9737b29_990x500_0_0_1_1.jpg) <small>www.sindmetalsjc.org.br</small>Greve Geral é nesta sexta-feira. Vamos parar o Brasil | Sindicato dos Metalúrgicos de São José ...

Greve Geral. Metro De Lisboa Prevê Paralisação Do Serviço E Encerramento Das Estações – ECO
-------------------------------------------------------------------------------------------

 ![Greve Geral. Metro de Lisboa prevê paralisação do serviço e encerramento das estações – ECO](https://eco.imgix.net/uploads/2025/12/thumb-1.jpg) <small>eco.sapo.pt</small>Greve Geral. Metro de Lisboa prevê paralisação do serviço e encerramento das estações – ECO

11 DEZ | GREVE GERAL - Expressão Pública Com Concentração às 14h30 No Rossio - STML
-----------------------------------------------------------------------------------

 ![11 DEZ | GREVE GERAL - Expressão Pública com concentração às 14h30 no Rossio - STML](https://www.stml.pt/wp-content/uploads/2025/12/GREVE-GERAL-2-752x1024.jpg) <small>www.stml.pt</small>11 DEZ | GREVE GERAL - Expressão Pública com concentração às 14h30 no Rossio - STML

GREVE GERAL JÁ – SITRAEMFA
--------------------------

 ![GREVE GERAL JÁ – SITRAEMFA](https://sitraemfa.org.br/wp-content/uploads/2016/11/greve-geral-11.jpg) <small>sitraemfa.org.br</small>GREVE GERAL JÁ – SITRAEMFA

greve geral: saiba quais são os serviços mínimos já decretados. Greve geral no brasil: o impacto e relevância de 2023 – bacana notícias. greve geral: escolas fechadas, transportes parados e impacto nacional
