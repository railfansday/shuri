---
title: "Greve Geral De 3 De Junho - Greve geral em lisboa a 3 de junho: o que pára na cidade"
description: "A greve geral de 3 de junho é para todos os trabalhadores"
date: "2026-05-25"
categories:
- "Uncategorized"
images:
- "https://staticx.noticiasilimitadas.pt/jn/image.webp?brand=jn&amp;type=generate&amp;guid=7ff89168-6db6-48c6-a848-7f6391614ee9&amp;w=3840"
featuredImage: "https://www.cgtp.pt/images/accao-e-luta/2025/sntct1.jpg"
featured_image: "https://www.spn.pt/Media/Default/Info/71000/800/10/5/Fenprof — Greve Geral.jpg"
image: "https://staticx.noticiasilimitadas.pt/jn/image.webp?brand=jn&amp;type=generate&amp;guid=7ff89168-6db6-48c6-a848-7f6391614ee9&amp;w=3840"
---

If you are looking for Nacional - FENPROF you've visit to the right web. We have 35 Images about Nacional - FENPROF like Greve geral de 3 de junho ameaça paralisar o país: que setores serão impactados?, Greve geral ameaça parar parte do país: 10 perguntas e respostas sobre a paralisação de 3 de junho and also MAIO É FESTA! MAIO É LUTA! GREVE GERAL - 3 DE JUNHO — União dos Sindicatos de Lisboa - USL/CGTP-IN. Here it is:

Nacional - FENPROF
------------------

 ![Nacional - FENPROF](https://www.fenprof.pt/media/download/510F5035E5C8AED530130C74C48BB00C/2026_05_16-manif-ecd-spra1.jpg?width=1200&rxy=0.5,0.5&token=2kOJePBdk812vkJog3s9Ds0ky8nF%2FgY1wJt2krWJDVA%3D) <small>www.fenprof.pt</small>Nacional - FENPROF

Greve Geral – Dia 3 De Junho - SPRA
-----------------------------------

 ![Greve Geral – dia 3 de junho - SPRA](https://www.spra.pt/wp-content/uploads/2026/05/Greve_Acores-768x1024.jpg) <small>www.spra.pt</small>Greve Geral – dia 3 de junho - SPRA

CGTP Confirma: Nova Greve Geral Convocada Para 3 De Junho
---------------------------------------------------------

 ![CGTP confirma: nova greve geral convocada para 3 de junho](https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA229V01.img?w=768&h=512&m=6&x=156&y=111&s=591&d=188) <small>www.msn.com</small>CGTP confirma: nova greve geral convocada para 3 de junho

FNSTFPS Já Emitiu Aviso Prévio Para A Greve Geral De 3 De Junho! - CGTP-IN
--------------------------------------------------------------------------

 ![FNSTFPS já emitiu Aviso Prévio para a Greve Geral de 3 de Junho! - CGTP-IN](https://www.cgtp.pt/images/accao-e-luta/2026/05/greve-geral-funcao-publica.jpg) <small>www.cgtp.pt</small>FNSTFPS já emitiu Aviso Prévio para a Greve Geral de 3 de Junho! - CGTP-IN

Greve Geral Em Lisboa A 3 De Junho: O Que Pára Na Cidade
--------------------------------------------------------

 ![Greve geral em Lisboa a 3 de Junho: o que pára na cidade](https://media.timeout.com/images/106411166/image.jpg) <small>www.timeout.pt</small>Greve geral em Lisboa a 3 de Junho: o que pára na cidade

CGTP Anuncia No Dia Do Trabalhador Nova Greve Geral No Dia 3 De Junho
---------------------------------------------------------------------

 ![CGTP anuncia no Dia do Trabalhador nova greve geral no dia 3 de junho](https://staticx.noticiasilimitadas.pt/jn/image.webp?brand=jn&type=generate&guid=7ff89168-6db6-48c6-a848-7f6391614ee9&w=3840) <small>www.jn.pt</small>CGTP anuncia no Dia do Trabalhador nova greve geral no dia 3 de junho

CGTP Convoca Greve Geral Para Dia 3 De Junho E UGT Poderá Aderir
----------------------------------------------------------------

 ![CGTP convoca greve geral para dia 3 de junho e UGT poderá aderir](https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA22c4u7.img?w=1024&h=576&m=4&q=81) <small>www.msn.com</small>CGTP convoca greve geral para dia 3 de junho e UGT poderá aderir

3 De Junho: Dia Nacional De Luta Pela Retomada De Negociações Com Educação Federal Em Greve
-------------------------------------------------------------------------------------------

 ![3 de junho: Dia Nacional de Luta pela retomada de negociações com Educação Federal em greve](https://www.andes.org.br/img/midias/1a208cc2305a3c74c97903345cc44643_1717025565.png) <small>www.andes.org.br</small>3 de junho: Dia Nacional de Luta pela retomada de negociações com Educação Federal em greve

Greve Geral De 3 De Junho: O Que Está Em Causa, Quem Pode Aderir E Que Impacto Se Prevê
---------------------------------------------------------------------------------------

 ![Greve Geral de 3 de junho: o que está em causa, quem pode aderir e que impacto se prevê](https://sabiasque.pt/images/stories/2026/trabalho/20260602-greve-geral-3-junho-1024x683.jpg) <small>sabiasque.pt</small>Greve Geral de 3 de junho: o que está em causa, quem pode aderir e que impacto se prevê

SPN - Greve Geral Com Forte Expressão Nos Professores (3/jun)
-------------------------------------------------------------

 ![SPN - Greve Geral com forte expressão nos professores (3/jun)](https://www.spn.pt/Media/Default/Info/71000/800/10/5/Fenprof — Greve Geral.jpg) <small>www.spn.pt</small>SPN - Greve Geral com forte expressão nos professores (3/jun)

Décimo-terceiro Salário; Como Pagamento Surgiu De Greve Geral Após Vitória Do Brasil Na Copa De
-----------------------------------------------------------------------------------------------

 ![Décimo-terceiro salário; como pagamento surgiu de greve geral após vitória do Brasil na Copa de](https://ichef.bbci.co.uk/ace/ws/640/cpsprodpb/f292/live/37f24e30-8d88-11ef-b3c2-754b6219680e.png.webp) <small>www.bbc.com</small>Décimo-terceiro salário; como pagamento surgiu de greve geral após vitória do Brasil na Copa de ...

Greve Geral: Sindicato Dos Enfermeiros Adere à Paralisação De 3 De Junho - Portugal - SÁBADO
--------------------------------------------------------------------------------------------

 ![Greve Geral: Sindicato dos Enfermeiros adere à paralisação de 3 de junho - Portugal - SÁBADO](https://cdn.sabado.pt/images/2025-12/img_980x653uu2025-12-11-07-13-54-752774.jpg) <small>www.sabado.pt</small>Greve Geral: Sindicato dos Enfermeiros adere à paralisação de 3 de junho - Portugal - SÁBADO

SNTCT Entrega Pré-avisos De Greve Geral De 3 Junho - CGTP-IN
------------------------------------------------------------

 ![SNTCT entrega pré-avisos de Greve Geral de 3 Junho - CGTP-IN](https://www.cgtp.pt/images/accao-e-luta/2025/sntct1.jpg) <small>www.cgtp.pt</small>SNTCT entrega pré-avisos de Greve Geral de 3 Junho - CGTP-IN

Greve Geral – Dia 3 De Junho - SPRA
-----------------------------------

 ![Greve Geral – dia 3 de junho - SPRA](https://www.spra.pt/wp-content/uploads/2026/05/banner-gg2026-1.jpg) <small>www.spra.pt</small>Greve Geral – dia 3 de junho - SPRA

GREVE GERAL - 3 JUNHO 2026 | Resolução - CGTP-IN
------------------------------------------------

 ![GREVE GERAL - 3 JUNHO 2026 | Resolução - CGTP-IN](https://www.cgtp.pt/images/images/2026/06/resolucao_grevegeral.jpg) <small>www.cgtp.pt</small>GREVE GERAL - 3 JUNHO 2026 | Resolução - CGTP-IN

Greve Geral Ameaça Parar Parte Do País: 10 Perguntas E Respostas Sobre A Paralisação De 3 De Junho
--------------------------------------------------------------------------------------------------

 ![Greve geral ameaça parar parte do país: 10 perguntas e respostas sobre a paralisação de 3 de junho](https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA24x1vf.img?w=768&h=512&m=6&x=100&y=201&s=372&d=164) <small>www.msn.com</small>Greve geral ameaça parar parte do país: 10 perguntas e respostas sobre a paralisação de 3 de junho

AVISO PRÉVIO DE GREVE GERAL 3 JUNHO 2026 – STTS
-----------------------------------------------

 ![AVISO PRÉVIO DE GREVE GERAL 3 JUNHO 2026 – STTS](https://www.stts.pt/wp-content/uploads/2026/05/Imagem1-210x136.png) <small>www.stts.pt</small>AVISO PRÉVIO DE GREVE GERAL 3 JUNHO 2026 – STTS

MAIO É FESTA! MAIO É LUTA! GREVE GERAL - 3 DE JUNHO — União Dos Sindicatos De Lisboa - USL/CGTP-IN
--------------------------------------------------------------------------------------------------

 ![MAIO É FESTA! MAIO É LUTA! GREVE GERAL - 3 DE JUNHO — União dos Sindicatos de Lisboa - USL/CGTP-IN](https://uniaolisboa-cgtp.pt/images/stories/uniao_imgs/2026/202605/IMG_4310.jpeg) <small>uniaolisboa-cgtp.pt</small>MAIO É FESTA! MAIO É LUTA! GREVE GERAL - 3 DE JUNHO — União dos Sindicatos de Lisboa - USL/CGTP-IN

Greve Geral – Derrotar O Pacote Laboral – 3 De Junho 2026 – SINTTAV Sindicato Nacional Dos
------------------------------------------------------------------------------------------

 ![Greve Geral – Derrotar o Pacote Laboral – 3 de Junho 2026 – SINTTAV Sindicato Nacional dos](https://sinttav.pt/wp-content/uploads/2026/05/Cartaz_Greve-Geral-Derrotar-o-Pacote-Laboral-3-de-Junho-2026.jpg) <small>sinttav.pt</small>Greve Geral – Derrotar o Pacote Laboral – 3 de Junho 2026 – SINTTAV Sindicato Nacional dos ...

CGTP Convoca Greve Geral Para 3 De Junho - Sociedade - Correio Da Manhã
-----------------------------------------------------------------------

 ![CGTP convoca greve geral para 3 de junho - Sociedade - Correio da Manhã](https://cdn.cmjornal.pt/images/2025-12/img_1500x1000uu2025-12-11-14-37-03-2253844.jpg) <small>www.cmjornal.pt</small>CGTP convoca greve geral para 3 de junho - Sociedade - Correio da Manhã

CGTP Convoca Greve Geral Para 3 De Junho - Portugal - SÁBADO
------------------------------------------------------------

 ![CGTP convoca greve geral para 3 de junho - Portugal - SÁBADO](https://cdn.sabado.pt/images/2026-05/img_1920x1080uu2026-05-01-08-54-55-764661.jpg) <small>www.sabado.pt</small>CGTP convoca greve geral para 3 de junho - Portugal - SÁBADO

Transportes, Escolas E Hospitais: O Que Esperar Da Greve De 3 De Junho - Dinheiro - SÁBADO
------------------------------------------------------------------------------------------

 ![Transportes, escolas e hospitais: o que esperar da greve de 3 de junho - Dinheiro - SÁBADO](https://cdn.sabado.pt/images/2026-05/img_980x653uu2026-05-30-11-36-15-766875.jpg) <small>www.sabado.pt</small>Transportes, escolas e hospitais: o que esperar da greve de 3 de junho - Dinheiro - SÁBADO

Greve Geral De 24 Horas No Dia 3 De Junho- Serviço De Transporte Afetado
------------------------------------------------------------------------

 ![Greve geral de 24 horas no dia 3 de junho- Serviço de transporte afetado](https://www.metrolisboa.pt/institucional/wp-content/uploads/sites/2/2026/06/greve-3-junho_1080x450.png) <small>www.metrolisboa.pt</small>Greve geral de 24 horas no dia 3 de junho- Serviço de transporte afetado

GREVE GERAL DE 3 DE JUNHO – AS FAQ EM IMAGENS – Spzs Site
---------------------------------------------------------

 ![GREVE GERAL DE 3 DE JUNHO – AS FAQ EM IMAGENS – spzs site](https://www.spzs.pt/wp-content/uploads/2026/05/faq-gg-24.jpeg) <small>www.spzs.pt</small>GREVE GERAL DE 3 DE JUNHO – AS FAQ EM IMAGENS – spzs site

O Que Vai Parar Com A Greve Geral De 3 De Junho? - Portugal - SÁBADO
--------------------------------------------------------------------

 ![O que vai parar com a greve geral de 3 de junho? - Portugal - SÁBADO](https://cdn.sabado.pt/images/2026-05/img_640x426uu2026-05-21-18-26-04-766232.jpg) <small>www.sabado.pt</small>O que vai parar com a greve geral de 3 de junho? - Portugal - SÁBADO

Greve Geral: Trabalhadores Em Arquitetura Juntam-se à Paralisação - Portugal - SÁBADO
-------------------------------------------------------------------------------------

 ![Greve geral: Trabalhadores em arquitetura juntam-se à paralisação - Portugal - SÁBADO](https://cdn.sabado.pt/images/2026-05/img_980x653uu2026-05-21-15-24-22-766216.jpg) <small>www.sabado.pt</small>Greve geral: Trabalhadores em arquitetura juntam-se à paralisação - Portugal - SÁBADO

Greve Geral De 3 De Junho Ameaça Paralisar O País: Que Setores Serão Impactados?
--------------------------------------------------------------------------------

 ![Greve geral de 3 de junho ameaça paralisar o país: que setores serão impactados?](https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA24BPMf.img?w=768&h=432&m=6&x=140&y=272&s=39&d=39) <small>www.msn.com</small>Greve geral de 3 de junho ameaça paralisar o país: que setores serão impactados?

Greve Geral - 3 De Junho De 2026 | Concentrações - CGTP-IN
----------------------------------------------------------

 ![Greve Geral - 3 de Junho de 2026 | Concentrações - CGTP-IN](https://www.cgtp.pt/images/images/2026/05/CONCENTRACOES-GG.jpg) <small>www.cgtp.pt</small>Greve Geral - 3 de Junho de 2026 | Concentrações - CGTP-IN

CGTP Avança Com Greve Geral Para 3 De Junho
-------------------------------------------

 ![CGTP avança com greve geral para 3 de junho](https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA229Sqw.img?w=1200&h=800&m=4&q=70) <small>www.msn.com</small>CGTP avança com greve geral para 3 de junho

A Greve Geral De 3 De Junho é Para Todos Os Trabalhadores
---------------------------------------------------------

 ![A greve geral de 3 de junho é para todos os trabalhadores](https://www.sep.org.pt/files/uploads/2026/05/SEP_03_JUNHO-04.jpg) <small>www.sep.org.pt</small>A greve geral de 3 de junho é para todos os trabalhadores

Professores Deram Uma Forte Expressão à Greve Geral De 3 De Junho - FENPROF
---------------------------------------------------------------------------

 ![Professores deram uma forte expressão à Greve Geral de 3 de junho - FENPROF](https://www.fenprof.pt/media/download/6FDA79F0A62C1CB1E79A4D96032CBC0A/foto-greve-na-rua.jpg) <small>www.fenprof.pt</small>Professores deram uma forte expressão à Greve Geral de 3 de junho - FENPROF

AVISO PRÉVIO DE GREVE GERAL 3 JUNHO 2026 – STTS
-----------------------------------------------

 ![AVISO PRÉVIO DE GREVE GERAL 3 JUNHO 2026 – STTS](https://www.stts.pt/wp-content/uploads/2026/05/123654.jpg) <small>www.stts.pt</small>AVISO PRÉVIO DE GREVE GERAL 3 JUNHO 2026 – STTS

Greve Geral - 03 De Junho De 2026
---------------------------------

 ![Greve Geral - 03 de junho de 2026](https://cabeceirasdebasto.pt/files/46/46246.jpg) <small>cabeceirasdebasto.pt</small>Greve Geral - 03 de junho de 2026

CGTP Convoca Greve Geral Para 3 De Junho, UGT Não Exclui
--------------------------------------------------------

 ![CGTP convoca greve geral para 3 de junho, UGT não exclui](https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA229tFU.img?w=1440&h=960&m=4&q=84) <small>www.msn.com</small>CGTP convoca greve geral para 3 de junho, UGT não exclui

CGTP-IN Convoca Uma Greve Geral Para O Dia 3 De Junho - Diário Do Distrito
--------------------------------------------------------------------------

 ![CGTP-IN convoca uma Greve Geral para o dia 3 de junho - Diário do Distrito](https://diariodistrito.sapo.pt/wp-content/uploads/2026/05/684149698_18402222190144979_5097408588536771741_n-scaled.jpg) <small>diariodistrito.sapo.pt</small>CGTP-IN convoca uma Greve Geral para o dia 3 de junho - Diário do Distrito

Professores deram uma forte expressão à greve geral de 3 de junho. Aviso prévio de greve geral 3 junho 2026 – stts. Greve geral
