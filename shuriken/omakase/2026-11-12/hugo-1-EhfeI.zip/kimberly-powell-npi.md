---
title: "Kimberly Powell Npi - Exclusive interview with kimberly powell, vp and general manager of nvidia healthcare"
description: "How ai is revolutionizing healthcare with kimberly powell of nvidia – health podcast network"
date: "2026-11-06"
categories:
- "Uncategorized"
images:
- "https://www.amgen.com/stories/2024/05/-/media/Themes/CorporateAffairs/amgen-com/amgen-com/Images/stories/2024/05-21-From-the-Office-to-the-Lab-Amgen-Uses-AI-Tools-to-Unlock-Innovation/powell.png"
featuredImage: "https://media.licdn.com/dms/image/v2/D4E10AQEoQkQL3_Sr8w/image-shrink_1280/image-shrink_1280/0/1707382180957?e=2147483647&amp;v=beta&amp;t=0dqql3MYC7lUbb88BTFqqiIbvIz3Tb1NcqvpEZkm5PY"
featured_image: "https://morningbrew.com/cdn-cgi/image/width=1336,format=auto/https://storage.morningbrew.com/image/2026-01-22/image-231c26908ecfb4c46ca27dc03994c37ea6982bf3-1500x1000-jpg/HCB-MakingRounds-KimPowell-Nvidia-0126.jpg"
image: "https://media.licdn.com/dms/image/v2/D4D22AQHI7fbK1GV1QQ/feedshare-shrink_2048_1536/feedshare-shrink_2048_1536/0/1717762363344?e=2147483647&amp;v=beta&amp;t=HcXrmL3078ePC82LlnhipxGpfpS2lI088q7m0yCHQ0I"
---

If you are searching about Kimberly Powell - Pennsylvania State University you've came to the right place. We have 34 Pics about Kimberly Powell - Pennsylvania State University like MS. Kimberly Sue Powell, LPC - Professional Counselor in Shreveport, LA | NPI 1306356803, NVIDIA Powers Up in Drug Discovery and also Kimberly Powell - Federal Cybersecurity Analyst | | Security Architecture Enterprise. Here it is:

Kimberly Powell - Pennsylvania State University
-----------------------------------------------

 ![Kimberly Powell - Pennsylvania State University](https://0.academia-photos.com/1058553/367697/155199356/s200_kimberly.powell.jpeg) <small>pennstate.academia.edu</small>Kimberly Powell - Pennsylvania State University

Generative AI Is Revolutionizing Healthcare, From Drug Discovery To Diagnostics And Post-op Care
------------------------------------------------------------------------------------------------

 ![Generative AI is revolutionizing healthcare, from drug discovery to diagnostics and post-op care](https://media.licdn.com/dms/image/v2/D4D22AQHI7fbK1GV1QQ/feedshare-shrink_2048_1536/feedshare-shrink_2048_1536/0/1717762363344?e=2147483647&v=beta&t=HcXrmL3078ePC82LlnhipxGpfpS2lI088q7m0yCHQ0I) <small>pe.linkedin.com</small>Generative AI is revolutionizing healthcare, from drug discovery to diagnostics and post-op care ...

Nvidia Expands AI Ambitions In Healthcare; Aims To Transform Hospitals With Robotics – Digital
----------------------------------------------------------------------------------------------

 ![Nvidia expands AI ambitions in healthcare; aims to transform hospitals with robotics – Digital](https://digitaleconomymag.com/wp-content/uploads/2024/11/Nvidia-Kimberly-Powel.png) <small>digitaleconomymag.com</small>Nvidia expands AI ambitions in healthcare; aims to transform hospitals with robotics – Digital ...

Nvidia Sees Major Shift In Radiology To AI Agents And New Autonomous Imaging Systems
------------------------------------------------------------------------------------

 ![Nvidia sees major shift in radiology to AI agents and new autonomous imaging systems](https://radiologybusiness.com/sites/default/files/styles/facebook/public/2025-12/kimberly_powell_explains_impact_of_nvidia_on_radiology_ai_across_the_rsna_expo_floor.jpg?h=8d346626&itok=ge9CtIQY) <small>radiologybusiness.com</small>Nvidia sees major shift in radiology to AI agents and new autonomous imaging systems

Nvidia Wants To Bring Robots To The Hospital - Business Insider
---------------------------------------------------------------

 ![Nvidia Wants to Bring Robots to the Hospital - Business Insider](https://i.insider.com/6722a9e501ea6d83dee542bb?width=700) <small>www.businessinsider.com</small>Nvidia Wants to Bring Robots to the Hospital - Business Insider

Hear From Kimberly Powell, Sr. Director Of Deep Learning, On The Highlights Of #CVPR2017
----------------------------------------------------------------------------------------

 ![Hear from Kimberly Powell, Sr. Director of Deep Learning, on the highlights of #CVPR2017](https://lookaside.fbsbx.com/lookaside/crawler/media/?media_id=10155005906623253&get_thumbnail=1) <small>www.facebook.com</small>Hear from Kimberly Powell, Sr. Director of Deep Learning, on the highlights of #CVPR2017 ...

🚨 NVIDIA’s Healthcare AI Revolution! Kimberly Powell Speaks At TD Cowen Conference | NVDA Stock
-----------------------------------------------------------------------------------------------

 ![🚨 NVIDIA’s Healthcare AI Revolution! Kimberly Powell Speaks at TD Cowen Conference | NVDA Stock](https://i.ytimg.com/vi/FJJaogTk5Jc/maxresdefault.jpg) <small>www.youtube.com</small>🚨 NVIDIA’s Healthcare AI Revolution! Kimberly Powell Speaks at TD Cowen Conference | NVDA Stock ...

Exclusive Interview With Kimberly Powell, VP And General Manager Of NVIDIA Healthcare - MarkTechPost
----------------------------------------------------------------------------------------------------

 ![Exclusive Interview with Kimberly Powell, VP and General Manager of NVIDIA Healthcare - MarkTechPost](https://www.marktechpost.com/wp-content/uploads/2022/04/Interview-2.png) <small>www.marktechpost.com</small>Exclusive Interview with Kimberly Powell, VP and General Manager of NVIDIA Healthcare - MarkTechPost

Kimberly Powell Honored For Pioneering Work In Health Informatics And Gerontology
---------------------------------------------------------------------------------

 ![Kimberly Powell honored for pioneering work in health informatics and gerontology](https://nursing.missouri.edu/wp-content/uploads/2024/05/Congratulations.png) <small>nursing.missouri.edu</small>Kimberly Powell honored for pioneering work in health informatics and gerontology

MS. Kimberly Sue Powell, LPC - Professional Counselor In Shreveport, LA | NPI 1306356803
----------------------------------------------------------------------------------------

 ![MS. Kimberly Sue Powell, LPC - Professional Counselor in Shreveport, LA | NPI 1306356803](https://lerasign.com/provider/kimberly-powell-shreveport-la-1306356803/opengraph-image?52129bcf1123a2e0) <small>lerasign.com</small>MS. Kimberly Sue Powell, LPC - Professional Counselor in Shreveport, LA | NPI 1306356803 ...

GTC 2025 – Announcements And Live Updates | NVIDIA Blog
-------------------------------------------------------

 ![GTC 2025 – Announcements and Live Updates | NVIDIA Blog](https://blogs.nvidia.com/wp-content/uploads/2025/03/kptalk-1280x960.jpg) <small>blogs.nvidia.com</small>GTC 2025 – Announcements and Live Updates | NVIDIA Blog

Isicad: NVIDIA стимулирует развитие глубокого обучения с помощью нового процессора TITAN X
------------------------------------------------------------------------------------------

 ![isicad: NVIDIA стимулирует развитие глубокого обучения с помощью нового процессора TITAN X](https://isicad.ru/uploads/img/9564_KPowell_headshot.jpg) <small>isicad.ru</small>isicad: NVIDIA стимулирует развитие глубокого обучения с помощью нового процессора TITAN X ...

AIで医療分野にイノベーションを起こすNVIDIA - PC Watch
------------------------------------

 ![AIで医療分野にイノベーションを起こすNVIDIA - PC Watch](https://asset.watch.impress.co.jp/img/pcw/docs/1120/878/DSCF5066_l.jpg) <small>pc.watch.impress.co.jp</small>AIで医療分野にイノベーションを起こすNVIDIA - PC Watch

UCO Press Release: Classical KCSC's Kimberly Powell Selected As Recipient Of Governor's Arts Award
--------------------------------------------------------------------------------------------------

 ![UCO Press Release: Classical KCSC's Kimberly Powell Selected as Recipient of Governor's Arts Award](http://www.uco.edu/photo/KimberlyPowell10.13/_3IA1247_POWELL.jpg) <small>www3.uco.edu</small>UCO Press Release: Classical KCSC's Kimberly Powell Selected as Recipient of Governor's Arts Award

What Can Health Care Learn From Self-Driving Cars? | Johns Hopkins Medicine
---------------------------------------------------------------------------

 ![What Can Health Care Learn from Self-Driving Cars? | Johns Hopkins Medicine](https://www.hopkinsmedicine.org/-/media/images/articles/2018/03/kimberly_powell.jpeg?h=640&iar=0&w=640&hash=1741F5E78A512573722D6BEAB32D9288) <small>www.hopkinsmedicine.org</small>What Can Health Care Learn from Self-Driving Cars? | Johns Hopkins Medicine

Kimberly Powell - Federal Cybersecurity Analyst | | Security Architecture Enterprise
------------------------------------------------------------------------------------

 ![Kimberly Powell - Federal Cybersecurity Analyst | | Security Architecture Enterprise](https://media.licdn.com/dms/image/v2/D4E03AQHf6Yx1tOaXCQ/profile-displayphoto-scale_200_200/B4EZvjsxCZJAAY-/0/1769051722281?e=2147483647&v=beta&t=UOjMcwZafuKlXgdI61I0hti_3ZXbs2LOpiufYIR0ZWk) <small>www.linkedin.com</small>Kimberly Powell - Federal Cybersecurity Analyst | | Security Architecture Enterprise ...

Nvidia's Kimberly Powell Is Leading The Chip Giant's Charge Into AI For Health Care - San
-----------------------------------------------------------------------------------------

 ![Nvidia's Kimberly Powell is leading the chip giant's charge into AI for health care - San](https://media.bizj.us/view/img/12968502/kimberlypowell-1*1200xx9428-5303-0-491.jpg) <small>www.bizjournals.com</small>Nvidia's Kimberly Powell is leading the chip giant's charge into AI for health care - San ...

NVIDIA: A Nova Fronteira Da Medicina Está Na IA - CM
----------------------------------------------------

 ![NVIDIA: A nova fronteira da Medicina está na IA - CM](https://consumidormoderno.com.br/wp-content/uploads/2025/03/Nvidia_Kimberly-Powell-1024x530.webp) <small>consumidormoderno.com.br</small>NVIDIA: A nova fronteira da Medicina está na IA - CM

Kimberly Powell - Vice President / General Manager, Healthcare @ NVIDIA - Crunchbase Person Profile
---------------------------------------------------------------------------------------------------

 ![Kimberly Powell - Vice President / General Manager, Healthcare @ NVIDIA - Crunchbase Person Profile](https://images.crunchbase.com/image/upload/c_thumb,h_256,w_256,f_auto,g_face,z_0.7,q_auto:eco,dpr_1/v1486125205/a5yj10qzswrekrnfpwag.png) <small>www.crunchbase.com</small>Kimberly Powell - Vice President / General Manager, Healthcare @ NVIDIA - Crunchbase Person Profile

Kimberly Powell Inducted As Fellow Of The American Medical Informatics Association, Announced As
------------------------------------------------------------------------------------------------

 ![Kimberly Powell inducted as Fellow of the American Medical Informatics Association, announced as](https://showme.missouri.edu/wp-content/uploads/2024/06/internet-usage-4x5-2-scaled.jpg) <small>showme.missouri.edu</small>Kimberly Powell inducted as Fellow of the American Medical Informatics Association, announced as ...

An Interview With Kimberley Powell (NVIDIA) At The AI Summit, San Francisco (2016). - YouTube
---------------------------------------------------------------------------------------------

 ![An Interview with Kimberley Powell (NVIDIA) at The AI Summit, San Francisco (2016). - YouTube](https://i.ytimg.com/vi/15s952bcezM/maxresdefault.jpg) <small>www.youtube.com</small>An Interview with Kimberley Powell (NVIDIA) at The AI Summit, San Francisco (2016). - YouTube

2024 STAT Breakthrough Summit West: Medicine's Future, Now
----------------------------------------------------------

 ![2024 STAT Breakthrough Summit West: Medicine's Future, Now](https://www.statnews.com/wp-content/uploads/2024/02/Kimberly-Powell_BTW_cropped-640x823.jpg) <small>www.statnews.com</small>2024 STAT Breakthrough Summit West: Medicine's Future, Now

Kimberly Powell Special Address - Healthcare At GTC | Channah Blocq
-------------------------------------------------------------------

 ![Kimberly Powell Special Address - Healthcare at GTC | Channah Blocq](https://media.licdn.com/dms/image/v2/D4E10AQEoQkQL3_Sr8w/image-shrink_1280/image-shrink_1280/0/1707382180957?e=2147483647&v=beta&t=0dqql3MYC7lUbb88BTFqqiIbvIz3Tb1NcqvpEZkm5PY) <small>www.linkedin.com</small>Kimberly Powell Special Address - Healthcare at GTC | Channah Blocq

Kimberly Powell, PMP - Senior Operations &amp; Project Management Executive | PMP | Focused On High
---------------------------------------------------------------------------------------------------

 ![Kimberly Powell, PMP - Senior Operations & Project Management Executive | PMP | Focused on High](https://media.licdn.com/dms/image/v2/D4E03AQEYu2Pv8-YTkg/profile-displayphoto-shrink_200_200/profile-displayphoto-shrink_200_200/0/1729185414021?e=2147483647&v=beta&t=Pa6hUnNnQc_2KjhhtdhccRC97EqOpP8qW8Qs4TYhuwY) <small>www.linkedin.com</small>Kimberly Powell, PMP - Senior Operations &amp; Project Management Executive | PMP | Focused on High ...

AI And Digital Biology: Unlocking The Future Of Drug Discovery With Kimberly Powell | WIRED
-------------------------------------------------------------------------------------------

 ![AI and digital biology: Unlocking the future of drug discovery with Kimberly Powell | WIRED](https://i.ytimg.com/vi/yeCmKq8aOY0/maxresdefault.jpg) <small>www.youtube.com</small>AI and digital biology: Unlocking the future of drug discovery with Kimberly Powell | WIRED ...

AWS High Performance Computing
------------------------------

 ![AWS High Performance Computing](https://pages.awscloud.com/rs/112-TZM-766/images/Kimberly_hpc_event.jpg) <small>pages.awscloud.com</small>AWS High Performance Computing

Healthcare Brew | Healthcare Industry News &amp; Trends | Healthcare Brew
-------------------------------------------------------------------------

 ![Healthcare Brew | Healthcare Industry News & Trends | Healthcare Brew](https://morningbrew.com/cdn-cgi/image/width=1336,format=auto/https://storage.morningbrew.com/image/2026-01-22/image-231c26908ecfb4c46ca27dc03994c37ea6982bf3-1500x1000-jpg/HCB-MakingRounds-KimPowell-Nvidia-0126.jpg) <small>www.healthcare-brew.com</small>Healthcare Brew | Healthcare Industry News &amp; Trends | Healthcare Brew

Kimberly Powell On LinkedIn: Had A Fantastic Time Hosting The PowerUp Strategic Educators
-----------------------------------------------------------------------------------------

 ![Kimberly Powell on LinkedIn: Had a fantastic time hosting the PowerUp Strategic Educators](https://media.licdn.com/dms/image/D5622AQEBItJYa-ypGw/feedshare-shrink_800/0/1708957758233?e=2147483647&v=beta&t=xMzVZhCGZYMoNSETCR7it3dpNlrrkZKiht8hIB45sdI) <small>www.linkedin.com</small>Kimberly Powell on LinkedIn: Had a fantastic time hosting the PowerUp Strategic Educators ...

Kimberly Powell Honored For Pioneering Work In Health Informatics And Gerontology
---------------------------------------------------------------------------------

 ![Kimberly Powell honored for pioneering work in health informatics and gerontology](https://nursing.missouri.edu/wp-content/uploads/2024/06/Kimberly-Powell-FAMIA-induction.png) <small>nursing.missouri.edu</small>Kimberly Powell honored for pioneering work in health informatics and gerontology

NVIDIA Powers Up In Drug Discovery
----------------------------------

 ![NVIDIA Powers Up in Drug Discovery](https://genengnews.com/wp-content/uploads/2020/10/Kimberly-Powell_avatar_1511719112-200x200-1.jpg) <small>www.genengnews.com</small>NVIDIA Powers Up in Drug Discovery

Home - Cell X Technologies
--------------------------

 ![Home - Cell X Technologies](https://cellxtechnologies.com/wp-content/uploads/2023/09/Image_Kimberly-Powell.jpg) <small>cellxtechnologies.com</small>Home - Cell X Technologies

Dive Into The Future Of Digital Surgery, Health, And Biology With NVIDIA's VP Of Healthcare And
-----------------------------------------------------------------------------------------------

 ![Dive into the future of digital surgery, health, and biology with NVIDIA's VP of Healthcare and](https://media.licdn.com/dms/image/v2/D5610AQEf18m9u13NPw/image-shrink_800/image-shrink_800/0/1718404075786?e=2147483647&v=beta&t=F-wL667A6hY7CE4c0fp8ufvPB6vLFAUNhCatqrC7jY4) <small>www.linkedin.com</small>Dive into the future of digital surgery, health, and biology with NVIDIA's VP of Healthcare and ...

How AI Is Revolutionizing Healthcare With Kimberly Powell Of NVIDIA – Health Podcast Network
--------------------------------------------------------------------------------------------

 ![How AI Is Revolutionizing Healthcare with Kimberly Powell of NVIDIA – Health Podcast Network](https://megaphone.imgix.net/podcasts/25c5f82c-2777-11f0-9b28-f39167168459/image/07e90bf930a6aa2fc971ce0501ed371e.png?ixlib=rails-4.3.1&max-w=3000&max-h=3000&fit=crop&auto=format,compress) <small>healthpodcastnetwork.com</small>How AI Is Revolutionizing Healthcare with Kimberly Powell of NVIDIA – Health Podcast Network

From The Office To The Lab, Amgen Uses AI Tools To Unlock Innovation | Amgen
----------------------------------------------------------------------------

 ![From the Office to the Lab, Amgen Uses AI Tools to Unlock Innovation | Amgen](https://www.amgen.com/stories/2024/05/-/media/Themes/CorporateAffairs/amgen-com/amgen-com/Images/stories/2024/05-21-From-the-Office-to-the-Lab-Amgen-Uses-AI-Tools-to-Unlock-Innovation/powell.png) <small>www.amgen.com</small>From the Office to the Lab, Amgen Uses AI Tools to Unlock Innovation | Amgen

Dive into the future of digital surgery, health, and biology with nvidia's vp of healthcare and. Nvidia wants to bring robots to the hospital. Generative ai is revolutionizing healthcare, from drug discovery to diagnostics and post-op care
