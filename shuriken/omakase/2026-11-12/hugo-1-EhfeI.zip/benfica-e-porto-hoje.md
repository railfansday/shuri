---
title: "Benfica E Porto Hoje - Porto x benfica hoje (14/1): onde assistir ao vivo, horário e escalações da taça de portugal"
description: "Taça de portugal: fc porto recebe hoje o benfica nos ‘quartos’"
date: "2026-07-17"
categories:
- "Uncategorized"
images:
- "https://www.dci.com.br/wp-content/uploads/2021/12/Porto-x-Benfica-onde-assistir.jpg"
featuredImage: "https://rtiesporte.com.br/wp-content/uploads/2026/03/2026-BENFICA-X-PORTP-LIGA-PORTUGUESA.jpg"
featured_image: "https://binny-bolanarede.b-cdn.net/wp-content/uploads/2025/11/Samuel-Dahl-Pepe-Benfica-FC-Porto-1536x864.jpg"
image: "https://binny-bolanarede.b-cdn.net/wp-content/uploads/2025/04/Tiago-Djalo-Angel-Di-Maria-FC-Porto-Benfica.jpg"
---

If you are searching about Onde assistir Porto x Benfica hoje: canal, horário e escalações - 30/12 you've visit to the right page. We have 35 Pics about Onde assistir Porto x Benfica hoje: canal, horário e escalações - 30/12 like Transmissão em directo de Benfica x Porto: Vai dar em sinal aberto? Saiba onde assistir ao vivo, Di María: «Hoje voltámos a ser o Benfica, já merecíamos» - CNN Portugal and also FC Porto Benfica José Mourinho Pós-jogo Liga - SL Benfica. Here it is:

Onde Assistir Porto X Benfica Hoje: Canal, Horário E Escalações - 30/12
-----------------------------------------------------------------------

 ![Onde assistir Porto x Benfica hoje: canal, horário e escalações - 30/12](https://www.dci.com.br/wp-content/uploads/2021/12/Porto-x-Benfica-onde-assistir.jpg) <small>www.dci.com.br</small>Onde assistir Porto x Benfica hoje: canal, horário e escalações - 30/12

Benfica 2 - 2 Porto (Relato) | Jornada 25 Da I Liga - Golo FM | A Primeira Rádio Desporto
-----------------------------------------------------------------------------------------

 ![Benfica 2 - 2 Porto (Relato) | Jornada 25 da I Liga - Golo FM | A Primeira Rádio Desporto](https://golo.fm/wp-content/uploads/2026/03/Benfica-vs-Porto-08032026-18H-Capa-Site-1024x661.png) <small>golo.fm</small>Benfica 2 - 2 Porto (Relato) | Jornada 25 da I Liga - Golo FM | A Primeira Rádio Desporto

FC Porto X Benfica: Eis Os últimos 5 Resultados Entre As Duas Equipas
---------------------------------------------------------------------

 ![FC Porto x Benfica: Eis os últimos 5 resultados entre as duas equipas](https://binny-bolanarede.b-cdn.net/wp-content/uploads/2025/04/Tiago-Djalo-Angel-Di-Maria-FC-Porto-Benfica.jpg) <small>bolanarede.pt</small>FC Porto x Benfica: Eis os últimos 5 resultados entre as duas equipas

FC Porto Benfica José Mourinho Pós-jogo Liga - SL Benfica
---------------------------------------------------------

 ![FC Porto Benfica José Mourinho Pós-jogo Liga - SL Benfica](https://media.slbenfica.pt/-/media/benficadp/images/departamento-de-comunicacao/2025/futebol/competicoes/liga-betclic/8-jornada-fc-porto-benfica/jogo/lukebakio-thumbnail.jpg?la=pt-pt&v=638952963450000000&hash=49C9B692A12902926F570943D7D3100E) <small>www.slbenfica.pt</small>FC Porto Benfica José Mourinho Pós-jogo Liga - SL Benfica

Benfica X Porto Ao Vivo: Onde Assistir, Palpites E Escalações No Português - RTI Esporte
----------------------------------------------------------------------------------------

 ![Benfica x Porto ao vivo: onde assistir, palpites e escalações no Português - RTI Esporte](https://rtiesporte.com.br/wp-content/uploads/2026/03/2026-BENFICA-X-PORTP-LIGA-PORTUGUESA.jpg) <small>rtiesporte.com.br</small>Benfica x Porto ao vivo: onde assistir, palpites e escalações no Português - RTI Esporte

Porto Empata Com Benfica E Perde Chance De Ampliar Distância Na Liderança Do Português - Gazeta
-----------------------------------------------------------------------------------------------

 ![Porto empata com Benfica e perde chance de ampliar distância na liderança do Português - Gazeta](https://static.gazetaesportiva.com/uploads/2025/10/AFP__20251005__77TA99G__v1__HighRes__FblPorLigaPortoBenfica.webp) <small>www.gazetaesportiva.com</small>Porto empata com Benfica e perde chance de ampliar distância na liderança do Português - Gazeta ...

Neste Domingo Tem Clássico Benfica E Porto – RNA
------------------------------------------------

 ![Neste domingo tem clássico Benfica e Porto – RNA](https://rna.ao/rna.ao/wp-content/uploads/2024/11/IMG_7862.jpeg) <small>rna.ao</small>Neste domingo tem clássico Benfica e Porto – RNA

Porto VS Benfica Live Stream 3 March 2024 Watch TV Porto Are | Información COLEGIO AUSUBEL
------------------------------------------------------------------------------------------

 ![Porto VS Benfica live stream 3 March 2024 Watch TV Porto are | Información COLEGIO AUSUBEL](https://static.wixstatic.com/media/097cef_f1115789e6de46aa805d6fbb8954a4fc~mv2.gif/v1/fill/w_1298,h_741,al_c/097cef_f1115789e6de46aa805d6fbb8954a4fc~mv2.gif) <small>www.colegiovirtualausubel.edu.co</small>Porto VS Benfica live stream 3 March 2024 Watch TV Porto are | Información COLEGIO AUSUBEL ...

ESSA MANHÃ! LUTA ENTRE BENFICA E FC PORTO! NOTÍCIAS DO BENFICA HOJE! BENFICA - YouTube
--------------------------------------------------------------------------------------

 ![ESSA MANHÃ! LUTA ENTRE BENFICA E FC PORTO! NOTÍCIAS DO BENFICA HOJE! BENFICA - YouTube](https://i.ytimg.com/vi/jBKbM7SVWMo/maxresdefault.jpg) <small>www.youtube.com</small>ESSA MANHÃ! LUTA ENTRE BENFICA E FC PORTO! NOTÍCIAS DO BENFICA HOJE! BENFICA - YouTube

Benfica Vs Porto Em Directo | Porto Benfica Players – VRIMCA
------------------------------------------------------------

 ![Benfica Vs Porto Em Directo | Porto Benfica Players – VRIMCA](https://i.ytimg.com/vi/0TX6I7SgyJ4/maxresdefault.jpg) <small>rhythm.eimagazine.com</small>Benfica Vs Porto Em Directo | Porto Benfica Players – VRIMCA

Vídeo - Liga Portugal Betclic (11ª Jornada): Resumo Benfica 4-1 FC Porto
------------------------------------------------------------------------

 ![Vídeo - Liga Portugal Betclic (11ª Jornada): Resumo Benfica 4-1 FC Porto](https://stc.vsports.pt/bigpic/liga/2425/2n110MmogcxKTZVzU82Wv.jpg) <small>vsports.pt</small>Vídeo - Liga Portugal Betclic (11ª Jornada): Resumo Benfica 4-1 FC Porto

Eis Os 5 Destaques Do Benfica X FC Porto Em Jogo Da Primeira Liga
-----------------------------------------------------------------

 ![Eis os 5 destaques do Benfica x FC Porto em jogo da Primeira Liga](https://binny-bolanarede.b-cdn.net/wp-content/uploads/2026/03/Nicolas-Otamendi-Benfica-Oskar-Pietuszweski-FC-Porto.jpg) <small>bolanarede.pt</small>Eis os 5 destaques do Benfica x FC Porto em jogo da Primeira Liga

Onde Assistir Hoje O Jogo Do Benfica X Porto Na Taça Portugal
-------------------------------------------------------------

 ![Onde assistir hoje o jogo do Benfica x Porto na Taça Portugal](https://www.dci.com.br/wp-content/uploads/2026/01/porto-benfica-hoje--scaled-1130x580.png) <small>www.dci.com.br</small>Onde assistir hoje o jogo do Benfica x Porto na Taça Portugal

FC Porto X Benfica: Onde E A Que Horas Ver O Jogo Da Liga Portuguesa? - 4gnews
------------------------------------------------------------------------------

 ![FC Porto x Benfica: onde e a que horas ver o jogo da Liga Portuguesa? - 4gnews](https://cdn.4gnews.pt/imagens/fc-porto-x-benfica-onde-e-a-que-horas-ver-o-jogo-da-liga-portuguesa-og.jpg) <small>4gnews.pt</small>FC Porto x Benfica: onde e a que horas ver o jogo da Liga Portuguesa? - 4gnews

Benfica, FC Porto E Braga Conhecem Hoje Adversários Na Fase De Grupos Da Liga Dos Campeões
------------------------------------------------------------------------------------------

 ![Benfica, FC Porto e Braga conhecem hoje adversários na fase de grupos da Liga dos Campeões](https://images.rr.pt/supertaca2023-slb-fcp-03113049bce_socialshare.jpg) <small>rr.pt</small>Benfica, FC Porto e Braga conhecem hoje adversários na fase de grupos da Liga dos Campeões ...

FPF Confirma Data E Transmissão Em Canal Aberto Do FC Porto X Benfica Dos Quartos De Final Da
---------------------------------------------------------------------------------------------

 ![FPF confirma data e transmissão em canal aberto do FC Porto x Benfica dos quartos de final da](https://binny-bolanarede.b-cdn.net/wp-content/uploads/2025/11/Samuel-Dahl-Pepe-Benfica-FC-Porto-1536x864.jpg) <small>bolanarede.pt</small>FPF confirma data e transmissão em canal aberto do FC Porto x Benfica dos quartos de final da ...

Liga Portugal - Empate Entre SL Benfica B E FC Porto B
------------------------------------------------------

 ![Liga Portugal - Empate entre SL Benfica B e FC Porto B](https://www.ligaportugal.pt/backoffice/assets/Post_Resultado_630cf1b443.jpg) <small>www.ligaportugal.pt</small>Liga Portugal - Empate entre SL Benfica B e FC Porto B

Onde Assistir Benfica Hoje X Porto: Horário Da Primeira Liga (21/10)
--------------------------------------------------------------------

 ![Onde assistir Benfica hoje x Porto: horário da Primeira Liga (21/10)](https://www.dci.com.br/wp-content/uploads/2022/10/onde-assistir-benfica-hoje.jpg) <small>www.dci.com.br</small>Onde assistir Benfica hoje x Porto: horário da Primeira Liga (21/10)

Antevisão Benfica 🆚 Porto | O Que Dizem Os Teus Analytics, Antunes? | GoalPoint
-------------------------------------------------------------------------------

 ![Antevisão Benfica 🆚 Porto | O que dizem os teus analytics, Antunes? | GoalPoint](https://goalpoint.pt/wp-content/uploads/2023/04/GoalPoint-Benfica-Porto-Antevisao-04.2023.jpg) <small>goalpoint.pt</small>Antevisão Benfica 🆚 Porto | O que dizem os teus analytics, Antunes? | GoalPoint

️ Porto X Benfica Onde Assistir Ao Vivo E Na TV, Palpite, H2H - 5 Out 2025
--------------------------------------------------------------------------

 ![️ Porto x Benfica Onde assistir ao vivo e na TV, Palpite, H2H - 5 out 2025](https://sporticos.com/images/pt-br/match/benfica-vs-fc-porto) <small>sporticos.com</small>️ Porto x Benfica Onde assistir ao vivo e na TV, Palpite, H2H - 5 out 2025

Taça De Portugal: FC Porto Recebe Hoje O Benfica Nos ‘quartos’
--------------------------------------------------------------

 ![Taça de Portugal: FC Porto recebe hoje o Benfica nos ‘quartos’](https://news.vsports.pt/wp-content/uploads/2026/01/fcp_slb_samu_antoniosilva_051025_1920.jpg) <small>vsports.pt</small>Taça de Portugal: FC Porto recebe hoje o Benfica nos ‘quartos’

Benfica X Porto Ao Vivo: Onde Assistir E Horário
------------------------------------------------

 ![Benfica x Porto ao vivo: onde assistir e horário](https://www.365scores.com/pt-br/news/magazine/wp-content/uploads/2026/01/porto-benfica.jpg) <small>www.365scores.com</small>Benfica x Porto ao vivo: onde assistir e horário

Visão | Benfica E FC Porto Na Abertura Da Jornada Em Jogo Com 'vista' Para O Título
-----------------------------------------------------------------------------------

 ![Visão | Benfica e FC Porto na abertura da jornada em jogo com 'vista' para o título](https://images.trustinnews.pt/uploads/sites/5/2023/04/39698673-1600x1067.jpg) <small>visao.pt</small>Visão | Benfica e FC Porto na abertura da jornada em jogo com 'vista' para o título

ASSISTIR BENFICA X FC PORTO EM DIRECTO HOJE 09/08 ONLINE: Onde Vai Passar O JOGO DO BENFICA Hoje
------------------------------------------------------------------------------------------------

 ![ASSISTIR BENFICA X FC PORTO EM DIRECTO HOJE 09/08 ONLINE: onde vai passar o JOGO DO BENFICA hoje](https://imagens.ne10.uol.com.br/veiculos/_midias/jpg/2023/07/21/806x444/1_di_maria_benfica_afp_04-23560947.jpg?20231108025743) <small>jc.uol.com.br</small>ASSISTIR BENFICA X FC PORTO EM DIRECTO HOJE 09/08 ONLINE: onde vai passar o JOGO DO BENFICA hoje ...

Highlights | Resumo: FC Porto 0-1 Benfica (Liga 22/23 #10) - YouTube
--------------------------------------------------------------------

 ![Highlights | Resumo: FC Porto 0-1 Benfica (Liga 22/23 #10) - YouTube](https://i.ytimg.com/vi/B582I1pIOe8/maxresdefault.jpg) <small>www.youtube.com</small>Highlights | Resumo: FC Porto 0-1 Benfica (Liga 22/23 #10) - YouTube

Porto X Benfica: Clássico Decisivo Na Taça De Portugal
------------------------------------------------------

 ![Porto x Benfica: Clássico Decisivo na Taça de Portugal](https://media.assettype.com/dn/2026-01-13/cv1s5c09/porto-benfica.webp?w=1200&ar=40:21&auto=format%2Ccompress&ogImage=true&mode=crop&enlarge=true&overlay=false&overlay_position=bottom&overlay_width=100) <small>www.dn.pt</small>Porto x Benfica: Clássico Decisivo na Taça de Portugal

Onde E Como Ver O Porto - Benfica Para A Liga Portugal Betclic | TechBit
------------------------------------------------------------------------

 ![Onde e como ver o Porto - Benfica para a Liga Portugal Betclic | TechBit](https://techbit.pt/wp-content/uploads/2025/10/porto-benfica.webp) <small>techbit.pt</small>Onde e como ver o Porto - Benfica para a Liga Portugal Betclic | TechBit

FC Porto - Benfica Em Direto Na Sport TV1
-----------------------------------------

 ![FC Porto - Benfica em direto na Sport TV1](https://www.atelevisao.com/wp-content/uploads/2020/02/portovsbenfica.jpg) <small>www.atelevisao.com</small>FC Porto - Benfica em direto na Sport TV1

Benfica 🆚 Porto | Águia Supera Dragão Com Decisão De Di María | GoalPoint
-------------------------------------------------------------------------

 ![Benfica 🆚 Porto | Águia supera dragão com decisão de Di María | GoalPoint](https://goalpoint.pt/wp-content/uploads/2023/09/GoalPoint-Benfica-Porto-Primeira-Liga-202324.jpg) <small>goalpoint.pt</small>Benfica 🆚 Porto | Águia supera dragão com decisão de Di María | GoalPoint

Onde Vai Passar O Jogo Do Benfica X Porto Hoje Ao Vivo (07/04/23)
-----------------------------------------------------------------

 ![Onde vai passar o jogo do Benfica x Porto hoje ao vivo (07/04/23)](https://www.dci.com.br/wp-content/uploads/2023/04/jogo-do-benfica-1130x580.jpg) <small>www.dci.com.br</small>Onde vai passar o jogo do Benfica x Porto hoje ao vivo (07/04/23)

Porto X Benfica Na Taça De Portugal: Onde Assistir Ao Vivo, Horário E Escalação - Estadão
-----------------------------------------------------------------------------------------

 ![Porto x Benfica na Taça de Portugal: onde assistir ao vivo, horário e escalação - Estadão](https://www.estadao.com.br/resizer/v2/DYEIIT6VD5BTRB6RU6JDNSTUKU.jpeg?quality=80&auth=ca806e8867ac119d2a607f145c2fc3fa20d5c3d5088152cd15ffa479572f6673&width=1200) <small>www.estadao.com.br</small>Porto x Benfica na Taça de Portugal: onde assistir ao vivo, horário e escalação - Estadão

Já Há Data Para O Clássico Entre Benfica E FC Porto - SIC Notícias
------------------------------------------------------------------

 ![Já há data para o clássico entre Benfica e FC Porto - SIC Notícias](https://images.impresa.pt/sicnot/2024-03-01-benfica-fc-porto-91d65d4d-1/original) <small>sicnoticias.pt</small>Já há data para o clássico entre Benfica e FC Porto - SIC Notícias

Di María: «Hoje Voltámos A Ser O Benfica, Já Merecíamos» - CNN Portugal
-----------------------------------------------------------------------

 ![Di María: «Hoje voltámos a ser o Benfica, já merecíamos» - CNN Portugal](https://img.iol.pt/image/id/673130fdd34ea1acf270767e/1024.jpg) <small>cnnportugal.iol.pt</small>Di María: «Hoje voltámos a ser o Benfica, já merecíamos» - CNN Portugal

Porto X Benfica Hoje (14/1): Onde Assistir Ao Vivo, Horário E Escalações Da Taça De Portugal
--------------------------------------------------------------------------------------------

 ![Porto x Benfica hoje (14/1): onde assistir ao vivo, horário e escalações da Taça de Portugal](https://imagens.ne10.uol.com.br/veiculos/_midias/png/2026/01/14/blog_do_torcedor___site__7_-36341043.png?6967a0050ea2d) <small>jc.uol.com.br</small>Porto x Benfica hoje (14/1): onde assistir ao vivo, horário e escalações da Taça de Portugal

Transmissão Em Directo De Benfica X Porto: Vai Dar Em Sinal Aberto? Saiba Onde Assistir Ao Vivo
-----------------------------------------------------------------------------------------------

 ![Transmissão em directo de Benfica x Porto: Vai dar em sinal aberto? Saiba onde assistir ao vivo](https://imagens.ne10.uol.com.br/veiculos/_midias/jpg/2023/09/28/benfica_e_porto_fizeram_a_final_da_supertaca_de_portugal_23_24-24443779.jpg?20230930163821) <small>interior.ne10.uol.com.br</small>Transmissão em directo de Benfica x Porto: Vai dar em sinal aberto? Saiba onde assistir ao vivo

Já há data para o clássico entre benfica e fc porto. Transmissão em directo de benfica x porto: vai dar em sinal aberto? saiba onde assistir ao vivo. Onde assistir porto x benfica hoje: canal, horário e escalações
