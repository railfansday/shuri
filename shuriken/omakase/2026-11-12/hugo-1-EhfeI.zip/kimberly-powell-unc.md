---
title: "Kimberly Powell Unc - Ai and digital biology: unlocking the future of drug discovery with kimberly powell"
description: "Exclusive interview with kimberly powell, vp and general manager of nvidia healthcare"
date: "2026-05-23"
categories:
- "Uncategorized"
images:
- "https://i1.rgstatic.net/ii/profile.image/548708995813376-1507833827958_Q128/Kimberly-Powell-5.jpg"
featuredImage: "https://i.ytimg.com/vi/yeCmKq8aOY0/maxresdefault.jpg"
featured_image: "https://communications.uoregon.edu/sites/default/files/styles/portrait_small/public/2025-02/kimberly-powell-2024.jpeg?h=29deb883&amp;itok=4JTZ-NeY"
image: "https://consumidormoderno.com.br/wp-content/uploads/2025/03/Nvidia_Kimberly-Powell-1024x530.webp"
---

If you are looking for Board of Directors — Basic Needs Inc. you've visit to the right web. We have 35 Pics about Board of Directors — Basic Needs Inc. like Kimberly Powell - Nurse Practitioner | LinkedIn, Kimberly Powell - Student Services Specialist for the Mechanical, Aeronautical &amp; Astronautical and also Kimberly Becomes a UNC Cheerleader for a Day! - YouTube. Here you go:

Board Of Directors — Basic Needs Inc.
-------------------------------------

 ![Board of Directors — Basic Needs Inc.](https://images.squarespace-cdn.com/content/v1/63d48a2e85aa7959f69d2f27/58712eb8-621f-4cbe-b73b-a7e4fbbc934a/Powell_Kim+2005.jpg) <small>www.basicneedsmn.org</small>Board of Directors — Basic Needs Inc.

Kimberly Powell - Nurse Practitioner | LinkedIn
-----------------------------------------------

 ![Kimberly Powell - Nurse Practitioner | LinkedIn](https://media.licdn.com/dms/image/v2/C5603AQF0MDdb46gYPA/profile-displayphoto-shrink_200_200/profile-displayphoto-shrink_200_200/0/1517816306842?e=2147483647&v=beta&t=jV3KuSUolnoDYE7NcPw8Ai65M953Zx3u7Dib_Rw9PRk) <small>www.linkedin.com</small>Kimberly Powell - Nurse Practitioner | LinkedIn

Staff Directory | University Communications
-------------------------------------------

 ![Staff Directory | University Communications](https://communications.uoregon.edu/sites/default/files/styles/portrait_small/public/2025-02/kimberly-powell-2024.jpeg?h=29deb883&itok=4JTZ-NeY) <small>communications.uoregon.edu</small>Staff Directory | University Communications

NVIDIA: A Nova Fronteira Da Medicina Está Na IA - CM
----------------------------------------------------

 ![NVIDIA: A nova fronteira da Medicina está na IA - CM](https://consumidormoderno.com.br/wp-content/uploads/2025/03/Nvidia_Kimberly-Powell-1024x530.webp) <small>consumidormoderno.com.br</small>NVIDIA: A nova fronteira da Medicina está na IA - CM

Initiative Leads | Divisions | PPMH - Program For Precision Medicine In Health Care
-----------------------------------------------------------------------------------

 ![Initiative Leads | Divisions | PPMH - Program for Precision Medicine in Health Care](https://www.med.unc.edu/ppmh/wp-content/uploads/sites/1356/2019/08/SPowell-678x1024.jpg) <small>www.med.unc.edu</small>Initiative Leads | Divisions | PPMH - Program for Precision Medicine in Health Care

Nvidia Aims To Bring Imaging AI To The People With Clara | AuntMinnie
---------------------------------------------------------------------

 ![Nvidia aims to bring imaging AI to the people with Clara | AuntMinnie](https://img.auntminnie.com/files/base/smg/all/image/2018/04/am.2018_04_10_20_01_4331_Powell_Kimberly_400.png?auto=format%2Ccompress&fit=max&q=70&w=400) <small>www.auntminnie.com</small>Nvidia aims to bring imaging AI to the people with Clara | AuntMinnie

Veteran Success Team | Military &amp; Veterans | Belmont University
-------------------------------------------------------------------

 ![Veteran Success Team | Military & Veterans | Belmont University](https://www.belmont.edu/profiles/kim-powell/_images/kim-powell.jpg) <small>www.belmont.edu</small>Veteran Success Team | Military &amp; Veterans | Belmont University

Message From The Nutrition Sciences Chair | North Carolina Central University
-----------------------------------------------------------------------------

 ![Message from the Nutrition Sciences Chair | North Carolina Central University](https://www.nccu.edu/sites/default/files/inline-images/kpowel34_0.jpg) <small>www.nccu.edu</small>Message from the Nutrition Sciences Chair | North Carolina Central University

Kimberly POWELL | Assistant Professor | PhD, RN | University Of Tennessee, TN | UTK | College Of
------------------------------------------------------------------------------------------------

 ![Kimberly POWELL | Assistant Professor | PhD, RN | University of Tennessee, TN | UTK | College of](https://i1.rgstatic.net/ii/profile.image/548708995813376-1507833827958_Q128/Kimberly-Powell-5.jpg) <small>www.researchgate.net</small>Kimberly POWELL | Assistant Professor | PhD, RN | University of Tennessee, TN | UTK | College of ...

GTC 2025 – Announcements And Live Updates | NVIDIA Blog
-------------------------------------------------------

 ![GTC 2025 – Announcements and Live Updates | NVIDIA Blog](https://blogs.nvidia.com/wp-content/uploads/2025/03/kptalk-1280x960.jpg) <small>blogs.nvidia.com</small>GTC 2025 – Announcements and Live Updates | NVIDIA Blog

Kimberly K. Powell, Ph.D. On LinkedIn: Thank You To The SU College Of Business For Featuring Me
-----------------------------------------------------------------------------------------------

 ![Kimberly K. Powell, Ph.D. on LinkedIn: Thank you to the SU College of Business for featuring me](https://media.licdn.com/dms/image/v2/D5622AQF0d2UY14WaiA/feedshare-shrink_2048_1536/feedshare-shrink_2048_1536/0/1723502745598?e=2147483647&v=beta&t=KD43SX5s_1-aRl-n1LW8jTWuTKolhMcTEii0tAm8KLA) <small>www.linkedin.com</small>Kimberly K. Powell, Ph.D. on LinkedIn: Thank you to the SU College of Business for featuring me ...

Kimberly Powell - Professor And Departmental Director Of Graduate Studies, Dept. Of Curriculum
----------------------------------------------------------------------------------------------

 ![Kimberly Powell - Professor and Departmental Director of Graduate Studies, Dept. of Curriculum](https://media.licdn.com/dms/image/v2/D4D03AQF3OxaIK34r3w/profile-displayphoto-shrink_200_200/B4DZPfunFUHMAc-/0/1734625358507?e=2147483647&v=beta&t=lC2VsRDV2HSE-yqm67nb6-slvK7V7Lgmbxt4edCDm1s) <small>www.linkedin.com</small>Kimberly Powell - Professor and Departmental Director of Graduate Studies, Dept. of Curriculum ...

Kimberly Powell - Asheville, North Carolina, United States | Professional Profile | LinkedIn
--------------------------------------------------------------------------------------------

 ![kimberly powell - Asheville, North Carolina, United States | Professional Profile | LinkedIn](https://media.licdn.com/dms/image/v2/D4E03AQGvxmB64uOPOw/profile-displayphoto-shrink_200_200/profile-displayphoto-shrink_200_200/0/1716276069681?e=2147483647&v=beta&t=4QhCnZ9JnsekyLYF2YIuVUiVA9T-DDyLgXwqxVViW20) <small>www.linkedin.com</small>kimberly powell - Asheville, North Carolina, United States | Professional Profile | LinkedIn

Home - Cell X Technologies
--------------------------

 ![Home - Cell X Technologies](https://cellxtechnologies.com/wp-content/uploads/2023/09/Image_Kimberly-Powell.jpg) <small>cellxtechnologies.com</small>Home - Cell X Technologies

Kimberly Powell - Vendor Manager Cricket Wireless #2021 MDP Graduate | LinkedIn
-------------------------------------------------------------------------------

 ![Kimberly Powell - Vendor Manager Cricket Wireless #2021 MDP Graduate | LinkedIn](https://media.licdn.com/dms/image/v2/C4D03AQEM8l-ceokP0g/profile-displayphoto-shrink_200_200/profile-displayphoto-shrink_200_200/0/1625234025357?e=2147483647&v=beta&t=FuM28YyHq69kyelqA8VrlUBAzsIs_5-tUWK4wvpxp_4) <small>www.linkedin.com</small>Kimberly Powell - Vendor Manager Cricket Wireless #2021 MDP Graduate | LinkedIn

Kimberly Chess-Powell - Customer Relationship Manager At Bank Of America | LinkedIn
-----------------------------------------------------------------------------------

 ![Kimberly Chess-Powell - Customer Relationship Manager at Bank of America | LinkedIn](https://media.licdn.com/dms/image/v2/C5103AQGUaQ4c2CYrTQ/profile-displayphoto-shrink_200_200/profile-displayphoto-shrink_200_200/0/1517406638807?e=2147483647&v=beta&t=dZjzWdWtPZCod6mPzDoFOHb92Z6HU5y5ouDDEtvHI1A) <small>www.linkedin.com</small>Kimberly Chess-Powell - Customer Relationship Manager at Bank of America | LinkedIn

AI And Digital Biology: Unlocking The Future Of Drug Discovery With Kimberly Powell | WIRED
-------------------------------------------------------------------------------------------

 ![AI and digital biology: Unlocking the future of drug discovery with Kimberly Powell | WIRED](https://i.ytimg.com/vi/yeCmKq8aOY0/maxresdefault.jpg) <small>www.youtube.com</small>AI and digital biology: Unlocking the future of drug discovery with Kimberly Powell | WIRED ...

About Us
--------

 ![About Us](https://img1.wsimg.com/isteam/ip/44d8c6eb-5847-48e2-aff5-373d62931250/blob.png/:/cr=t:0%25,l:0%25,w:100%25,h:67.46%25/rs=w:365,h:365,cg:true) <small>757wecare.org</small>About Us

Kimberly Powell - Student Services Specialist For The Mechanical, Aeronautical &amp; Astronautical
--------------------------------------------------------------------------------------------------

 ![Kimberly Powell - Student Services Specialist for the Mechanical, Aeronautical & Astronautical](https://media.licdn.com/dms/image/v2/D5603AQHG7P7fwrwt1g/profile-displayphoto-shrink_200_200/profile-displayphoto-shrink_200_200/0/1729514339987?e=2147483647&v=beta&t=618YQWbHvXVuH9AxmfnxTKy8myI4emyzsY9P7_amtBs) <small>www.linkedin.com</small>Kimberly Powell - Student Services Specialist for the Mechanical, Aeronautical &amp; Astronautical ...

From The Office To The Lab, Amgen Uses AI Tools To Unlock Innovation | Amgen
----------------------------------------------------------------------------

 ![From the Office to the Lab, Amgen Uses AI Tools to Unlock Innovation | Amgen](https://www.amgen.com/stories/2024/05/-/media/Themes/CorporateAffairs/amgen-com/amgen-com/Images/stories/2024/05-21-From-the-Office-to-the-Lab-Amgen-Uses-AI-Tools-to-Unlock-Innovation/powell.png) <small>www.amgen.com</small>From the Office to the Lab, Amgen Uses AI Tools to Unlock Innovation | Amgen

Nvidia's Kimberly Powell Is Leading The Chip Giant's Charge Into AI For Health Care - San
-----------------------------------------------------------------------------------------

 ![Nvidia's Kimberly Powell is leading the chip giant's charge into AI for health care - San](https://media.bizj.us/view/img/12968502/kimberlypowell-1*1200xx9428-5303-0-491.jpg) <small>www.bizjournals.com</small>Nvidia's Kimberly Powell is leading the chip giant's charge into AI for health care - San ...

Kimberly Powell On LinkedIn: Had A Fantastic Time Hosting The PowerUp Strategic Educators
-----------------------------------------------------------------------------------------

 ![Kimberly Powell on LinkedIn: Had a fantastic time hosting the PowerUp Strategic Educators](https://media.licdn.com/dms/image/D5622AQEBItJYa-ypGw/feedshare-shrink_800/0/1708957758233?e=2147483647&v=beta&t=xMzVZhCGZYMoNSETCR7it3dpNlrrkZKiht8hIB45sdI) <small>www.linkedin.com</small>Kimberly Powell on LinkedIn: Had a fantastic time hosting the PowerUp Strategic Educators ...

Kimberly Becomes A UNC Cheerleader For A Day! - YouTube
-------------------------------------------------------

 ![Kimberly Becomes a UNC Cheerleader for a Day! - YouTube](https://i.ytimg.com/vi/7mT-mnUnd3E/maxresdefault.jpg) <small>www.youtube.com</small>Kimberly Becomes a UNC Cheerleader for a Day! - YouTube

Kimberly Powell - College Of Arts &amp; Architecture
----------------------------------------------------

 ![Kimberly Powell - College of Arts & Architecture](https://arts.psu.edu/assets/uploads/directoryImages/_480x480_crop_center-center_80_none/screen_shot.jpg) <small>arts.psu.edu</small>Kimberly Powell - College of Arts &amp; Architecture

UNC Asheville Chancellor Kimberly Van Noort's Installation Ceremony
-------------------------------------------------------------------

 ![UNC Asheville Chancellor Kimberly van Noort's installation ceremony](https://www.citizen-times.com/gcdn/authoring/authoring-images/2025/04/26/PASH/83300905007-0425-unca-15.jpg?width=660&height=400&fit=crop&format=pjpg&auto=webp) <small>www.citizen-times.com</small>UNC Asheville Chancellor Kimberly van Noort's installation ceremony

Kimberly Powell On LinkedIn: #speakupsisawards2024 #susawards2024 #susawardsfinalist2024 #voteforme
---------------------------------------------------------------------------------------------------

 ![Kimberly Powell on LinkedIn: #speakupsisawards2024 #susawards2024 #susawardsfinalist2024 #voteforme](https://media.licdn.com/dms/image/D4D22AQHnpcTAQwDtzg/feedshare-shrink_2048_1536/0/1710527087105?e=2147483647&v=beta&t=ABcsxN8h4u0sB8mJDrZKm9poz4E6UKa_kzE8Y0XAmbE) <small>www.linkedin.com</small>Kimberly Powell on LinkedIn: #speakupsisawards2024 #susawards2024 #susawardsfinalist2024 #voteforme

Kimberly Powell Honored For Pioneering Work In Health Informatics And Gerontology
---------------------------------------------------------------------------------

 ![Kimberly Powell honored for pioneering work in health informatics and gerontology](https://nursing.missouri.edu/wp-content/uploads/2024/06/Kimberly-Powell-FAMIA-induction-1024x1024.png) <small>nursing.missouri.edu</small>Kimberly Powell honored for pioneering work in health informatics and gerontology

Kimberly Powell Honored For Pioneering Work In Health Informatics And Gerontology
---------------------------------------------------------------------------------

 ![Kimberly Powell honored for pioneering work in health informatics and gerontology](https://nursing.missouri.edu/wp-content/uploads/2024/05/Congratulations.png) <small>nursing.missouri.edu</small>Kimberly Powell honored for pioneering work in health informatics and gerontology

Exclusive Interview With Kimberly Powell, VP And General Manager Of NVIDIA Healthcare - MarkTechPost
----------------------------------------------------------------------------------------------------

 ![Exclusive Interview with Kimberly Powell, VP and General Manager of NVIDIA Healthcare - MarkTechPost](https://www.marktechpost.com/wp-content/uploads/2022/04/Interview-2.png) <small>www.marktechpost.com</small>Exclusive Interview with Kimberly Powell, VP and General Manager of NVIDIA Healthcare - MarkTechPost

Kimberly Powell - Keynote - Ohio Genealogical Society
-----------------------------------------------------

 ![Kimberly Powell - Keynote - Ohio Genealogical Society](https://www.ogs.org/wp-content/uploads/2026/02/Powell-Kimberly-2.png) <small>www.ogs.org</small>Kimberly Powell - Keynote - Ohio Genealogical Society

Kimberly Powell On LinkedIn: #womenwholead #mentorship #success #thepurpledoorwellnesshouse…
--------------------------------------------------------------------------------------------

 ![Kimberly Powell on LinkedIn: #womenwholead #mentorship #success #thepurpledoorwellnesshouse…](https://media.licdn.com/dms/image/D4E22AQFEXBAgYvTBYg/feedshare-shrink_2048_1536/0/1716164335026?e=2147483647&v=beta&t=wOCsAhyrEMQHVUnhTT1IhqfJ_a6E7rx2TyyA5C6T2nQ) <small>www.linkedin.com</small>Kimberly Powell on LinkedIn: #womenwholead #mentorship #success #thepurpledoorwellnesshouse…

Faculty Staff | College Of Medicine
-----------------------------------

 ![Faculty Staff | College of Medicine](https://public.med.fsu.edu/images/Faculty/Kimberly.Powell.jpg) <small>public.med.fsu.edu</small>Faculty Staff | College of Medicine

Kimberly Powell Inducted As Fellow Of The American Medical Informatics Association, Announced As
------------------------------------------------------------------------------------------------

 ![Kimberly Powell inducted as Fellow of the American Medical Informatics Association, announced as](https://showme.missouri.edu/wp-content/uploads/2024/06/071124_PowellFeature-940x529.jpg) <small>showme.missouri.edu</small>Kimberly Powell inducted as Fellow of the American Medical Informatics Association, announced as ...

Kimberly Powell - Speech Language Pathologist | LinkedIn
--------------------------------------------------------

 ![Kimberly Powell - Speech Language Pathologist | LinkedIn](https://media.licdn.com/dms/image/v2/C4E03AQGad6PJpLEGrA/profile-displayphoto-shrink_200_200/profile-displayphoto-shrink_200_200/0/1517616680748?e=2147483647&v=beta&t=0kIdF8R4KSg9kR0lU-baZL1JAARdnS570j_qCD7FsDA) <small>www.linkedin.com</small>Kimberly Powell - Speech Language Pathologist | LinkedIn

Generative AI Is Revolutionizing Healthcare, From Drug Discovery To Diagnostics And Post-op Care
------------------------------------------------------------------------------------------------

 ![Generative AI is revolutionizing healthcare, from drug discovery to diagnostics and post-op care](https://media.licdn.com/dms/image/v2/D4D22AQHI7fbK1GV1QQ/feedshare-shrink_2048_1536/feedshare-shrink_2048_1536/0/1717762363344?e=2147483647&v=beta&t=HcXrmL3078ePC82LlnhipxGpfpS2lI088q7m0yCHQ0I) <small>pe.linkedin.com</small>Generative AI is revolutionizing healthcare, from drug discovery to diagnostics and post-op care ...

Faculty staff. Gtc 2025 – announcements and live updates. kimberly powell
