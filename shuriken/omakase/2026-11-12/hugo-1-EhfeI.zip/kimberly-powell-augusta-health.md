---
title: "Kimberly Powell Augusta Health - Nvidia sees major shift in radiology to ai agents and new autonomous imaging systems"
description: "Funding secured for augusta health neighborhood clinic mobile medical unit"
date: "2026-06-10"
categories:
- "Uncategorized"
images:
- "https://www.goldsboronc.gov/wp-content/uploads/kim-pic.png"
featuredImage: "https://lookaside.fbsbx.com/lookaside/crawler/media/?media_id=1150262653938099"
featured_image: "https://media.licdn.com/dms/image/D4E22AQFEXBAgYvTBYg/feedshare-shrink_2048_1536/0/1716164335026?e=2147483647&amp;v=beta&amp;t=wOCsAhyrEMQHVUnhTT1IhqfJ_a6E7rx2TyyA5C6T2nQ"
image: "https://showme.missouri.edu/wp-content/uploads/2024/06/internet-usage-4x5-2-scaled.jpg"
---

If you are searching about What Can Health Care Learn from Self-Driving Cars? | Johns Hopkins Medicine you've visit to the right page. We have 33 Images about What Can Health Care Learn from Self-Driving Cars? | Johns Hopkins Medicine like Kimberly Powell - Augusta Health, Augusta Health | Fishersville VA and also Kimberly Powell Special Address - Healthcare at GTC | Channah Blocq. Read more:

What Can Health Care Learn From Self-Driving Cars? | Johns Hopkins Medicine
---------------------------------------------------------------------------

 ![What Can Health Care Learn from Self-Driving Cars? | Johns Hopkins Medicine](https://www.hopkinsmedicine.org/-/media/images/articles/2018/03/kimberly_powell.jpeg?h=640&iar=0&w=640&hash=1741F5E78A512573722D6BEAB32D9288) <small>www.hopkinsmedicine.org</small>What Can Health Care Learn from Self-Driving Cars? | Johns Hopkins Medicine

Kimberly Powell Special Address - Healthcare At GTC | Channah Blocq
-------------------------------------------------------------------

 ![Kimberly Powell Special Address - Healthcare at GTC | Channah Blocq](https://media.licdn.com/dms/image/v2/D4E10AQEoQkQL3_Sr8w/image-shrink_1280/image-shrink_1280/0/1707382180957?e=2147483647&v=beta&t=0dqql3MYC7lUbb88BTFqqiIbvIz3Tb1NcqvpEZkm5PY) <small>www.linkedin.com</small>Kimberly Powell Special Address - Healthcare at GTC | Channah Blocq

Kimberly Dawn Powell, FNP-BC - Florence, SC
-------------------------------------------

 ![Kimberly Dawn Powell, FNP-BC - Florence, SC](https://www.getcare.muschealth.org/images/width=194,height=248,fit=cover/https://a.mktgcdn.com/p/Ez16s5P3XprqNrtCfEAQn285khdOdYy9xSWV3OGo-lY/1500x1793.jpg) <small>www.getcare.muschealth.org</small>Kimberly Dawn Powell, FNP-BC - Florence, SC

Exclusive Interview With Kimberly Powell, VP And General Manager Of NVIDIA Healthcare - MarkTechPost
----------------------------------------------------------------------------------------------------

 ![Exclusive Interview with Kimberly Powell, VP and General Manager of NVIDIA Healthcare - MarkTechPost](https://www.marktechpost.com/wp-content/uploads/2022/04/Interview-2.png) <small>www.marktechpost.com</small>Exclusive Interview with Kimberly Powell, VP and General Manager of NVIDIA Healthcare - MarkTechPost

Kimberly Powell - PhD, RN, FAMIA, FAAN | LinkedIn
-------------------------------------------------

 ![Kimberly Powell - PhD, RN, FAMIA, FAAN | LinkedIn](https://media.licdn.com/dms/image/v2/D4E03AQELNZTNqlomtw/profile-displayphoto-scale_200_200/B4EZiemXJLHoAY-/0/1755007513927?e=2147483647&v=beta&t=9aVHNfS1ADg7fyk_hbUBaCziZDNeQpkjMX0xwrnhkTQ) <small>www.linkedin.com</small>Kimberly Powell - PhD, RN, FAMIA, FAAN | LinkedIn

Kimberly Powell On LinkedIn: Had A Fantastic Time Hosting The PowerUp Strategic Educators
-----------------------------------------------------------------------------------------

 ![Kimberly Powell on LinkedIn: Had a fantastic time hosting the PowerUp Strategic Educators](https://media.licdn.com/dms/image/D5622AQEBItJYa-ypGw/feedshare-shrink_800/0/1708957758233?e=2147483647&v=beta&t=xMzVZhCGZYMoNSETCR7it3dpNlrrkZKiht8hIB45sdI) <small>www.linkedin.com</small>Kimberly Powell on LinkedIn: Had a fantastic time hosting the PowerUp Strategic Educators ...

Generative AI Is Revolutionizing Healthcare, From Drug Discovery To Diagnostics And Post-op Care
------------------------------------------------------------------------------------------------

 ![Generative AI is revolutionizing healthcare, from drug discovery to diagnostics and post-op care](https://media.licdn.com/dms/image/v2/D4D22AQHI7fbK1GV1QQ/feedshare-shrink_2048_1536/feedshare-shrink_2048_1536/0/1717762363344?e=2147483647&v=beta&t=HcXrmL3078ePC82LlnhipxGpfpS2lI088q7m0yCHQ0I) <small>pe.linkedin.com</small>Generative AI is revolutionizing healthcare, from drug discovery to diagnostics and post-op care ...

Hospice Team - Augusta Health
-----------------------------

 ![Hospice Team - Augusta Health](https://www.augustahealth.com/wp-content/uploads/2022/12/Kim-Lowery-scaled.jpg) <small>www.augustahealth.com</small>Hospice Team - Augusta Health

Kimberly Powell - Augusta Health
--------------------------------

 ![Kimberly Powell - Augusta Health](https://www.augustahealth.com/wp-content/uploads/2023/04/Kim-Powell-2-scaled.jpg) <small>www.augustahealth.com</small>Kimberly Powell - Augusta Health

Employee Health And Wellness – City Of Goldsboro
------------------------------------------------

 ![Employee Health and Wellness – City of Goldsboro](https://www.goldsboronc.gov/wp-content/uploads/kim-pic.png) <small>www.goldsboronc.gov</small>Employee Health and Wellness – City of Goldsboro

We're Here! The Indiana Black Expo! Hall H, Booth 1447! Come Visit Us! | Kimberly Powell
----------------------------------------------------------------------------------------

 ![We're here! The Indiana Black Expo! Hall H, booth 1447! Come visit us! | Kimberly Powell](https://media.licdn.com/dms/image/v2/D5622AQG_Iha5ZShNxQ/feedshare-shrink_2048_1536/feedshare-shrink_2048_1536/0/1689354648155?e=2147483647&v=beta&t=tO0eWpxk-SFUhmapMMCOBpe5SUV4oVhyiIhxUpW5z_k) <small>www.linkedin.com</small>We're here! The Indiana Black Expo! Hall H, booth 1447! Come visit us! | Kimberly Powell

Hospice Team - Augusta Health
-----------------------------

 ![Hospice Team - Augusta Health](https://www.augustahealth.com/wp-content/uploads/2022/12/Lindsey-Wallace-1097x1536.jpg) <small>www.augustahealth.com</small>Hospice Team - Augusta Health

Kimberly Powell Honored For Pioneering Work In Health Informatics And Gerontology
---------------------------------------------------------------------------------

 ![Kimberly Powell honored for pioneering work in health informatics and gerontology](https://nursing.missouri.edu/wp-content/uploads/2024/06/Kimberly-Powell-FAMIA-induction.png) <small>nursing.missouri.edu</small>Kimberly Powell honored for pioneering work in health informatics and gerontology

Kimberly Powell On LinkedIn: #speakupsisawards2024 #susawards2024 #susawardsfinalist2024 #voteforme
---------------------------------------------------------------------------------------------------

 ![Kimberly Powell on LinkedIn: #speakupsisawards2024 #susawards2024 #susawardsfinalist2024 #voteforme](https://media.licdn.com/dms/image/D4D22AQHnpcTAQwDtzg/feedshare-shrink_2048_1536/0/1710527087105?e=2147483647&v=beta&t=ABcsxN8h4u0sB8mJDrZKm9poz4E6UKa_kzE8Y0XAmbE) <small>www.linkedin.com</small>Kimberly Powell on LinkedIn: #speakupsisawards2024 #susawards2024 #susawardsfinalist2024 #voteforme

Augusta Health Birthing Suite - Augusta Health
----------------------------------------------

 ![Augusta Health Birthing Suite - Augusta Health](https://www.augustahealth.com/wp-content/uploads/2023/08/Kimberly-Greer-scaled.jpg) <small>www.augustahealth.com</small>Augusta Health Birthing Suite - Augusta Health

Augusta Health | Fishersville VA
--------------------------------

 ![Augusta Health | Fishersville VA](https://lookaside.fbsbx.com/lookaside/crawler/media/?media_id=1150262653938099) <small>www.facebook.com</small>Augusta Health | Fishersville VA

Staff Highlights: A Rising Star Among Us – WHSC Library News
------------------------------------------------------------

 ![Staff Highlights: A Rising Star Among Us – WHSC Library News](https://scholarblogs.emory.edu/whscl-news/files/2023/03/Kim-Powell-0121-1024x819.jpg) <small>scholarblogs.emory.edu</small>Staff Highlights: A Rising Star Among Us – WHSC Library News

From The Office To The Lab, Amgen Uses AI Tools To Unlock Innovation | Amgen
----------------------------------------------------------------------------

 ![From the Office to the Lab, Amgen Uses AI Tools to Unlock Innovation | Amgen](https://www.amgen.com/stories/2024/05/-/media/Themes/CorporateAffairs/amgen-com/amgen-com/Images/stories/2024/05-21-From-the-Office-to-the-Lab-Amgen-Uses-AI-Tools-to-Unlock-Innovation/powell.png) <small>www.amgen.com</small>From the Office to the Lab, Amgen Uses AI Tools to Unlock Innovation | Amgen

Kimberly Powell On LinkedIn: #womenwholead #mentorship #success #thepurpledoorwellnesshouse…
--------------------------------------------------------------------------------------------

 ![Kimberly Powell on LinkedIn: #womenwholead #mentorship #success #thepurpledoorwellnesshouse…](https://media.licdn.com/dms/image/D4E22AQFEXBAgYvTBYg/feedshare-shrink_2048_1536/0/1716164335026?e=2147483647&v=beta&t=wOCsAhyrEMQHVUnhTT1IhqfJ_a6E7rx2TyyA5C6T2nQ) <small>www.linkedin.com</small>Kimberly Powell on LinkedIn: #womenwholead #mentorship #success #thepurpledoorwellnesshouse…

Nvidia Looks To Genentech For Its Next Leap In AI Drug Discovery
----------------------------------------------------------------

 ![Nvidia Looks to Genentech for Its Next Leap in AI Drug Discovery](https://www.genengnews.com/wp-content/uploads/2023/11/Kimberly-Powell-NVIDIA-CROPPED11111.jpg) <small>www.genengnews.com</small>Nvidia Looks to Genentech for Its Next Leap in AI Drug Discovery

AI And Digital Biology: Unlocking The Future Of Drug Discovery With Kimberly Powell | WIRED
-------------------------------------------------------------------------------------------

 ![AI and digital biology: Unlocking the future of drug discovery with Kimberly Powell | WIRED](https://i.ytimg.com/vi/yeCmKq8aOY0/maxresdefault.jpg) <small>www.youtube.com</small>AI and digital biology: Unlocking the future of drug discovery with Kimberly Powell | WIRED ...

Mental Health First Aid (MHFA)
------------------------------

 ![Mental Health First Aid (MHFA)](https://www.augusta.edu/ahec/images/williams.kimberly.jpeg) <small>www.augusta.edu</small>Mental Health First Aid (MHFA)

Funding Secured For Augusta Health Neighborhood Clinic Mobile Medical Unit - Augusta Health
-------------------------------------------------------------------------------------------

 ![Funding Secured for Augusta Health Neighborhood Clinic Mobile Medical Unit - Augusta Health](https://www.augustahealth.com/wp-content/uploads/2025/03/Powell-630x1024.png) <small>www.augustahealth.com</small>Funding Secured for Augusta Health Neighborhood Clinic Mobile Medical Unit - Augusta Health

Nvidia Sees Major Shift In Radiology To AI Agents And New Autonomous Imaging Systems
------------------------------------------------------------------------------------

 ![Nvidia sees major shift in radiology to AI agents and new autonomous imaging systems](https://radiologybusiness.com/sites/default/files/styles/facebook/public/2025-12/kimberly_powell_explains_impact_of_nvidia_on_radiology_ai_across_the_rsna_expo_floor.jpg?h=8d346626&itok=ge9CtIQY) <small>radiologybusiness.com</small>Nvidia sees major shift in radiology to AI agents and new autonomous imaging systems

Kimberly Powell - Clinic Manager - MultiCare Health System | LinkedIn
---------------------------------------------------------------------

 ![Kimberly Powell - Clinic Manager - MultiCare Health System | LinkedIn](https://media.licdn.com/dms/image/C5603AQG7MpUq0T4ubw/profile-displayphoto-shrink_200_200/0/1553727787738?e=2147483647&v=beta&t=EgYVmO5tcnfLXaq3BFoGTL0xbbv0Dp9diHjYBEhFewI) <small>www.linkedin.com</small>Kimberly Powell - Clinic Manager - MultiCare Health System | LinkedIn

Family Medicine Doctors Near Me In Northglenn, CO
-------------------------------------------------

 ![Family Medicine Doctors near me in Northglenn, CO](https://doximity-res.cloudinary.com/images/f_auto,q_auto,t_public_profile_photo_320x320/vyzwfcajlry7r3bvtqlw/kim-powell-denver-co.jpg) <small>health.usnews.com</small>Family Medicine Doctors near me in Northglenn, CO

NVIDIA: A Nova Fronteira Da Medicina Está Na IA - CM
----------------------------------------------------

 ![NVIDIA: A nova fronteira da Medicina está na IA - CM](https://consumidormoderno.com.br/wp-content/uploads/2025/03/Nvidia_Kimberly-Powell-1024x530.webp) <small>consumidormoderno.com.br</small>NVIDIA: A nova fronteira da Medicina está na IA - CM

Nvidia Aims To Bring Imaging AI To The People With Clara | AuntMinnie
---------------------------------------------------------------------

 ![Nvidia aims to bring imaging AI to the people with Clara | AuntMinnie](https://img.auntminnie.com/files/base/smg/all/image/2018/04/am.2018_04_10_20_01_4331_Powell_Kimberly_400.png?auto=format%2Ccompress&fit=max&q=70&w=400) <small>www.auntminnie.com</small>Nvidia aims to bring imaging AI to the people with Clara | AuntMinnie

Kim Powell's Instagram, Twitter &amp; Facebook On IDCrawl
---------------------------------------------------------

 ![Kim Powell's Instagram, Twitter & Facebook on IDCrawl](https://www.belmont.edu/profiles/kim-powell/_images/kim-powell.jpg) <small>www.idcrawl.com</small>Kim Powell's Instagram, Twitter &amp; Facebook on IDCrawl

Kimberly Powell Inducted As Fellow Of The American Medical Informatics Association, Announced As
------------------------------------------------------------------------------------------------

 ![Kimberly Powell inducted as Fellow of the American Medical Informatics Association, announced as](https://showme.missouri.edu/wp-content/uploads/2024/06/internet-usage-4x5-2-scaled.jpg) <small>showme.missouri.edu</small>Kimberly Powell inducted as Fellow of the American Medical Informatics Association, announced as ...

Dive Into The Future Of Digital Surgery, Health, And Biology With NVIDIA's VP Of Healthcare And
-----------------------------------------------------------------------------------------------

 ![Dive into the future of digital surgery, health, and biology with NVIDIA's VP of Healthcare and](https://media.licdn.com/dms/image/v2/D5610AQEf18m9u13NPw/image-shrink_800/image-shrink_800/0/1718404075786?e=2147483647&v=beta&t=F-wL667A6hY7CE4c0fp8ufvPB6vLFAUNhCatqrC7jY4) <small>www.linkedin.com</small>Dive into the future of digital surgery, health, and biology with NVIDIA's VP of Healthcare and ...

Kimberly Powell Honored For Pioneering Work In Health Informatics And Gerontology
---------------------------------------------------------------------------------

 ![Kimberly Powell honored for pioneering work in health informatics and gerontology](https://nursing.missouri.edu/wp-content/uploads/2024/05/Congratulations.png) <small>nursing.missouri.edu</small>Kimberly Powell honored for pioneering work in health informatics and gerontology

Kimberly Powell On LinkedIn: Accelerating Generative AI In Biology And Healthcare
---------------------------------------------------------------------------------

 ![Kimberly Powell on LinkedIn: Accelerating Generative AI in Biology and Healthcare](https://media.licdn.com/dms/image/C5610AQE1cSmTeTDugg/image-shrink_800/0/1678898624805?e=2147483647&v=beta&t=L3r_MC6OMP4ctzlhbDJAPKC2RrpU2kiN4DrXxRk5xHA) <small>www.linkedin.com</small>Kimberly Powell on LinkedIn: Accelerating Generative AI in Biology and Healthcare

kimberly dawn powell, fnp-bc. Family medicine doctors near me in northglenn, co. Kimberly powell on linkedin: had a fantastic time hosting the powerup strategic educators
