---
title: "Greve Geral 2 De Outubro - 27 de outubro"
description: "Manifestantes convocam greve-geral para 2ª e pedem adesão de empresários"
date: "2026-05-19"
categories:
- "Uncategorized"
images:
- "https://www.stal.pt/images/2025/Manif_GreveGeral.jpg"
featuredImage: "https://www.jpn.up.pt/wp-content/uploads/2025/12/greve_geral6.jpg"
featured_image: "https://fne.pt/uploads/noticias/big_1666252804_9001_ID_FNE_site2.png"
image: "https://p2.trrsf.com/image/fget/cf/648/0/images.terra.com/2017/04/27/95818331e3c5a7de-1d73-435a-a64c-6edfb0c1fd11.jpg"
---

If you are looking for Greve de 2 de outubro: o que esperar do novo dia de protesto em França? you've came to the right page. We have 35 Images about Greve de 2 de outubro: o que esperar do novo dia de protesto em França? like Greve de 2 de outubro: o que esperar do novo dia de protesto em França?, Associação de pesquisadores planeja greve geral contra cortes na educação - 18/09/2019 - UOL and also Motivos da adesão à Greve Geral de 11 de dezembro de 2025. Read more:

Greve De 2 De Outubro: O Que Esperar Do Novo Dia De Protesto Em França?
-----------------------------------------------------------------------

 ![Greve de 2 de outubro: o que esperar do novo dia de protesto em França?](https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA1NGuTP.img?w=800&h=450&m=4&q=79) <small>www.msn.com</small>Greve de 2 de outubro: o que esperar do novo dia de protesto em França?

Associação De Pesquisadores Planeja Greve Geral Contra Cortes Na Educação - 18/09/2019 - UOL
--------------------------------------------------------------------------------------------

 ![Associação de pesquisadores planeja greve geral contra cortes na educação - 18/09/2019 - UOL](https://conteudo.imguol.com.br/c/noticias/17/2019/09/18/associacao-nacional-de-pos-graduandos-convoca-greve-geral-e-marcha-no-dia-2-de-outubro-1568821171710_v2_450x450.jpg) <small>educacao.uol.com.br</small>Associação de pesquisadores planeja greve geral contra cortes na educação - 18/09/2019 - UOL ...

Greve De 2 De Outubro De 2025: Perturbações Na RATP E Na SNCF Em Paris E Na Região De Île-de
--------------------------------------------------------------------------------------------

 ![Greve de 2 de outubro de 2025: perturbações na RATP e na SNCF em Paris e na região de Île-de](https://cdn.sortiraparis.com/images/80/1467/1197264-greve-du-2-octobre-transports-ratp-et-sncf.jpg) <small>www.sortiraparis.com</small>Greve de 2 de outubro de 2025: perturbações na RATP e na SNCF em Paris e na região de Île-de ...

Nouvelle Grève Du 2 Octobre : Voici Ce Qui Vous Attend
------------------------------------------------------

 ![Nouvelle grève du 2 octobre : voici ce qui vous attend](https://www.maison-travaux.fr/wp-content/uploads/sites/8/2025/09/greve-2-octobre-750x410.jpg) <small>www.maison-travaux.fr</small>Nouvelle grève du 2 octobre : voici ce qui vous attend

Greve Geral Juntou Centenas Nos Aliados. Governo Fala Em Adesão "inexpressiva" - JPN
------------------------------------------------------------------------------------

 ![Greve Geral juntou centenas nos Aliados. Governo fala em adesão "inexpressiva" - JPN](https://www.jpn.up.pt/wp-content/uploads/2025/12/greve_geral8.jpg) <small>www.jpn.up.pt</small>Greve Geral juntou centenas nos Aliados. Governo fala em adesão "inexpressiva" - JPN

Administração Pública Em Greve No Próximo Dia 24 De Outubro. - CGTP-IN
----------------------------------------------------------------------

 ![Administração Pública em greve no próximo dia 24 de Outubro. - CGTP-IN](https://cgtp.pt/images/accao-e-luta/2025/frente-comum-1.jpg) <small>www.cgtp.pt</small>Administração Pública em greve no próximo dia 24 de Outubro. - CGTP-IN

SINASEFE - Sergipe - Dias 2 E 3 De Outubro: Greve Geral Da Educação
-------------------------------------------------------------------

 ![SINASEFE - Sergipe - Dias 2 e 3 de outubro: greve geral da educação](https://www.sinasefesergipe.com.br/uploads/images/216f21b03362a05c384c69c2d51d5e87_thumb.png) <small>www.sinasefesergipe.com.br</small>SINASEFE - Sergipe - Dias 2 e 3 de outubro: greve geral da educação

Motivos Da Adesão à Greve Geral De 11 De Dezembro De 2025
---------------------------------------------------------

 ![Motivos da adesão à Greve Geral de 11 de dezembro de 2025](https://spzn.pt/uploads/noticias/big_1763717239_6728_SPZN_2025_site_novo_(17).png) <small>spzn.pt</small>Motivos da adesão à Greve Geral de 11 de dezembro de 2025

GREVE GERAL | Trabalhadores Das Autarquias E Sector Empresarial Rejeitam “pacote Laboral”
-----------------------------------------------------------------------------------------

 ![GREVE GERAL | Trabalhadores das autarquias e sector empresarial rejeitam “pacote laboral”](https://www.stal.pt/images/2025/Manif_GreveGeral.jpg) <small>www.stal.pt</small>GREVE GERAL | Trabalhadores das autarquias e sector empresarial rejeitam “pacote laboral”

Falta Uma Semana E Cada Vez Mais Apoiam Greve Geral: Qual O Impacto?
--------------------------------------------------------------------

 ![Falta uma semana e cada vez mais apoiam greve geral: Qual o impacto?](https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA215STz.img?w=768&h=432&m=6&x=193&y=425&s=717&d=119) <small>www.msn.com</small>Falta uma semana e cada vez mais apoiam greve geral: Qual o impacto?

27 De Outubro - Greve Nacional Da Administração Pública - CGTP-IN
-----------------------------------------------------------------

 ![27 de Outubro - Greve Nacional da Administração Pública - CGTP-IN](https://www.cgtp.pt/images/images/2017/10/171003_GreveFCcartazB.jpg) <small>www.cgtp.pt</small>27 de Outubro - Greve Nacional da Administração Pública - CGTP-IN

Greve Geral Juntou Centenas Nos Aliados. Governo Fala Em Adesão "inexpressiva" - JPN
------------------------------------------------------------------------------------

 ![Greve Geral juntou centenas nos Aliados. Governo fala em adesão "inexpressiva" - JPN](https://www.jpn.up.pt/wp-content/uploads/2025/12/greve_geral9.jpg) <small>www.jpn.up.pt</small>Greve Geral juntou centenas nos Aliados. Governo fala em adesão "inexpressiva" - JPN

PRÉ- AVISO DE GREVE – 23 E 24 De Outubro – AEC
----------------------------------------------

 ![PRÉ- AVISO DE GREVE – 23 e 24 de outubro – AEC](https://aeceleiros.pt/wp-content/uploads/2025/10/Greve_out2025_v1.png) <small>aeceleiros.pt</small>PRÉ- AVISO DE GREVE – 23 e 24 de outubro – AEC

Grève Du 2 Octobre : Transports, écoles, Hôpitaux… A Quelles Perturbations S’attendre
-------------------------------------------------------------------------------------

 ![Grève du 2 octobre : transports, écoles, hôpitaux… A quelles perturbations s’attendre](https://www.publicsenat.fr/app/uploads/2025/09/Greve-2-octobre-scaled.jpg) <small>www.publicsenat.fr</small>Grève du 2 octobre : transports, écoles, hôpitaux… A quelles perturbations s’attendre

SPN - 27 De Outubro De 2017 - Greve Por Um Descongelamento Justo E Sem Discriminação
------------------------------------------------------------------------------------

 ![SPN - 27 de outubro de 2017 - Greve por um descongelamento justo e sem discriminação](https://www.spn.pt/Media/Default/Info/18000/600/20/2/cartaz-GREVE_Norte.jpg) <small>www.spn.pt</small>SPN - 27 de outubro de 2017 - Greve por um descongelamento justo e sem discriminação

Greve Geral Deve Parar A França Nesta Terça; Trabalhadores Querem Reajuste Por Inflação | Mundo | G1
----------------------------------------------------------------------------------------------------

 ![Greve geral deve parar a França nesta terça; trabalhadores querem reajuste por inflação | Mundo | G1](https://s2.glbimg.com/dHKLMDY5Euu5sDqMO5OmPBjTBQ4=/1200x/smart/filters:cover():strip_icc()/i.s3.glbimg.com/v1/AUTH_59edd422c0c84a879bd37670ae4f538a/internal_photos/bs/2022/G/h/Z2ahq8R3ixaACR4a87eQ/protesto-paris.jpg) <small>g1.globo.com</small>Greve geral deve parar a França nesta terça; trabalhadores querem reajuste por inflação | Mundo | G1

Em 02 De Outubro, Vamos Aumentar A Pressão E Derrubar O Pior Presidente Da História - Sindicato
-----------------------------------------------------------------------------------------------

 ![Em 02 de outubro, vamos aumentar a pressão e derrubar o pior presidente da história - Sindicato](https://sjsp.org.br/wp-content/uploads/2023/05/210-2.jpg) <small>sjsp.org.br</small>Em 02 de outubro, vamos aumentar a pressão e derrubar o pior presidente da história - Sindicato ...

FENPROF Emite Pré-aviso De Greve Para 27 De Outubro De 2023 E Junta-se Ao Protesto Dos
--------------------------------------------------------------------------------------

 ![FENPROF emite pré-aviso de greve para 27 de outubro de 2023 e junta-se ao protesto dos](https://www.spra.pt/wp-content/uploads/2023/10/cartaz-greve-fc-27-outubro-net-1-704x1024.jpg) <small>www.spra.pt</small>FENPROF emite pré-aviso de greve para 27 de outubro de 2023 e junta-se ao protesto dos ...

Dados Recolhidos Até às 19h20 Demonstram Que A Greve Geral Parou O País - CGTP-IN
---------------------------------------------------------------------------------

 ![Dados recolhidos até às 19h20 demonstram que a Greve Geral parou o país - CGTP-IN](https://www.cgtp.pt/images/images/2025/11/gg_banner2025.jpg) <small>www.cgtp.pt</small>Dados recolhidos até às 19h20 demonstram que a Greve Geral parou o país - CGTP-IN

Greve Geral Paralisa A Grécia Contra Projeto Que Amplia Jornada Diária De Trabalho Para 13 Horas
------------------------------------------------------------------------------------------------

 ![Greve geral paralisa a Grécia contra projeto que amplia jornada diária de trabalho para 13 horas](https://p2.trrsf.com/image/fget/cf/774/0/images.terra.com/2025/10/01/255139162-ap25274355543412.jpg) <small>www.terra.com.br</small>Greve geral paralisa a Grécia contra projeto que amplia jornada diária de trabalho para 13 horas

GREVE - 2 De Novembro De 2022 - Por Um ORÇAMENTO DE ESTADO Que Valorize Educadores E Professores
------------------------------------------------------------------------------------------------

 ![GREVE - 2 de novembro de 2022 - Por um ORÇAMENTO DE ESTADO que valorize Educadores e Professores](https://www.sdpa.pt/uploads/greve_2_novembro.jpg) <small>www.sdpa.pt</small>GREVE - 2 de novembro de 2022 - Por um ORÇAMENTO DE ESTADO que valorize Educadores e Professores ...

Manifestação Em Frente Ao Parlamento Resultou Em Seis Detidos: Tudo Sobre A Greve Geral
---------------------------------------------------------------------------------------

 ![Manifestação em frente ao Parlamento resultou em seis detidos: tudo sobre a greve geral](https://cdn.sabado.pt/images/2025-12/img_1200x676uu2025-12-11-12-44-17-752810.jpg) <small>www.sabado.pt</small>Manifestação em frente ao Parlamento resultou em seis detidos: tudo sobre a greve geral ...

Greve Nacional De 2 De Dezembro: Transportes, Escolas, Aeroportos... As Informações
-----------------------------------------------------------------------------------

 ![Greve nacional de 2 de dezembro: transportes, escolas, aeroportos... as informações](https://cdn.sortiraparis.com/images/80/1467/1199124-greve-du-2-octobre-les-manifestations-prevues-a-paris-et-en-ile-de-france.jpg) <small>www.sortiraparis.com</small>Greve nacional de 2 de dezembro: transportes, escolas, aeroportos... as informações ...

FNE Avança Com Pré-Aviso De Greve Para O Dia 2 De Novembro
----------------------------------------------------------

 ![FNE avança com Pré-Aviso de Greve para o dia 2 de novembro](https://fne.pt/uploads/noticias/big_1666252804_9001_ID_FNE_site2.png) <small>fne.pt</small>FNE avança com Pré-Aviso de Greve para o dia 2 de novembro

2 De Novembro – Greve Nacional De Professores E Educadores - CGTP-IN
--------------------------------------------------------------------

 ![2 de novembro – Greve Nacional de Professores e Educadores - CGTP-IN](https://www.cgtp.pt/images/accao-e-luta/2022/10/2_de_novembro__Greve_Nacional_de_Professores_e_Educadores.jpg) <small>www.cgtp.pt</small>2 de novembro – Greve Nacional de Professores e Educadores - CGTP-IN

Manifestantes Convocam Greve-geral Para 2ª E Pedem Adesão De Empresários
------------------------------------------------------------------------

 ![Manifestantes convocam greve-geral para 2ª e pedem adesão de empresários](https://www.otempo.com.br/content/dam/otempo/editorias/eleicoes/2022/11/eleicoes-greve-geral-bolsonarro-belo-horizonte-1708430585.jpeg) <small>www.otempo.com.br</small>Manifestantes convocam greve-geral para 2ª e pedem adesão de empresários

CUT Mantém A Construção Da Greve Geral - SINDPD-PE
--------------------------------------------------

 ![CUT mantém a construção da Greve Geral - SINDPD-PE](https://sindpdpe.org.br/wp-content/uploads/2016/10/sindpd-20161025_cut-mantem-a-construcao.jpeg) <small>sindpdpe.org.br</small>CUT mantém a construção da Greve Geral - SINDPD-PE

STML | Trabalhadores Do Município De Lisboa Também Aderem à Greve Geral - CGTP-IN
---------------------------------------------------------------------------------

 ![STML | Trabalhadores do Município de Lisboa também aderem à Greve Geral - CGTP-IN](https://www.cgtp.pt/images/images/2026/06/tiago-greve-geral.jpg) <small>www.cgtp.pt</small>STML | Trabalhadores do Município de Lisboa também aderem à Greve Geral - CGTP-IN

O Sintrafesc Apoia E Reforça A Greve Geral Dos Dias 2 E 3 De Outubro - CONDSEF
------------------------------------------------------------------------------

 ![O Sintrafesc apoia e reforça a Greve Geral dos dias 2 e 3 de outubro - CONDSEF](https://www.condsef.org.br/img/noticias/o-sintrafesc-apoia-reforca-greve-geral-dos-dias-2-3-outubro-767.jpg) <small>www.condsef.org.br</small>O Sintrafesc apoia e reforça a Greve Geral dos dias 2 e 3 de outubro - CONDSEF

Setor Das Ifes Indica Greve Da Educação Federal Nos Dias 2 E 3 De Outubro – ADUFPB
----------------------------------------------------------------------------------

 ![Setor das Ifes indica greve da Educação Federal nos dias 2 e 3 de outubro – ADUFPB](https://www.adufpb.org.br/site/wp-content/uploads/2019/09/greve-nacionao-2-e-3-out-01.jpg) <small>www.adufpb.org.br</small>Setor das Ifes indica greve da Educação Federal nos dias 2 e 3 de outubro – ADUFPB

Greve Geral Paralisa Portugal Contra Precarização De Direitos
-------------------------------------------------------------

 ![Greve geral paralisa Portugal contra precarização de direitos](https://pcdob.org.br/wp-content/uploads/2025/12/Ruas-de-Lisboa-foram-tomadas-por-trabalhadores-durante-a-greve-geral-Rafael-Medeiros-Esquerda.jpg) <small>pcdob.org.br</small>Greve geral paralisa Portugal contra precarização de direitos

Manifestação Em Frente Ao Parlamento Resultou Em Seis Detidos: Tudo Sobre A Greve Geral
---------------------------------------------------------------------------------------

 ![Manifestação em frente ao Parlamento resultou em seis detidos: tudo sobre a greve geral](https://cdn.sabado.pt/images/2025-12/img_1320x742uu2025-12-11-15-03-48-752830.jpg) <small>www.sabado.pt</small>Manifestação em frente ao Parlamento resultou em seis detidos: tudo sobre a greve geral ...

Greve Geral: O Que Você Precisa Saber Sobre A Tentativa De Parar O País Pela 1ª Vez Em 20 Anos
----------------------------------------------------------------------------------------------

 ![Greve geral: o que você precisa saber sobre a tentativa de parar o país pela 1ª vez em 20 anos](https://p2.trrsf.com/image/fget/cf/648/0/images.terra.com/2017/04/27/95818331e3c5a7de-1d73-435a-a64c-6edfb0c1fd11.jpg) <small>www.terra.com.br</small>Greve geral: o que você precisa saber sobre a tentativa de parar o país pela 1ª vez em 20 anos

Metro Do Porto "fortemente Condicionado" No Dia Da Greve Geral - JPN
--------------------------------------------------------------------

 ![Metro do Porto "fortemente condicionado" no dia da greve geral - JPN](https://www.jpn.up.pt/wp-content/uploads/2025/12/greve_geral1-1152x759.jpg) <small>www.jpn.up.pt</small>Metro do Porto "fortemente condicionado" no dia da greve geral - JPN

Greve Geral Juntou Centenas Nos Aliados. Governo Fala Em Adesão "inexpressiva" - JPN
------------------------------------------------------------------------------------

 ![Greve Geral juntou centenas nos Aliados. Governo fala em adesão "inexpressiva" - JPN](https://www.jpn.up.pt/wp-content/uploads/2025/12/greve_geral6.jpg) <small>www.jpn.up.pt</small>Greve Geral juntou centenas nos Aliados. Governo fala em adesão "inexpressiva" - JPN

Greve geral: o que você precisa saber sobre a tentativa de parar o país pela 1ª vez em 20 anos. Manifestação em frente ao parlamento resultou em seis detidos: tudo sobre a greve geral .... Manifestantes convocam greve-geral para 2ª e pedem adesão de empresários
