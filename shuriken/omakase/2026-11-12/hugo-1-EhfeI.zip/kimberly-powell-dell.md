---
title: "Kimberly Powell Dell - kimberly powell author page"
description: "Hear from kimberly powell, sr. director of deep learning, on the highlights of #cvpr2017 ..."
date: "2026-07-20"
categories:
- "Uncategorized"
images:
- "https://media.licdn.com/dms/image/D5622AQHpO63Gdvh9pA/feedshare-shrink_2048_1536/0/1686869396106?e=2147483647&amp;v=beta&amp;t=br0qoF38jSsM6UDaZFY07EPc3IwdUveCofo65zD08K8"
featuredImage: "https://www.hopkinsmedicine.org/-/media/images/articles/2018/03/kimberly_powell.jpeg?h=640&amp;iar=0&amp;w=640&amp;hash=1741F5E78A512573722D6BEAB32D9288"
featured_image: "https://media.licdn.com/dms/image/v2/D5603AQFaZX-TikH51A/profile-displayphoto-shrink_200_200/profile-displayphoto-shrink_200_200/0/1695195797796?e=2147483647&amp;v=beta&amp;t=WKXeR24Fo4zMw6-s5CeH0hkX17k2v_-_AOl4fXFvBE8"
image: "https://go.forrester.com/wp-content/uploads/2024/01/CXNA-2023-Kimberly-Smith-Dell.-Thumbnail-1.jpg"
---

If you are looking for Kimberly POWELL | Director | NVIDIA, CA | Nvidia | business development | Research profile you've visit to the right web. We have 35 Pics about Kimberly POWELL | Director | NVIDIA, CA | Nvidia | business development | Research profile like Kimberly Powell - Account Manager IV at Dell Technologies | LinkedIn, Special thanks to the team at Dell Technologies that supports our recruiting at Penn State today and also NVIDIA on LinkedIn: Missed #EmTechDigital? Watch Kimberly Powell, our Sr. Director of…. Read more:

Kimberly POWELL | Director | NVIDIA, CA | Nvidia | Business Development | Research Profile
------------------------------------------------------------------------------------------

 ![Kimberly POWELL | Director | NVIDIA, CA | Nvidia | business development | Research profile](https://i1.rgstatic.net/ii/profile.image/340307037179915-1458146928717_Q512/Kimberly-Powell-7.jpg) <small>www.researchgate.net</small>Kimberly POWELL | Director | NVIDIA, CA | Nvidia | business development | Research profile

Kimberly Powell - Educator | LinkedIn
-------------------------------------

 ![Kimberly Powell - Educator | LinkedIn](https://media.licdn.com/dms/image/v2/D4E03AQHOuOY6ZGYI0Q/profile-displayphoto-scale_200_200/B4EZ7ki9AUIcAc-/0/1781950829543?e=2147483647&v=beta&t=Hru_4tKnxIC5gaaOhdGXpnQNaEiYz0TBaABXWrcZnSo) <small>www.linkedin.com</small>Kimberly Powell - Educator | LinkedIn

Kimberly Powell - SR Partner Technical Advisor | LinkedIn
---------------------------------------------------------

 ![Kimberly Powell - SR Partner Technical Advisor | LinkedIn](https://media.licdn.com/dms/image/v2/D5603AQGY1P7BMa4UrA/profile-displayphoto-shrink_200_200/profile-displayphoto-shrink_200_200/0/1709256150173?e=2147483647&v=beta&t=Sr6TwAk9jjQSdKtZX537kaHgDevPQ700DsIYeMP3l0Q) <small>www.linkedin.com</small>Kimberly Powell - SR Partner Technical Advisor | LinkedIn

The Age Of AI In Radiology Is Here – Entelechy Asia
---------------------------------------------------

 ![The age of AI in radiology is here – Entelechy Asia](https://entelechyasia.com/wp-content/uploads/2019/01/kimberly-powell-at-emtech-asia.jpg) <small>entelechyasia.com</small>The age of AI in radiology is here – Entelechy Asia

NVIDIA On LinkedIn: Missed #EmTechDigital? Watch Kimberly Powell, Our Sr. Director Of…
--------------------------------------------------------------------------------------

 ![NVIDIA on LinkedIn: Missed #EmTechDigital? Watch Kimberly Powell, our Sr. Director of…](https://media.licdn.com/dms/image/C4E22AQF_Yb-stkVkEg/feedshare-shrink_800/0/1592157286148?e=2147483647&v=beta&t=7QHOCwj_Y8H2hWCipes3UAij4_lekRTa99CikP6HdkA) <small>www.linkedin.com</small>NVIDIA on LinkedIn: Missed #EmTechDigital? Watch Kimberly Powell, our Sr. Director of…

Kimberly Powell Inducted As Fellow Of The American Medical Informatics Association, Announced As
------------------------------------------------------------------------------------------------

 ![Kimberly Powell inducted as Fellow of the American Medical Informatics Association, announced as](https://showme.missouri.edu/wp-content/uploads/2024/06/internet-usage-4x5-2-scaled.jpg) <small>showme.missouri.edu</small>Kimberly Powell inducted as Fellow of the American Medical Informatics Association, announced as ...

NVIDIA Powers Up In Drug Discovery
----------------------------------

 ![NVIDIA Powers Up in Drug Discovery](https://genengnews.com/wp-content/uploads/2020/10/Kimberly-Powell_avatar_1511719112-200x200-1.jpg) <small>www.genengnews.com</small>NVIDIA Powers Up in Drug Discovery

Hear From Kimberly Powell, Sr. Director Of Deep Learning, On The Highlights Of #CVPR2017
----------------------------------------------------------------------------------------

 ![Hear from Kimberly Powell, Sr. Director of Deep Learning, on the highlights of #CVPR2017](https://lookaside.fbsbx.com/lookaside/crawler/media/?media_id=10155005906623253&get_thumbnail=1) <small>www.facebook.com</small>Hear from Kimberly Powell, Sr. Director of Deep Learning, on the highlights of #CVPR2017 ...

Kimberly Powell Honored For Pioneering Work In Health Informatics And Gerontology
---------------------------------------------------------------------------------

 ![Kimberly Powell honored for pioneering work in health informatics and gerontology](https://nursing.missouri.edu/wp-content/uploads/2024/06/Kimberly-Powell-FAMIA-induction.png) <small>nursing.missouri.edu</small>Kimberly Powell honored for pioneering work in health informatics and gerontology

Kimberly Powell - Keynote - Ohio Genealogical Society
-----------------------------------------------------

 ![Kimberly Powell - Keynote - Ohio Genealogical Society](https://www.ogs.org/wp-content/uploads/2026/02/Powell-Kimberly-2.png) <small>www.ogs.org</small>Kimberly Powell - Keynote - Ohio Genealogical Society

Faculty Staff | College Of Medicine
-----------------------------------

 ![Faculty Staff | College of Medicine](https://public.med.fsu.edu/images/Faculty/Kimberly.Powell.jpg) <small>public.med.fsu.edu</small>Faculty Staff | College of Medicine

Customer Experience - Earn Loyalty And Fuel Growth With Forrester
-----------------------------------------------------------------

 ![Customer Experience - Earn Loyalty And Fuel Growth With Forrester](https://go.forrester.com/wp-content/uploads/2024/01/CXNA-2023-Kimberly-Smith-Dell.-Thumbnail-1.jpg) <small>www.forrester.com</small>Customer Experience - Earn Loyalty And Fuel Growth With Forrester

Special Thanks To The Team At Dell Technologies That Supports Our Recruiting At Penn State Today
------------------------------------------------------------------------------------------------

 ![Special thanks to the team at Dell Technologies that supports our recruiting at Penn State today](https://media.licdn.com/dms/image/v2/D5610AQFSaqU04vtWtw/image-shrink_800/image-shrink_800/0/1713388518439?e=2147483647&v=beta&t=t0jEmLiutWrejcpBqWcgrnAYjLft0nPU70shxz2ZrFM) <small>www.linkedin.com</small>Special thanks to the team at Dell Technologies that supports our recruiting at Penn State today ...

Nvidia’s AI Healthcare Vision Spans New Drugs, Robots, And Beyond - Fast Company
--------------------------------------------------------------------------------

 ![Nvidia’s AI healthcare vision spans new drugs, robots, and beyond - Fast Company](https://images.fastcompany.com/image/upload/f_webp,q_auto,c_fit/wp-cms-2/2025/12/p-1-91452480-kimberly-powell-qa.jpg) <small>www.fastcompany.com</small>Nvidia’s AI healthcare vision spans new drugs, robots, and beyond - Fast Company

NVIDIA: A Nova Fronteira Da Medicina Está Na IA - CM
----------------------------------------------------

 ![NVIDIA: A nova fronteira da Medicina está na IA - CM](https://consumidormoderno.com.br/wp-content/uploads/2025/03/Nvidia_Kimberly-Powell-1024x530.webp) <small>consumidormoderno.com.br</small>NVIDIA: A nova fronteira da Medicina está na IA - CM

Generative AI Is Revolutionizing Healthcare, From Drug Discovery To Diagnostics And Post-op Care
------------------------------------------------------------------------------------------------

 ![Generative AI is revolutionizing healthcare, from drug discovery to diagnostics and post-op care](https://media.licdn.com/dms/image/v2/D4D22AQHI7fbK1GV1QQ/feedshare-shrink_2048_1536/feedshare-shrink_2048_1536/0/1717762363344?e=2147483647&v=beta&t=HcXrmL3078ePC82LlnhipxGpfpS2lI088q7m0yCHQ0I) <small>pe.linkedin.com</small>Generative AI is revolutionizing healthcare, from drug discovery to diagnostics and post-op care ...

Board Of Directors — Basic Needs Inc.
-------------------------------------

 ![Board of Directors — Basic Needs Inc.](https://images.squarespace-cdn.com/content/v1/63d48a2e85aa7959f69d2f27/58712eb8-621f-4cbe-b73b-a7e4fbbc934a/Powell_Kim+2005.jpg) <small>www.basicneedsmn.org</small>Board of Directors — Basic Needs Inc.

What Can Health Care Learn From Self-Driving Cars? | Johns Hopkins Medicine
---------------------------------------------------------------------------

 ![What Can Health Care Learn from Self-Driving Cars? | Johns Hopkins Medicine](https://www.hopkinsmedicine.org/-/media/images/articles/2018/03/kimberly_powell.jpeg?h=640&iar=0&w=640&hash=1741F5E78A512573722D6BEAB32D9288) <small>www.hopkinsmedicine.org</small>What Can Health Care Learn from Self-Driving Cars? | Johns Hopkins Medicine

Kimberly Powell - PhD, RN, FAMIA, FAAN | LinkedIn
-------------------------------------------------

 ![Kimberly Powell - PhD, RN, FAMIA, FAAN | LinkedIn](https://media.licdn.com/dms/image/v2/D4E03AQELNZTNqlomtw/profile-displayphoto-scale_200_200/B4EZiemXJLHoAY-/0/1755007513927?e=2147483647&v=beta&t=9aVHNfS1ADg7fyk_hbUBaCziZDNeQpkjMX0xwrnhkTQ) <small>www.linkedin.com</small>Kimberly Powell - PhD, RN, FAMIA, FAAN | LinkedIn

Kimberly Powell - Account Manager IV At Dell Technologies | LinkedIn
--------------------------------------------------------------------

 ![Kimberly Powell - Account Manager IV at Dell Technologies | LinkedIn](https://media.licdn.com/dms/image/v2/D5603AQFaZX-TikH51A/profile-displayphoto-shrink_200_200/profile-displayphoto-shrink_200_200/0/1695195797796?e=2147483647&v=beta&t=WKXeR24Fo4zMw6-s5CeH0hkX17k2v_-_AOl4fXFvBE8) <small>www.linkedin.com</small>Kimberly Powell - Account Manager IV at Dell Technologies | LinkedIn

AIで医療分野にイノベーションを起こすNVIDIA - PC Watch
------------------------------------

 ![AIで医療分野にイノベーションを起こすNVIDIA - PC Watch](https://asset.watch.impress.co.jp/img/pcw/docs/1120/878/DSCF5066_l.jpg) <small>pc.watch.impress.co.jp</small>AIで医療分野にイノベーションを起こすNVIDIA - PC Watch

Home - Cell X Technologies
--------------------------

 ![Home - Cell X Technologies](https://cellxtechnologies.com/wp-content/uploads/2023/09/Image_Kimberly-Powell.jpg) <small>cellxtechnologies.com</small>Home - Cell X Technologies

Kimberly Powell On LinkedIn: Had A Fantastic Time Hosting The PowerUp Strategic Educators
-----------------------------------------------------------------------------------------

 ![Kimberly Powell on LinkedIn: Had a fantastic time hosting the PowerUp Strategic Educators](https://media.licdn.com/dms/image/D5622AQEBItJYa-ypGw/feedshare-shrink_800/0/1708957758233?e=2147483647&v=beta&t=xMzVZhCGZYMoNSETCR7it3dpNlrrkZKiht8hIB45sdI) <small>www.linkedin.com</small>Kimberly Powell on LinkedIn: Had a fantastic time hosting the PowerUp Strategic Educators ...

Nvidia's Kimberly Powell Is Leading The Chip Giant's Charge Into AI For Health Care - San
-----------------------------------------------------------------------------------------

 ![Nvidia's Kimberly Powell is leading the chip giant's charge into AI for health care - San](https://media.bizj.us/view/img/12968502/kimberlypowell-1*1200xx9428-5303-0-491.jpg) <small>www.bizjournals.com</small>Nvidia's Kimberly Powell is leading the chip giant's charge into AI for health care - San ...

Kimberly Powell's Instagram, Twitter &amp; Facebook On IDCrawl
--------------------------------------------------------------

 ![Kimberly Powell's Instagram, Twitter & Facebook on IDCrawl](https://girlgeek.io/wp-content/uploads/2018/10/kimberly-powell.jpg) <small>www.idcrawl.com</small>Kimberly Powell's Instagram, Twitter &amp; Facebook on IDCrawl

Kimberly Powell - Federal Cybersecurity Analyst | | Security Architecture Enterprise
------------------------------------------------------------------------------------

 ![Kimberly Powell - Federal Cybersecurity Analyst | | Security Architecture Enterprise](https://media.licdn.com/dms/image/v2/D4E03AQHf6Yx1tOaXCQ/profile-displayphoto-scale_200_200/B4EZvjsxCZJAAY-/0/1769051722281?e=2147483647&v=beta&t=UOjMcwZafuKlXgdI61I0hti_3ZXbs2LOpiufYIR0ZWk) <small>www.linkedin.com</small>Kimberly Powell - Federal Cybersecurity Analyst | | Security Architecture Enterprise ...

Kimberly Powell On LinkedIn: I Am Honored To Have Been Nominated And Awarded The BAM WW - Gerald
------------------------------------------------------------------------------------------------

 ![Kimberly Powell on LinkedIn: I am honored to have been nominated and awarded the BAM WW - Gerald](https://media.licdn.com/dms/image/D5622AQHpO63Gdvh9pA/feedshare-shrink_2048_1536/0/1686869396106?e=2147483647&v=beta&t=br0qoF38jSsM6UDaZFY07EPc3IwdUveCofo65zD08K8) <small>www.linkedin.com</small>Kimberly Powell on LinkedIn: I am honored to have been nominated and awarded the BAM WW - Gerald ...

An Interview With Kimberley Powell (NVIDIA) At The AI Summit, San Francisco (2016). - YouTube
---------------------------------------------------------------------------------------------

 ![An Interview with Kimberley Powell (NVIDIA) at The AI Summit, San Francisco (2016). - YouTube](https://i.ytimg.com/vi/15s952bcezM/maxresdefault.jpg) <small>www.youtube.com</small>An Interview with Kimberley Powell (NVIDIA) at The AI Summit, San Francisco (2016). - YouTube

Kimberly Powell Author Page | NVIDIA Blog
-----------------------------------------

 ![Kimberly Powell Author Page | NVIDIA Blog](https://blogs.nvidia.com/wp-content/uploads/2025/02/AI-Podcast-Telenor-Blog-Feature.jpg) <small>blogs.nvidia.com</small>Kimberly Powell Author Page | NVIDIA Blog

Exclusive Interview With Kimberly Powell, VP And General Manager Of NVIDIA Healthcare - MarkTechPost
----------------------------------------------------------------------------------------------------

 ![Exclusive Interview with Kimberly Powell, VP and General Manager of NVIDIA Healthcare - MarkTechPost](https://www.marktechpost.com/wp-content/uploads/2022/04/Interview-2.png) <small>www.marktechpost.com</small>Exclusive Interview with Kimberly Powell, VP and General Manager of NVIDIA Healthcare - MarkTechPost

Kimberly Powell - At | LinkedIn
-------------------------------

 ![Kimberly Powell - at | LinkedIn](https://media.licdn.com/dms/image/v2/C4E03AQEGJk--BTydNw/profile-displayphoto-shrink_200_200/profile-displayphoto-shrink_200_200/0/1516849136673?e=2147483647&v=beta&t=eSvvy8LcE7y1pXitI4462Hh6HI-1SU2m37-7VI6r4Ek) <small>www.linkedin.com</small>Kimberly Powell - at | LinkedIn

Kimberly Powell - Regions Bank | LinkedIn
-----------------------------------------

 ![Kimberly Powell - Regions Bank | LinkedIn](https://media.licdn.com/dms/image/v2/D5603AQFFFnb2ioIYxw/profile-displayphoto-scale_200_200/B56Z3k.YUiG0Ac-/0/1777663051903?e=2147483647&v=beta&t=p5K04LuctkVJy81qIChxQI97dmtIJ0eQv4yskRpy9zc) <small>www.linkedin.com</small>Kimberly Powell - Regions Bank | LinkedIn

From The Office To The Lab, Amgen Uses AI Tools To Unlock Innovation | Amgen
----------------------------------------------------------------------------

 ![From the Office to the Lab, Amgen Uses AI Tools to Unlock Innovation | Amgen](https://www.amgen.com/stories/2024/05/-/media/Themes/CorporateAffairs/amgen-com/amgen-com/Images/stories/2024/05-21-From-the-Office-to-the-Lab-Amgen-Uses-AI-Tools-to-Unlock-Innovation/powell.png) <small>www.amgen.com</small>From the Office to the Lab, Amgen Uses AI Tools to Unlock Innovation | Amgen

Nvidia Expands AI Ambitions In Healthcare; Aims To Transform Hospitals With Robotics – Digital
----------------------------------------------------------------------------------------------

 ![Nvidia expands AI ambitions in healthcare; aims to transform hospitals with robotics – Digital](https://digitaleconomymag.com/wp-content/uploads/2024/11/Nvidia-Kimberly-Powel.png) <small>digitaleconomymag.com</small>Nvidia expands AI ambitions in healthcare; aims to transform hospitals with robotics – Digital ...

Dive Into The Future Of Digital Surgery, Health, And Biology With NVIDIA's VP Of Healthcare And
-----------------------------------------------------------------------------------------------

 ![Dive into the future of digital surgery, health, and biology with NVIDIA's VP of Healthcare and](https://media.licdn.com/dms/image/v2/D5610AQEf18m9u13NPw/image-shrink_800/image-shrink_800/0/1718404075786?e=2147483647&v=beta&t=F-wL667A6hY7CE4c0fp8ufvPB6vLFAUNhCatqrC7jY4) <small>www.linkedin.com</small>Dive into the future of digital surgery, health, and biology with NVIDIA's VP of Healthcare and ...

From the office to the lab, amgen uses ai tools to unlock innovation. Kimberly powell. Nvidia powers up in drug discovery
