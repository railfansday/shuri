---
title: "Cantor Eric Cantor - Category:eric cantor in 2014"
description: "eric cantor to resign as majority leader after dave brat win"
date: "2026-08-01"
categories:
- "Uncategorized"
images:
- "https://biographs.org/images/21/21552/eric-cantor-1.jpg"
featuredImage: "https://static01.nyt.com/images/2014/06/11/us/11CANTOR-hp2/11CANTOR-hp2-superJumbo-v3.jpg?quality=75&amp;auto=webp"
featured_image: "https://media.gettyimages.com/id/96870475/photo/house-minority-whip-eric-cantor-addresses-supporters-at-the-conservative-political-action.jpg?s=612x612&amp;w=gi&amp;k=20&amp;c=pTEQq2RqU8Shs-1y2eiQ3kpTHpIOq0Z3bXdg96ymMfw="
image: "https://static01.nyt.com/images/2014/06/11/us/11CANTOR-hp2/11CANTOR-hp2-superJumbo-v3.jpg?quality=75&amp;auto=webp"
---

If you are searching about Eric Cantor Stepping Down as House Majority Leader - ABC News you've came to the right place. We have 35 Images about Eric Cantor Stepping Down as House Majority Leader - ABC News like Eric Cantor – The Forward, Eric Cantor Defeated by David Brat, Tea Party Challenger, in G.O.P. Primary Upset - The New York and also Eric Cantor Defeated by David Brat, Tea Party Challenger, in G.O.P. Primary Upset - The New York. Here it is:

Eric Cantor Stepping Down As House Majority Leader - ABC News
-------------------------------------------------------------

 ![Eric Cantor Stepping Down as House Majority Leader - ABC News](https://s.abcnews.com/images/Politics/AP_Eric_Cantor_ml_140610_16x9_992.jpg?w=1600) <small>abcnews.com</small>Eric Cantor Stepping Down as House Majority Leader - ABC News

File:Eric Cantor (8568961099) (cropped).jpg - Wikimedia Commons
---------------------------------------------------------------

 ![File:Eric Cantor (8568961099) (cropped).jpg - Wikimedia Commons](https://upload.wikimedia.org/wikipedia/commons/thumb/0/0a/Eric_Cantor_(8568961099)_(cropped).jpg/250px-Eric_Cantor_(8568961099)_(cropped).jpg) <small>commons.wikimedia.org</small>File:Eric Cantor (8568961099) (cropped).jpg - Wikimedia Commons

Eric Cantor To Resign From Congress Early, Aug. 18 | IBTimes
------------------------------------------------------------

 ![Eric Cantor To Resign From Congress Early, Aug. 18 | IBTimes](https://d.ibtimes.com/en/full/1646110/eric-cantor.jpg?w=736&f=c585d69aacd1fce4effc62ae9c3558bc) <small>www.ibtimes.com</small>Eric Cantor To Resign From Congress Early, Aug. 18 | IBTimes

Category:Eric Cantor In 2014 - Wikimedia Commons
------------------------------------------------

 ![Category:Eric Cantor in 2014 - Wikimedia Commons](https://upload.wikimedia.org/wikipedia/commons/thumb/b/b9/Eric_Cantor_(01).jpg/250px-Eric_Cantor_(01).jpg) <small>commons.wikimedia.org</small>Category:Eric Cantor in 2014 - Wikimedia Commons

Eric Cantor Biography. American Republican Politician
-----------------------------------------------------

 ![Eric Cantor biography. American Republican politician](https://biographs.org/images/21/21552/eric-cantor-1.jpg) <small>biographs.org</small>Eric Cantor biography. American Republican politician

Eric Cantor's Focus On D.C. Led To His Virginia Defeat - WSJ
------------------------------------------------------------

 ![Eric Cantor's Focus on D.C. Led to His Virginia Defeat - WSJ](https://s.wsj.net/public/resources/images/NA-CB558_CANTOR_GR_20140611175444.jpg) <small>www.wsj.com</small>Eric Cantor's Focus on D.C. Led to His Virginia Defeat - WSJ

Eric Cantor Defeated By David Brat, Tea Party Challenger, In G.O.P. Primary Upset - The New York
------------------------------------------------------------------------------------------------

 ![Eric Cantor Defeated by David Brat, Tea Party Challenger, in G.O.P. Primary Upset - The New York](https://static01.nyt.com/images/2014/06/11/us/11CANTOR-hp2/11CANTOR-hp2-superJumbo-v3.jpg?quality=75&auto=webp) <small>www.nytimes.com</small>Eric Cantor Defeated by David Brat, Tea Party Challenger, in G.O.P. Primary Upset - The New York ...

Eric Cantor’s Primary Loss Reflects A Global Trend That Can Affect Investment Portfolios – The
----------------------------------------------------------------------------------------------

 ![Eric Cantor’s Primary Loss Reflects a Global Trend That Can Affect Investment Portfolios – The](https://www.stuysquare.com/wp-content/uploads/2014/06/1280px-Eric_Cantor.jpg) <small>www.stuysquare.com</small>Eric Cantor’s Primary Loss Reflects a Global Trend That Can Affect Investment Portfolios – The ...

3,323 Eric Cantor Photos &amp; High Res Pictures - Getty Images
---------------------------------------------------------------

 ![3,323 Eric Cantor Photos & High Res Pictures - Getty Images](https://media.gettyimages.com/id/450452080/photo/washington-dc-house-majority-leader-eric-cantor-announces-that-he-will-resign-his-leadership.jpg?s=612x612&w=gi&k=20&c=tsKI9dn2K4C-eNhX9sLF3XylxTSyo8_aQbDe5dnzs1U=) <small>www.gettyimages.co.uk</small>3,323 Eric Cantor Photos &amp; High Res Pictures - Getty Images

Eric Cantor News &amp; Latest Pictures From Newsweek.com
--------------------------------------------------------

 ![Eric Cantor news & latest pictures from Newsweek.com](https://d.newsweek.com/en/full/1780532/eric-cantor.jpg) <small>www.newsweek.com</small>Eric Cantor news &amp; latest pictures from Newsweek.com

Eric Cantor’s Political Force -- New York Magazine - Nymag
----------------------------------------------------------

 ![Eric Cantor’s Political Force -- New York Magazine - Nymag](https://images.nymag.com/news/politics/cantor111010_1_560.jpg) <small>nymag.com</small>Eric Cantor’s Political Force -- New York Magazine - Nymag

The GOP Can't Win With Eric Cantor As Its Ambassador - The Atlantic
-------------------------------------------------------------------

 ![The GOP Can't Win With Eric Cantor as Its Ambassador - The Atlantic](https://cdn.theatlantic.com/media/mt/politics/eric cantor full.jpg) <small>www.theatlantic.com</small>The GOP Can't Win With Eric Cantor as Its Ambassador - The Atlantic

Eric Cantor To Resign As Majority Leader After Dave Brat Win | TIME
-------------------------------------------------------------------

 ![Eric Cantor to Resign As Majority Leader After Dave Brat Win | TIME](https://api.time.com/wp-content/uploads/2014/06/eric_cantor_quits2.jpg?quality=85) <small>time.com</small>Eric Cantor to Resign As Majority Leader After Dave Brat Win | TIME

130 Eric Cantor Photos Stock Photos, High-Res Pictures, And Images - Getty Images
---------------------------------------------------------------------------------

 ![130 Eric Cantor Photos Stock Photos, High-Res Pictures, and Images - Getty Images](https://media.gettyimages.com/id/525603122/photo/minority-whip-rep-eric-cantor-of-virginia-at-the-republican-national-convention-in-tampa-fla.jpg?s=612x612&w=gi&k=20&c=gIejx5oIioks1vmvxj5Mm01v0DVTpJUppQS-Su3DP0k=) <small>www.gettyimages.dk</small>130 Eric Cantor Photos Stock Photos, High-Res Pictures, and Images - Getty Images

Eric Cantor’s Webpage Now Just Has A Picture Of Him That Goes Nowhere If You Click On It - Vox
----------------------------------------------------------------------------------------------

 ![Eric Cantor’s webpage now just has a picture of him that goes nowhere if you click on it - Vox](https://cdn.vox-cdn.com/thumbor/8AcAUTPKoC_kXDI8vrHHw0S2WVI=/0x0:718x607/1200x0/filters:focal(0x0:718x607):no_upscale()/cdn.vox-cdn.com/uploads/chorus_asset/file/2343148/Screen_Shot_2014-10-10_at_9.52.49_AM.0.png) <small>www.vox.com</small>Eric Cantor’s webpage now just has a picture of him that goes nowhere if you click on it - Vox

Eric Cantor Defeated By David Brat, Tea Party Challenger, In G.O.P. Primary Upset - The New York
------------------------------------------------------------------------------------------------

 ![Eric Cantor Defeated by David Brat, Tea Party Challenger, in G.O.P. Primary Upset - The New York](https://static01.nyt.com/images/2014/06/11/multimedia/cantor-primary-speeches/cantor-primary-speeches-superJumbo.jpg) <small>www.nytimes.com</small>Eric Cantor Defeated by David Brat, Tea Party Challenger, in G.O.P. Primary Upset - The New York ...

Eric Cantor Photos Photos And Premium High Res Pictures - Getty Images
----------------------------------------------------------------------

 ![Eric Cantor Photos Photos and Premium High Res Pictures - Getty Images](https://media.gettyimages.com/id/541012038/photo/eric-cantor-the-former-house-majority-leader-at-his-new-office-at-morelis-an-investment-bank.jpg?s=612x612&w=gi&k=20&c=TMcI05VRIfTgSrtTRDtFR9HTTDc22wi-hGkBDxIOkeI=) <small>www.gettyimages.co.uk</small>Eric Cantor Photos Photos and Premium High Res Pictures - Getty Images

File:Headshot Of Eric Cantor.jpg - Wikimedia Commons
----------------------------------------------------

 ![File:Headshot of Eric Cantor.jpg - Wikimedia Commons](https://upload.wikimedia.org/wikipedia/commons/thumb/a/aa/Headshot_of_Eric_Cantor.jpg/960px-Headshot_of_Eric_Cantor.jpg?utm_source=commons.wikimedia.org&utm_campaign=index&utm_content=thumbnail) <small>commons.wikimedia.org</small>File:Headshot of Eric Cantor.jpg - Wikimedia Commons

Eric Cantor's Immigration Predicament - CBS News
------------------------------------------------

 ![Eric Cantor's immigration predicament - CBS News](https://assets1.cbsnewsstatic.com/hub/i/2014/06/13/bef5ee6a-7df8-45a2-8484-449ce3c2eebf/cantor.jpg) <small>www.cbsnews.com</small>Eric Cantor's immigration predicament - CBS News

3,323 Eric Cantor Photos &amp; High Res Pictures - Getty Images
---------------------------------------------------------------

 ![3,323 Eric Cantor Photos & High Res Pictures - Getty Images](https://media.gettyimages.com/id/450452130/photo/washington-dc-house-majority-leader-eric-cantor-announces-that-he-will-resign-his-leadership.jpg?s=612x612&w=gi&k=20&c=TP9Y9PotV7Q0kiAURcF6v-KYd_OeMoOx_eWQmL6jiFU=) <small>www.gettyimages.co.uk</small>3,323 Eric Cantor Photos &amp; High Res Pictures - Getty Images

Why Did Eric Cantor Lose To Dave Brat? 5 Reasons For House Majority Leader's Defeat | IBTimes
---------------------------------------------------------------------------------------------

 ![Why Did Eric Cantor Lose To Dave Brat? 5 Reasons For House Majority Leader's Defeat | IBTimes](https://d.ibtimes.com/en/full/1598432/eric-cantor.jpg) <small>www.ibtimes.com</small>Why Did Eric Cantor Lose To Dave Brat? 5 Reasons For House Majority Leader's Defeat | IBTimes

Eric Cantor – The Forward
-------------------------

 ![Eric Cantor – The Forward](https://images.forwardcdn.com/image/1300x/center/images/cropped/f50-cantor-getty-images-1425822269.jpg) <small>forward.com</small>Eric Cantor – The Forward

CANTOR--House GOP Chief Deputy Whip Eric Cantor, R-Va., During An... News Photo - Getty Images
----------------------------------------------------------------------------------------------

 ![CANTOR--House GOP Chief Deputy Whip Eric Cantor, R-Va., during an... News Photo - Getty Images](https://media.gettyimages.com/id/74893541/photo/eric-cantor.jpg?s=1024x1024&w=gi&k=20&c=3bmhPdcJNxb-Z4V3m4XsIUrlLwgR1ty2zOJmYCFyNWc=) <small>www.gettyimages.com</small>CANTOR--House GOP Chief Deputy Whip Eric Cantor, R-Va., during an... News Photo - Getty Images

230 Eric Cantor Photos Stock Photos, High-Res Pictures, And Images - Getty Images
---------------------------------------------------------------------------------

 ![230 Eric Cantor Photos Stock Photos, High-Res Pictures, and Images - Getty Images](https://media.gettyimages.com/id/1258891983/photo/eric-cantor-managing-director-of-moelis-co-following-a-bloomberg-television-interview-in.jpg?s=612x612&w=gi&k=20&c=P9P1RI8toEothL4AGMLStxMMYfdV3kFdSeSZNosUfn8=) <small>www.gettyimages.com</small>230 Eric Cantor Photos Stock Photos, High-Res Pictures, and Images - Getty Images

Eric Cantor
-----------

 ![Eric Cantor](https://excelined.org/wp-content/uploads/2020/08/Eric-Cantor-e1597713949490.jpg) <small>excelined.org</small>Eric Cantor

Eric Cantor To Lead Twenty-Six House Republicans On AIPAC Trip To Israel – The Forward
--------------------------------------------------------------------------------------

 ![Eric Cantor To Lead Twenty-Six House Republicans on AIPAC Trip to Israel – The Forward](https://images.forwardcdn.com/image/970x/center/images/cropped/ericcantor-080713-1425647734.jpg) <small>forward.com</small>Eric Cantor To Lead Twenty-Six House Republicans on AIPAC Trip to Israel – The Forward

Eric Cantor Net Worth - Wiki, Age, Weight And Height, Relationships, Family, And More - LuxLux
----------------------------------------------------------------------------------------------

 ![Eric Cantor Net Worth - Wiki, Age, Weight and Height, Relationships, Family, and More - LuxLux](https://luxlux.net/lux/wp-content/uploads/eric-cantor-2-scaled.jpeg) <small>luxlux.net</small>Eric Cantor Net Worth - Wiki, Age, Weight and Height, Relationships, Family, and More - LuxLux

Eric Cantor | Former US House Majority Leader, Republican Politician | Britannica
---------------------------------------------------------------------------------

 ![Eric Cantor | Former US House Majority Leader, Republican Politician | Britannica](https://cdn.britannica.com/35/130935-050-F55C6384/Eric-Cantor-2009.jpg) <small>www.britannica.com</small>Eric Cantor | Former US House Majority Leader, Republican Politician | Britannica

Eric Cantor A Casualty Of Immigration Reform
--------------------------------------------

 ![Eric Cantor a Casualty of Immigration Reform](https://media-cldnry.s-nbcnews.com/image/upload/t_nbcnews-fp-1200-630,f_auto,q_auto:best/newscms/2014_24/501176/140611-eric-cantor-concession-250a.jpg) <small>www.nbcnews.com</small>Eric Cantor a Casualty of Immigration Reform

Eric Cantor
-----------

 ![Eric Cantor](https://www.adipec.com/media/1wfk5xbg/ericcantor.jpg) <small>www.adipec.com</small>Eric Cantor

Cantor Considering His Next Move After Stunning Primary Defeat | TIME
---------------------------------------------------------------------

 ![Cantor Considering His Next Move After Stunning Primary Defeat | TIME](https://api.time.com/wp-content/uploads/2014/06/eric-cantor1.jpg) <small>time.com</small>Cantor Considering His Next Move After Stunning Primary Defeat | TIME

Eric Cantor Photos And Premium High Res Pictures - Getty Images
---------------------------------------------------------------

 ![Eric Cantor Photos and Premium High Res Pictures - Getty Images](https://media.gettyimages.com/id/96870475/photo/house-minority-whip-eric-cantor-addresses-supporters-at-the-conservative-political-action.jpg?s=612x612&w=gi&k=20&c=pTEQq2RqU8Shs-1y2eiQ3kpTHpIOq0Z3bXdg96ymMfw=) <small>www.gettyimages.ie</small>Eric Cantor Photos and Premium High Res Pictures - Getty Images

Eric Cantor Photos Photos And Premium High Res Pictures - Getty Images
----------------------------------------------------------------------

 ![Eric Cantor Photos Photos and Premium High Res Pictures - Getty Images](https://media.gettyimages.com/id/527156554/photo/eric-cantor-pauses-in-the-hallway-to-chat-with-journalists-at-the-white-house-correspondents.jpg?s=612x612&w=gi&k=20&c=KvUUdBxKzwpRIc-s1ma3bE8PuSFeYd6-IAIHmw219XY=) <small>www.gettyimages.in</small>Eric Cantor Photos Photos and Premium High Res Pictures - Getty Images

Eric Cantor | Celebrities Lists.
--------------------------------

 ![Eric Cantor | Celebrities lists.](https://waytofamous.com/images/eric-cantor-06.jpg) <small>waytofamous.com</small>Eric Cantor | Celebrities lists.

Eric Cantor | GW Alumni | The George Washington University
----------------------------------------------------------

 ![Eric Cantor | GW Alumni | The George Washington University](https://www.alumni.gwu.edu/sites/g/files/zaxdzs5076/files/image/monumental-alumni/MonAlum_Cantor_500x650.jpg) <small>www.alumni.gwu.edu</small>Eric Cantor | GW Alumni | The George Washington University

3,323 eric cantor photos &amp; high res pictures. eric cantor to resign as majority leader after dave brat win. 3,323 eric cantor photos &amp; high res pictures
