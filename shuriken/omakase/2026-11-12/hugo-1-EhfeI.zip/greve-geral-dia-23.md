---
title: "Greve Geral Dia 23 - Fenprof emite pré-aviso de greve para 27 de outubro de 2023 e junta-se ao protesto dos ..."
description: "Transportes, escolas e hospitais: o que esperar da greve de 3 de junho"
date: "2026-02-05"
categories:
- "Uncategorized"
images:
- "https://www.spra.pt/wp-content/uploads/2025/10/cartaz-24-out-scaled.jpg"
featuredImage: "https://www.jpn.up.pt/wp-content/uploads/2025/12/greve_geral6.jpg"
featured_image: "https://www.jpn.up.pt/wp-content/uploads/2025/12/greve_geral9.jpg"
image: "https://cdn.sabado.pt/images/2026-05/img_980x653uu2026-05-30-11-36-15-766875.jpg"
---

If you are searching about Servidor faz greve geral contra RRF e congelamento de reajuste you've came to the right page. We have 35 Pics about Servidor faz greve geral contra RRF e congelamento de reajuste like Funcionalismo Público Federal prepara greve para o dia 23 de março | APUBH, Greve geral paralisa Portugal contra precarização de direitos and also Greve Nacional | 24 de outubro - SPRA. Here it is:

Servidor Faz Greve Geral Contra RRF E Congelamento De Reajuste
--------------------------------------------------------------

 ![Servidor faz greve geral contra RRF e congelamento de reajuste](https://alemdofato.uai.com.br/wp-content/uploads/sites/5/2023/11/greve-geral-servidor-nov-23a-scaled.jpg) <small>alemdofato.uai.com.br</small>Servidor faz greve geral contra RRF e congelamento de reajuste

SPN - Diário Da Greve Nacional Por Distritos (16/jan A 8/fev)
-------------------------------------------------------------

 ![SPN - Diário da greve nacional por distritos (16/jan a 8/fev)](https://www.spn.pt/Media/Default/Info/51000/700/50/3/Greve Nacional por Distritos.png) <small>www.spn.pt</small>SPN - Diário da greve nacional por distritos (16/jan a 8/fev)

Greve Geral: Escolas Fechadas, Transportes Parados E Impacto Nacional
---------------------------------------------------------------------

 ![Greve Geral: Escolas Fechadas, Transportes Parados e Impacto Nacional](https://media.assettype.com/dn%2F2025-12-11%2F9hy4apil%2Fgreve-geral.jpg?w=768&auto=format%2Ccompress) <small>www.dn.pt</small>Greve Geral: Escolas Fechadas, Transportes Parados e Impacto Nacional

Greve Geral | Ações E Dados
---------------------------

 ![Greve Geral | Ações e dados](https://spzn.pt/uploads/noticias/big_1765534268_2581_SPZN_2025_site_novo_(29).png) <small>spzn.pt</small>Greve Geral | Ações e dados

FENPROF Emite Pré-aviso De Greve Para 27 De Outubro De 2023 E Junta-se Ao Protesto Dos
--------------------------------------------------------------------------------------

 ![FENPROF emite pré-aviso de greve para 27 de outubro de 2023 e junta-se ao protesto dos](https://www.spra.pt/wp-content/uploads/2023/10/cartaz-greve-fc-27-outubro-net-1-704x1024.jpg) <small>www.spra.pt</small>FENPROF emite pré-aviso de greve para 27 de outubro de 2023 e junta-se ao protesto dos ...

Pré-avisos De Greves De 2 E 3 De Março 2023
-------------------------------------------

 ![Pré-avisos de Greves de 2 e 3 de março 2023](https://fne.pt/uploads/rte/cartaz_greve_manif_2e3marco2023.jpeg) <small>fne.pt</small>Pré-avisos de Greves de 2 e 3 de março 2023

Greve Nacional | 24 De Outubro - SPRA
-------------------------------------

 ![Greve Nacional | 24 de outubro - SPRA](https://www.spra.pt/wp-content/uploads/2025/10/cartaz-24-out-scaled.jpg) <small>www.spra.pt</small>Greve Nacional | 24 de outubro - SPRA

SPN - Fenprof — Adesão Histórica à Greve Geral
----------------------------------------------

 ![SPN - Fenprof — Adesão histórica à greve geral](https://www.spn.pt/Media/Default/Info/68000/500/60/7/grevegeral11dez_cartaz.jpg) <small>www.spn.pt</small>SPN - Fenprof — Adesão histórica à greve geral

Greve Geral Juntou Centenas Nos Aliados. Governo Fala Em Adesão "inexpressiva" - JPN
------------------------------------------------------------------------------------

 ![Greve Geral juntou centenas nos Aliados. Governo fala em adesão "inexpressiva" - JPN](https://www.jpn.up.pt/wp-content/uploads/2025/12/greve_geral8.jpg) <small>www.jpn.up.pt</small>Greve Geral juntou centenas nos Aliados. Governo fala em adesão "inexpressiva" - JPN

2023 – Metroviários
-------------------

 ![2023 – Metroviários](https://www.metroviarios.org.br/site/wp-content/uploads/2023/03/Slider_dia140323.png) <small>www.metroviarios.org.br</small>2023 – Metroviários

SPN - Fenprof — Adesão Histórica à Greve Geral
----------------------------------------------

 ![SPN - Fenprof — Adesão histórica à greve geral](https://www.spn.pt/Media/Default/_Profiles/ee10172b/dadfb8d0/esigrevegeral_w.jpg?v=639008770978208893) <small>www.spn.pt</small>SPN - Fenprof — Adesão histórica à greve geral

Angola: Sindicatos Iniciam Segunda Fase Da Greve Geral - RFI
------------------------------------------------------------

 ![Angola: Sindicatos iniciam segunda fase da greve geral - RFI](https://s.rfi.fr/media/display/d2549654-e6b7-11ee-9eaa-005056bf30b7/w:1024/p:16x9/WhatsApp Image 2024-03-20 at 12.46.31.jpeg) <small>www.rfi.fr</small>Angola: Sindicatos iniciam segunda fase da greve geral - RFI

Aviso Prévio De Greve Administração Pública – Setor Público Empresarial – IPSS 23 DE MARÇO DE
---------------------------------------------------------------------------------------------

 ![Aviso prévio de greve Administração Pública – Setor Público Empresarial – IPSS 23 DE MARÇO DE](https://www.stts.pt/wp-content/uploads/2026/03/CAPA.png) <small>www.stts.pt</small>Aviso prévio de greve Administração Pública – Setor Público Empresarial – IPSS 23 DE MARÇO DE ...

PRÉ- AVISO DE GREVE – 23 E 24 De Outubro – AEC
----------------------------------------------

 ![PRÉ- AVISO DE GREVE – 23 e 24 de outubro – AEC](https://aeceleiros.pt/wp-content/uploads/2025/10/Greve_out2025_v1.png) <small>aeceleiros.pt</small>PRÉ- AVISO DE GREVE – 23 e 24 de outubro – AEC

Greve Geral Juntou Centenas Nos Aliados. Governo Fala Em Adesão "inexpressiva" - JPN
------------------------------------------------------------------------------------

 ![Greve Geral juntou centenas nos Aliados. Governo fala em adesão "inexpressiva" - JPN](https://www.jpn.up.pt/wp-content/uploads/2025/12/greve_geral_11.jpg) <small>www.jpn.up.pt</small>Greve Geral juntou centenas nos Aliados. Governo fala em adesão "inexpressiva" - JPN

Funcionalismo Público Federal Prepara Greve Para O Dia 23 De Março | APUBH
--------------------------------------------------------------------------

 ![Funcionalismo Público Federal prepara greve para o dia 23 de março | APUBH](https://apubh.org.br/wp-content/uploads/2022/02/card_redes-1.png) <small>apubh.org.br</small>Funcionalismo Público Federal prepara greve para o dia 23 de março | APUBH

Dados Recolhidos Até às 19h20 Demonstram Que A Greve Geral Parou O País - CGTP-IN
---------------------------------------------------------------------------------

 ![Dados recolhidos até às 19h20 demonstram que a Greve Geral parou o país - CGTP-IN](https://cgtp.pt/images/images/2026/06/Captura de ecra 2026-06-03 120926.png#joomlaImage:/local-images/images/2026/06/Captura de ecra 2026-06-03 120926.png?width=1162&height=610) <small>www.cgtp.pt</small>Dados recolhidos até às 19h20 demonstram que a Greve Geral parou o país - CGTP-IN

FAQ: Os Direitos Dos Docentes Em Dia De Greve Geral - 11/12/2025
----------------------------------------------------------------

 ![FAQ: Os direitos dos docentes em dia de Greve Geral - 11/12/2025](https://static.wixstatic.com/media/d0f32c_9ff1199ee2c34418af0094a43c516733~mv2.png/v1/fill/w_940,h_788,al_c,q_90,enc_avif,quality_auto/d0f32c_9ff1199ee2c34418af0094a43c516733~mv2.png) <small>www.sprc.pt</small>FAQ: Os direitos dos docentes em dia de Greve Geral - 11/12/2025

Chegou A Hora: Vamos Construir A Greve Geral A Partir De 23 De Março! - Fenasps
-------------------------------------------------------------------------------

 ![Chegou a hora: vamos construir a Greve Geral a partir de 23 de março! - Fenasps](https://fenasps.org.br/wp-content/uploads/2022/03/vamos.construir.greve_.23mar_18.03.22.jpg) <small>fenasps.org.br</small>Chegou a hora: vamos construir a Greve Geral a partir de 23 de março! - Fenasps

Greve Geral Na Argentina: Governo Monta Postos De Controle, Mas Não Evita Protestos E Multidão
----------------------------------------------------------------------------------------------

 ![Greve geral na Argentina: governo monta postos de controle, mas não evita protestos e multidão](https://s2-oglobo.glbimg.com/V7Y8UJwANx11oJDI3S06BJ3H-IY=/1600x0/smart/filters:strip_icc()/i.s3.glbimg.com/v1/AUTH_da025474c0c44edd99332dddb09cabe8/internal_photos/bs/2024/7/b/SCOa79QxybJ0mnPp3zDg/afp-20240124-34gp483-v1-highres-argentinapoliticseconomynationalstrike.jpg) <small>oglobo.globo.com</small>Greve geral na Argentina: governo monta postos de controle, mas não evita protestos e multidão ...

Greve Geral Juntou Centenas Nos Aliados. Governo Fala Em Adesão "inexpressiva" - JPN
------------------------------------------------------------------------------------

 ![Greve Geral juntou centenas nos Aliados. Governo fala em adesão "inexpressiva" - JPN](https://www.jpn.up.pt/wp-content/uploads/2025/12/greve_geral6.jpg) <small>www.jpn.up.pt</small>Greve Geral juntou centenas nos Aliados. Governo fala em adesão "inexpressiva" - JPN

Falta Uma Semana E Cada Vez Mais Apoiam Greve Geral: Qual O Impacto?
--------------------------------------------------------------------

 ![Falta uma semana e cada vez mais apoiam greve geral: Qual o impacto?](https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA215STz.img?w=768&h=432&m=6&x=193&y=425&s=717&d=119) <small>www.msn.com</small>Falta uma semana e cada vez mais apoiam greve geral: Qual o impacto?

Greve Geral - Manifestação - 30 De Junho - Seeb
-----------------------------------------------

 ![Greve Geral - Manifestação - 30 de Junho - Seeb](http://seeb.org.br/wp-content/uploads/2017/06/GREVE-GERAL-30-1-1024x1024.jpg) <small>seeb.org.br</small>Greve Geral - Manifestação - 30 de Junho - Seeb

Agenda De Greve | 23 A 30/3
---------------------------

 ![Agenda de greve | 23 a 30/3](https://static.wixstatic.com/media/427e8e_a1c64498a00b4f2499af9b089307e769~mv2.png/v1/fill/w_1000,h_500,al_c,q_90,usm_0.66_1.00_0.01/427e8e_a1c64498a00b4f2499af9b089307e769~mv2.png) <small>www.sintetufu.org</small>Agenda de greve | 23 a 30/3

Metro Do Porto "fortemente Condicionado" No Dia Da Greve Geral - JPN
--------------------------------------------------------------------

 ![Metro do Porto "fortemente condicionado" no dia da greve geral - JPN](https://www.jpn.up.pt/wp-content/uploads/2025/12/greve_geral1-1152x759.jpg) <small>www.jpn.up.pt</small>Metro do Porto "fortemente condicionado" no dia da greve geral - JPN

Greve Geral. Metro De Lisboa Prevê Paralisação Do Serviço E Encerramento Das Estações – ECO
-------------------------------------------------------------------------------------------

 ![Greve Geral. Metro de Lisboa prevê paralisação do serviço e encerramento das estações – ECO](https://eco.imgix.net/uploads/2025/12/thumb-1.jpg) <small>eco.sapo.pt</small>Greve Geral. Metro de Lisboa prevê paralisação do serviço e encerramento das estações – ECO

Greve Geral Juntou Centenas Nos Aliados. Governo Fala Em Adesão "inexpressiva" - JPN
------------------------------------------------------------------------------------

 ![Greve Geral juntou centenas nos Aliados. Governo fala em adesão "inexpressiva" - JPN](https://www.jpn.up.pt/wp-content/uploads/2025/12/greve_geral9.jpg) <small>www.jpn.up.pt</small>Greve Geral juntou centenas nos Aliados. Governo fala em adesão "inexpressiva" - JPN

AO MINUTO: Greve Geral Para O País. "Forte Adesão" E "impacto Fortíssimo"
-------------------------------------------------------------------------

 ![AO MINUTO: Greve geral para o país. "Forte adesão" e "impacto fortíssimo"](https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA1S86fG.img?w=1920&h=1080&m=4&q=100) <small>www.msn.com</small>AO MINUTO: Greve geral para o país. "Forte adesão" e "impacto fortíssimo"

Transportes, Escolas E Hospitais: O Que Esperar Da Greve De 3 De Junho - Dinheiro - SÁBADO
------------------------------------------------------------------------------------------

 ![Transportes, escolas e hospitais: o que esperar da greve de 3 de junho - Dinheiro - SÁBADO](https://cdn.sabado.pt/images/2026-05/img_980x653uu2026-05-30-11-36-15-766875.jpg) <small>www.sabado.pt</small>Transportes, escolas e hospitais: o que esperar da greve de 3 de junho - Dinheiro - SÁBADO

Esta Semana Há Greve Geral E Constrangimentos Começam (já) Amanhã
-----------------------------------------------------------------

 ![Esta semana há greve geral e constrangimentos começam (já) amanhã](https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA1U62iE.img?w=1920&h=1080&m=4&q=100) <small>www.msn.com</small>Esta semana há greve geral e constrangimentos começam (já) amanhã

Ao Minuto: Convocada Greve Geral; Milhares Esperados Por Todo O País
--------------------------------------------------------------------

 ![Ao minuto: Convocada greve geral; milhares esperados por todo o país](https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA22asuP.img?w=1920&h=1080&m=4&q=100) <small>www.msn.com</small>Ao minuto: Convocada greve geral; milhares esperados por todo o país

Pré-Aviso De Greve – 17 De Abril De 2026 – AE António Correia De Oliveira
-------------------------------------------------------------------------

 ![Pré-Aviso de Greve – 17 de abril de 2026 – AE António Correia de Oliveira](https://www.acoliveira.pt/wp-content/uploads/2026/04/7e9f6ec4-4873-4685-897b-30c62aab02d6.png) <small>www.acoliveira.pt</small>Pré-Aviso de Greve – 17 de abril de 2026 – AE António Correia de Oliveira

Calendário Semanal Da Greve (23 A 27 De Março) | SINTUFAL
---------------------------------------------------------

 ![Calendário semanal da greve (23 a 27 de março) | SINTUFAL](https://site-sintufal.s3.amazonaws.com/uploads/3557/calend-n26_1ffceeb266e5f3b439d01c9d87776afa.jpg) <small>sintufal.org.br</small>Calendário semanal da greve (23 a 27 de março) | SINTUFAL

Greve Geral Paralisa Portugal Contra Precarização De Direitos
-------------------------------------------------------------

 ![Greve geral paralisa Portugal contra precarização de direitos](https://pcdob.org.br/wp-content/uploads/2025/12/Ruas-de-Lisboa-foram-tomadas-por-trabalhadores-durante-a-greve-geral-Rafael-Medeiros-Esquerda.jpg) <small>pcdob.org.br</small>Greve geral paralisa Portugal contra precarização de direitos

Mais De 50 Sindicatos Aderem à Greve Geral Marcada Para 11 De Dezembro
----------------------------------------------------------------------

 ![Mais de 50 sindicatos aderem à greve geral marcada para 11 de dezembro](https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA1QBjfX.img?w=1200&h=800&m=4&q=70) <small>www.msn.com</small>Mais de 50 sindicatos aderem à greve geral marcada para 11 de dezembro

Calendário semanal da greve (23 a 27 de março). Chegou a hora: vamos construir a greve geral a partir de 23 de março!. Esta semana há greve geral e constrangimentos começam (já) amanhã
