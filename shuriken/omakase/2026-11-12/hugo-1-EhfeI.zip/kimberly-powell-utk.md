---
title: "Kimberly Powell Utk - kimberly powell inducted as fellow of the american medical informatics association, announced as ..."
description: "Nvidia aims to bring imaging ai to the people with clara"
date: "2026-01-09"
categories:
- "Uncategorized"
images:
- "https://media.licdn.com/dms/image/v2/D4E10AQEoQkQL3_Sr8w/image-shrink_1280/image-shrink_1280/0/1707382180957?e=2147483647&amp;v=beta&amp;t=0dqql3MYC7lUbb88BTFqqiIbvIz3Tb1NcqvpEZkm5PY"
featuredImage: "https://i1.rgstatic.net/ii/profile.image/807870794842112-1569622815790_Q512/Kimberly-Powell-11.jpg"
featured_image: "https://www.ogs.org/wp-content/uploads/2026/02/Powell-Kimberly-2.png"
image: "https://showme.missouri.edu/wp-content/uploads/2024/06/internet-usage-4x5-2-scaled.jpg"
---

If you are searching about Kimberly Powell honored for pioneering work in health informatics and gerontology you've came to the right page. We have 35 Pictures about Kimberly Powell honored for pioneering work in health informatics and gerontology like Kimberly POWELL | Assistant Professor | PhD, RN | University of Tennessee, TN | UTK | College of, Kimberly POWELL | University of Utah, Utah | UOU | College of Nursing | Research profile and also Nvidia aims to bring imaging AI to the people with Clara | AuntMinnie. Here it is:

Kimberly Powell Honored For Pioneering Work In Health Informatics And Gerontology
---------------------------------------------------------------------------------

 ![Kimberly Powell honored for pioneering work in health informatics and gerontology](https://nursing.missouri.edu/wp-content/uploads/2024/05/Congratulations.png) <small>nursing.missouri.edu</small>Kimberly Powell honored for pioneering work in health informatics and gerontology

Kimberly Powell - Keynote - Ohio Genealogical Society
-----------------------------------------------------

 ![Kimberly Powell - Keynote - Ohio Genealogical Society](https://www.ogs.org/wp-content/uploads/2026/02/Powell-Kimberly-2.png) <small>www.ogs.org</small>Kimberly Powell - Keynote - Ohio Genealogical Society

The Age Of AI In Radiology Is Here – Entelechy Asia
---------------------------------------------------

 ![The age of AI in radiology is here – Entelechy Asia](https://entelechyasia.com/wp-content/uploads/2019/01/kimberly-powell-at-emtech-asia.jpg) <small>entelechyasia.com</small>The age of AI in radiology is here – Entelechy Asia

Kimberly Powell, PMP - Senior Operations &amp; Project Management Executive | PMP | Focused On High
---------------------------------------------------------------------------------------------------

 ![Kimberly Powell, PMP - Senior Operations & Project Management Executive | PMP | Focused on High](https://media.licdn.com/dms/image/v2/D4E03AQEYu2Pv8-YTkg/profile-displayphoto-shrink_200_200/profile-displayphoto-shrink_200_200/0/1729185414021?e=2147483647&v=beta&t=Pa6hUnNnQc_2KjhhtdhccRC97EqOpP8qW8Qs4TYhuwY) <small>www.linkedin.com</small>Kimberly Powell, PMP - Senior Operations &amp; Project Management Executive | PMP | Focused on High ...

Exclusive Interview With Kimberly Powell, VP And General Manager Of NVIDIA Healthcare - MarkTechPost
----------------------------------------------------------------------------------------------------

 ![Exclusive Interview with Kimberly Powell, VP and General Manager of NVIDIA Healthcare - MarkTechPost](https://www.marktechpost.com/wp-content/uploads/2022/04/Interview-2.png) <small>www.marktechpost.com</small>Exclusive Interview with Kimberly Powell, VP and General Manager of NVIDIA Healthcare - MarkTechPost

Kimberly Powell - Student Services Specialist For The Mechanical, Aeronautical &amp; Astronautical
--------------------------------------------------------------------------------------------------

 ![Kimberly Powell - Student Services Specialist for the Mechanical, Aeronautical & Astronautical](https://media.licdn.com/dms/image/v2/D5603AQHG7P7fwrwt1g/profile-displayphoto-shrink_200_200/profile-displayphoto-shrink_200_200/0/1729514339987?e=2147483647&v=beta&t=618YQWbHvXVuH9AxmfnxTKy8myI4emyzsY9P7_amtBs) <small>www.linkedin.com</small>Kimberly Powell - Student Services Specialist for the Mechanical, Aeronautical &amp; Astronautical ...

Kimberly Powell - PhD, RN, FAMIA, FAAN | LinkedIn
-------------------------------------------------

 ![Kimberly Powell - PhD, RN, FAMIA, FAAN | LinkedIn](https://media.licdn.com/dms/image/v2/D4E03AQELNZTNqlomtw/profile-displayphoto-scale_200_200/B4EZiemXJLHoAY-/0/1755007513927?e=2147483647&v=beta&t=9aVHNfS1ADg7fyk_hbUBaCziZDNeQpkjMX0xwrnhkTQ) <small>www.linkedin.com</small>Kimberly Powell - PhD, RN, FAMIA, FAAN | LinkedIn

\#locinternships #libraryofcongress | Kimberly Powell, MBA, PMP
---------------------------------------------------------------

 ![#locinternships #libraryofcongress | Kimberly Powell, MBA, PMP](https://media.licdn.com/dms/image/v2/D5622AQH-9yhDoWzSRg/feedshare-shrink_800/feedshare-shrink_800/0/1691613719431?e=2147483647&v=beta&t=V6h7FJjIMWbICbGHmyK-sIZnB8eFpxVdqNLLvCQujok) <small>www.linkedin.com</small>\#locinternships #libraryofcongress | Kimberly Powell, MBA, PMP

Faculty Staff | College Of Medicine
-----------------------------------

 ![Faculty Staff | College of Medicine](https://public.med.fsu.edu/images/Faculty/Kimberly.Powell.jpg) <small>public.med.fsu.edu</small>Faculty Staff | College of Medicine

Dive Into The Future Of Digital Surgery, Health, And Biology With NVIDIA's VP Of Healthcare And
-----------------------------------------------------------------------------------------------

 ![Dive into the future of digital surgery, health, and biology with NVIDIA's VP of Healthcare and](https://media.licdn.com/dms/image/v2/D5610AQEf18m9u13NPw/image-shrink_800/image-shrink_800/0/1718404075786?e=2147483647&v=beta&t=F-wL667A6hY7CE4c0fp8ufvPB6vLFAUNhCatqrC7jY4) <small>www.linkedin.com</small>Dive into the future of digital surgery, health, and biology with NVIDIA's VP of Healthcare and ...

Generative AI Is Revolutionizing Healthcare, From Drug Discovery To Diagnostics And Post-op Care
------------------------------------------------------------------------------------------------

 ![Generative AI is revolutionizing healthcare, from drug discovery to diagnostics and post-op care](https://media.licdn.com/dms/image/v2/D4D22AQHI7fbK1GV1QQ/feedshare-shrink_2048_1536/feedshare-shrink_2048_1536/0/1717762363344?e=2147483647&v=beta&t=HcXrmL3078ePC82LlnhipxGpfpS2lI088q7m0yCHQ0I) <small>pe.linkedin.com</small>Generative AI is revolutionizing healthcare, from drug discovery to diagnostics and post-op care ...

An Interview With Kimberley Powell (NVIDIA) At The AI Summit, San Francisco (2016). - YouTube
---------------------------------------------------------------------------------------------

 ![An Interview with Kimberley Powell (NVIDIA) at The AI Summit, San Francisco (2016). - YouTube](https://i.ytimg.com/vi/15s952bcezM/maxresdefault.jpg) <small>www.youtube.com</small>An Interview with Kimberley Powell (NVIDIA) at The AI Summit, San Francisco (2016). - YouTube

Kimberly Powell Special Address - Healthcare At GTC | Channah Blocq
-------------------------------------------------------------------

 ![Kimberly Powell Special Address - Healthcare at GTC | Channah Blocq](https://media.licdn.com/dms/image/v2/D4E10AQEoQkQL3_Sr8w/image-shrink_1280/image-shrink_1280/0/1707382180957?e=2147483647&v=beta&t=0dqql3MYC7lUbb88BTFqqiIbvIz3Tb1NcqvpEZkm5PY) <small>www.linkedin.com</small>Kimberly Powell Special Address - Healthcare at GTC | Channah Blocq

NVIDIA: A Nova Fronteira Da Medicina Está Na IA - CM
----------------------------------------------------

 ![NVIDIA: A nova fronteira da Medicina está na IA - CM](https://consumidormoderno.com.br/wp-content/uploads/2025/03/Nvidia_Kimberly-Powell-1024x530.webp) <small>consumidormoderno.com.br</small>NVIDIA: A nova fronteira da Medicina está na IA - CM

What Can Health Care Learn From Self-Driving Cars? | Johns Hopkins Medicine
---------------------------------------------------------------------------

 ![What Can Health Care Learn from Self-Driving Cars? | Johns Hopkins Medicine](https://www.hopkinsmedicine.org/-/media/images/articles/2018/03/kimberly_powell.jpeg?h=640&iar=0&w=640&hash=1741F5E78A512573722D6BEAB32D9288) <small>www.hopkinsmedicine.org</small>What Can Health Care Learn from Self-Driving Cars? | Johns Hopkins Medicine

Kimberly Powell On LinkedIn: #speakupsisawards2024 #susawards2024 #susawardsfinalist2024 #voteforme
---------------------------------------------------------------------------------------------------

 ![Kimberly Powell on LinkedIn: #speakupsisawards2024 #susawards2024 #susawardsfinalist2024 #voteforme](https://media.licdn.com/dms/image/D4D22AQHnpcTAQwDtzg/feedshare-shrink_2048_1536/0/1710527087105?e=2147483647&v=beta&t=ABcsxN8h4u0sB8mJDrZKm9poz4E6UKa_kzE8Y0XAmbE) <small>www.linkedin.com</small>Kimberly Powell on LinkedIn: #speakupsisawards2024 #susawards2024 #susawardsfinalist2024 #voteforme

From The Office To The Lab, Amgen Uses AI Tools To Unlock Innovation | Amgen
----------------------------------------------------------------------------

 ![From the Office to the Lab, Amgen Uses AI Tools to Unlock Innovation | Amgen](https://www.amgen.com/stories/2024/05/-/media/Themes/CorporateAffairs/amgen-com/amgen-com/Images/stories/2024/05-21-From-the-Office-to-the-Lab-Amgen-Uses-AI-Tools-to-Unlock-Innovation/powell.png) <small>www.amgen.com</small>From the Office to the Lab, Amgen Uses AI Tools to Unlock Innovation | Amgen

Kimberly Powell On LinkedIn: Join Me And The CX Heroes Community In May To Talk About Implementing…
---------------------------------------------------------------------------------------------------

 ![Kimberly Powell on LinkedIn: Join me and the CX Heroes community in May to talk about implementing…](https://media.licdn.com/dms/image/D5622AQEby3Y-jXsdeQ/feedshare-shrink_2048_1536/0/1681408291296?e=2147483647&v=beta&t=ofZEijJAo82xsXWxyOfyy1ysPvuYP7bpIGQrK5s9Ut8) <small>www.linkedin.com</small>Kimberly Powell on LinkedIn: Join me and the CX Heroes community in May to talk about implementing…

Staff Directory | University Communications
-------------------------------------------

 ![Staff Directory | University Communications](https://communications.uoregon.edu/sites/default/files/styles/portrait_small/public/2025-02/kimberly-powell-2024.jpeg?h=29deb883&itok=4JTZ-NeY) <small>communications.uoregon.edu</small>Staff Directory | University Communications

Kimberly Powell Inducted As Fellow Of The American Medical Informatics Association, Announced As
------------------------------------------------------------------------------------------------

 ![Kimberly Powell inducted as Fellow of the American Medical Informatics Association, announced as](https://showme.missouri.edu/wp-content/uploads/2024/06/internet-usage-4x5-2-scaled.jpg) <small>showme.missouri.edu</small>Kimberly Powell inducted as Fellow of the American Medical Informatics Association, announced as ...

Kimberly Powell On LinkedIn: Had A Fantastic Time Hosting The PowerUp Strategic Educators
-----------------------------------------------------------------------------------------

 ![Kimberly Powell on LinkedIn: Had a fantastic time hosting the PowerUp Strategic Educators](https://media.licdn.com/dms/image/D5622AQEBItJYa-ypGw/feedshare-shrink_800/0/1708957758233?e=2147483647&v=beta&t=xMzVZhCGZYMoNSETCR7it3dpNlrrkZKiht8hIB45sdI) <small>www.linkedin.com</small>Kimberly Powell on LinkedIn: Had a fantastic time hosting the PowerUp Strategic Educators ...

About Us
--------

 ![About Us](https://img1.wsimg.com/isteam/ip/44d8c6eb-5847-48e2-aff5-373d62931250/blob.png/:/cr=t:0%25,l:0%25,w:100%25,h:67.46%25/rs=w:365,h:365,cg:true) <small>757wecare.org</small>About Us

Nvidia Expands AI Ambitions In Healthcare; Aims To Transform Hospitals With Robotics – Digital
----------------------------------------------------------------------------------------------

 ![Nvidia expands AI ambitions in healthcare; aims to transform hospitals with robotics – Digital](https://digitaleconomymag.com/wp-content/uploads/2024/11/Nvidia-Kimberly-Powel.png) <small>digitaleconomymag.com</small>Nvidia expands AI ambitions in healthcare; aims to transform hospitals with robotics – Digital ...

Board Of Directors — Basic Needs Inc.
-------------------------------------

 ![Board of Directors — Basic Needs Inc.](https://images.squarespace-cdn.com/content/v1/63d48a2e85aa7959f69d2f27/58712eb8-621f-4cbe-b73b-a7e4fbbc934a/Powell_Kim+2005.jpg) <small>www.basicneedsmn.org</small>Board of Directors — Basic Needs Inc.

Sharing Rocky Top Business Sense | UT Knoxville Alumni
------------------------------------------------------

 ![Sharing Rocky Top Business Sense | UT Knoxville Alumni](https://alumni.utk.edu/wp-content/uploads/2025/05/marden-kim-and-powell-kyra-in-neyland-1200x678-1.jpg) <small>alumni.utk.edu</small>Sharing Rocky Top Business Sense | UT Knoxville Alumni

Kimberly POWELL | Pennsylvania State University, PA | Penn State | Department Of Curriculum And
-----------------------------------------------------------------------------------------------

 ![Kimberly POWELL | Pennsylvania State University, PA | Penn State | Department of Curriculum and](https://i1.rgstatic.net/ii/profile.image/807870794842112-1569622815790_Q512/Kimberly-Powell-11.jpg) <small>www.researchgate.net</small>Kimberly POWELL | Pennsylvania State University, PA | Penn State | Department of Curriculum and ...

Kimberly POWELL | Assistant Professor | PhD, RN | University Of Tennessee, TN | UTK | College Of
------------------------------------------------------------------------------------------------

 ![Kimberly POWELL | Assistant Professor | PhD, RN | University of Tennessee, TN | UTK | College of](https://i1.rgstatic.net/ii/profile.image/548708995813376-1507833827958_Q128/Kimberly-Powell-5.jpg) <small>www.researchgate.net</small>Kimberly POWELL | Assistant Professor | PhD, RN | University of Tennessee, TN | UTK | College of ...

Kimberly POWELL | University Of Utah, Utah | UOU | College Of Nursing | Research Profile
----------------------------------------------------------------------------------------

 ![Kimberly POWELL | University of Utah, Utah | UOU | College of Nursing | Research profile](https://i1.rgstatic.net/ii/profile.image/389952421548033-1469983310221_Q512/Kimberly-Powell-2.jpg) <small>www.researchgate.net</small>Kimberly POWELL | University of Utah, Utah | UOU | College of Nursing | Research profile

Welcome To The Team Kimberly Powell ! | Kelvin Kam
--------------------------------------------------

 ![Welcome to the team Kimberly Powell ! | Kelvin Kam](https://media.licdn.com/dms/image/v2/D5622AQFyslA_bU6SmQ/feedshare-shrink_2048_1536/feedshare-shrink_2048_1536/0/1701478818727?e=2147483647&v=beta&t=DJkohkKyaZ_7xCO8qbg4sbuEXtvwp1Ue88oRp9zZehw) <small>www.linkedin.com</small>Welcome to the team Kimberly Powell ! | Kelvin Kam

Hear From Kimberly Powell, Sr. Director Of Deep Learning, On The Highlights Of #CVPR2017
----------------------------------------------------------------------------------------

 ![Hear from Kimberly Powell, Sr. Director of Deep Learning, on the highlights of #CVPR2017](https://lookaside.fbsbx.com/lookaside/crawler/media/?media_id=10155005906623253&get_thumbnail=1) <small>www.facebook.com</small>Hear from Kimberly Powell, Sr. Director of Deep Learning, on the highlights of #CVPR2017 ...

Nvidia's Kimberly Powell Is Leading The Chip Giant's Charge Into AI For Health Care - San
-----------------------------------------------------------------------------------------

 ![Nvidia's Kimberly Powell is leading the chip giant's charge into AI for health care - San](https://media.bizj.us/view/img/12968502/kimberlypowell-1*1200xx9428-5303-0-491.jpg) <small>www.bizjournals.com</small>Nvidia's Kimberly Powell is leading the chip giant's charge into AI for health care - San ...

Kimberly Powell On LinkedIn: Accelerating Generative AI In Biology And Healthcare
---------------------------------------------------------------------------------

 ![Kimberly Powell on LinkedIn: Accelerating Generative AI in Biology and Healthcare](https://media.licdn.com/dms/image/C5610AQE1cSmTeTDugg/image-shrink_800/0/1678898624805?e=2147483647&v=beta&t=L3r_MC6OMP4ctzlhbDJAPKC2RrpU2kiN4DrXxRk5xHA) <small>www.linkedin.com</small>Kimberly Powell on LinkedIn: Accelerating Generative AI in Biology and Healthcare

GTC 2025 – Announcements And Live Updates | NVIDIA Blog
-------------------------------------------------------

 ![GTC 2025 – Announcements and Live Updates | NVIDIA Blog](https://blogs.nvidia.com/wp-content/uploads/2025/03/kptalk-1280x960.jpg) <small>blogs.nvidia.com</small>GTC 2025 – Announcements and Live Updates | NVIDIA Blog

Nvidia Aims To Bring Imaging AI To The People With Clara | AuntMinnie
---------------------------------------------------------------------

 ![Nvidia aims to bring imaging AI to the people with Clara | AuntMinnie](https://img.auntminnie.com/files/base/smg/all/image/2018/04/am.2018_04_10_20_01_4331_Powell_Kimberly_400.png?auto=format%2Ccompress&fit=max&q=70&w=400) <small>www.auntminnie.com</small>Nvidia aims to bring imaging AI to the people with Clara | AuntMinnie

Kimberly Powell Honored For Pioneering Work In Health Informatics And Gerontology
---------------------------------------------------------------------------------

 ![Kimberly Powell honored for pioneering work in health informatics and gerontology](https://nursing.missouri.edu/wp-content/uploads/2024/06/Kimberly-Powell-FAMIA-induction.png) <small>nursing.missouri.edu</small>Kimberly Powell honored for pioneering work in health informatics and gerontology

kimberly powell honored for pioneering work in health informatics and gerontology. From the office to the lab, amgen uses ai tools to unlock innovation. kimberly powell
