---
title: "Greve Geral 12 De Dezembro - greve geral a 11 de dezembro"
description: "greve geral paralisa transportes, saúde e educação no porto"
date: "2026-05-12"
categories:
- "Uncategorized"
images:
- "https://images.impresa.pt/expresso/2025-11-27-greve-geral-anuncio-para-a-realizacao-de-greve-a-11-de-dezembro-marques-pombal--9b289114/original"
featuredImage: "https://horadopovo.com.br/wp-content/uploads/2025/12/Ruas-de-Lisboa-foram-tomadas-por-trabalhadores-durante-a-greve-geral-Rafael-Medeiros-Esquerda.jpg"
featured_image: "https://cdn.cmjornal.pt/images/2025-12/img_1500x1000uu2025-12-10-22-06-51-2253721.jpg"
image: "https://sinapsa.pt/wp-content/uploads/2025/11/Info_Sindical_51_Novembro_2025_Greve_Geral_Site_2.jpg"
---

If you are looking for Entre o dever de informar e a adesão è greve, Sindicato dos Jornalistas faz balanço you've came to the right web. We have 35 Pictures about Entre o dever de informar e a adesão è greve, Sindicato dos Jornalistas faz balanço like Depois da Greve Geral, mais uma paralisação marcada para 12 de dezembro | A Bola, UGT vai reunir-se com ministra do Trabalho mas avisa que "é impossível negociar" sozinha a and also Greve Geral. Metro de Lisboa prevê paralisação do serviço e encerramento das estações – ECO. Here you go:

Entre O Dever De Informar E A Adesão è Greve, Sindicato Dos Jornalistas Faz Balanço
-----------------------------------------------------------------------------------

 ![Entre o dever de informar e a adesão è greve, Sindicato dos Jornalistas faz balanço](https://eco.imgix.net/uploads/2025/12/cropped-greve-geral03.jpg) <small>eco.sapo.pt</small>Entre o dever de informar e a adesão è greve, Sindicato dos Jornalistas faz balanço ...

11 De Dezembro. Portugal Terá A Sua Primeira Greve Geral Em 12 Anos Contra O Pacote Laboral
-------------------------------------------------------------------------------------------

 ![11 de Dezembro. Portugal terá a sua primeira Greve Geral em 12 anos contra o pacote laboral](https://www.esquerdadiario.com.br/IMG/logo/imagem_do_whatsapp_de_2025-11-18_a_s_20.02_31_2e7bdf41.jpg?1763508227) <small>www.esquerdadiario.com.br</small>11 de Dezembro. Portugal terá a sua primeira Greve Geral em 12 anos contra o pacote laboral ...

Revista De Imprensa: Greve Geral Domina O Dia Nos Jornais - JN
--------------------------------------------------------------

 ![Revista de Imprensa: Greve geral domina o dia nos jornais - JN](https://staticx.noticiasilimitadas.pt/jn/image.webp?brand=jn&type=generate&guid=bb587b3b-769b-4983-a511-3d9260d240ec&w=3840) <small>www.jn.pt</small>Revista de Imprensa: Greve geral domina o dia nos jornais - JN

SDP Sul
-------

 ![SDP Sul](https://sdpsul.com/storage/publicacao/imagem_563_6929dba6ddf62.jpeg) <small>sdpsul.com</small>SDP Sul

15 Minutos: Impacto Da Greve Geral Já Se Começou A Sentir No Setor Dos Transportes - SIC Notícias
-------------------------------------------------------------------------------------------------

 ![15 minutos: impacto da greve geral já se começou a sentir no setor dos transportes - SIC Notícias](https://images.impresa.pt/sicnot/2025-12-12-greve-geral-045a9380/1.91x1?wm=true&outputFormat=jpeg) <small>sicnoticias.pt</small>15 minutos: impacto da greve geral já se começou a sentir no setor dos transportes - SIC Notícias

UGT Vai Reunir-se Com Ministra Do Trabalho Mas Avisa Que "é Impossível Negociar" Sozinha A
------------------------------------------------------------------------------------------

 ![UGT vai reunir-se com ministra do Trabalho mas avisa que "é impossível negociar" sozinha a](https://img.iol.pt/image/id/693b2a1ad34e3caad84c47e9/1024.jpg) <small>cnnportugal.iol.pt</small>UGT vai reunir-se com ministra do Trabalho mas avisa que "é impossível negociar" sozinha a ...

Greve Geral Deverá Ter Impacto Inferior A 0,1% Do PIB – ECO
-----------------------------------------------------------

 ![Greve geral deverá ter impacto inferior a 0,1% do PIB – ECO](https://eco.imgix.net/uploads/2025/12/cropped-46141990-scaled.jpg) <small>eco.sapo.pt</small>Greve geral deverá ter impacto inferior a 0,1% do PIB – ECO

Depois Da Greve Geral, Mais Uma Paralisação Marcada Para 12 De Dezembro | A Bola
--------------------------------------------------------------------------------

 ![Depois da Greve Geral, mais uma paralisação marcada para 12 de dezembro | A Bola](https://sportal365images.com/process/smp-images-production/abola.pt/09122025/6efc249f-1534-4fe0-94ae-f9c29c518ecd.webp?operations=scale(860:574)) <small>www.abola.pt</small>Depois da Greve Geral, mais uma paralisação marcada para 12 de dezembro | A Bola

Greve Geral A 11 De Dezembro | Sindicato Dos Quadros Técnicos Do Estado
-----------------------------------------------------------------------

 ![Greve Geral a 11 de Dezembro | Sindicato dos Quadros Técnicos do Estado](https://www.ste.pt/wp-content/uploads/2025/12/GreveGeral-Cartaz-scaled.jpg) <small>www.ste.pt</small>Greve Geral a 11 de Dezembro | Sindicato dos Quadros Técnicos do Estado

Comunicado E Esclarecimentos - Greve Semana 12-17 Dezembro - YouTube
--------------------------------------------------------------------

 ![Comunicado e Esclarecimentos - Greve Semana 12-17 Dezembro - YouTube](https://i.ytimg.com/vi/CoRuIZF3jRU/maxresdefault.jpg) <small>www.youtube.com</small>Comunicado e Esclarecimentos - Greve Semana 12-17 Dezembro - YouTube

Motivos Da Adesão à Greve Geral De 11 De Dezembro De 2025
---------------------------------------------------------

 ![Motivos da adesão à Greve Geral de 11 de dezembro de 2025](https://spzn.pt/uploads/noticias/big_1763717239_6728_SPZN_2025_site_novo_(17).png) <small>spzn.pt</small>Motivos da adesão à Greve Geral de 11 de dezembro de 2025

Greve Geral Paralisa Portugal Contra Precarização De Direitos
-------------------------------------------------------------

 ![Greve geral paralisa Portugal contra precarização de direitos](https://horadopovo.com.br/wp-content/uploads/2025/12/Ruas-de-Lisboa-foram-tomadas-por-trabalhadores-durante-a-greve-geral-Rafael-Medeiros-Esquerda.jpg) <small>horadopovo.com.br</small>Greve geral paralisa Portugal contra precarização de direitos

CGTP Fala De Adesão Massiva à Greve Geral - TSF
-----------------------------------------------

 ![CGTP fala de adesão massiva à greve geral - TSF](https://staticx.noticiasilimitadas.pt/tsf/image.webp?brand=tsf&type=generate&guid=f2fd45e3-0eb3-424b-9e51-c41a22a41e1a&w=3840) <small>www.tsf.pt</small>CGTP fala de adesão massiva à greve geral - TSF

Greve Geral: Escolas Fechadas, Transportes Parados E Impacto Nacional
---------------------------------------------------------------------

 ![Greve Geral: Escolas Fechadas, Transportes Parados e Impacto Nacional](https://media.assettype.com/dn%2F2025-12-11%2F9hy4apil%2Fgreve-geral.jpg?w=768&auto=format%2Ccompress) <small>www.dn.pt</small>Greve Geral: Escolas Fechadas, Transportes Parados e Impacto Nacional

Greve Geral Em Portugal – 11 De Dezembro - FLEMACON
---------------------------------------------------

 ![Greve geral em Portugal – 11 de dezembro - FLEMACON](https://www.flemacon.org/wp-content/uploads/2025/12/WhatsApp-Image-2025-12-12-at-19.45.27-1-696x870.jpeg) <small>www.flemacon.org</small>Greve geral em Portugal – 11 de dezembro - FLEMACON

Há Muitas Razões Para Aderir à Greve Geral - SINAPSA
----------------------------------------------------

 ![Há muitas razões para aderir à Greve Geral - SINAPSA](https://sinapsa.pt/wp-content/uploads/2025/11/Info_Sindical_51_Novembro_2025_Greve_Geral_Site_2.jpg) <small>sinapsa.pt</small>Há muitas razões para aderir à Greve Geral - SINAPSA

Lutar Pela Segurança No Emprego De Todos é Aderir à Greve Geral! - SINAPSA
--------------------------------------------------------------------------

 ![Lutar pela segurança no Emprego de todos é aderir à Greve Geral! - SINAPSA](https://sinapsa.pt/wp-content/uploads/2025/12/Info_Sindical_53_Dezembro_2025_Greve_Geral.jpg) <small>sinapsa.pt</small>Lutar pela segurança no Emprego de todos é aderir à Greve Geral! - SINAPSA

Greve Geral Paralisa Transportes, Saúde E Educação No Porto - Expresso
----------------------------------------------------------------------

 ![Greve geral paralisa transportes, saúde e educação no Porto - Expresso](https://images.impresa.pt/expresso/2025-12-11-rds_15_greve-geral-2025-manifestacao-porto_rds_4314.jpg-f75ffda9/original) <small>expresso.pt</small>Greve geral paralisa transportes, saúde e educação no Porto - Expresso

GREVE GERAL – Protesto Em Frente Da Escola Secundária De Caneças – 11 Dezembro 8h00 – Sindicato
-----------------------------------------------------------------------------------------------

 ![GREVE GERAL – Protesto em frente da Escola Secundária de Caneças – 11 Dezembro 8h00 – Sindicato](https://stop-sindicato.pt/wp-content/uploads/2025/12/S.TO_.P.-Cartaz-Protesto-AE-Canecas-GreveGeral-11Dez-8h-1086x1536.png) <small>stop-sindicato.pt</small>GREVE GERAL – Protesto em frente da Escola Secundária de Caneças – 11 Dezembro 8h00 – Sindicato ...

Pré-Aviso De Greve 11 E 12 De Dezembro
--------------------------------------

 ![Pré-Aviso de Greve 11 e 12 de dezembro](https://static.wixstatic.com/media/1029eb_a6db1017a2334a9abf146e02d7454c28~mv2.png/v1/fill/w_770,h_395,al_c,lg_1,q_85/1029eb_a6db1017a2334a9abf146e02d7454c28~mv2.png) <small>www.aecadaval.com</small>Pré-Aviso de Greve 11 e 12 de dezembro

FENPROF Converge Com Os Restantes Setores Da Administração Pública E Envia Pré-aviso De Greve
---------------------------------------------------------------------------------------------

 ![FENPROF converge com os restantes setores da Administração Pública e envia pré-aviso de greve](https://www.fenprof.pt/media/download/6724C9782B10A339D0E76BFD41D4E50B/greveap_12nov21.jpg) <small>www.fenprof.pt</small>FENPROF converge com os restantes setores da Administração Pública e envia pré-aviso de greve ...

ASSIFECO ADERE À GREVE GERAL DE 11 DE DEZEMBRO — ASSIFECO
---------------------------------------------------------

 ![ASSIFECO ADERE À GREVE GERAL DE 11 DE DEZEMBRO — ASSIFECO](https://www.assifeco.pt/images/2025/12/05/USI BANNER_thumbnail.jpg) <small>www.assifeco.pt</small>ASSIFECO ADERE À GREVE GERAL DE 11 DE DEZEMBRO — ASSIFECO

Agora é GREVE GERAL!
--------------------

 ![Agora é GREVE GERAL!](https://jundiagora.com.br/wp-content/uploads/2023/01/greve-geral.jpg) <small>jundiagora.com.br</small>Agora é GREVE GERAL!

FAQ: Os Direitos Dos Docentes Em Dia De Greve Geral - 11/12/2025
----------------------------------------------------------------

 ![FAQ: Os direitos dos docentes em dia de Greve Geral - 11/12/2025](https://static.wixstatic.com/media/d0f32c_9ff1199ee2c34418af0094a43c516733~mv2.png/v1/fill/w_940,h_788,al_c,q_90,enc_avif,quality_auto/d0f32c_9ff1199ee2c34418af0094a43c516733~mv2.png) <small>www.sprc.pt</small>FAQ: Os direitos dos docentes em dia de Greve Geral - 11/12/2025

Sindicatos Independentes Aderem à Greve Geral Pela Primeira Vez E Juntam-se à UGT E CGTP - Expresso
---------------------------------------------------------------------------------------------------

 ![Sindicatos independentes aderem à greve geral pela primeira vez e juntam-se à UGT e CGTP - Expresso](https://images.impresa.pt/expresso/2025-11-27-greve-geral-anuncio-para-a-realizacao-de-greve-a-11-de-dezembro-marques-pombal--9b289114/original) <small>expresso.pt</small>Sindicatos independentes aderem à greve geral pela primeira vez e juntam-se à UGT e CGTP - Expresso

Greve Geral. Metro De Lisboa Prevê Paralisação Do Serviço E Encerramento Das Estações – ECO
-------------------------------------------------------------------------------------------

 ![Greve Geral. Metro de Lisboa prevê paralisação do serviço e encerramento das estações – ECO](https://eco.imgix.net/uploads/2025/12/thumb-1.jpg) <small>eco.sapo.pt</small>Greve Geral. Metro de Lisboa prevê paralisação do serviço e encerramento das estações – ECO

A Greve Geral De 11 De Dezembro Em 38 Imagens – Observador
----------------------------------------------------------

 ![A greve geral de 11 de dezembro em 38 imagens – Observador](https://bordalo.observador.pt/v2/q:60/rs:fill:1440/c:4096:2730:nowe:0:0/plain/https://s3.observador.pt/wp-content/uploads/2025/12/11173319/dventura-greve-geral-11dez-47-scaled.jpg) <small>observador.pt</small>A greve geral de 11 de dezembro em 38 imagens – Observador

Mapa QZP Carenciados De 2025/26 – Despacho N.º 11200-A/2025 – Apoio à Deslocação – Sindicato S.TO.P.
----------------------------------------------------------------------------------------------------

 ![Mapa QZP carenciados de 2025/26 – Despacho n.º 11200-A/2025 – Apoio à deslocação – Sindicato S.TO.P.](https://stop-sindicato.pt/wp-content/uploads/2025/11/S.TO_.P.-Cartaz-Greve-Geral-Educacao-11Dez2025_x1000-768x1086.png) <small>stop-sindicato.pt</small>Mapa QZP carenciados de 2025/26 – Despacho n.º 11200-A/2025 – Apoio à deslocação – Sindicato S.TO.P.

Aviso Prévio De Greves - 11 E 12 De Dezembro 2025
-------------------------------------------------

 ![Aviso Prévio de Greves - 11 e 12 de dezembro 2025](https://aefernandopessoafeira.pt/images/noticias/2025/aviso-previo-de-greve/aviso-previo-de-greve.jpg) <small>aefernandopessoafeira.pt</small>Aviso Prévio de Greves - 11 e 12 de dezembro 2025

Agrupamento De Escolas De Mira - Pré - Aviso De Greve Para Os Dias 11 E 12 De Dezembro De 2025
----------------------------------------------------------------------------------------------

 ![Agrupamento de Escolas de Mira - Pré - aviso de greve para os dias 11 e 12 de dezembro de 2025](https://www.escolasdemira.pt/images/PR-_AVISO_DE_GREVE_para_os_dias_11_e_12_de_dezembro_de_2025.png) <small>www.escolasdemira.pt</small>Agrupamento de Escolas de Mira - Pré - aviso de greve para os dias 11 e 12 de dezembro de 2025

A Greve Geral De 11 De Dezembro Em 38 Imagens – Observador
----------------------------------------------------------

 ![A greve geral de 11 de dezembro em 38 imagens – Observador](https://bordalo.observador.pt/v2/q:60/rs:fill:1440/c:4096:2730:nowe:0:0/plain/https://s3.observador.pt/wp-content/uploads/2025/12/11173246/dventura-greve-geral-11dez-43-scaled.jpg) <small>observador.pt</small>A greve geral de 11 de dezembro em 38 imagens – Observador

SPN - Fenprof — Adesão Histórica à Greve Geral
----------------------------------------------

 ![SPN - Fenprof — Adesão histórica à greve geral](https://www.spn.pt/Media/Default/Info/68000/500/60/7/grevegeral11dez_cartaz.jpg) <small>www.spn.pt</small>SPN - Fenprof — Adesão histórica à greve geral

As Maiores Greves Gerais Que O Brasil Já Viu | Exame
----------------------------------------------------

 ![As maiores greves gerais que o Brasil já viu | Exame](https://classic.exame.com/wp-content/uploads/2017/04/1986-greve-geral-12-de-dezembro.jpg) <small>exame.com</small>As maiores greves gerais que o Brasil já viu | Exame

CGIL: Greve Geral No Dia 12 De Dezembro Para Protestar Contra A Lei Orçamental - Rádio Miróbriga
------------------------------------------------------------------------------------------------

 ![CGIL: greve geral no dia 12 de dezembro para protestar contra a lei orçamental - Rádio Miróbriga](https://www.radiom24.pt/wp-content/uploads/2025/11/CGIL-greve-geral-no-dia-12-de-dezembro-para-protestar-1024x683.jpg) <small>www.radiom24.pt</small>CGIL: greve geral no dia 12 de dezembro para protestar contra a lei orçamental - Rádio Miróbriga

Greve Geral Pára País 12 Anos Depois - Sociedade - Correio Da Manhã
-------------------------------------------------------------------

 ![Greve geral pára País 12 anos depois - Sociedade - Correio da Manhã](https://cdn.cmjornal.pt/images/2025-12/img_1500x1000uu2025-12-10-22-06-51-2253721.jpg) <small>www.cmjornal.pt</small>Greve geral pára País 12 anos depois - Sociedade - Correio da Manhã

A greve geral de 11 de dezembro em 38 imagens – observador. Agora é greve geral!. Depois da greve geral, mais uma paralisação marcada para 12 de dezembro
