---
title: "Kimberly Powell Np - Hear from kimberly powell, sr. director of deep learning, on the highlights of #cvpr2017 ..."
description: "20 people to know in banking: kimberly powell, huntington national bank"
date: "2026-01-09"
categories:
- "Uncategorized"
images:
- "https://images.crunchbase.com/image/upload/c_thumb,h_256,w_256,f_auto,g_face,z_0.7,q_auto:eco,dpr_1/v1486125205/a5yj10qzswrekrnfpwag.png"
featuredImage: "https://www.marktechpost.com/wp-content/uploads/2022/04/Interview-2.png"
featured_image: "https://consumidormoderno.com.br/wp-content/uploads/2025/03/Nvidia_Kimberly-Powell-1024x530.webp"
image: "https://megaphone.imgix.net/podcasts/25c5f82c-2777-11f0-9b28-f39167168459/image/07e90bf930a6aa2fc971ce0501ed371e.png?ixlib=rails-4.3.1&amp;max-w=3000&amp;max-h=3000&amp;fit=crop&amp;auto=format,compress"
---

If you are searching about Faculty Staff | College of Medicine you've visit to the right web. We have 34 Pictures about Faculty Staff | College of Medicine like Kimberly Powell - Nurse Practitioner | LinkedIn, Kimberly Powell, APRN - Nurse Practitioner in Florence, SC | Healthgrades and also Kimberly Powell inducted as Fellow of the American Medical Informatics Association, announced as. Read more:

Faculty Staff | College Of Medicine
-----------------------------------

 ![Faculty Staff | College of Medicine](https://public.med.fsu.edu/images/Faculty/Kimberly.Powell.jpg) <small>public.med.fsu.edu</small>Faculty Staff | College of Medicine

What Can Health Care Learn From Self-Driving Cars? | Johns Hopkins Medicine
---------------------------------------------------------------------------

 ![What Can Health Care Learn from Self-Driving Cars? | Johns Hopkins Medicine](https://www.hopkinsmedicine.org/-/media/images/articles/2018/03/kimberly_powell.jpeg?h=640&iar=0&w=640&hash=1741F5E78A512573722D6BEAB32D9288) <small>www.hopkinsmedicine.org</small>What Can Health Care Learn from Self-Driving Cars? | Johns Hopkins Medicine

NVIDIA: A Nova Fronteira Da Medicina Está Na IA - CM
----------------------------------------------------

 ![NVIDIA: A nova fronteira da Medicina está na IA - CM](https://consumidormoderno.com.br/wp-content/uploads/2025/03/Nvidia_Kimberly-Powell-1024x530.webp) <small>consumidormoderno.com.br</small>NVIDIA: A nova fronteira da Medicina está na IA - CM

Powell, Kimberly R., APRN | Medical Associates Of Northwest Arkansas
--------------------------------------------------------------------

 ![Powell, Kimberly R., APRN | Medical Associates of Northwest Arkansas](https://mana.md/wp-content/uploads/2022/06/Powell_Kim_headshot.png) <small>mana.md</small>Powell, Kimberly R., APRN | Medical Associates of Northwest Arkansas

NVIDIA Powers Up In Drug Discovery
----------------------------------

 ![NVIDIA Powers Up in Drug Discovery](https://genengnews.com/wp-content/uploads/2020/10/Kimberly-Powell_avatar_1511719112-200x200-1.jpg) <small>www.genengnews.com</small>NVIDIA Powers Up in Drug Discovery

Kimberly Powell Inducted As Fellow Of The American Medical Informatics Association, Announced As
------------------------------------------------------------------------------------------------

 ![Kimberly Powell inducted as Fellow of the American Medical Informatics Association, announced as](https://showme.missouri.edu/wp-content/uploads/2024/06/internet-usage-4x5-2-scaled.jpg) <small>showme.missouri.edu</small>Kimberly Powell inducted as Fellow of the American Medical Informatics Association, announced as ...

AI And Digital Biology: Unlocking The Future Of Drug Discovery With Kimberly Powell | WIRED
-------------------------------------------------------------------------------------------

 ![AI and digital biology: Unlocking the future of drug discovery with Kimberly Powell | WIRED](https://i.ytimg.com/vi/yeCmKq8aOY0/maxresdefault.jpg) <small>www.youtube.com</small>AI and digital biology: Unlocking the future of drug discovery with Kimberly Powell | WIRED ...

Kimberly Powell, APRN - Nurse Practitioner In Florence, SC | Healthgrades
-------------------------------------------------------------------------

 ![Kimberly Powell, APRN - Nurse Practitioner in Florence, SC | Healthgrades](https://dims.healthgrades.com/dims3/MMH/format/webp/?url=https:%2F%2Fphotos.healthgrades.com%2Fimg%2Fprov%2Fx%2Fy%2Fn%2Fxynv2gc_w185h248_v68ff32fb4b61391f7343c8f3e9f5b81883c4f80d.jpg%3Fname%3DKimberly%2520Powell%252C%2520APRN) <small>www.healthgrades.com</small>Kimberly Powell, APRN - Nurse Practitioner in Florence, SC | Healthgrades

20 People To Know In Banking: Kimberly Powell, Huntington National Bank - Pittsburgh Business Times
---------------------------------------------------------------------------------------------------

 ![20 People to Know in Banking: Kimberly Powell, Huntington National Bank - Pittsburgh Business Times](https://media.bizj.us/view/img/12644095/powellkimhuntington*1200xx4046-2282-0-1248.jpg) <small>www.bizjournals.com</small>20 People to Know in Banking: Kimberly Powell, Huntington National Bank - Pittsburgh Business Times

Kimberly Powell - Pennsylvania State University
-----------------------------------------------

 ![Kimberly Powell - Pennsylvania State University](https://0.academia-photos.com/1058553/367697/155199356/s200_kimberly.powell.jpeg) <small>pennstate.academia.edu</small>Kimberly Powell - Pennsylvania State University

Kimberly POWELL | Assistant Professor | PhD, RN | University Of Missouri, Missouri | Mizzou
-------------------------------------------------------------------------------------------

 ![Kimberly POWELL | Assistant Professor | PhD, RN | University of Missouri, Missouri | Mizzou](https://i1.rgstatic.net/ii/profile.image/548708995813376-1507833827958_Q512/Kimberly-Powell-5.jpg) <small>www.researchgate.net</small>Kimberly POWELL | Assistant Professor | PhD, RN | University of Missouri, Missouri | Mizzou ...

How AI Is Revolutionizing Healthcare With Kimberly Powell Of NVIDIA – Health Podcast Network
--------------------------------------------------------------------------------------------

 ![How AI Is Revolutionizing Healthcare with Kimberly Powell of NVIDIA – Health Podcast Network](https://megaphone.imgix.net/podcasts/25c5f82c-2777-11f0-9b28-f39167168459/image/07e90bf930a6aa2fc971ce0501ed371e.png?ixlib=rails-4.3.1&max-w=3000&max-h=3000&fit=crop&auto=format,compress) <small>healthpodcastnetwork.com</small>How AI Is Revolutionizing Healthcare with Kimberly Powell of NVIDIA – Health Podcast Network

Kimberly Powell - College Of Arts &amp; Architecture
----------------------------------------------------

 ![Kimberly Powell - College of Arts & Architecture](https://arts.psu.edu/assets/uploads/directoryImages/_480x480_crop_center-center_80_none/screen_shot.jpg) <small>arts.psu.edu</small>Kimberly Powell - College of Arts &amp; Architecture

Kimberly POWELL | Pennsylvania State University, PA | Penn State | Department Of Curriculum And
-----------------------------------------------------------------------------------------------

 ![Kimberly POWELL | Pennsylvania State University, PA | Penn State | Department of Curriculum and](https://i1.rgstatic.net/ii/profile.image/807870794842112-1569622815790_Q512/Kimberly-Powell-11.jpg) <small>www.researchgate.net</small>Kimberly POWELL | Pennsylvania State University, PA | Penn State | Department of Curriculum and ...

KIMBERLY KIM, NP - Updated October 2025 - 111 Medical Pkwy, Chesapeake, Virginia - Nurse
----------------------------------------------------------------------------------------

 ![KIMBERLY KIM, NP - Updated October 2025 - 111 Medical Pkwy, Chesapeake, Virginia - Nurse](https://s3-media0.fl.yelpcdn.com/bphoto/Npk-M_Y8J-zI_YK7Bd2kXQ/o.jpg) <small>www.yelp.com</small>KIMBERLY KIM, NP - Updated October 2025 - 111 Medical Pkwy, Chesapeake, Virginia - Nurse ...

Kimberly Powell Honored For Pioneering Work In Health Informatics And Gerontology
---------------------------------------------------------------------------------

 ![Kimberly Powell honored for pioneering work in health informatics and gerontology](https://nursing.missouri.edu/wp-content/uploads/2024/05/Congratulations.png) <small>nursing.missouri.edu</small>Kimberly Powell honored for pioneering work in health informatics and gerontology

Kimberly Powell Special Address - Healthcare At GTC | Channah Blocq
-------------------------------------------------------------------

 ![Kimberly Powell Special Address - Healthcare at GTC | Channah Blocq](https://media.licdn.com/dms/image/v2/D4E10AQEoQkQL3_Sr8w/image-shrink_1280/image-shrink_1280/0/1707382180957?e=2147483647&v=beta&t=0dqql3MYC7lUbb88BTFqqiIbvIz3Tb1NcqvpEZkm5PY) <small>www.linkedin.com</small>Kimberly Powell Special Address - Healthcare at GTC | Channah Blocq

Kimberly Powell - Department Of Asian Studies
---------------------------------------------

 ![Kimberly Powell - Department of Asian Studies](https://asian.la.psu.edu/wp-content/uploads/sites/15/elementor/thumbs/kim-powell-pa5m38pq3z30k614xeby5gzgg2ll7bgd14zci6yywc.png) <small>asian.la.psu.edu</small>Kimberly Powell - Department of Asian Studies

Kimberly Powell Honored For Pioneering Work In Health Informatics And Gerontology
---------------------------------------------------------------------------------

 ![Kimberly Powell honored for pioneering work in health informatics and gerontology](https://nursing.missouri.edu/wp-content/uploads/2024/06/Kimberly-Powell-FAMIA-induction.png) <small>nursing.missouri.edu</small>Kimberly Powell honored for pioneering work in health informatics and gerontology

Family Medicine Doctors Near Me In Northglenn, CO
-------------------------------------------------

 ![Family Medicine Doctors near me in Northglenn, CO](https://doximity-res.cloudinary.com/images/f_auto,q_auto,t_public_profile_photo_320x320/vyzwfcajlry7r3bvtqlw/kim-powell-denver-co.jpg) <small>health.usnews.com</small>Family Medicine Doctors near me in Northglenn, CO

Powell, Kimberly R., APRN - Medical Associates Of Northwest Arkansas
--------------------------------------------------------------------

 ![Powell, Kimberly R., APRN - Medical Associates of Northwest Arkansas](https://mana.md/wp-content/uploads/2022/06/Powell_Kim_headshotweb.jpg) <small>mana.md</small>Powell, Kimberly R., APRN - Medical Associates of Northwest Arkansas

Dive Into The Future Of Digital Surgery, Health, And Biology With NVIDIA's VP Of Healthcare And
-----------------------------------------------------------------------------------------------

 ![Dive into the future of digital surgery, health, and biology with NVIDIA's VP of Healthcare and](https://media.licdn.com/dms/image/v2/D5610AQEf18m9u13NPw/image-shrink_800/image-shrink_800/0/1718404075786?e=2147483647&v=beta&t=F-wL667A6hY7CE4c0fp8ufvPB6vLFAUNhCatqrC7jY4) <small>www.linkedin.com</small>Dive into the future of digital surgery, health, and biology with NVIDIA's VP of Healthcare and ...

An Interview With Kimberley Powell (NVIDIA) At The AI Summit, San Francisco (2016). - YouTube
---------------------------------------------------------------------------------------------

 ![An Interview with Kimberley Powell (NVIDIA) at The AI Summit, San Francisco (2016). - YouTube](https://i.ytimg.com/vi/15s952bcezM/maxresdefault.jpg) <small>www.youtube.com</small>An Interview with Kimberley Powell (NVIDIA) at The AI Summit, San Francisco (2016). - YouTube

Exclusive Interview With Kimberly Powell, VP And General Manager Of NVIDIA Healthcare - MarkTechPost
----------------------------------------------------------------------------------------------------

 ![Exclusive Interview with Kimberly Powell, VP and General Manager of NVIDIA Healthcare - MarkTechPost](https://www.marktechpost.com/wp-content/uploads/2022/04/Interview-2.png) <small>www.marktechpost.com</small>Exclusive Interview with Kimberly Powell, VP and General Manager of NVIDIA Healthcare - MarkTechPost

Hear From Kimberly Powell, Sr. Director Of Deep Learning, On The Highlights Of #CVPR2017
----------------------------------------------------------------------------------------

 ![Hear from Kimberly Powell, Sr. Director of Deep Learning, on the highlights of #CVPR2017](https://lookaside.fbsbx.com/lookaside/crawler/media/?media_id=10155005906623253&get_thumbnail=1) <small>www.facebook.com</small>Hear from Kimberly Powell, Sr. Director of Deep Learning, on the highlights of #CVPR2017 ...

Nvidia Looks To Genentech For Its Next Leap In AI Drug Discovery
----------------------------------------------------------------

 ![Nvidia Looks to Genentech for Its Next Leap in AI Drug Discovery](https://www.genengnews.com/wp-content/uploads/2023/11/Kimberly-Powell-NVIDIA-CROPPED11111.jpg) <small>www.genengnews.com</small>Nvidia Looks to Genentech for Its Next Leap in AI Drug Discovery

From The Office To The Lab, Amgen Uses AI Tools To Unlock Innovation | Amgen
----------------------------------------------------------------------------

 ![From the Office to the Lab, Amgen Uses AI Tools to Unlock Innovation | Amgen](https://www.amgen.com/stories/2024/05/-/media/Themes/CorporateAffairs/amgen-com/amgen-com/Images/stories/2024/05-21-From-the-Office-to-the-Lab-Amgen-Uses-AI-Tools-to-Unlock-Innovation/powell.png) <small>www.amgen.com</small>From the Office to the Lab, Amgen Uses AI Tools to Unlock Innovation | Amgen

Kimberly Powell - Nurse Practitioner | LinkedIn
-----------------------------------------------

 ![Kimberly Powell - Nurse Practitioner | LinkedIn](https://media.licdn.com/dms/image/v2/C5603AQF0MDdb46gYPA/profile-displayphoto-shrink_200_200/profile-displayphoto-shrink_200_200/0/1517816306842?e=2147483647&v=beta&t=jV3KuSUolnoDYE7NcPw8Ai65M953Zx3u7Dib_Rw9PRk) <small>www.linkedin.com</small>Kimberly Powell - Nurse Practitioner | LinkedIn

Nvidia Expands AI Ambitions In Healthcare; Aims To Transform Hospitals With Robotics – Digital
----------------------------------------------------------------------------------------------

 ![Nvidia expands AI ambitions in healthcare; aims to transform hospitals with robotics – Digital](https://digitaleconomymag.com/wp-content/uploads/2024/11/Nvidia-Kimberly-Powel.png) <small>digitaleconomymag.com</small>Nvidia expands AI ambitions in healthcare; aims to transform hospitals with robotics – Digital ...

Generative AI Is Revolutionizing Healthcare, From Drug Discovery To Diagnostics And Post-op Care
------------------------------------------------------------------------------------------------

 ![Generative AI is revolutionizing healthcare, from drug discovery to diagnostics and post-op care](https://media.licdn.com/dms/image/v2/D4D22AQHI7fbK1GV1QQ/feedshare-shrink_2048_1536/feedshare-shrink_2048_1536/0/1717762363344?e=2147483647&v=beta&t=HcXrmL3078ePC82LlnhipxGpfpS2lI088q7m0yCHQ0I) <small>pe.linkedin.com</small>Generative AI is revolutionizing healthcare, from drug discovery to diagnostics and post-op care ...

Kimberly Powell - PhD, RN, FAMIA, FAAN | LinkedIn
-------------------------------------------------

 ![Kimberly Powell - PhD, RN, FAMIA, FAAN | LinkedIn](https://media.licdn.com/dms/image/v2/D4E03AQELNZTNqlomtw/profile-displayphoto-scale_200_200/B4EZiemXJLHoAY-/0/1755007513927?e=2147483647&v=beta&t=9aVHNfS1ADg7fyk_hbUBaCziZDNeQpkjMX0xwrnhkTQ) <small>www.linkedin.com</small>Kimberly Powell - PhD, RN, FAMIA, FAAN | LinkedIn

Kimberly Powell - Speech Language Pathologist | LinkedIn
--------------------------------------------------------

 ![Kimberly Powell - Speech Language Pathologist | LinkedIn](https://media.licdn.com/dms/image/v2/C4E03AQGad6PJpLEGrA/profile-displayphoto-shrink_200_200/profile-displayphoto-shrink_200_200/0/1517616680748?e=2147483647&v=beta&t=0kIdF8R4KSg9kR0lU-baZL1JAARdnS570j_qCD7FsDA) <small>www.linkedin.com</small>Kimberly Powell - Speech Language Pathologist | LinkedIn

FDC Welcomes Kimberly Powell, APRN! | Medical Associates Of Northwest Arkansas
------------------------------------------------------------------------------

 ![FDC Welcomes Kimberly Powell, APRN! | Medical Associates of Northwest Arkansas](https://mana.md/wp-content/uploads/2022/06/Powell_KImberly_blog.jpg) <small>mana.md</small>FDC Welcomes Kimberly Powell, APRN! | Medical Associates of Northwest Arkansas

Kimberly Powell - Vice President / General Manager, Healthcare @ NVIDIA - Crunchbase Person Profile
---------------------------------------------------------------------------------------------------

 ![Kimberly Powell - Vice President / General Manager, Healthcare @ NVIDIA - Crunchbase Person Profile](https://images.crunchbase.com/image/upload/c_thumb,h_256,w_256,f_auto,g_face,z_0.7,q_auto:eco,dpr_1/v1486125205/a5yj10qzswrekrnfpwag.png) <small>www.crunchbase.com</small>Kimberly Powell - Vice President / General Manager, Healthcare @ NVIDIA - Crunchbase Person Profile

kimberly powell. Hear from kimberly powell, sr. director of deep learning, on the highlights of #cvpr2017 .... Nvidia: a nova fronteira da medicina está na ia
