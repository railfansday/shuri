---
title: "Greve Geral 13 Janeiro - Greve geral tem atos em pelo menos 123 cidades do país"
description: "Greve geral: o que você precisa saber sobre a tentativa de parar o país pela 1ª vez em 20 anos ..."
date: "2025-12-07"
categories:
- "Uncategorized"
images:
- "https://imagens.ebc.com.br/6nTGXx94tJl_JbpI5sGvDq6UFEU=/1600x800/https://agenciabrasil.ebc.com.br/sites/default/files/atoms/image/913946-rodoviarios_rj_1.jpg?itok=hSlzn7_W"
featuredImage: "https://ichef.bbci.co.uk/ace/ws/640/cpsprodpb/11542/production/_95787907_931378-bancariosbc-9895.jpg.webp"
featured_image: "https://classic.exame.com/wp-content/uploads/2019/06/p19.jpg?resize=920,613"
image: "https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA1QvLq8.img?w=1024&amp;h=576&amp;m=4&amp;q=75"
---

If you are looking for Seminário na Casa do Jornalista discute atualidade da Greve Geral de 1917 – Sindicato dos you've came to the right page. We have 35 Images about Seminário na Casa do Jornalista discute atualidade da Greve Geral de 1917 – Sindicato dos like Depois da greve geral, CGTP convoca manifestação contra pacote laboral para 13 de janeiro - TSF, Décimo-terceiro salário; como pagamento surgiu de greve geral após vitória do Brasil na Copa de and also GREVE GERAL | Trabalhadores das autarquias e sector empresarial rejeitam “pacote laboral”. Read more:

Seminário Na Casa Do Jornalista Discute Atualidade Da Greve Geral De 1917 – Sindicato Dos
-----------------------------------------------------------------------------------------

 ![Seminário na Casa do Jornalista discute atualidade da Greve Geral de 1917 – Sindicato dos](https://www.sjpmg.org.br/wp-content/uploads/2017/06/17-6-5-100-anos-greve-1917-b.jpg) <small>www.sjpmg.org.br</small>Seminário na Casa do Jornalista discute atualidade da Greve Geral de 1917 – Sindicato dos ...

Petroleiros Aprovam Greve Nacional A Partir De 0h De Segunda-feira | Radioagência Nacional
------------------------------------------------------------------------------------------

 ![Petroleiros aprovam greve nacional a partir de 0h de segunda-feira | Radioagência Nacional](https://imagens.ebc.com.br/1gWWvqpL8LPU48VSM4uHsOBC28s=/1170x700/smart/https://agenciabrasil.ebc.com.br/sites/default/files/atoms/image/983468-04112015-_dsc6205.jpg?itok=4I6J4BYU) <small>agenciabrasil.ebc.com.br</small>Petroleiros aprovam greve nacional a partir de 0h de segunda-feira | Radioagência Nacional

Greve Geral Pode Voltar 12 Anos Depois: O Que Está Em Causa E Quais São Os Direitos Dos
---------------------------------------------------------------------------------------

 ![Greve geral pode voltar 12 anos depois: o que está em causa e quais são os direitos dos](https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA1QvLq8.img?w=1024&h=576&m=4&q=75) <small>www.msn.com</small>Greve geral pode voltar 12 anos depois: o que está em causa e quais são os direitos dos ...

Greve Geral: O Que Você Precisa Saber Sobre A Tentativa De Parar O País Pela 1ª Vez Em 20 Anos
----------------------------------------------------------------------------------------------

 ![Greve geral: o que você precisa saber sobre a tentativa de parar o país pela 1ª vez em 20 anos](https://ichef.bbci.co.uk/ace/ws/640/cpsprodpb/17438/production/_95788259_pp_-protesto-em-frente-a-sede-da-petrobras-em-sao-paulo-foto-paulo-pinto-fotos-publicas0015_2.jpg.webp) <small>www.bbc.com</small>Greve geral: o que você precisa saber sobre a tentativa de parar o país pela 1ª vez em 20 anos ...

Depois Da Greve Geral, CGTP Convoca Manifestação Contra Pacote Laboral Para 13 De Janeiro - TSF
-----------------------------------------------------------------------------------------------

 ![Depois da greve geral, CGTP convoca manifestação contra pacote laboral para 13 de janeiro - TSF](https://staticx.noticiasilimitadas.pt/tsf/image.webp?brand=tsf&type=generate&guid=7e6b0af3-e173-45b3-8029-3da7d93c4477&w=3840) <small>www.tsf.pt</small>Depois da greve geral, CGTP convoca manifestação contra pacote laboral para 13 de janeiro - TSF

Esta Semana Há Greve Geral E Constrangimentos Começam (já) Amanhã
-----------------------------------------------------------------

 ![Esta semana há greve geral e constrangimentos começam (já) amanhã](https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA1U62iE.img?w=1920&h=1080&m=4&q=100) <small>www.msn.com</small>Esta semana há greve geral e constrangimentos começam (já) amanhã

Ao Minuto: Convocada Greve Geral; Milhares Esperados Por Todo O País
--------------------------------------------------------------------

 ![Ao minuto: Convocada greve geral; milhares esperados por todo o país](https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA22asuP.img?w=1920&h=1080&m=4&q=100) <small>www.msn.com</small>Ao minuto: Convocada greve geral; milhares esperados por todo o país

Profissionais De Saúde Confirmam Greve Geral A Partir De Sexta-feira
--------------------------------------------------------------------

 ![Profissionais de Saúde confirmam Greve Geral a partir de sexta-feira](https://mznews.co.mz/wp-content/uploads/2023/08/medicos-greve-1320x743.jpg) <small>mznews.co.mz</small>Profissionais de Saúde confirmam Greve Geral a partir de sexta-feira

Após Dia De Greve, Protestos Tomam Av. Paulista E Candelária; Veja Fotos | Exame
--------------------------------------------------------------------------------

 ![Após dia de greve, protestos tomam Av. Paulista e Candelária; veja fotos | Exame](https://classic.exame.com/wp-content/uploads/2019/06/p19.jpg?resize=920,613) <small>exame.com</small>Após dia de greve, protestos tomam Av. Paulista e Candelária; veja fotos | Exame

Há 100 Anos, Ocorria A Primeira Greve Geral No Brasil | Nova Escola
-------------------------------------------------------------------

 ![Há 100 anos, ocorria a primeira greve geral no Brasil | Nova Escola](https://nova-escola-producao.s3.amazonaws.com/2mWWWyKhRvvC2GmGkBXvV96JX5eUu2CqN773hMu8SDYn2aZxKS9pj5FcHN9d/grevegeralde1917-3.gif) <small>novaescola.org.br</small>Há 100 anos, ocorria a primeira greve geral no Brasil | Nova Escola

GREVE GERAL | Trabalhadores Das Autarquias E Sector Empresarial Rejeitam “pacote Laboral”
-----------------------------------------------------------------------------------------

 ![GREVE GERAL | Trabalhadores das autarquias e sector empresarial rejeitam “pacote laboral”](https://www.stal.pt/images/2025/Manif_GreveGeral.jpg) <small>www.stal.pt</small>GREVE GERAL | Trabalhadores das autarquias e sector empresarial rejeitam “pacote laboral”

Greve Geral Juntou Centenas Nos Aliados. Governo Fala Em Adesão "inexpressiva" - JPN
------------------------------------------------------------------------------------

 ![Greve Geral juntou centenas nos Aliados. Governo fala em adesão "inexpressiva" - JPN](https://www.jpn.up.pt/wp-content/uploads/2025/12/greve_geral6.jpg) <small>www.jpn.up.pt</small>Greve Geral juntou centenas nos Aliados. Governo fala em adesão "inexpressiva" - JPN

AO MINUTO: Greve Geral Para O País. "Forte Adesão" E "impacto Fortíssimo"
-------------------------------------------------------------------------

 ![AO MINUTO: Greve geral para o país. "Forte adesão" e "impacto fortíssimo"](https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA1S86fG.img?w=1920&h=1080&m=4&q=100) <small>www.msn.com</small>AO MINUTO: Greve geral para o país. "Forte adesão" e "impacto fortíssimo"

Metro Do Porto "fortemente Condicionado" No Dia Da Greve Geral - JPN
--------------------------------------------------------------------

 ![Metro do Porto "fortemente condicionado" no dia da greve geral - JPN](https://www.jpn.up.pt/wp-content/uploads/2025/12/greve_geral1-1152x759.jpg) <small>www.jpn.up.pt</small>Metro do Porto "fortemente condicionado" no dia da greve geral - JPN

Greve Geral Juntou Centenas Nos Aliados. Governo Fala Em Adesão "inexpressiva" - JPN
------------------------------------------------------------------------------------

 ![Greve Geral juntou centenas nos Aliados. Governo fala em adesão "inexpressiva" - JPN](https://www.jpn.up.pt/wp-content/uploads/2025/12/greve_geral9.jpg) <small>www.jpn.up.pt</small>Greve Geral juntou centenas nos Aliados. Governo fala em adesão "inexpressiva" - JPN

Décimo-terceiro Salário; Como Pagamento Surgiu De Greve Geral Após Vitória Do Brasil Na Copa De
-----------------------------------------------------------------------------------------------

 ![Décimo-terceiro salário; como pagamento surgiu de greve geral após vitória do Brasil na Copa de](https://ichef.bbci.co.uk/ace/ws/640/cpsprodpb/f292/live/37f24e30-8d88-11ef-b3c2-754b6219680e.png.webp) <small>www.bbc.com</small>Décimo-terceiro salário; como pagamento surgiu de greve geral após vitória do Brasil na Copa de ...

Balanço Da Greve Geral - CGTP-IN
--------------------------------

 ![Balanço da Greve Geral - CGTP-IN](https://www.cgtp.pt/images/images/2025/11/gg_banner2025.jpg) <small>www.cgtp.pt</small>Balanço da Greve Geral - CGTP-IN

Motivos Da Adesão à Greve Geral De 11 De Dezembro De 2025
---------------------------------------------------------

 ![Motivos da adesão à Greve Geral de 11 de dezembro de 2025](https://fne.pt/uploads/noticias/big_1763657174_7468_SiteGREVE11dez25.jpeg) <small>fne.pt</small>Motivos da adesão à Greve Geral de 11 de dezembro de 2025

Professores Da Rede Pública Fazem Greve E Protesto No Rio De Janeiro | Agência Brasil
-------------------------------------------------------------------------------------

 ![Professores da rede pública fazem greve e protesto no Rio de Janeiro | Agência Brasil](https://imagens.ebc.com.br/FqkyJKWiep5b7wWtG-iXQQUWRcA=/1600x800/https://agenciabrasil.ebc.com.br/sites/default/files/thumbnails/image/2026/04/09/_d6a9768_1.jpg?itok=6hodtIHP) <small>agenciabrasil.ebc.com.br</small>Professores da rede pública fazem greve e protesto no Rio de Janeiro | Agência Brasil

Greve Geral - FECESC
--------------------

 ![greve geral - FECESC](https://www.fecesc.org.br/siteprincipal/wp-content/uploads/2017/04/greve-geral.jpg) <small>www.fecesc.org.br</small>greve geral - FECESC

Atos Pela Greve Geral E Contra A Reforma Trabalhista
----------------------------------------------------

 ![Atos pela Greve Geral e contra a Reforma Trabalhista](https://cdn77.pressenza.com/wp-content/uploads/2017/07/13.jpg) <small>www.pressenza.com</small>Atos pela Greve Geral e contra a Reforma Trabalhista

Greve Geral Tem Atos Em Pelo Menos 123 Cidades Do País | Política | Valor Econômico
-----------------------------------------------------------------------------------

 ![Greve geral tem atos em pelo menos 123 cidades do país | Política | Valor Econômico](https://s2-valor.glbimg.com/yhBieNVzb_pHsf_trf3MA1Ta6gM=/1200x/smart/filters:cover():strip_icc()/i.s3.glbimg.com/v1/AUTH_63b422c2caee4269b8b34177e8876b93/internal_photos/bs/2019/A/Y/AdN6l6QX6ELW498Ho1Ng/protesto14junho.jpg) <small>valor.globo.com</small>Greve geral tem atos em pelo menos 123 cidades do país | Política | Valor Econômico

Greve Geral: Imagens Das Manifestações - Jornal O Globo
-------------------------------------------------------

 ![Greve geral: imagens das manifestações - Jornal O Globo](https://ogimg.infoglobo.com.br/in/23741593-d28-d1f/FT1086A/760/greve-geral-previdencia.jpg) <small>oglobo.globo.com</small>Greve geral: imagens das manifestações - Jornal O Globo

Professores Da Rede Pública Fazem Greve E Protesto No Rio De Janeiro | Agência Brasil
-------------------------------------------------------------------------------------

 ![Professores da rede pública fazem greve e protesto no Rio de Janeiro | Agência Brasil](https://imagens.ebc.com.br/xrBBz93BJxi4wTJmdImw6_Ne2SE=/1600x800/https://agenciabrasil.ebc.com.br/sites/default/files/thumbnails/image/2026/04/09/_d6a9858.jpg?itok=ryDKmZtj) <small>agenciabrasil.ebc.com.br</small>Professores da rede pública fazem greve e protesto no Rio de Janeiro | Agência Brasil

Greve Geral – Ibase
-------------------

 ![greve geral – Ibase](https://ibase.br/wp-content/uploads/2017/04/greve-geral.jpg) <small>ibase.br</small>greve geral – Ibase

Greve Geral: O Que Você Precisa Saber Sobre A Tentativa De Parar O País Pela 1ª Vez Em 20 Anos
----------------------------------------------------------------------------------------------

 ![Greve geral: o que você precisa saber sobre a tentativa de parar o país pela 1ª vez em 20 anos](https://p2.trrsf.com/image/fget/cf/648/0/images.terra.com/2017/04/27/95818331e3c5a7de-1d73-435a-a64c-6edfb0c1fd11.jpg) <small>www.terra.com.br</small>Greve geral: o que você precisa saber sobre a tentativa de parar o país pela 1ª vez em 20 anos

Medo De Demissões E Fragilização De Sindicatos Prejudicam Adesão à Greve - 14/06/2019 - UOL Notícias
----------------------------------------------------------------------------------------------------

 ![Medo de demissões e fragilização de sindicatos prejudicam adesão à greve - 14/06/2019 - UOL Notícias](http://conteudo.imguol.com.br/c/noticias/90/2019/06/14/14jun2019---homem-caminha-proximo-a-banco-no-centro-do-rio-de-janeiro-em-dia-de-greve-geral-1560535753767_v2_1920x1287.jpg) <small>noticias.uol.com.br</small>Medo de demissões e fragilização de sindicatos prejudicam adesão à greve - 14/06/2019 - UOL Notícias

Greve Geral | VEJA
------------------

 ![Greve Geral | VEJA](https://veja.abril.com.br/wp-content/uploads/2017/04/brasil-greve-rj-20170428-002.jpg?quality=90&strip=info&w=920&w=636) <small>veja.abril.com.br</small>Greve Geral | VEJA

Medo De Demissões E Fragilização De Sindicatos Prejudicam Adesão à Greve - 14/06/2019 - UOL Notícias
----------------------------------------------------------------------------------------------------

 ![Medo de demissões e fragilização de sindicatos prejudicam adesão à greve - 14/06/2019 - UOL Notícias](http://conteudo.imguol.com.br/c/noticias/1a/2019/06/14/14junho2019---no-rio-de-janeiro-manifestante-defende-motivos-da-greve-geral-1560543729182_v2_1920x1281.jpg) <small>noticias.uol.com.br</small>Medo de demissões e fragilização de sindicatos prejudicam adesão à greve - 14/06/2019 - UOL Notícias

Após Dia De Greve, Protestos Tomam Av. Paulista E Candelária; Veja Fotos | Exame
--------------------------------------------------------------------------------

 ![Após dia de greve, protestos tomam Av. Paulista e Candelária; veja fotos | Exame](https://classic.exame.com/wp-content/uploads/2019/06/p1.jpg?resize=920,613) <small>exame.com</small>Após dia de greve, protestos tomam Av. Paulista e Candelária; veja fotos | Exame

Manifestação Em Frente Ao Parlamento Resultou Em Seis Detidos: Tudo Sobre A Greve Geral
---------------------------------------------------------------------------------------

 ![Manifestação em frente ao Parlamento resultou em seis detidos: tudo sobre a greve geral](https://cdn.sabado.pt/images/2025-12/img_1320x742uu2025-12-11-15-03-48-752830.jpg) <small>www.sabado.pt</small>Manifestação em frente ao Parlamento resultou em seis detidos: tudo sobre a greve geral ...

Trabalhadores Dos Correios Reforçam A Greve Geral No Rio De Janeiro - SINTECT-RJ | SINTECT-RJ
---------------------------------------------------------------------------------------------

 ![Trabalhadores dos Correios reforçam a Greve Geral no Rio de Janeiro - SINTECT-RJ | SINTECT-RJ](https://sintectrj.org.br/wp-content/uploads/2019/06/destaque_sintect_rj_GREVE_GERAL_ECETSITAS_17_06_2019.png) <small>sintectrj.org.br</small>Trabalhadores dos Correios reforçam a Greve Geral no Rio de Janeiro - SINTECT-RJ | SINTECT-RJ

Greve Geral Paralisa Portugal Contra Precarização De Direitos
-------------------------------------------------------------

 ![Greve geral paralisa Portugal contra precarização de direitos](https://pcdob.org.br/wp-content/uploads/2025/12/Ruas-de-Lisboa-foram-tomadas-por-trabalhadores-durante-a-greve-geral-Rafael-Medeiros-Esquerda.jpg) <small>pcdob.org.br</small>Greve geral paralisa Portugal contra precarização de direitos

Greve Geral: O Que Você Precisa Saber Sobre A Tentativa De Parar O País Pela 1ª Vez Em 20 Anos
----------------------------------------------------------------------------------------------

 ![Greve geral: o que você precisa saber sobre a tentativa de parar o país pela 1ª vez em 20 anos](https://ichef.bbci.co.uk/ace/ws/640/cpsprodpb/11542/production/_95787907_931378-bancariosbc-9895.jpg.webp) <small>www.bbc.com</small>Greve geral: o que você precisa saber sobre a tentativa de parar o país pela 1ª vez em 20 anos ...

Rodoviários Do Rio De Janeiro Fazem Greve | Agência Brasil
----------------------------------------------------------

 ![Rodoviários do Rio de Janeiro fazem greve | Agência Brasil](https://imagens.ebc.com.br/6nTGXx94tJl_JbpI5sGvDq6UFEU=/1600x800/https://agenciabrasil.ebc.com.br/sites/default/files/atoms/image/913946-rodoviarios_rj_1.jpg?itok=hSlzn7_W) <small>agenciabrasil.ebc.com.br</small>Rodoviários do Rio de Janeiro fazem greve | Agência Brasil

Depois da greve geral, cgtp convoca manifestação contra pacote laboral para 13 de janeiro. Medo de demissões e fragilização de sindicatos prejudicam adesão à greve. Há 100 anos, ocorria a primeira greve geral no brasil
