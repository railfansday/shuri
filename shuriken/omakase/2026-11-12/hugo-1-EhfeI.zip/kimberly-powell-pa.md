---
title: "Kimberly Powell Pa - kimberly powell"
description: "kimberly powell"
date: "2026-10-19"
categories:
- "Uncategorized"
images:
- "https://media.licdn.com/dms/image/v2/D4D03AQEI7dApM_pS0A/profile-displayphoto-shrink_200_200/profile-displayphoto-shrink_200_200/0/1718265597191?e=2147483647&amp;v=beta&amp;t=UqlYf0lvLCxChjAm3LYOWWyDml1oBQuy3uJwdlMGceU"
featuredImage: "https://media.licdn.com/dms/image/D4D22AQHnpcTAQwDtzg/feedshare-shrink_2048_1536/0/1710527087105?e=2147483647&amp;v=beta&amp;t=ABcsxN8h4u0sB8mJDrZKm9poz4E6UKa_kzE8Y0XAmbE"
featured_image: "https://media.bizj.us/view/img/12644095/powellkimhuntington*1200xx4046-2282-0-1248.jpg"
image: "https://i1.rgstatic.net/ii/profile.image/807870794842112-1569622815790_Q512/Kimberly-Powell-11.jpg"
---

If you are looking for Kimberly POWELL | Pennsylvania State University, PA | Penn State | Department of Curriculum and you've visit to the right page. We have 35 Pictures about Kimberly POWELL | Pennsylvania State University, PA | Penn State | Department of Curriculum and like Kimberly POWELL | Pennsylvania State University, PA | Penn State | Department of Curriculum and, Kimberly Powell - Pennsylvania State University and also Nvidia Looks to Genentech for Its Next Leap in AI Drug Discovery. Here it is:

Kimberly POWELL | Pennsylvania State University, PA | Penn State | Department Of Curriculum And
-----------------------------------------------------------------------------------------------

 ![Kimberly POWELL | Pennsylvania State University, PA | Penn State | Department of Curriculum and](https://i1.rgstatic.net/ii/profile.image/807870794842112-1569622815790_Q512/Kimberly-Powell-11.jpg) <small>www.researchgate.net</small>Kimberly POWELL | Pennsylvania State University, PA | Penn State | Department of Curriculum and ...

Kim Powell's Instagram, Twitter &amp; Facebook On IDCrawl
---------------------------------------------------------

 ![Kim Powell's Instagram, Twitter & Facebook on IDCrawl](https://www.belmont.edu/profiles/kim-powell/_images/kim-powell.jpg) <small>www.idcrawl.com</small>Kim Powell's Instagram, Twitter &amp; Facebook on IDCrawl

Kimberly Powell On LinkedIn: Had A Fantastic Time Hosting The PowerUp Strategic Educators
-----------------------------------------------------------------------------------------

 ![Kimberly Powell on LinkedIn: Had a fantastic time hosting the PowerUp Strategic Educators](https://media.licdn.com/dms/image/D5622AQEBItJYa-ypGw/feedshare-shrink_800/0/1708957758233?e=2147483647&v=beta&t=xMzVZhCGZYMoNSETCR7it3dpNlrrkZKiht8hIB45sdI) <small>www.linkedin.com</small>Kimberly Powell on LinkedIn: Had a fantastic time hosting the PowerUp Strategic Educators ...

Kimberly Powell, MBA, PMP On LinkedIn: Maya Cade Shares Her Experiences As CCDI Scholar-in
------------------------------------------------------------------------------------------

 ![Kimberly Powell, MBA, PMP on LinkedIn: Maya Cade Shares Her Experiences as CCDI Scholar-in](https://media.licdn.com/dms/image/sync/v2/D4E27AQEv-QMu_2IxFw/articleshare-shrink_800/articleshare-shrink_800/0/1711419092350?e=2147483647&v=beta&t=Ts4BMRgamjuXwpcngfzZAF2SjeR8_aTxyPWYabn70vU) <small>www.linkedin.com</small>Kimberly Powell, MBA, PMP on LinkedIn: Maya Cade Shares Her Experiences as CCDI Scholar-in ...

Kimberly Powell - Retired But Looking For Part Time Positions | LinkedIn
------------------------------------------------------------------------

 ![Kimberly Powell - Retired but looking for part time positions | LinkedIn](https://media.licdn.com/dms/image/v2/D4D03AQEI7dApM_pS0A/profile-displayphoto-shrink_200_200/profile-displayphoto-shrink_200_200/0/1718265597191?e=2147483647&v=beta&t=UqlYf0lvLCxChjAm3LYOWWyDml1oBQuy3uJwdlMGceU) <small>www.linkedin.com</small>Kimberly Powell - Retired but looking for part time positions | LinkedIn

Nvidia Looks To Genentech For Its Next Leap In AI Drug Discovery
----------------------------------------------------------------

 ![Nvidia Looks to Genentech for Its Next Leap in AI Drug Discovery](https://www.genengnews.com/wp-content/uploads/2023/11/Kimberly-Powell-NVIDIA-CROPPED11111.jpg) <small>www.genengnews.com</small>Nvidia Looks to Genentech for Its Next Leap in AI Drug Discovery

Kimberly Powell - Augusta Health
--------------------------------

 ![Kimberly Powell - Augusta Health](https://www.augustahealth.com/wp-content/uploads/2023/04/Kim-Powell-2-300x300.jpg) <small>www.augustahealth.com</small>Kimberly Powell - Augusta Health

Kimberly Powell - PhD, RN, FAMIA, FAAN | LinkedIn
-------------------------------------------------

 ![Kimberly Powell - PhD, RN, FAMIA, FAAN | LinkedIn](https://media.licdn.com/dms/image/v2/D4E03AQELNZTNqlomtw/profile-displayphoto-scale_200_200/B4EZiemXJLHoAY-/0/1755007513927?e=2147483647&v=beta&t=9aVHNfS1ADg7fyk_hbUBaCziZDNeQpkjMX0xwrnhkTQ) <small>www.linkedin.com</small>Kimberly Powell - PhD, RN, FAMIA, FAAN | LinkedIn

Kim Powell – SENIOR ASSOCIATE, OFFICE MANAGER – LandDesign
----------------------------------------------------------

 ![Kim Powell – SENIOR ASSOCIATE, OFFICE MANAGER – LandDesign](https://landdesign.com/wp-content/uploads/2015/05/Portrait_1356x1694-KimSchneider.jpg) <small>landdesign.com</small>Kim Powell – SENIOR ASSOCIATE, OFFICE MANAGER – LandDesign

Kimberly Powell - Vendor Manager - Cricket Wireless | LinkedIn
--------------------------------------------------------------

 ![Kimberly Powell - Vendor Manager - Cricket Wireless | LinkedIn](https://media.licdn.com/dms/image/C4D03AQEM8l-ceokP0g/profile-displayphoto-shrink_800_800/0/1625234024608?e=2147483647&v=beta&t=yuTwtwzeWsuqXRr60NCGM4C3AmKB_OuM8b1Bwo7Epkk) <small>www.linkedin.com</small>Kimberly Powell - Vendor Manager - Cricket Wireless | LinkedIn

Kimberly Powell On LinkedIn: I Am Honored To Have Been Nominated And Awarded The BAM WW - Gerald
------------------------------------------------------------------------------------------------

 ![Kimberly Powell on LinkedIn: I am honored to have been nominated and awarded the BAM WW - Gerald](https://media.licdn.com/dms/image/D5622AQHpO63Gdvh9pA/feedshare-shrink_2048_1536/0/1686869396106?e=2147483647&v=beta&t=br0qoF38jSsM6UDaZFY07EPc3IwdUveCofo65zD08K8) <small>www.linkedin.com</small>Kimberly Powell on LinkedIn: I am honored to have been nominated and awarded the BAM WW - Gerald ...

Kimberly Powell Page - Administrative Assistant At Ogeechee Technical College | LinkedIn
----------------------------------------------------------------------------------------

 ![Kimberly Powell Page - Administrative Assistant at Ogeechee Technical College | LinkedIn](https://media.licdn.com/dms/image/v2/C4E03AQEPRGqSSaMOJA/profile-displayphoto-shrink_200_200/profile-displayphoto-shrink_200_200/0/1542385435752?e=2147483647&v=beta&t=aFyRZ_BkfBqkOWLkc2A_uZBTWb54OLzdUZEuLvD2I4o) <small>www.linkedin.com</small>Kimberly Powell Page - Administrative Assistant at Ogeechee Technical College | LinkedIn

Dive Into The Future Of Digital Surgery, Health, And Biology With NVIDIA's VP Of Healthcare And
-----------------------------------------------------------------------------------------------

 ![Dive into the future of digital surgery, health, and biology with NVIDIA's VP of Healthcare and](https://media.licdn.com/dms/image/v2/D5610AQEf18m9u13NPw/image-shrink_800/image-shrink_800/0/1718404075786?e=2147483647&v=beta&t=F-wL667A6hY7CE4c0fp8ufvPB6vLFAUNhCatqrC7jY4) <small>www.linkedin.com</small>Dive into the future of digital surgery, health, and biology with NVIDIA's VP of Healthcare and ...

Family Medicine Doctors Near Me In Northglenn, CO
-------------------------------------------------

 ![Family Medicine Doctors near me in Northglenn, CO](https://doximity-res.cloudinary.com/images/f_auto,q_auto,t_public_profile_photo_320x320/vyzwfcajlry7r3bvtqlw/kim-powell-denver-co.jpg) <small>health.usnews.com</small>Family Medicine Doctors near me in Northglenn, CO

Store 1 — Monmouth County Genealogy Society
-------------------------------------------

 ![Store 1 — Monmouth County Genealogy Society](https://images.squarespace-cdn.com/content/v1/5e13cf64d27b8e7f7fed649c/92bb66e6-ef18-46a9-b852-0ab884324205/Kimberly+Powell+-+headshot+2023+cropped+sm.png?format=1000w) <small>www.njmcgs.org</small>Store 1 — Monmouth County Genealogy Society

Kim Powell, LCPC | Therapist In Chicago | Proactive Therapy — Proactive Therapy
-------------------------------------------------------------------------------

 ![Kim Powell, LCPC | Therapist in Chicago | Proactive Therapy — Proactive Therapy](https://images.squarespace-cdn.com/content/v1/5d2609ffe8dd35000171e596/7b645ca6-1ca3-43b9-a765-302ceb9639f5/KPowell+Headshot+2024.jpg) <small>www.proactive-therapy.com</small>Kim Powell, LCPC | Therapist in Chicago | Proactive Therapy — Proactive Therapy

Kimberly Powell - College Of Arts &amp; Architecture
----------------------------------------------------

 ![Kimberly Powell - College of Arts & Architecture](https://arts.psu.edu/assets/uploads/directoryImages/_480x480_crop_center-center_80_none/screen_shot.jpg) <small>arts.psu.edu</small>Kimberly Powell - College of Arts &amp; Architecture

Generative AI Is Revolutionizing Healthcare, From Drug Discovery To Diagnostics And Post-op Care
------------------------------------------------------------------------------------------------

 ![Generative AI is revolutionizing healthcare, from drug discovery to diagnostics and post-op care](https://media.licdn.com/dms/image/v2/D4D22AQHI7fbK1GV1QQ/feedshare-shrink_2048_1536/feedshare-shrink_2048_1536/0/1717762363344?e=2147483647&v=beta&t=HcXrmL3078ePC82LlnhipxGpfpS2lI088q7m0yCHQ0I) <small>pe.linkedin.com</small>Generative AI is revolutionizing healthcare, from drug discovery to diagnostics and post-op care ...

What Can Health Care Learn From Self-Driving Cars? | Johns Hopkins Medicine
---------------------------------------------------------------------------

 ![What Can Health Care Learn from Self-Driving Cars? | Johns Hopkins Medicine](https://www.hopkinsmedicine.org/-/media/images/articles/2018/03/kimberly_powell.jpeg?h=640&iar=0&w=640&hash=1741F5E78A512573722D6BEAB32D9288) <small>www.hopkinsmedicine.org</small>What Can Health Care Learn from Self-Driving Cars? | Johns Hopkins Medicine

Kimberly Powell - Human Resources - BOSS Crane &amp; Rigging | LinkedIn
-----------------------------------------------------------------------

 ![Kimberly Powell - Human Resources - BOSS Crane & Rigging | LinkedIn](https://media.licdn.com/dms/image/D5603AQEXfis-Hbrfhg/profile-displayphoto-shrink_800_800/0/1685802318985?e=2147483647&v=beta&t=OGDfazO4VN6cRyowwDf_V0TKsvUS9iJRYTOOfSVXbNc) <small>www.linkedin.com</small>Kimberly Powell - Human Resources - BOSS Crane &amp; Rigging | LinkedIn

Kimberly Powell - Federal Cybersecurity Analyst | | Security Architecture Enterprise
------------------------------------------------------------------------------------

 ![Kimberly Powell - Federal Cybersecurity Analyst | | Security Architecture Enterprise](https://media.licdn.com/dms/image/v2/D4E03AQHf6Yx1tOaXCQ/profile-displayphoto-scale_200_200/B4EZvjsxCZJAAY-/0/1769051722281?e=2147483647&v=beta&t=UOjMcwZafuKlXgdI61I0hti_3ZXbs2LOpiufYIR0ZWk) <small>www.linkedin.com</small>Kimberly Powell - Federal Cybersecurity Analyst | | Security Architecture Enterprise ...

20 People To Know In Banking: Kimberly Powell, Huntington National Bank - Pittsburgh Business Times
---------------------------------------------------------------------------------------------------

 ![20 People to Know in Banking: Kimberly Powell, Huntington National Bank - Pittsburgh Business Times](https://media.bizj.us/view/img/12644095/powellkimhuntington*1200xx4046-2282-0-1248.jpg) <small>www.bizjournals.com</small>20 People to Know in Banking: Kimberly Powell, Huntington National Bank - Pittsburgh Business Times

Exclusive Interview With Kimberly Powell, VP And General Manager Of NVIDIA Healthcare - MarkTechPost
----------------------------------------------------------------------------------------------------

 ![Exclusive Interview with Kimberly Powell, VP and General Manager of NVIDIA Healthcare - MarkTechPost](https://www.marktechpost.com/wp-content/uploads/2022/04/Interview-2.png) <small>www.marktechpost.com</small>Exclusive Interview with Kimberly Powell, VP and General Manager of NVIDIA Healthcare - MarkTechPost

Kimberly Powell - Pennsylvania State University
-----------------------------------------------

 ![Kimberly Powell - Pennsylvania State University](https://0.academia-photos.com/1058553/367697/155199356/s200_kimberly.powell.jpeg) <small>pennstate.academia.edu</small>Kimberly Powell - Pennsylvania State University

Kimberly Powell - Educational Leadership | LinkedIn
---------------------------------------------------

 ![Kimberly Powell - Educational Leadership | LinkedIn](https://media.licdn.com/dms/image/v2/C4D03AQFvbnGF5URDTA/profile-displayphoto-shrink_200_200/profile-displayphoto-shrink_200_200/0/1659223261194?e=2147483647&v=beta&t=9SGjgV0o8RS_OXtxsXz5k_T5Y33ZylRxRzDb8fbflbA) <small>www.linkedin.com</small>Kimberly Powell - Educational Leadership | LinkedIn

Kimberly Powell - Educator | LinkedIn
-------------------------------------

 ![Kimberly Powell - Educator | LinkedIn](https://media.licdn.com/dms/image/v2/D4E03AQHOuOY6ZGYI0Q/profile-displayphoto-scale_200_200/B4EZ7ki9AUIcAc-/0/1781950829543?e=2147483647&v=beta&t=Hru_4tKnxIC5gaaOhdGXpnQNaEiYz0TBaABXWrcZnSo) <small>www.linkedin.com</small>Kimberly Powell - Educator | LinkedIn

Kimberly Powell - Department Of Asian Studies
---------------------------------------------

 ![Kimberly Powell - Department of Asian Studies](https://asian.la.psu.edu/wp-content/uploads/sites/15/elementor/thumbs/kim-powell-pa5m38pq3z30k614xeby5gzgg2ll7bgd14zci6yywc.png) <small>asian.la.psu.edu</small>Kimberly Powell - Department of Asian Studies

Kimberly Powell On LinkedIn: #speakupsisawards2024 #susawards2024 #susawardsfinalist2024 #voteforme
---------------------------------------------------------------------------------------------------

 ![Kimberly Powell on LinkedIn: #speakupsisawards2024 #susawards2024 #susawardsfinalist2024 #voteforme](https://media.licdn.com/dms/image/D4D22AQHnpcTAQwDtzg/feedshare-shrink_2048_1536/0/1710527087105?e=2147483647&v=beta&t=ABcsxN8h4u0sB8mJDrZKm9poz4E6UKa_kzE8Y0XAmbE) <small>www.linkedin.com</small>Kimberly Powell on LinkedIn: #speakupsisawards2024 #susawards2024 #susawardsfinalist2024 #voteforme

NVIDIA Powers Up In Drug Discovery
----------------------------------

 ![NVIDIA Powers Up in Drug Discovery](https://genengnews.com/wp-content/uploads/2020/10/Kimberly-Powell_avatar_1511719112-200x200-1.jpg) <small>www.genengnews.com</small>NVIDIA Powers Up in Drug Discovery

Faculty Staff | College Of Medicine
-----------------------------------

 ![Faculty Staff | College of Medicine](https://public.med.fsu.edu/images/Faculty/Kimberly.Powell.jpg) <small>public.med.fsu.edu</small>Faculty Staff | College of Medicine

Kimberly Powell - Entertainment Coordinator At 'Self-Employed' | LinkedIn
-------------------------------------------------------------------------

 ![kimberly powell - Entertainment Coordinator at 'Self-Employed' | LinkedIn](https://media.licdn.com/dms/image/v2/C5603AQHA3-jfOZ-oiQ/profile-displayphoto-shrink_200_200/profile-displayphoto-shrink_200_200/0/1517027890787?e=2147483647&v=beta&t=-hzj2KJWJev-z_BmojESEaEyrwflgZLBYRlOUS_zuCE) <small>www.linkedin.com</small>kimberly powell - Entertainment Coordinator at 'Self-Employed' | LinkedIn

Kimberly Powell - Ameriprise Financial Services, LLC | LinkedIn
---------------------------------------------------------------

 ![Kimberly Powell - Ameriprise Financial Services, LLC | LinkedIn](https://media.licdn.com/dms/image/v2/D5603AQGczgPZHL-qRw/profile-displayphoto-shrink_200_200/profile-displayphoto-shrink_200_200/0/1694200867578?e=2147483647&v=beta&t=kg582iE3LiLZhrClX5KIfmnqUUFyag9x8hYXM9xPD7U) <small>www.linkedin.com</small>Kimberly Powell - Ameriprise Financial Services, LLC | LinkedIn

Kimberly Powell Inducted As Fellow Of The American Medical Informatics Association, Announced As
------------------------------------------------------------------------------------------------

 ![Kimberly Powell inducted as Fellow of the American Medical Informatics Association, announced as](https://showme.missouri.edu/wp-content/uploads/2024/06/071124_PowellFeature-940x529.jpg) <small>showme.missouri.edu</small>Kimberly Powell inducted as Fellow of the American Medical Informatics Association, announced as ...

20 People To Know In Banking: Kimberly Powell, Huntington National Bank - Pittsburgh Business Times
---------------------------------------------------------------------------------------------------

 ![20 People to Know in Banking: Kimberly Powell, Huntington National Bank - Pittsburgh Business Times](https://media.bizj.us/view/img/12644095/powellkimhuntington*320xx4045-6068-1-0.jpg) <small>www.bizjournals.com</small>20 People to Know in Banking: Kimberly Powell, Huntington National Bank - Pittsburgh Business Times

FDC Welcomes Kimberly Powell, APRN! | Medical Associates Of Northwest Arkansas
------------------------------------------------------------------------------

 ![FDC Welcomes Kimberly Powell, APRN! | Medical Associates of Northwest Arkansas](https://mana.md/wp-content/uploads/2022/06/Powell_KImberly_blog.jpg) <small>mana.md</small>FDC Welcomes Kimberly Powell, APRN! | Medical Associates of Northwest Arkansas

kimberly powell on linkedin: #speakupsisawards2024 #susawards2024 #susawardsfinalist2024 #voteforme. Kimberly powell. Kimberly powell
