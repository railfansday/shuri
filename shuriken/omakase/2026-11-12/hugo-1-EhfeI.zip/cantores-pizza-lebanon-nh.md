---
title: "Cantores Pizza Lebanon Nh - cantore’s pizza"
description: "cantore’s pizza"
date: "2026-07-23"
categories:
- "Uncategorized"
images:
- "https://s3-media0.fl.yelpcdn.com/bphoto/7QaNSu8uqblzvXPt7ubMZw/258s.jpg"
featuredImage: "https://s3-media0.fl.yelpcdn.com/bphoto/OUj08YKFKwsGSHlK7FL21w/348s.jpg"
featured_image: "https://www.cantorespizza.com/wp-content/uploads/2011/06/cantores-001-1024x768.jpg"
image: "https://s3-media0.fl.yelpcdn.com/bphoto/_XgjZBxHQIQ3rdPhC1gn2g/348s.jpg"
---

If you are looking for CANTORE’S PIZZA - Updated June 2026 - 84 Photos &amp; 178 Reviews - 1 Glen Rd Plz, West Lebanon, New you've came to the right place. We have 35 Pics about CANTORE’S PIZZA - Updated June 2026 - 84 Photos &amp; 178 Reviews - 1 Glen Rd Plz, West Lebanon, New like CANTORE’S PIZZA - Updated June 2026 - 84 Photos &amp; 178 Reviews - 1 Glen Rd Plz, West Lebanon, New, Delivery | Cantore's Pizza West Lebanon NH and also CANTORE PIZZA, Lebanon - Menu, Prices &amp; Restaurant Reviews - Tripadvisor. Here it is:

CANTORE’S PIZZA - Updated June 2026 - 84 Photos &amp; 178 Reviews - 1 Glen Rd Plz, West Lebanon, New
----------------------------------------------------------------------------------------------------

 ![CANTORE’S PIZZA - Updated June 2026 - 84 Photos & 178 Reviews - 1 Glen Rd Plz, West Lebanon, New](https://s3-media0.fl.yelpcdn.com/bphoto/MLMrAqJigQmW5RFtegpo2g/300s.jpg) <small>www.yelp.com</small>CANTORE’S PIZZA - Updated June 2026 - 84 Photos &amp; 178 Reviews - 1 Glen Rd Plz, West Lebanon, New ...

CANTORE’S PIZZA - Updated October 2026 - 182 Reviews - 84 Photos - 1 Glen Rd Plz, West Lebanon
----------------------------------------------------------------------------------------------

 ![CANTORE’S PIZZA - Updated October 2026 - 182 Reviews - 84 Photos - 1 Glen Rd Plz, West Lebanon](https://s3-media0.fl.yelpcdn.com/bphoto/ztPk60rjHsHFMIJ4838uew/300s.jpg) <small>www.yelp.com</small>CANTORE’S PIZZA - Updated October 2026 - 182 Reviews - 84 Photos - 1 Glen Rd Plz, West Lebanon ...

Cantore's Pizza | West Lebanon NH
---------------------------------

 ![Cantore's Pizza | West Lebanon NH](https://lookaside.fbsbx.com/lookaside/crawler/media/?media_id=1069252073991126) <small>www.facebook.com</small>Cantore's Pizza | West Lebanon NH

CANTORE’S PIZZA - Updated October 2026 - 182 Reviews - 84 Photos - 1 Glen Rd Plz, West Lebanon
----------------------------------------------------------------------------------------------

 ![CANTORE’S PIZZA - Updated October 2026 - 182 Reviews - 84 Photos - 1 Glen Rd Plz, West Lebanon](https://s3-media0.fl.yelpcdn.com/bphoto/0oUW6WIVurP8FQefKypxiw/258s.jpg) <small>www.yelp.com</small>CANTORE’S PIZZA - Updated October 2026 - 182 Reviews - 84 Photos - 1 Glen Rd Plz, West Lebanon ...

Cantore's Pizza | West Lebanon NH
---------------------------------

 ![Cantore's Pizza | West Lebanon NH](https://lookaside.fbsbx.com/lookaside/crawler/media/?media_id=100027190317134) <small>www.facebook.com</small>Cantore's Pizza | West Lebanon NH

CANTORE’S PIZZA - Updated July 2025 - 82 Photos &amp; 170 Reviews - 1 Glen Rd Plz, West Lebanon, New
----------------------------------------------------------------------------------------------------

 ![CANTORE’S PIZZA - Updated July 2025 - 82 Photos & 170 Reviews - 1 Glen Rd Plz, West Lebanon, New](https://s3-media0.fl.yelpcdn.com/bphoto/aB5i1CEBHlexjExNToTVFw/258s.jpg) <small>www.yelp.com</small>CANTORE’S PIZZA - Updated July 2025 - 82 Photos &amp; 170 Reviews - 1 Glen Rd Plz, West Lebanon, New ...

CANTORE’S PIZZA - Updated October 2026 - 182 Reviews - 84 Photos - 1 Glen Rd Plz, West Lebanon
----------------------------------------------------------------------------------------------

 ![CANTORE’S PIZZA - Updated October 2026 - 182 Reviews - 84 Photos - 1 Glen Rd Plz, West Lebanon](https://s3-media0.fl.yelpcdn.com/bphoto/778NLphoTtsvRj26ckaG2A/258s.jpg) <small>www.yelp.com</small>CANTORE’S PIZZA - Updated October 2026 - 182 Reviews - 84 Photos - 1 Glen Rd Plz, West Lebanon ...

CANTORE’S PIZZA - Updated June 2026 - 84 Photos &amp; 178 Reviews - 1 Glen Rd Plz, West Lebanon, New
----------------------------------------------------------------------------------------------------

 ![CANTORE’S PIZZA - Updated June 2026 - 84 Photos & 178 Reviews - 1 Glen Rd Plz, West Lebanon, New](https://s3-media0.fl.yelpcdn.com/bphoto/7QaNSu8uqblzvXPt7ubMZw/258s.jpg) <small>www.yelp.com</small>CANTORE’S PIZZA - Updated June 2026 - 84 Photos &amp; 178 Reviews - 1 Glen Rd Plz, West Lebanon, New ...

CANTORE’S PIZZA - Updated June 2026 - 84 Photos &amp; 178 Reviews - 1 Glen Rd Plz, West Lebanon, New
----------------------------------------------------------------------------------------------------

 ![CANTORE’S PIZZA - Updated June 2026 - 84 Photos & 178 Reviews - 1 Glen Rd Plz, West Lebanon, New](https://s3-media0.fl.yelpcdn.com/businessregularlogo/XrKtbb6i0TVFUD-TRkBymQ/300s.jpg) <small>www.yelp.com</small>CANTORE’S PIZZA - Updated June 2026 - 84 Photos &amp; 178 Reviews - 1 Glen Rd Plz, West Lebanon, New ...

Cantore's Pizza Menu - West Lebanon, NH
---------------------------------------

 ![Cantore's Pizza Menu - West Lebanon, NH](https://lh5.googleusercontent.com/p/AF1QipNU9hWjWynWuBBn-7O6HelsHv85ziEhdaZxpn9F=s1024) <small>www.roostcafeandbistro.com</small>Cantore's Pizza Menu - West Lebanon, NH

CANTORE’S PIZZA - Updated July 2025 - 82 Photos &amp; 170 Reviews - 1 Glen Rd Plz, West Lebanon, New
----------------------------------------------------------------------------------------------------

 ![CANTORE’S PIZZA - Updated July 2025 - 82 Photos & 170 Reviews - 1 Glen Rd Plz, West Lebanon, New](https://s3-media0.fl.yelpcdn.com/bphoto/HX9xNQwWnoN0nHhRfuOvJA/258s.jpg) <small>www.yelp.com</small>CANTORE’S PIZZA - Updated July 2025 - 82 Photos &amp; 170 Reviews - 1 Glen Rd Plz, West Lebanon, New ...

Cantore's Pizza - Glen Road Plaza #14, West Lebanon NH -Online Ordering For Pickup Or Delivery
----------------------------------------------------------------------------------------------

 ![Cantore's Pizza - Glen Road Plaza #14, West Lebanon NH -Online ordering for pickup or delivery](https://www.cantorespizza.com/wp-content/uploads/2022/02/topLogo.png) <small>www.cantorespizza.com</small>Cantore's Pizza - Glen Road Plaza #14, West Lebanon NH -Online ordering for pickup or delivery

CANTORE’S PIZZA - Updated June 2026 - 84 Photos &amp; 178 Reviews - 1 Glen Rd Plz, West Lebanon, New
----------------------------------------------------------------------------------------------------

 ![CANTORE’S PIZZA - Updated June 2026 - 84 Photos & 178 Reviews - 1 Glen Rd Plz, West Lebanon, New](https://s3-media0.fl.yelpcdn.com/bphoto/JdaMt71434aqexIQe2BMNA/300s.jpg) <small>www.yelp.com</small>CANTORE’S PIZZA - Updated June 2026 - 84 Photos &amp; 178 Reviews - 1 Glen Rd Plz, West Lebanon, New ...

CANTORE’S PIZZA - Updated June 2026 - 84 Photos &amp; 178 Reviews - 1 Glen Rd Plz, West Lebanon, New
----------------------------------------------------------------------------------------------------

 ![CANTORE’S PIZZA - Updated June 2026 - 84 Photos & 178 Reviews - 1 Glen Rd Plz, West Lebanon, New](https://s3-media0.fl.yelpcdn.com/bphoto/dGcI26aejMxhdsswmowwtQ/348s.jpg) <small>www.yelp.com</small>CANTORE’S PIZZA - Updated June 2026 - 84 Photos &amp; 178 Reviews - 1 Glen Rd Plz, West Lebanon, New ...

CANTORE’S PIZZA - Updated June 2026 - 84 Photos &amp; 178 Reviews - 1 Glen Rd Plz, West Lebanon, New
----------------------------------------------------------------------------------------------------

 ![CANTORE’S PIZZA - Updated June 2026 - 84 Photos & 178 Reviews - 1 Glen Rd Plz, West Lebanon, New](https://s3-media0.fl.yelpcdn.com/bphoto/YOD1Pmo4tFMbZXDPlkWsqw/348s.jpg) <small>www.yelp.com</small>CANTORE’S PIZZA - Updated June 2026 - 84 Photos &amp; 178 Reviews - 1 Glen Rd Plz, West Lebanon, New ...

CANTORE’S PIZZA - Updated June 2026 - 84 Photos &amp; 178 Reviews - 1 Glen Rd Plz, West Lebanon, New
----------------------------------------------------------------------------------------------------

 ![CANTORE’S PIZZA - Updated June 2026 - 84 Photos & 178 Reviews - 1 Glen Rd Plz, West Lebanon, New](https://s3-media0.fl.yelpcdn.com/bphoto/J0TvFtqUWJ_MProKJhTllA/258s.jpg) <small>www.yelp.com</small>CANTORE’S PIZZA - Updated June 2026 - 84 Photos &amp; 178 Reviews - 1 Glen Rd Plz, West Lebanon, New ...

Cantore's Pizza - West Lebanon New Hampshire Restaurant - HappyCow
------------------------------------------------------------------

 ![Cantore's Pizza - West Lebanon New Hampshire Restaurant - HappyCow](https://images.happycow.net/venues/500/28/74/hcmp28746_2271274.jpeg) <small>www.happycow.net</small>Cantore's Pizza - West Lebanon New Hampshire Restaurant - HappyCow

Cantore’s Pizza (West Lebanon, NH) | Offbeat Eats
-------------------------------------------------

 ![Cantore’s Pizza (West Lebanon, NH) | Offbeat Eats](https://farm8.staticflickr.com/7032/6771888209_5d7bae737f_m.jpg) <small>offbeateats.org</small>Cantore’s Pizza (West Lebanon, NH) | Offbeat Eats

CANTORE’S PIZZA - Updated June 2026 - 84 Photos &amp; 178 Reviews - 1 Glen Rd Plz, West Lebanon, New
----------------------------------------------------------------------------------------------------

 ![CANTORE’S PIZZA - Updated June 2026 - 84 Photos & 178 Reviews - 1 Glen Rd Plz, West Lebanon, New](https://s3-media0.fl.yelpcdn.com/bphoto/1nHHuQCl8Za0eDGI5LizGg/258s.jpg) <small>www.yelp.com</small>CANTORE’S PIZZA - Updated June 2026 - 84 Photos &amp; 178 Reviews - 1 Glen Rd Plz, West Lebanon, New ...

CANTORE’S PIZZA - Updated June 2026 - 84 Photos &amp; 178 Reviews - 1 Glen Rd Plz, West Lebanon, New
----------------------------------------------------------------------------------------------------

 ![CANTORE’S PIZZA - Updated June 2026 - 84 Photos & 178 Reviews - 1 Glen Rd Plz, West Lebanon, New](https://s3-media0.fl.yelpcdn.com/bphoto/o6_tAn-nZEd5l0BATaUo2A/258s.jpg) <small>www.yelp.com</small>CANTORE’S PIZZA - Updated June 2026 - 84 Photos &amp; 178 Reviews - 1 Glen Rd Plz, West Lebanon, New ...

Cantore's Pizza - West Lebanon New Hampshire Restaurant - HappyCow
------------------------------------------------------------------

 ![Cantore's Pizza - West Lebanon New Hampshire Restaurant - HappyCow](https://images.happycow.net/venues/500/28/74/hcmp28746_181977.jpeg) <small>www.happycow.net</small>Cantore's Pizza - West Lebanon New Hampshire Restaurant - HappyCow

CANTORE’S PIZZA - Updated June 2026 - 84 Photos &amp; 178 Reviews - 1 Glen Rd Plz, West Lebanon, New
----------------------------------------------------------------------------------------------------

 ![CANTORE’S PIZZA - Updated June 2026 - 84 Photos & 178 Reviews - 1 Glen Rd Plz, West Lebanon, New](https://s3-media0.fl.yelpcdn.com/bphoto/OUj08YKFKwsGSHlK7FL21w/348s.jpg) <small>www.yelp.com</small>CANTORE’S PIZZA - Updated June 2026 - 84 Photos &amp; 178 Reviews - 1 Glen Rd Plz, West Lebanon, New ...

CANTORE’S PIZZA - Updated June 2026 - 84 Photos &amp; 178 Reviews - 1 Glen Rd Plz, West Lebanon, New
----------------------------------------------------------------------------------------------------

 ![CANTORE’S PIZZA - Updated June 2026 - 84 Photos & 178 Reviews - 1 Glen Rd Plz, West Lebanon, New](https://s3-media0.fl.yelpcdn.com/bphoto/Tbr03f5ip4f48_VJWpvMXA/258s.jpg) <small>www.yelp.com</small>CANTORE’S PIZZA - Updated June 2026 - 84 Photos &amp; 178 Reviews - 1 Glen Rd Plz, West Lebanon, New ...

CANTORE’S PIZZA - Updated July 2025 - 82 Photos &amp; 170 Reviews - 1 Glen Rd Plz, West Lebanon, New
----------------------------------------------------------------------------------------------------

 ![CANTORE’S PIZZA - Updated July 2025 - 82 Photos & 170 Reviews - 1 Glen Rd Plz, West Lebanon, New](https://s3-media0.fl.yelpcdn.com/bphoto/28_y3sOurR9ACy-yOIGYRw/258s.jpg) <small>www.yelp.com</small>CANTORE’S PIZZA - Updated July 2025 - 82 Photos &amp; 170 Reviews - 1 Glen Rd Plz, West Lebanon, New ...

CANTORE’S PIZZA - Updated June 2026 - 84 Photos &amp; 178 Reviews - 1 Glen Rd Plz, West Lebanon, New
----------------------------------------------------------------------------------------------------

 ![CANTORE’S PIZZA - Updated June 2026 - 84 Photos & 178 Reviews - 1 Glen Rd Plz, West Lebanon, New](https://s3-media0.fl.yelpcdn.com/bphoto/BY3SxBg0I8iIlWNBeVQEng/258s.jpg) <small>www.yelp.com</small>CANTORE’S PIZZA - Updated June 2026 - 84 Photos &amp; 178 Reviews - 1 Glen Rd Plz, West Lebanon, New ...

Cantore's Pizza Menu In West Lebanon, New Hampshire, USA
--------------------------------------------------------

 ![Cantore's Pizza menu in West Lebanon, New Hampshire, USA](https://images.sirved.com/ChIJnRIgUmC1tEwReaE6weOIQ_Q/5b1e43d29d980.jpg) <small>www.sirved.com</small>Cantore's Pizza menu in West Lebanon, New Hampshire, USA

Delivery | Cantore's Pizza West Lebanon NH
------------------------------------------

 ![Delivery | Cantore's Pizza West Lebanon NH](https://www.cantorespizza.com/wp-content/uploads/2011/06/cantores-001-1024x768.jpg) <small>www.cantorespizza.com</small>Delivery | Cantore's Pizza West Lebanon NH

Menu For Cantore's Pizza In West Lebanon, NH | Sirved
-----------------------------------------------------

 ![Menu for Cantore's Pizza in West Lebanon, NH | Sirved](https://images.sirved.com/ChIJnRIgUmC1tEwReaE6weOIQ_Q/5b1e441284f11.jpg) <small>www.sirved.com</small>Menu for Cantore's Pizza in West Lebanon, NH | Sirved

Best New York–Style Pizza In Lebanon, New Hampshire Restaurants, Spring 2024 - Restaurant Guru
----------------------------------------------------------------------------------------------

 ![Best new York–Style Pizza in Lebanon, New Hampshire restaurants, spring 2024 - Restaurant Guru](https://img.restaurantguru.com/c691-Cantores-Pizza-interior.jpg) <small>restaurantguru.com</small>Best new York–Style Pizza in Lebanon, New Hampshire restaurants, spring 2024 - Restaurant Guru

Cantore's Pizza - West Lebanon New Hampshire Restaurant - HappyCow
------------------------------------------------------------------

 ![Cantore's Pizza - West Lebanon New Hampshire Restaurant - HappyCow](https://images.happycow.net/venues/1024/28/74/hcmp28746_411344.jpeg) <small>www.happycow.net</small>Cantore's Pizza - West Lebanon New Hampshire Restaurant - HappyCow

Cantore's Pizza - West Lebanon New Hampshire Restaurant - HappyCow
------------------------------------------------------------------

 ![Cantore's Pizza - West Lebanon New Hampshire Restaurant - HappyCow](https://images.happycow.net/venues/1024/28/74/hcmp28746_944387.jpeg) <small>www.happycow.net</small>Cantore's Pizza - West Lebanon New Hampshire Restaurant - HappyCow

CANTORE’S PIZZA - Updated June 2026 - 84 Photos &amp; 178 Reviews - 1 Glen Rd Plz, West Lebanon, New
----------------------------------------------------------------------------------------------------

 ![CANTORE’S PIZZA - Updated June 2026 - 84 Photos & 178 Reviews - 1 Glen Rd Plz, West Lebanon, New](https://s3-media0.fl.yelpcdn.com/bphoto/_XgjZBxHQIQ3rdPhC1gn2g/348s.jpg) <small>www.yelp.com</small>CANTORE’S PIZZA - Updated June 2026 - 84 Photos &amp; 178 Reviews - 1 Glen Rd Plz, West Lebanon, New ...

CANTORE’S PIZZA - Updated June 2026 - 84 Photos &amp; 178 Reviews - 1 Glen Rd Plz, West Lebanon, New
----------------------------------------------------------------------------------------------------

 ![CANTORE’S PIZZA - Updated June 2026 - 84 Photos & 178 Reviews - 1 Glen Rd Plz, West Lebanon, New](https://s3-media0.fl.yelpcdn.com/bphoto/iLgrIHDY5DgGNLu5PSDYTg/258s.jpg) <small>www.yelp.com</small>CANTORE’S PIZZA - Updated June 2026 - 84 Photos &amp; 178 Reviews - 1 Glen Rd Plz, West Lebanon, New ...

CANTORE’S PIZZA - 72 Photos &amp; 149 Reviews - 1 Glen Rd Plz, West Lebanon, NH - Yelp
--------------------------------------------------------------------------------------

 ![CANTORE’S PIZZA - 72 Photos & 149 Reviews - 1 Glen Rd Plz, West Lebanon, NH - Yelp](https://s3-media0.fl.yelpcdn.com/bphoto/76DCQrgDN8Nqe3QKDA-opw/300s.jpg) <small>www.yelp.com</small>CANTORE’S PIZZA - 72 Photos &amp; 149 Reviews - 1 Glen Rd Plz, West Lebanon, NH - Yelp

CANTORE PIZZA, Lebanon - Menu, Prices &amp; Restaurant Reviews - Tripadvisor
----------------------------------------------------------------------------

 ![CANTORE PIZZA, Lebanon - Menu, Prices & Restaurant Reviews - Tripadvisor](https://dynamic-media-cdn.tripadvisor.com/media/photo-o/06/5c/24/f6/cantore-pizza.jpg?w=1200&h=1200&s=1) <small>www.tripadvisor.com</small>CANTORE PIZZA, Lebanon - Menu, Prices &amp; Restaurant Reviews - Tripadvisor

Cantore’s pizza. cantore's pizza menu in west lebanon, new hampshire, usa. cantore’s pizza
