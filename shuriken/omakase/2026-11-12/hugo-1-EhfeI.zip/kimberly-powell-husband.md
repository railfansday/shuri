---
title: "Kimberly Powell Husband - Who is kimberly powell? what we know about the nvidia executive with whom ceo jensen huang had"
description: "Jen hsun and lori huang living trust news and updates from the economic times"
date: "2026-04-07"
categories:
- "Uncategorized"
images:
- "https://images.filmibeat.com/img/2026/11/feature-2026-11-12t124058-719-90771794467475.jpg"
featuredImage: "https://www.asiaone.com/sites/default/files/styles/article_top_image/public/original_images/Nov2026/kimberly-powell-nvidia-facebook (1).jpg?itok=hIIek7fk"
featured_image: "https://www.shutterstock.com/editorial/image-editorial/MfT4Qcy7N9j7c5x6NzM3MTc=/kimberly-powell-440nw-14136080dr.jpg"
image: "https://images.filmibeat.com/img/2026/11/feature-2026-11-12t124058-719-90771794467475.jpg"
---

If you are searching about Kimberly Powell-Jensen Huang Alleged Affair: What Nvidia's Cod... you've came to the right page. We have 35 Pictures about Kimberly Powell-Jensen Huang Alleged Affair: What Nvidia's Cod... like Kimberly Powell's Family: Meet Her Husband Graham &amp; 2 Kids, Who is Kimberly Powell? What we know about the Nvidia executive with whom CEO Jensen Huang had and also ¿La vicepresidenta de NVIDIA, Kimberly Powell, anunció su... 2026 | Polymarket. Here it is:

Kimberly Powell-Jensen Huang Alleged Affair: What Nvidia's Cod...
-----------------------------------------------------------------

 ![Kimberly Powell-Jensen Huang Alleged Affair: What Nvidia's Cod...](https://data.ibtimes.sg/en/full/99518/kimberly-powell.jpg?w=736) <small>www.ibtimes.sg</small>Kimberly Powell-Jensen Huang Alleged Affair: What Nvidia's Cod...

Kimberly Powell Husband: His Career, Family And Connection To Medical Technology – Westperthgp
----------------------------------------------------------------------------------------------

 ![Kimberly Powell Husband: His Career, Family and Connection to Medical Technology – westperthgp](https://images.inkl.com/s3/article/lead_image/24052916/kimberly-powell.png) <small>westperthgp.com.au</small>Kimberly Powell Husband: His Career, Family and Connection to Medical Technology – westperthgp ...

Kimberly Powell's Net Worth (2026) &amp; NVIDIA Salary Revealed
---------------------------------------------------------------

 ![Kimberly Powell's Net Worth (2026) & NVIDIA Salary Revealed](https://celebsfortune.com/wp-content/uploads/2026/11/kimberly-powell-picture.jpg) <small>celebsfortune.com</small>Kimberly Powell's Net Worth (2026) &amp; NVIDIA Salary Revealed

Who Is Kimberly Powell? Nvidia Executive Who Had Affair With CEO Jensen Huang
-----------------------------------------------------------------------------

 ![Who Is Kimberly Powell? Nvidia Executive Who Had Affair With CEO Jensen Huang](https://c.ndtvimg.com/2026-11/atbds6hc_kimberly-powell_625x300_12_November_26.jpeg?im=FaceCrop,algorithm=dnn,width=1600,height=900) <small>www.ndtv.com</small>Who Is Kimberly Powell? Nvidia Executive Who Had Affair With CEO Jensen Huang

Kimberly Powell Had Affair With Jensen Huang, NYT Reports
---------------------------------------------------------

 ![Kimberly Powell had affair with Jensen Huang, NYT reports](https://media.nacionale.kabineti.net/uploads/kimberly_powell_nvidia_illustration_5a1969db6f.jpg) <small>www.nacionale.com</small>Kimberly Powell had affair with Jensen Huang, NYT reports

Kimberly Powell, Who CEO Jensen Huang Allegedly Had Affair With, Studied At Northeastern
----------------------------------------------------------------------------------------

 ![Kimberly Powell, who CEO Jensen Huang allegedly had affair with, studied at Northeastern](https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA2hg6BC.img?w=549&h=309&m=6&x=97&y=55&s=352&d=81) <small>www.msn.com</small>Kimberly Powell, who CEO Jensen Huang allegedly had affair with, studied at Northeastern ...

Jensen Huang News | Jensen Huang Second Affair Controversy: Who Is Kimberly Powell? Nvidia CEO
----------------------------------------------------------------------------------------------

 ![Jensen Huang News | Jensen Huang Second Affair Controversy: Who Is Kimberly Powell? Nvidia CEO](https://images.filmibeat.com/img/2026/11/feature-2026-11-12t124058-719-90771794467475.jpg) <small>www.filmibeat.com</small>Jensen Huang News | Jensen Huang Second Affair Controversy: Who Is Kimberly Powell? Nvidia CEO ...

Kimberly Powell: How Married Nvidia Healthcare VP Rose Through...
-----------------------------------------------------------------

 ![Kimberly Powell: How Married Nvidia Healthcare VP Rose Through...](https://data.ibtimes.sg/en/full/99508/kimberly-powell.jpg?w=736) <small>www.ibtimes.sg</small>Kimberly Powell: How Married Nvidia Healthcare VP Rose Through...

Kimberly Powell Editorial Stock Photo - Stock Image | Shutterstock Editorial
----------------------------------------------------------------------------

 ![Kimberly Powell Editorial Stock Photo - Stock Image | Shutterstock Editorial](https://www.shutterstock.com/editorial/image-editorial/MfT4Qcy7N9j7c5x6NzM3MTc=/kimberly-powell-440nw-14136080dr.jpg) <small>www.shutterstock.com</small>Kimberly Powell Editorial Stock Photo - Stock Image | Shutterstock Editorial

John Farnham Latest Images News And Updates From The Economic Times - Page 1
----------------------------------------------------------------------------

 ![john farnham latest images News and Updates from The Economic Times - Page 1](https://img.etimg.com/thumb/msid-135752226,width-100,height-75,resizemode-4/news/new-updates/who-is-kimberly-powell-nvidia-vice-president-named-in-new-report-alleging-extramarital-affair-with-married-ceo-jensen-huang.jpg) <small>economictimes.indiatimes.com</small>john farnham latest images News and Updates from The Economic Times - Page 1

Kimberly Powell's 18-Year Journey At Nvidia Draws Attention After Personal Links With CEO Jensen
------------------------------------------------------------------------------------------------

 ![Kimberly Powell's 18-Year Journey At Nvidia Draws Attention After Personal Links With CEO Jensen](https://images.thedailyjagran.com/images/2026/11/12/template/image/Kimberlypowell-1794456712201.webp) <small>www.thedailyjagran.com</small>Kimberly Powell's 18-Year Journey At Nvidia Draws Attention After Personal Links With CEO Jensen ...

Kimberly Powell Biography: Age, Nvidia Healthcare Career And The Jensen Huang Report – The
------------------------------------------------------------------------------------------

 ![Kimberly Powell Biography: Age, Nvidia Healthcare Career and the Jensen Huang Report – The](https://jaisalmernews.com/wp-content/uploads/2026/11/kimberly-powell-biography-cover.webp) <small>jaisalmernews.com</small>Kimberly Powell Biography: Age, Nvidia Healthcare Career and the Jensen Huang Report – The ...

Kimberly Powell (Nvidia) Wiki, Age, Husband &amp; Salary
--------------------------------------------------------

 ![Kimberly Powell (Nvidia) Wiki, Age, Husband & Salary](https://wikiofcelebrities.com/wp-content/uploads/2026/11/Kimberly-Powell.webp) <small>wikiofcelebrities.com</small>Kimberly Powell (Nvidia) Wiki, Age, Husband &amp; Salary

As Mark Zuckerberg Is Reportedly Building An AI Agent To Help Him Do His CEO Duties; Says He
--------------------------------------------------------------------------------------------

 ![As Mark Zuckerberg is reportedly building an AI agent to help him do his CEO duties; says he](https://static.toiimg.com/thumb/msid-135763009,width-1280,height-720,resizemode-6,overlay-toi_sw,pt-32,y_pad-600/photo.jpg) <small>timesofindia.indiatimes.com</small>As Mark Zuckerberg is reportedly building an AI agent to help him do his CEO duties; says he ...

Jen Hsun And Lori Huang Living Trust News And Updates From The Economic Times - Page 1
--------------------------------------------------------------------------------------

 ![jen hsun and lori huang living trust News and Updates from The Economic Times - Page 1](https://img.etimg.com/thumb/msid-135754160,width-100,height-75,resizemode-4/world/us/watch-jensen-huangs-reported-extramarital-partner-kimberly-powell-walks-the-show-floor-in-nvidia-video.jpg) <small>economictimes.indiatimes.com</small>jen hsun and lori huang living trust News and Updates from The Economic Times - Page 1

Kimberly Powell, The Engineer Who Became Nvidia's Healthcare VP And Is Now Caught In The Jensen
-----------------------------------------------------------------------------------------------

 ![Kimberly Powell, the engineer who became Nvidia's healthcare VP and is now caught in the Jensen](https://www.asiaone.com/sites/default/files/styles/article_top_image/public/original_images/Nov2026/kimberly-powell-nvidia-facebook (1).jpg?itok=hIIek7fk) <small>www.asiaone.com</small>Kimberly Powell, the engineer who became Nvidia's healthcare VP and is now caught in the Jensen ...

Who Is Graham Gerade? What To Know About Kimberly Powell's Husband Amid Jensen Huang Controversy
------------------------------------------------------------------------------------------------

 ![Who is Graham Gerade? What to know about Kimberly Powell's husband amid Jensen Huang controversy](https://img.etimg.com/thumb/msid-135757356,width-1200,height-900,imgsize-55824,overlay-economictimes/articleshow.jpg) <small>economictimes.indiatimes.com</small>Who is Graham Gerade? What to know about Kimberly Powell's husband amid Jensen Huang controversy ...

Nvidia Kimberly Powell Husband: Latest News &amp; Videos, Photos About Nvidia Kimberly Powell
---------------------------------------------------------------------------------------------

 ![nvidia kimberly powell husband: Latest News & Videos, Photos about nvidia kimberly powell](https://img.etimg.com/thumb/msid-135769516,width-100,height-75,resizemode-4/news/international/us/sunday-confidence-in-jensen-wednesday-preparing-to-oust-him-how-one-report-flipped-nvidias-board.jpg) <small>economictimes.indiatimes.com</small>nvidia kimberly powell husband: Latest News &amp; Videos, Photos about nvidia kimberly powell ...

Who Is Kimberly Powell, Nvidia Executive Who Had Affair With CEO Jensen Huang?
------------------------------------------------------------------------------

 ![Who Is Kimberly Powell, Nvidia Executive Who Had Affair With CEO Jensen Huang?](https://c.ndtvimg.com/2026-11/9ks3vb1s_kimberly-powell_625x300_12_November_26.jpeg?downsize=723:486) <small>www.ndtv.com</small>Who Is Kimberly Powell, Nvidia Executive Who Had Affair With CEO Jensen Huang?

Watch: Jensen Huang’s Reported Extramarital Partner Kimberly Powell Walks The Show Floor In
-------------------------------------------------------------------------------------------

 ![Watch: Jensen Huang’s reported extramarital partner Kimberly Powell walks the show floor in](https://img.etimg.com/thumb/msid-135754452,width-950,height-600,imgsize-130156,resizemode-75/jensen-huangs-former-partner-kimberly-powell-walks-the-show-floor-in-nvidia-videobr.jpg) <small>economictimes.indiatimes.com</small>Watch: Jensen Huang’s reported extramarital partner Kimberly Powell walks the show floor in ...

Who Is Kimberly Powell’s Husband? All About Graham D. Gerade – Hollywood Life
-----------------------------------------------------------------------------

 ![Who Is Kimberly Powell’s Husband? All About Graham D. Gerade – Hollywood Life](https://i0.wp.com/media.hollywoodlife.com/uploads/2026/11/GettyImages-2299100584-1-e1794493161212.jpeg?fit=1024%2C580&quality=89&ssl=1&w=1536) <small>hollywoodlife.com</small>Who Is Kimberly Powell’s Husband? All About Graham D. Gerade – Hollywood Life

Who Is Kimberly Powell? What We Know About The Nvidia Executive With Whom CEO Jensen Huang Had
----------------------------------------------------------------------------------------------

 ![Who is Kimberly Powell? What we know about the Nvidia executive with whom CEO Jensen Huang had](https://www.livemint.com/lm-img/img/2026/11/12/1600x900/logo/Kimberly_Powell_1794449319430_njB3_1794449333715_Hkre_bc717c92-2d65-48fa-87f0-0d42d73e664b_8mDq.jpg) <small>www.livemint.com</small>Who is Kimberly Powell? What we know about the Nvidia executive with whom CEO Jensen Huang had ...

Jensen Huang Had 2nd Affair With Nvidia VP Kimberly Powell, Who Reported Directly To Him
----------------------------------------------------------------------------------------

 ![Jensen Huang had 2nd affair with Nvidia VP Kimberly Powell, who reported directly to him](https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA1x6gvE.img?w=768&h=432&m=6&x=663&y=101&s=152&d=152) <small>www.msn.com</small>Jensen Huang had 2nd affair with Nvidia VP Kimberly Powell, who reported directly to him

Who Is Graham Gerade? Why His Name Has Surfaced In The Jensen Huang Controversy
-------------------------------------------------------------------------------

 ![Who Is Graham Gerade? Why His Name Has Surfaced In The Jensen Huang Controversy](https://static.toiimg.com/thumb/resizemode-4,msid-135769863,imgsize-152718,width-1200/135769863.jpg) <small>gadgetsnow.indiatimes.com</small>Who Is Graham Gerade? Why His Name Has Surfaced In The Jensen Huang Controversy

Kimberly Powell Nvidia: Summit Exit After Huang Report
------------------------------------------------------

 ![Kimberly Powell Nvidia: Summit Exit After Huang Report](https://bitcoinfoundation.org/wp-content/uploads/2026/11/kimberly-powell-cancels-health-summit-appearance-after-nvidia-ceo-relationship-r.webp) <small>bitcoinfoundation.org</small>Kimberly Powell Nvidia: Summit Exit After Huang Report

Kimberly Powell's Family: Meet Her Husband Graham &amp; 2 Kids
--------------------------------------------------------------

 ![Kimberly Powell's Family: Meet Her Husband Graham & 2 Kids](https://celebsindepth.com/wp-content/uploads/2026/11/kimberly-powell-husband-and-children.jpg) <small>celebsindepth.com</small>Kimberly Powell's Family: Meet Her Husband Graham &amp; 2 Kids

Kimberly Powell Husband: His Career, Family And Connection To Medical Technology – Westperthgp
----------------------------------------------------------------------------------------------

 ![Kimberly Powell Husband: His Career, Family and Connection to Medical Technology – westperthgp](https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTLGQqPxc7DL1Gyg3HIohOedzDTddD8Qr2QuEifoC0Jeg&s=10) <small>westperthgp.com.au</small>Kimberly Powell Husband: His Career, Family and Connection to Medical Technology – westperthgp ...

Graham Gerade, An Inventor, Is Married To Kimberly Powell, Who Allegedly Had An Affair With
-------------------------------------------------------------------------------------------

 ![Graham Gerade, an inventor, is married to Kimberly Powell, who allegedly had an affair with](https://www.hindustantimes.com/ht-img/img/2026/11/12/400x225/jensenpow_1794475711148_ehUc_1794475719831_W57Y_5a01fc52-a10b-45a6-80db-73113c637af5_vUlW.jpg) <small>www.hindustantimes.com</small>Graham Gerade, an inventor, is married to Kimberly Powell, who allegedly had an affair with ...

Who Is Kimberly Powell, The Nvidia Executive Linked To CEO Jensen Huang? | Republic World
-----------------------------------------------------------------------------------------

 ![Who Is Kimberly Powell, the Nvidia Executive Linked to CEO Jensen Huang? | Republic World](https://img.republicworld.com/all_images/2026/11/who-is-kimberly-powell-the-nvidia-executive-linked-to-ceo-jensen-huang-1794455712889-1280x720.webp?w=1280&h=720&q=75&format=webp) <small>www.republicworld.com</small>Who Is Kimberly Powell, the Nvidia Executive Linked to CEO Jensen Huang? | Republic World

Nvidia CEO Jensen Huang Was Introduced To Alice Huang By Her Husband A Decade Ago: Reports
------------------------------------------------------------------------------------------

 ![Nvidia CEO Jensen Huang Was Introduced To Alice Huang By Her Husband A Decade Ago: Reports](https://images.thedailyjagran.com/images/2026/11/12/article/image/Nvidia-CEO-1794478005908_v.webp) <small>www.thedailyjagran.com</small>Nvidia CEO Jensen Huang Was Introduced To Alice Huang By Her Husband A Decade Ago: Reports

Kimberly Powell Biography: Net Worth, Lifestyle &amp; Success Story | Gen-z Bio - YouTube
-----------------------------------------------------------------------------------------

 ![Kimberly Powell Biography: Net Worth, Lifestyle & Success Story | Gen-z Bio - YouTube](https://i.ytimg.com/vi/KWlhh49Nh18/maxres2.jpg?sqp=-oaymwEoCIAKENAF8quKqQMcGADwAQH4AbYIgAKAD4oCDAgAEAEYciBLKEIwDw==&rs=AOn4CLD4hVZeJqrNtcNMJybmuwutd5NWtg) <small>www.youtube.com</small>Kimberly Powell Biography: Net Worth, Lifestyle &amp; Success Story | Gen-z Bio - YouTube

Who Is Kimberly Powell, Nvidia Executive Who Had Affair With CEO Jensen Huang?
------------------------------------------------------------------------------

 ![Who Is Kimberly Powell, Nvidia Executive Who Had Affair With CEO Jensen Huang?](https://c.ndtvimg.com/2026-11/tc1q8iag_kimberly-powell_625x300_12_November_26.jpeg) <small>www.ndtv.com</small>Who Is Kimberly Powell, Nvidia Executive Who Had Affair With CEO Jensen Huang?

Who Is Kimberly Powell’s Husband? Nvidia CEO Scandal #shorts - YouTube
----------------------------------------------------------------------

 ![Who Is Kimberly Powell’s Husband? Nvidia CEO Scandal #shorts - YouTube](https://i.ytimg.com/vi/7fjfOPps8zc/maxresdefault.jpg) <small>www.youtube.com</small>Who Is Kimberly Powell’s Husband? Nvidia CEO Scandal #shorts - YouTube

¿La Vicepresidenta De NVIDIA, Kimberly Powell, Anunció Su... 2026 | Polymarket
------------------------------------------------------------------------------

 ![¿La vicepresidenta de NVIDIA, Kimberly Powell, anunció su... 2026 | Polymarket](https://polymarket.com/api/og?eslug=nvidia-vp-kimberly-powell-announced-resignation-or-removal-byptptpt&locale=es&tid=1794492950790) <small>polymarket.com</small>¿La vicepresidenta de NVIDIA, Kimberly Powell, anunció su... 2026 | Polymarket

Who Is Kimberly Powell's Husband, Graham D. Gerade? Inside Her...
-----------------------------------------------------------------

 ![Who Is Kimberly Powell's Husband, Graham D. Gerade? Inside Her...](https://data.ibtimes.sg/en/full/99517/kimberly-powell.jpg?w=736) <small>www.ibtimes.sg</small>Who Is Kimberly Powell's Husband, Graham D. Gerade? Inside Her...

Who is graham gerade? why his name has surfaced in the jensen huang controversy. Who is kimberly powell’s husband? all about graham d. gerade – hollywood life. John farnham latest images news and updates from the economic times
