---
title: "Kimberly Powell - Who is kimberly powell, the nvidia executive linked to ceo jensen huang?"
description: "Kimberly powell&#039;s family: meet her husband graham &amp; 2 kids"
date: "2026-02-25"
categories:
- "Uncategorized"
images:
- "https://www.shutterstock.com/editorial/image-editorial/MfT4Qcy7N9j7c5x6NzM3MTc=/kimberly-powell-1500w-14136080dr.jpg"
featuredImage: "https://wikiofcelebrities.com/wp-content/uploads/2026/11/Kimberly-Powell.webp"
featured_image: "https://i.ytimg.com/vi/KWlhh49Nh18/maxres2.jpg?sqp=-oaymwEoCIAKENAF8quKqQMcGADwAQH4AbYIgAKAD4oCDAgAEAEYciBLKEIwDw==&amp;rs=AOn4CLD4hVZeJqrNtcNMJybmuwutd5NWtg"
image: "https://celebsindepth.com/wp-content/uploads/2026/11/kimberly-powell-husband-and-children.jpg"
---

If you are searching about Kimberly Powell's Net Worth (2026) &amp; NVIDIA Salary Revealed you've visit to the right place. We have 22 Pics about Kimberly Powell's Net Worth (2026) &amp; NVIDIA Salary Revealed like Kimberly Powell's Nvidia Role Goes Beyond AI Chips as…, Watch: Jensen Huang’s reported extramarital partner Kimberly Powell walks the show floor in and also NVIDIA VP Kimberly Powell announced resignation or remova... 2026 | Polymarket. Read more:

Kimberly Powell's Net Worth (2026) &amp; NVIDIA Salary Revealed
---------------------------------------------------------------

 ![Kimberly Powell's Net Worth (2026) & NVIDIA Salary Revealed](https://celebsfortune.com/wp-content/uploads/2026/11/kimberly-powell-picture.jpg) <small>celebsfortune.com</small>Kimberly Powell's Net Worth (2026) &amp; NVIDIA Salary Revealed

Who Is Kimberly Powell, Nvidia Executive Who Had Affair With CEO Jensen Huang?
------------------------------------------------------------------------------

 ![Who Is Kimberly Powell, Nvidia Executive Who Had Affair With CEO Jensen Huang?](https://c.ndtvimg.com/2026-11/tc1q8iag_kimberly-powell_625x300_12_November_26.jpeg) <small>www.ndtv.com</small>Who Is Kimberly Powell, Nvidia Executive Who Had Affair With CEO Jensen Huang?

Kimberly Powell's Nvidia Role Goes Beyond AI Chips As…
------------------------------------------------------

 ![Kimberly Powell's Nvidia Role Goes Beyond AI Chips as…](https://images.inkl.com/s3/article/lead_image/24054567/kimberly-powell.png) <small>www.inkl.com</small>Kimberly Powell's Nvidia Role Goes Beyond AI Chips as…

Kimberly Powell's Family: Meet Her Husband Graham &amp; 2 Kids
--------------------------------------------------------------

 ![Kimberly Powell's Family: Meet Her Husband Graham & 2 Kids](https://celebsindepth.com/wp-content/uploads/2026/11/kimberly-powell-husband-and-children.jpg) <small>celebsindepth.com</small>Kimberly Powell's Family: Meet Her Husband Graham &amp; 2 Kids

Kimberly Powell's 18-Year Journey At Nvidia Draws Attention After Personal Links With CEO Jensen
------------------------------------------------------------------------------------------------

 ![Kimberly Powell's 18-Year Journey At Nvidia Draws Attention After Personal Links With CEO Jensen](https://images.thedailyjagran.com/images/2026/11/12/template/image/Kimberlypowell-1794456712201.webp) <small>www.thedailyjagran.com</small>Kimberly Powell's 18-Year Journey At Nvidia Draws Attention After Personal Links With CEO Jensen ...

Who Is Kimberly Powell, Nvidia Exec Alleged To Have A Relationship With CEO Jensen Huang
----------------------------------------------------------------------------------------

 ![Who is Kimberly Powell, Nvidia exec alleged to have a relationship with CEO Jensen Huang](https://images.news9live.com/wp-content/uploads/2026/11/kimberly.png) <small>www.news9live.com</small>Who is Kimberly Powell, Nvidia exec alleged to have a relationship with CEO Jensen Huang ...

NVIDIA VP Kimberly Powell Announced Resignation Or Remova... 2026 | Polymarket
------------------------------------------------------------------------------

 ![NVIDIA VP Kimberly Powell announced resignation or remova... 2026 | Polymarket](https://polymarket.com/api/og?eslug=nvidia-vp-kimberly-powell-announced-resignation-or-removal-byptptpt&tid=1794470875799) <small>polymarket.com</small>NVIDIA VP Kimberly Powell announced resignation or remova... 2026 | Polymarket

Kimberly Powell Had Affair With Jensen Huang, NYT Reports
---------------------------------------------------------

 ![Kimberly Powell had affair with Jensen Huang, NYT reports](https://www.nacionale.com/_next/image?url=https:%2F%2Fmedia.nacionale.kabineti.net%2Fuploads%2Fkimberly_powell_nvidia_illustration_5a1969db6f.jpg&w=1080&q=85) <small>nacionale.com</small>Kimberly Powell had affair with Jensen Huang, NYT reports

Kimberly Powell Editorial Stock Photo - Stock Image | Shutterstock Editorial
----------------------------------------------------------------------------

 ![Kimberly Powell Editorial Stock Photo - Stock Image | Shutterstock Editorial](https://www.shutterstock.com/editorial/image-editorial/MfT4Qcy7N9j7c5x6NzM3MTc=/kimberly-powell-1500w-14136080dr.jpg) <small>www.shutterstock.com</small>Kimberly Powell Editorial Stock Photo - Stock Image | Shutterstock Editorial

Kimberly Powell: How Married Nvidia Healthcare VP Rose Through...
-----------------------------------------------------------------

 ![Kimberly Powell: How Married Nvidia Healthcare VP Rose Through...](https://data.ibtimes.sg/en/full/99508/kimberly-powell.jpg?w=736) <small>www.ibtimes.sg</small>Kimberly Powell: How Married Nvidia Healthcare VP Rose Through...

Who Is Graham Gerade? What To Know About Kimberly Powell's Husband Amid Jensen Huang Controversy
------------------------------------------------------------------------------------------------

 ![Who is Graham Gerade? What to know about Kimberly Powell's husband amid Jensen Huang controversy](https://img.etimg.com/thumb/msid-135757356,width-950,height-600,imgsize-55824,resizemode-75/image-of-kimberly-powell.jpg) <small>economictimes.indiatimes.com</small>Who is Graham Gerade? What to know about Kimberly Powell's husband amid Jensen Huang controversy ...

Kimberly Powell (Nvidia) Wiki, Age, Husband &amp; Salary
--------------------------------------------------------

 ![Kimberly Powell (Nvidia) Wiki, Age, Husband & Salary](https://wikiofcelebrities.com/wp-content/uploads/2026/11/Kimberly-Powell.webp) <small>wikiofcelebrities.com</small>Kimberly Powell (Nvidia) Wiki, Age, Husband &amp; Salary

Who Is Kimberly Powell, The Nvidia Executive Linked To CEO Jensen Huang? | Republic World
-----------------------------------------------------------------------------------------

 ![Who Is Kimberly Powell, the Nvidia Executive Linked to CEO Jensen Huang? | Republic World](https://img.republicworld.com/all_images/2026/11/who-is-kimberly-powell-the-nvidia-executive-linked-to-ceo-jensen-huang-1794455712889-1280x720.webp?w=1280&h=720&q=75&format=webp) <small>www.republicworld.com</small>Who Is Kimberly Powell, the Nvidia Executive Linked to CEO Jensen Huang? | Republic World

Kimberly Powell-Jensen Huang Alleged Affair: What Nvidia's Cod...
-----------------------------------------------------------------

 ![Kimberly Powell-Jensen Huang Alleged Affair: What Nvidia's Cod...](https://data.ibtimes.sg/en/full/99518/kimberly-powell.jpg?w=736) <small>www.ibtimes.sg</small>Kimberly Powell-Jensen Huang Alleged Affair: What Nvidia's Cod...

Kimberly Powell, The Engineer Who Became Nvidia's Healthcare VP And Is Now Caught In The Jensen
-----------------------------------------------------------------------------------------------

 ![Kimberly Powell, the engineer who became Nvidia's healthcare VP and is now caught in the Jensen](https://www.asiaone.com/sites/default/files/styles/article_top_image/public/original_images/Nov2026/kimberly-powell-nvidia-facebook (1).jpg?itok=hIIek7fk) <small>www.asiaone.com</small>Kimberly Powell, the engineer who became Nvidia's healthcare VP and is now caught in the Jensen ...

Kimberly Powell Nvidia: Summit Exit After Huang Report
------------------------------------------------------

 ![Kimberly Powell Nvidia: Summit Exit After Huang Report](https://bitcoinfoundation.org/wp-content/uploads/2026/11/kimberly-powell-cancels-health-summit-appearance-after-nvidia-ceo-relationship-r.webp) <small>bitcoinfoundation.org</small>Kimberly Powell Nvidia: Summit Exit After Huang Report

Before Nvidia, Kimberly Powell Was An Engineering…
--------------------------------------------------

 ![Before Nvidia, Kimberly Powell was an engineering…](https://images.inkl.com/s3/article/lead_image/24056025/135773875.jpg) <small>www.inkl.com</small>Before Nvidia, Kimberly Powell was an engineering…

Kimberly Powell Biography: Net Worth, Lifestyle &amp; Success Story | Gen-z Bio - YouTube
-----------------------------------------------------------------------------------------

 ![Kimberly Powell Biography: Net Worth, Lifestyle & Success Story | Gen-z Bio - YouTube](https://i.ytimg.com/vi/KWlhh49Nh18/maxres2.jpg?sqp=-oaymwEoCIAKENAF8quKqQMcGADwAQH4AbYIgAKAD4oCDAgAEAEYciBLKEIwDw==&rs=AOn4CLD4hVZeJqrNtcNMJybmuwutd5NWtg) <small>www.youtube.com</small>Kimberly Powell Biography: Net Worth, Lifestyle &amp; Success Story | Gen-z Bio - YouTube

¿Quién Es Kimberly Powell, Ligada A Jensen Huang, Ex Ceo De Nvidia?- Grupo Milenio
----------------------------------------------------------------------------------

 ![¿Quién es Kimberly Powell, ligada a Jensen Huang, ex Ceo de Nvidia?- Grupo Milenio](https://cdn.milenio.com/uploads/media/2026/11/12/kimberly-powell-ejecutiva-nvidia-relacionada.jpg) <small>www.milenio.com</small>¿Quién es Kimberly Powell, ligada a Jensen Huang, ex Ceo de Nvidia?- Grupo Milenio

Who Is Kimberly Powell? Nvidia Executive Who Had Affair With CEO Jensen Huang
-----------------------------------------------------------------------------

 ![Who Is Kimberly Powell? Nvidia Executive Who Had Affair With CEO Jensen Huang](https://c.ndtvimg.com/2026-11/atbds6hc_kimberly-powell_625x300_12_November_26.jpeg?im=FaceCrop,algorithm=dnn,width=1600,height=900) <small>www.ndtv.com</small>Who Is Kimberly Powell? Nvidia Executive Who Had Affair With CEO Jensen Huang

Kimberly Powell Biography: Age, Nvidia Healthcare Career And The Jensen Huang Report – The
------------------------------------------------------------------------------------------

 ![Kimberly Powell Biography: Age, Nvidia Healthcare Career and the Jensen Huang Report – The](https://jaisalmernews.com/wp-content/uploads/2026/11/kimberly-powell-biography-cover.webp) <small>jaisalmernews.com</small>Kimberly Powell Biography: Age, Nvidia Healthcare Career and the Jensen Huang Report – The ...

Watch: Jensen Huang’s Reported Extramarital Partner Kimberly Powell Walks The Show Floor In
-------------------------------------------------------------------------------------------

 ![Watch: Jensen Huang’s reported extramarital partner Kimberly Powell walks the show floor in](https://img.etimg.com/thumb/msid-135754452,width-950,height-600,imgsize-130156,resizemode-75/jensen-huangs-former-partner-kimberly-powell-walks-the-show-floor-in-nvidia-videobr.jpg) <small>economictimes.indiatimes.com</small>Watch: Jensen Huang’s reported extramarital partner Kimberly Powell walks the show floor in ...

kimberly powell's 18-year journey at nvidia draws attention after personal links with ceo jensen .... kimberly powell's nvidia role goes beyond ai chips as…. Who is kimberly powell? nvidia executive who had affair with ceo jensen huang
