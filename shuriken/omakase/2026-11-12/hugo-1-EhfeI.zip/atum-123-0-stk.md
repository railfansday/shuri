---
title: "Atum-12/3-0-stk - atum-12/3-0-stk"
description: "atum-12/3-0-stk"
date: "2026-09-29"
categories:
- "Uncategorized"
images:
- "https://sku-product-images.s3.us-east-2.amazonaws.com/RYC/RYCNB13892001.jpg"
featuredImage: "https://mm.digikey.com/Volume0/opasdata/d220001/derivates/1/100/959/385/1208_ATUM-123-0-STK_sml.jpg"
featured_image: "https://mm.digikey.com/Volume0/opasdata/d220001/derivates/1/003/226/041/MFG_ATUM-XX-X-0-SP_sml(200x200).jpg"
image: "https://jp.c.misumi-ec.com/book/AMP1_E05_MJP/650/0457.jpg"
---

If you are looking for ATUM-12/3-0-STK TE CONNECTIVITY - RAYCHEM, Adhesive Lined Heat Shrink Tubing, Dual Medium Wall you've visit to the right web. We have 34 Pictures about ATUM-12/3-0-STK TE CONNECTIVITY - RAYCHEM, Adhesive Lined Heat Shrink Tubing, Dual Medium Wall like ATUM-12/3-0-STK TE Connectivity Raychem Cable Protection | Cables, Wires - Management | DigiKey, ATUM-12/3-0-STK TE Connectivity | Raychem Products | Heilind and also ATUM-12/4-0-STK : RAYCHEM ATUM 3:1 Heat Shrink Tubing | TE Connectivity. Here you go:

ATUM-12/3-0-STK TE CONNECTIVITY - RAYCHEM, Adhesive Lined Heat Shrink Tubing, Dual Medium Wall
----------------------------------------------------------------------------------------------

 ![ATUM-12/3-0-STK TE CONNECTIVITY - RAYCHEM, Adhesive Lined Heat Shrink Tubing, Dual Medium Wall](https://nl.farnell.com/productimages/standard/en_GB/2752880-40.jpg) <small>nl.farnell.com</small>ATUM-12/3-0-STK TE CONNECTIVITY - RAYCHEM, Adhesive Lined Heat Shrink Tubing, Dual Medium Wall ...

ATUM-12/3-0-STK | Tubos Termorretráctiles TE Connectivity De Poliolefina Negro, Ø 12 Mm, Long. 1
------------------------------------------------------------------------------------------------

 ![ATUM-12/3-0-STK | Tubos termorretráctiles TE Connectivity de Poliolefina Negro, Ø 12 mm, long. 1](https://media.rs-online.com/image/upload/bo_1.5px_solid_white,b_auto,c_pad,dpr_2,f_auto,h_399,q_auto,w_710/c_pad,h_399,w_710/Y0487262-01?pgw=1) <small>es.rs-online.com</small>ATUM-12/3-0-STK | Tubos termorretráctiles TE Connectivity de Poliolefina Negro, Ø 12 mm, long. 1 ...

Raychem ATUM-12/3-0-STK | ProductFrom.com
-----------------------------------------

 ![Raychem ATUM-12/3-0-STK | ProductFrom.com](https://www.productfrom.com/photos/0059/59189_full.jpg) <small>www.productfrom.com</small>Raychem ATUM-12/3-0-STK | ProductFrom.com

ATUM-12/3-0-STK, TE Connectivity купить оптом и в розницу
---------------------------------------------------------

 ![ATUM-12/3-0-STK, TE Connectivity купить оптом и в розницу](https://www.promelec.ru/fs/cache/a1/f8/93/3b/e86a2cbc5ce40c0f3c83c2b6.jpg) <small>www.promelec.ru</small>ATUM-12/3-0-STK, TE Connectivity купить оптом и в розницу

ATUM-12/3-0-STK - Datasheet PDF - Heat Shrink Tubing - TE Connectivity Raychem Cable Protection
-----------------------------------------------------------------------------------------------

 ![ATUM-12/3-0-STK - Datasheet PDF - Heat Shrink Tubing - TE Connectivity Raychem Cable Protection](https://static.utmel.com/200dimg/teconnectivityraychemcableprotection-atum1230stk-0134.jpg) <small>www.utmel.com</small>ATUM-12/3-0-STK - Datasheet PDF - Heat Shrink Tubing - TE Connectivity Raychem Cable Protection ...

ATUM-12/3-0 | TE Connectivity Heat Shrink Tubing, Black 12 Mm Sleeve Dia. X 1.2m Length 4:1
-------------------------------------------------------------------------------------------

 ![ATUM-12/3-0 | TE Connectivity Heat Shrink Tubing, Black 12 mm Sleeve Dia. x 1.2m Length 4:1](https://media.rs-online.com/image/upload/bo_1.5px_solid_white,b_auto,c_pad,dpr_2,f_auto,h_399,q_auto,w_710/c_pad,h_399,w_710/F3161647-01?pgw=1) <small>uk.rs-online.com</small>ATUM-12/3-0 | TE Connectivity Heat Shrink Tubing, Black 12 mm Sleeve Dia. x 1.2m Length 4:1 ...

ATUM-12/3-0-STK TE CONNECTIVITY - RAYCHEM, Adhesive Lined Heat Shrink Tubing, 4:1, 0.472
----------------------------------------------------------------------------------------

 ![ATUM-12/3-0-STK TE CONNECTIVITY - RAYCHEM, Adhesive Lined Heat Shrink Tubing, 4:1, 0.472](https://www.newark.com/productimages/standard/en_US/59AM1170-40.jpg) <small>www.newark.com</small>ATUM-12/3-0-STK TE CONNECTIVITY - RAYCHEM, Adhesive Lined Heat Shrink Tubing, 4:1, 0.472 ...

ATUM-12/4-0-STK Raychem - Te Connectivity, Wärmeschrumpfschlauch Klebebeschichtung, 3:1, 0.472
----------------------------------------------------------------------------------------------

 ![ATUM-12/4-0-STK Raychem - Te Connectivity, Wärmeschrumpfschlauch Klebebeschichtung, 3:1, 0.472](https://de.farnell.com/productimages/large/en_GB/3236574-40.jpg) <small>de.farnell.com</small>ATUM-12/4-0-STK Raychem - Te Connectivity, Wärmeschrumpfschlauch Klebebeschichtung, 3:1, 0.472 ...

ATUM-12/3-2-STK Raychem - Te Connectivity, Adhesive Lined Heat Shrink Tubing, Dual Medium Wall
----------------------------------------------------------------------------------------------

 ![ATUM-12/3-2-STK Raychem - Te Connectivity, Adhesive Lined Heat Shrink Tubing, Dual Medium Wall](https://uk.farnell.com/productimages/large/en_GB/42266388.jpg) <small>uk.farnell.com</small>ATUM-12/3-2-STK Raychem - Te Connectivity, Adhesive Lined Heat Shrink Tubing, Dual Medium Wall ...

ATUM-12/3-0-STK TE Connectivity Raychem Cable Protection | Heat Shrink Tubing | DigiKey
---------------------------------------------------------------------------------------

 ![ATUM-12/3-0-STK TE Connectivity Raychem Cable Protection | Heat Shrink Tubing | DigiKey](https://mm.digikey.com/Volume0/opasdata/d220001/derivates/1/100/959/385/1208_ATUM-123-0-STK_sml.jpg) <small>www.digikey.com</small>ATUM-12/3-0-STK TE Connectivity Raychem Cable Protection | Heat Shrink Tubing | DigiKey

Raychem Heat Shrink Tube, Dual Wall, 4:1 I.D. Shrink Ratio, Black, 48.03 In ATUM-12/3-0-STK | Zoro
--------------------------------------------------------------------------------------------------

 ![Raychem Heat Shrink Tube, Dual Wall, 4:1 I.D. Shrink Ratio, Black, 48.03 in ATUM-12/3-0-STK | Zoro](https://www.zoro.com/static/cms/product/full/Waldom Electronics_ATUMxx12xx3xx0xxSTKxx1xx0e4bce.jpeg) <small>www.zoro.com</small>Raychem Heat Shrink Tube, Dual Wall, 4:1 I.D. Shrink Ratio, Black, 48.03 in ATUM-12/3-0-STK | Zoro

ATUM-12/3-0-STK, TE Connectivity купить оптом и в розницу
---------------------------------------------------------

 ![ATUM-12/3-0-STK, TE Connectivity купить оптом и в розницу](https://www.promelec.ru/fs/cache/68/e4/32/0b/3894e74aa742d0c04dd5da44.jpg) <small>www.promelec.ru</small>ATUM-12/3-0-STK, TE Connectivity купить оптом и в розницу

供应ATUM-12/3-0-STK电线与电缆，TE Connectivity / Raychem品牌电线与电缆ATUM-12/3-0-STK 原装现货\_深圳市圣莱尔电子有限公司
-----------------------------------------------------------------------------------------

 ![供应ATUM-12/3-0-STK电线与电缆，TE Connectivity / Raychem品牌电线与电缆ATUM-12/3-0-STK 原装现货_深圳市圣莱尔电子有限公司](https://www.dzsc.com/news/uploadfile/2013328152729225.jpg) <small>sales.dzsc.com</small>供应ATUM-12/3-0-STK电线与电缆，TE Connectivity / Raychem品牌电线与电缆ATUM-12/3-0-STK 原装现货\_深圳市圣莱尔电子有限公司

Raychem美国瑞侃ATUM热缩管ATUM-12/4-0-STK热收缩绝缘套管进口-淘宝Taobao | 天猫Tmall
-------------------------------------------------------------

 ![Raychem美国瑞侃ATUM热缩管ATUM-12/4-0-STK热收缩绝缘套管进口-淘宝Taobao | 天猫Tmall](https://img.alicdn.com/imgextra/i2/1049709076/O1CN01XHQWKe2GurpGXI6r9_!!1049709076.jpg_q50s50.jpg_.webp) <small>www.taobao.com</small>Raychem美国瑞侃ATUM热缩管ATUM-12/4-0-STK热收缩绝缘套管进口-淘宝Taobao | 天猫Tmall

ATUM-12/3-0-STK TE Connectivity | Raychem Products | Heilind
------------------------------------------------------------

 ![ATUM-12/3-0-STK TE Connectivity | Raychem Products | Heilind](https://sku-product-images.s3.us-east-2.amazonaws.com/AMP/770476-2.png) <small>www.heilind.com</small>ATUM-12/3-0-STK TE Connectivity | Raychem Products | Heilind

ATUM-12/3-0 | TE Connectivity 熱収縮チューブ ATUMシリーズ | TE Connectivity | MISUMI(ミスミ)
------------------------------------------------------------------------------

 ![ATUM-12/3-0 | TE Connectivity 熱収縮チューブ ATUMシリーズ | TE Connectivity | MISUMI(ミスミ)](https://jp.c.misumi-ec.com/book/AMP1_E05_MJP/650/0457.jpg) <small>jp.misumi-ec.com</small>ATUM-12/3-0 | TE Connectivity 熱収縮チューブ ATUMシリーズ | TE Connectivity | MISUMI(ミスミ)

ATUM-12/4-0-STK TE Connectivity | Raychem Products | Heilind
------------------------------------------------------------

 ![ATUM-12/4-0-STK TE Connectivity | Raychem Products | Heilind](https://sku-product-images.s3.us-east-2.amazonaws.com/AMP/AMP206485-1.jpg) <small>www.heilind.com</small>ATUM-12/4-0-STK TE Connectivity | Raychem Products | Heilind

ATUM-12/3-0-STK TE Connectivity Raychem Cable Protection | Heat Shrink Tubing | DigiKey
---------------------------------------------------------------------------------------

 ![ATUM-12/3-0-STK TE Connectivity Raychem Cable Protection | Heat Shrink Tubing | DigiKey](https://mm.digikey.com/Volume0/opasdata/d220001/derivates/1/003/226/041/MFG_ATUM-XX-X-0-SP_sml(200x200).jpg) <small>www.digikey.com</small>ATUM-12/3-0-STK TE Connectivity Raychem Cable Protection | Heat Shrink Tubing | DigiKey

ATUM-12/3-0-STK TE Connectivity | Raychem Products | Heilind
------------------------------------------------------------

 ![ATUM-12/3-0-STK TE Connectivity | Raychem Products | Heilind](https://sku-product-images.s3.us-east-2.amazonaws.com/AMP/640907-2.P.png) <small>www.heilind.com</small>ATUM-12/3-0-STK TE Connectivity | Raychem Products | Heilind

ATUM-12/4-0-STK : RAYCHEM ATUM 3:1 Heat Shrink Tubing | TE Connectivity
-----------------------------------------------------------------------

 ![ATUM-12/4-0-STK : RAYCHEM ATUM 3:1 Heat Shrink Tubing | TE Connectivity](https://www.te.com/content/dam/te-com/catalog/part/EM5/611/600/EM56116001-t1.jpg/jcr:content/renditions/product-high-res.png) <small>www.te.com</small>ATUM-12/4-0-STK : RAYCHEM ATUM 3:1 Heat Shrink Tubing | TE Connectivity

HEATSHRINK DUAL WALL 12MM X 4' ATUM-12/3-0-STK-CS7408 TE Connectivity(Tyco Electronics)製｜電子部品
---------------------------------------------------------------------------------------------

 ![HEATSHRINK DUAL WALL 12MM X 4' ATUM-12/3-0-STK-CS7408 TE Connectivity(Tyco Electronics)製｜電子部品](https://www.marutsu.co.jp/contents/shop/marutsu/dgimg/goods/photos/TycoRaychemPhotos/ATU031K.jpg) <small>www.marutsu.co.jp</small>HEATSHRINK DUAL WALL 12MM X 4' ATUM-12/3-0-STK-CS7408 TE Connectivity(Tyco Electronics)製｜電子部品 ...

ATUM-12/3-0-STK TE Connectivity Raychem Cable Protection | Heat Shrink Tubing | DigiKey
---------------------------------------------------------------------------------------

 ![ATUM-12/3-0-STK TE Connectivity Raychem Cable Protection | Heat Shrink Tubing | DigiKey](https://mm.digikey.com/Volume0/opasdata/d220001/derivates/3/003/226/041/MFG_ATUM-XX-X-0-SP_tmb(64x64).jpg) <small>www.digikey.com</small>ATUM-12/3-0-STK TE Connectivity Raychem Cable Protection | Heat Shrink Tubing | DigiKey

ATUM-12/3-0-STK TE Connectivity | Raychem Products | Heilind
------------------------------------------------------------

 ![ATUM-12/3-0-STK TE Connectivity | Raychem Products | Heilind](https://sku-product-images.s3.us-east-2.amazonaws.com/AMP/AMP2822352-1.jpg) <small>www.heilind.com</small>ATUM-12/3-0-STK TE Connectivity | Raychem Products | Heilind

ATUM-12/4-0-STK TE Connectivity | Raychem Products | Heilind
------------------------------------------------------------

 ![ATUM-12/4-0-STK TE Connectivity | Raychem Products | Heilind](https://sku-product-images.s3.us-east-2.amazonaws.com/RYC/RYCNB13892001.jpg) <small>www.heilind.com</small>ATUM-12/4-0-STK TE Connectivity | Raychem Products | Heilind

ATUM-12/3-0-STK TE Connectivity Raychem Cable Protection | Cables, Wires - Management | DigiKey
-----------------------------------------------------------------------------------------------

 ![ATUM-12/3-0-STK TE Connectivity Raychem Cable Protection | Cables, Wires - Management | DigiKey](https://mm.digikey.com/Volume0/opasdata/d220001/medias/images/4847/1208_ATUM-123-0-STK.JPG) <small>www.digikey.ca</small>ATUM-12/3-0-STK TE Connectivity Raychem Cable Protection | Cables, Wires - Management | DigiKey

ATUM-12/3-0-STK | Tubos Termorretráctiles Chemelex De Poliolefina Negro, Contracción 4:1, Ø 12
----------------------------------------------------------------------------------------------

 ![ATUM-12/3-0-STK | Tubos termorretráctiles Chemelex de Poliolefina Negro, contracción 4:1, Ø 12](https://media.rs-online.com/image/upload/bo_1.5px_solid_white,b_auto,c_pad,dpr_2,f_auto,h_399,q_auto,w_710/c_pad,h_399,w_710/Y0433204-01?pgw=1) <small>es.rs-online.com</small>ATUM-12/3-0-STK | Tubos termorretráctiles Chemelex de Poliolefina Negro, contracción 4:1, Ø 12 ...

ATUM-12/4-0-STK TE Connectivity | Raychem Products | Heilind
------------------------------------------------------------

 ![ATUM-12/4-0-STK TE Connectivity | Raychem Products | Heilind](https://sku-product-images.s3.us-east-2.amazonaws.com/AMP/794911-1.jpg) <small>www.heilind.com</small>ATUM-12/4-0-STK TE Connectivity | Raychem Products | Heilind

ATUM-12/4-0-STK TE Connectivity Raychem Cable Protection | Cables, Wires - Management | DigiKey
-----------------------------------------------------------------------------------------------

 ![ATUM-12/4-0-STK TE Connectivity Raychem Cable Protection | Cables, Wires - Management | DigiKey](https://media.digikey.com/pdf/Catalog Drawings/Heat Shrink/ATUM-124-0-STK.jpg) <small>www.digikey.com</small>ATUM-12/4-0-STK TE Connectivity Raychem Cable Protection | Cables, Wires - Management | DigiKey

Raychem美国瑞侃ATUM热缩管ATUM-12/4-0-STK热收缩绝缘套管进口-淘宝Taobao | 天猫Tmall
-------------------------------------------------------------

 ![Raychem美国瑞侃ATUM热缩管ATUM-12/4-0-STK热收缩绝缘套管进口-淘宝Taobao | 天猫Tmall](https://img.alicdn.com/imgextra/i4/1049709076/O1CN01qy2maV2GurpFerjvY_!!1049709076.jpg_q50s50.jpg_.webp) <small>www.taobao.com</small>Raychem美国瑞侃ATUM热缩管ATUM-12/4-0-STK热收缩绝缘套管进口-淘宝Taobao | 天猫Tmall

ATUM-12/3-0-STK-CS7408 TE Connectivity Raychem Cable Protection From Ichome.com
-------------------------------------------------------------------------------

 ![ATUM-12/3-0-STK-CS7408 TE Connectivity Raychem Cable Protection from ichome.com](https://img.ichome.com/1132798/atum-12-3-0-stk-cs7408.jpg) <small>www.ichome.com</small>ATUM-12/3-0-STK-CS7408 TE Connectivity Raychem Cable Protection from ichome.com

ATUM-12/3-0-STK - Te Connectivity / Raychem Brand - OnlineComponents.com
------------------------------------------------------------------------

 ![ATUM-12/3-0-STK - Te Connectivity / Raychem Brand - OnlineComponents.com](https://media.onlinecomponents.com/images/parts/webp-large-images/12275588.webp) <small>www.onlinecomponents.com</small>ATUM-12/3-0-STK - Te Connectivity / Raychem Brand - OnlineComponents.com

Термосвиваем шлаух с лепило ATUM-12/3-0-STK Термосвиваема тръба с лепило 4: 1 12mm L: 1,2m черен
------------------------------------------------------------------------------------------------

 ![Термосвиваем шлаух с лепило ATUM-12/3-0-STK Термосвиваема тръба с лепило 4: 1 12mm L: 1,2m черен](https://static.protonbg.bg/thumbs/3/25371_40181_806502_1.jpg) <small>protonbg.bg</small>Термосвиваем шлаух с лепило ATUM-12/3-0-STK Термосвиваема тръба с лепило 4: 1 12mm L: 1,2m черен ...

ATUM12/3-0-STK | TE Connectivity | 4:1 Tubing | Prowireusa
----------------------------------------------------------

 ![ATUM12/3-0-STK | TE Connectivity | 4:1 Tubing | Prowireusa](https://www.prowireusa.com/content/90771/ATUM12-3-0-STK  TE Connectivity_thumb100.webp) <small>www.prowireusa.com</small>ATUM12/3-0-STK | TE Connectivity | 4:1 Tubing | Prowireusa

ATUM-8/2-0-STK TE Connectivity Raychem Cable Protection | 电缆，电线 - 管理 | DigiKey
------------------------------------------------------------------------------

 ![ATUM-8/2-0-STK TE Connectivity Raychem Cable Protection | 电缆，电线 - 管理 | DigiKey](https://mm.digikey.com/Volume0/opasdata/d220001/derivates/3/100/959/385/1208_ATUM-123-0-STK_tmb.jpg) <small>www.digikey.cn</small>ATUM-8/2-0-STK TE Connectivity Raychem Cable Protection | 电缆，电线 - 管理 | DigiKey

atum-12/3-0-stk te connectivity. Raychem atum-12/3-0-stk. Heatshrink dual wall 12mm x 4' atum-12/3-0-stk-cs7408 te connectivity(tyco electronics)製｜電子部品
