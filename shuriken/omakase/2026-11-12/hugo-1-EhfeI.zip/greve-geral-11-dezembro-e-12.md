---
title: "Greve Geral 11 Dezembro E 12 - Greve geral em portugal – 11 de dezembro"
description: "Ugt aprova por unanimidade greve geral a 11 de dezembro"
date: "2026-01-19"
categories:
- "Uncategorized"
images:
- "https://sincomar.pt/wp-content/uploads/2025/12/2-cartaz-GREVE-GERAL-UGT-final.jpg"
featuredImage: "https://img.iol.pt/image/id/693b2a1ad34e3caad84c47e9/1024.jpg"
featured_image: "https://img.iol.pt/image/id/693b2a1ad34e3caad84c47e9/1024.jpg"
image: "https://www.flemacon.org/wp-content/uploads/2025/12/WhatsApp-Image-2025-12-12-at-19.45.27-1-696x870.jpeg"
---

If you are searching about SDP Sul you've came to the right place. We have 35 Pictures about SDP Sul like GREVE GERAL – Dia 11 de Dezembro | Sincomar - Sindicato de Capitães e Oficiais da Marinha Mercante, S.TO.P. junta-se à greve geral de 11 de dezembro com pré-aviso de greve para a educação and also GREVE GERAL DIA 11 DEZEMBRO DE 2025 | FESAHT. Read more:

SDP Sul
-------

 ![SDP Sul](https://sdpsul.com/storage/publicacao/imagem_563_6929dba6ddf62.jpeg) <small>sdpsul.com</small>SDP Sul

SPGL - Greve Geral | 11 De Dezembro De 2025 (Piquetes, Concentrações E Manifestações)
-------------------------------------------------------------------------------------

 ![SPGL - Greve Geral | 11 de dezembro de 2025 (Piquetes, Concentrações e Manifestações)](https://www.spgl.pt/Media/Default/_Profiles/722d2b7d/68bcf4e1/IMG_2694.JPG?v=639010778412646835) <small>www.spgl.pt</small>SPGL - Greve Geral | 11 de dezembro de 2025 (Piquetes, Concentrações e Manifestações)

SPN - Fenprof — Adesão Histórica à Greve Geral
----------------------------------------------

 ![SPN - Fenprof — Adesão histórica à greve geral](https://www.spn.pt/Media/Default/Info/68000/500/60/7/grevegeral11dez_cartaz.jpg) <small>www.spn.pt</small>SPN - Fenprof — Adesão histórica à greve geral

SIPE - 📢 Motivações Para A Adesão à Greve Geral – 11 De Dezembro De 2025 O SIPE Está Envolvido
----------------------------------------------------------------------------------------------

 ![SIPE - 📢 Motivações para a adesão à Greve Geral – 11 de dezembro de 2025 O SIPE está envolvido](https://lookaside.fbsbx.com/lookaside/crawler/media/?media_id=1270541985109687) <small>www.facebook.com</small>SIPE - 📢 Motivações para a adesão à Greve Geral – 11 de dezembro de 2025 O SIPE está envolvido ...

A Greve Geral De 11 De Dezembro Em 38 Imagens – Observador
----------------------------------------------------------

 ![A greve geral de 11 de dezembro em 38 imagens – Observador](https://bordalo.observador.pt/v2/q:60/rs:fill:1440/c:4096:2730:nowe:0:0/plain/https://s3.observador.pt/wp-content/uploads/2025/12/11173228/dventura-greve-geral-11dez-41-scaled.jpg) <small>observador.pt</small>A greve geral de 11 de dezembro em 38 imagens – Observador

Aprovada Greve Geral A 11 De Dezembro - JN
------------------------------------------

 ![Aprovada greve geral a 11 de dezembro - JN](https://staticx.noticiasilimitadas.pt/jn/image.webp?brand=jn&type=generate&guid=2f8a95a6-a95b-4d9e-9129-e7b34b5a15b5&w=3840) <small>www.jn.pt</small>Aprovada greve geral a 11 de dezembro - JN

A Greve Geral De 11 De Dezembro Em 38 Imagens – Observador
----------------------------------------------------------

 ![A greve geral de 11 de dezembro em 38 imagens – Observador](https://bordalo.observador.pt/v2/q:60/rs:fill:1440/c:4096:2730:nowe:0:0/plain/https://s3.observador.pt/wp-content/uploads/2025/12/11173414/dventura-greve-geral-11dez-54-scaled.jpg) <small>observador.pt</small>A greve geral de 11 de dezembro em 38 imagens – Observador

A Greve Geral De 11 De Dezembro Em 38 Imagens – Observador
----------------------------------------------------------

 ![A greve geral de 11 de dezembro em 38 imagens – Observador](https://bordalo.observador.pt/v2/q:60/rs:fill:1440/c:4096:2730:nowe:0:0/plain/https://s3.observador.pt/wp-content/uploads/2025/12/11173246/dventura-greve-geral-11dez-43-scaled.jpg) <small>observador.pt</small>A greve geral de 11 de dezembro em 38 imagens – Observador

Greve Geral Em Portugal – 11 De Dezembro - FLEMACON
---------------------------------------------------

 ![Greve geral em Portugal – 11 de dezembro - FLEMACON](https://www.flemacon.org/wp-content/uploads/2025/12/WhatsApp-Image-2025-12-12-at-19.45.27-1-696x870.jpeg) <small>www.flemacon.org</small>Greve geral em Portugal – 11 de dezembro - FLEMACON

Climáximo Apoia A Greve Geral - Climaximo
-----------------------------------------

 ![Climáximo apoia a Greve Geral - Climaximo](https://www.climaximo.pt/wp-content/uploads/2025/12/Greve-Geral3-819x1024.png) <small>www.climaximo.pt</small>Climáximo apoia a Greve Geral - Climaximo

Motivos Da Adesão à Greve Geral De 11 De Dezembro De 2025
---------------------------------------------------------

 ![Motivos da adesão à Greve Geral de 11 de dezembro de 2025](https://spzn.pt/uploads/noticias/big_1763717239_6728_SPZN_2025_site_novo_(17).png) <small>spzn.pt</small>Motivos da adesão à Greve Geral de 11 de dezembro de 2025

Greve Geral De 11 De Dezembro: Saudação A Todos Os Educadores, Professores E Investigadores
-------------------------------------------------------------------------------------------

 ![Greve Geral de 11 de dezembro: Saudação a todos os Educadores, Professores e Investigadores](https://static.wixstatic.com/media/d0f32c_8a3cc6ad84094dbda8b603cfe1bf566c~mv2.jpeg/v1/fill/w_980,h_735,al_c,q_85,usm_0.66_1.00_0.01,enc_avif,quality_auto/d0f32c_8a3cc6ad84094dbda8b603cfe1bf566c~mv2.jpeg) <small>www.sprc.pt</small>Greve Geral de 11 de dezembro: Saudação a todos os Educadores, Professores e Investigadores

S.TO.P. Junta-se à Greve Geral De 11 De Dezembro Com Pré-aviso De Greve Para A Educação
---------------------------------------------------------------------------------------

 ![S.TO.P. junta-se à greve geral de 11 de dezembro com pré-aviso de greve para a educação](https://stop-sindicato.pt/wp-content/uploads/2025/11/S.TO_.P.-Cartaz-Greve-Geral-Educacao-11Dez2025_x1000-724x1024.png) <small>stop-sindicato.pt</small>S.TO.P. junta-se à greve geral de 11 de dezembro com pré-aviso de greve para a educação ...

GREVE GERAL – Protesto Em Frente Da Escola Secundária De Caneças – 11 Dezembro 8h00 – Sindicato
-----------------------------------------------------------------------------------------------

 ![GREVE GERAL – Protesto em frente da Escola Secundária de Caneças – 11 Dezembro 8h00 – Sindicato](https://stop-sindicato.pt/wp-content/uploads/2025/12/S.TO_.P.-Cartaz-Protesto-AE-Canecas-GreveGeral-11Dez-8h-1086x1536.png) <small>stop-sindicato.pt</small>GREVE GERAL – Protesto em frente da Escola Secundária de Caneças – 11 Dezembro 8h00 – Sindicato ...

FAQ: Os Direitos Dos Docentes Em Dia De Greve Geral - 11/12/2025
----------------------------------------------------------------

 ![FAQ: Os direitos dos docentes em dia de Greve Geral - 11/12/2025](https://static.wixstatic.com/media/d0f32c_9ff1199ee2c34418af0094a43c516733~mv2.png/v1/fill/w_940,h_788,al_c,q_90,enc_avif,quality_auto/d0f32c_9ff1199ee2c34418af0094a43c516733~mv2.png) <small>www.sprc.pt</small>FAQ: Os direitos dos docentes em dia de Greve Geral - 11/12/2025

11 De Dezembro. Portugal Terá A Sua Primeira Greve Geral Em 12 Anos Contra O Pacote Laboral
-------------------------------------------------------------------------------------------

 ![11 de Dezembro. Portugal terá a sua primeira Greve Geral em 12 anos contra o pacote laboral](https://www.esquerdadiario.com.br/IMG/logo/imagem_do_whatsapp_de_2025-11-18_a_s_20.02_31_2e7bdf41.jpg?1763508227) <small>www.esquerdadiario.com.br</small>11 de Dezembro. Portugal terá a sua primeira Greve Geral em 12 anos contra o pacote laboral ...

Greve Geral De 11 De Dezembro Em Portugal: Razões Para Participar
-----------------------------------------------------------------

 ![Greve Geral de 11 de dezembro em Portugal: razões para participar](https://sabiasque.pt/images/stories/2025/trabalho/20251209-greve-geral-11-dezembro-320x480.jpg) <small>sabiasque.pt</small>Greve Geral de 11 de dezembro em Portugal: razões para participar

Agrupamento De Escolas De Mira - Pré - Aviso De Greve Para Os Dias 11 E 12 De Dezembro De 2025
----------------------------------------------------------------------------------------------

 ![Agrupamento de Escolas de Mira - Pré - aviso de greve para os dias 11 e 12 de dezembro de 2025](https://www.escolasdemira.pt/images/PR-_AVISO_DE_GREVE_para_os_dias_11_e_12_de_dezembro_de_2025.png) <small>www.escolasdemira.pt</small>Agrupamento de Escolas de Mira - Pré - aviso de greve para os dias 11 e 12 de dezembro de 2025

VISEU - Esclarecimento E Mobilização Para A Greve Geral Marcada Para 11 De Dezembro - CGTP-IN
---------------------------------------------------------------------------------------------

 ![VISEU - Esclarecimento e mobilização para a Greve Geral marcada para 11 de Dezembro - CGTP-IN](https://www.cgtp.pt/images/accao-e-luta/2025/gg.jpg) <small>www.cgtp.pt</small>VISEU - Esclarecimento e mobilização para a Greve Geral marcada para 11 de Dezembro - CGTP-IN

GREVE GERAL – Dia 11 De Dezembro | Sincomar - Sindicato De Capitães E Oficiais Da Marinha Mercante
--------------------------------------------------------------------------------------------------

 ![GREVE GERAL – Dia 11 de Dezembro | Sincomar - Sindicato de Capitães e Oficiais da Marinha Mercante](https://sincomar.pt/wp-content/uploads/2025/12/2-cartaz-GREVE-GERAL-UGT-final.jpg) <small>sincomar.pt</small>GREVE GERAL – Dia 11 de Dezembro | Sincomar - Sindicato de Capitães e Oficiais da Marinha Mercante

GREVE GERAL – Concentração Em Frente Da Câmara Municipal De Portimão – 11 Dezembro 8h30
---------------------------------------------------------------------------------------

 ![GREVE GERAL – Concentração em frente da Câmara Municipal de Portimão – 11 Dezembro 8h30](https://stop-sindicato.pt/wp-content/uploads/2025/12/S.TO_.P.-Cartaz-Protesto-CM-Portimao-GreveGeral-11Dez-8h30.png) <small>stop-sindicato.pt</small>GREVE GERAL – Concentração em frente da Câmara Municipal de Portimão – 11 Dezembro 8h30 ...

GREVE GERAL DE 11 DE DEZEMBRO DE 2025 – MANIFESTAÇÕES – VIANA DO CASTELO – EPHEMERA – Biblioteca
------------------------------------------------------------------------------------------------

 ![GREVE GERAL DE 11 DE DEZEMBRO DE 2025 – MANIFESTAÇÕES – VIANA DO CASTELO – EPHEMERA – Biblioteca](https://ephemerajpp.com/wp-content/uploads/2025/12/IMG-20251211-WA0007.jpg) <small>ephemerajpp.com</small>GREVE GERAL DE 11 DE DEZEMBRO DE 2025 – MANIFESTAÇÕES – VIANA DO CASTELO – EPHEMERA – Biblioteca ...

UGT Vai Reunir-se Com Ministra Do Trabalho Mas Avisa Que "é Impossível Negociar" Sozinha A
------------------------------------------------------------------------------------------

 ![UGT vai reunir-se com ministra do Trabalho mas avisa que "é impossível negociar" sozinha a](https://img.iol.pt/image/id/693b2a1ad34e3caad84c47e9/1024.jpg) <small>cnnportugal.iol.pt</small>UGT vai reunir-se com ministra do Trabalho mas avisa que "é impossível negociar" sozinha a ...

Adere à Greve Geral Dia 11 De Dezembro
--------------------------------------

 ![Adere à Greve Geral dia 11 de dezembro](https://www.sep.org.pt/files/uploads/2025/11/SEP_GREVEGERAL_WEB_1-800x350.jpg) <small>www.sep.org.pt</small>Adere à Greve Geral dia 11 de dezembro

UGT Aprova Por Unanimidade Greve Geral A 11 De Dezembro - Diário Do Minho
-------------------------------------------------------------------------

 ![UGT aprova por unanimidade greve geral a 11 de dezembro - Diário do Minho](https://www.diariodominho.pt/storage/posts/greve-direito-a-greve_655b8a6d702c0_og.jpg) <small>www.diariodominho.pt</small>UGT aprova por unanimidade greve geral a 11 de dezembro - Diário do Minho

Pré-Aviso De Greve 11 E 12 De Dezembro
--------------------------------------

 ![Pré-Aviso de Greve 11 e 12 de dezembro](https://static.wixstatic.com/media/1029eb_b4cf39036f744ea9833c234b7b4b5af5~mv2.jpg/v1/fill/w_980,h_1386,al_c,q_85,usm_0.66_1.00_0.01,enc_avif,quality_auto/1029eb_b4cf39036f744ea9833c234b7b4b5af5~mv2.jpg) <small>www.aecadaval.com</small>Pré-Aviso de Greve 11 e 12 de dezembro

Perguntas E Respostas Sobre A Greve Geral De 11 De Dezembro - SBC - Sindicato Nacional Dos
------------------------------------------------------------------------------------------

 ![Perguntas e respostas sobre a Greve Geral de 11 de dezembro - SBC - Sindicato Nacional dos](https://www.sibace.pt/wp-content/uploads/2025/11/greve-2-1170-x-400.png) <small>www.sibace.pt</small>Perguntas e respostas sobre a Greve Geral de 11 de dezembro - SBC - Sindicato Nacional dos ...

GREVE GERAL DE 11 DE DEZEMBRO DE 2025 – MANIFESTAÇÕES – LISBOA (VÍDEO) – EPHEMERA – Biblioteca E
------------------------------------------------------------------------------------------------

 ![GREVE GERAL DE 11 DE DEZEMBRO DE 2025 – MANIFESTAÇÕES – LISBOA (VÍDEO) – EPHEMERA – Biblioteca e](https://ephemerajpp.com/wp-content/uploads/2025/12/IMG_2182.jpg) <small>ephemerajpp.com</small>GREVE GERAL DE 11 DE DEZEMBRO DE 2025 – MANIFESTAÇÕES – LISBOA (VÍDEO) – EPHEMERA – Biblioteca e ...

Mais De 50 Sindicatos Aderem à Greve Geral Marcada Para 11 De Dezembro - SIC Notícias
-------------------------------------------------------------------------------------

 ![Mais de 50 sindicatos aderem à greve geral marcada para 11 de dezembro - SIC Notícias](https://images.impresa.pt/sicnot/2025-11-17-cgtp-pre-aviso-greve-82e19fc3-1/16x9/mw-1200) <small>sicnoticias.pt</small>Mais de 50 sindicatos aderem à greve geral marcada para 11 de dezembro - SIC Notícias

Aviso Prévio De Greves - 11 E 12 De Dezembro 2025
-------------------------------------------------

 ![Aviso Prévio de Greves - 11 e 12 de dezembro 2025](https://aefernandopessoafeira.pt/images/noticias/2025/aviso-previo-de-greve/aviso-previo-de-greve.jpg) <small>aefernandopessoafeira.pt</small>Aviso Prévio de Greves - 11 e 12 de dezembro 2025

Greve Geral De 11 De Dezembro: Impacto Económico Estimado E Análise | Economia
------------------------------------------------------------------------------

 ![Greve Geral de 11 de Dezembro: Impacto Económico Estimado e Análise | Economia](https://i.headtopics.com/images/2025/12/6/publico/greve-geral-o-que-e-quem-abrange-e-como-funciona-greve-geral-o-que-e-quem-abrange-e-como-funciona-43970BF408A401F542300934033BEA05.webp?w=640) <small>ph.headtopics.com</small>Greve Geral de 11 de Dezembro: Impacto Económico Estimado e Análise | Economia

Greve Geral Paralisa Transportes, Saúde E Educação No Porto - Expresso
----------------------------------------------------------------------

 ![Greve geral paralisa transportes, saúde e educação no Porto - Expresso](https://images.impresa.pt/expresso/2025-12-11-rds_15_greve-geral-2025-manifestacao-porto_rds_4314.jpg-f75ffda9/original) <small>expresso.pt</small>Greve geral paralisa transportes, saúde e educação no Porto - Expresso

Dos Transportes à Saúde, Lares E Prisões, Que Serviços Mínimos Estão Garantidos Para A Greve
--------------------------------------------------------------------------------------------

 ![Dos transportes à saúde, lares e prisões, que serviços mínimos estão garantidos para a greve](https://images.impresa.pt/expresso/2025-12-09-greve-geral.jpg-0c01f0f6/original) <small>expresso.pt</small>Dos transportes à saúde, lares e prisões, que serviços mínimos estão garantidos para a greve ...

GREVE GERAL DIA 11 DEZEMBRO DE 2025 | FESAHT
--------------------------------------------

 ![GREVE GERAL DIA 11 DEZEMBRO DE 2025 | FESAHT](https://sindicatos.cgtp.pt/fesaht/wp-content/blogs.dir/52/files/sites/52/2025/12/11-DEZ-faz-greve-e-sai-a-Rua.jpg) <small>sindicatos.cgtp.pt</small>GREVE GERAL DIA 11 DEZEMBRO DE 2025 | FESAHT

Pré-Aviso De Greve 11 E 12 De Dezembro
--------------------------------------

 ![Pré-Aviso de Greve 11 e 12 de dezembro](https://static.wixstatic.com/media/1029eb_a6db1017a2334a9abf146e02d7454c28~mv2.png/v1/fill/w_770,h_395,al_c,lg_1,q_85/1029eb_a6db1017a2334a9abf146e02d7454c28~mv2.png) <small>www.aecadaval.com</small>Pré-Aviso de Greve 11 e 12 de dezembro

A greve geral de 11 de dezembro em 38 imagens – observador. greve geral de 11 de dezembro: saudação a todos os educadores, professores e investigadores. greve geral em portugal – 11 de dezembro
