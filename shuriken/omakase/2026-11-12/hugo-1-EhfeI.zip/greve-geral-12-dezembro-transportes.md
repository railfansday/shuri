---
title: "Greve Geral 12 Dezembro Transportes - Greve geral – 24 horas – dia 11 de dezembro de 2025 – sinttav sindicato nacional dos"
description: "Greve geral: escolas fechadas, transportes parados e impacto nacional"
date: "2026-10-12"
categories:
- "Uncategorized"
images:
- "https://cdn.sabado.pt/images/2026-05/img_980x653uu2026-05-21-18-26-04-766232.jpg"
featuredImage: "https://lookaside.fbsbx.com/lookaside/crawler/media/?media_id=1634621500842359"
featured_image: "https://img.iol.pt/image/id/693b2a1ad34e3caad84c47e9/1024.jpg"
image: "https://s.rfi.fr/media/display/074d4efc-d66a-11f0-a540-005056bfb2b6/w:1024/p:9x16/AP25345021595048.jpg"
---

If you are looking for Braga: Transportes, escolas e cultura paralisados por adesão “elevadíssima” à greve | e24.pt you've came to the right web. We have 35 Pictures about Braga: Transportes, escolas e cultura paralisados por adesão “elevadíssima” à greve | e24.pt like Greve Geral: Escolas Fechadas, Transportes Parados e Impacto Nacional, 15 minutos: impacto da greve geral já se começou a sentir no setor dos transportes - SIC Notícias and also Agrupamento de Escolas de Mira - Pré - aviso de greve para os dias 11 e 12 de dezembro de 2025. Here you go:

Braga: Transportes, Escolas E Cultura Paralisados Por Adesão “elevadíssima” à Greve | E24.pt
--------------------------------------------------------------------------------------------

 ![Braga: Transportes, escolas e cultura paralisados por adesão “elevadíssima” à greve | e24.pt](https://e24.pt/wp-content/uploads/2025/12/geral-greve-geral-Braga-1-1-860x531.jpeg) <small>e24.pt</small>Braga: Transportes, escolas e cultura paralisados por adesão “elevadíssima” à greve | e24.pt

Greve Geral Paralisa Transportes, Saúde E Educação No Porto - Expresso
----------------------------------------------------------------------

 ![Greve geral paralisa transportes, saúde e educação no Porto - Expresso](https://images.impresa.pt/expresso/2025-12-11-rds_15_greve-geral-2025-manifestacao-porto_rds_4314.jpg-f75ffda9/1.91x1?wm=true&outputFormat=jpeg) <small>expresso.pt</small>Greve geral paralisa transportes, saúde e educação no Porto - Expresso

Mapa QZP Carenciados De 2025/26 – Despacho N.º 11200-A/2025 – Apoio à Deslocação – Sindicato S.TO.P.
----------------------------------------------------------------------------------------------------

 ![Mapa QZP carenciados de 2025/26 – Despacho n.º 11200-A/2025 – Apoio à deslocação – Sindicato S.TO.P.](https://stop-sindicato.pt/wp-content/uploads/2025/11/S.TO_.P.-Cartaz-Greve-Geral-Educacao-11Dez2025_x1000-768x1086.png) <small>stop-sindicato.pt</small>Mapa QZP carenciados de 2025/26 – Despacho n.º 11200-A/2025 – Apoio à deslocação – Sindicato S.TO.P.

Transportes, Hospitais, Escolas E Até Bancos. Que Setores Vão Ser Afetados Pela Greve Geral? – ECO
--------------------------------------------------------------------------------------------------

 ![Transportes, hospitais, escolas e até bancos. Que setores vão ser afetados pela greve geral? – ECO](https://ecoonline.s3.amazonaws.com/uploads/2025/12/46141990.jpg) <small>eco.sapo.pt</small>Transportes, hospitais, escolas e até bancos. Que setores vão ser afetados pela greve geral? – ECO

Greve Geral. Metro De Lisboa Prevê Paralisação Do Serviço E Encerramento Das Estações – ECO
-------------------------------------------------------------------------------------------

 ![Greve Geral. Metro de Lisboa prevê paralisação do serviço e encerramento das estações – ECO](https://eco.imgix.net/uploads/2025/12/thumb-1.jpg) <small>eco.sapo.pt</small>Greve Geral. Metro de Lisboa prevê paralisação do serviço e encerramento das estações – ECO

Dos Transportes à Saúde, Lares E Prisões, Que Serviços Mínimos Estão Garantidos Para A Greve
--------------------------------------------------------------------------------------------

 ![Dos transportes à saúde, lares e prisões, que serviços mínimos estão garantidos para a greve](https://images.impresa.pt/expresso/2025-12-09-greve-geral.jpg-0c01f0f6/original) <small>expresso.pt</small>Dos transportes à saúde, lares e prisões, que serviços mínimos estão garantidos para a greve ...

Pré-Aviso De Greve 11 E 12 De Dezembro
--------------------------------------

 ![Pré-Aviso de Greve 11 e 12 de dezembro](https://static.wixstatic.com/media/1029eb_a6db1017a2334a9abf146e02d7454c28~mv2.png/v1/fill/w_770,h_395,al_c,lg_1,q_85/1029eb_a6db1017a2334a9abf146e02d7454c28~mv2.png) <small>www.aecadaval.com</small>Pré-Aviso de Greve 11 e 12 de dezembro

Greve Geral: Saiba Quais São Os Serviços Mínimos Já Decretados - SIC Notícias
-----------------------------------------------------------------------------

 ![Greve geral: saiba quais são os serviços mínimos já decretados - SIC Notícias](https://images.impresa.pt/sicnot/2025-11-17-cgtp-pre-aviso-greve-82e19fc3-1/16x9/mw-1200) <small>sicnoticias.pt</small>Greve geral: saiba quais são os serviços mínimos já decretados - SIC Notícias

TCB | Pré-aviso De Greve A 11 De Dezembro - Portal Institucional
----------------------------------------------------------------

 ![TCB | Pré-aviso de greve a 11 de dezembro - Portal Institucional](https://www.cm-barreiro.pt/wp-content/uploads/2025/12/GREVE-11_DEZEMBRO_1920px-1536x920.jpg) <small>www.cm-barreiro.pt</small>TCB | Pré-aviso de greve a 11 de dezembro - Portal Institucional

Saiba Tudo Sobre A Greve Geral De Amanhã
----------------------------------------

 ![Saiba tudo sobre a greve geral de Amanhã](https://jornaldemafra.pt/wp-content/uploads/2025/12/greve-geral.webp) <small>jornaldemafra.pt</small>Saiba tudo sobre a greve geral de Amanhã

Greve Geral Ameaça Parar Saúde, Educação, Transportes | Sintra Notícias
-----------------------------------------------------------------------

 ![Greve geral ameaça parar saúde, educação, transportes | Sintra Notícias](https://sintranoticias.pt/wp-content/uploads/2025/12/greve-geral2.jpg) <small>sintranoticias.pt</small>Greve geral ameaça parar saúde, educação, transportes | Sintra Notícias

Governo Promete “minimizar E Mitigar” Os Efeitos Da Greve Geral: Até Onde Pode Ir? - Expresso
---------------------------------------------------------------------------------------------

 ![Governo promete “minimizar e mitigar” os efeitos da greve geral: até onde pode ir? - Expresso](https://images.impresa.pt/expresso/2025-11-08-manifestacao-da-cgtp-contra-o-pacote-laboral-com-anuncio-de-greve-geral-4e98c28a/1.91x1?wm=true&outputFormat=jpeg) <small>expresso.pt</small>Governo promete “minimizar e mitigar” os efeitos da greve geral: até onde pode ir? - Expresso

Agrupamento De Escolas De Mira - Pré - Aviso De Greve Para Os Dias 11 E 12 De Dezembro De 2025
----------------------------------------------------------------------------------------------

 ![Agrupamento de Escolas de Mira - Pré - aviso de greve para os dias 11 e 12 de dezembro de 2025](https://www.escolasdemira.pt/images/PR-_AVISO_DE_GREVE_para_os_dias_11_e_12_de_dezembro_de_2025.png) <small>www.escolasdemira.pt</small>Agrupamento de Escolas de Mira - Pré - aviso de greve para os dias 11 e 12 de dezembro de 2025

🔴 Ao Minuto: Foi Assim A Greve Geral De 11 De Dezembro De 2025 - Renascença
---------------------------------------------------------------------------

 ![🔴 Ao minuto: Foi assim a greve geral de 11 de dezembro de 2025 - Renascença](https://images.rr.pt/geve-geral-de-11-de-dezembro-de-2025-na-assembleia-da-republica-foto-ricardo-fortunato-rr-31311c45c_socialshare.jpg) <small>rr.pt</small>🔴 Ao minuto: Foi assim a greve geral de 11 de dezembro de 2025 - Renascença

Depois Da Greve Geral, Mais Uma Paralisação Marcada Para 12 De Dezembro | A Bola
--------------------------------------------------------------------------------

 ![Depois da Greve Geral, mais uma paralisação marcada para 12 de dezembro | A Bola](https://sportal365images.com/process/smp-images-production/abola.pt/09122025/6efc249f-1534-4fe0-94ae-f9c29c518ecd.webp?operations=scale(860:574)) <small>www.abola.pt</small>Depois da Greve Geral, mais uma paralisação marcada para 12 de dezembro | A Bola

SDP Sul
-------

 ![SDP Sul](https://sdpsul.com/storage/publicacao/imagem_563_6929dba6ddf62.jpeg) <small>sdpsul.com</small>SDP Sul

A Greve Que Parou O País: Dos Constrangimentos Nos Transportes, Saúde E Educação à Tensão Junto
-----------------------------------------------------------------------------------------------

 ![A greve que parou o País: dos constrangimentos nos transportes, saúde e educação à tensão junto](https://cdn.cmjornal.pt/images/2025-12/img_1300x732uu2025-12-11-20-00-10-2253909.jpg) <small>www.cmjornal.pt</small>A greve que parou o País: dos constrangimentos nos transportes, saúde e educação à tensão junto ...

Unificar As Lutas, Rumo à Construção Da Greve Geral - Liga Internacional Dos TrabalhadoresLiga
----------------------------------------------------------------------------------------------

 ![Unificar as lutas, rumo à construção da greve geral - Liga Internacional dos TrabalhadoresLiga](https://litci.org/pt/wp-content/uploads/2022/11/Portugal.jpeg) <small>litci.org</small>Unificar as lutas, rumo à construção da greve geral - Liga Internacional dos TrabalhadoresLiga ...

O Que Vai Parar Com A Greve Geral De 3 De Junho? - Portugal - SÁBADO
--------------------------------------------------------------------

 ![O que vai parar com a greve geral de 3 de junho? - Portugal - SÁBADO](https://cdn.sabado.pt/images/2026-05/img_980x653uu2026-05-21-18-26-04-766232.jpg) <small>www.sabado.pt</small>O que vai parar com a greve geral de 3 de junho? - Portugal - SÁBADO

Greve Geral A 11 De Dezembro | Sindicato Dos Quadros Técnicos Do Estado
-----------------------------------------------------------------------

 ![Greve Geral a 11 de Dezembro | Sindicato dos Quadros Técnicos do Estado](https://www.ste.pt/wp-content/uploads/2025/12/GreveGeral-Cartaz-scaled.jpg) <small>www.ste.pt</small>Greve Geral a 11 de Dezembro | Sindicato dos Quadros Técnicos do Estado

Greve Geral Histórica Em Portugal Paralisa Transportes, Fecha Escolas E Pressiona Hospitais
-------------------------------------------------------------------------------------------

 ![Greve geral histórica em Portugal paralisa transportes, fecha escolas e pressiona hospitais](https://p2.trrsf.com/image/fget/cf/1200/630/middle/images.terra.com/2025/12/11/greve-ubj4bs8ccokh.png) <small>www.terra.com.br</small>Greve geral histórica em Portugal paralisa transportes, fecha escolas e pressiona hospitais

JORNAL - GREVE GERAL AVANÇA NO DIA 11. SEXTA-FEIRA CONTA COM NOVA GREVE A Greve Geral Que Se
--------------------------------------------------------------------------------------------

 ![JORNAL - GREVE GERAL AVANÇA NO DIA 11. SEXTA-FEIRA CONTA COM NOVA GREVE A greve geral que se](https://lookaside.fbsbx.com/lookaside/crawler/media/?media_id=1634621500842359) <small>www.facebook.com</small>JORNAL - GREVE GERAL AVANÇA NO DIA 11. SEXTA-FEIRA CONTA COM NOVA GREVE A greve geral que se ...

Pré-avisos De Greve – Dias 11 E 12 De Dezembro 2025 – AE Terras Do Ave
----------------------------------------------------------------------

 ![Pré-avisos de greve – dias 11 e 12 de dezembro 2025 – AE Terras do Ave](https://aeterrasave.net/wp-content/uploads/2025/12/Greves-11-e-12-dezembro-768x518.png) <small>aeterrasave.net</small>Pré-avisos de greve – dias 11 e 12 de dezembro 2025 – AE Terras do Ave

Greve Geral A 11 De Dezembro: Estes São Os Autocarros STCP Que Vão Circular No Porto (e As
------------------------------------------------------------------------------------------

 ![Greve geral a 11 de dezembro: estes são os autocarros STCP que vão circular no Porto (e as](https://offloadmedia.feverup.com/portosecreto.co/wp-content/uploads/2025/12/10134535/stcp-autocarro-porto-1024x683.jpg) <small>portosecreto.co</small>Greve geral a 11 de dezembro: estes são os autocarros STCP que vão circular no Porto (e as ...

Greve Geral Faz-se Sentir Em Coimbra Nos Transportes, Educação E Saúde – Campeão Das Províncias
-----------------------------------------------------------------------------------------------

 ![Greve Geral faz-se sentir em Coimbra nos transportes, educação e saúde – Campeão das Províncias](https://www.campeaoprovincias.pt/wp-content/uploads/2025/12/Greve-geral.jpg) <small>www.campeaoprovincias.pt</small>Greve Geral faz-se sentir em Coimbra nos transportes, educação e saúde – Campeão das Províncias

Greve. 2 Milhões Mudaram De Rotina, Mas Indústria Não Parou – Observador
------------------------------------------------------------------------

 ![Greve. 2 milhões mudaram de rotina, mas indústria não parou – Observador](https://bordalo.observador.pt/v2/q:60/rs:fill:1440/c:4096:2304:nowe:0:213/plain/https://s3.observador.pt/wp-content/uploads/2025/12/11173407/dventura-greve-geral-11dez-53-scaled.jpg) <small>observador.pt</small>Greve. 2 milhões mudaram de rotina, mas indústria não parou – Observador

Greve Geral: Escolas Fechadas, Transportes Parados E Impacto Nacional
---------------------------------------------------------------------

 ![Greve Geral: Escolas Fechadas, Transportes Parados e Impacto Nacional](https://media.assettype.com/dn/2025-12-11/s9kf1m1u/greve-geral.jpeg?w=1200&auto=format%2Ccompress) <small>www.dn.pt</small>Greve Geral: Escolas Fechadas, Transportes Parados e Impacto Nacional

UGT Vai Reunir-se Com Ministra Do Trabalho Mas Avisa Que "é Impossível Negociar" Sozinha A
------------------------------------------------------------------------------------------

 ![UGT vai reunir-se com ministra do Trabalho mas avisa que "é impossível negociar" sozinha a](https://img.iol.pt/image/id/693b2a1ad34e3caad84c47e9/1024.jpg) <small>cnnportugal.iol.pt</small>UGT vai reunir-se com ministra do Trabalho mas avisa que "é impossível negociar" sozinha a ...

15 Minutos: Impacto Da Greve Geral Já Se Começou A Sentir No Setor Dos Transportes - SIC Notícias
-------------------------------------------------------------------------------------------------

 ![15 minutos: impacto da greve geral já se começou a sentir no setor dos transportes - SIC Notícias](https://images.impresa.pt/sicnot/2025-12-12-greve-geral-045a9380/1.91x1?wm=true&outputFormat=jpeg) <small>sicnoticias.pt</small>15 minutos: impacto da greve geral já se começou a sentir no setor dos transportes - SIC Notícias

Greve Geral Histórica Em Portugal Paralisa Transportes, Fecha Escolas E Pressiona Hospitais
-------------------------------------------------------------------------------------------

 ![Greve geral histórica em Portugal paralisa transportes, fecha escolas e pressiona hospitais](https://s.rfi.fr/media/display/074d4efc-d66a-11f0-a540-005056bfb2b6/w:1024/p:16x9/AP25345021595048.jpg) <small>www.rfi.fr</small>Greve geral histórica em Portugal paralisa transportes, fecha escolas e pressiona hospitais ...

Greve Geral Pára País 12 Anos Depois - Sociedade - Correio Da Manhã
-------------------------------------------------------------------

 ![Greve geral pára País 12 anos depois - Sociedade - Correio da Manhã](https://cdn.cmjornal.pt/images/2025-12/img_1500x1000uu2025-12-10-22-06-51-2253721.jpg) <small>www.cmjornal.pt</small>Greve geral pára País 12 anos depois - Sociedade - Correio da Manhã

Greve Geral Histórica Em Portugal Paralisa Transportes, Fecha Escolas E Pressiona Hospitais
-------------------------------------------------------------------------------------------

 ![Greve geral histórica em Portugal paralisa transportes, fecha escolas e pressiona hospitais](https://s.rfi.fr/media/display/074d4efc-d66a-11f0-a540-005056bfb2b6/w:1024/p:9x16/AP25345021595048.jpg) <small>www.rfi.fr</small>Greve geral histórica em Portugal paralisa transportes, fecha escolas e pressiona hospitais ...

Greve Geral: Serviços Mínimos Decretados Da Saúde Aos Transportes
-----------------------------------------------------------------

 ![Greve Geral: Serviços mínimos decretados da saúde aos transportes](https://www.jornaldocentro.pt/wp-content/uploads/2025/12/3bd37d80-9182-4913-9fac-0bc13012bc36.JPG) <small>www.jornaldocentro.pt</small>Greve Geral: Serviços mínimos decretados da saúde aos transportes

Greve Geral – 24 Horas – Dia 11 De Dezembro De 2025 – SINTTAV Sindicato Nacional Dos
------------------------------------------------------------------------------------

 ![Greve Geral – 24 Horas – Dia 11 de Dezembro de 2025 – SINTTAV Sindicato Nacional dos](https://sinttav.pt/wp-content/uploads/2025/11/pag-1.jpg) <small>sinttav.pt</small>Greve Geral – 24 Horas – Dia 11 de Dezembro de 2025 – SINTTAV Sindicato Nacional dos ...

Greve Geral: Escolas Fechadas, Transportes Parados E Impacto Nacional
---------------------------------------------------------------------

 ![Greve Geral: Escolas Fechadas, Transportes Parados e Impacto Nacional](https://media.assettype.com/dn%2F2025-12-11%2F9hy4apil%2Fgreve-geral.jpg?w=768&auto=format%2Ccompress) <small>www.dn.pt</small>Greve Geral: Escolas Fechadas, Transportes Parados e Impacto Nacional

Ugt vai reunir-se com ministra do trabalho mas avisa que "é impossível negociar" sozinha a. transportes, hospitais, escolas e até bancos. que setores vão ser afetados pela greve geral? – eco. Greve geral: escolas fechadas, transportes parados e impacto nacional
