---
title: "Kimberly Powell Musc - An interview with kimberley powell (nvidia) at the ai summit, san francisco (2016)."
description: "Kimberly powell — fitness and nutrition creator in phoenix, az, usa"
date: "2026-02-01"
categories:
- "Uncategorized"
images:
- "https://media.bizj.us/view/img/12968502/kimberlypowell-1*1200xx9428-5303-0-491.jpg"
featuredImage: "https://media.licdn.com/dms/image/v2/D4E10AQEoQkQL3_Sr8w/image-shrink_1280/image-shrink_1280/0/1707382180957?e=2147483647&amp;v=beta&amp;t=0dqql3MYC7lUbb88BTFqqiIbvIz3Tb1NcqvpEZkm5PY"
featured_image: "https://i.ytimg.com/vi/15s952bcezM/maxresdefault.jpg"
image: "https://media.licdn.com/dms/image/v2/D5622AQG_Iha5ZShNxQ/feedshare-shrink_2048_1536/feedshare-shrink_2048_1536/0/1689354648155?e=2147483647&amp;v=beta&amp;t=tO0eWpxk-SFUhmapMMCOBpe5SUV4oVhyiIhxUpW5z_k"
---

If you are searching about Kimberly Powell honored for pioneering work in health informatics and gerontology you've visit to the right web. We have 35 Images about Kimberly Powell honored for pioneering work in health informatics and gerontology like The role of genetic counselors in healthcare today | South Carolina Public Radio, Kimberly Powell: Credits, Bio, News &amp; More | Broadway World and also Home - Cell X Technologies. Here it is:

Kimberly Powell Honored For Pioneering Work In Health Informatics And Gerontology
---------------------------------------------------------------------------------

 ![Kimberly Powell honored for pioneering work in health informatics and gerontology](https://nursing.missouri.edu/wp-content/uploads/2024/06/Kimberly-Powell-FAMIA-induction-1024x1024.png) <small>nursing.missouri.edu</small>Kimberly Powell honored for pioneering work in health informatics and gerontology

NGUMC | Meet Kim Powell: Next Conference Lay Leader Delivers Laity Luncheon Address
-----------------------------------------------------------------------------------

 ![NGUMC | Meet Kim Powell: Next Conference Lay Leader Delivers Laity Luncheon Address](https://www.ngumc.org/files/tables/content/18398080/fields/primaryimage/e32722b28b8245cca559619bbe7424aa/kim+powell.png?width=1200&height=630) <small>www.ngumc.org</small>NGUMC | Meet Kim Powell: Next Conference Lay Leader Delivers Laity Luncheon Address

NVIDIA Powers Up In Drug Discovery
----------------------------------

 ![NVIDIA Powers Up in Drug Discovery](https://genengnews.com/wp-content/uploads/2020/10/Kimberly-Powell_avatar_1511719112-200x200-1.jpg) <small>www.genengnews.com</small>NVIDIA Powers Up in Drug Discovery

Augusta Health Neighborhood Clinic – Augusta Health
---------------------------------------------------

 ![Augusta Health Neighborhood Clinic – Augusta Health](https://www.augustahealth.com/wp-content/uploads/2023/04/Kim-Powell-2-scaled.jpg) <small>www.augustahealth.com</small>Augusta Health Neighborhood Clinic – Augusta Health

Classical Music With Kimberly Powell | Free Internet Radio | TuneIn
-------------------------------------------------------------------

 ![Classical Music with Kimberly Powell | Free Internet Radio | TuneIn](https://cdn-profiles.tunein.com/p428084/images/logog.png?t=1) <small>tunein.com</small>Classical Music with Kimberly Powell | Free Internet Radio | TuneIn

Kimberly Powell — Fitness And Nutrition Creator In Phoenix, AZ, USA | Creator Data
----------------------------------------------------------------------------------

 ![Kimberly Powell — Fitness and Nutrition Creator in Phoenix, AZ, USA | Creator Data](https://creator-data.com/uploads/profiles/652ac223-c7c0-4ac4-874c-47bf3466c415-1779725830357.jpg) <small>creator-data.com</small>Kimberly Powell — Fitness and Nutrition Creator in Phoenix, AZ, USA | Creator Data

Meet The Church Staff | New Beginnings
--------------------------------------

 ![Meet the Church Staff | New Beginnings](https://newbeginningfgbc.com/wp-content/uploads/2023/06/kimberly-morton-powell_new_square-768x768.jpg) <small>newbeginningfgbc.com</small>Meet the Church Staff | New Beginnings

The Role Of Genetic Counselors In Healthcare Today | South Carolina Public Radio
--------------------------------------------------------------------------------

 ![The role of genetic counselors in healthcare today | South Carolina Public Radio](https://npr.brightspotcdn.com/dims4/default/a3f5f25/2147483647/strip/true/crop/342x480+0+0/resize/880x1235!/quality/90/?url=http%3A%2F%2Fnpr-brightspot.s3.amazonaws.com%2F8b%2F02%2Ff9575dac404abec9c79907d7efdf%2Ffoil-kimberly-2025.jpg) <small>www.southcarolinapublicradio.org</small>The role of genetic counselors in healthcare today | South Carolina Public Radio

Kimberly Powell On LinkedIn: Had A Fantastic Time Hosting The PowerUp Strategic Educators
-----------------------------------------------------------------------------------------

 ![Kimberly Powell on LinkedIn: Had a fantastic time hosting the PowerUp Strategic Educators](https://media.licdn.com/dms/image/D5622AQEBItJYa-ypGw/feedshare-shrink_800/0/1708957758233?e=2147483647&v=beta&t=xMzVZhCGZYMoNSETCR7it3dpNlrrkZKiht8hIB45sdI) <small>www.linkedin.com</small>Kimberly Powell on LinkedIn: Had a fantastic time hosting the PowerUp Strategic Educators ...

Kimberly Powell
---------------

 ![Kimberly Powell](https://lookaside.fbsbx.com/lookaside/crawler/media/?media_id=1100947362019309) <small>www.facebook.com</small>Kimberly Powell

Kimberly Powell - Keynote - Ohio Genealogical Society
-----------------------------------------------------

 ![Kimberly Powell - Keynote - Ohio Genealogical Society](https://www.ogs.org/wp-content/uploads/2026/02/Powell-Kimberly-2.png) <small>www.ogs.org</small>Kimberly Powell - Keynote - Ohio Genealogical Society

Nvidia Expands AI Ambitions In Healthcare; Aims To Transform Hospitals With Robotics – Digital
----------------------------------------------------------------------------------------------

 ![Nvidia expands AI ambitions in healthcare; aims to transform hospitals with robotics – Digital](https://digitaleconomymag.com/wp-content/uploads/2024/11/Nvidia-Kimberly-Powel.png) <small>digitaleconomymag.com</small>Nvidia expands AI ambitions in healthcare; aims to transform hospitals with robotics – Digital ...

Kimberly R. Powell
------------------

 ![Kimberly R. Powell](https://nursing.missouri.edu/wp-content/uploads/2022/09/social.jpg) <small>nursing.missouri.edu</small>Kimberly R. Powell

Just Praise - Single By Kimberly Morton Powell | Spotify
--------------------------------------------------------

 ![Just Praise - Single by Kimberly Morton Powell | Spotify](https://i.scdn.co/image/ab67616d0000b27327b4128d3f227f109764eb39) <small>open.spotify.com</small>Just Praise - Single by Kimberly Morton Powell | Spotify

Board Of Directors — Basic Needs Inc.
-------------------------------------

 ![Board of Directors — Basic Needs Inc.](https://images.squarespace-cdn.com/content/v1/63d48a2e85aa7959f69d2f27/58712eb8-621f-4cbe-b73b-a7e4fbbc934a/Powell_Kim+2005.jpg) <small>www.basicneedsmn.org</small>Board of Directors — Basic Needs Inc.

Kimberly Powell Special Address - Healthcare At GTC | Channah Blocq
-------------------------------------------------------------------

 ![Kimberly Powell Special Address - Healthcare at GTC | Channah Blocq](https://media.licdn.com/dms/image/v2/D4E10AQEoQkQL3_Sr8w/image-shrink_1280/image-shrink_1280/0/1707382180957?e=2147483647&v=beta&t=0dqql3MYC7lUbb88BTFqqiIbvIz3Tb1NcqvpEZkm5PY) <small>www.linkedin.com</small>Kimberly Powell Special Address - Healthcare at GTC | Channah Blocq

What Can Health Care Learn From Self-Driving Cars? | Johns Hopkins Medicine
---------------------------------------------------------------------------

 ![What Can Health Care Learn from Self-Driving Cars? | Johns Hopkins Medicine](https://www.hopkinsmedicine.org/-/media/images/articles/2018/03/kimberly_powell.jpeg?h=640&iar=0&w=640&hash=1741F5E78A512573722D6BEAB32D9288) <small>www.hopkinsmedicine.org</small>What Can Health Care Learn from Self-Driving Cars? | Johns Hopkins Medicine

Home - Cell X Technologies
--------------------------

 ![Home - Cell X Technologies](https://cellxtechnologies.com/wp-content/uploads/2023/09/Image_Kimberly-Powell.jpg) <small>cellxtechnologies.com</small>Home - Cell X Technologies

An Interview With Kimberley Powell (NVIDIA) At The AI Summit, San Francisco (2016). - YouTube
---------------------------------------------------------------------------------------------

 ![An Interview with Kimberley Powell (NVIDIA) at The AI Summit, San Francisco (2016). - YouTube](https://i.ytimg.com/vi/15s952bcezM/maxresdefault.jpg) <small>www.youtube.com</small>An Interview with Kimberley Powell (NVIDIA) at The AI Summit, San Francisco (2016). - YouTube

We're Here! The Indiana Black Expo! Hall H, Booth 1447! Come Visit Us! | Kimberly Powell
----------------------------------------------------------------------------------------

 ![We're here! The Indiana Black Expo! Hall H, booth 1447! Come visit us! | Kimberly Powell](https://media.licdn.com/dms/image/v2/D5622AQG_Iha5ZShNxQ/feedshare-shrink_2048_1536/feedshare-shrink_2048_1536/0/1689354648155?e=2147483647&v=beta&t=tO0eWpxk-SFUhmapMMCOBpe5SUV4oVhyiIhxUpW5z_k) <small>www.linkedin.com</small>We're here! The Indiana Black Expo! Hall H, booth 1447! Come visit us! | Kimberly Powell

From The Office To The Lab, Amgen Uses AI Tools To Unlock Innovation | Amgen
----------------------------------------------------------------------------

 ![From the Office to the Lab, Amgen Uses AI Tools to Unlock Innovation | Amgen](https://www.amgen.com/stories/2024/05/-/media/Themes/CorporateAffairs/amgen-com/amgen-com/Images/stories/2024/05-21-From-the-Office-to-the-Lab-Amgen-Uses-AI-Tools-to-Unlock-Innovation/powell.png) <small>www.amgen.com</small>From the Office to the Lab, Amgen Uses AI Tools to Unlock Innovation | Amgen

Dive Into The Future Of Digital Surgery, Health, And Biology With NVIDIA's VP Of Healthcare And
-----------------------------------------------------------------------------------------------

 ![Dive into the future of digital surgery, health, and biology with NVIDIA's VP of Healthcare and](https://media.licdn.com/dms/image/v2/D5610AQEf18m9u13NPw/image-shrink_800/image-shrink_800/0/1718404075786?e=2147483647&v=beta&t=F-wL667A6hY7CE4c0fp8ufvPB6vLFAUNhCatqrC7jY4) <small>www.linkedin.com</small>Dive into the future of digital surgery, health, and biology with NVIDIA's VP of Healthcare and ...

Leadership — The American Cathedral In Paris
--------------------------------------------

 ![Leadership — The American Cathedral in Paris](https://images.squarespace-cdn.com/content/v1/61ae319c152d7a516d11d475/df7f91fe-ae17-4b0f-8238-56876e4b022c/KimPowell_VestryBio(1).jpg) <small>amcathparis.com</small>Leadership — The American Cathedral in Paris

The Age Of AI In Radiology Is Here – Entelechy Asia
---------------------------------------------------

 ![The age of AI in radiology is here – Entelechy Asia](https://entelechyasia.com/wp-content/uploads/2019/01/kimberly-powell-at-emtech-asia.jpg) <small>entelechyasia.com</small>The age of AI in radiology is here – Entelechy Asia

Kimberly Powell (@KimbePowell) / Posts / X
------------------------------------------

 ![Kimberly Powell (@KimbePowell) / Posts / X](https://pbs.twimg.com/profile_banners/761310478345900032/1470346849) <small>x.com</small>Kimberly Powell (@KimbePowell) / Posts / X

About Us
--------

 ![About Us](https://img1.wsimg.com/isteam/ip/44d8c6eb-5847-48e2-aff5-373d62931250/blob.png/:/cr=t:0%25,l:0%25,w:100%25,h:67.46%25/rs=w:365,h:365,cg:true) <small>757wecare.org</small>About Us

Kimberly Powell: Credits, Bio, News &amp; More | Broadway World
---------------------------------------------------------------

 ![Kimberly Powell: Credits, Bio, News & More | Broadway World](https://cloudimages.broadwayworld.com/headshots/449551sm.jpg) <small>www.broadwayworld.com</small>Kimberly Powell: Credits, Bio, News &amp; More | Broadway World

GTC 2025 – Announcements And Live Updates | NVIDIA Blog
-------------------------------------------------------

 ![GTC 2025 – Announcements and Live Updates | NVIDIA Blog](https://blogs.nvidia.com/wp-content/uploads/2025/03/kptalk-1280x960.jpg) <small>blogs.nvidia.com</small>GTC 2025 – Announcements and Live Updates | NVIDIA Blog

Exclusive Interview With Kimberly Powell, VP And General Manager Of NVIDIA Healthcare - MarkTechPost
----------------------------------------------------------------------------------------------------

 ![Exclusive Interview with Kimberly Powell, VP and General Manager of NVIDIA Healthcare - MarkTechPost](https://www.marktechpost.com/wp-content/uploads/2022/04/Interview-2.png) <small>www.marktechpost.com</small>Exclusive Interview with Kimberly Powell, VP and General Manager of NVIDIA Healthcare - MarkTechPost

Kimberly Powell On LinkedIn: #speakupsisawards2024 #susawards2024 #susawardsfinalist2024 #voteforme
---------------------------------------------------------------------------------------------------

 ![Kimberly Powell on LinkedIn: #speakupsisawards2024 #susawards2024 #susawardsfinalist2024 #voteforme](https://media.licdn.com/dms/image/D4D22AQHnpcTAQwDtzg/feedshare-shrink_2048_1536/0/1710527087105?e=2147483647&v=beta&t=ABcsxN8h4u0sB8mJDrZKm9poz4E6UKa_kzE8Y0XAmbE) <small>www.linkedin.com</small>Kimberly Powell on LinkedIn: #speakupsisawards2024 #susawards2024 #susawardsfinalist2024 #voteforme

NVIDIA: A Nova Fronteira Da Medicina Está Na IA - CM
----------------------------------------------------

 ![NVIDIA: A nova fronteira da Medicina está na IA - CM](https://consumidormoderno.com.br/wp-content/uploads/2025/03/Nvidia_Kimberly-Powell-1024x530.webp) <small>consumidormoderno.com.br</small>NVIDIA: A nova fronteira da Medicina está na IA - CM

Nvidia's Kimberly Powell Is Leading The Chip Giant's Charge Into AI For Health Care - San
-----------------------------------------------------------------------------------------

 ![Nvidia's Kimberly Powell is leading the chip giant's charge into AI for health care - San](https://media.bizj.us/view/img/12968502/kimberlypowell-1*1200xx9428-5303-0-491.jpg) <small>www.bizjournals.com</small>Nvidia's Kimberly Powell is leading the chip giant's charge into AI for health care - San ...

Faculty Staff | College Of Medicine
-----------------------------------

 ![Faculty Staff | College of Medicine](https://public.med.fsu.edu/images/Faculty/Kimberly.Powell.jpg) <small>public.med.fsu.edu</small>Faculty Staff | College of Medicine

Kimberly Powell Honored For Pioneering Work In Health Informatics And Gerontology
---------------------------------------------------------------------------------

 ![Kimberly Powell honored for pioneering work in health informatics and gerontology](https://nursing.missouri.edu/wp-content/uploads/2024/05/Congratulations.png) <small>nursing.missouri.edu</small>Kimberly Powell honored for pioneering work in health informatics and gerontology

Generative AI Is Revolutionizing Healthcare, From Drug Discovery To Diagnostics And Post-op Care
------------------------------------------------------------------------------------------------

 ![Generative AI is revolutionizing healthcare, from drug discovery to diagnostics and post-op care](https://media.licdn.com/dms/image/v2/D4D22AQHI7fbK1GV1QQ/feedshare-shrink_2048_1536/feedshare-shrink_2048_1536/0/1717762363344?e=2147483647&v=beta&t=HcXrmL3078ePC82LlnhipxGpfpS2lI088q7m0yCHQ0I) <small>pe.linkedin.com</small>Generative AI is revolutionizing healthcare, from drug discovery to diagnostics and post-op care ...

kimberly powell: credits, bio, news &amp; more. The role of genetic counselors in healthcare today. Exclusive interview with kimberly powell, vp and general manager of nvidia healthcare
