---
title: "Atum-8/2-0-stk - Raychem atum heat shrink"
description: "atum-8/2-0-stk"
date: "2026-04-20"
categories:
- "Uncategorized"
images:
- "https://sku-product-images.s3.us-east-2.amazonaws.com/AMP/1658527-6.jpg"
featuredImage: "https://i.ebayimg.com/images/g/sZwAAOSwGnNlbOFQ/s-l1600.jpg"
featured_image: "http://6049499.s21i.faiusr.com/2/ABUIABACGAAgxqnGvAUojNXFhwMwhAc4jAk.jpg"
image: "https://mm.digikey.com/Volume0/opasdata/d220001/derivates/3/003/226/041/MFG_ATUM-XX-X-0-SP_tmb(64x64).jpg"
---

If you are searching about ATUM-8/2-0-STK TE Connectivity Raychem Cable Protection | Cables, Wires - Management | DigiKey you've visit to the right web. We have 35 Pictures about ATUM-8/2-0-STK TE Connectivity Raychem Cable Protection | Cables, Wires - Management | DigiKey like ATUM-8/2-0-STK | TE Connectivity 熱収縮チューブ, 黒, 8 mmから 2 mm, ポリオレフィン, 1.2m | RS, ATUM-8/2-0-STK TE Connectivity Raychem Cable Protection | Cables, Wires - Management | DigiKey and also Raychem ATUM-24/8-0-STK ATUM-24/8-0-STK | Zoro. Read more:

ATUM-8/2-0-STK TE Connectivity Raychem Cable Protection | Cables, Wires - Management | DigiKey
----------------------------------------------------------------------------------------------

 ![ATUM-8/2-0-STK TE Connectivity Raychem Cable Protection | Cables, Wires - Management | DigiKey](https://media.digikey.com/photos/Tyco Photos/ATUM-8^2-0-STK.JPG) <small>www.digikey.in</small>ATUM-8/2-0-STK TE Connectivity Raychem Cable Protection | Cables, Wires - Management | DigiKey

TE Connectivity NB11784001 ATUM 8/2 Heat Shrink Tubing 656Ft Roll .315 Exp ID | EBay
------------------------------------------------------------------------------------

 ![TE Connectivity NB11784001 ATUM 8/2 Heat Shrink Tubing 656Ft Roll .315 Exp ID | eBay](https://i.ebayimg.com/images/g/sZwAAOSwGnNlbOFQ/s-l1600.jpg) <small>www.ebay.com</small>TE Connectivity NB11784001 ATUM 8/2 Heat Shrink Tubing 656Ft Roll .315 Exp ID | eBay

Клеевая термоусадка 4:1, Raychem ATUM-8/2-0-STK, NB11022001 для герметизации кабеля и разъёмов
----------------------------------------------------------------------------------------------

 ![Клеевая термоусадка 4:1, Raychem ATUM-8/2-0-STK, NB11022001 для герметизации кабеля и разъёмов](https://s-motorsport.com/image/cache/catalog/Raychem/ATUM 4-1/ATUM-8 2-0-STK Raychem NB11802001-2000x2000.jpg) <small>s-motorsport.com</small>Клеевая термоусадка 4:1, Raychem ATUM-8/2-0-STK, NB11022001 для герметизации кабеля и разъёмов

Raychem ATUM-24/8-0-STK ATUM-24/8-0-STK | Zoro
----------------------------------------------

 ![Raychem ATUM-24/8-0-STK ATUM-24/8-0-STK | Zoro](https://www.zoro.com/static/cms/product/full/Waldom Electronics_ATUMxx24xx8xx0xxSTKxx1xx2c0230.jpeg) <small>www.zoro.com</small>Raychem ATUM-24/8-0-STK ATUM-24/8-0-STK | Zoro

ATUM-8/2-0-STK TE Connectivity Raychem Cable Protection | Cables, Wires - Management | DigiKey
----------------------------------------------------------------------------------------------

 ![ATUM-8/2-0-STK TE Connectivity Raychem Cable Protection | Cables, Wires - Management | DigiKey](https://mm.digikey.com/Volume0/opasdata/d220001/derivates/3/003/226/041/MFG_ATUM-XX-X-0-SP_tmb(64x64).jpg) <small>www.digikey.com</small>ATUM-8/2-0-STK TE Connectivity Raychem Cable Protection | Cables, Wires - Management | DigiKey

ATUM-8/2-0-STK TE Connectivity Raychem Cable Protection | 电缆，电线 - 管理 | DigiKey
------------------------------------------------------------------------------

 ![ATUM-8/2-0-STK TE Connectivity Raychem Cable Protection | 电缆，电线 - 管理 | DigiKey](https://mm.digikey.com/Volume0/opasdata/d220001/derivates/3/003/209/407/ATU062K_tmb.jpg) <small>www.digikey.cn</small>ATUM-8/2-0-STK TE Connectivity Raychem Cable Protection | 电缆，电线 - 管理 | DigiKey

ATUM-32/8-0-STK TE Connectivity | Raychem Products | Heilind
------------------------------------------------------------

 ![ATUM-32/8-0-STK TE Connectivity | Raychem Products | Heilind](https://sku-product-images.s3.us-east-2.amazonaws.com/AMP/1658527-6.jpg) <small>www.heilind.com</small>ATUM-32/8-0-STK TE Connectivity | Raychem Products | Heilind

ATUM-8/2-0-STK RAYCHEM - TE CONNECTIVITY, Adhesive Lined Heat Shrink Tubing, Dual Medium Wall, 4
------------------------------------------------------------------------------------------------

 ![ATUM-8/2-0-STK RAYCHEM - TE CONNECTIVITY, Adhesive Lined Heat Shrink Tubing, Dual Medium Wall, 4](https://hk.element14.com/productimages/standard/en_GB/42246141.jpg) <small>hk.element14.com</small>ATUM-8/2-0-STK RAYCHEM - TE CONNECTIVITY, Adhesive Lined Heat Shrink Tubing, Dual Medium Wall, 4 ...

Raychem Термоусадка ATUM-8/2-0-STK ATUM-8/2-0-STK
-------------------------------------------------

 ![Raychem Термоусадка ATUM-8/2-0-STK ATUM-8/2-0-STK](https://1evel.ru/wa-data/public/shop/products/16/11/21116/images/17255/17255.750x0.jpg) <small>1evel.ru</small>Raychem Термоусадка ATUM-8/2-0-STK ATUM-8/2-0-STK

ATUM-8/2-0-STK | Tubos Termorretráctiles Chemelex De Poliolefina Negro, Contracción 4:1, Ø 8 Mm
-----------------------------------------------------------------------------------------------

 ![ATUM-8/2-0-STK | Tubos termorretráctiles Chemelex de Poliolefina Negro, contracción 4:1, Ø 8 mm](https://media.rs-online.com/image/upload/bo_1.5px_solid_white,b_auto,c_pad,dpr_2,f_auto,h_399,q_auto,w_710/c_pad,h_399,w_710/Y0433224-01?pgw=1) <small>es.rs-online.com</small>ATUM-8/2-0-STK | Tubos termorretráctiles Chemelex de Poliolefina Negro, contracción 4:1, Ø 8 mm ...

ATUM-8/2-0-STK TE Connectivity Raychem Cable Protection | 电缆，电线 - 管理 | DigiKey
------------------------------------------------------------------------------

 ![ATUM-8/2-0-STK TE Connectivity Raychem Cable Protection | 电缆，电线 - 管理 | DigiKey](https://mm.digikey.com/Volume0/opasdata/d220001/derivates/3/100/959/385/1208_ATUM-123-0-STK_tmb.jpg) <small>www.digikey.cn</small>ATUM-8/2-0-STK TE Connectivity Raychem Cable Protection | 电缆，电线 - 管理 | DigiKey

RAYCHEM ATUM Heat Shrink - ATUM-8/2-0-SP
----------------------------------------

 ![RAYCHEM ATUM Heat Shrink - ATUM-8/2-0-SP](https://hilltop-products.co.uk/media/catalog/product/cache/f9f2413c71b073e5359531a425f36bfa/t/u/tum_2_3.png) <small>hilltop-products.co.uk</small>RAYCHEM ATUM Heat Shrink - ATUM-8/2-0-SP

ATUM-8/2-0-STK TE Connectivity Raychem Cable Protection | Cables, Wires - Management | DigiKey
----------------------------------------------------------------------------------------------

 ![ATUM-8/2-0-STK TE Connectivity Raychem Cable Protection | Cables, Wires - Management | DigiKey](https://media.digikey.com/pdf/Catalog Drawings/Heat Shrink/ATUM-82-0-STK.jpg) <small>www.digikey.com</small>ATUM-8/2-0-STK TE Connectivity Raychem Cable Protection | Cables, Wires - Management | DigiKey

ATUM-8/2-0-STK TE Connectivity - Heat Shrink Sleeve | Glued; 4: 1; 8mm; L: 1.2m; Black
--------------------------------------------------------------------------------------

 ![ATUM-8/2-0-STK TE Connectivity - Heat shrink sleeve | glued; 4: 1; 8mm; L: 1.2m; black](https://ce8dc832c.cloudimg.io/v7/_cdn_/1A/7F/90/00/0/653217_1.jpg?width=640&height=480&wat=1&wat_url=_tme-wrk_%2Ftme_new.png&wat_scale=100p&ci_sign=6f8267ed128451dc14441c82edff7fa4b3dbd673) <small>www.tme.com</small>ATUM-8/2-0-STK TE Connectivity - Heat shrink sleeve | glued; 4: 1; 8mm; L: 1.2m; black ...

RAYCHEM ATUM Heat Shrink - ATUM-8/2-0-SP
----------------------------------------

 ![RAYCHEM ATUM Heat Shrink - ATUM-8/2-0-SP](https://hilltop-products.co.uk/media/catalog/product/cache/6d2ffb848796335b7eb82cc8e3ea4df5/a/t/atum_new_2015_3_3nd.jpg) <small>hilltop-products.co.uk</small>RAYCHEM ATUM Heat Shrink - ATUM-8/2-0-SP

常备库存 ATUM-32/8-0-STK-阿里巴巴
-------------------------

 ![常备库存 ATUM-32/8-0-STK-阿里巴巴](https://cbu01.alicdn.com/img/ibank/2020/105/276/13933672501_988176765.jpg) <small>detail.1688.com</small>常备库存 ATUM-32/8-0-STK-阿里巴巴

ATUM-8/2-0 | TE Connectivity Adhesive Lined Heat Shrink Tubing, Black 8mm Sleeve Dia. X 1.2m
--------------------------------------------------------------------------------------------

 ![ATUM-8/2-0 | TE Connectivity Adhesive Lined Heat Shrink Tubing, Black 8mm Sleeve Dia. x 1.2m](https://media.rs-online.com/f_auto/F3161631-01.jpg) <small>za.rs-online.com</small>ATUM-8/2-0 | TE Connectivity Adhesive Lined Heat Shrink Tubing, Black 8mm Sleeve Dia. x 1.2m ...

ATUM-8/2-0-STK TE Connectivity Raychem Cable Protection | 电缆，电线 - 管理 | DigiKey
------------------------------------------------------------------------------

 ![ATUM-8/2-0-STK TE Connectivity Raychem Cable Protection | 电缆，电线 - 管理 | DigiKey](https://mm.digikey.com/Volume0/opasdata/d220001/derivates/3/010/195/618/ATUM-4^1-0-STK_tmb.jpg) <small>www.digikey.cn</small>ATUM-8/2-0-STK TE Connectivity Raychem Cable Protection | 电缆，电线 - 管理 | DigiKey

ATUM-8/2-0-STK TE Connectivity | Raychem Products | Heilind
-----------------------------------------------------------

 ![ATUM-8/2-0-STK TE Connectivity | Raychem Products | Heilind](https://sku-product-images.s3.us-east-2.amazonaws.com/RYC/RYCATUM-16-4-0-STK.jpg) <small>www.heilind.com</small>ATUM-8/2-0-STK TE Connectivity | Raychem Products | Heilind

TE Connectivity NB11784001 ATUM 8/2 Heat Shrink Tubing 656Ft Roll .315 Exp ID | EBay
------------------------------------------------------------------------------------

 ![TE Connectivity NB11784001 ATUM 8/2 Heat Shrink Tubing 656Ft Roll .315 Exp ID | eBay](https://i.ebayimg.com/images/g/POwAAOSwNl1lbOOT/s-l1600.png) <small>www.ebay.com</small>TE Connectivity NB11784001 ATUM 8/2 Heat Shrink Tubing 656Ft Roll .315 Exp ID | eBay

TE Connectivity(泰科电子)热缩套管ATUM-8/2-0-STK\[4.00'（1.22m）\]【价格 采购 图片】-立创MRO工业品
--------------------------------------------------------------------------

 ![TE Connectivity(泰科电子)热缩套管ATUM-8/2-0-STK[4.00'（1.22m）]【价格 采购 图片】-立创MRO工业品](https://alimg.szlcsc.com/upload/public/product/breviary/20250508/EC75C7B0A2BD79E2F5F5F8A1301601C2.jpg) <small>item.szlcsc.com</small>TE Connectivity(泰科电子)热缩套管ATUM-8/2-0-STK\[4.00'（1.22m）\]【价格 采购 图片】-立创MRO工业品

ATUM-24/8-0-STK TE Connectivity | Raychem Products | Heilind
------------------------------------------------------------

 ![ATUM-24/8-0-STK TE Connectivity | Raychem Products | Heilind](https://sku-product-images.s3.us-east-2.amazonaws.com/AMP/87631-2.png) <small>www.heilind.com</small>ATUM-24/8-0-STK TE Connectivity | Raychem Products | Heilind

ATUM-8/2-0-STK TE Connectivity Raychem Cable Protection | Cables, Wires - Management | DigiKey
----------------------------------------------------------------------------------------------

 ![ATUM-8/2-0-STK TE Connectivity Raychem Cable Protection | Cables, Wires - Management | DigiKey](https://media.digikey.com/photos/nophoto/pna_en_tmb.jpg) <small>www.digikey.com</small>ATUM-8/2-0-STK TE Connectivity Raychem Cable Protection | Cables, Wires - Management | DigiKey

ATUM-8/2-0-STK - Te Connectivity / Raychem Brand - OnlineComponents.com
-----------------------------------------------------------------------

 ![ATUM-8/2-0-STK - Te Connectivity / Raychem Brand - OnlineComponents.com](https://media.onlinecomponents.com/images/parts/webp-large-images/12275673.webp) <small>www.onlinecomponents.com</small>ATUM-8/2-0-STK - Te Connectivity / Raychem Brand - OnlineComponents.com

ATUM-8/2-0 TE Connectivity | TE Connectivity Heat Shrink Tubing, Black 8 Mm Sleeve Dia. X 1.2m
----------------------------------------------------------------------------------------------

 ![ATUM-8/2-0 TE Connectivity | TE Connectivity Heat Shrink Tubing, Black 8 mm Sleeve Dia. x 1.2m](https://res.cloudinary.com/rsc/image/upload/b_rgb:FFFFFF,c_pad,dpr_1.0,f_auto,q_auto,w_700/c_pad,w_700/F3161631-02) <small>sa.rsdelivers.com</small>ATUM-8/2-0 TE Connectivity | TE Connectivity Heat Shrink Tubing, Black 8 mm Sleeve Dia. x 1.2m ...

ATUM-8/2-0-SP|ATUM-8/2-0-STK|热缩套管
---------------------------------

 ![ATUM-8/2-0-SP|ATUM-8/2-0-STK|热缩套管](http://6049499.s21i.faiusr.com/2/ABUIABACGAAgxqnGvAUojNXFhwMwhAc4jAk.jpg) <small>www.e-ksm.com</small>ATUM-8/2-0-SP|ATUM-8/2-0-STK|热缩套管

ATUM-8/2-0-STK TE Connectivity Raychem Cable Protection | Cables, Wires - Management | DigiKey
----------------------------------------------------------------------------------------------

 ![ATUM-8/2-0-STK TE Connectivity Raychem Cable Protection | Cables, Wires - Management | DigiKey](https://mm.digikey.com/Volume0/opasdata/d220001/medias/images/630/ATUM-82-0-STK.jpg) <small>www.digikey.com</small>ATUM-8/2-0-STK TE Connectivity Raychem Cable Protection | Cables, Wires - Management | DigiKey

Raychem Products Made In Germany | ProductFrom.com
--------------------------------------------------

 ![Raychem products made in Germany | ProductFrom.com](https://www.productfrom.com/photos/0059/59183_medium.jpg) <small>www.productfrom.com</small>Raychem products made in Germany | ProductFrom.com

ATUM-8/2-0-STK Heat Shrink Tubing By RAYCHEM CONNECTIVITY
---------------------------------------------------------

 ![ATUM-8/2-0-STK Heat Shrink Tubing by RAYCHEM CONNECTIVITY](https://cdn.radwell.com/productgoogleimages/19a8ebba631c4c8a9d06a555d0fe8795.jpg) <small>www.radwell.com</small>ATUM-8/2-0-STK Heat Shrink Tubing by RAYCHEM CONNECTIVITY

ATUM-8/2-0-STK TE Connectivity Raychem Cable Protection | Heat Shrink Tubing | DigiKey
--------------------------------------------------------------------------------------

 ![ATUM-8/2-0-STK TE Connectivity Raychem Cable Protection | Heat Shrink Tubing | DigiKey](https://mm.digikey.com/Volume0/opasdata/d220001/derivates/1/003/226/041/MFG_ATUM-XX-X-0-SP_sml(200x200).jpg) <small>www.digikey.com</small>ATUM-8/2-0-STK TE Connectivity Raychem Cable Protection | Heat Shrink Tubing | DigiKey

ATUM-32/8-0-STK TE Connectivity Raychem Cable Protection | Heat Shrink Tubing | DigiKey
---------------------------------------------------------------------------------------

 ![ATUM-32/8-0-STK TE Connectivity Raychem Cable Protection | Heat Shrink Tubing | DigiKey](https://mm.digikey.com/Volume0/opasdata/d220001/derivates/1/300/358/434/ATUM-32^8-0-STK_sml.jpg) <small>www.digikey.com</small>ATUM-32/8-0-STK TE Connectivity Raychem Cable Protection | Heat Shrink Tubing | DigiKey

ATUM-8/2-0-STK TE Connectivity 熱収縮チューブ， 収縮前 8mm， 収縮後 2mm， スリーブ長さ 1.2m ポリオレフィン， 黒 1本 TE
--------------------------------------------------------------------------------------

 ![ATUM-8/2-0-STK TE Connectivity 熱収縮チューブ， 収縮前 8mm， 収縮後 2mm， スリーブ長さ 1.2m ポリオレフィン， 黒 1本 TE](https://jp.images-monotaro.com/Monotaro3/pi/full/mono40953387-190508-02.jpg) <small>www.monotaro.com</small>ATUM-8/2-0-STK TE Connectivity 熱収縮チューブ， 収縮前 8mm， 収縮後 2mm， スリーブ長さ 1.2m ポリオレフィン， 黒 1本 TE ...

ATUM-8/2-0 | TE Connectivity Heat Shrink Tubing, Black 8 Mm Sleeve Dia. X 1.2m Length 4:1 Ratio
-----------------------------------------------------------------------------------------------

 ![ATUM-8/2-0 | TE Connectivity Heat Shrink Tubing, Black 8 mm Sleeve Dia. x 1.2m Length 4:1 Ratio](https://media.rs-online.com/image/upload/bo_1.5px_solid_white,b_auto,c_pad,dpr_2,f_auto,h_399,q_auto,w_710/c_pad,h_399,w_710/F3161631-01?pgw=1) <small>uk.rs-online.com</small>ATUM-8/2-0 | TE Connectivity Heat Shrink Tubing, Black 8 mm Sleeve Dia. x 1.2m Length 4:1 Ratio ...

レイケム ATUM- 8/ 2-0-STK（カット品1.2m） 黒色 接着層付き 防水熱収縮チューブ 8.0→2.0mm : FA-Ubon Yahoo!店 - 通販 - Yahoo!ショッピング
--------------------------------------------------------------------------------------------------

 ![レイケム ATUM- 8/ 2-0-STK（カット品1.2m） 黒色 接着層付き 防水熱収縮チューブ 8.0→2.0mm : FA-Ubon Yahoo!店 - 通販 - Yahoo!ショッピング](https://item-shopping.c.yimg.jp/i/n/faubon_0880620) <small>store.shopping.yahoo.co.jp</small>レイケム ATUM- 8/ 2-0-STK（カット品1.2m） 黒色 接着層付き 防水熱収縮チューブ 8.0→2.0mm : FA-Ubon Yahoo!店 - 通販 - Yahoo!ショッピング

ATUM-8/2-0-STK | TE Connectivity 熱収縮チューブ, 黒, 8 Mmから 2 Mm, ポリオレフィン, 1.2m | RS
----------------------------------------------------------------------------

 ![ATUM-8/2-0-STK | TE Connectivity 熱収縮チューブ, 黒, 8 mmから 2 mm, ポリオレフィン, 1.2m | RS](https://media.rs-online.com/image/upload/bo_1.5px_solid_white,b_auto,c_pad,dpr_2,f_auto,h_399,q_auto,w_710/c_pad,h_399,w_710/Y0487216-01?pgw=1) <small>jp.rs-online.com</small>ATUM-8/2-0-STK | TE Connectivity 熱収縮チューブ, 黒, 8 mmから 2 mm, ポリオレフィン, 1.2m | RS

Atum-8/2-0-stk te connectivity raychem cable protection. Atum-8/2-0-stk te connectivity raychem cable protection. atum-8/2-0-stk te connectivity raychem cable protection
