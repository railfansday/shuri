---
title: "A Que Horas Joga O Benfica Porto - Transmissão em directo porto x benfica: a que horas joga o porto? veja onde assistir porto x benfica"
description: "Benfica x porto: confira informações e onde assistir ao clássico português"
date: "2026-09-16"
categories:
- "Uncategorized"
images:
- "https://static.wixstatic.com/media/097cef_f1115789e6de46aa805d6fbb8954a4fc~mv2.gif"
featuredImage: "https://goalpoint.pt/wp-content/uploads/2024/11/GoalPoint-2024-11-10-Benfica-Porto-Primeira-Liga-202425-90m.jpg"
featured_image: "https://livesport-ott-images.ssl.cdn.cra.cz/r900xfq60/96ba0185-97da-4df8-b6bd-09d4f78facf3.jpg"
image: "https://ostris.pt/wp-content/uploads/2024/12/benfica-vs-fc-porto-ao-vivo-liga-portugal-24-25-simulacao-e-placar-ao-vivo.jpg"
---

If you are looking for FC Porto-Benfica: Dragão com mais 10 vitórias em 256 clássicos | Flashscore.pt you've visit to the right web. We have 35 Pics about FC Porto-Benfica: Dragão com mais 10 vitórias em 256 clássicos | Flashscore.pt like Horário do Jogo Benfica vs Porto | Actualizado julio 2026, Vídeo - Liga Portugal Betclic (24ª Jornada): Resumo FC Porto 5-0 Benfica and also TRANSMISSÃO EM DIRECTO PORTO X BENFICA: a que horas joga o PORTO? Veja onde assistir PORTO X BENFICA. Here it is:

FC Porto-Benfica: Dragão Com Mais 10 Vitórias Em 256 Clássicos | Flashscore.pt
------------------------------------------------------------------------------

 ![FC Porto-Benfica: Dragão com mais 10 vitórias em 256 clássicos | Flashscore.pt](https://livesport-ott-images.ssl.cdn.cra.cz/r900xfq60/96ba0185-97da-4df8-b6bd-09d4f78facf3.jpg) <small>www.flashscore.pt</small>FC Porto-Benfica: Dragão com mais 10 vitórias em 256 clássicos | Flashscore.pt

Benfica X Porto: Onde Assistir, Horário E Escalações Do Jogo Pelo Campeonato Português
--------------------------------------------------------------------------------------

 ![Benfica x Porto: onde assistir, horário e escalações do jogo pelo Campeonato Português](https://lncimg.lance.com.br/cdn-cgi/image/width=950,quality=75,fit=pad,format=webp/uploads/2022/10/21/63530d8cc749b.jpeg) <small>www.lance.com.br</small>Benfica x Porto: onde assistir, horário e escalações do jogo pelo Campeonato Português

Benfica 🆚 Porto | Di María E Musa Inspiram águia Em Aveiro | GoalPoint
----------------------------------------------------------------------

 ![Benfica 🆚 Porto | Di María e Musa inspiram águia em Aveiro | GoalPoint](https://goalpoint.pt/wp-content/uploads/2023/08/GoalPoint-2023-08-09-Benfica-Porto-Supertaca-2023-90m.jpg) <small>goalpoint.pt</small>Benfica 🆚 Porto | Di María e Musa inspiram águia em Aveiro | GoalPoint

SL Benfica - FC Porto (1-2), Liga Portugal 2023, Portugal | Forza Football
--------------------------------------------------------------------------

 ![SL Benfica - FC Porto (1-2), Liga Portugal 2023, Portugal | Forza Football](https://stc.vsports.pt/bigpic/liga/2223/R93SHjBjhUVOjaTMDAYUx.jpg) <small>forzafootball.com</small>SL Benfica - FC Porto (1-2), Liga Portugal 2023, Portugal | Forza Football

Benfica X Porto: Confira Informações E Onde Assistir Ao Clássico Português - Gazeta Esportiva
---------------------------------------------------------------------------------------------

 ![Benfica x Porto: confira informações e onde assistir ao clássico português - Gazeta Esportiva](https://static.gazetaesportiva.com/uploads/imagem/2023/04/06/benfica-porto.jpg) <small>www.gazetaesportiva.com</small>Benfica x Porto: confira informações e onde assistir ao clássico português - Gazeta Esportiva

Benfica 🆚 Porto | “Chocolate” Argentino Em Goleada Da águia | GoalPoint
-----------------------------------------------------------------------

 ![Benfica 🆚 Porto | “Chocolate” argentino em goleada da águia | GoalPoint](https://goalpoint.pt/wp-content/uploads/2024/11/GoalPoint-2024-11-10-Benfica-Porto-Primeira-Liga-202425-pass-network-1068x778.jpg) <small>goalpoint.pt</small>Benfica 🆚 Porto | “Chocolate” argentino em goleada da águia | GoalPoint

TRANSMISSÃO EM DIRECTO PORTO X BENFICA: A Que Horas Joga O PORTO? Veja Onde Assistir PORTO X BENFICA
----------------------------------------------------------------------------------------------------

 ![TRANSMISSÃO EM DIRECTO PORTO X BENFICA: a que horas joga o PORTO? Veja onde assistir PORTO X BENFICA](https://imagens.ne10.uol.com.br/veiculos/_midias/jpg/2022/09/30/806x444/1_design_sem_nome-21808517.jpg) <small>interior.ne10.uol.com.br</small>TRANSMISSÃO EM DIRECTO PORTO X BENFICA: a que horas joga o PORTO? Veja onde assistir PORTO X BENFICA

SL Benfica 1 - 0 FC Porto (Relato) | Jornada 7 Da I Liga - Golo FM | A Primeira Rádio Desporto
----------------------------------------------------------------------------------------------

 ![SL Benfica 1 - 0 FC Porto (Relato) | Jornada 7 da I Liga - Golo FM | A Primeira Rádio Desporto](https://golo.fm/wp-content/uploads/2023/09/Benfica-vs-FC-Porto-29092023-20h15-CAPA.png) <small>golo.fm</small>SL Benfica 1 - 0 FC Porto (Relato) | Jornada 7 da I Liga - Golo FM | A Primeira Rádio Desporto

Porto X Benfica: Horário, Escalações E Onde Assistir
----------------------------------------------------

 ![Porto x Benfica: horário, escalações e onde assistir](https://www.365scores.com/pt-br/news/magazine/wp-content/uploads/2026/01/porto-benfica.jpg) <small>www.365scores.com</small>Porto x Benfica: horário, escalações e onde assistir

Benfica E Porto Encontram-se No Sábado 7 De Maio – Observador
-------------------------------------------------------------

 ![Benfica e Porto encontram-se no sábado 7 de maio – Observador](https://bordalo.observador.pt/v2/q:60/rs:fill:980/c:2000:1126:nowe:0:0/plain/https://s3.observador.pt/wp-content/uploads/2022/04/20105641/35120370.jpg) <small>observador.pt</small>Benfica e Porto encontram-se no sábado 7 de maio – Observador

Porto X Benfica Na Liga Portugal: Onde Assistir Ao Vivo, Horário E Escalação - Estadão
--------------------------------------------------------------------------------------

 ![Porto x Benfica na Liga Portugal: onde assistir ao vivo, horário e escalação - Estadão](https://www.estadao.com.br/resizer/v2/DYEIIT6VD5BTRB6RU6JDNSTUKU.jpeg?quality=80&auth=ca806e8867ac119d2a607f145c2fc3fa20d5c3d5088152cd15ffa479572f6673&width=1200) <small>www.estadao.com.br</small>Porto x Benfica na Liga Portugal: onde assistir ao vivo, horário e escalação - Estadão

Benfica 🆚 Porto | Dragão Volta A Dar Aula Na Luz | GoalPoint
------------------------------------------------------------

 ![Benfica 🆚 Porto | Dragão volta a dar aula na Luz | GoalPoint](https://goalpoint.pt/wp-content/uploads/2023/04/GoalPoint-Benfica-Porto-Liga-bwin-202223.jpg) <small>goalpoint.pt</small>Benfica 🆚 Porto | Dragão volta a dar aula na Luz | GoalPoint

FC Porto 0 - 1 SL Benfica (Relato) Ll Abertura Da Jornada 10 Da I Liga - Golo FM | A Primeira
---------------------------------------------------------------------------------------------

 ![FC Porto 0 - 1 SL Benfica (Relato) ll Abertura da Jornada 10 da I Liga - Golo FM | A Primeira](https://golo.fm/wp-content/uploads/2022/10/Porto-vs-Benfica-21102022-20h15-Capa.png) <small>golo.fm</small>FC Porto 0 - 1 SL Benfica (Relato) ll Abertura da Jornada 10 da I Liga - Golo FM | A Primeira ...

Onde Assistir Benfica Vs Porto: Canal E Informações | Actualizado Octubre 2026
------------------------------------------------------------------------------

 ![Onde Assistir Benfica vs Porto: Canal e Informações | Actualizado octubre 2026](https://cssjoao.pt/wp-content/uploads/2024/12/liga-24-25-jornada-11-f09f94b4-benfica-vs-porto-f09f94b5-antevisao-e2978f-o-onze-do-benfica-para-o-classico.jpg) <small>cssjoao.pt</small>Onde Assistir Benfica vs Porto: Canal e Informações | Actualizado octubre 2026

Benfica - Porto Previsão E Antevisão Jogo
-----------------------------------------

 ![Benfica - Porto Previsão e Antevisão Jogo](https://sportcdns.live/news-2/8cac4738448c62d0f8d9f2f7583567d10eadcb262a4ab99adffc5314eabdbfb0.jpeg) <small>www.footboom1.com</small>Benfica - Porto Previsão e Antevisão Jogo

PORTO VS MOREIRENSE EM DIRETO: A QUE HORAS JOGA O PORTO? Veja Onde Vai Dar E Horário Do JOGO DO
-----------------------------------------------------------------------------------------------

 ![PORTO VS MOREIRENSE EM DIRETO: A QUE HORAS JOGA O PORTO? Veja onde vai dar e horário do JOGO DO](https://imagens.ne10.uol.com.br/veiculos/_midias/jpg/2023/01/20/615x300/1_fc_porto-22326811.jpg?20231113185208) <small>jc.uol.com.br</small>PORTO VS MOREIRENSE EM DIRETO: A QUE HORAS JOGA O PORTO? Veja onde vai dar e horário do JOGO DO ...

Assistir FC Porto X SL Benfica Ao Vivo Na Tv FPB TV 3 Março | Discusión | Sbm.edu.pe
------------------------------------------------------------------------------------

 ![assistir FC Porto x SL Benfica ao vivo na tv FPB TV 3 março | Discusión | sbm.edu.pe](https://static.wixstatic.com/media/097cef_f1115789e6de46aa805d6fbb8954a4fc~mv2.gif) <small>www.sbm.edu.pe</small>assistir FC Porto x SL Benfica ao vivo na tv FPB TV 3 março | Discusión | sbm.edu.pe

Benfica 🆚 Porto | “Chocolate” Argentino Em Goleada Da águia | GoalPoint
-----------------------------------------------------------------------

 ![Benfica 🆚 Porto | “Chocolate” argentino em goleada da águia | GoalPoint](https://goalpoint.pt/wp-content/uploads/2024/11/GoalPoint-2024-11-10-Benfica-Porto-Primeira-Liga-202425-90m.jpg) <small>goalpoint.pt</small>Benfica 🆚 Porto | “Chocolate” argentino em goleada da águia | GoalPoint

FC Porto 5 - 0 SL Benfica (Relato) | Jornada 24 Da I Liga - Golo FM | A Primeira Rádio Desporto
-----------------------------------------------------------------------------------------------

 ![FC Porto 5 - 0 SL Benfica (Relato) | Jornada 24 da I Liga - Golo FM | A Primeira Rádio Desporto](https://golo.fm/wp-content/uploads/2024/03/Porto-vs-Benfica-03032024-20H30-CAPA.png) <small>golo.fm</small>FC Porto 5 - 0 SL Benfica (Relato) | Jornada 24 da I Liga - Golo FM | A Primeira Rádio Desporto

Calendário: O Que Falta A Benfica E FC Porto | MAISFUTEBOL
----------------------------------------------------------

 ![Calendário: o que falta a Benfica e FC Porto | MAISFUTEBOL](http://www.iol.pt/multimedia/oratvi/multimedia/imagem/id/550df3290cf2cc713bb594af/) <small>maisfutebol.iol.pt</small>Calendário: o que falta a Benfica e FC Porto | MAISFUTEBOL

Benfica X FC Porto: Onde E A Que Horas Ver O Jogo Da Liga Portuguesa? - 4gnews
------------------------------------------------------------------------------

 ![Benfica x FC Porto: onde e a que horas ver o jogo da Liga Portuguesa? - 4gnews](https://cdn.4gnews.pt/imagens/sporting-x-benfica-onde-e-a-que-horas-ver-o-classico-da-liga-portuguesa-s4g.jpg) <small>4gnews.pt</small>Benfica x FC Porto: onde e a que horas ver o jogo da Liga Portuguesa? - 4gnews

Clássico: Benfica E FC Porto Frente A Frente Este Domingo! - Golo FM | A Primeira Rádio Desporto
------------------------------------------------------------------------------------------------

 ![Clássico: Benfica e FC Porto frente a frente este domingo! - Golo FM | A Primeira Rádio Desporto](https://golo.fm/wp-content/uploads/2026/03/Benfica-e-FC-Porto.jpg) <small>golo.fm</small>Clássico: Benfica e FC Porto frente a frente este domingo! - Golo FM | A Primeira Rádio Desporto

Horário Do Jogo Benfica Vs Porto | Actualizado Julio 2026
---------------------------------------------------------

 ![Horário do Jogo Benfica vs Porto | Actualizado julio 2026](https://cssjoao.pt/wp-content/uploads/2024/11/resumo-fc-porto-5-0-benfica-liga-portugal-betclic-sport-tv.jpg) <small>cssjoao.pt</small>Horário do Jogo Benfica vs Porto | Actualizado julio 2026

Clássico Benfica-FC Porto Já Tem Data E Hora | MAISFUTEBOL
----------------------------------------------------------

 ![Clássico Benfica-FC Porto já tem data e hora | MAISFUTEBOL](https://www.iol.pt/multimedia/oratvi/multimedia/imagem/id/5d49aa700cf2918a3666f017/) <small>maisfutebol.iol.pt</small>Clássico Benfica-FC Porto já tem data e hora | MAISFUTEBOL

Vídeo - Liga Portugal Betclic (24ª Jornada): Resumo FC Porto 5-0 Benfica
------------------------------------------------------------------------

 ![Vídeo - Liga Portugal Betclic (24ª Jornada): Resumo FC Porto 5-0 Benfica](https://stc.vsports.pt/bigpic/liga/2324/a85gGrMmOCCR3PeZBeDof.jpg) <small>vsports.pt</small>Vídeo - Liga Portugal Betclic (24ª Jornada): Resumo FC Porto 5-0 Benfica

Porto X Benfica Hoje (14/1): Onde Assistir Ao Vivo, Horário E Escalações Da Taça De Portugal
--------------------------------------------------------------------------------------------

 ![Porto x Benfica hoje (14/1): onde assistir ao vivo, horário e escalações da Taça de Portugal](https://imagens.ne10.uol.com.br/veiculos/_midias/png/2026/01/14/blog_do_torcedor___site__7_-36341043.png?6967a0050ea2d) <small>jc.uol.com.br</small>Porto x Benfica hoje (14/1): onde assistir ao vivo, horário e escalações da Taça de Portugal

Antevisão Benfica 🆚 Porto | O Que Dizem Os Teus Analytics, Antunes? | GoalPoint
-------------------------------------------------------------------------------

 ![Antevisão Benfica 🆚 Porto | O que dizem os teus analytics, Antunes? | GoalPoint](https://goalpoint.pt/wp-content/uploads/2023/04/GoalPoint-Benfica-Porto-Antevisao-C-RaioX-04.2023-infog.jpg) <small>goalpoint.pt</small>Antevisão Benfica 🆚 Porto | O que dizem os teus analytics, Antunes? | GoalPoint

Benfica 🆚 Porto | Águia Supera Dragão Com Decisão De Di María | GoalPoint
-------------------------------------------------------------------------

 ![Benfica 🆚 Porto | Águia supera dragão com decisão de Di María | GoalPoint](https://goalpoint.pt/wp-content/uploads/2023/09/GoalPoint-Benfica-Porto-Primeira-Liga-202324.jpg) <small>goalpoint.pt</small>Benfica 🆚 Porto | Águia supera dragão com decisão de Di María | GoalPoint

Liga: Já Há Datas E Horas Para O Benfica-FC Porto E Sp. Braga-Sporting - CNN Portugal
-------------------------------------------------------------------------------------

 ![Liga: já há datas e horas para o Benfica-FC Porto e Sp. Braga-Sporting - CNN Portugal](https://img.iol.pt/image/id/68e2f00fd34e58bc67968d69/1024.jpg) <small>cnnportugal.iol.pt</small>Liga: já há datas e horas para o Benfica-FC Porto e Sp. Braga-Sporting - CNN Portugal

FC Porto Benfica Resumo Alargado Liga Betclic - SL Benfica
----------------------------------------------------------

 ![FC Porto Benfica Resumo Alargado Liga Betclic - SL Benfica](https://media.slbenfica.pt/-/media/benficadp/images/departamento-de-comunicacao/2025/futebol/competicoes/liga-betclic/8-jornada-fc-porto-benfica/jogo/lukebakio-1-new.jpg?h=725&w=1208&v=638953055690000000&hash=D875750D447A6781D67FC65DDAC648EA) <small>www.slbenfica.pt</small>FC Porto Benfica Resumo Alargado Liga Betclic - SL Benfica

Benfica X FC Porto: Onde E A Que Horas Ver O Jogo Da Liga Portuguesa? - 4gnews
------------------------------------------------------------------------------

 ![Benfica x FC Porto: onde e a que horas ver o jogo da Liga Portuguesa? - 4gnews](https://cdn.4gnews.pt/imagens/benfica-x-fc-porto-onde-e-a-que-horas-ver-o-jogo-da-liga-portuguesa-og.jpg) <small>4gnews.pt</small>Benfica x FC Porto: onde e a que horas ver o jogo da Liga Portuguesa? - 4gnews

Já Há Data E Hora Para O Clássico Entre Benfica E FC Porto - Futebol - Correio Da Manhã
---------------------------------------------------------------------------------------

 ![Já há data e hora para o Clássico entre Benfica e FC Porto - Futebol - Correio da Manhã](https://cdn.cmjornal.pt/images/2021-04/img_1500x1000uu2021-04-16-21-00-23-1030154.jpg) <small>www.cmjornal.pt</small>Já há data e hora para o Clássico entre Benfica e FC Porto - Futebol - Correio da Manhã

ONDE ASSISTIR PORTO X BRUGGE EM DIRETO: Veja Escalações, A Que Horas Joga O PORTO E Onde
----------------------------------------------------------------------------------------

 ![ONDE ASSISTIR PORTO X BRUGGE EM DIRETO: veja escalações, a que horas joga o PORTO e onde](https://imagens.ne10.uol.com.br/veiculos/_midias/jpg/2022/09/13/806x444/1_whatsapp_image_2022_09_13_at_09_36_24-21705969.jpeg) <small>interior.ne10.uol.com.br</small>ONDE ASSISTIR PORTO X BRUGGE EM DIRETO: veja escalações, a que horas joga o PORTO e onde ...

Assista Porto Vs Benfica Online Grátis | Actualizado Julio 2026
---------------------------------------------------------------

 ![Assista Porto vs Benfica Online Grátis | Actualizado julio 2026](https://ostris.pt/wp-content/uploads/2024/12/benfica-vs-fc-porto-ao-vivo-liga-portugal-24-25-simulacao-e-placar-ao-vivo.jpg) <small>ostris.pt</small>Assista Porto vs Benfica Online Grátis | Actualizado julio 2026

Jogo Do Porto E Do Benfica : FC Porto – KXBBAD
----------------------------------------------

 ![Jogo Do Porto E Do Benfica : FC Porto – KXBBAD](https://goalpoint.pt/wp-content/uploads/2015/09/GP-destaque-AntevisãonNumerosFCPSLBLigaNOS201516-19Set2015.jpg) <small>willisfraternity.com</small>Jogo Do Porto E Do Benfica : FC Porto – KXBBAD

Assista porto vs benfica online grátis. benfica x porto: onde assistir, horário e escalações do jogo pelo campeonato português. Porto x benfica hoje (14/1): onde assistir ao vivo, horário e escalações da taça de portugal
