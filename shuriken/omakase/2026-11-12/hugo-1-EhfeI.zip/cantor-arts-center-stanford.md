---
title: "Cantor Arts Center Stanford - Cantor arts center facade, stanford campus, palo alto, california stock photo"
description: "Visiting stanford university: where to stay, what to eat, what to do"
date: "2026-05-24"
categories:
- "Uncategorized"
images:
- "https://media.istockphoto.com/photos/cantor-center-for-visual-arts-museum-at-stanford-university-campus-picture-id663937156?k=6&amp;m=663937156&amp;s=170667a&amp;w=0&amp;h=crF_bckYLmcfOo5hZQ7xHO9FuOomCG4AescdHO_Z_ZA="
featuredImage: "https://assets.simpleviewinc.com/simpleview/image/fetch/c_limit,q_75,w_1200/https://assets.simpleviewinc.com/simpleview/image/upload/crm/sanmateoca/Cantor_Arts_Museum_by_Juan_Camero_-3-_-Copy-_fc03fcc6-5056-a36a-0b33dbd7f85b97b5.jpg"
featured_image: "https://1.bp.blogspot.com/-6S89r6AYG9I/Vp1iNSq80kI/AAAAAAAAYeY/OoJJrfEi5ww/s640/Center-For-Visual-Arts-Stanford.jpg"
image: "https://rde.stanford.edu/sites/default/files/styles/half_width/public/2025-04/cantor arts center.jpg?itok=4N7-7-0o"
---

If you are searching about Cantor arts center stanford hi-res stock photography and images - Alamy you've came to the right web. We have 35 Pics about Cantor arts center stanford hi-res stock photography and images - Alamy like El Anatsui | Cantor Arts Center, 17 Best Things to Do in Palo Alto, California and also Museum Policies | Cantor Arts Center. Here it is:

Cantor Arts Center Stanford Hi-res Stock Photography And Images - Alamy
-----------------------------------------------------------------------

 ![Cantor arts center stanford hi-res stock photography and images - Alamy](https://c8.alamy.com/comp/T945NE/may-9-2019-palo-alto-ca-usa-entrance-to-the-cantor-center-for-visual-arts-stanford-san-francisco-bay-area-T945NE.jpg) <small>www.alamy.com</small>Cantor arts center stanford hi-res stock photography and images - Alamy

Cantor Arts Center Receives Collection Of Over 1,000 Photos | Giving To Stanford
--------------------------------------------------------------------------------

 ![Cantor Arts Center receives collection of over 1,000 photos | Giving to Stanford](https://assets.stanford.edu/i/2000x0/filters:quality(60)/f/78141/3008x1960/15b3794cf5/cantor.jpg) <small>giving.stanford.edu</small>Cantor Arts Center receives collection of over 1,000 photos | Giving to Stanford

Cantor Center For Visual Arts - Architectural Restoration
---------------------------------------------------------

 ![Cantor Center for Visual Arts - Architectural Restoration](https://www.argcreate.com/wp-content/uploads/2015/09/IMG_9631.jpg) <small>www.argcreate.com</small>Cantor Center for Visual Arts - Architectural Restoration

Entrance To Cantor Arts Center, Formerly The Leland Stanford Junior Museum, On The Campus Of
--------------------------------------------------------------------------------------------

 ![Entrance to Cantor Arts Center, formerly the Leland Stanford Junior Museum, on the campus of](https://c8.alamy.com/comp/KW4KC4/entrance-to-cantor-arts-center-formerly-the-leland-stanford-junior-KW4KC4.jpg) <small>www.alamy.com</small>Entrance to Cantor Arts Center, formerly the Leland Stanford Junior Museum, on the campus of ...

Art Collection At The Stanford University California USA | Delhi-Fun-Dos.com
----------------------------------------------------------------------------

 ![Art Collection at The Stanford University California USA | Delhi-Fun-Dos.com](https://delhi-fun-dos.com/wp-content/uploads/2021/01/Stanford-art-Cantor-Arts-Center-Collection.jpg) <small>delhi-fun-dos.com</small>Art Collection at The Stanford University California USA | Delhi-Fun-Dos.com

News - Stanford AIA Society Pairs With The Stanford Cantor Arts Center For Specialized Gallery
----------------------------------------------------------------------------------------------

 ![News - Stanford AIA Society Pairs with the Stanford Cantor Arts Center for Specialized Gallery](https://www.archaeological.org/wp-content/uploads/2019/04/stanford_cantor_center.jpg) <small>www.archaeological.org</small>News - Stanford AIA Society Pairs with the Stanford Cantor Arts Center for Specialized Gallery ...

Stanford’s Cantor Arts Center Adds Over 100 New Works Of Asian American Art | NextShark.com
-------------------------------------------------------------------------------------------

 ![Stanford’s Cantor Arts Center adds over 100 new works of Asian American art | NextShark.com](https://data.nextshark.com/wp-content/uploads/2023/12/Cantor-Arts-Center.jpg) <small>nextshark.com</small>Stanford’s Cantor Arts Center adds over 100 new works of Asian American art | NextShark.com

Cantor Arts Center At Stanford University
-----------------------------------------

 ![Cantor Arts Center at Stanford University](https://assets.simpleviewinc.com/simpleview/image/fetch/c_limit,q_75,w_1200/https://assets.simpleviewinc.com/simpleview/image/upload/crm/sanmateoca/Cantor-Arts-Center-Lobby---with-two-guys---by-Stephen-Gladfelter-Visual-Art-Services-95e52e785056a36_95e52f89-5056-a36a-0bfc2234bc8b543c.jpg) <small>www.thesanfranciscopeninsula.com</small>Cantor Arts Center at Stanford University

El Anatsui | Cantor Arts Center
-------------------------------

 ![El Anatsui | Cantor Arts Center](https://elanatsui.art/cms/2019/04/Iris-B.-Gerald-Cantor-Center-for-Visual-Arts-Stanford-University-California-Photo-courtesy-Sothebys-Museum-Network.jpg) <small>elanatsui.art</small>El Anatsui | Cantor Arts Center

Cantor Center For Visual Arts Museum At Stanford University Campus Palo Alto California Usa
-------------------------------------------------------------------------------------------

 ![Cantor Center For Visual Arts Museum At Stanford University Campus Palo Alto California Usa](https://media.istockphoto.com/photos/cantor-center-for-visual-arts-museum-at-stanford-university-campus-picture-id663937156?k=6&m=663937156&s=170667a&w=0&h=crF_bckYLmcfOo5hZQ7xHO9FuOomCG4AescdHO_Z_ZA=) <small>www.istockphoto.com</small>Cantor Center For Visual Arts Museum At Stanford University Campus Palo Alto California Usa ...

Summer Intern Housing | Stanford R&amp;DE
-----------------------------------------

 ![Summer Intern Housing | Stanford R&DE](https://rde.stanford.edu/sites/default/files/styles/half_width/public/2025-04/cantor arts center.jpg?itok=4N7-7-0o) <small>rde.stanford.edu</small>Summer Intern Housing | Stanford R&amp;DE

17 Best Things To Do In Palo Alto, California
---------------------------------------------

 ![17 Best Things to Do in Palo Alto, California](https://admin.viatravelers.com/wp-content/uploads/cantor-arts-center.jpeg) <small>viatravelers.com</small>17 Best Things to Do in Palo Alto, California

Stanford Sweeteners | Cardinal At Work
--------------------------------------

 ![Stanford Sweeteners | Cardinal at Work](https://cardinalatwork.stanford.edu/sites/cardinalatwork/files/styles/card_1900x950/public/media/images/sweetener/cantor_front-copy_870x330-2.png?h=b33c5a89&itok=fG6vS-R3) <small>cardinalatwork.stanford.edu</small>Stanford Sweeteners | Cardinal at Work

Museo De Arte De La Universidad De Stanford: Cantor Arts Center
---------------------------------------------------------------

 ![Museo de Arte de la Universidad de Stanford: Cantor Arts Center](https://1.bp.blogspot.com/-6S89r6AYG9I/Vp1iNSq80kI/AAAAAAAAYeY/OoJJrfEi5ww/s640/Center-For-Visual-Arts-Stanford.jpg) <small>www.amis30porboston.com</small>Museo de Arte de la Universidad de Stanford: Cantor Arts Center

General Overall View Of The Cantor Arts Center, Named After Iris And B. Gerald Cantor, On The
---------------------------------------------------------------------------------------------

 ![General overall view of the Cantor Arts Center, named after Iris and B. Gerald Cantor, on the](https://c8.alamy.com/comp/W1JX20/general-overall-view-of-the-cantor-arts-center-named-after-iris-and-b-gerald-cantor-on-the-campus-of-stanford-university-sunday-june-30-2019-in-stanford-calif-the-museum-which-opened-in-1894-consists-of-over-130000-square-feet-of-space-including-sculpture-gardens-the-cantor-center-houses-one-of-the-largest-collections-of-auguste-rodin-sculptures-outside-paris-france-with-199-works-by-rodin-most-in-bronze-but-also-other-media-many-sculptures-are-on-display-in-the-b-gerald-cantor-rodin-sculpture-garden-photo-via-newscom-W1JX20.jpg) <small>www.alamy.com</small>General overall view of the Cantor Arts Center, named after Iris and B. Gerald Cantor, on the ...

Museums From Home | Cantor Arts Center
--------------------------------------

 ![Museums From Home | Cantor Arts Center](https://museum.stanford.edu/sites/default/files/images/2020-03/oyyo-0_0.png) <small>museum.stanford.edu</small>Museums From Home | Cantor Arts Center

Cantor Arts Center, Stanford University, California Stock Photo - Alamy
-----------------------------------------------------------------------

 ![Cantor Arts Center, Stanford University, California Stock Photo - Alamy](https://c8.alamy.com/comp/2PJ17R9/cantor-arts-center-stanford-university-california-2PJ17R9.jpg) <small>www.alamy.com</small>Cantor Arts Center, Stanford University, California Stock Photo - Alamy

Cantor Arts Center At Stanford University | Stanford CA
-------------------------------------------------------

 ![Cantor Arts Center at Stanford University | Stanford CA](https://lookaside.fbsbx.com/lookaside/crawler/media/?media_id=1250253237099774) <small>www.facebook.com</small>Cantor Arts Center at Stanford University | Stanford CA

Hello, Cantor | Cantor Arts Center
----------------------------------

 ![Hello, Cantor | Cantor Arts Center](https://museum.stanford.edu/sites/default/files/images/2021-07/hello-cantor.jpg) <small>museum.stanford.edu</small>Hello, Cantor | Cantor Arts Center

Museo De Arte De La Universidad De Stanford: Cantor Arts Center
---------------------------------------------------------------

 ![Museo de Arte de la Universidad de Stanford: Cantor Arts Center](https://2.bp.blogspot.com/-5hyPve7bIZc/Vp1ickmjfUI/AAAAAAAAYeg/fu7PwZhqhOA/s1600/Leland-Stanford-Junior-Museum.jpg) <small>www.amis30porboston.com</small>Museo de Arte de la Universidad de Stanford: Cantor Arts Center

Museums From Home | Cantor Arts Center
--------------------------------------

 ![Museums From Home | Cantor Arts Center](https://museum.stanford.edu/sites/default/files/styles/9_7_md/public/images/2020-10/acatsu-outdoors-zoom-background.png?itok=Gmcy1fYI) <small>museum.stanford.edu</small>Museums From Home | Cantor Arts Center

Stanford - Until Suburbia!
--------------------------

 ![Stanford - until suburbia!](https://i0.wp.com/untilsuburbia.com/wp-content/uploads/2018/01/IMG_4066.jpg?ssl=1) <small>untilsuburbia.com</small>Stanford - until suburbia!

Senior Column: The Final Statement
----------------------------------

 ![Senior Column: The final statement](https://stanforddaily.com/wp-content/uploads/2019/07/IMG_2096.jpg) <small>stanforddaily.com</small>Senior Column: The final statement

Cantor Arts Center - Wikipedia
------------------------------

 ![Cantor Arts Center - Wikipedia](https://upload.wikimedia.org/wikipedia/commons/thumb/6/6d/Iris_%26_B._Gerald_Cantor_Center_for_Visual_Arts%2C_Stanford%2C_California_-_20060728.jpg/375px-Iris_%26_B._Gerald_Cantor_Center_for_Visual_Arts%2C_Stanford%2C_California_-_20060728.jpg) <small>en.wikipedia.org</small>Cantor Arts Center - Wikipedia

Cantor Arts Center - Stanford University
----------------------------------------

 ![Cantor Arts Center - Stanford University](https://localist-images.azureedge.net/photos/39183653332271/square_300@2x/27f55fd46d828d18149e63d3559d9acf3ffbdf0c.jpg) <small>events.stanford.edu</small>Cantor Arts Center - Stanford University

Cantor Arts Center - Wikipedia
------------------------------

 ![Cantor Arts Center - Wikipedia](https://upload.wikimedia.org/wikipedia/commons/thumb/3/32/The_B._Gerald_Cantor_Sculpture_Garden_at_Stanford_University%3B_view_from_west_entrance_(cropped).JPG/2135px-The_B._Gerald_Cantor_Sculpture_Garden_at_Stanford_University%3B_view_from_west_entrance_(cropped).JPG) <small>en.wikipedia.org</small>Cantor Arts Center - Wikipedia

Stanford University, Cantor Arts Center Skylight - SGH
------------------------------------------------------

 ![Stanford University, Cantor Arts Center Skylight - SGH](https://www.sgh.com/wp-content/uploads/2021/09/CantorArtCenter-1024x492.jpg) <small>www.sgh.com</small>Stanford University, Cantor Arts Center Skylight - SGH

Visiting Stanford University: Where To Stay, What To Eat, What To Do | Cantor Arts Center News
----------------------------------------------------------------------------------------------

 ![Visiting Stanford University: Where To Stay, What To Eat, What To Do | Cantor Arts Center News](https://museum.stanford.edu/sites/default/files/styles/width_constrained_md/public/images/2022-04/thumbnail-n6a9573.jpg?itok=LgQT6ORp) <small>museum.stanford.edu</small>Visiting Stanford University: Where To Stay, What To Eat, What To Do | Cantor Arts Center News

Cantor Arts Center Stanford Hi-res Stock Photography And Images - Alamy
-----------------------------------------------------------------------

 ![Cantor arts center stanford hi-res stock photography and images - Alamy](https://c8.alamy.com/comp/G3HB94/the-iris-and-b-gerald-cantor-center-for-visual-arts-stanford-university-G3HB94.jpg) <small>www.alamy.com</small>Cantor arts center stanford hi-res stock photography and images - Alamy

Cantor Arts Center At Stanford University Opens Christian Marclay's Video Quartet | Museum Publicity
----------------------------------------------------------------------------------------------------

 ![Cantor Arts Center at Stanford University opens Christian Marclay's Video Quartet | Museum Publicity](http://museumpublicity.com/wp-content/uploads/2012/11/Cantor-Arts-Center.jpg) <small>museumpublicity.com</small>Cantor Arts Center at Stanford University opens Christian Marclay's Video Quartet | Museum Publicity

Museum Policies | Cantor Arts Center
------------------------------------

 ![Museum Policies | Cantor Arts Center](https://museum.stanford.edu/sites/default/files/images/2017-11/6-staff-directory-garden-photo.jpg) <small>museum.stanford.edu</small>Museum Policies | Cantor Arts Center

Cantor Arts Center Photos And Premium High Res Pictures - Getty Images
----------------------------------------------------------------------

 ![Cantor Arts Center Photos and Premium High Res Pictures - Getty Images](https://media.gettyimages.com/id/598748812/photo/entrance-to-cantor-arts-center-formerly-the-leland-stanford-junior-museum-on-the-campus-of.jpg?s=612x612&w=gi&k=20&c=5Z2N4tIxFuVvvZH5Q6fRhIp-pIVzPKqxmwMc3yoCsmM=) <small>www.gettyimages.ie</small>Cantor Arts Center Photos and Premium High Res Pictures - Getty Images

Cantor Arts Center At Stanford University
-----------------------------------------

 ![Cantor Arts Center at Stanford University](https://assets.simpleviewinc.com/simpleview/image/fetch/c_limit,q_75,w_1200/https://assets.simpleviewinc.com/simpleview/image/upload/crm/sanmateoca/Cantor_Arts_Museum_by_Juan_Camero_-3-_-Copy-_fc03fcc6-5056-a36a-0b33dbd7f85b97b5.jpg) <small>www.thesanfranciscopeninsula.com</small>Cantor Arts Center at Stanford University

The Rodin Collection At Stanford's Cantor Arts Center
-----------------------------------------------------

 ![The Rodin Collection at Stanford's Cantor Arts Center](https://stanforddaily.com/wp-content/uploads/2013/07/rodin_reinstallation-5.jpg) <small>stanforddaily.com</small>The Rodin Collection at Stanford's Cantor Arts Center

Cantor Arts Center Facade, Stanford Campus, Palo Alto, California Stock Photo - Alamy
-------------------------------------------------------------------------------------

 ![Cantor arts center facade, Stanford campus, Palo Alto, California Stock Photo - Alamy](https://www.alamy.com/aggregator-api/download?url=https://c8.alamy.com/comp/GC2A7G/cantor-arts-center-facade-stanford-campus-palo-alto-california-GC2A7G.jpg) <small>www.alamy.com</small>Cantor arts center facade, Stanford campus, Palo Alto, California Stock Photo - Alamy

Visiting stanford university: where to stay, what to eat, what to do. The rodin collection at stanford's cantor arts center. Cantor arts center
