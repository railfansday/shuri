---
title: "Kimberly Powell Nvda - Who is kimberly powell? the name at the center of nvidia&#039;s $4 trillion key-man risk"
description: "Who is kimberly powell, nvidia executive who had affair with ceo jensen huang?"
date: "2026-11-02"
categories:
- "Uncategorized"
images:
- "https://polymarket.us/api/og/event/kimpow-nvda-vp.png"
featuredImage: "https://jf.x.com/images/media-preview/2120653520701686223"
featured_image: "https://img.etimg.com/thumb/msid-135754452,width-950,height-600,imgsize-130156,resizemode-75/jensen-huangs-former-partner-kimberly-powell-walks-the-show-floor-in-nvidia-videobr.jpg"
image: "https://wikiofcelebrities.com/wp-content/uploads/2026/11/Kimberly-Powell.webp"
---

If you are looking for Kimberly Powell Nvidia career: Before Nvidia, Kimberly Powell was an engineering intern in you've came to the right page. We have 35 Images about Kimberly Powell Nvidia career: Before Nvidia, Kimberly Powell was an engineering intern in like Who Is Kimberly Powell, the Nvidia Executive Linked to CEO Jensen Huang? | Republic World, Kimberly Powell-Jensen Huang Alleged Affair: What Nvidia's Cod... and also AlphaGen on X: "JUST IN: Nvidia $NVDA CEO Jensen Huang had another affair with an Nvidia. Here it is:

Kimberly Powell Nvidia Career: Before Nvidia, Kimberly Powell Was An Engineering Intern In
------------------------------------------------------------------------------------------

 ![Kimberly Powell Nvidia career: Before Nvidia, Kimberly Powell was an engineering intern in](https://img.etimg.com/thumb/msid-135774638,width-650,height-488,imgsize-152718,resizemode-75/before-nvidia-kimberly-powell-was-an-engineering-intern-in-radiology-tech-how-she-built-an-18-year-career-in-ai-healthcare-now-in-the-spotlight-after-jensen-huang-report.jpg) <small>economictimes.indiatimes.com</small>Kimberly Powell Nvidia career: Before Nvidia, Kimberly Powell was an engineering intern in ...

Nvidia Executive Kimberly Powell Suddenly Drops Out Of Major Health Summit After Bombshell
------------------------------------------------------------------------------------------

 ![Nvidia Executive Kimberly Powell Suddenly Drops Out of Major Health Summit After Bombshell](https://s.yimg.com/lo/mysterio/api/d6a972b54b34b419f7e64a75ea4376ab500c6f90e417ae306e42bbcc44eed87b/lightyear_networkapi/resizefit_w960%3Bquality_80%3Bformat_webp/https://media.zenfs.com/en/Benzinga/8ac06398c886889c1474a11071a89bc8.jpg) <small>uk.finance.yahoo.com</small>Nvidia Executive Kimberly Powell Suddenly Drops Out of Major Health Summit After Bombshell ...

J Gautam ♑️ On X: "This Is Kimberly Powell, NVIDIA VP Of Healthcare." / X
-------------------------------------------------------------------------

 ![J Gautam ♑️ on X: "This is Kimberly Powell, NVIDIA VP of Healthcare." / X](https://jf.x.com/images/media-preview/2120653520701686223) <small>x.com</small>J Gautam ♑️ on X: "This is Kimberly Powell, NVIDIA VP of Healthcare." / X

Kimberly Powell, The Engineer Who Became Nvidia's Healthcare VP And Is Now Caught In The Jensen
-----------------------------------------------------------------------------------------------

 ![Kimberly Powell, the engineer who became Nvidia's healthcare VP and is now caught in the Jensen](https://www.asiaone.com/sites/default/files/styles/article_top_image/public/original_images/Nov2026/kimberly-powell-nvidia-facebook (1).jpg?itok=hIIek7fk) <small>www.asiaone.com</small>Kimberly Powell, the engineer who became Nvidia's healthcare VP and is now caught in the Jensen ...

Kimberly Powell Nvidia: Summit Exit After Huang Report
------------------------------------------------------

 ![Kimberly Powell Nvidia: Summit Exit After Huang Report](https://bitcoinfoundation.org/wp-content/uploads/2026/11/kimberly-powell-cancels-health-summit-appearance-after-nvidia-ceo-relationship-r.webp) <small>bitcoinfoundation.org</small>Kimberly Powell Nvidia: Summit Exit After Huang Report

Who Is Kimberly Powell, The Nvidia Executive Linked To CEO Jensen Huang? | Republic World
-----------------------------------------------------------------------------------------

 ![Who Is Kimberly Powell, the Nvidia Executive Linked to CEO Jensen Huang? | Republic World](https://img.republicworld.com/all_images/2026/11/who-is-kimberly-powell-the-nvidia-executive-linked-to-ceo-jensen-huang-1794455712889-1280x720.webp?w=1280&h=720&q=75&format=webp) <small>www.republicworld.com</small>Who Is Kimberly Powell, the Nvidia Executive Linked to CEO Jensen Huang? | Republic World

Who Is Kimberly Powell, Nvidia Executive Who Had Affair With CEO Jensen Huang?
------------------------------------------------------------------------------

 ![Who Is Kimberly Powell, Nvidia Executive Who Had Affair With CEO Jensen Huang?](https://c.ndtvimg.com/2026-11/9ks3vb1s_kimberly-powell_625x300_12_November_26.jpeg?downsize=773:435) <small>www.ndtv.com</small>Who Is Kimberly Powell, Nvidia Executive Who Had Affair With CEO Jensen Huang?

Kimberly Powell Y El Pulso Interno Que Sacude Nvidia
----------------------------------------------------

 ![Kimberly Powell Y El Pulso Interno Que Sacude Nvidia](https://media.elperiodico.digital/uploads/2026/11/Kimberly-Powell-Nvidia-ejecutiva.jpg.webp) <small>www.elperiodico.digital</small>Kimberly Powell Y El Pulso Interno Que Sacude Nvidia

Who Is Kimberly Powell? The Name At The Center Of Nvidia's $4 Trillion Key-Man Risk | AInvest
---------------------------------------------------------------------------------------------

 ![Who Is Kimberly Powell? The Name at the Center of Nvidia's $4 Trillion Key-Man Risk | AInvest](https://cdn.ainvest.com/news/visual/visual_components/img_e122ea27b24e1c19-94bd444e50b4.png) <small>www.ainvest.com</small>Who Is Kimberly Powell? The Name at the Center of Nvidia's $4 Trillion Key-Man Risk | AInvest

Who Is Kimberly Powell? Nvidia Executive Who Had Affair With CEO Jensen Huang
-----------------------------------------------------------------------------

 ![Who Is Kimberly Powell? Nvidia Executive Who Had Affair With CEO Jensen Huang](https://c.ndtvimg.com/2026-11/atbds6hc_kimberly-powell_625x300_12_November_26.jpeg?im=FaceCrop,algorithm=dnn,width=1600,height=900) <small>www.ndtv.com</small>Who Is Kimberly Powell? Nvidia Executive Who Had Affair With CEO Jensen Huang

Kimberly Powell Announced Out As NVIDIA VP Of Healthcare? | Polymarket
----------------------------------------------------------------------

 ![Kimberly Powell Announced Out as NVIDIA VP of Healthcare? | Polymarket](https://polymarket.us/_next/image?url=https:%2F%2Fpolymarket-upload.s3.us-east-2.amazonaws.com%2Fmisc-kimberly-powell-a3ecb6d98c.jpg&w=128&q=75) <small>polymarket.us</small>Kimberly Powell Announced Out as NVIDIA VP of Healthcare? | Polymarket

Who Is Nvidia Executive Kimberly Powell? - AOL
----------------------------------------------

 ![Who is Nvidia executive Kimberly Powell? - AOL](https://hermes.media.static.aol.com/media/2026/11/11/d44c8ff8-5e6e-30b3-9296-a33be5b28962/8e0af17b-97df-4856-bacf-736fe2214218.jpg) <small>www.aol.com</small>Who is Nvidia executive Kimberly Powell? - AOL

Kimberly Powell's Nvidia Role Goes Beyond AI Chips As…
------------------------------------------------------

 ![Kimberly Powell's Nvidia Role Goes Beyond AI Chips as…](https://images.inkl.com/s3/article/lead_image/24054567/kimberly-powell.png) <small>www.inkl.com</small>Kimberly Powell's Nvidia Role Goes Beyond AI Chips as…

Kimberly Powell Biography: Age, Nvidia Healthcare Career And The Jensen Huang Report – The
------------------------------------------------------------------------------------------

 ![Kimberly Powell Biography: Age, Nvidia Healthcare Career and the Jensen Huang Report – The](https://jaisalmernews.com/wp-content/uploads/2026/11/kimberly-powell-biography-cover.webp) <small>jaisalmernews.com</small>Kimberly Powell Biography: Age, Nvidia Healthcare Career and the Jensen Huang Report – The ...

¿Quién Es Kimberly Powell, Ligada A Jensen Huang, Ex Ceo De Nvidia?- Grupo Milenio
----------------------------------------------------------------------------------

 ![¿Quién es Kimberly Powell, ligada a Jensen Huang, ex Ceo de Nvidia?- Grupo Milenio](https://cdn.milenio.com/uploads/media/2026/11/12/kimberly-powell-ejecutiva-nvidia-relacionada.jpg) <small>www.milenio.com</small>¿Quién es Kimberly Powell, ligada a Jensen Huang, ex Ceo de Nvidia?- Grupo Milenio

Illustration: Quartz
--------------------

 ![Illustration: Quartz](https://qz.com/cdn-cgi/image/width=1920,quality=85,format=auto/https://assets.qz.com/media/quartz-run-2382-slide-2-18782-1920x1288.jpg) <small>qz.com</small>Illustration: Quartz

NVIDIA VP Kimberly Powell Announced Resignation Or Remova... 2026 | Polymarket
------------------------------------------------------------------------------

 ![NVIDIA VP Kimberly Powell announced resignation or remova... 2026 | Polymarket](https://polymarket.com/api/og?eslug=nvidia-vp-kimberly-powell-announced-resignation-or-removal-byptptpt&tid=1794481024899) <small>polymarket.com</small>NVIDIA VP Kimberly Powell announced resignation or remova... 2026 | Polymarket

Kimberly Powell's 18-Year Journey At Nvidia Draws Attention After Personal Links With CEO Jensen
------------------------------------------------------------------------------------------------

 ![Kimberly Powell's 18-Year Journey At Nvidia Draws Attention After Personal Links With CEO Jensen](https://images.thedailyjagran.com/images/2026/11/12/template/image/Kimberlypowell-1794456712201.webp) <small>www.thedailyjagran.com</small>Kimberly Powell's 18-Year Journey At Nvidia Draws Attention After Personal Links With CEO Jensen ...

THIS IS GETTING CRAZY !! Nvidia $NVDA CEO Jensen Huang Reportedly Had Another Affair With
-----------------------------------------------------------------------------------------

 ![THIS IS GETTING CRAZY !! Nvidia $NVDA CEO Jensen Huang reportedly had another affair with](https://lookaside.fbsbx.com/lookaside/crawler/media/?media_id=100045486611488) <small>www.facebook.com</small>THIS IS GETTING CRAZY !! Nvidia $NVDA CEO Jensen Huang reportedly had another affair with ...

Autopilot On X: "Breaking: Nvidia Is Plummeting After Hours On Reports The CEO Jensen Huang Had
-----------------------------------------------------------------------------------------------

 ![Autopilot on X: "Breaking: Nvidia is plummeting after hours on reports the CEO Jensen Huang had](https://jf.x.com/images/media-preview/2120648537319072226) <small>x.com</small>Autopilot on X: "Breaking: Nvidia is plummeting after hours on reports the CEO Jensen Huang had ...

Who Is Graham Gerade? What To Know About Kimberly Powell's Husband Amid Jensen Huang Controversy
------------------------------------------------------------------------------------------------

 ![Who is Graham Gerade? What to know about Kimberly Powell's husband amid Jensen Huang controversy](https://img.etimg.com/thumb/msid-135757356,width-950,height-600,imgsize-55824,resizemode-75/image-of-kimberly-powell.jpg) <small>economictimes.indiatimes.com</small>Who is Graham Gerade? What to know about Kimberly Powell's husband amid Jensen Huang controversy ...

Kimberly Powell: How Married Nvidia Healthcare VP Rose Through...
-----------------------------------------------------------------

 ![Kimberly Powell: How Married Nvidia Healthcare VP Rose Through...](https://data.ibtimes.sg/en/full/99508/kimberly-powell.jpg?w=736) <small>www.ibtimes.sg</small>Kimberly Powell: How Married Nvidia Healthcare VP Rose Through...

BREAKING: The CEO Of Nvidia Jensen Huang Allegedly Has A Second Affair (Kimberly Powell) On Top
-----------------------------------------------------------------------------------------------

 ![BREAKING: The CEO of Nvidia Jensen Huang allegedly has a second affair (Kimberly Powell) on top](https://lookaside.fbsbx.com/lookaside/crawler/media/?media_id=131954979588881) <small>www.facebook.com</small>BREAKING: The CEO of Nvidia Jensen Huang allegedly has a second affair (Kimberly Powell) on top ...

AlphaGen On X: "JUST IN: Nvidia $NVDA CEO Jensen Huang Had Another Affair With An Nvidia
----------------------------------------------------------------------------------------

 ![AlphaGen on X: "JUST IN: Nvidia $NVDA CEO Jensen Huang had another affair with an Nvidia](https://pbs.twimg.com/media/HW4Gcy7WMAAxuZK?format=webp&name=large) <small>x.com</small>AlphaGen on X: "JUST IN: Nvidia $NVDA CEO Jensen Huang had another affair with an Nvidia ...

Kimberly Powell (Nvidia) Wiki, Age, Husband &amp; Salary
--------------------------------------------------------

 ![Kimberly Powell (Nvidia) Wiki, Age, Husband & Salary](https://wikiofcelebrities.com/wp-content/uploads/2026/11/Kimberly-Powell.webp) <small>wikiofcelebrities.com</small>Kimberly Powell (Nvidia) Wiki, Age, Husband &amp; Salary

Who Is Kimberly Powell? The Name At The Center Of Nvidia's $4 Trillion Key-Man Risk | AInvest
---------------------------------------------------------------------------------------------

 ![Who Is Kimberly Powell? The Name at the Center of Nvidia's $4 Trillion Key-Man Risk | AInvest](https://cdn.ainvest.com/news/visual/visual_components/img_0faa8e08c1556054-244366b9e4ab.png?format=webp) <small>www.ainvest.com</small>Who Is Kimberly Powell? The Name at the Center of Nvidia's $4 Trillion Key-Man Risk | AInvest

Kimberly Powell's Net Worth (2026) &amp; NVIDIA Salary Revealed
---------------------------------------------------------------

 ![Kimberly Powell's Net Worth (2026) & NVIDIA Salary Revealed](https://celebsfortune.com/wp-content/uploads/2026/11/kimberly-powell-picture.jpg) <small>celebsfortune.com</small>Kimberly Powell's Net Worth (2026) &amp; NVIDIA Salary Revealed

Who Is Kimberly Powell? What To Know About The Nvidia Executive – Hollywood Life
--------------------------------------------------------------------------------

 ![Who Is Kimberly Powell? What to Know About the Nvidia Executive – Hollywood Life](https://i0.wp.com/media.hollywoodlife.com/uploads/2026/11/jensen-1920x1920-1-e1794491821965.jpeg?resize=1200%2C675&quality=100&ssl=1) <small>hollywoodlife.com</small>Who Is Kimberly Powell? What to Know About the Nvidia Executive – Hollywood Life

Kimberly Powell's Net Worth (2026) &amp; NVIDIA Salary Revealed
---------------------------------------------------------------

 ![Kimberly Powell's Net Worth (2026) & NVIDIA Salary Revealed](https://celebsfortune.com/wp-content/uploads/2026/11/kimberly-powell-nvidia-salary-and-net-worth-2026.jpg) <small>celebsfortune.com</small>Kimberly Powell's Net Worth (2026) &amp; NVIDIA Salary Revealed

Who Is Kimberly Powell, Nvidia Executive Who Had Affair With CEO Jensen Huang?
------------------------------------------------------------------------------

 ![Who Is Kimberly Powell, Nvidia Executive Who Had Affair With CEO Jensen Huang?](https://c.ndtvimg.com/2026-11/9ks3vb1s_kimberly-powell_625x300_12_November_26.jpeg?downsize=723:486) <small>www.ndtv.com</small>Who Is Kimberly Powell, Nvidia Executive Who Had Affair With CEO Jensen Huang?

Generational Run Coming??? #nvda #stocks #hotchinaspy | Patrick Dalton
----------------------------------------------------------------------

 ![Generational run coming??? #nvda #stocks #hotchinaspy | Patrick Dalton](https://lookaside.fbsbx.com/lookaside/crawler/media/?media_id=122215267718470519) <small>www.facebook.com</small>Generational run coming??? #nvda #stocks #hotchinaspy | Patrick Dalton

Kimberly Powell-Jensen Huang Alleged Affair: What Nvidia's Cod...
-----------------------------------------------------------------

 ![Kimberly Powell-Jensen Huang Alleged Affair: What Nvidia's Cod...](https://data.ibtimes.sg/en/full/99518/kimberly-powell.jpg?w=736) <small>www.ibtimes.sg</small>Kimberly Powell-Jensen Huang Alleged Affair: What Nvidia's Cod...

Kimberly Powell Announced Out As NVIDIA VP Of Healthcare? | Polymarket
----------------------------------------------------------------------

 ![Kimberly Powell Announced Out as NVIDIA VP of Healthcare? | Polymarket](https://polymarket.us/api/og/event/kimpow-nvda-vp.png) <small>polymarket.us</small>Kimberly Powell Announced Out as NVIDIA VP of Healthcare? | Polymarket

Autopilot On X: "Breaking: Nvidia Is Plummeting After Hours On Reports The CEO Jensen Huang Had
-----------------------------------------------------------------------------------------------

 ![Autopilot on X: "Breaking: Nvidia is plummeting after hours on reports the CEO Jensen Huang had](https://pbs.twimg.com/media/HW4OkrdWgAAmCA9?format=webp&name=large) <small>x.com</small>Autopilot on X: "Breaking: Nvidia is plummeting after hours on reports the CEO Jensen Huang had ...

Watch: Jensen Huang’s Reported Extramarital Partner Kimberly Powell Walks The Show Floor In
-------------------------------------------------------------------------------------------

 ![Watch: Jensen Huang’s reported extramarital partner Kimberly Powell walks the show floor in](https://img.etimg.com/thumb/msid-135754452,width-950,height-600,imgsize-130156,resizemode-75/jensen-huangs-former-partner-kimberly-powell-walks-the-show-floor-in-nvidia-videobr.jpg) <small>economictimes.indiatimes.com</small>Watch: Jensen Huang’s reported extramarital partner Kimberly Powell walks the show floor in ...

kimberly powell: how married nvidia healthcare vp rose through.... Autopilot on x: "breaking: nvidia is plummeting after hours on reports the ceo jensen huang had. Who is kimberly powell, the nvidia executive linked to ceo jensen huang?
