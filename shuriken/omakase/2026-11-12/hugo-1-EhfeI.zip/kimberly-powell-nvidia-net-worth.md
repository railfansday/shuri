---
title: "Kimberly Powell Nvidia Net Worth - Gtc 2025 – announcements and live updates"
description: "Nvidia&#039;s web of ai investments"
date: "2026-06-09"
categories:
- "Uncategorized"
images:
- "https://celebsfortune.com/wp-content/uploads/2026/11/kimberly-powell-picture.jpg"
featuredImage: "https://lookaside.fbsbx.com/lookaside/crawler/media/?media_id=5481128138593161"
featured_image: "https://www.marktechpost.com/wp-content/uploads/2022/04/Interview-2.png"
image: "https://www.statnews.com/wp-content/uploads/2024/05/STAT_Breakthrough_SF_10-645x645.jpg"
---

If you are searching about NVIDIA Taiwan - 數位孿生技術的進步正加速推動生命科學的新時代，立即報名 #GTC22 與 NVIDIA 醫療照護與生命科學副總裁 Kimberly Powell 一同探索 you've came to the right page. We have 35 Pictures about NVIDIA Taiwan - 數位孿生技術的進步正加速推動生命科學的新時代，立即報名 #GTC22 與 NVIDIA 醫療照護與生命科學副總裁 Kimberly Powell 一同探索 like Nvidia expands AI ambitions in healthcare; aims to transform hospitals with robotics – Digital, Exclusive Interview with Kimberly Powell, VP and General Manager of NVIDIA Healthcare - MarkTechPost and also Nvidia’s AI healthcare vision spans new drugs, robots, and beyond - Fast Company. Here you go:

NVIDIA Taiwan - 數位孿生技術的進步正加速推動生命科學的新時代，立即報名 #GTC22 與 NVIDIA 醫療照護與生命科學副總裁 Kimberly Powell 一同探索
---------------------------------------------------------------------------------------------

 ![NVIDIA Taiwan - 數位孿生技術的進步正加速推動生命科學的新時代，立即報名 #GTC22 與 NVIDIA 醫療照護與生命科學副總裁 Kimberly Powell 一同探索](https://lookaside.fbsbx.com/lookaside/crawler/media/?media_id=5481128138593161) <small>www.facebook.com</small>NVIDIA Taiwan - 數位孿生技術的進步正加速推動生命科學的新時代，立即報名 #GTC22 與 NVIDIA 醫療照護與生命科學副總裁 Kimberly Powell 一同探索 ...

From The Office To The Lab, Amgen Uses AI Tools To Unlock Innovation | Amgen
----------------------------------------------------------------------------

 ![From the Office to the Lab, Amgen Uses AI Tools to Unlock Innovation | Amgen](https://www.amgen.com/stories/2024/05/-/media/Themes/CorporateAffairs/amgen-com/amgen-com/Images/stories/2024/05-21-From-the-Office-to-the-Lab-Amgen-Uses-AI-Tools-to-Unlock-Innovation/powell.png) <small>www.amgen.com</small>From the Office to the Lab, Amgen Uses AI Tools to Unlock Innovation | Amgen

\[BIO USA 2026\] NVIDIA Pushes Agentic AI Beyond Coding And Into Drug Discovery
-------------------------------------------------------------------------------

 ![[BIO USA 2026] NVIDIA pushes agentic AI beyond coding and into drug discovery](https://cdn.koreabiomed.com/news/photo/202606/32170_34935_1840.jpg) <small>www.koreabiomed.com</small>\[BIO USA 2026\] NVIDIA pushes agentic AI beyond coding and into drug discovery

Hear From Kimberly Powell, Sr. Director Of Deep Learning, On The Highlights Of #CVPR2017
----------------------------------------------------------------------------------------

 ![Hear from Kimberly Powell, Sr. Director of Deep Learning, on the highlights of #CVPR2017](https://lookaside.fbsbx.com/lookaside/crawler/media/?media_id=10155005906623253&get_thumbnail=1) <small>www.facebook.com</small>Hear from Kimberly Powell, Sr. Director of Deep Learning, on the highlights of #CVPR2017 ...

Kimberly Powell's Net Worth (2026) &amp; NVIDIA Salary Revealed
---------------------------------------------------------------

 ![Kimberly Powell's Net Worth (2026) & NVIDIA Salary Revealed](https://celebsfortune.com/wp-content/uploads/2026/11/kimberly-powell-picture.jpg) <small>celebsfortune.com</small>Kimberly Powell's Net Worth (2026) &amp; NVIDIA Salary Revealed

How AI Is Revolutionizing Healthcare With Kimberly Powell Of NVIDIA – Health Podcast Network
--------------------------------------------------------------------------------------------

 ![How AI Is Revolutionizing Healthcare with Kimberly Powell of NVIDIA – Health Podcast Network](https://megaphone.imgix.net/podcasts/25c5f82c-2777-11f0-9b28-f39167168459/image/07e90bf930a6aa2fc971ce0501ed371e.png?ixlib=rails-4.3.1&max-w=3000&max-h=3000&fit=crop&auto=format,compress) <small>healthpodcastnetwork.com</small>How AI Is Revolutionizing Healthcare with Kimberly Powell of NVIDIA – Health Podcast Network

GTC 2025 – Announcements And Live Updates | NVIDIA Blog
-------------------------------------------------------

 ![GTC 2025 – Announcements and Live Updates | NVIDIA Blog](https://blogs.nvidia.com/wp-content/uploads/2025/03/kptalk-1280x960.jpg) <small>blogs.nvidia.com</small>GTC 2025 – Announcements and Live Updates | NVIDIA Blog

Kimberly Powell Author Page | NVIDIA Blog
-----------------------------------------

 ![Kimberly Powell Author Page | NVIDIA Blog](https://blogs.nvidia.com/wp-content/uploads/2025/04/finance-corp-blog-capital-one-podcast-25-1280x680-1.jpg) <small>blogs.nvidia.com</small>Kimberly Powell Author Page | NVIDIA Blog

Dive Into The Future Of Digital Surgery, Health, And Biology With NVIDIA's VP Of Healthcare And
-----------------------------------------------------------------------------------------------

 ![Dive into the future of digital surgery, health, and biology with NVIDIA's VP of Healthcare and](https://media.licdn.com/dms/image/v2/D5610AQEf18m9u13NPw/image-shrink_800/image-shrink_800/0/1718404075786?e=2147483647&v=beta&t=F-wL667A6hY7CE4c0fp8ufvPB6vLFAUNhCatqrC7jY4) <small>www.linkedin.com</small>Dive into the future of digital surgery, health, and biology with NVIDIA's VP of Healthcare and ...

Generative AI Is Revolutionizing Healthcare, From Drug Discovery To Diagnostics And Post-op Care
------------------------------------------------------------------------------------------------

 ![Generative AI is revolutionizing healthcare, from drug discovery to diagnostics and post-op care](https://media.licdn.com/dms/image/v2/D4D22AQHI7fbK1GV1QQ/feedshare-shrink_2048_1536/feedshare-shrink_2048_1536/0/1717762363344?e=2147483647&v=beta&t=HcXrmL3078ePC82LlnhipxGpfpS2lI088q7m0yCHQ0I) <small>pe.linkedin.com</small>Generative AI is revolutionizing healthcare, from drug discovery to diagnostics and post-op care ...

Nvidia Vê ‘possibilidades Infinitas’ Da IA Na Saúde - Brazil Journal
--------------------------------------------------------------------

 ![Nvidia vê ‘possibilidades infinitas’ da IA na saúde - Brazil Journal](https://braziljournal.com/wp-content/uploads/2024/05/kimberly-powell-768x858.jpg) <small>braziljournal.com</small>Nvidia vê ‘possibilidades infinitas’ da IA na saúde - Brazil Journal

NVIDIA Powers Up In Drug Discovery
----------------------------------

 ![NVIDIA Powers Up in Drug Discovery](https://genengnews.com/wp-content/uploads/2020/10/Kimberly-Powell_avatar_1511719112-200x200-1.jpg) <small>www.genengnews.com</small>NVIDIA Powers Up in Drug Discovery

¿Quién Es Kimberly Powell, Vinculado Sentimentalmente Con Jensen Huang, Ex Ceo De Nvidia?
-----------------------------------------------------------------------------------------

 ![¿Quién es Kimberly Powell, vinculado sentimentalmente con Jensen Huang, ex Ceo de Nvidia?](https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA2hiDOd.img?w=768&h=434&m=6&x=442&y=84&s=168&d=168) <small>www.msn.com</small>¿Quién es Kimberly Powell, vinculado sentimentalmente con Jensen Huang, ex Ceo de Nvidia?

Nvidia Earnings On Deck: What Investors Need To Know
----------------------------------------------------

 ![Nvidia earnings on deck: What investors need to know](https://image.cnbcfm.com/api/v1/image/107337337-17005869131700586909-32122973269-1080pnbcnews.jpg?v=1700586913&w=1920&h=1080) <small>www.cnbc.com</small>Nvidia earnings on deck: What investors need to know

NVIDIA: A Nova Fronteira Da Medicina Está Na IA - CM
----------------------------------------------------

 ![NVIDIA: A nova fronteira da Medicina está na IA - CM](https://consumidormoderno.com.br/wp-content/uploads/2025/03/Nvidia_Kimberly-Powell-1024x530.webp) <small>consumidormoderno.com.br</small>NVIDIA: A nova fronteira da Medicina está na IA - CM

Nvidia’s AI Healthcare Vision Spans New Drugs, Robots, And Beyond - Fast Company
--------------------------------------------------------------------------------

 ![Nvidia’s AI healthcare vision spans new drugs, robots, and beyond - Fast Company](https://images.fastcompany.com/image/upload/f_webp,q_auto,c_fit/wp-cms-2/2025/12/p-1-91452480-kimberly-powell-qa.jpg) <small>www.fastcompany.com</small>Nvidia’s AI healthcare vision spans new drugs, robots, and beyond - Fast Company

Kimberly Powell Author Page | NVIDIA Blog
-----------------------------------------

 ![Kimberly Powell Author Page | NVIDIA Blog](https://blogs.nvidia.com/wp-content/uploads/2025/10/keynoterecap-featuredimag-updated-scaled.jpg) <small>blogs.nvidia.com</small>Kimberly Powell Author Page | NVIDIA Blog

Nvidia's Kimberly Powell Is Leading The Chip Giant's Charge Into AI For Health Care - San
-----------------------------------------------------------------------------------------

 ![Nvidia's Kimberly Powell is leading the chip giant's charge into AI for health care - San](https://media.bizj.us/view/img/12968502/kimberlypowell-1*1200xx9428-5303-0-491.jpg) <small>www.bizjournals.com</small>Nvidia's Kimberly Powell is leading the chip giant's charge into AI for health care - San ...

Exclusive Interview With Kimberly Powell, VP And General Manager Of NVIDIA Healthcare - MarkTechPost
----------------------------------------------------------------------------------------------------

 ![Exclusive Interview with Kimberly Powell, VP and General Manager of NVIDIA Healthcare - MarkTechPost](https://www.marktechpost.com/wp-content/uploads/2022/04/Interview-2.png) <small>www.marktechpost.com</small>Exclusive Interview with Kimberly Powell, VP and General Manager of NVIDIA Healthcare - MarkTechPost

STAT Breakthrough Summit West - San Francisco | May 14, 2025
------------------------------------------------------------

 ![STAT Breakthrough Summit West - San Francisco | May 14, 2025](https://www.statnews.com/wp-content/uploads/2024/11/BSW2025_Wordpress_WhyAttendImage.png) <small>www.statnews.com</small>STAT Breakthrough Summit West - San Francisco | May 14, 2025

Nvidia Looks To Genentech For Its Next Leap In AI Drug Discovery
----------------------------------------------------------------

 ![Nvidia Looks to Genentech for Its Next Leap in AI Drug Discovery](https://www.genengnews.com/wp-content/uploads/2023/11/Kimberly-Powell-NVIDIA-CROPPED11111.jpg) <small>www.genengnews.com</small>Nvidia Looks to Genentech for Its Next Leap in AI Drug Discovery

NVIDIA Taiwan - #GTC23 巨人肩膀上眺望 AI 新世界 ∣ Kimberly Powell,... | Facebook
----------------------------------------------------------------------

 ![NVIDIA Taiwan - #GTC23 巨人肩膀上眺望 AI 新世界 ∣ Kimberly Powell,... | Facebook](https://lookaside.fbsbx.com/lookaside/crawler/media/?media_id=6109594919079810) <small>www.facebook.com</small>NVIDIA Taiwan - #GTC23 巨人肩膀上眺望 AI 新世界 ∣ Kimberly Powell,... | Facebook

The Age Of AI In Radiology Is Here – Entelechy Asia
---------------------------------------------------

 ![The age of AI in radiology is here – Entelechy Asia](https://entelechyasia.com/wp-content/uploads/2019/01/kimberly-powell-at-emtech-asia.jpg) <small>entelechyasia.com</small>The age of AI in radiology is here – Entelechy Asia

Nvidia's Web Of AI Investments
------------------------------

 ![Nvidia's web of AI investments](https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA1ZPjFB.img?w=1910&h=1000&m=4&q=67) <small>www.msn.com</small>Nvidia's web of AI investments

Nvidia Becomes World's First $4 Trillion Company
------------------------------------------------

 ![Nvidia becomes world's first $4 trillion company](https://image.cnbcfm.com/api/v1/image/108170023-17521375071752137504-40651628515-1080pnbcnews.jpg?v=1752137506&w=1920&h=1080) <small>www.cnbc.com</small>Nvidia becomes world's first $4 trillion company

Kimberly Powell's Net Worth (2026) &amp; NVIDIA Salary Revealed
---------------------------------------------------------------

 ![Kimberly Powell's Net Worth (2026) & NVIDIA Salary Revealed](https://celebsfortune.com/wp-content/uploads/2026/11/kimberly-powell-nvidia-salary-and-net-worth-2026-1100x619.jpg) <small>celebsfortune.com</small>Kimberly Powell's Net Worth (2026) &amp; NVIDIA Salary Revealed

Kim Powell Bio, Age, Family, 3TV, Husband, Height, Salary, Net Worth
--------------------------------------------------------------------

 ![Kim Powell Bio, Age, Family, 3TV, Husband, Height, Salary, Net Worth](https://oneworldinformation.com/wp-content/uploads/2022/05/Kim-Powell-2-400x381.jpg) <small>oneworldinformation.com</small>Kim Powell Bio, Age, Family, 3TV, Husband, Height, Salary, Net Worth

AI助攻，智慧医疗飞速发展-电子工程专辑
--------------------

 ![AI助攻，智慧医疗飞速发展-电子工程专辑](https://www.eet-china.com/d/file/news/2019-03-12/38a3f53d426b61869c770535f78399b1.jpg) <small>www.eet-china.com</small>AI助攻，智慧医疗飞速发展-电子工程专辑

NVIDIA Released Its Highly Anticipated Earnings Report On Wednesday After The Bell. Nvidia CFO
----------------------------------------------------------------------------------------------

 ![NVIDIA released its highly anticipated earnings report on Wednesday after the bell. Nvidia CFO](https://media.licdn.com/dms/image/v2/D4E10AQGp5Y9JcJQa7A/image-shrink_1280/image-shrink_1280/0/1724969584916?e=2147483647&v=beta&t=YG7yE_u3yBReverTOBciMN-S0cNv63MfVUaqsB_hx1o) <small>www.linkedin.com</small>NVIDIA released its highly anticipated earnings report on Wednesday after the bell. Nvidia CFO ...

AIで医療分野にイノベーションを起こすNVIDIA - PC Watch
------------------------------------

 ![AIで医療分野にイノベーションを起こすNVIDIA - PC Watch](https://asset.watch.impress.co.jp/img/pcw/docs/1120/878/DSCF5066_l.jpg) <small>pc.watch.impress.co.jp</small>AIで医療分野にイノベーションを起こすNVIDIA - PC Watch

Nvidia Expands AI Ambitions In Healthcare; Aims To Transform Hospitals With Robotics – Digital
----------------------------------------------------------------------------------------------

 ![Nvidia expands AI ambitions in healthcare; aims to transform hospitals with robotics – Digital](https://digitaleconomymag.com/wp-content/uploads/2024/11/Nvidia-Kimberly-Powel.png) <small>digitaleconomymag.com</small>Nvidia expands AI ambitions in healthcare; aims to transform hospitals with robotics – Digital ...

Kimberly Powell Special Address - Healthcare At GTC | Channah Blocq
-------------------------------------------------------------------

 ![Kimberly Powell Special Address - Healthcare at GTC | Channah Blocq](https://media.licdn.com/dms/image/v2/D4E10AQEoQkQL3_Sr8w/image-shrink_1280/image-shrink_1280/0/1707382180957?e=2147483647&v=beta&t=0dqql3MYC7lUbb88BTFqqiIbvIz3Tb1NcqvpEZkm5PY) <small>www.linkedin.com</small>Kimberly Powell Special Address - Healthcare at GTC | Channah Blocq

Gã Khổng Lồ Chip Nvidia Muốn đưa Robot Vào Bệnh Viện
----------------------------------------------------

 ![Gã khổng lồ chip Nvidia muốn đưa robot vào bệnh viện](https://cdn.viettimes.vn/images/8f57e31090c6e6a8f88d6b852c8b04f7a25b1ddb130825a39014f2aff0bb05d04f8625b90ec47b629bfa78f09131e6273d4400072ae07d057e6862055a1c045b/capture-8699.png.webp) <small>viettimes.vn</small>Gã khổng lồ chip Nvidia muốn đưa robot vào bệnh viện

NVIDIA And Google Execs On The Future Of AI And Drug Discovery
--------------------------------------------------------------

 ![NVIDIA and Google execs on the future of AI and drug discovery](https://www.statnews.com/wp-content/uploads/2024/05/STAT_Breakthrough_SF_10-645x645.jpg) <small>www.statnews.com</small>NVIDIA and Google execs on the future of AI and drug discovery

An Interview With Kimberley Powell (NVIDIA) At The AI Summit, San Francisco (2016). - YouTube
---------------------------------------------------------------------------------------------

 ![An Interview with Kimberley Powell (NVIDIA) at The AI Summit, San Francisco (2016). - YouTube](https://i.ytimg.com/vi/15s952bcezM/maxresdefault.jpg) <small>www.youtube.com</small>An Interview with Kimberley Powell (NVIDIA) at The AI Summit, San Francisco (2016). - YouTube

nvidia powers up in drug discovery. Generative ai is revolutionizing healthcare, from drug discovery to diagnostics and post-op care. nvidia's web of ai investments
