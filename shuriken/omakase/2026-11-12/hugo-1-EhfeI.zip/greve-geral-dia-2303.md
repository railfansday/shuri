---
title: "Greve Geral Dia 23/03 - Fenprof emite pré-aviso de greve para 27 de outubro de 2023 e junta-se ao protesto dos ..."
description: "Metro do porto &quot;fortemente condicionado&quot; no dia da greve geral"
date: "2026-02-02"
categories:
- "Uncategorized"
images:
- "https://fne.pt/uploads/rte/cartaz_greve_manif_2e3marco2023.jpeg"
featuredImage: "https://veja.abril.com.br/wp-content/uploads/2017/03/greve-metroviarios-02.jpg"
featured_image: "https://veja.abril.com.br/wp-content/uploads/2017/03/greve-metroviarios-02.jpg"
image: "https://www.acoliveira.pt/wp-content/uploads/2026/03/ChatGPT-Image-20_03_2026-16_59_29.png"
---

If you are searching about Agora é GREVE GERAL! you've came to the right page. We have 35 Pics about Agora é GREVE GERAL! like Chegou a hora: vamos construir a Greve Geral a partir de 23 de março! - Fenasps, Funcionalismo Público Federal prepara greve para o dia 23 de março | APUBH and also Pré-avisos de Greves de 2 e 3 de março 2023. Here it is:

Agora é GREVE GERAL!
--------------------

 ![Agora é GREVE GERAL!](https://jundiagora.com.br/wp-content/uploads/2023/01/greve-geral.jpg) <small>jundiagora.com.br</small>Agora é GREVE GERAL!

Pré-aviso De Greve Dia 23 De Março De 2026 – AE Terras Do Ave
-------------------------------------------------------------

 ![Pré-aviso de greve dia 23 de março de 2026 – AE Terras do Ave](https://aeterrasave.net/wp-content/uploads/2026/03/Pre-avisoGreve23-03-2026-1024x591.jpg) <small>aeterrasave.net</small>Pré-aviso de greve dia 23 de março de 2026 – AE Terras do Ave

Greve Geral. Metro De Lisboa Prevê Paralisação Do Serviço E Encerramento Das Estações – ECO
-------------------------------------------------------------------------------------------

 ![Greve Geral. Metro de Lisboa prevê paralisação do serviço e encerramento das estações – ECO](https://eco.imgix.net/uploads/2025/12/thumb-1.jpg) <small>eco.sapo.pt</small>Greve Geral. Metro de Lisboa prevê paralisação do serviço e encerramento das estações – ECO

Aviso – AE António Correia De Oliveira
--------------------------------------

 ![Aviso – AE António Correia de Oliveira](https://www.acoliveira.pt/wp-content/uploads/2026/03/ChatGPT-Image-20_03_2026-16_59_29.png) <small>www.acoliveira.pt</small>Aviso – AE António Correia de Oliveira

Dia 16/03 é Dia De Paralisação Das Atividades - Greve Geral De 24h! - ASAV Sindicato
------------------------------------------------------------------------------------

 ![Dia 16/03 é dia de paralisação das atividades - Greve Geral de 24h! - ASAV Sindicato](https://asavufv.org.br/wp-content/uploads/2023/03/65672688a4f4c8a57ea38e20056bdce1.jpg) <small>asavufv.org.br</small>Dia 16/03 é dia de paralisação das atividades - Greve Geral de 24h! - ASAV Sindicato

Metrô Voltou A Funcionar? Saiba Como Está Greve Hoje - 23/03/2023 - BOL BOL
---------------------------------------------------------------------------

 ![Metrô voltou a funcionar? Saiba como está greve hoje - 23/03/2023 - BOL BOL](https://conteudo.imguol.com.br/c/noticias/72/2023/03/23/23mar2023---movimento-intenso-de-passageiros-na-estacao-itaquera-do-metro-na-zona-leste-por-causa-da-greve-dos-metroviarios-1679568422900_v2_900x506.jpg) <small>www.bol.uol.com.br</small>Metrô voltou a funcionar? Saiba como está greve hoje - 23/03/2023 - BOL BOL

Servidor Faz Greve Geral Contra RRF E Congelamento De Reajuste
--------------------------------------------------------------

 ![Servidor faz greve geral contra RRF e congelamento de reajuste](https://alemdofato.uai.com.br/wp-content/uploads/sites/5/2023/11/greve-geral-servidor-nov-23a-scaled.jpg) <small>alemdofato.uai.com.br</small>Servidor faz greve geral contra RRF e congelamento de reajuste

Greve Geral Juntou Centenas Nos Aliados. Governo Fala Em Adesão "inexpressiva" - JPN
------------------------------------------------------------------------------------

 ![Greve Geral juntou centenas nos Aliados. Governo fala em adesão "inexpressiva" - JPN](https://www.jpn.up.pt/wp-content/uploads/2025/12/greve_geral8.jpg) <small>www.jpn.up.pt</small>Greve Geral juntou centenas nos Aliados. Governo fala em adesão "inexpressiva" - JPN

Greve Geral Juntou Centenas Nos Aliados. Governo Fala Em Adesão "inexpressiva" - JPN
------------------------------------------------------------------------------------

 ![Greve Geral juntou centenas nos Aliados. Governo fala em adesão "inexpressiva" - JPN](https://www.jpn.up.pt/wp-content/uploads/2025/12/greve_geral9.jpg) <small>www.jpn.up.pt</small>Greve Geral juntou centenas nos Aliados. Governo fala em adesão "inexpressiva" - JPN

Greve Dia 23/03/2026 – Atualização - Agrupamento De Escolas Da Lousã
--------------------------------------------------------------------

 ![Greve dia 23/03/2026 – atualização - Agrupamento de Escolas da Lousã](https://escolas.aglousa.com/wp-content/uploads/2019/06/greve.png) <small>escolas.aglousa.com</small>Greve dia 23/03/2026 – atualização - Agrupamento de Escolas da Lousã

22/03 - Rumo à Greve Geral - Sinthoress
---------------------------------------

 ![22/03 - Rumo à Greve Geral - Sinthoress](https://sinthoress.org.br/wp-content/uploads/2019/03/greve.jpg) <small>sinthoress.org.br</small>22/03 - Rumo à Greve Geral - Sinthoress

Funcionalismo Público Federal Prepara Greve Para O Dia 23 De Março | APUBH
--------------------------------------------------------------------------

 ![Funcionalismo Público Federal prepara greve para o dia 23 de março | APUBH](https://apubh.org.br/wp-content/uploads/2022/02/card_redes-1.png) <small>apubh.org.br</small>Funcionalismo Público Federal prepara greve para o dia 23 de março | APUBH

FAQ: Os Direitos Dos Docentes Em Dia De Greve Geral - 11/12/2025
----------------------------------------------------------------

 ![FAQ: Os direitos dos docentes em dia de Greve Geral - 11/12/2025](https://static.wixstatic.com/media/d0f32c_9ff1199ee2c34418af0094a43c516733~mv2.png/v1/fill/w_940,h_788,al_c,q_90,enc_avif,quality_auto/d0f32c_9ff1199ee2c34418af0094a43c516733~mv2.png) <small>www.sprc.pt</small>FAQ: Os direitos dos docentes em dia de Greve Geral - 11/12/2025

É Dia De Greve Geral: Saúde, Educação E Transportes Afetados | A Bola
---------------------------------------------------------------------

 ![É dia de greve geral: saúde, educação e transportes afetados | A Bola](https://sportal365images.com/process/smp-images-production/abola.pt/05122025/ae92708d-0084-4837-92a4-9c4db8b926e7.jpg?operations=scale(860:574)) <small>www.abola.pt</small>É dia de greve geral: saúde, educação e transportes afetados | A Bola

Pré-avisos De Greves De 2 E 3 De Março 2023
-------------------------------------------

 ![Pré-avisos de Greves de 2 e 3 de março 2023](https://fne.pt/uploads/rte/cartaz_greve_manif_2e3marco2023.jpeg) <small>fne.pt</small>Pré-avisos de Greves de 2 e 3 de março 2023

3 JUNHO | GREVE GERAL CONTRA O PACOTE LABORAL - Sindicato Dos Trabalhadores Do Comércio
---------------------------------------------------------------------------------------

 ![3 JUNHO | GREVE GERAL CONTRA O PACOTE LABORAL - Sindicato dos Trabalhadores do Comércio](https://image.jimcdn.com/app/cms/image/transf/dimension=4000x3000:format=jpg/path/s3820655f8d987127/image/i4ba186dc42d4f07e/version/1778075119/3-junho-greve-geral-contra-o-pacote-laboral.jpg) <small>www.cesp.pt</small>3 JUNHO | GREVE GERAL CONTRA O PACOTE LABORAL - Sindicato dos Trabalhadores do Comércio ...

2023 – Metroviários
-------------------

 ![2023 – Metroviários](https://www.metroviarios.org.br/site/wp-content/uploads/2023/03/Slider_dia140323.png) <small>www.metroviarios.org.br</small>2023 – Metroviários

Greve Geral No Brasil 2023
--------------------------

 ![Greve Geral no Brasil 2023](https://bacana.news/wp-content/uploads/2025/10/greve-geral-7.jpeg) <small>bacana.news</small>Greve Geral no Brasil 2023

Greve Geral: Escolas Fechadas, Transportes Parados E Impacto Nacional
---------------------------------------------------------------------

 ![Greve Geral: Escolas Fechadas, Transportes Parados e Impacto Nacional](https://media.assettype.com/dn/2025-12-11/s9kf1m1u/greve-geral.jpeg?w=1200&auto=format%2Ccompress) <small>www.dn.pt</small>Greve Geral: Escolas Fechadas, Transportes Parados e Impacto Nacional

Metro Do Porto "fortemente Condicionado" No Dia Da Greve Geral - JPN
--------------------------------------------------------------------

 ![Metro do Porto "fortemente condicionado" no dia da greve geral - JPN](https://www.jpn.up.pt/wp-content/uploads/2025/12/greve_geral1-1152x759.jpg) <small>www.jpn.up.pt</small>Metro do Porto "fortemente condicionado" no dia da greve geral - JPN

Agenda De Greve | 23 A 30/3
---------------------------

 ![Agenda de greve | 23 a 30/3](https://static.wixstatic.com/media/427e8e_a1c64498a00b4f2499af9b089307e769~mv2.png/v1/fill/w_1000,h_500,al_c,q_90,usm_0.66_1.00_0.01/427e8e_a1c64498a00b4f2499af9b089307e769~mv2.png) <small>www.sintetufu.org</small>Agenda de greve | 23 a 30/3

FENPROF Emite Pré-aviso De Greve Para 27 De Outubro De 2023 E Junta-se Ao Protesto Dos
--------------------------------------------------------------------------------------

 ![FENPROF emite pré-aviso de greve para 27 de outubro de 2023 e junta-se ao protesto dos](https://www.spra.pt/wp-content/uploads/2023/10/cartaz-greve-fc-27-outubro-net-1-704x1024.jpg) <small>www.spra.pt</small>FENPROF emite pré-aviso de greve para 27 de outubro de 2023 e junta-se ao protesto dos ...

Greve Geral é Para Todos Os Trabalhadores! – Escola Portuguesa
--------------------------------------------------------------

 ![Greve Geral é para todos os trabalhadores! – Escola Portuguesa](https://escolapt.wordpress.com/wp-content/uploads/2026/05/706357188_18081656384561625_6623516586727525352_n.jpg) <small>escolapt.wordpress.com</small>Greve Geral é para todos os trabalhadores! – Escola Portuguesa

Pré-avisos De Greve Em 2023 Dispararam No Estado E No Privado Até Novembro — DNOTICIAS.PT
-----------------------------------------------------------------------------------------

 ![Pré-avisos de greve em 2023 dispararam no Estado e no privado até Novembro — DNOTICIAS.PT](https://static-storage.dnoticias.pt/www-assets.dnoticias.pt/images/configuration/fb-9/logo48222299_GI30112023LeoneldeCastro003.JPEG) <small>www.dnoticias.pt</small>Pré-avisos de greve em 2023 dispararam no Estado e no privado até Novembro — DNOTICIAS.PT

Eurodreams De 17 De Novembro De 2025
------------------------------------

 ![Eurodreams de 17 de novembro de 2025](https://jornaldemafra.pt/wp-content/uploads/2025/12/greve-geral.webp) <small>jornaldemafra.pt</small>Eurodreams de 17 de novembro de 2025

Hoje é Dia De Greve Geral | Rádio Alto Minho
--------------------------------------------

 ![Hoje é dia de greve geral | Rádio Alto Minho](https://radioaltominho.pt/wp-content/uploads/2026/06/greve-1.jpg) <small>radioaltominho.pt</small>Hoje é dia de greve geral | Rádio Alto Minho

Pré-Aviso De Greve – 17 De Abril De 2026 – AE António Correia De Oliveira
-------------------------------------------------------------------------

 ![Pré-Aviso de Greve – 17 de abril de 2026 – AE António Correia de Oliveira](https://www.acoliveira.pt/wp-content/uploads/2026/04/7e9f6ec4-4873-4685-897b-30c62aab02d6.png) <small>www.acoliveira.pt</small>Pré-Aviso de Greve – 17 de abril de 2026 – AE António Correia de Oliveira

Chegou A Hora: Vamos Construir A Greve Geral A Partir De 23 De Março! - Fenasps
-------------------------------------------------------------------------------

 ![Chegou a hora: vamos construir a Greve Geral a partir de 23 de março! - Fenasps](https://fenasps.org.br/wp-content/uploads/2022/03/vamos.construir.greve_.23mar_18.03.22.jpg) <small>fenasps.org.br</small>Chegou a hora: vamos construir a Greve Geral a partir de 23 de março! - Fenasps

DIA 14 DE JUNHO: ORIENTAÇÕES PARA ATUAÇÃO NA GREVE GERAL – SindJustiça Ceará
----------------------------------------------------------------------------

 ![DIA 14 DE JUNHO: ORIENTAÇÕES PARA ATUAÇÃO NA GREVE GERAL – SindJustiça Ceará](https://sindjusticaceara.org.br/wp-content/uploads/2019/06/CARTAZ-GREVE-GERAL.jpg) <small>sindjusticaceara.org.br</small>DIA 14 DE JUNHO: ORIENTAÇÕES PARA ATUAÇÃO NA GREVE GERAL – SindJustiça Ceará

Greve Geral Em Lisboa A 3 De Junho: O Que Pára Na Cidade
--------------------------------------------------------

 ![Greve geral em Lisboa a 3 de Junho: o que pára na cidade](https://media.timeout.com/images/106411166/image.jpg) <small>www.timeout.pt</small>Greve geral em Lisboa a 3 de Junho: o que pára na cidade

Hoje é Dia De Greve Geral
-------------------------

 ![Hoje é dia de greve geral](https://media.ominho.pt/wp-content/uploads/2025/12/greve-geral-viana-do-castelo-min-1160x630.jpg) <small>ominho.pt</small>Hoje é dia de greve geral

Greve Do Metrô: Preços De Apps Irritam Usuários Em SP - 23/03/2023 - Cotidiano - Folha
--------------------------------------------------------------------------------------

 ![Greve do metrô: Preços de apps irritam usuários em SP - 23/03/2023 - Cotidiano - Folha](https://f.i.uol.com.br/fotografia/2023/03/23/1679575444641c499486ea6_1679575444_3x2_xl.jpg) <small>www1.folha.uol.com.br</small>Greve do metrô: Preços de apps irritam usuários em SP - 23/03/2023 - Cotidiano - Folha

Greve Geral Paralisa Portugal Contra Precarização De Direitos
-------------------------------------------------------------

 ![Greve geral paralisa Portugal contra precarização de direitos](https://pcdob.org.br/wp-content/uploads/2025/12/Ruas-de-Lisboa-foram-tomadas-por-trabalhadores-durante-a-greve-geral-Rafael-Medeiros-Esquerda.jpg) <small>pcdob.org.br</small>Greve geral paralisa Portugal contra precarização de direitos

Diário Da Greve Geral - CGTP-IN
-------------------------------

 ![Diário da Greve Geral - CGTP-IN](https://www.cgtp.pt/images/images/2025/12/diario_gg/diario-banner.jpg) <small>www.cgtp.pt</small>Diário da Greve Geral - CGTP-IN

Greve Geral: Entenda Os Seus Direitos E Deveres | VEJA
------------------------------------------------------

 ![Greve geral: Entenda os seus direitos e deveres | VEJA](https://veja.abril.com.br/wp-content/uploads/2017/03/greve-metroviarios-02.jpg) <small>veja.abril.com.br</small>Greve geral: Entenda os seus direitos e deveres | VEJA

Pré-aviso de greve dia 23 de março de 2026 – ae terras do ave. Dia 14 de junho: orientações para atuação na greve geral – sindjustiça ceará. Faq: os direitos dos docentes em dia de greve geral
