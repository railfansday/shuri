---
title: "Vitinha Injury - Psg : vitinha sort sur blessure contre l’ol"
description: "Psg : premières nouvelles rassurantes pour vitinha, sorti sur blessure face à nantes"
date: "2026-10-19"
categories:
- "Uncategorized"
images:
- "https://www.leparisien.fr/resizer/j7RAZ3hGdFvP7GkZ4aL4tuAKQFw=/1200x675/cloudfront-eu-central-1.images.arcpublishing.com/leparisien/3KU3JMXRXBBILFFLJ6EMNZX5SQ.jpg"
featuredImage: "https://pictures.tribuna.com/image/3ca2b375-cca9-43fa-ad9f-2f23ae5bf798?width=1920&amp;quality=70"
featured_image: "https://media.gettyimages.com/id/2272112081/photo/paris-saint-germain-v-olympique-lyonnais-ligue-1-mcdonalds.jpg?s=594x594&amp;w=0&amp;k=20&amp;c=1S-pT4PcDyVgo2Y9hWmvzU1sSCgD0qeVX4-E3QDsnq8="
image: "https://assets-fr.imgfoot.com/media/cache/1200x675/vitinha-697a82b495714.jpg"
---

If you are searching about PSG midfielder Vitinha taken off with possible injury ahead of Barcelona clash - Football you've visit to the right web. We have 35 Images about PSG midfielder Vitinha taken off with possible injury ahead of Barcelona clash - Football like Vitinha of Paris Saint-Germain goes down with injury during the UEFA Champions League Last 16, Vitinha of Paris Saint-Germain receives treatment to a head injury. UEFA Champions League ,round and also ¡Vitinha, lesionado!. Here you go:

PSG Midfielder Vitinha Taken Off With Possible Injury Ahead Of Barcelona Clash - Football
-----------------------------------------------------------------------------------------

 ![PSG midfielder Vitinha taken off with possible injury ahead of Barcelona clash - Football](https://pictures.tribuna.com/image/877391fb-e0fa-4980-916d-2870d9d284e8?width=1920&quality=70) <small>tribuna.com</small>PSG midfielder Vitinha taken off with possible injury ahead of Barcelona clash - Football ...

PSG &amp; Bayern Hit By Injuries Before UCL Semi-Final
------------------------------------------------------

 ![PSG & Bayern Hit by Injuries Before UCL Semi-Final](https://www.ufootball.com.my/wp-content/uploads/2026/04/UFOOTBALL_PSG-confirms-Vitinha-injury-1.png) <small>www.ufootball.com.my</small>PSG &amp; Bayern Hit by Injuries Before UCL Semi-Final

Exact Moment Vitinha Picks Up Injury Vs Lyon Caught On Camera — Tribuna.com
---------------------------------------------------------------------------

 ![Exact moment Vitinha picks up injury vs Lyon caught on camera — Tribuna.com](https://pictures.tribuna.com/image/0234be2c-cdc1-4363-839c-99670c9a93f3?width=1920&quality=70) <small>tribuna.com</small>Exact moment Vitinha picks up injury vs Lyon caught on camera — Tribuna.com

29,506 Forehead Stock Photos, High-Res Pictures, And Images - Getty Images
--------------------------------------------------------------------------

 ![29,506 Forehead Stock Photos, High-Res Pictures, and Images - Getty Images](https://media.gettyimages.com/id/2203998595/photo/paris-saint-germains-portuguese-midfielder-vitinha-reacts-following-an-injury-on-his-forehead.jpg?s=612x612&w=gi&k=20&c=JsX0RrocuIMdsG7yk94n97mLDd5EmeM8mI2woFrjNAA=) <small>www.gettyimages.co.uk</small>29,506 Forehead Stock Photos, High-Res Pictures, and Images - Getty Images

Onefootball - 🚨 Vitinha Was Subbed Off Due To An Injury In... | Facebook
------------------------------------------------------------------------

 ![Onefootball - 🚨 Vitinha was subbed off due to an injury in... | Facebook](https://lookaside.fbsbx.com/lookaside/crawler/media/?media_id=1363246045165731) <small>www.facebook.com</small>Onefootball - 🚨 Vitinha was subbed off due to an injury in... | Facebook

Vitinha, The Official Verdict Has Fallen
----------------------------------------

 ![Vitinha, the official verdict has fallen](https://frenchfootballweekly.com/wp-content/uploads/2026/04/Vitinha-the-official-verdict-has-fallen.jpg) <small>frenchfootballweekly.com</small>Vitinha, the official verdict has fallen

Um Mal Não Veio Só: Além Da Derrota Contra O Lyon De Paulo Fonseca, O PSG Perdeu Vitinha Para
---------------------------------------------------------------------------------------------

 ![Um mal não veio só: além da derrota contra o Lyon de Paulo Fonseca, o PSG perdeu Vitinha para](https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA21idJX.img?w=768&h=518&m=6&x=961&y=60&s=61&d=61) <small>www.msn.com</small>Um mal não veio só: além da derrota contra o Lyon de Paulo Fonseca, o PSG perdeu Vitinha para ...

¡Vitinha, Lesionado!
--------------------

 ![¡Vitinha, lesionado!](https://imagenes2.mundodeportivo.com/files/image_449_221/files/fp/uploads/2026/04/20/69e557f27772f.r_d.320-214-7016.jpeg) <small>www.mundodeportivo.com</small>¡Vitinha, lesionado!

PSG's Vitinha To Undergo MRI On Ankle Injury - Get French Football News
-----------------------------------------------------------------------

 ![PSG's Vitinha to undergo MRI on ankle injury - Get French Football News](https://www.getfootballnewsfrance.com/assets/paris-saint-germain-fc-v-liverpool-fc-uefa-champions-league-2025-26-quarter-final-first-leg-3-1-scaled.jpg) <small>www.getfootballnewsfrance.com</small>PSG's Vitinha to undergo MRI on ankle injury - Get French Football News

PSG: La Blessure De Vitihna, Le Bayern N'y Croit Pas
----------------------------------------------------

 ![PSG: La Blessure de Vitihna, le Bayern n'y croit pas](https://www.les-transferts.com/wp-content/uploads/2026/04/Vitinha.webp) <small>www.les-transferts.com</small>PSG: La Blessure de Vitihna, le Bayern n'y croit pas

29,506 Forehead Stock Photos, High-Res Pictures, And Images - Getty Images
--------------------------------------------------------------------------

 ![29,506 Forehead Stock Photos, High-Res Pictures, and Images - Getty Images](https://media.gettyimages.com/id/2203998738/photo/paris-saint-germains-portuguese-midfielder-vitinha-reacts-following-an-injury-on-his-forehead.jpg?s=612x612&w=gi&k=20&c=59fnzNwONyVq1YkwHd-VPYBzDAZLxyf-YccaIpfP1To=) <small>www.gettyimages.co.uk</small>29,506 Forehead Stock Photos, High-Res Pictures, and Images - Getty Images

Comment Le PSG Pourrait Se Présenter En Cas De Blessure De Vitinha? Une Compo Proposée
--------------------------------------------------------------------------------------

 ![Comment le PSG pourrait se présenter en cas de blessure de Vitinha? Une compo proposée](https://pictures.tribuna.com/image/7aa28a4b-89a8-4da5-ae62-5374d23f567a?width=1920&quality=70) <small>tribuna.com</small>Comment le PSG pourrait se présenter en cas de blessure de Vitinha? Une compo proposée ...

Injury Setback For PSG As Vitinha Awaits MRI Scan Ahead Of Champions League Semi-Final
--------------------------------------------------------------------------------------

 ![Injury Setback for PSG as Vitinha Awaits MRI Scan Ahead of Champions League Semi-Final](https://www.sportingpedia.com/wp-content/uploads/2025/11/Vitinha1.jpg) <small>www.sportingpedia.com</small>Injury Setback for PSG as Vitinha Awaits MRI Scan Ahead of Champions League Semi-Final ...

Vitinha Of Paris Saint-Germain Goes Down With Injury During The UEFA Champions League Last 16
---------------------------------------------------------------------------------------------

 ![Vitinha of Paris Saint-Germain goes down with injury during the UEFA Champions League Last 16](https://l450v.alamy.com/450v/3a24bw0/vitinha-of-paris-saint-germain-goes-down-with-injury-during-the-uefa-champions-league-last-16-match-liverpool-vs-paris-saint-germain-at-anfield-liverpool-united-kingdom-11th-march-2025-photo-by-mark-cosgrovenews-images-3a24bw0.jpg) <small>www.alamy.com</small>Vitinha of Paris Saint-Germain goes down with injury during the UEFA Champions League Last 16 ...

Portugal Midfielder Vitinha Out For PSG After Right Heel Injury | AP News
-------------------------------------------------------------------------

 ![Portugal midfielder Vitinha out for PSG after right heel injury | AP News](https://dims.apnews.com/dims4/default/2766190/2147483647/strip/true/crop/3684x2455+0+1/resize/980x653!/quality/90/?url=https:%2F%2Fassets.apnews.com%2F50%2Fa0%2F11917222eb85fef5f5fe28bce6f7%2Fabcf917afbc24f65aa4be0beaf5453b1) <small>apnews.com</small>Portugal midfielder Vitinha out for PSG after right heel injury | AP News

Alarma En El PSG: Vitinha En Duda Para El Tramo Decisivo | BeIN SPORTS
----------------------------------------------------------------------

 ![Alarma en el PSG: Vitinha en duda para el tramo decisivo | beIN SPORTS](https://prod-media.beinsports.com/image/1776692063521_75139a23-a772-4aa5-bc15-9e7a930c7254.1080.png) <small>www.beinsports.com</small>Alarma en el PSG: Vitinha en duda para el tramo decisivo | beIN SPORTS

PSG : Vitinha Sort Sur Blessure Contre L’OL
-------------------------------------------

 ![PSG : Vitinha sort sur blessure contre l’OL](https://assets-fr.imgfoot.com/media/cache/1200x675/vitinha-697a82b495714.jpg) <small>www.footmercato.net</small>PSG : Vitinha sort sur blessure contre l’OL

Vitinha Of Paris Saint-Germain Reacts After His Injury With Head... News Photo - Getty Images
---------------------------------------------------------------------------------------------

 ![Vitinha of Paris Saint-Germain reacts after his injury with head... News Photo - Getty Images](https://media.gettyimages.com/id/2272112081/photo/paris-saint-germain-v-olympique-lyonnais-ligue-1-mcdonalds.jpg?s=594x594&w=0&k=20&c=1S-pT4PcDyVgo2Y9hWmvzU1sSCgD0qeVX4-E3QDsnq8=) <small>www.gettyimages.com</small>Vitinha of Paris Saint-Germain reacts after his injury with head... News Photo - Getty Images

PSG : Premières Nouvelles Rassurantes Pour Vitinha, Sorti Sur Blessure Face à Nantes
------------------------------------------------------------------------------------

 ![PSG : premières nouvelles rassurantes pour Vitinha, sorti sur blessure face à Nantes](https://static.onzemondial.com/8/2022/09/photo_article/794850/314901/1200-L-psg-premires-nouvelles-rassurantes-pour-vitinha-sorti-sur-blessure-face-nantes.jpg) <small>www.onzemondial.com</small>PSG : premières nouvelles rassurantes pour Vitinha, sorti sur blessure face à Nantes

PSG &amp; Bayern Hit By Injuries Before UCL Semi-Final
------------------------------------------------------

 ![PSG & Bayern Hit by Injuries Before UCL Semi-Final](https://www.ufootball.com.my/wp-content/uploads/2026/04/UFOOTBALL_Vitinha-add-to-PSG-injury-crisis-1-1024x576.jpg) <small>www.ufootball.com.my</small>PSG &amp; Bayern Hit by Injuries Before UCL Semi-Final

Paris Saint-Germain Hit With Major Setback After Vitinha Injury
---------------------------------------------------------------

 ![Paris Saint-Germain hit with major setback after Vitinha injury](https://imagenes2.mundodeportivo.com/uploads/2026/03/11/69b1e5f401a2e.jpeg) <small>www.mundodeportivo.com</small>Paris Saint-Germain hit with major setback after Vitinha injury

PSG Face Serious Injury Concerns Ahead Of Champions League Clash Against Arsenal - Now.arsenal
----------------------------------------------------------------------------------------------

 ![PSG face serious injury concerns ahead of Champions League clash against Arsenal - now.arsenal](https://www.nowarsenal.com/wp-content/uploads/2024/09/Vitinha.webp) <small>www.nowarsenal.com</small>PSG face serious injury concerns ahead of Champions League clash against Arsenal - now.arsenal

PSG &amp; Bayern Hit By Injuries Before UCL Semi-Final
------------------------------------------------------

 ![PSG & Bayern Hit by Injuries Before UCL Semi-Final](https://www.ufootball.com.my/wp-content/uploads/2026/04/UFOOTBALL_Vitinha-heel-injury-1-1024x683.jpg) <small>www.ufootball.com.my</small>PSG &amp; Bayern Hit by Injuries Before UCL Semi-Final

Vitinha Of Paris Saint-Germain Receives Treatment To A Head Injury. UEFA Champions League ,round
------------------------------------------------------------------------------------------------

 ![Vitinha of Paris Saint-Germain receives treatment to a head injury. UEFA Champions League ,round](https://c8.alamy.com/comp/3A25176/vitinha-of-paris-saint-germain-receives-treatment-to-a-head-injury-uefa-champions-league-round-of-16-2nd-leg-liverpool-v-psg-at-anfield-in-liverpool-on-tuesday-11th-march-2025-this-image-may-only-be-used-for-editorial-purposes-editorial-use-onlypic-by-chris-stadingandrew-orchard-sports-photographyalamy-live-news-3A25176.jpg) <small>www.alamy.com</small>Vitinha of Paris Saint-Germain receives treatment to a head injury. UEFA Champions League ,round ...

PSG En Vilo Por Lesión De Vitinha Al Final De La Campaña
--------------------------------------------------------

 ![PSG en vilo por lesión de Vitinha al final de la campaña](https://lagazzettadf.com/wp-content/uploads/2026/04/PSG-lesion-Vitinha-1.jpg) <small>lagazzettadf.com</small>PSG en vilo por lesión de Vitinha al final de la campaña

The Next Galactico? Real Madrid Begin Pursuit Of PSG's Vitinha In Bid To Bring Balance Back To
----------------------------------------------------------------------------------------------

 ![The next Galactico? Real Madrid begin pursuit of PSG's Vitinha in bid to bring balance back to](https://assets.goal.com/images/v3/blt4840a76194cf2250/Vitinha.jpeg?auto=webp&format=pjpg&width=3840&quality=60) <small>www.goal.com</small>The next Galactico? Real Madrid begin pursuit of PSG's Vitinha in bid to bring balance back to ...

PSG : Quelle Est La Gravité De La Blessure De Vitinha, à Quelques Jours D'affronter Le Bayern Munich
----------------------------------------------------------------------------------------------------

 ![PSG : quelle est la gravité de la blessure de Vitinha, à quelques jours d'affronter le Bayern Munich](https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA21iwnq.img?w=912&h=513&m=4&q=60) <small>www.msn.com</small>PSG : quelle est la gravité de la blessure de Vitinha, à quelques jours d'affronter le Bayern Munich

Vitinha Forced Off The Pitch With Apparent Injury Just DAYS Before PSG's Clash With Barcelona
---------------------------------------------------------------------------------------------

 ![Vitinha forced off the pitch with apparent injury just DAYS before PSG's clash with Barcelona](https://pictures.tribuna.com/image/62515231-a008-473b-b323-20be1e064684?width=1920&quality=70) <small>tribuna.com</small>Vitinha forced off the pitch with apparent injury just DAYS before PSG's clash with Barcelona ...

PSG : Vitinha, Précisions Importantes Sur Sa Blessure
-----------------------------------------------------

 ![PSG : Vitinha, précisions importantes sur sa blessure](https://cdn.football365.fr/wp-content/uploads/se/2024/09/ICONSPORT_238656_0020.jpg) <small>www.football365.fr</small>PSG : Vitinha, précisions importantes sur sa blessure

Vitinha Of Paris Saint-Germain Goes Down With Injury During The UEFA Champions League Last 16
---------------------------------------------------------------------------------------------

 ![Vitinha of Paris Saint-Germain goes down with injury during the UEFA Champions League Last 16](https://c8.alamy.com/comp/3A24BN4/vitinha-of-paris-saint-germain-goes-down-with-injury-during-the-uefa-champions-league-last-16-match-liverpool-vs-paris-saint-germain-at-anfield-liverpool-united-kingdom-11th-march-2025-photo-by-mark-cosgrovenews-images-3A24BN4.jpg) <small>www.alamy.com</small>Vitinha of Paris Saint-Germain goes down with injury during the UEFA Champions League Last 16 ...

Vitinha Injury Update: Why Was He Subbed Off Vs. Auxerre? - Archysport
----------------------------------------------------------------------

 ![Vitinha Injury Update: Why Was He Subbed Off vs. Auxerre? - Archysport](https://www.leparisien.fr/resizer/j7RAZ3hGdFvP7GkZ4aL4tuAKQFw=/1200x675/cloudfront-eu-central-1.images.arcpublishing.com/leparisien/3KU3JMXRXBBILFFLJ6EMNZX5SQ.jpg) <small>www.archysport.com</small>Vitinha Injury Update: Why Was He Subbed Off vs. Auxerre? - Archysport

Exact Moment Vitinha Picks Up Injury Vs Lyon Caught On Camera — Tribuna.com
---------------------------------------------------------------------------

 ![Exact moment Vitinha picks up injury vs Lyon caught on camera — Tribuna.com](https://pictures.tribuna.com/image/3ca2b375-cca9-43fa-ad9f-2f23ae5bf798?width=1920&quality=70) <small>tribuna.com</small>Exact moment Vitinha picks up injury vs Lyon caught on camera — Tribuna.com

Both PSG And Vitinha's Camp Expect Him To Be Available Against Bayern Next Week Despite The
-------------------------------------------------------------------------------------------

 ![Both PSG and Vitinha's camp expect him to be available against Bayern next week despite the](https://pbs.twimg.com/media/HGXtyCzaUAACpmH.jpg) <small>x.com</small>Both PSG and Vitinha's camp expect him to be available against Bayern next week despite the ...

Vitinha Of Paris Saint-Germain Goes Down With Injury During The UEFA Champions League Last 16
---------------------------------------------------------------------------------------------

 ![Vitinha of Paris Saint-Germain goes down with injury during the UEFA Champions League Last 16](https://c8.alamy.com/comp/3A24BMW/vitinha-of-paris-saint-germain-goes-down-with-injury-during-the-uefa-champions-league-last-16-match-liverpool-vs-paris-saint-germain-at-anfield-liverpool-united-kingdom-11th-march-2025-photo-by-mark-cosgrovenews-images-3A24BMW.jpg) <small>www.alamy.com</small>Vitinha of Paris Saint-Germain goes down with injury during the UEFA Champions League Last 16 ...

594 Forehead Injury Stock Photos, High-Res Pictures, And Images - Getty Images
------------------------------------------------------------------------------

 ![594 Forehead Injury Stock Photos, High-Res Pictures, and Images - Getty Images](https://media.gettyimages.com/id/2203998722/photo/paris-saint-germains-portuguese-midfielder-vitinha-reacts-following-an-injury-on-his-forehead.jpg?s=612x612&w=gi&k=20&c=NivYP5BdbbKbYWwXOxOv1CVm037yTAR3RnMWj9pEUbI=) <small>www.gettyimages.co.uk</small>594 Forehead Injury Stock Photos, High-Res Pictures, and Images - Getty Images

Psg &amp; bayern hit by injuries before ucl semi-final. Psg : quelle est la gravité de la blessure de vitinha, à quelques jours d'affronter le bayern munich. Comment le psg pourrait se présenter en cas de blessure de vitinha? une compo proposée
