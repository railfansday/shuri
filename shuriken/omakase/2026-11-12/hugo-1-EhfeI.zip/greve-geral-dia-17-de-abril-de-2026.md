---
title: "Greve Geral Dia 17 De Abril De 2026 - Manifestação nacional – 17 de abril 2026/national demonstration – april 17, 2026 – sinttav"
description: "greve por distritos de 17 de abril a 12 de maio – spzs site"
date: "2026-08-17"
categories:
- "Uncategorized"
images:
- "https://sinapsa.pt/wp-content/uploads/2026/04/info30_site-scaled.jpg"
featuredImage: "https://www.spzs.pt/wp-content/uploads/2026/04/BANNER-17ABRIL-MANIF-1024x363.jpg"
featured_image: "https://sinttav.pt/wp-content/uploads/2026/04/Manifestacao-Nacional-17-de-Abril-2026_page-0001.jpg"
image: "https://trabalhadores-unidos.pt/wp-content/uploads/2026/01/IMG_6655-1-scaled.jpg"
---

If you are looking for Pré-aviso de greve 17 de abril de 2026 – AE Terras do Ave you've came to the right page. We have 35 Pics about Pré-aviso de greve 17 de abril de 2026 – AE Terras do Ave like Pré-Aviso de Greve – 17 de abril de 2026 – Página 2 – AE António Correia de Oliveira, AETCF: Pré-aviso de Greve da Função Pública para 17 de abril 2026 and also GREVE POR DISTRITOS DE 17 DE ABRIL A 12 DE MAIO – spzs site. Here it is:

Pré-aviso De Greve 17 De Abril De 2026 – AE Terras Do Ave
---------------------------------------------------------

 ![Pré-aviso de greve 17 de abril de 2026 – AE Terras do Ave](https://aeterrasave.net/wp-content/uploads/2026/04/Greve-17-de-Abril-2026.png) <small>aeterrasave.net</small>Pré-aviso de greve 17 de abril de 2026 – AE Terras do Ave

Agrupamento De Escolas De Mira - PRÉ-AVISO DE GREVE 17 DE ABRIL DE 2026
-----------------------------------------------------------------------

 ![Agrupamento de Escolas de Mira - PRÉ-AVISO DE GREVE 17 DE ABRIL DE 2026](https://www.escolasdemira.pt/images/Ateno_Recado_com_Informao_Importante_Vermelho_Chamativo_Post_para_Facebook_3.png) <small>www.escolasdemira.pt</small>Agrupamento de Escolas de Mira - PRÉ-AVISO DE GREVE 17 DE ABRIL DE 2026

Pré-Aviso De Greve | 17 De Abril
--------------------------------

 ![Pré-Aviso de Greve | 17 de abril](https://www.aecarcavelos.pt/wp-content/uploads/2026/04/Greve-17-abril-2026-1024x724.jpg) <small>www.aecarcavelos.pt</small>Pré-Aviso de Greve | 17 de abril

SPN - Greves Distritais — Norte Com Forte Adesão!
-------------------------------------------------

 ![SPN - Greves distritais — Norte com forte adesão!](https://www.spn.pt/Media/Default/Info/55000/900/30/0/17a_greve_Porto.jpg) <small>www.spn.pt</small>SPN - Greves distritais — Norte com forte adesão!

FENPROF Emitiu Pré-aviso De Greve Para Permitir Aos Docentes Participarem Na Manifestação
-----------------------------------------------------------------------------------------

 ![FENPROF emitiu Pré-aviso de greve para permitir aos docentes participarem na manifestação](https://www.spzs.pt/wp-content/uploads/2026/04/BANNER-17ABRIL-MANIF-1024x363.jpg) <small>www.spzs.pt</small>FENPROF emitiu Pré-aviso de greve para permitir aos docentes participarem na manifestação ...

GREVE DA FUNÇÃO PÚBLICA - Dia 17 De Abril
-----------------------------------------

 ![GREVE DA FUNÇÃO PÚBLICA - dia 17 de abril](https://static.wixstatic.com/media/9e8139_4ff4ac6d0330454aa75616e5ac18ceba~mv2.png/v1/fill/w_790,h_394,al_c,lg_1,q_85/9e8139_4ff4ac6d0330454aa75616e5ac18ceba~mv2.png) <small>agrupluiscamoes.wixsite.com</small>GREVE DA FUNÇÃO PÚBLICA - dia 17 de abril

Manifestação Nacional 17 De Abril 2026 — SERAM
----------------------------------------------

 ![Manifestação Nacional 17 de abril 2026 — SERAM](https://images.squarespace-cdn.com/content/v1/6909d9adcba7e03be6c550a8/06d5c271-5b75-4367-b115-f06351e133b2/Manif-17-abril.png) <small>www.seram.pt</small>Manifestação Nacional 17 de abril 2026 — SERAM

Pré-Aviso De Greve 17 De Abril De 2026 | Agrupamento De Escolas De Monção
-------------------------------------------------------------------------

 ![Pré-Aviso de Greve 17 de abril de 2026 | Agrupamento de Escolas de Monção](https://aemoncao.com/sites/default/files/styles/max_650x650/public/2026-04/greve.png?itok=qUVQzkGJ) <small>aemoncao.com</small>Pré-Aviso de Greve 17 de abril de 2026 | Agrupamento de Escolas de Monção

Pré-avisos De Greve A Todo O Trabalho Associado às Provas-ensaio 2026 (início A 13 De Abril
-------------------------------------------------------------------------------------------

 ![Pré-avisos de greve a todo o trabalho associado às Provas-ensaio 2026 (início a 13 de abril](https://stop-sindicato.pt/wp-content/uploads/2026/04/S.TO_.P.-Cartaz-Greve-Provas-Ensaio-Inicio-13abril26_comp.png) <small>stop-sindicato.pt</small>Pré-avisos de greve a todo o trabalho associado às Provas-ensaio 2026 (início a 13 de abril ...

AVISO PRÉVIO DE GREVE TRABALHADORES ADMINISTRAÇÃO PÚBLICA 16 DE MAIO 2025 – STTS
--------------------------------------------------------------------------------

 ![AVISO PRÉVIO DE GREVE TRABALHADORES ADMINISTRAÇÃO PÚBLICA 16 DE MAIO 2025 – STTS](https://www.stts.pt/wp-content/uploads/2025/05/CAPA.jpg) <small>www.stts.pt</small>AVISO PRÉVIO DE GREVE TRABALHADORES ADMINISTRAÇÃO PÚBLICA 16 DE MAIO 2025 – STTS

A APG/GNR Saúda A Greve Geral - APG | GNR
-----------------------------------------

 ![A APG/GNR Saúda a Greve Geral - APG | GNR](https://apg-gnr.pt/wp-content/uploads/2026/06/Greve-geral-em-Lisboa-a-3-de-Junho-o-que-para-na-cidade-06-03-2026_01_05_PM-1.png) <small>apg-gnr.pt</small>A APG/GNR Saúda a Greve Geral - APG | GNR

Perspetivas Para 2026: Num Mundo Em Crise, Organizar A Resposta De Quem Trabalha • Trabalhadores
------------------------------------------------------------------------------------------------

 ![Perspetivas para 2026: num mundo em crise, organizar a resposta de quem trabalha • Trabalhadores](https://trabalhadores-unidos.pt/wp-content/uploads/2026/01/IMG_6655-1-scaled.jpg) <small>trabalhadores-unidos.pt</small>Perspetivas para 2026: num mundo em crise, organizar a resposta de quem trabalha • Trabalhadores ...

Greve Geral. Metro De Lisboa Prevê Paralisação Do Serviço E Encerramento Das Estações – ECO
-------------------------------------------------------------------------------------------

 ![Greve Geral. Metro de Lisboa prevê paralisação do serviço e encerramento das estações – ECO](https://eco.imgix.net/uploads/2025/12/thumb-1.jpg) <small>eco.sapo.pt</small>Greve Geral. Metro de Lisboa prevê paralisação do serviço e encerramento das estações – ECO

Manifestação Nacional – 17 De Abril 2026/National Demonstration – April 17, 2026 – SINTTAV
------------------------------------------------------------------------------------------

 ![Manifestação Nacional – 17 de Abril 2026/National Demonstration – April 17, 2026 – SINTTAV](https://sinttav.pt/wp-content/uploads/2026/04/Manifestacao-Nacional-17-de-Abril-2026_page-0001.jpg) <small>sinttav.pt</small>Manifestação Nacional – 17 de Abril 2026/National Demonstration – April 17, 2026 – SINTTAV ...

GREVE POR DISTRITOS DE 17 DE ABRIL A 12 DE MAIO – Spzs Site
-----------------------------------------------------------

 ![GREVE POR DISTRITOS DE 17 DE ABRIL A 12 DE MAIO – spzs site](http://www.spzs.pt/wp-content/uploads/2023/04/greves-abr23-724x1024.jpg) <small>www.spzs.pt</small>GREVE POR DISTRITOS DE 17 DE ABRIL A 12 DE MAIO – spzs site

Greve De 17 De Abril Pode Provocar Constrangimentos Nas Escolas De Ovar - OvarNews
----------------------------------------------------------------------------------

 ![Greve de 17 de abril pode provocar constrangimentos nas escolas de Ovar - OvarNews](https://www.ovarnews.pt/wp-content/uploads/2026/04/GREVE-780x470.png) <small>www.ovarnews.pt</small>Greve de 17 de abril pode provocar constrangimentos nas escolas de Ovar - OvarNews

Nacional - FENPROF
------------------

 ![Nacional - FENPROF](https://www.fenprof.pt/media/download/FA35D84EB902AC7A6FFE8691F2CE04D8/2026_05_16-manifestacao-ecd-2.jpeg?width=800&rxy=0.5) <small>www.fenprof.pt</small>Nacional - FENPROF

17 De Abril é Dia De Luta!
--------------------------

 ![17 de Abril é dia de luta!](https://fectrans.pt/images/Imagens2024/Fotos/Geral/Manif17Abril2026.jpg) <small>fectrans.pt</small>17 de Abril é dia de luta!

Eurodreams De 17 De Novembro De 2025
------------------------------------

 ![Eurodreams de 17 de novembro de 2025](https://jornaldemafra.pt/wp-content/uploads/2025/12/greve-geral.webp) <small>jornaldemafra.pt</small>Eurodreams de 17 de novembro de 2025

Confira A Agenda De Greve Para A Semana Dos Dias 13 A 17 De Abril – ASSUFSM | Associação Dos
--------------------------------------------------------------------------------------------

 ![Confira a agenda de greve para a semana dos dias 13 a 17 de abril – ASSUFSM | Associação dos](https://assufsm.com.br/wp-content/uploads/2026/04/SITE-4.png) <small>assufsm.com.br</small>Confira a agenda de greve para a semana dos dias 13 a 17 de abril – ASSUFSM | Associação dos ...

Pré-Aviso De Greve - 17 De Abril De 2026
----------------------------------------

 ![Pré-Aviso de Greve - 17 de abril de 2026](https://static.wixstatic.com/media/c8427b_580a74e765244b6bb1d9606fc20b7b13~mv2.jpg/v1/fill/w_1000,h_709,al_c,q_85,usm_0.66_1.00_0.01/c8427b_580a74e765244b6bb1d9606fc20b7b13~mv2.jpg) <small>www.atb-23.net</small>Pré-Aviso de Greve - 17 de abril de 2026

SPN - Docentes Na Greve Da Administração Pública (17/mai)
---------------------------------------------------------

 ![SPN - Docentes na Greve da Administração Pública (17/mai)](https://www.spn.pt/Media/Default/Info/60000/700/90/7/greveap-17maio24.jpeg) <small>www.spn.pt</small>SPN - Docentes na Greve da Administração Pública (17/mai)

Greve Dia 17-04-2026 - Agrupamento De Escolas Da Lousã
------------------------------------------------------

 ![Greve dia 17-04-2026 - Agrupamento de Escolas da Lousã](https://escolas.aglousa.com/wp-content/uploads/2019/06/greve.png) <small>escolas.aglousa.com</small>Greve dia 17-04-2026 - Agrupamento de Escolas da Lousã

Manifestação Nacional | 17 Abril 2026 - SINAPSA
-----------------------------------------------

 ![Manifestação Nacional | 17 Abril 2026 - SINAPSA](https://sinapsa.pt/wp-content/uploads/2026/04/info30_site-scaled.jpg) <small>sinapsa.pt</small>Manifestação Nacional | 17 Abril 2026 - SINAPSA

Professores(as) Da UFPB Aprovam Indicativo De Greve Sem Data E Paralisação No Dia 17 De Abril
---------------------------------------------------------------------------------------------

 ![Professores(as) da UFPB aprovam indicativo de greve sem data e paralisação no dia 17 de abril](https://www.adufpb.org.br/site/wp-content/uploads/2024/04/2024.04.03-assembleia-indicativo-de-greve-5-scaled.jpg) <small>www.adufpb.org.br</small>Professores(as) da UFPB aprovam indicativo de greve sem data e paralisação no dia 17 de abril ...

Greve 17 Abril: Direitos Dos Trabalhadores | Expert Zoom
--------------------------------------------------------

 ![Greve 17 Abril: direitos dos trabalhadores | Expert Zoom](https://img.expert-zoom.com/cdn-cgi/image/w=820,q=60,f=auto/hero/ec7d4f37c029-defa97.webp) <small>expert-zoom.com</small>Greve 17 Abril: direitos dos trabalhadores | Expert Zoom

AVISO À COMUNIDADE EDUCATIVA – GREVE | 17 De Abril De 2026
----------------------------------------------------------

 ![AVISO À COMUNIDADE EDUCATIVA – GREVE | 17 de abril de 2026](https://aealcabideche.pt/images/Aviso_à_Comunidade_Educativa_-_Greve.png) <small>aealcabideche.pt</small>AVISO À COMUNIDADE EDUCATIVA – GREVE | 17 de abril de 2026

GREVE DA EDUCAÇÃO – ANDES Disponibiliza ônibus De Fortaleza A Brasília Para Ato Nacional No Dia
-----------------------------------------------------------------------------------------------

 ![GREVE DA EDUCAÇÃO – ANDES disponibiliza ônibus de Fortaleza a Brasília para ato nacional no dia](https://www.adufc.org.br/wp-content/uploads/2024/04/Informe-2023-Modelo-Quadrado.png) <small>www.adufc.org.br</small>GREVE DA EDUCAÇÃO – ANDES disponibiliza ônibus de Fortaleza a Brasília para ato nacional no dia ...

Vencimentos Técnico Superior 2024 – 2025 – Sindicato S.TO.P.
------------------------------------------------------------

 ![Vencimentos Técnico Superior 2024 – 2025 – Sindicato S.TO.P.](https://stop-sindicato.pt/wp-content/uploads/2025/11/S.TO_.P.-Cartaz-Greve-Geral-Educacao-11Dez2025_x1000-768x1086.png) <small>stop-sindicato.pt</small>Vencimentos Técnico Superior 2024 – 2025 – Sindicato S.TO.P.

Greve 2026 - Sindifes-MG
------------------------

 ![Greve 2026 - Sindifes-MG](https://site-wp.sfo3.digitaloceanspaces.com/wp-content/uploads/2026/03/24161831/Prancheta-2.png) <small>sindifes.org.br</small>Greve 2026 - Sindifes-MG

AETCF: Pré-aviso De Greve Da Função Pública Para 17 De Abril 2026
-----------------------------------------------------------------

 ![AETCF: Pré-aviso de Greve da Função Pública para 17 de abril 2026](https://www.aetcf.pt/pluginfile.php/16/mod_forum/post/2094/prevaviso_greve_17abri26.png) <small>www.aetcf.pt</small>AETCF: Pré-aviso de Greve da Função Pública para 17 de abril 2026

Pré-Aviso De Greve – 17 De Abril De 2026 – Página 2 – AE António Correia De Oliveira
------------------------------------------------------------------------------------

 ![Pré-Aviso de Greve – 17 de abril de 2026 – Página 2 – AE António Correia de Oliveira](https://www.acoliveira.pt/wp-content/uploads/2026/04/7e9f6ec4-4873-4685-897b-30c62aab02d6.png) <small>www.acoliveira.pt</small>Pré-Aviso de Greve – 17 de abril de 2026 – Página 2 – AE António Correia de Oliveira

SPN - Fenprof — Adesão Histórica à Greve Geral
----------------------------------------------

 ![SPN - Fenprof — Adesão histórica à greve geral](https://www.spn.pt/Media/Default/Info/68000/500/60/7/grevegeral11dez_cartaz.jpg) <small>www.spn.pt</small>SPN - Fenprof — Adesão histórica à greve geral

Greve Da Administração Pública Marcada Para 17 De Abril — DNOTICIAS.PT
----------------------------------------------------------------------

 ![Greve da Administração Pública marcada para 17 de Abril — DNOTICIAS.PT](https://static-storage.dnoticias.pt/www-assets.dnoticias.pt/images/configuration/fb-9/logoWhatsApp_Image_2025-10-24_at_10.56.44_eFMSccu.JPEG) <small>www.dnoticias.pt</small>Greve da Administração Pública marcada para 17 de Abril — DNOTICIAS.PT

Veja A últimas Notícias Da Greve 2026 - Sindifes-MG
---------------------------------------------------

 ![Veja a últimas notícias da Greve 2026 - Sindifes-MG](https://site-wp.sfo3.digitaloceanspaces.com/wp-content/uploads/2025/12/10115923/IMG_2230-2048x1366-1.jpeg) <small>sindifes.org.br</small>Veja a últimas notícias da Greve 2026 - Sindifes-MG

Greve da função pública. Pré-aviso de greve 17 de abril de 2026 – ae terras do ave. Greve dia 17-04-2026
