---
title: "Clifton Powell Wife And Kids - Clifton powell jr. archives"
description: "Everything we know about sasha obama&#039;s new boyfriend and his famous father"
date: "2026-06-25"
categories:
- "Uncategorized"
images:
- "https://www.thelist.com/img/gallery/everything-we-know-about-sasha-obamas-new-boyfriend-and-his-famous-father/clifton-powell-sr-raised-his-family-in-a-wealthy-community-1650649036.jpg"
featuredImage: "https://biographytribune.com/wp-content/uploads/2018/11/Clifton-Powell-4.jpg"
featured_image: "https://liverampup.com/uploads/clifton-powell-with-ex-wife.JPG"
image: "https://st.depositphotos.com/1814084/1596/i/950/depositphotos_15960511-stock-photo-clifton-powell-and-family.jpg"
---

If you are looking for Clifton Powell's Love Life- Married or Divorced? you've came to the right place. We have 34 Pics about Clifton Powell's Love Life- Married or Divorced? like Actor Clifton Powell and daughter Maya Powell attend "Chocolate City"... News Photo - Getty Images, Clifton Powell's Love Life- Married or Divorced? and also Actor Clifton Powell and his wife Kimberly Powell attend the "Genius:... News Photo - Getty Images. Read more:

Clifton Powell's Love Life- Married Or Divorced?
------------------------------------------------

 ![Clifton Powell's Love Life- Married or Divorced?](https://liverampup.com/uploads/clifton-powell-with-girlfriend-kita.JPG) <small>liverampup.com</small>Clifton Powell's Love Life- Married or Divorced?

Who Is Clifton Powell Jr? Wiki, Net Worth, Biography, Age, Height, Girlfriend
-----------------------------------------------------------------------------

 ![Who is Clifton Powell Jr? Wiki, Net Worth, Biography, Age, Height, Girlfriend](https://www.walikali.com/wp-content/uploads/2022/04/Clifton-Powell-Jr-2-768x384.jpg) <small>www.walikali.com</small>Who is Clifton Powell Jr? Wiki, Net Worth, Biography, Age, Height, Girlfriend

Clifton Powell Jr. Archives - TheJasmineBRAND
---------------------------------------------

 ![Clifton Powell Jr. Archives - theJasmineBRAND](https://thejasminebrand.com/wp-content/uploads/2022/04/Untitled-design-2022-04-21T133135.970-620x600.png) <small>thejasminebrand.com</small>Clifton Powell Jr. Archives - theJasmineBRAND

379 Clifton Powell Stock Photos, High-Res Pictures, And Images - Getty Images
-----------------------------------------------------------------------------

 ![379 Clifton Powell Stock Photos, High-Res Pictures, and Images - Getty Images](https://media.gettyimages.com/id/79508949/photo/clifton-powell-and-wife-kimberly.jpg?s=612x612&w=gi&k=20&c=D7ixwqgBqO7xspOZ3Cu8sxkLYigO88usB0BTG8cKCaU=) <small>www.gettyimages.co.uk</small>379 Clifton Powell Stock Photos, High-Res Pictures, and Images - Getty Images

Actor Clifton Powell (C) Attends The 18th Annual BET Awards At Microsoft Theater In Los Angeles
-----------------------------------------------------------------------------------------------

 ![Actor Clifton Powell (C) attends the 18th annual BET Awards at Microsoft Theater in Los Angeles](https://c8.alamy.com/comp/TY836B/actor-clifton-powell-c-attends-the-18th-annual-bet-awards-at-microsoft-theater-in-los-angeles-on-june-24-2018-the-ceremony-celebrates-achievements-in-entertainment-and-honors-music-sports-television-and-movies-released-between-april-1-2017-and-march-31-2018-photo-by-gregg-deguireupi-TY836B.jpg) <small>www.alamy.com</small>Actor Clifton Powell (C) attends the 18th annual BET Awards at Microsoft Theater in Los Angeles ...

Everything We Know About Sasha Obama's New Boyfriend And His Famous Father
--------------------------------------------------------------------------

 ![Everything We Know About Sasha Obama's New Boyfriend And His Famous Father](https://www.thelist.com/img/gallery/everything-we-know-about-sasha-obamas-new-boyfriend-and-his-famous-father/clifton-powell-sr-raised-his-family-in-a-wealthy-community-1650649036.jpg) <small>www.thelist.com</small>Everything We Know About Sasha Obama's New Boyfriend And His Famous Father

92 Clifton Powell Stock Pictures, Editorial Images And Stock Photos | Shutterstock Editorial
--------------------------------------------------------------------------------------------

 ![92 Clifton Powell Stock Pictures, Editorial Images and Stock Photos | Shutterstock Editorial](https://www.shutterstock.com/editorial/image-editorial/NeDcMa55O3Ddg9x4ODI2Nw==/clifton-powell-wife-kim-440nw-4372122b.jpg) <small>www.shutterstock.com</small>92 Clifton Powell Stock Pictures, Editorial Images and Stock Photos | Shutterstock Editorial

351 Clifton Powell Stock Photos, High-Res Pictures, And Images - Getty Images
-----------------------------------------------------------------------------

 ![351 Clifton Powell Stock Photos, High-Res Pictures, and Images - Getty Images](https://media.gettyimages.com/id/115378383/photo/clifton-powell-and-his-wife-kim-powell-during-2005-h-e-r-b-i-e-awards-presented-by-the-rhythm.jpg?s=612x612&w=gi&k=20&c=7AgZ_sTybfZzVYy50eaenZeuXHRfwTjVm91nD5TQROk=) <small>www.gettyimages.co.uk</small>351 Clifton Powell Stock Photos, High-Res Pictures, and Images - Getty Images

Clifton Powell's Love Life- Married Or Divorced?
------------------------------------------------

 ![Clifton Powell's Love Life- Married or Divorced?](https://cdn.liverampup.com/uploads/clifton-powell-son's-family-photo.JPG) <small>cdn.liverampup.com</small>Clifton Powell's Love Life- Married or Divorced?

Clifton Powell Jr , Barack Obamas Tochter Sasha Liebt Sohn Eines Hollywoodstars – NTBA
--------------------------------------------------------------------------------------

 ![Clifton Powell Jr , Barack Obamas Tochter Sasha liebt Sohn eines Hollywoodstars – NTBA](https://pagesix.com/wp-content/uploads/sites/3/2022/04/who-is-clifton-powell-jr_23.jpg) <small>elbschul-eltern.de</small>Clifton Powell Jr , Barack Obamas Tochter Sasha liebt Sohn eines Hollywoodstars – NTBA

Actor Clifton Powell And His Family Arrive At The 36th NAACP Image... News Photo - Getty Images
-----------------------------------------------------------------------------------------------

 ![Actor Clifton Powell and his family arrive at the 36th NAACP Image... News Photo - Getty Images](https://media.gettyimages.com/id/52457971/photo/36th-naacp-image-awards-arrival-reception.jpg?s=1024x1024&w=gi&k=20&c=VgUGmGrfF_WPHjMLA32__3fD9368ygJWdpnbO8X1NOU=) <small>www.gettyimages.com</small>Actor Clifton Powell and his family arrive at the 36th NAACP Image... News Photo - Getty Images

379 Clifton Powell Stock Photos, High-Res Pictures, And Images - Getty Images
-----------------------------------------------------------------------------

 ![379 Clifton Powell Stock Photos, High-Res Pictures, and Images - Getty Images](https://media.gettyimages.com/id/474358662/photo/westwood-ca-actor-clifton-powell-and-daughter-maya-powell-attend-chocolate-city-movie-premiere.jpg?s=612x612&w=gi&k=20&c=7xcHWbrZrbAHKtM6ogpAwHOn9qKY2jNuNLCc4CVlIME=) <small>www.gettyimages.co.uk</small>379 Clifton Powell Stock Photos, High-Res Pictures, and Images - Getty Images

Clifton Powell Jr. Wiki: Biography, Age, Height, Parents, Ethnicity, Girlfriend, Net Worth &amp; More
-----------------------------------------------------------------------------------------------------

 ![Clifton Powell Jr. Wiki: Biography, Age, Height, Parents, Ethnicity, Girlfriend, Net Worth & More](https://www.newsunzip.com/wp-content/uploads/2022/04/Clifton-Powell-Jr.-with-Sasha-Obama.jpg) <small>www.newsunzip.com</small>Clifton Powell Jr. Wiki: Biography, Age, Height, Parents, Ethnicity, Girlfriend, Net Worth &amp; More

Who Is Clifton Powell From “Menace To Society”? Wikipedia, Biography, Age, Family, Height, Net
----------------------------------------------------------------------------------------------

 ![Who is Clifton Powell from “Menace to Society”? Wikipedia, Biography, Age, Family, Height, Net](https://biographytribune.com/wp-content/uploads/2018/11/Clifton-Powell-4.jpg) <small>wikibious.com</small>Who is Clifton Powell from “Menace to Society”? Wikipedia, Biography, Age, Family, Height, Net ...

Clifton Theater Hi-res Stock Photography And Images - Alamy
-----------------------------------------------------------

 ![Clifton theater hi-res stock photography and images - Alamy](https://c8.alamy.com/comp/TY8368/actor-clifton-powell-c-attends-the-18th-annual-bet-awards-at-microsoft-theater-in-los-angeles-on-june-24-2018-the-ceremony-celebrates-achievements-in-entertainment-and-honors-music-sports-television-and-movies-released-between-april-1-2017-and-march-31-2018-photo-by-gregg-deguireupi-TY8368.jpg) <small>www.alamy.com</small>Clifton theater hi-res stock photography and images - Alamy

Clifton Powell Photos And Premium High Res Pictures - Getty Images
------------------------------------------------------------------

 ![Clifton Powell Photos and Premium High Res Pictures - Getty Images](https://media.gettyimages.com/id/988071808/photo/clifton-powell-arrives-to-the-2018-bet-awards-held-at-microsoft-theater-on-june-24-2018-in-los.jpg?s=612x612&w=gi&k=20&c=2FINkFygb7z2_KC0w6yw2FzRZmonzccju0zmrCtjOb4=) <small>www.gettyimages.dk</small>Clifton Powell Photos and Premium High Res Pictures - Getty Images

The Advice Clifton Powell Gave His Son About Dating Sasha Obama
---------------------------------------------------------------

 ![The Advice Clifton Powell Gave His Son About Dating Sasha Obama](https://www.thelist.com/img/gallery/the-advice-clifton-powell-gave-his-son-about-dating-sasha-obama/l-intro-1690133864.jpg) <small>www.thelist.com</small>The Advice Clifton Powell Gave His Son About Dating Sasha Obama

Who Is Clifton Powell Jr? Sasha Obama Dating Scriptwriter Son
-------------------------------------------------------------

 ![Who Is Clifton Powell Jr? Sasha Obama Dating Scriptwriter Son](https://data.ibtimes.sg/en/full/57147/sasha-obama-and-clifton-powell-jr.jpg?w=736) <small>www.ibtimes.sg</small>Who Is Clifton Powell Jr? Sasha Obama Dating Scriptwriter Son ...

Clifton Powell Wiki, Age, Height, Siblings, Wife, Kids, Net Worth, GTA
----------------------------------------------------------------------

 ![Clifton Powell Wiki, Age, Height, Siblings, Wife, Kids, Net Worth, GTA](https://factsbio.com/wp-content/uploads/2021/06/Clifton-Powell-son-500x428.jpg) <small>factsbio.com</small>Clifton Powell Wiki, Age, Height, Siblings, Wife, Kids, Net Worth, GTA

Meet Sasha Obama's BOYFRIEND: Inside Daughter Of Former President Barack Obama's Budding New
--------------------------------------------------------------------------------------------

 ![Meet Sasha Obama's BOYFRIEND: Inside daughter of former President Barack Obama's budding new](https://i.dailymail.co.uk/1s/2022/04/21/19/56887265-10739881-The_second_child_of_actor_Clifton_Powell_66_and_his_wife_Kimberl-a-7_1650564483151.jpg) <small>www.dailymail.com</small>Meet Sasha Obama's BOYFRIEND: Inside daughter of former President Barack Obama's budding new ...

92 Clifton Powell Stock Pictures, Editorial Images And Stock Photos | Shutterstock Editorial
--------------------------------------------------------------------------------------------

 ![92 Clifton Powell Stock Pictures, Editorial Images and Stock Photos | Shutterstock Editorial](https://www.shutterstock.com/editorial/image-editorial/NaDdM857O7D6g7x9ODI2NQ==/clifton-powell-wife-kim-440nw-4372122a.jpg) <small>www.shutterstock.com</small>92 Clifton Powell Stock Pictures, Editorial Images and Stock Photos | Shutterstock Editorial

Clifton Powell And Wife Kimberly During 11th Annual Screen Actors... | WireImage | 130312531
--------------------------------------------------------------------------------------------

 ![Clifton Powell and wife Kimberly during 11th Annual Screen Actors... | WireImage | 130312531](https://i.pinimg.com/originals/97/72/55/977255b7c874047824f1ac2bd2fa6787.jpg) <small>www.pinterest.com</small>Clifton Powell and wife Kimberly during 11th Annual Screen Actors... | WireImage | 130312531 ...

Clifton Powell Wife Kim Editorial Stock Photo - Stock Image | Shutterstock
--------------------------------------------------------------------------

 ![Clifton Powell Wife Kim Editorial Stock Photo - Stock Image | Shutterstock](https://editorial01.shutterstock.com/preview-440/5137138m/ad89a64a/Shutterstock_5137138m.jpg) <small>www.shutterstock.com</small>Clifton Powell Wife Kim Editorial Stock Photo - Stock Image | Shutterstock

Clifton Powell Wife Kim Editorial Stock Photo - Stock Image | Shutterstock
--------------------------------------------------------------------------

 ![Clifton Powell Wife Kim Editorial Stock Photo - Stock Image | Shutterstock](https://editorial01.shutterstock.com/preview-440/498932az/25fd668f/Shutterstock_498932az.jpg) <small>www.shutterstock.com</small>Clifton Powell Wife Kim Editorial Stock Photo - Stock Image | Shutterstock

Actor Clifton Powell And Daughter Maya Powell Attend "Chocolate City"... News Photo - Getty Images
--------------------------------------------------------------------------------------------------

 ![Actor Clifton Powell and daughter Maya Powell attend "Chocolate City"... News Photo - Getty Images](https://media.gettyimages.com/id/474358674/photo/chocolate-city-los-angeles-premiere.jpg?s=1024x1024&w=gi&k=20&c=yrUiAMazNB4u5970G6OFCgc-2_dIDaXcvIvy8_Bmjaw=) <small>www.gettyimages.ca</small>Actor Clifton Powell and daughter Maya Powell attend "Chocolate City"... News Photo - Getty Images

Clifton Powell Wife Kim Editorial Stock Photo - Stock Image | Shutterstock
--------------------------------------------------------------------------

 ![Clifton Powell Wife Kim Editorial Stock Photo - Stock Image | Shutterstock](https://editorial01.shutterstock.com/preview-440/4372122c/bd80acb5/Shutterstock_4372122c.jpg) <small>www.shutterstock.com</small>Clifton Powell Wife Kim Editorial Stock Photo - Stock Image | Shutterstock

Actor Clifton Powell And His Wife Kimberly Powell Attend The "Genius:... News Photo - Getty Images
--------------------------------------------------------------------------------------------------

 ![Actor Clifton Powell and his wife Kimberly Powell attend the "Genius:... News Photo - Getty Images](https://media.gettyimages.com/id/51456961/photo/cbs-ray-charles-tribute-with-jamie-foxx-and-other-celebs-arrivals.jpg?s=594x594&w=gi&k=20&c=XAOtWtuLWk7K5NUIT7dU6cPHv5pamX75kpadxJYXOm4=) <small>www.gettyimages.ca</small>Actor Clifton Powell and his wife Kimberly Powell attend the "Genius:... News Photo - Getty Images

351 Clifton Powell Stock Photos, High-Res Pictures, And Images - Getty Images
-----------------------------------------------------------------------------

 ![351 Clifton Powell Stock Photos, High-Res Pictures, and Images - Getty Images](https://media.gettyimages.com/id/115378384/photo/clifton-powell-and-his-wife-kim-powell-during-2005-h-e-r-b-i-e-awards-presented-by-the-rhythm.jpg?s=612x612&w=gi&k=20&c=vdjJPdyf3hxFqj5mfpTCdnLh1yET1k6yKVlyxF1p8bY=) <small>www.gettyimages.co.uk</small>351 Clifton Powell Stock Photos, High-Res Pictures, and Images - Getty Images

379 Clifton Powell Stock Photos, High-Res Pictures, And Images - Getty Images
-----------------------------------------------------------------------------

 ![379 Clifton Powell Stock Photos, High-Res Pictures, and Images - Getty Images](https://media.gettyimages.com/id/111517335/photo/clifton-powell-jr-clifton-powell-and-mya-powell-at-the-world-premiere-of-screen-gems-first.jpg?s=612x612&w=gi&k=20&c=_RMjlAAY87MzChEu-cv5XpS8RpJMJzolyMTKUFs4Imo=) <small>www.gettyimages.co.uk</small>379 Clifton Powell Stock Photos, High-Res Pictures, and Images - Getty Images

Nov. 13, 2002 - Westwood, CALIFORNIA, USA - K27137TR FRIDAY AFTER NEXT MOVIE PREMIERE.MANN
------------------------------------------------------------------------------------------

 ![Nov. 13, 2002 - Westwood, CALIFORNIA, USA - K27137TR FRIDAY AFTER NEXT MOVIE PREMIERE.MANN](https://c8.alamy.com/comp/DN77B8/nov-13-2002-westwood-california-usa-k27137tr-friday-after-next-movie-DN77B8.jpg) <small>www.alamy.com</small>Nov. 13, 2002 - Westwood, CALIFORNIA, USA - K27137TR FRIDAY AFTER NEXT MOVIE PREMIERE.MANN ...

Clifton Powell's Love Life- Married Or Divorced?
------------------------------------------------

 ![Clifton Powell's Love Life- Married or Divorced?](https://liverampup.com/uploads/clifton-powell-with-ex-wife.JPG) <small>liverampup.com</small>Clifton Powell's Love Life- Married or Divorced?

Who Is Clifton Powell Jr.? What To Know About Sasha Obama’s BF
--------------------------------------------------------------

 ![Who is Clifton Powell Jr.? What to know about Sasha Obama’s BF](https://pagesix.com/wp-content/uploads/sites/3/2022/04/who-is-clifton-powell-jr_25.jpg) <small>pagesix.com</small>Who is Clifton Powell Jr.? What to know about Sasha Obama’s BF

Clifton Powell And Family – Stock Editorial Photo © S\_bukley #15960511
-----------------------------------------------------------------------

 ![Clifton Powell and family – Stock Editorial Photo © s_bukley #15960511](https://st.depositphotos.com/1814084/1596/i/950/depositphotos_15960511-stock-photo-clifton-powell-and-family.jpg) <small>depositphotos.com</small>Clifton Powell and family – Stock Editorial Photo © s\_bukley #15960511

Clifton Powell Pictures And Photos
----------------------------------

 ![Clifton Powell Pictures and Photos](https://static3.imagecollect.com/preview/137/86707c06368bcf5) <small>imagecollect.com</small>Clifton Powell Pictures and Photos

Clifton powell and family – stock editorial photo © s\_bukley #15960511. 351 clifton powell stock photos, high-res pictures, and images. Clifton powell jr. wiki: biography, age, height, parents, ethnicity, girlfriend, net worth &amp; more
