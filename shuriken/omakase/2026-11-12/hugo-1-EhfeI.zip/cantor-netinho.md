---
title: "Cantor Netinho - Morre netinho: cantor se declarou bissexual em 2008 e causou polêmica ao fazer críticas à"
description: "20 grandes sucessos de netinho von netinho auf amazon music unlimited"
date: "2026-05-05"
categories:
- "Uncategorized"
images:
- "https://s2-extra.glbimg.com/Fi4iM-a-LNOlKJOjW6iF0RK3gHE=/0x0:2000x1194/888x0/smart/filters:strip_icc()/i.s3.glbimg.com/v1/AUTH_1f551ea7087a47f39ead75f64041559a/internal_photos/bs/2026/X/5/0il39ARi2JNg2tIwtEmw/arte-2026-10-13t110549.915.png"
featuredImage: "https://sbtnews.sbt.com.br/imagens/medium_netinho_assessoria_85732cd1a7.jpg"
featured_image: "https://billboard-com-br.s3.amazonaws.com/wp-content/uploads/2026/10/13111024/Netinho-durante-participacao-no-Altas-Horas-em-2014-Globo_Ze-Paulo-Cardeal.webp"
image: "https://conteudo.imguol.com.br/c/splash/4d/2026/10/13/netinho-cantor-do-hit-milla-1791901039989_v2_615x300.jpg"
---

If you are looking for Morre aos 60 anos o cantor Netinho, do hit Milla, vítima de câncer linfático · Notícias da TV you've came to the right place. We have 35 Pictures about Morre aos 60 anos o cantor Netinho, do hit Milla, vítima de câncer linfático · Notícias da TV like Ícone do axé music, Netinho morre aos 60 anos, Murió el cantante brasileño Netinho, autor del tema La isla del sol and also Netinho, cantor de 'Milla', morre aos 60 anos. Read more:

Morre Aos 60 Anos O Cantor Netinho, Do Hit Milla, Vítima De Câncer Linfático · Notícias Da TV
---------------------------------------------------------------------------------------------

 ![Morre aos 60 anos o cantor Netinho, do hit Milla, vítima de câncer linfático · Notícias da TV](https://noticiasdatv.uol.com.br/media/uploads/artigos_2024/netinho-cantor-cura-cancer-foto-instagram.jpg) <small>noticiasdatv.uol.com.br</small>Morre aos 60 anos o cantor Netinho, do hit Milla, vítima de câncer linfático · Notícias da TV

Netinho, Cantor De 'Milla', Morre Aos 60 Anos
---------------------------------------------

 ![Netinho, cantor de 'Milla', morre aos 60 anos](https://billboard-com-br.s3.amazonaws.com/wp-content/uploads/2026/10/13110117/Morre-o-cantor-Netinho-do-hit-Milla-Divulgacao.webp) <small>billboard.com.br</small>Netinho, cantor de 'Milla', morre aos 60 anos

Quem São Os Herdeiros Do Cantor Netinho? Artista Deixa Filha única
------------------------------------------------------------------

 ![Quem são os herdeiros do cantor Netinho? Artista deixa filha única](https://p2.trrsf.com/image/fget/cf/1200/630/middle/images.terra.com/2026/10/13/netinho-filha-urgrs80s5quu.jpg) <small>www.terra.com.br</small>Quem são os herdeiros do cantor Netinho? Artista deixa filha única

Cantor Netinho, Dono Do Hit 'Milla', Morre Aos 60 Anos Em Meio A Tratamento De Câncer
-------------------------------------------------------------------------------------

 ![Cantor Netinho, dono do hit 'Milla', morre aos 60 anos em meio a tratamento de câncer](https://s2-quem.glbimg.com/Cg_XdfiDChb2QoxaV5ECapcaaWE=/0x0:640x440/984x0/smart/filters:strip_icc()/i.s3.glbimg.com/v1/AUTH_b0f0e84207c948ab8b8777be5a6a4395/internal_photos/bs/2026/C/v/kJtDuQRaOVN94sfx97hQ/netinho.jpeg) <small>revistaquem.globo.com</small>Cantor Netinho, dono do hit 'Milla', morre aos 60 anos em meio a tratamento de câncer

Morre O Cantor Netinho, ícone Do Carnaval Baiano E Pioneiro Do Axé Music, Aos 60 Anos
-------------------------------------------------------------------------------------

 ![Morre o cantor Netinho, ícone do Carnaval baiano e pioneiro do axé music, aos 60 anos](https://www.cbnsantos.com.br/media/_versions/caracteristicas__-_2026-10-13t110656.149_widelg.jpg) <small>www.cbnsantos.com.br</small>Morre o cantor Netinho, ícone do Carnaval baiano e pioneiro do axé music, aos 60 anos

Morreu O Cantor Brasileiro Netinho, Autor De Mila
-------------------------------------------------

 ![Morreu o cantor brasileiro Netinho, autor de Mila](https://staticx.noticiasilimitadas.pt/oj/image.webp?brand=oj&type=generate&guid=d7227a23-1a2a-44f1-aea9-1b3c986724d2&w=3840) <small>www.ojogo.pt</small>Morreu o cantor brasileiro Netinho, autor de Mila

Treta Política Impediu Netinho, Que Morreu Nesta Terça-feira (13), De Cantar 'Milla', Seu Maior
-----------------------------------------------------------------------------------------------

 ![Treta política impediu Netinho, que morreu nesta terça-feira (13), de cantar 'Milla', seu maior](https://s2-oglobo.glbimg.com/SxX6SjbOL2Gsw1kHtTK9ZpK7g3U=/0x0:714x741/888x0/smart/filters:strip_icc()/i.s3.glbimg.com/v1/AUTH_da025474c0c44edd99332dddb09cabe8/internal_photos/bs/2026/K/h/qULtJgSFiywWsVMJ3Btw/netinho-2.jpg) <small>oglobo.globo.com</small>Treta política impediu Netinho, que morreu nesta terça-feira (13), de cantar 'Milla', seu maior ...

Ícone Do Axé Music, Netinho Morre Aos 60 Anos
---------------------------------------------

 ![Ícone do axé music, Netinho morre aos 60 anos](https://s2-cbn.glbimg.com/RS56cSTfvX7N2GtOZTLi6DZ0j_E=/0x0:1116x628/888x0/smart/filters:strip_icc()/i.s3.glbimg.com/v1/AUTH_d975fad146a14bbfad9e763717b09688/internal_photos/bs/2026/d/U/Vbu2UFSvWjGgUwtwXUQg/captura-de-tela-2026-10-13-105507.png) <small>cbn.globo.com</small>Ícone do axé music, Netinho morre aos 60 anos

Morreu Netinho, O Cantor De 'Milla' - Expresso
----------------------------------------------

 ![Morreu Netinho, o cantor de 'Milla' - Expresso](https://images.impresa.pt/expresso/2026-10-13-netinho.jpg-1b1d71a9/original) <small>expresso.pt</small>Morreu Netinho, o cantor de 'Milla' - Expresso

20 Grandes Sucessos De Netinho Von Netinho Auf Amazon Music Unlimited
---------------------------------------------------------------------

 ![20 Grandes Sucessos De Netinho von Netinho auf Amazon Music Unlimited](https://m.media-amazon.com/images/I/41WqnJtPPWS._UXNaN_FMjpg_QL85_.jpg) <small>music.amazon.de</small>20 Grandes Sucessos De Netinho von Netinho auf Amazon Music Unlimited

Murió El Cantante Brasileño Netinho, Autor Del Tema La Isla Del Sol
-------------------------------------------------------------------

 ![Murió el cantante brasileño Netinho, autor del tema La isla del sol](https://media.ambito.com/p/cb699ce5e16c6640b8532b2fcde283a4/adjuntos/239/imagenes/043/703/0043703010/netinho.webp) <small>www.ambito.com</small>Murió el cantante brasileño Netinho, autor del tema La isla del sol

Entenda O Tipo De Câncer Do Cantor Netinho E Os Sinais De Alerta Da Doença
--------------------------------------------------------------------------

 ![Entenda o tipo de câncer do cantor Netinho e os sinais de alerta da doença](https://conteudo.imguol.com.br/c/entretenimento/a0/2018/05/20/cantor-netinho-participa-de-show-na-virada-cultural-em-sao-paulo-1526800979368_v2_615x300.jpg) <small>www.uol.com.br</small>Entenda o tipo de câncer do cantor Netinho e os sinais de alerta da doença

Morre O Cantor Netinho, ícone Do Axé, Aos 60 Anos
-------------------------------------------------

 ![Morre o cantor Netinho, ícone do axé, aos 60 anos](https://mistobrasil.com/wp-content/uploads/2026/10/cantor-netinho.jpg) <small>mistobrasil.com</small>Morre o cantor Netinho, ícone do axé, aos 60 anos

Qual Doença Tinha O Cantor Netinho? Baiano Morreu Nesta Terça-feira (13), Aos 60 Anos
-------------------------------------------------------------------------------------

 ![Qual doença tinha o cantor Netinho? Baiano morreu nesta terça-feira (13), aos 60 anos](https://s2-oglobo.glbimg.com/nFvK1pHW1czJgdHby9H0v7gOqzE=/0x0:992x565/888x0/smart/filters:strip_icc()/i.s3.glbimg.com/v1/AUTH_da025474c0c44edd99332dddb09cabe8/internal_photos/bs/2026/3/A/qzi3SIQouMfOKIiS3ROQ/101805468-o-cantor-netinho-sucesso-dos-anos-90-com-o-hit-milla-se-manifestou-sobre-o-iate-club-de-ar.jpg) <small>oglobo.globo.com</small>Qual doença tinha o cantor Netinho? Baiano morreu nesta terça-feira (13), aos 60 anos

Morre Netinho: Relembre A Trajetória Do Cantor De 'Milla' E Um Dos Nomes Mais Marcantes Do Axé Music
----------------------------------------------------------------------------------------------------

 ![Morre Netinho: relembre a trajetória do cantor de 'Milla' e um dos nomes mais marcantes do axé music](https://s2-oglobo.glbimg.com/hQt7-xjh8cj8Ll6-op5ZPLw-sMc=/0x0:1322x916/888x0/smart/filters:strip_icc()/i.s3.glbimg.com/v1/AUTH_da025474c0c44edd99332dddb09cabe8/internal_photos/bs/2026/R/K/TK0v7KR7ALySewRF797A/40436667-0312.1998-divulgacao-cristian-gaul-ext-sx-cantor.jpg) <small>oglobo.globo.com</small>Morre Netinho: relembre a trajetória do cantor de 'Milla' e um dos nomes mais marcantes do axé music

Netinho, Cantor De 'Milla', Morre Aos 60 Anos
---------------------------------------------

 ![Netinho, cantor de 'Milla', morre aos 60 anos](https://billboard-com-br.s3.amazonaws.com/wp-content/uploads/2026/10/13111024/Netinho-durante-participacao-no-Altas-Horas-em-2014-Globo_Ze-Paulo-Cardeal.webp) <small>billboard.com.br</small>Netinho, cantor de 'Milla', morre aos 60 anos

Cantor Netinho Morre Aos 60 Anos Em Salvador | Radioagência Nacional
--------------------------------------------------------------------

 ![Cantor Netinho morre aos 60 anos em Salvador | Radioagência Nacional](https://imagens.ebc.com.br/MXzAb4BuYiqKcF5zQ7ml6hayZJ8=/1600x800/https://agenciabrasil.ebc.com.br/sites/default/files/thumbnails/image/2026/10/13/2025-12-05-073a9765-copy-69337a1291d.jpg?itok=iJtuS9wM) <small>agenciabrasil.ebc.com.br</small>Cantor Netinho morre aos 60 anos em Salvador | Radioagência Nacional

Fãs E Famosos Lamentam Morte De Netinho, Voz Do Hit 'Milla'; Claudia Leitte Se Despede: 'Meu Irmão'
---------------------------------------------------------------------------------------------------

 ![Fãs e famosos lamentam morte de Netinho, voz do hit 'Milla'; Claudia Leitte se despede: 'Meu irmão'](https://s2-quem.glbimg.com/oTIHIO0JeSwxuNVAKVmFH9tO2rY=/0x0:600x412/888x0/smart/filters:strip_icc()/i.s3.glbimg.com/v1/AUTH_b0f0e84207c948ab8b8777be5a6a4395/internal_photos/bs/2026/e/0/BWl2fLT5uEYr0cUeQw2g/e144ad910568db8308b009aaec9f2ac404c9-netinho.jpg) <small>revistaquem.globo.com</small>Fãs e famosos lamentam morte de Netinho, voz do hit 'Milla'; Claudia Leitte se despede: 'Meu irmão'

O Que Netinho Disse Antes De Morrer? Equipe Revela Mensagem Emocionante E Diz Que Cantor Já
-------------------------------------------------------------------------------------------

 ![O que Netinho disse antes de morrer? Equipe revela mensagem emocionante e diz que cantor já](https://midias.correio24horas.com.br/2026/10/13/netinho-3449073-article.webp) <small>www.correio24horas.com.br</small>O que Netinho disse antes de morrer? Equipe revela mensagem emocionante e diz que cantor já ...

Morre O Cantor Netinho, Aos 60 Anos
-----------------------------------

 ![Morre o cantor Netinho, aos 60 anos](https://conteudo.imguol.com.br/c/splash/4d/2026/10/13/netinho-cantor-do-hit-milla-1791901039989_v2_615x300.jpg) <small>www.uol.com.br</small>Morre o cantor Netinho, aos 60 anos

Cantor Netinho Morre Aos 60 Anos Após Longa Batalha Contra O Câncer
-------------------------------------------------------------------

 ![Cantor Netinho morre aos 60 anos após longa batalha contra o câncer](https://www.bnews.com.br/media/_versions/2026/10/image-2_widexl.png) <small>www.bnews.com.br</small>Cantor Netinho morre aos 60 anos após longa batalha contra o câncer

Relembre Carreira De Netinho, Cantor Do Hit "Milla", Que Morreu Aos 60 Anos | CNN Brasil
----------------------------------------------------------------------------------------

 ![Relembre carreira de Netinho, cantor do hit "Milla", que morreu aos 60 anos | CNN Brasil](https://admin.cnnbrasil.com.br/wp-content/uploads/sites/12/2026/10/netinho-1.jpg?w=1200&h=630&crop=1) <small>www.cnnbrasil.com.br</small>Relembre carreira de Netinho, cantor do hit "Milla", que morreu aos 60 anos | CNN Brasil

Morre Netinho: Cantor Se Declarou Bissexual Em 2008 E Causou Polêmica Ao Fazer Críticas à
-----------------------------------------------------------------------------------------

 ![Morre Netinho: cantor se declarou bissexual em 2008 e causou polêmica ao fazer críticas à](https://s2-oglobo.glbimg.com/rKTZ5RBFzuVI6U3qHF6T_B7HzGQ=/997x0/smart/filters:strip_icc()/i.s3.glbimg.com/v1/AUTH_da025474c0c44edd99332dddb09cabe8/internal_photos/bs/2026/h/w/SbIkyKQfyUnNXX66ybCw/40831331-2104.1997-divulgacao-pl-netinho-em-entrevista-ao-planeta-globo.jpg) <small>oglobo.globo.com</small>Morre Netinho: cantor se declarou bissexual em 2008 e causou polêmica ao fazer críticas à ...

Netinho: Cantor Morre Aos 60 Anos E Deixa Legado Em Sergipe | G1
----------------------------------------------------------------

 ![Netinho: cantor morre aos 60 anos e deixa legado em Sergipe | G1](https://s2-g1.glbimg.com/hw1ErGuaYEbWNYzSo3tzP5orIY8=/2048x0/filters:format(jpeg)/https://i.s3.glbimg.com/v1/AUTH_59edd422c0c84a879bd37670ae4f538a/internal_photos/bs/2026/2/h/AkJbDmQ1yrBGQMvAc5eA/planeta-xuxa-netinho-i0000955.t51d5eeea.m2048.xcwijizq-9otyqqlb.jfif) <small>g1.globo.com</small>Netinho: cantor morre aos 60 anos e deixa legado em Sergipe | G1

Quem Era Netinho, ícone Do Axé Music Que Morreu Aos 60 Anos | SBT News
----------------------------------------------------------------------

 ![Quem era Netinho, ícone do axé music que morreu aos 60 anos | SBT News](https://sbtnews.sbt.com.br/imagens/medium_netinho_assessoria_85732cd1a7.jpg) <small>sbtnews.sbt.com.br</small>Quem era Netinho, ícone do axé music que morreu aos 60 anos | SBT News

Netinho, Um Dos Principais Cantores Do Axé Music, Morre Aos 60 Anos | G1
------------------------------------------------------------------------

 ![Netinho, um dos principais cantores do axé music, morre aos 60 anos | G1](https://s04.video.glbimg.com/x240/13459539.jpg) <small>g1.globo.com</small>Netinho, um dos principais cantores do axé music, morre aos 60 anos | G1

Cantor Netinho, Do Hit "Milla", Deixa Uma Filha, Formada Em Medicina | CNN Brasil
---------------------------------------------------------------------------------

 ![Cantor Netinho, do hit "Milla", deixa uma filha, formada em medicina | CNN Brasil](https://admin.cnnbrasil.com.br/wp-content/uploads/sites/12/2025/04/cantor-netinho-alta.jpg?w=956&h=506&crop=1) <small>www.cnnbrasil.com.br</small>Cantor Netinho, do hit "Milla", deixa uma filha, formada em medicina | CNN Brasil

Ele Queria Muito Sobreviver #Netinho #cantor | Edson Manoel Martins Da Silva
----------------------------------------------------------------------------

 ![Ele queria muito sobreviver #Netinho #cantor | Edson Manoel Martins da Silva](https://lookaside.fbsbx.com/lookaside/crawler/media/?media_id=100004687000772) <small>www.facebook.com</small>Ele queria muito sobreviver #Netinho #cantor | Edson Manoel Martins da Silva

Morre Netinho: Cantor Se Declarou Bissexual Em 2008 E Causou Polêmica Ao Fazer Críticas à
-----------------------------------------------------------------------------------------

 ![Morre Netinho: cantor se declarou bissexual em 2008 e causou polêmica ao fazer críticas à](https://s2-oglobo.glbimg.com/0JqRj1nVw4LkVXTPZgl9sF6PtCk=/1586x0/smart/filters:strip_icc()/i.s3.glbimg.com/v1/AUTH_da025474c0c44edd99332dddb09cabe8/internal_photos/bs/2026/M/p/Gw8B6qS9eLdYabshGECg/40498665-09091998-divulgacao-arley-alves-tv-netinho-no-planeta-xuxa..jpg) <small>oglobo.globo.com</small>Morre Netinho: cantor se declarou bissexual em 2008 e causou polêmica ao fazer críticas à ...

Morre O Cantor Netinho, Um Dos Principais Nomes Do Axé, Aos 60 Anos
-------------------------------------------------------------------

 ![Morre o cantor Netinho, um dos principais nomes do axé, aos 60 anos](https://s2-extra.glbimg.com/Fi4iM-a-LNOlKJOjW6iF0RK3gHE=/0x0:2000x1194/888x0/smart/filters:strip_icc()/i.s3.glbimg.com/v1/AUTH_1f551ea7087a47f39ead75f64041559a/internal_photos/bs/2026/X/5/0il39ARi2JNg2tIwtEmw/arte-2026-10-13t110549.915.png) <small>extra.globo.com</small>Morre o cantor Netinho, um dos principais nomes do axé, aos 60 anos

Morre Netinho: Cantor Se Declarou Bissexual Em 2008 E Causou Polêmica Ao Fazer Críticas à
-----------------------------------------------------------------------------------------

 ![Morre Netinho: cantor se declarou bissexual em 2008 e causou polêmica ao fazer críticas à](https://s2-oglobo.glbimg.com/0t-_XHVreqGWN6MeZcn-vNMqyYs=/1080x0/smart/filters:strip_icc()/i.s3.glbimg.com/v1/AUTH_da025474c0c44edd99332dddb09cabe8/internal_photos/bs/2026/c/T/yv9qy6SLWf5dDLIKxdDw/2024-08-28-e1e34732-1d60-47f7-8ee4-435a46940aa7-66cfd8f6ed1.jpg) <small>oglobo.globo.com</small>Morre Netinho: cantor se declarou bissexual em 2008 e causou polêmica ao fazer críticas à ...

Morreu O Cantor Netinho, Voz Do êxito 'Milla', Vítima De Linfoma
----------------------------------------------------------------

 ![Morreu o cantor Netinho, voz do êxito 'Milla', vítima de linfoma](https://www.diarioaveiro.pt/wp-content/uploads/sites/6/2026/11/09112026-scaled.webp) <small>www.diarioaveiro.pt</small>Morreu o cantor Netinho, voz do êxito 'Milla', vítima de linfoma

Morreu O Cantor Brasileiro Netinho - CNN Portugal
-------------------------------------------------

 ![Morreu o cantor brasileiro Netinho - CNN Portugal](https://img.iol.pt/image/id/6ace3bfcd34e9a786e75bffd/1200.jpg) <small>cnnportugal.iol.pt</small>Morreu o cantor brasileiro Netinho - CNN Portugal

Morre Netinho: Cantor Se Declarou Bissexual Em 2008 E Causou Polêmica Ao Fazer Críticas à
-----------------------------------------------------------------------------------------

 ![Morre Netinho: cantor se declarou bissexual em 2008 e causou polêmica ao fazer críticas à](https://s2-oglobo.glbimg.com/Z65DQshbylhQcQ9VKDExj-zidb0=/1600x0/smart/filters:strip_icc()/i.s3.glbimg.com/v1/AUTH_da025474c0c44edd99332dddb09cabe8/internal_photos/bs/2026/3/a/Ue0vYCQ7aOKAAK6C6ouA/2024-08-28-e39e42af-15dc-4fbf-8122-0f87ba77944d-66cfd8f8496.jpg) <small>oglobo.globo.com</small>Morre Netinho: cantor se declarou bissexual em 2008 e causou polêmica ao fazer críticas à ...

Cantor Netinho Morre Aos 60 Anos Após Longa Batalha Contra O Câncer
-------------------------------------------------------------------

 ![Cantor Netinho morre aos 60 anos após longa batalha contra o câncer](https://www.bnews.com.br/media/uploads/marco_2025/netinho.jpg) <small>www.bnews.com.br</small>Cantor Netinho morre aos 60 anos após longa batalha contra o câncer

Morre o cantor netinho, ícone do carnaval baiano e pioneiro do axé music, aos 60 anos. Morreu o cantor brasileiro netinho, autor de mila. Fãs e famosos lamentam morte de netinho, voz do hit 'milla'; claudia leitte se despede: 'meu irmão'
