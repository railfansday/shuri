---
title: "Greve Geral 10 Dezembro - Greve geral de 11 de dezembro: impacto económico estimado e análise"
description: "Sindicatos independentes aderem à greve geral pela primeira vez e juntam-se à ugt e cgtp"
date: "2026-06-20"
categories:
- "Uncategorized"
images:
- "https://jundiagora.com.br/wp-content/uploads/2023/01/greve-geral.jpg"
featuredImage: "https://www.sindipublicos.com.br/wp-content/uploads/2021/12/age-site-1012.png"
featured_image: "https://www.spra.pt/wp-content/uploads/2025/10/cartaz-24-out-scaled.jpg"
image: "https://3.bp.blogspot.com/-Aefw3JPyG_E/WCN9dFbxNmI/AAAAAAAACHY/BT_1946qr3Ix5QI7iLpsXPttDd1yS9UjQCLcB/s1600/RUMO-A-GREVE-GERAL-01.jpg"
---

If you are looking for Greve geral histórica em Portugal paralisa transportes, fecha escolas e pressiona hospitais you've visit to the right page. We have 35 Pictures about Greve geral histórica em Portugal paralisa transportes, fecha escolas e pressiona hospitais like Greve geral deverá ter impacto inferior a 0,1% do PIB – ECO, Greve geral paralisa transportes, saúde e educação no Porto - Expresso and also Greve geral histórica em Portugal paralisa transportes, fecha escolas e pressiona hospitais. Here you go:

Greve Geral Histórica Em Portugal Paralisa Transportes, Fecha Escolas E Pressiona Hospitais
-------------------------------------------------------------------------------------------

 ![Greve geral histórica em Portugal paralisa transportes, fecha escolas e pressiona hospitais](https://s.rfi.fr/media/display/074d4efc-d66a-11f0-a540-005056bfb2b6/w:1024/p:16x9/AP25345021595048.jpg) <small>www.rfi.fr</small>Greve geral histórica em Portugal paralisa transportes, fecha escolas e pressiona hospitais ...

FAQ: Os Direitos Dos Docentes Em Dia De Greve Geral - 11/12/2025
----------------------------------------------------------------

 ![FAQ: Os direitos dos docentes em dia de Greve Geral - 11/12/2025](https://static.wixstatic.com/media/d0f32c_9ff1199ee2c34418af0094a43c516733~mv2.png/v1/fill/w_940,h_788,al_c,q_90,enc_avif,quality_auto/d0f32c_9ff1199ee2c34418af0094a43c516733~mv2.png) <small>www.sprc.pt</small>FAQ: Os direitos dos docentes em dia de Greve Geral - 11/12/2025

Greve Geral De 11 De Dezembro – UGT MADEIRA
-------------------------------------------

 ![Greve Geral de 11 de dezembro – UGT MADEIRA](https://www.ugt.pt/publicfiles/d0b1baa907190cd7253e353893dcc34837999b11.jpg) <small>ugtmadeira.pt</small>Greve Geral de 11 de dezembro – UGT MADEIRA

Mapa QZP Carenciados De 2025/26 – Despacho N.º 11200-A/2025 – Apoio à Deslocação – Sindicato S.TO.P.
----------------------------------------------------------------------------------------------------

 ![Mapa QZP carenciados de 2025/26 – Despacho n.º 11200-A/2025 – Apoio à deslocação – Sindicato S.TO.P.](https://stop-sindicato.pt/wp-content/uploads/2025/11/S.TO_.P.-Cartaz-Greve-Geral-Educacao-11Dez2025_x1000-768x1086.png) <small>stop-sindicato.pt</small>Mapa QZP carenciados de 2025/26 – Despacho n.º 11200-A/2025 – Apoio à deslocação – Sindicato S.TO.P.

SPN - Fenprof — Adesão Histórica à Greve Geral
----------------------------------------------

 ![SPN - Fenprof — Adesão histórica à greve geral](https://www.spn.pt/Media/Default/Info/68000/500/60/7/grevegeral11dez_cartaz.jpg) <small>www.spn.pt</small>SPN - Fenprof — Adesão histórica à greve geral

Prof. Anderson Freitas: PARALISAÇÃO 10 E 11 DE NOVEMBRO
-------------------------------------------------------

 ![Prof. Anderson Freitas: PARALISAÇÃO 10 E 11 DE NOVEMBRO](https://3.bp.blogspot.com/-Aefw3JPyG_E/WCN9dFbxNmI/AAAAAAAACHY/BT_1946qr3Ix5QI7iLpsXPttDd1yS9UjQCLcB/s1600/RUMO-A-GREVE-GERAL-01.jpg) <small>profandersonfreitas.blogspot.com</small>Prof. Anderson Freitas: PARALISAÇÃO 10 E 11 DE NOVEMBRO

Greve Geral Pode Custar Até 793 Milhões De Euros à Economia – Observador
------------------------------------------------------------------------

 ![Greve geral pode custar até 793 milhões de euros à economia – Observador](https://bordalo.observador.pt/v2/q:60/rs:fill:980/c:2000:1123:nowe:0:55/plain/https://s3.observador.pt/wp-content/uploads/2024/10/25202405/43796597.jpg) <small>observador.pt</small>Greve geral pode custar até 793 milhões de euros à economia – Observador

VISEU - Esclarecimento E Mobilização Para A Greve Geral Marcada Para 11 De Dezembro - CGTP-IN
---------------------------------------------------------------------------------------------

 ![VISEU - Esclarecimento e mobilização para a Greve Geral marcada para 11 de Dezembro - CGTP-IN](https://www.cgtp.pt/images/accao-e-luta/2025/gg.jpg) <small>www.cgtp.pt</small>VISEU - Esclarecimento e mobilização para a Greve Geral marcada para 11 de Dezembro - CGTP-IN

Greve Geral No Brasil: O Impacto E Relevância De 2023 – Bacana Notícias
-----------------------------------------------------------------------

 ![Greve Geral no Brasil: O Impacto e Relevância de 2023 – Bacana Notícias](https://bacana.news/wp-content/uploads/2025/10/greve-geral-7-905x613.jpeg) <small>bacana.news</small>Greve Geral no Brasil: O Impacto e Relevância de 2023 – Bacana Notícias

A Plataforma Já Marchavas Apoia A Greve Geral De 11 De Dezembro – Já Marchavas
------------------------------------------------------------------------------

 ![A Plataforma Já Marchavas apoia a Greve Geral de 11 de Dezembro – Já Marchavas](https://jamarchavas.pt/wp-content/uploads/2025/12/greve-geral-2025-1.jpg) <small>jamarchavas.pt</small>A Plataforma Já Marchavas apoia a Greve Geral de 11 de Dezembro – Já Marchavas

GREVE GERAL | 11 DEZEMBRO 2025 - ATE
------------------------------------

 ![GREVE GERAL | 11 DEZEMBRO 2025 - ATE](https://www.ate.pt/wp-content/uploads/2025/12/Greve-geral-11.12.jpg) <small>www.ate.pt</small>GREVE GERAL | 11 DEZEMBRO 2025 - ATE

Mais De 50 Sindicatos Aderem à Greve Geral Marcada Para 11 De Dezembro - SIC Notícias
-------------------------------------------------------------------------------------

 ![Mais de 50 sindicatos aderem à greve geral marcada para 11 de dezembro - SIC Notícias](https://images.impresa.pt/sicnot/2025-11-17-cgtp-pre-aviso-greve-82e19fc3-1/16x9/mw-1200) <small>sicnoticias.pt</small>Mais de 50 sindicatos aderem à greve geral marcada para 11 de dezembro - SIC Notícias

Greve Geral: Sindicato Dos Trabalhadores Em Funções Públicas Apela à Mobilização Para Dia 11 De
-----------------------------------------------------------------------------------------------

 ![Greve Geral: Sindicato dos Trabalhadores em Funções Públicas apela à mobilização para dia 11 de](https://acores.rtp.pt/wp-content/uploads/2025/11/greve_geral_11dez.jpg) <small>acores.rtp.pt</small>Greve Geral: Sindicato dos Trabalhadores em Funções Públicas apela à mobilização para dia 11 de ...

CGTP Garante Elevada Adesão à Greve Geral E Divulga Números: País Regista Fortes Perturbações
---------------------------------------------------------------------------------------------

 ![CGTP garante elevada adesão à greve geral e divulga números: país regista fortes perturbações](https://images.impresa.pt/expresso/2025-12-11-efeitos-da-greve-geral-em-cascais-0d35f268-1/1.91x1?wm=true&outputFormat=jpeg) <small>expresso.pt</small>CGTP garante elevada adesão à greve geral e divulga números: país regista fortes perturbações ...

Greve Geral: 10 Perguntas Essenciais Que Muitos Trabalhadores Ainda Fazem | E24.pt
----------------------------------------------------------------------------------

 ![Greve geral: 10 perguntas essenciais que muitos trabalhadores ainda fazem | e24.pt](https://e24.pt/wp-content/uploads/2025/12/Greve-geral-11-860x648.jpg) <small>e24.pt</small>Greve geral: 10 perguntas essenciais que muitos trabalhadores ainda fazem | e24.pt

Greve Geral De 11 De Dezembro: Impacto Económico Estimado E Análise | Economia
------------------------------------------------------------------------------

 ![Greve Geral de 11 de Dezembro: Impacto Económico Estimado e Análise | Economia](https://i.headtopics.com/images/2025/12/6/publico/greve-geral-o-que-e-quem-abrange-e-como-funciona-greve-geral-o-que-e-quem-abrange-e-como-funciona-43970BF408A401F542300934033BEA05.webp?w=640) <small>ph.headtopics.com</small>Greve Geral de 11 de Dezembro: Impacto Económico Estimado e Análise | Economia

Motivos Da Adesão à Greve Geral De 11 De Dezembro De 2025
---------------------------------------------------------

 ![Motivos da adesão à Greve Geral de 11 de dezembro de 2025](https://spzn.pt/uploads/noticias/big_1763717239_6728_SPZN_2025_site_novo_(17).png) <small>spzn.pt</small>Motivos da adesão à Greve Geral de 11 de dezembro de 2025

Amanhã Há Greve Da Função Pública (escolas Podem Fechar)
--------------------------------------------------------

 ![Amanhã há greve da função pública (escolas podem fechar)](https://jornaldemafra.pt/wp-content/uploads/2025/12/greve-geral.webp) <small>jornaldemafra.pt</small>Amanhã há greve da função pública (escolas podem fechar)

Greve Geral: Escolas Fechadas, Transportes Parados E Impacto Nacional
---------------------------------------------------------------------

 ![Greve Geral: Escolas Fechadas, Transportes Parados e Impacto Nacional](https://media.assettype.com/dn%2F2025-12-11%2F9hy4apil%2Fgreve-geral.jpg?w=768&auto=format%2Ccompress) <small>www.dn.pt</small>Greve Geral: Escolas Fechadas, Transportes Parados e Impacto Nacional

Greve Geral Vista Das Ruas: Manhã Cinzenta, Autocarros Vazios E Um País Que Abrandou O Passo
--------------------------------------------------------------------------------------------

 ![Greve geral vista das ruas: manhã cinzenta, autocarros vazios e um país que abrandou o passo](https://images.impresa.pt/expresso/2025-12-11-fox_greve_geral_0018.jpg-6e16cd12-1) <small>expresso.pt</small>Greve geral vista das ruas: manhã cinzenta, autocarros vazios e um país que abrandou o passo ...

Greve Geral Paralisa Portugal Contra Precarização De Direitos
-------------------------------------------------------------

 ![Greve geral paralisa Portugal contra precarização de direitos](https://horadopovo.com.br/wp-content/uploads/2025/12/Ruas-de-Lisboa-foram-tomadas-por-trabalhadores-durante-a-greve-geral-Rafael-Medeiros-Esquerda.jpg) <small>horadopovo.com.br</small>Greve geral paralisa Portugal contra precarização de direitos

🔴 Ao Minuto: Foi Assim A Greve Geral De 11 De Dezembro De 2025 - Renascença
---------------------------------------------------------------------------

 ![🔴 Ao minuto: Foi assim a greve geral de 11 de dezembro de 2025 - Renascença](https://images.rr.pt/geve-geral-de-11-de-dezembro-de-2025-na-assembleia-da-republica-foto-ricardo-fortunato-rr-31311c45c_socialshare.jpg) <small>rr.pt</small>🔴 Ao minuto: Foi assim a greve geral de 11 de dezembro de 2025 - Renascença

Greve Geral Marcada Para 11 De Dezembro, Contra O Pacote Laboral E A Política De Empobrecimento
-----------------------------------------------------------------------------------------------

 ![Greve Geral marcada para 11 de Dezembro, contra o pacote laboral e a política de empobrecimento](https://lookaside.fbsbx.com/lookaside/crawler/media/?media_id=1624831588881210&get_thumbnail=1) <small>www.facebook.com</small>Greve Geral marcada para 11 de Dezembro, contra o pacote laboral e a política de empobrecimento ...

SPN - Greve Geral (10/dez/2002)
-------------------------------

 ![SPN - Greve Geral (10/dez/2002)](https://www.spn.pt/Media/Default/_Profiles/5f2efba9/49dd7175/greve10dez2002.jpg?v=638628900774651037) <small>www.spn.pt</small>SPN - Greve Geral (10/dez/2002)

15 Minutos: Impacto Da Greve Geral Já Se Começou A Sentir No Setor Dos Transportes - SIC Notícias
-------------------------------------------------------------------------------------------------

 ![15 minutos: impacto da greve geral já se começou a sentir no setor dos transportes - SIC Notícias](https://images.impresa.pt/sicnot/2025-12-12-greve-geral-045a9380/1.91x1?wm=true&outputFormat=jpeg) <small>sicnoticias.pt</small>15 minutos: impacto da greve geral já se começou a sentir no setor dos transportes - SIC Notícias

Agora é GREVE GERAL!
--------------------

 ![Agora é GREVE GERAL!](https://jundiagora.com.br/wp-content/uploads/2023/01/greve-geral.jpg) <small>jundiagora.com.br</small>Agora é GREVE GERAL!

Greve Geral Paralisa Transportes, Saúde E Educação No Porto - Expresso
----------------------------------------------------------------------

 ![Greve geral paralisa transportes, saúde e educação no Porto - Expresso](https://images.impresa.pt/expresso/2025-12-11-rds_15_greve-geral-2025-manifestacao-porto_rds_4314.jpg-f75ffda9/original) <small>expresso.pt</small>Greve geral paralisa transportes, saúde e educação no Porto - Expresso

Greve Geral Deverá Ter Impacto Inferior A 0,1% Do PIB – ECO
-----------------------------------------------------------

 ![Greve geral deverá ter impacto inferior a 0,1% do PIB – ECO](https://eco.imgix.net/uploads/2025/12/cropped-46141990-scaled.jpg) <small>eco.sapo.pt</small>Greve geral deverá ter impacto inferior a 0,1% do PIB – ECO

Com Perdas De 55%, Servidores Discutirão Greve Em Assembleia Geral Dia 10 - Sindipublicos
-----------------------------------------------------------------------------------------

 ![Com perdas de 55%, servidores discutirão greve em Assembleia Geral dia 10 - Sindipublicos](https://www.sindipublicos.com.br/wp-content/uploads/2021/12/age-site-1012.png) <small>www.sindipublicos.com.br</small>Com perdas de 55%, servidores discutirão greve em Assembleia Geral dia 10 - Sindipublicos

Greve Geral. Metro De Lisboa Prevê Paralisação Do Serviço E Encerramento Das Estações – ECO
-------------------------------------------------------------------------------------------

 ![Greve Geral. Metro de Lisboa prevê paralisação do serviço e encerramento das estações – ECO](https://eco.imgix.net/uploads/2025/12/thumb-1.jpg) <small>eco.sapo.pt</small>Greve Geral. Metro de Lisboa prevê paralisação do serviço e encerramento das estações – ECO

UGT Vai Reunir-se Com Ministra Do Trabalho Mas Avisa Que "é Impossível Negociar" Sozinha A
------------------------------------------------------------------------------------------

 ![UGT vai reunir-se com ministra do Trabalho mas avisa que "é impossível negociar" sozinha a](https://img.iol.pt/image/id/693b2a1ad34e3caad84c47e9/1024.jpg) <small>cnnportugal.iol.pt</small>UGT vai reunir-se com ministra do Trabalho mas avisa que "é impossível negociar" sozinha a ...

Sindicatos Independentes Aderem à Greve Geral Pela Primeira Vez E Juntam-se à UGT E CGTP - Expresso
---------------------------------------------------------------------------------------------------

 ![Sindicatos independentes aderem à greve geral pela primeira vez e juntam-se à UGT e CGTP - Expresso](https://images.impresa.pt/expresso/2025-11-27-greve-geral-anuncio-para-a-realizacao-de-greve-a-11-de-dezembro-marques-pombal--9b289114/original) <small>expresso.pt</small>Sindicatos independentes aderem à greve geral pela primeira vez e juntam-se à UGT e CGTP - Expresso

UGT - UGT Convoca Greve Geral Para 11 De Dezembro De 2025
---------------------------------------------------------

 ![UGT - UGT convoca Greve Geral para 11 de dezembro de 2025](https://www.ugt.pt/publicfiles/dvc3keu4ex9l4e2fizbuignqdef3jdmrhdwzogyd.png) <small>www.ugt.pt</small>UGT - UGT convoca Greve Geral para 11 de dezembro de 2025

Greve Nacional | 24 De Outubro - SPRA
-------------------------------------

 ![Greve Nacional | 24 de outubro - SPRA](https://www.spra.pt/wp-content/uploads/2025/10/cartaz-24-out-scaled.jpg) <small>www.spra.pt</small>Greve Nacional | 24 de outubro - SPRA

Explicador: Sindicatos Esperam Paralisação "ainda Maior" Do Que Em Dezembro. O Que Motiva A
-------------------------------------------------------------------------------------------

 ![Explicador: Sindicatos esperam paralisação "ainda maior" do que em dezembro. O que motiva a](https://executivedigest.b-cdn.net/wp-content/uploads/2026/06/greve-geral.png) <small>executivedigest.sapo.pt</small>Explicador: Sindicatos esperam paralisação "ainda maior" do que em dezembro. O que motiva a ...

Greve geral. Mais de 50 sindicatos aderem à greve geral marcada para 11 de dezembro. Explicador: sindicatos esperam paralisação "ainda maior" do que em dezembro. o que motiva a ...
