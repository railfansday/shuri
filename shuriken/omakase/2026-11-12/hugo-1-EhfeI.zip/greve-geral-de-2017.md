---
title: "Greve Geral De 2017 - Paralisação: acompanhe a situação das principais capitais"
description: "Greve geral 1"
date: "2025-12-01"
categories:
- "Uncategorized"
images:
- "https://1.bp.blogspot.com/-gBgMWL-DhcA/WQTkQFLyCeI/AAAAAAAAFWU/mVvZh9GUclASUVuUEhzzx8e_7TpVBIgSQCLcB/w1200-h630-p-k-no-nu/IMG_7327.JPG"
featuredImage: "https://uploads.polemicaparaiba.com.br/2017/04/GREVE-5.jpeg"
featured_image: "https://3.bp.blogspot.com/-7w814xFAmn4/WQi4ydb6P-I/AAAAAAAAM4A/EdJQpAW5VEoR9ybwF2kK2YRk7SN-dezVACLcB/s1600/34288847666_080b6a2f46_o.jpg"
image: "https://uploads.polemicaparaiba.com.br/2017/04/GREVE-5.jpeg"
---

If you are looking for As imagens da Greve Geral pelo Brasil, em 28 de abril de 2017, que vão entrar para a História you've visit to the right page. We have 35 Images about As imagens da Greve Geral pelo Brasil, em 28 de abril de 2017, que vão entrar para a História like Greve geral nesta sexta? Veja quais categorias já decidiram parar - 29/06/2017 - UOL Notícias, Raquel Montero: 28 de abril de 2017, dia da maior greve geral da história do Brasil and also Sem motoristas e ferroviários, centrais marcam greve para 30/06 | VEJA. Here it is:

As Imagens Da Greve Geral Pelo Brasil, Em 28 De Abril De 2017, Que Vão Entrar Para A História
---------------------------------------------------------------------------------------------

 ![As imagens da Greve Geral pelo Brasil, em 28 de abril de 2017, que vão entrar para a História](https://uploads.polemicaparaiba.com.br/2017/04/GREVE-5.jpeg) <small>www.polemicaparaiba.com.br</small>As imagens da Greve Geral pelo Brasil, em 28 de abril de 2017, que vão entrar para a História ...

Greve Paralisa Transporte No Brasil, Esvazia SP, Mas Governo Minimiza Atos - 28/04/2017 - UOL
---------------------------------------------------------------------------------------------

 ![Greve paralisa transporte no Brasil, esvazia SP, mas governo minimiza atos - 28/04/2017 - UOL](http://conteudo.imguol.com.br/c/noticias/86/2017/04/28/28abr2017---manifestantes-fazem-passeata-nas-rua-de-salvador-na-regiao-do-campo-grande-nesta-sexta-feira-em-protesto-contra-as-reformas-do-governo-1493414072913_1280x960.jpg) <small>noticias.uol.com.br</small>Greve paralisa transporte no Brasil, esvazia SP, mas governo minimiza atos - 28/04/2017 - UOL ...

Sem Motoristas E Ferroviários, Centrais Marcam Greve Para 30/06 | VEJA
----------------------------------------------------------------------

 ![Sem motoristas e ferroviários, centrais marcam greve para 30/06 | VEJA](https://veja.abril.com.br/wp-content/uploads/2017/04/img-20170428-wa0013.jpg?quality=70&strip=info&w=1280&h=720&crop=1) <small>veja.abril.com.br</small>Sem motoristas e ferroviários, centrais marcam greve para 30/06 | VEJA

DA LUTA NÃO ARREDO O PÉ!: Galeria De Imagens - Esquenta Da Greve Geral
----------------------------------------------------------------------

 ![DA LUTA NÃO ARREDO O PÉ!: Galeria de imagens - Esquenta da Greve Geral](https://farm5.static.flickr.com/4231/34591046544_3892eb53bd_b.jpg) <small>eduardovasconcelos2016.blogspot.com</small>DA LUTA NÃO ARREDO O PÉ!: Galeria de imagens - Esquenta da Greve Geral

Raquel Montero: 28 De Abril De 2017, Dia Da Maior Greve Geral Da História Do Brasil
-----------------------------------------------------------------------------------

 ![Raquel Montero: 28 de abril de 2017, dia da maior greve geral da história do Brasil](https://1.bp.blogspot.com/-gBgMWL-DhcA/WQTkQFLyCeI/AAAAAAAAFWU/mVvZh9GUclASUVuUEhzzx8e_7TpVBIgSQCLcB/w1200-h630-p-k-no-nu/IMG_7327.JPG) <small>raquelbencsikmontero.blogspot.com</small>Raquel Montero: 28 de abril de 2017, dia da maior greve geral da história do Brasil

DA LUTA NÃO ARREDO O PÉ!: Galeria De Imagens - Esquenta Da Greve Geral
----------------------------------------------------------------------

 ![DA LUTA NÃO ARREDO O PÉ!: Galeria de imagens - Esquenta da Greve Geral](https://farm5.static.flickr.com/4284/35393478616_3e1f49d9f8_b.jpg) <small>eduardovasconcelos2016.blogspot.com</small>DA LUTA NÃO ARREDO O PÉ!: Galeria de imagens - Esquenta da Greve Geral

Greve Geral: O Que Você Precisa Saber Sobre A Tentativa De Parar O País Pela 1ª Vez Em 20 Anos
----------------------------------------------------------------------------------------------

 ![Greve geral: o que você precisa saber sobre a tentativa de parar o país pela 1ª vez em 20 anos](http://f.i.uol.com.br/folha/mercado/images/17117165.jpeg) <small>www1.folha.uol.com.br</small>Greve geral: o que você precisa saber sobre a tentativa de parar o país pela 1ª vez em 20 anos ...

Greve Geral | VEJA
------------------

 ![Greve Geral | VEJA](https://veja.abril.com.br/wp-content/uploads/2017/04/brasil-greve-rj-20170428-002.jpg?quality=90&strip=info&w=920&w=636) <small>veja.abril.com.br</small>Greve Geral | VEJA

DA LUTA NÃO ARREDO O PÉ!: Galeria De Imagens - Esquenta Da Greve Geral
----------------------------------------------------------------------

 ![DA LUTA NÃO ARREDO O PÉ!: Galeria de imagens - Esquenta da Greve Geral](https://farm5.static.flickr.com/4262/34591048954_a2f60a7941_b.jpg) <small>eduardovasconcelos2016.blogspot.com</small>DA LUTA NÃO ARREDO O PÉ!: Galeria de imagens - Esquenta da Greve Geral

DA LUTA NÃO ARREDO O PÉ!: Galeria De Imagens - Esquenta Da Greve Geral
----------------------------------------------------------------------

 ![DA LUTA NÃO ARREDO O PÉ!: Galeria de imagens - Esquenta da Greve Geral](https://farm5.static.flickr.com/4224/35303351751_2e680fa603_b.jpg) <small>eduardovasconcelos2016.blogspot.com</small>DA LUTA NÃO ARREDO O PÉ!: Galeria de imagens - Esquenta da Greve Geral

Greve Geral Nesta Sexta? Veja Quais Categorias Já Decidiram Parar - 29/06/2017 - UOL Notícias
---------------------------------------------------------------------------------------------

 ![Greve geral nesta sexta? Veja quais categorias já decidiram parar - 29/06/2017 - UOL Notícias](https://conteudo.imguol.com.br/c/noticias/fa/2017/05/18/18mai2017---manifestantes-levam-bandeira-em-defesa-de-uma-greve-geral-durante-o-protesto-contra-o-presidente-michel-temer-na-avenida-paulista-em-sao-paulo-1495156255585_615x300.jpg) <small>noticias.uol.com.br</small>Greve geral nesta sexta? Veja quais categorias já decidiram parar - 29/06/2017 - UOL Notícias

Paralisação: Acompanhe A Situação Das Principais Capitais - ISTOÉ Independente
------------------------------------------------------------------------------

 ![Paralisação: acompanhe a situação das principais capitais - ISTOÉ Independente](https://istoe.com.br/wp-content/uploads/2017/06/greve-geral-30-junho.jpg) <small>istoe.com.br</small>Paralisação: acompanhe a situação das principais capitais - ISTOÉ Independente

Greve Geral 1 - Sindicato Dos Químicos De São Paulo
---------------------------------------------------

 ![Greve Geral 1 - Sindicato dos Químicos de São Paulo](https://quimicosp.org.br/wp-content/uploads/2017/04/greve-geral-1-8.jpg) <small>quimicosp.org.br</small>Greve Geral 1 - Sindicato dos Químicos de São Paulo

Greve Geral: O Que Você Precisa Saber Sobre A Tentativa De Parar O País Pela 1ª Vez Em 20 Anos
----------------------------------------------------------------------------------------------

 ![Greve geral: o que você precisa saber sobre a tentativa de parar o país pela 1ª vez em 20 anos](https://conteudo.imguol.com.br/c/noticias/56/2017/03/31/31mar2017---durante-protesto-contra-a-reforma-da-previdencia-na-candelaria-rio-de-janeiro-manifestantes-convocam-para-greve-geral-em-abril-1490992452526_615x300.jpg) <small>noticias.uol.com.br</small>Greve geral: o que você precisa saber sobre a tentativa de parar o país pela 1ª vez em 20 anos ...

Às Vésperas Da Greve Geral, Centrais Sindicais Apostam Na Unidade Contra Bolsonaro | Brasil De Fato
---------------------------------------------------------------------------------------------------

 ![Às vésperas da Greve Geral, centrais sindicais apostam na unidade contra Bolsonaro | Brasil de Fato](https://www.brasildefato.com.br/wp-content/uploads/2024/09/image_processing20200201-29235-147ar1k.jpg) <small>www.brasildefato.com.br</small>Às vésperas da Greve Geral, centrais sindicais apostam na unidade contra Bolsonaro | Brasil de Fato

Greve Geral 1 - Sindicato Dos Químicos De São Paulo
---------------------------------------------------

 ![Greve Geral 1 - Sindicato dos Químicos de São Paulo](https://quimicosp.org.br/wp-content/uploads/2017/04/greve-geral-1-7.jpg) <small>quimicosp.org.br</small>Greve Geral 1 - Sindicato dos Químicos de São Paulo

Greve Geral Dia 28 Abril 2017
-----------------------------

 ![Greve Geral dia 28 abril 2017](https://sintramb.com.br/imgs/galeria/656291012149f83bdb6ab64986a654b4.jpg) <small>sintramb.com.br</small>Greve Geral dia 28 abril 2017

Greve Geral, 30 De Junho De 2017
--------------------------------

 ![Greve Geral, 30 de junho de 2017](https://sindipetro.org.br/wp-content/uploads/2017/07/Samuel-Tostad750_99687-Copia.jpg) <small>sindipetro.org.br</small>Greve Geral, 30 de junho de 2017

DA LUTA NÃO ARREDO O PÉ!: Galeria De Imagens - Esquenta Da Greve Geral
----------------------------------------------------------------------

 ![DA LUTA NÃO ARREDO O PÉ!: Galeria de imagens - Esquenta da Greve Geral](https://farm5.static.flickr.com/4281/35046025470_577a163e9f_b.jpg) <small>eduardovasconcelos2016.blogspot.com</small>DA LUTA NÃO ARREDO O PÉ!: Galeria de imagens - Esquenta da Greve Geral

As Imagens Da Greve Geral Pelo Brasil, Em 28 De Abril De 2017, Que Vão Entrar Para A História
---------------------------------------------------------------------------------------------

 ![As imagens da Greve Geral pelo Brasil, em 28 de abril de 2017, que vão entrar para a História](https://uploads.polemicaparaiba.com.br/2017/04/GREVE-4.jpeg) <small>www.polemicaparaiba.com.br</small>As imagens da Greve Geral pelo Brasil, em 28 de abril de 2017, que vão entrar para a História ...

Greve Geral | VEJA
------------------

 ![Greve Geral | VEJA](https://veja.abril.com.br/wp-content/uploads/2017/04/greve-geral-curitiba-22.jpg?quality=70&strip=info&w=920) <small>veja.abril.com.br</small>Greve Geral | VEJA

GREVE GERAL PARECE SER O COMEÇO DE UMA NOVA REVOLTA POPULAR
-----------------------------------------------------------

 ![GREVE GERAL PARECE SER O COMEÇO DE UMA NOVA REVOLTA POPULAR](https://4.bp.blogspot.com/-z6_VAOuHbzs/WQNYYslsnvI/AAAAAAAAMJw/qmhmTxL-Ijkrb7-DcqV9ObkPZYtU9d55ACLcB/w1200-h630-p-k-no-nu/greve-geral-protesto-em-frente-a-estacao-das-barcas-praca-arariboia-niteroi-28-04-2017_foto-rebeca-letieri-jornal-do-brasil.jpg) <small>linhacaatomica.blogspot.com</small>GREVE GERAL PARECE SER O COMEÇO DE UMA NOVA REVOLTA POPULAR

DA LUTA NÃO ARREDO O PÉ!: Galeria De Imagens - Esquenta Da Greve Geral
----------------------------------------------------------------------

 ![DA LUTA NÃO ARREDO O PÉ!: Galeria de imagens - Esquenta da Greve Geral](https://farm5.static.flickr.com/4289/35303352401_5fb00efbc8_b.jpg) <small>eduardovasconcelos2016.blogspot.com</small>DA LUTA NÃO ARREDO O PÉ!: Galeria de imagens - Esquenta da Greve Geral

40 Milhões Param Na Greve Geral Contra As Reformas Do Governo - A Verdade
-------------------------------------------------------------------------

 ![40 milhões param na Greve Geral contra as reformas do Governo - A Verdade](https://averdade.org.br/wp-content/uploads/2017/05/greve-geral-2017-recife.jpg) <small>averdade.org.br</small>40 milhões param na Greve Geral contra as reformas do Governo - A Verdade

\#GreveGeral • 28/04/2017 • São Paulo (SP) | A Greve Geral Pa… | Flickr
-----------------------------------------------------------------------

 ![#GreveGeral • 28/04/2017 • São Paulo (SP) | A Greve Geral pa… | Flickr](https://live.staticflickr.com/2814/33990694400_0f703d889e_b.jpg) <small>www.flickr.com</small>\#GreveGeral • 28/04/2017 • São Paulo (SP) | A Greve Geral pa… | Flickr

\#28A: Greve Geral De 2017 Foi A Maior Da História Do Brasil – Sindimovec
-------------------------------------------------------------------------

 ![#28A: Greve Geral de 2017 foi a maior da história do Brasil – Sindimovec](https://www.sindimovec.com.br/wp-content/uploads/2017/04/02sitesite.jpg) <small>www.sindimovec.com.br</small>\#28A: Greve Geral de 2017 foi a maior da história do Brasil – Sindimovec

Dez Textos Para Entender O Que Está Em Jogo Na Greve Geral Do País - 28/04/2017 - UOL Notícias
----------------------------------------------------------------------------------------------

 ![Dez textos para entender o que está em jogo na greve geral do país - 28/04/2017 - UOL Notícias](https://conteudo.imguol.com.br/c/noticias/12/2017/04/28/28abr2017---um-grupo-de-motoboys-circulou-por-importantes-vias-da-cidade-de-sao-paulo-em-adesao-a-greve-geral-convocada-por-sindicatos-de-trabalhadores-nesta-sexta-feira-1493407239259_615x300.jpg) <small>noticias.uol.com.br</small>Dez textos para entender o que está em jogo na greve geral do país - 28/04/2017 - UOL Notícias

Raquel Montero: 28 De Abril De 2017, Dia Da Maior Greve Geral Da História Do Brasil
-----------------------------------------------------------------------------------

 ![Raquel Montero: 28 de abril de 2017, dia da maior greve geral da história do Brasil](https://3.bp.blogspot.com/-xsqXQD2vT0U/WQThuk7mU9I/AAAAAAAAFV0/WWQnj9PZYL00eRwBVMITvY0hSVnBbUYDgCLcB/s1600/IMG_7093.JPG) <small>raquelbencsikmontero.blogspot.com</small>Raquel Montero: 28 de abril de 2017, dia da maior greve geral da história do Brasil

Greve Geral: Saiba O Que Vai Parar No Dia 28 De Abril, No Rio De Janeiro - Esquerda Online
------------------------------------------------------------------------------------------

 ![Greve Geral: saiba o que vai parar no dia 28 de abril, no Rio de Janeiro - Esquerda Online](https://esquerdaonline.com.br/wp-content/uploads/2017/04/greve-geral-1024x587.jpg) <small>esquerdaonline.com.br</small>Greve Geral: saiba o que vai parar no dia 28 de abril, no Rio de Janeiro - Esquerda Online

Greve Geral, 30 De Junho De 2017
--------------------------------

 ![Greve Geral, 30 de junho de 2017](https://sindipetro.org.br/wp-content/uploads/2017/07/Samuel-Tostad750_99649-Copia.jpg) <small>sindipetro.org.br</small>Greve Geral, 30 de junho de 2017

Dia 28 O Brasil Parou! Agora Vamos Ocupar Brasília E Preparar Uma Greve Geral De 48 Horas
-----------------------------------------------------------------------------------------

 ![Dia 28 o Brasil parou! Agora vamos ocupar Brasília e preparar uma Greve Geral de 48 horas](https://3.bp.blogspot.com/-7w814xFAmn4/WQi4ydb6P-I/AAAAAAAAM4A/EdJQpAW5VEoR9ybwF2kK2YRk7SN-dezVACLcB/s1600/34288847666_080b6a2f46_o.jpg) <small>pstuvale.blogspot.com</small>Dia 28 o Brasil parou! Agora vamos ocupar Brasília e preparar uma Greve Geral de 48 horas

Imprensa Internacional Destaca Brasil; BBC Vê 1ª Greve Geral Em Mais De 2 Décadas - Pequenas
--------------------------------------------------------------------------------------------

 ![Imprensa internacional destaca Brasil; BBC vê 1ª greve geral em mais de 2 décadas - Pequenas](https://s2.glbimg.com/ZUv7xxUmP55dYzk4H9ue63xjTm0=/940x523/e.glbimg.com/og/ed/f/original/2017/04/28/33337301181_5a55568819_k.jpg) <small>revistapegn.globo.com</small>Imprensa internacional destaca Brasil; BBC vê 1ª greve geral em mais de 2 décadas - Pequenas ...

Greve Geral, 30 De Junho De 2017
--------------------------------

 ![Greve Geral, 30 de junho de 2017](https://sindipetro.org.br/wp-content/uploads/2017/07/Samuel-Tostad750_99822-Copia.jpg) <small>sindipetro.org.br</small>Greve Geral, 30 de junho de 2017

Greve Geral . BH . Abr 2017 01
------------------------------

 ![Greve Geral . BH . Abr 2017 01](https://i.pinimg.com/originals/d8/7a/29/d87a2941343d66815d0401f76e917374.jpg) <small>www.pinterest.com</small>Greve Geral . BH . Abr 2017 01

Greve Geral – 30 De Junho – SEEB Santos E Região
------------------------------------------------

 ![Greve Geral – 30 de junho – SEEB Santos e Região](https://santosbancarios.com.br/wp-content/uploads/images/2017/06/greve-geral-30-de-junho-1498846455.jpg) <small>santosbancarios.com.br</small>Greve Geral – 30 de junho – SEEB Santos e Região

Da luta não arredo o pé!: galeria de imagens. Greve geral 1. As imagens da greve geral pelo brasil, em 28 de abril de 2017, que vão entrar para a história ...
