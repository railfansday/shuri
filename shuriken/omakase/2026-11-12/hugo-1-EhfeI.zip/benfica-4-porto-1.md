---
title: "Benfica 4 Porto 1 - Fc porto 1-4 benfica, liga portugal betclic (ex liga nos) : résumé du match (06/04/2025)"
description: "Fc porto 1-4 benfica, liga portugal betclic (ex liga nos) : résumé du match (06/04/2025)"
date: "2026-08-28"
categories:
- "Uncategorized"
images:
- "https://i.ytimg.com/vi/apz8vgKNRNM/maxresdefault.jpg"
featuredImage: "https://goalpoint.pt/wp-content/uploads/2024/11/GoalPoint-2024-11-10-Benfica-Porto-Primeira-Liga-202425-90m.jpg"
featured_image: "https://www.lequipe.fr/_medias/img-photo-jpg/soccer-football-primeira-liga-fc-porto-v-benfica-estadio-do-dragao-porto-portugal-april-6-2025-benfi/1500000002176733/39:0,1943:1904-824-824-75/4953a.jpg"
image: "https://i.ytimg.com/vi/743Yrq6L2Pc/maxresdefault.jpg"
---

If you are looking for BENFICA, 4 — FC PORTO, 1: ‘Encarnados’ goleiam com ‘bis’ de Di María - LusoAmericano you've visit to the right place. We have 35 Images about BENFICA, 4 — FC PORTO, 1: ‘Encarnados’ goleiam com ‘bis’ de Di María - LusoAmericano like Benfica humble Porto with 4-1 thrashing at the Luz | OneFootball, Benfica humble Porto with 4-1 thrashing at the Luz - portugoal.net and also BENFICA, 4 — FC PORTO, 1: ‘Encarnados’ goleiam com ‘bis’ de Di María - LusoAmericano. Read more:

BENFICA, 4 — FC PORTO, 1: ‘Encarnados’ Goleiam Com ‘bis’ De Di María - LusoAmericano
------------------------------------------------------------------------------------

 ![BENFICA, 4 — FC PORTO, 1: ‘Encarnados’ goleiam com ‘bis’ de Di María - LusoAmericano](https://lusoamericano.com/wp-content/uploads/2024/11/Benfica-vs-FC-Porto-scaled-e1731438176146-1200x540.jpg) <small>lusoamericano.com</small>BENFICA, 4 — FC PORTO, 1: ‘Encarnados’ goleiam com ‘bis’ de Di María - LusoAmericano

FC Porto 1-4 Benfica
--------------------

 ![FC Porto 1-4 Benfica](https://organizer-assets.vsports.pt/media/game_cover/Foto_5_4_copiar.webp) <small>vsports.pt</small>FC Porto 1-4 Benfica

Benfica Humble Porto With 4-1 Thrashing At The Luz - Portugoal.net
------------------------------------------------------------------

 ![Benfica humble Porto with 4-1 thrashing at the Luz - portugoal.net](https://portugoal.net/images/Benfica/Di-Maria-v-Porto-Luz-20241110.jpg) <small>portugoal.net</small>Benfica humble Porto with 4-1 thrashing at the Luz - portugoal.net

BENFICA 4 PORTO 1 E PARTE FINAL DO JOGO DO SPORTING - YouTube
-------------------------------------------------------------

 ![BENFICA 4 PORTO 1 E PARTE FINAL DO JOGO DO SPORTING - YouTube](https://i.ytimg.com/vi/4SLgW6nQbvY/maxresdefault.jpg?sqp=-oaymwEmCIAKENAF8quKqQMa8AEB-AH-CYAC0AWKAgwIABABGGUgZShlMA8=&rs=AOn4CLC0jizkkZumcMBCLHoNiCJOVJdvFg) <small>www.youtube.com</small>BENFICA 4 PORTO 1 E PARTE FINAL DO JOGO DO SPORTING - YouTube

Benfica Humilie Porto (4-1) : Di Maria Brille Au Clássico - JustFootball : Toute L'Actu Du
------------------------------------------------------------------------------------------

 ![Benfica humilie Porto (4-1) : Di Maria brille au Clássico - JustFootball : Toute l'Actu du](https://justfootball.fr/wp-content/uploads/2024/12/Benfica-humilie-Porto-4-1-Di-Maria-brille-au-Classico-Benfica-Porto.jpeg) <small>justfootball.fr</small>Benfica humilie Porto (4-1) : Di Maria brille au Clássico - JustFootball : Toute l'Actu du ...

FC Porto, 1 – Benfica, 4 – No Aproveitar Esteve O Ganho… | O Cidadão
--------------------------------------------------------------------

 ![FC Porto, 1 – Benfica, 4 – No aproveitar esteve o ganho… | O Cidadão](https://ocidadao.pt/wp-content/uploads/2025/04/FC-P-Benfica-10-1024x682.jpg) <small>ocidadao.pt</small>FC Porto, 1 – Benfica, 4 – No aproveitar esteve o ganho… | O Cidadão

FC Porto 1-4 Benfica, Liga Portugal Betclic (ex Liga Nos) : Résumé Du Match (06/04/2025)
----------------------------------------------------------------------------------------

 ![FC Porto 1-4 Benfica, Liga Portugal Betclic (ex Liga Nos) : résumé du match (06/04/2025)](https://www.lequipe.fr/_medias/img-photo-jpg/soccer-football-primeira-liga-fc-porto-v-benfica-estadio-do-dragao-porto-portugal-april-6-2025-benfi/1500000002176733/0:0,2500:1150-1305-600-75/b1c3c.jpg) <small>www.lequipe.fr</small>FC Porto 1-4 Benfica, Liga Portugal Betclic (ex Liga Nos) : résumé du match (06/04/2025)

A Luz Que Ofuscou O Dragão | Benfica 4-1 FC Porto
-------------------------------------------------

 ![A Luz que ofuscou o Dragão | Benfica 4-1 FC Porto](https://bolanarede.pt/wp-content/uploads/2024/11/Alvaro-Carreras-Benfica-Jogadores-1.jpg) <small>bolanarede.pt</small>A Luz que ofuscou o Dragão | Benfica 4-1 FC Porto

Os Segredos Do🔴 BENFICA 4-1 PORTO 🔵 As 5 Razões Que Levaram à Goleada Do Benfica Frente Ao Porto
------------------------------------------------------------------------------------------------

 ![Os segredos do🔴 BENFICA 4-1 PORTO 🔵 As 5 razões que levaram à goleada do Benfica frente ao Porto](https://i.ytimg.com/vi/743Yrq6L2Pc/maxresdefault.jpg) <small>www.youtube.com</small>Os segredos do🔴 BENFICA 4-1 PORTO 🔵 As 5 razões que levaram à goleada do Benfica frente ao Porto ...

🔵 PORTO 1-4 BENFICA 🔴 Goleada Histórica: As Razões Que Levaram à Goleada Do Benfica Frente Ao
---------------------------------------------------------------------------------------------

 ![🔵 PORTO 1-4 BENFICA 🔴 Goleada histórica: as razões que levaram à goleada do Benfica frente ao](https://i.ytimg.com/vi/2cloYV8ewB0/maxresdefault.jpg) <small>www.youtube.com</small>🔵 PORTO 1-4 BENFICA 🔴 Goleada histórica: as razões que levaram à goleada do Benfica frente ao ...

17.214 Benfica Porto Stock Photos, High-Res Pictures, And Images - Getty Images
-------------------------------------------------------------------------------

 ![17.214 Benfica Porto Stock Photos, High-Res Pictures, and Images - Getty Images](https://media.gettyimages.com/id/2183468582/pt/foto/lisbon-portugal-a-stadium-scoreboard-shows-a-match-result-benfica-4-1-fc-porto-during-the-liga.jpg?s=612x612&w=gi&k=20&c=e2Wp6Jbvx5GiZ0Cj6U-6EVk2L3rvGK2ebzh2ITPHOAk=) <small>www.gettyimages.pt</small>17.214 Benfica Porto Stock Photos, High-Res Pictures, and Images - Getty Images

🔴 BENFICA 4-1 AVS 🔴 (ANÁLISE) Benfica Garante A Final Four Da Taça Da Liga Com Goleada! (1.ª
--------------------------------------------------------------------------------------------

 ![🔴 BENFICA 4-1 AVS 🔴 (ANÁLISE) Benfica garante a final four da Taça da Liga com goleada! (1.ª](https://i.ytimg.com/vi/slgXoZT9geg/maxresdefault.jpg) <small>www.youtube.com</small>🔴 BENFICA 4-1 AVS 🔴 (ANÁLISE) Benfica garante a final four da Taça da Liga com goleada! (1.ª ...

🔴 BENFICA 4-1 PORTO 🔵 (Análise) BENFICA AVASSALADOR GOLEIA O PORTO NA LUZ! - YouTube
------------------------------------------------------------------------------------

 ![🔴 BENFICA 4-1 PORTO 🔵 (Análise) BENFICA AVASSALADOR GOLEIA O PORTO NA LUZ! - YouTube](https://i.ytimg.com/vi/apz8vgKNRNM/maxresdefault.jpg) <small>www.youtube.com</small>🔴 BENFICA 4-1 PORTO 🔵 (Análise) BENFICA AVASSALADOR GOLEIA O PORTO NA LUZ! - YouTube

Benfica 🆚 Porto | “Chocolate” Argentino Em Goleada Da águia | GoalPoint
-----------------------------------------------------------------------

 ![Benfica 🆚 Porto | “Chocolate” argentino em goleada da águia | GoalPoint](https://goalpoint.pt/wp-content/uploads/2024/11/GoalPoint-2024-11-10-Benfica-Porto-Primeira-Liga-202425-90m.jpg) <small>goalpoint.pt</small>Benfica 🆚 Porto | “Chocolate” argentino em goleada da águia | GoalPoint

Porto Vs Benfica (4-1) | HIGHLIGHTS FINAL PLAY OFF CN PLACARD - YouTube
-----------------------------------------------------------------------

 ![Porto vs Benfica (4-1) | HIGHLIGHTS FINAL PLAY OFF CN PLACARD - YouTube](https://i.ytimg.com/vi/PjMQTXy_290/maxresdefault.jpg) <small>www.youtube.com</small>Porto vs Benfica (4-1) | HIGHLIGHTS FINAL PLAY OFF CN PLACARD - YouTube

Benfica 4-1 Porto | MAÇ SONUCU - ÖZET Portekiz Premier Lig - Son Dakika Futbol Haberleri - Fotomaç
--------------------------------------------------------------------------------------------------

 ![Benfica 4-1 Porto | MAÇ SONUCU - ÖZET Portekiz Premier Lig - Son dakika Futbol haberleri - Fotomaç](https://iaftm.tmgrup.com.tr/464514/385/218/0/81/798/534?u=https://iftm.tmgrup.com.tr/2024/11/11/benfica-3-1-porto-mac-sonucu-ozet-portekiz-premier-lig-1731277270010.png) <small>www.fotomac.com.tr</small>Benfica 4-1 Porto | MAÇ SONUCU - ÖZET Portekiz Premier Lig - Son dakika Futbol haberleri - Fotomaç

PortuGOAL
---------

 ![PortuGOAL](https://portugoal.net/images/Benfica/Porto-1-4-Benfica-2025.jpg) <small>portugoal.net</small>PortuGOAL

Benfica FC Porto Liga Betclic Match Highlights - SL Benfica
-----------------------------------------------------------

 ![Benfica FC Porto Liga Betclic Match Highlights - SL Benfica](https://media.slbenfica.pt/-/media/benficadp/images/departamento-de-comunicacao/2024/futebol/competicoes/liga-betclic/11-jornada-benfica-fc-porto/jogo/festa-capa-new.jpg?h=725&w=1208&v=638669226560000000&hash=B6494FF8EDB7FCC24EE68479147937C6) <small>www.slbenfica.pt</small>Benfica FC Porto Liga Betclic Match Highlights - SL Benfica

Benfica Humble Porto With 4-1 Thrashing At The Luz | OneFootball
----------------------------------------------------------------

 ![Benfica humble Porto with 4-1 thrashing at the Luz | OneFootball](https://photobooth-api.onefootball.com/api/screenshot/%2Fv2%2Fphotobooth%2Fcms%2Fes%2F40293157%3Fdate=2024-11-11) <small>onefootball.com</small>Benfica humble Porto with 4-1 thrashing at the Luz | OneFootball

BENFICA 4-1 PORTO!! UM BENFICA DE ÉPOCA E MÍSTICA ARRASA DRAGÕES E ALCANÇA RESULTADO HISTÓRICO
----------------------------------------------------------------------------------------------

 ![BENFICA 4-1 PORTO!! UM BENFICA DE ÉPOCA E MÍSTICA ARRASA DRAGÕES E ALCANÇA RESULTADO HISTÓRICO](https://i.ytimg.com/vi/wEOw5bELasQ/maxresdefault.jpg) <small>www.youtube.com</small>BENFICA 4-1 PORTO!! UM BENFICA DE ÉPOCA E MÍSTICA ARRASA DRAGÕES E ALCANÇA RESULTADO HISTÓRICO ...

Benfica 4 - Porto 1 . Que Exibição Fantastica @Benfica\_XXI #benfica #futebol #ligaportugal - YouTube
-----------------------------------------------------------------------------------------------------

 ![Benfica 4 - Porto 1 . Que exibição fantastica @Benfica_XXI #benfica #futebol #ligaportugal - YouTube](https://i.ytimg.com/vi/VpFppxfqH14/maxresdefault.jpg) <small>www.youtube.com</small>Benfica 4 - Porto 1 . Que exibição fantastica @Benfica\_XXI #benfica #futebol #ligaportugal - YouTube

Benfica-FC Porto, 4-1 (crónica) - CNN Portugal
----------------------------------------------

 ![Benfica-FC Porto, 4-1 (crónica) - CNN Portugal](https://img.iol.pt/preset/67313915d34e94b82907467d/og/cnn) <small>cnnportugal.iol.pt</small>Benfica-FC Porto, 4-1 (crónica) - CNN Portugal

SL Benfica 4-1 FC Porto | Liga Portugal | LIVE - YouTube
--------------------------------------------------------

 ![SL Benfica 4-1 FC Porto | Liga Portugal | LIVE - YouTube](https://i.ytimg.com/vi/EHr7GxQ1ZTo/hqdefault.jpg) <small>www.youtube.com</small>SL Benfica 4-1 FC Porto | Liga Portugal | LIVE - YouTube

Extended Highlights | FC Porto 1-4 SL Benfica - YouTube
-------------------------------------------------------

 ![Extended Highlights | FC Porto 1-4 SL Benfica - YouTube](https://i.ytimg.com/vi/-1EKj1Pr8bc/maxresdefault.jpg#auto) <small>www.youtube.com</small>Extended Highlights | FC Porto 1-4 SL Benfica - YouTube

FC Porto 1-4 Benfica, Liga Portugal Betclic (ex Liga Nos) : Résumé Du Match (06/04/2025)
----------------------------------------------------------------------------------------

 ![FC Porto 1-4 Benfica, Liga Portugal Betclic (ex Liga Nos) : résumé du match (06/04/2025)](https://www.lequipe.fr/_medias/img-photo-jpg/soccer-football-primeira-liga-fc-porto-v-benfica-estadio-do-dragao-porto-portugal-april-6-2025-benfi/1500000002176733/39:0,1943:1904-824-824-75/4953a.jpg) <small>www.lequipe.fr</small>FC Porto 1-4 Benfica, Liga Portugal Betclic (ex Liga Nos) : résumé du match (06/04/2025)

Resumo: FC Porto 1-4 Benfica (Liga 24/25 #28) | OneFootball
-----------------------------------------------------------

 ![Resumo: FC Porto 1-4 Benfica (Liga 24/25 #28) | OneFootball](https://image-service.onefootball.com/transform?w=840&h=472&dpr=2&image=https://i.ytimg.com/vi/XMkljVNZDL0/hqdefault.jpg) <small>onefootball.com</small>Resumo: FC Porto 1-4 Benfica (Liga 24/25 #28) | OneFootball

Extended Highlights | SL Benfica 4-1 FC Porto - YouTube
-------------------------------------------------------

 ![Extended Highlights | SL Benfica 4-1 FC Porto - YouTube](https://i.ytimg.com/vi/acQHLFjDwUE/maxresdefault.jpg) <small>www.youtube.com</small>Extended Highlights | SL Benfica 4-1 FC Porto - YouTube

Como Matar Um Dragão, Segundo O Evangelho De Pavlidis: Benfica Goleia Na Casa Do FC Porto (1-4
----------------------------------------------------------------------------------------------

 ![Como matar um Dragão, segundo o Evangelho de Pavlidis: Benfica goleia na casa do FC Porto (1-4](https://livesport-ott-images.ssl.cdn.cra.cz/r900xfq60/794cea62-6c91-49be-87e6-d833bb084d37.jpeg) <small>www.flashscore.pt</small>Como matar um Dragão, segundo o Evangelho de Pavlidis: Benfica goleia na casa do FC Porto (1-4 ...

DI MARIA Fa Il FENOMENO E Travolge Il Porto: Benfica-Porto 4-1 | Liga Portugal | DAZN - YouTube
-----------------------------------------------------------------------------------------------

 ![DI MARIA fa il FENOMENO e travolge il Porto: Benfica-Porto 4-1 | Liga Portugal | DAZN - YouTube](https://i.ytimg.com/vi/8NT4U37ogng/maxresdefault.jpg) <small>www.youtube.com</small>DI MARIA fa il FENOMENO e travolge il Porto: Benfica-Porto 4-1 | Liga Portugal | DAZN - YouTube

Benfica Humilha Porto Em Campo... E Nas Redes Sociais! Eis O Vídeo Que Já é Viral | Glorioso1904.pt
---------------------------------------------------------------------------------------------------

 ![Benfica humilha Porto em campo... e nas redes sociais! Eis o vídeo que já é viral | Glorioso1904.pt](https://glorioso1904.pt/storage/media-items/image/2025/04/pavlidis-eustaquio-benfica-porto_20250407112021.webp) <small>glorioso1904.pt</small>Benfica humilha Porto em campo... e nas redes sociais! Eis o vídeo que já é viral | Glorioso1904.pt

Benfica Et Di María Giflent Le FC Porto - Liga Portugal - J11 - Benfica-Porto (4-1) - 10 Nov
--------------------------------------------------------------------------------------------

 ![Benfica et Di María giflent le FC Porto - Liga Portugal - J11 - Benfica-Porto (4-1) - 10 Nov](https://www.sofoot.com/convert/LzIwMjQvMTEvMTAyMzQxNDIvODk4NzYxNC0xNDAweDkzMy5qcGc/image/portugal-benfica-gifle-le-fc-porto-avec-un-grand-angel-di-maria-le-sporting-se-frotte-les-mains.jpg) <small>www.sofoot.com</small>Benfica et Di María giflent le FC Porto - Liga Portugal - J11 - Benfica-Porto (4-1) - 10 Nov ...

Liga Portugal - GOLO! SL Benfica, Di María Aos 82', SL Benfica 4-1 FC Porto
---------------------------------------------------------------------------

 ![Liga Portugal - GOLO! SL Benfica, Di María aos 82', SL Benfica 4-1 FC Porto](https://stc.vsports.pt/bigpic/liga/2425/5YlAZPJHIdtElTOpZ6mFF.jpg) <small>www.ligaportugal.pt</small>Liga Portugal - GOLO! SL Benfica, Di María aos 82', SL Benfica 4-1 FC Porto

Benfica Vs Porto (4-1) All Goals &amp; Extеndеd Hіghlіghts || Di María Goals - YouTube
--------------------------------------------------------------------------------------

 ![Benfica vs Porto (4-1) All Goals & Extеndеd Hіghlіghts || Di María Goals - YouTube](https://i.ytimg.com/vi/PdnWQdEIEHo/maxresdefault.jpg) <small>www.youtube.com</small>Benfica vs Porto (4-1) All Goals &amp; Extеndеd Hіghlіghts || Di María Goals - YouTube

Liga Record
-----------

 ![Liga Record](https://stc.vsports.pt/bigpic/liga/2425/2n110MmogcxKTZVzU82Wv.jpg) <small>liga.record.pt</small>Liga Record

Highlights | Resumo: FC Porto 1-1 Benfica (Liga 20/21 #14) - YouTube
--------------------------------------------------------------------

 ![Highlights | Resumo: FC Porto 1-1 Benfica (Liga 20/21 #14) - YouTube](https://i.ytimg.com/vi/mQkV3xtQmp4/maxresdefault.jpg) <small>www.youtube.com</small>Highlights | Resumo: FC Porto 1-1 Benfica (Liga 20/21 #14) - YouTube

Benfica humble porto with 4-1 thrashing at the luz. Di maria fa il fenomeno e travolge il porto: benfica-porto 4-1. Extended highlights
