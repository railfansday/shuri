---
title: "Greve Geral 11 Dezembro Motivo - As maiores greves gerais que o brasil já viu"
description: "Concentrações e manifestações no dia 11 de dezembro"
date: "2026-06-21"
categories:
- "Uncategorized"
images:
- "https://www.escolasdemira.pt/images/PR-_AVISO_DE_GREVE_para_os_dias_11_e_12_de_dezembro_de_2025.png"
featuredImage: "https://spzn.pt/uploads/noticias/big_1763717239_6728_SPZN_2025_site_novo_(17).png"
featured_image: "https://www.spn.pt/Media/Default/Info/68000/900/70/3/ESI — Greve Geral (cartaz).jpg"
image: "https://images.impresa.pt/expresso/2025-12-09-greve-geral.jpg-0c01f0f6/original"
---

If you are looking for Category:General strike 11 December 2025 (Portugal) - Wikimedia Commons you've visit to the right page. We have 35 Images about Category:General strike 11 December 2025 (Portugal) - Wikimedia Commons like SPN - Fenprof — Adesão histórica à greve geral, SINDEP - Greve Geral 11 de dezembro and also Nossos motivos para a GREVE GERAL - 11 de novembro - FECESC. Here you go:

Category:General Strike 11 December 2025 (Portugal) - Wikimedia Commons
-----------------------------------------------------------------------

 ![Category:General strike 11 December 2025 (Portugal) - Wikimedia Commons](https://upload.wikimedia.org/wikipedia/commons/thumb/d/d1/Convocatórias_nas_ruas_sobre_a_Greve_Geral_de_7_de_dezembro_2025%2C_em_Portugal_07.jpg/960px-Convocatórias_nas_ruas_sobre_a_Greve_Geral_de_7_de_dezembro_2025%2C_em_Portugal_07.jpg) <small>commons.wikimedia.org</small>Category:General strike 11 December 2025 (Portugal) - Wikimedia Commons

A Greve Geral De 11 De Dezembro Em 38 Imagens – Observador
----------------------------------------------------------

 ![A greve geral de 11 de dezembro em 38 imagens – Observador](https://bordalo.observador.pt/v2/q:60/rs:fill:1440/c:4096:2730:nowe:0:0/plain/https://s3.observador.pt/wp-content/uploads/2025/12/11090822/dventura-greve-geral-11dez-8-scaled.jpg) <small>observador.pt</small>A greve geral de 11 de dezembro em 38 imagens – Observador

Perguntas E Respostas Sobre A Greve Geral De 11 De Dezembro - SBC - Sindicato Nacional Dos
------------------------------------------------------------------------------------------

 ![Perguntas e respostas sobre a Greve Geral de 11 de dezembro - SBC - Sindicato Nacional dos](https://www.sibace.pt/wp-content/uploads/2025/11/greve-2-1170-x-400.png) <small>www.sibace.pt</small>Perguntas e respostas sobre a Greve Geral de 11 de dezembro - SBC - Sindicato Nacional dos ...

Fesete Vai Aderir à Greve Geral De 11 De Dezembro - Portugal - SÁBADO
---------------------------------------------------------------------

 ![Fesete vai aderir à greve geral de 11 de dezembro - Portugal - SÁBADO](https://cdn.sabado.pt/images/2013-05/img_1920x1080uu2013-05-30-19-15-03-73602.jpg) <small>www.sabado.pt</small>Fesete vai aderir à greve geral de 11 de dezembro - Portugal - SÁBADO

SPGL - Greve Geral | 11 De Dezembro De 2025 (Piquetes, Concentrações E Manifestações)
-------------------------------------------------------------------------------------

 ![SPGL - Greve Geral | 11 de dezembro de 2025 (Piquetes, Concentrações e Manifestações)](https://www.spgl.pt/Media/Default/_Profiles/722d2b7d/68bcf4e1/IMG_2694.JPG?v=639010778412646835) <small>www.spgl.pt</small>SPGL - Greve Geral | 11 de dezembro de 2025 (Piquetes, Concentrações e Manifestações)

Pré-Aviso De Greve 11 E 12 De Dezembro
--------------------------------------

 ![Pré-Aviso de Greve 11 e 12 de dezembro](https://static.wixstatic.com/media/1029eb_b4cf39036f744ea9833c234b7b4b5af5~mv2.jpg/v1/fill/w_980,h_1386,al_c,q_85,usm_0.66_1.00_0.01,enc_avif,quality_auto/1029eb_b4cf39036f744ea9833c234b7b4b5af5~mv2.jpg) <small>www.aecadaval.com</small>Pré-Aviso de Greve 11 e 12 de dezembro

A Greve Geral De 11 De Dezembro Em 38 Imagens – Observador
----------------------------------------------------------

 ![A greve geral de 11 de dezembro em 38 imagens – Observador](https://bordalo.observador.pt/v2/q:60/rs:fill:1440/c:4096:2730:nowe:0:0/plain/https://s3.observador.pt/wp-content/uploads/2025/12/11173414/dventura-greve-geral-11dez-54-scaled.jpg) <small>observador.pt</small>A greve geral de 11 de dezembro em 38 imagens – Observador

VISEU - Esclarecimento E Mobilização Para A Greve Geral Marcada Para 11 De Dezembro - CGTP-IN
---------------------------------------------------------------------------------------------

 ![VISEU - Esclarecimento e mobilização para a Greve Geral marcada para 11 de Dezembro - CGTP-IN](https://www.cgtp.pt/images/accao-e-luta/2025/gg.jpg) <small>www.cgtp.pt</small>VISEU - Esclarecimento e mobilização para a Greve Geral marcada para 11 de Dezembro - CGTP-IN

As Maiores Greves Gerais Que O Brasil Já Viu | Exame
----------------------------------------------------

 ![As maiores greves gerais que o Brasil já viu | Exame](https://classic.exame.com/wp-content/uploads/2017/04/1986-greve-geral-12-de-dezembro.jpg) <small>exame.com</small>As maiores greves gerais que o Brasil já viu | Exame

Maioria Dos Portugueses Diz Que Greve Geral Foi Justificada - Portugal - SÁBADO
-------------------------------------------------------------------------------

 ![Maioria dos portugueses diz que greve geral foi justificada - Portugal - SÁBADO](https://cdn.sabado.pt/images/2025-12/img_980x653uu2025-12-22-09-03-14-753915.jpg) <small>www.sabado.pt</small>Maioria dos portugueses diz que greve geral foi justificada - Portugal - SÁBADO

Concentrações E Manifestações No Dia 11 De Dezembro - CGTP-IN
-------------------------------------------------------------

 ![Concentrações e Manifestações no dia 11 de Dezembro - CGTP-IN](https://www.cgtp.pt/images/images/2025/12/CONCNETRACOES.jpg) <small>www.cgtp.pt</small>Concentrações e Manifestações no dia 11 de Dezembro - CGTP-IN

Nossos Motivos Para A GREVE GERAL - 11 De Novembro - FECESC
-----------------------------------------------------------

 ![Nossos motivos para a GREVE GERAL - 11 de novembro - FECESC](http://www.fecesc.org.br/siteprincipal/wp-content/uploads/2016/11/DESTAQUE-greve-geral-11-de-novembro-.jpg) <small>www.fecesc.org.br</small>Nossos motivos para a GREVE GERAL - 11 de novembro - FECESC

Mais De 50 Sindicatos Aderem à Greve Geral Marcada Para 11 De Dezembro
----------------------------------------------------------------------

 ![Mais de 50 sindicatos aderem à greve geral marcada para 11 de dezembro](https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA1QBjfX.img?w=1200&h=800&m=4&q=70) <small>www.msn.com</small>Mais de 50 sindicatos aderem à greve geral marcada para 11 de dezembro

Agrupamento De Escolas De Mira - Pré - Aviso De Greve Para Os Dias 11 E 12 De Dezembro De 2025
----------------------------------------------------------------------------------------------

 ![Agrupamento de Escolas de Mira - Pré - aviso de greve para os dias 11 e 12 de dezembro de 2025](https://www.escolasdemira.pt/images/PR-_AVISO_DE_GREVE_para_os_dias_11_e_12_de_dezembro_de_2025.png) <small>www.escolasdemira.pt</small>Agrupamento de Escolas de Mira - Pré - aviso de greve para os dias 11 e 12 de dezembro de 2025

SINDEP - Greve Geral 11 De Dezembro
-----------------------------------

 ![SINDEP - Greve Geral 11 de dezembro](https://sindep.pt/images/cartaz_GREVE_GERAL_UGT.jpg) <small>sindep.pt</small>SINDEP - Greve Geral 11 de dezembro

Pré-Aviso De Greve 11 E 12 De Dezembro
--------------------------------------

 ![Pré-Aviso de Greve 11 e 12 de dezembro](https://static.wixstatic.com/media/1029eb_a6db1017a2334a9abf146e02d7454c28~mv2.png/v1/fill/w_770,h_395,al_c,lg_1,q_85/1029eb_a6db1017a2334a9abf146e02d7454c28~mv2.png) <small>www.aecadaval.com</small>Pré-Aviso de Greve 11 e 12 de dezembro

Informações | Greve Geral De 11 Dezembro
----------------------------------------

 ![Informações | Greve Geral de 11 dezembro](https://fne.pt/uploads/noticias/big_1764325137_7603_InfoGreve.jpeg) <small>fne.pt</small>Informações | Greve Geral de 11 dezembro

A Greve Geral De 11 De Dezembro Em 38 Imagens – Observador
----------------------------------------------------------

 ![A greve geral de 11 de dezembro em 38 imagens – Observador](https://bordalo.observador.pt/v2/q:60/rs:fill:1440/c:4096:2730:nowe:0:0/plain/https://s3.observador.pt/wp-content/uploads/2025/12/11173228/dventura-greve-geral-11dez-41-scaled.jpg) <small>observador.pt</small>A greve geral de 11 de dezembro em 38 imagens – Observador

CGTP Anuncia Greve Geral Para 11 De Dezembro
--------------------------------------------

 ![CGTP anuncia greve geral para 11 de dezembro](https://www.lusa.pt/TEMP/IMAGES/780x1200/CACHE_780X1200_ANALOG_WATERMARKED_45998234_7085120_08112025053627.JPG) <small>www.lusa.pt</small>CGTP anuncia greve geral para 11 de dezembro

Greves Gerais? "Os Trabalhadores Unem-se Quando A Ofensiva é Grande"
--------------------------------------------------------------------

 ![Greves gerais? "Os trabalhadores unem-se quando a ofensiva é grande"](https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA24x2oz.img?w=768&h=432&m=6) <small>www.msn.com</small>Greves gerais? "Os trabalhadores unem-se quando a ofensiva é grande"

Greve Geral De 11 De Dezembro Em Portugal: Razões Para Participar
-----------------------------------------------------------------

 ![Greve Geral de 11 de dezembro em Portugal: razões para participar](https://sabiasque.pt/images/stories/2025/trabalho/20251209-greve-geral-11-dezembro-320x480.jpg) <small>sabiasque.pt</small>Greve Geral de 11 de dezembro em Portugal: razões para participar

CIL Apoia A Greve Geral Do Próximo Dia 11 De Dezembro - CGTP-IN
---------------------------------------------------------------

 ![CIL apoia a Greve Geral do próximo dia 11 de Dezembro - CGTP-IN](https://www.cgtp.pt/images/accao-e-luta/2025/54909309207_62b0afa28f_o1.jpg) <small>www.cgtp.pt</small>CIL apoia a Greve Geral do próximo dia 11 de Dezembro - CGTP-IN

TCB | Pré-aviso De Greve A 11 De Dezembro - Portal Institucional
----------------------------------------------------------------

 ![TCB | Pré-aviso de greve a 11 de dezembro - Portal Institucional](https://www.cm-barreiro.pt/wp-content/uploads/2025/12/GREVE-11_DEZEMBRO_650px.png) <small>www.cm-barreiro.pt</small>TCB | Pré-aviso de greve a 11 de dezembro - Portal Institucional

SPN - ESI — Participação Expressiva Na Greve Geral (11/dez)
-----------------------------------------------------------

 ![SPN - ESI — Participação expressiva na greve geral (11/dez)](https://www.spn.pt/Media/Default/Info/68000/900/70/3/ESI — Greve Geral (cartaz).jpg) <small>www.spn.pt</small>SPN - ESI — Participação expressiva na greve geral (11/dez)

GREVE DIA 11 DE DEZEMBRO DE 2025 ADMINISTRAÇÃO PÚBLICA – SETOR PÚBLICO EMPRESARIAL – SETOR
------------------------------------------------------------------------------------------

 ![GREVE DIA 11 DE DEZEMBRO DE 2025 ADMINISTRAÇÃO PÚBLICA – SETOR PÚBLICO EMPRESARIAL – SETOR](https://www.stts.pt/wp-content/uploads/2025/12/Cartaz-2025-11-27-às-09.39.13_5014e264.jpg) <small>www.stts.pt</small>GREVE DIA 11 DE DEZEMBRO DE 2025 ADMINISTRAÇÃO PÚBLICA – SETOR PÚBLICO EMPRESARIAL – SETOR ...

TCB | Pré-aviso De Greve A 11 De Dezembro - Portal Institucional
----------------------------------------------------------------

 ![TCB | Pré-aviso de greve a 11 de dezembro - Portal Institucional](https://www.cm-barreiro.pt/wp-content/uploads/2025/12/GREVE-11_DEZEMBRO_1920px-1536x920.jpg) <small>www.cm-barreiro.pt</small>TCB | Pré-aviso de greve a 11 de dezembro - Portal Institucional

Dos Transportes à Saúde, Lares E Prisões, Que Serviços Mínimos Estão Garantidos Para A Greve
--------------------------------------------------------------------------------------------

 ![Dos transportes à saúde, lares e prisões, que serviços mínimos estão garantidos para a greve](https://images.impresa.pt/expresso/2025-12-09-greve-geral.jpg-0c01f0f6/original) <small>expresso.pt</small>Dos transportes à saúde, lares e prisões, que serviços mínimos estão garantidos para a greve ...

Fertagus &gt; Fertagus (pt) &gt; Viajar &gt; Comunicados E Campanhas &gt; Greve Geral 11 De Dezembro De 2025
------------------------------------------------------------------------------------------------------------

 ![Fertagus > Fertagus (pt) > Viajar > Comunicados e Campanhas > Greve Geral 11 de dezembro de 2025](https://www.fertagus.pt/portals/0/FTG-Greve-Geral-web-1253x886.jpg) <small>www.fertagus.pt</small>Fertagus &gt; Fertagus (pt) &gt; Viajar &gt; Comunicados e Campanhas &gt; Greve Geral 11 de dezembro de 2025

GREVE GERAL | 11 DEZEMBRO 2025 - ATE
------------------------------------

 ![GREVE GERAL | 11 DEZEMBRO 2025 - ATE](https://www.ate.pt/wp-content/uploads/2025/12/Greve-geral-11.12.jpg) <small>www.ate.pt</small>GREVE GERAL | 11 DEZEMBRO 2025 - ATE

SPN - Fenprof — Adesão Histórica à Greve Geral
----------------------------------------------

 ![SPN - Fenprof — Adesão histórica à greve geral](https://www.spn.pt/Media/Default/Info/68000/500/60/7/grevegeral11dez_cartaz.jpg) <small>www.spn.pt</small>SPN - Fenprof — Adesão histórica à greve geral

GREVE GERAL DIA 11 DEZEMBRO DE 2025 | FESAHT
--------------------------------------------

 ![GREVE GERAL DIA 11 DEZEMBRO DE 2025 | FESAHT](https://sindicatos.cgtp.pt/fesaht/wp-content/blogs.dir/52/files/sites/52/2025/12/11-DEZ-faz-greve-e-sai-a-Rua.jpg) <small>sindicatos.cgtp.pt</small>GREVE GERAL DIA 11 DEZEMBRO DE 2025 | FESAHT

FNSTFPS Adere à Greve Geral De 11 De Dezembro - CGTP-IN
-------------------------------------------------------

 ![FNSTFPS adere à Greve Geral de 11 de Dezembro - CGTP-IN](https://www.cgtp.pt/images/accao-e-luta/2025/54910179541_10702918c8_c.jpg) <small>www.cgtp.pt</small>FNSTFPS adere à Greve Geral de 11 de Dezembro - CGTP-IN

SPGL - Greve 11 De Dezembro 2020
--------------------------------

 ![SPGL - Greve 11 de Dezembro 2020](https://www.spgl.pt/Media/Default/_Profiles/dd11bcb9/c59f797e/CARROSSEL-GREVE-11-DEZ-2020-FENPROF.jpg?v=637420844365449978) <small>www.spgl.pt</small>SPGL - Greve 11 de Dezembro 2020

Aviso – Pré-Avisos De Greve | 11 E 12 De Dezembro De 2025 – AE António Correia De Oliveira
------------------------------------------------------------------------------------------

 ![Aviso – Pré-Avisos de Greve | 11 e 12 de dezembro de 2025 – AE António Correia de Oliveira](https://www.acoliveira.pt/wp-content/uploads/2025/12/11.png) <small>www.acoliveira.pt</small>Aviso – Pré-Avisos de Greve | 11 e 12 de dezembro de 2025 – AE António Correia de Oliveira

Motivos Da Adesão à Greve Geral De 11 De Dezembro De 2025
---------------------------------------------------------

 ![Motivos da adesão à Greve Geral de 11 de dezembro de 2025](https://spzn.pt/uploads/noticias/big_1763717239_6728_SPZN_2025_site_novo_(17).png) <small>spzn.pt</small>Motivos da adesão à Greve Geral de 11 de dezembro de 2025

Cil apoia a greve geral do próximo dia 11 de dezembro. Agrupamento de escolas de mira. motivos da adesão à greve geral de 11 de dezembro de 2025
