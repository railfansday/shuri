---
title: "Greve Geral 11 Dezembro Metro - Greve geral: constrangimentos/limitações à circulação do metro de lisboa"
description: "Agrupamento de escolas de mira"
date: "2026-06-20"
categories:
- "Uncategorized"
images:
- "https://static.wixstatic.com/media/1029eb_b4cf39036f744ea9833c234b7b4b5af5~mv2.jpg/v1/fill/w_980,h_1386,al_c,q_85,usm_0.66_1.00_0.01,enc_avif,quality_auto/1029eb_b4cf39036f744ea9833c234b7b4b5af5~mv2.jpg"
featuredImage: "https://staticx.noticiasilimitadas.pt/jn/image.webp?brand=jn&amp;type=generate&amp;guid=4a9e034d-f191-4476-908a-d05d2af1a846&amp;w=3840"
featured_image: "https://staticx.noticiasilimitadas.pt/jn/image.webp?brand=jn&amp;type=generate&amp;guid=4a9e034d-f191-4476-908a-d05d2af1a846&amp;w=3840"
image: "https://www.escolasdemira.pt/images/PR-_AVISO_DE_GREVE_para_os_dias_11_e_12_de_dezembro_de_2025.png"
---

If you are looking for A greve geral de 11 de dezembro em 38 imagens – Observador you've came to the right page. We have 35 Images about A greve geral de 11 de dezembro em 38 imagens – Observador like Maioria dos portugueses diz que greve geral foi justificada - Portugal - SÁBADO, SPN - Fenprof — Adesão histórica à greve geral and also SPN - ESI — Participação expressiva na greve geral (11/dez). Read more:

A Greve Geral De 11 De Dezembro Em 38 Imagens – Observador
----------------------------------------------------------

 ![A greve geral de 11 de dezembro em 38 imagens – Observador](https://bordalo.observador.pt/v2/q:60/rs:fill:1440/c:4096:2730:nowe:0:0/plain/https://s3.observador.pt/wp-content/uploads/2025/12/11173246/dventura-greve-geral-11dez-43-scaled.jpg) <small>observador.pt</small>A greve geral de 11 de dezembro em 38 imagens – Observador

GREVE GERAL | 11 DEZEMBRO 2025 - ATE
------------------------------------

 ![GREVE GERAL | 11 DEZEMBRO 2025 - ATE](https://www.ate.pt/wp-content/uploads/2025/12/Greve-geral-11.12.jpg) <small>www.ate.pt</small>GREVE GERAL | 11 DEZEMBRO 2025 - ATE

SPN - Fenprof — Adesão Histórica à Greve Geral
----------------------------------------------

 ![SPN - Fenprof — Adesão histórica à greve geral](https://www.spn.pt/Media/Default/Info/68000/500/60/7/grevegeral11dez_cartaz.jpg) <small>www.spn.pt</small>SPN - Fenprof — Adesão histórica à greve geral

Perguntas E Respostas Sobre A Greve Geral De 11 De Dezembro - SBC - Sindicato Nacional Dos
------------------------------------------------------------------------------------------

 ![Perguntas e respostas sobre a Greve Geral de 11 de dezembro - SBC - Sindicato Nacional dos](https://www.sibace.pt/wp-content/uploads/2025/11/greve-2-1170-x-400.png) <small>www.sibace.pt</small>Perguntas e respostas sobre a Greve Geral de 11 de dezembro - SBC - Sindicato Nacional dos ...

Informações | Greve Geral De 11 Dezembro
----------------------------------------

 ![Informações | Greve Geral de 11 dezembro](https://fne.pt/uploads/noticias/big_1764325137_7603_InfoGreve.jpeg) <small>fne.pt</small>Informações | Greve Geral de 11 dezembro

UGT Avança Para Greve Geral A 11 De Dezembro
--------------------------------------------

 ![UGT avança para greve geral a 11 de dezembro](https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA1Q3P3K.img?w=860&h=471&m=4&q=87) <small>www.msn.com</small>UGT avança para greve geral a 11 de dezembro

UGT - Greve Geral De 11 De Dezembro é Um Sucesso E Marca Um Rotundo Não Dos Trabalhadores à
-------------------------------------------------------------------------------------------

 ![UGT - Greve Geral de 11 de dezembro é um sucesso e marca um rotundo não dos trabalhadores à](https://www.ugt.pt/publicfiles/dvc3keu4ex9l4e2fizbuignqdef3jdmrhdwzogyd.png) <small>www.ugt.pt</small>UGT - Greve Geral de 11 de dezembro é um sucesso e marca um rotundo não dos trabalhadores à ...

Fertagus &gt; Fertagus (pt) &gt; Viajar &gt; Comunicados E Campanhas &gt; Greve Geral 11 De Dezembro De 2025
------------------------------------------------------------------------------------------------------------

 ![Fertagus > Fertagus (pt) > Viajar > Comunicados e Campanhas > Greve Geral 11 de dezembro de 2025](https://www.fertagus.pt/portals/0/FTG-Greve-Geral-web-1253x886.jpg) <small>www.fertagus.pt</small>Fertagus &gt; Fertagus (pt) &gt; Viajar &gt; Comunicados e Campanhas &gt; Greve Geral 11 de dezembro de 2025

A Greve Geral De 11 De Dezembro Em 38 Imagens – Observador
----------------------------------------------------------

 ![A greve geral de 11 de dezembro em 38 imagens – Observador](https://bordalo.observador.pt/v2/q:60/rs:fill:1440/c:4096:2730:nowe:0:0/plain/https://s3.observador.pt/wp-content/uploads/2025/12/11173414/dventura-greve-geral-11dez-54-scaled.jpg) <small>observador.pt</small>A greve geral de 11 de dezembro em 38 imagens – Observador

TCB | Pré-aviso De Greve A 11 De Dezembro - Portal Institucional
----------------------------------------------------------------

 ![TCB | Pré-aviso de greve a 11 de dezembro - Portal Institucional](https://www.cm-barreiro.pt/wp-content/uploads/2025/12/GREVE-11_DEZEMBRO_1920px-1536x920.jpg) <small>www.cm-barreiro.pt</small>TCB | Pré-aviso de greve a 11 de dezembro - Portal Institucional

Dos Transportes à Saúde, Lares E Prisões, Que Serviços Mínimos Estão Garantidos Para A Greve
--------------------------------------------------------------------------------------------

 ![Dos transportes à saúde, lares e prisões, que serviços mínimos estão garantidos para a greve](https://images.impresa.pt/expresso/2025-12-09-greve-geral.jpg-0c01f0f6/original) <small>expresso.pt</small>Dos transportes à saúde, lares e prisões, que serviços mínimos estão garantidos para a greve ...

Nossos Motivos Para A GREVE GERAL - 11 De Novembro - FECESC
-----------------------------------------------------------

 ![Nossos motivos para a GREVE GERAL - 11 de novembro - FECESC](http://www.fecesc.org.br/siteprincipal/wp-content/uploads/2016/11/DESTAQUE-greve-geral-11-de-novembro--850x427.jpg) <small>www.fecesc.org.br</small>Nossos motivos para a GREVE GERAL - 11 de novembro - FECESC

Maioria Dos Portugueses Diz Que Greve Geral Foi Justificada - Portugal - SÁBADO
-------------------------------------------------------------------------------

 ![Maioria dos portugueses diz que greve geral foi justificada - Portugal - SÁBADO](https://cdn.sabado.pt/images/2025-12/img_980x653uu2025-12-22-09-03-14-753915.jpg) <small>www.sabado.pt</small>Maioria dos portugueses diz que greve geral foi justificada - Portugal - SÁBADO

CIL Apoia A Greve Geral Do Próximo Dia 11 De Dezembro - CGTP-IN
---------------------------------------------------------------

 ![CIL apoia a Greve Geral do próximo dia 11 de Dezembro - CGTP-IN](https://www.cgtp.pt/images/accao-e-luta/2025/54909309207_62b0afa28f_o1.jpg) <small>www.cgtp.pt</small>CIL apoia a Greve Geral do próximo dia 11 de Dezembro - CGTP-IN

O Que Muda (e O Que Fica Na Mesma) No Pacote Laboral – Observador
-----------------------------------------------------------------

 ![O que muda (e o que fica na mesma) no pacote laboral – Observador](https://bordalo.observador.pt/v2/q:60/rs:fill:1440/c:4096:2298:nowe:0:250/plain/https://s3.observador.pt/wp-content/uploads/2025/12/11085005/dventura-greve-geral-11dez-2-scaled.jpg) <small>observador.pt</small>O que muda (e o que fica na mesma) no pacote laboral – Observador

Greve Geral: Quem Pode Aderir, O Que Muda No Salário E O Que Vai Estar A Funcionar - JN
---------------------------------------------------------------------------------------

 ![Greve geral: quem pode aderir, o que muda no salário e o que vai estar a funcionar - JN](https://staticx.noticiasilimitadas.pt/jn/image.webp?brand=jn&type=generate&guid=4a9e034d-f191-4476-908a-d05d2af1a846&w=3840) <small>www.jn.pt</small>Greve geral: quem pode aderir, o que muda no salário e o que vai estar a funcionar - JN

CGTP Anuncia Greve Geral Para 11 De Dezembro
--------------------------------------------

 ![CGTP anuncia greve geral para 11 de dezembro](https://www.diarioleiria.pt/wp-content/uploads/sites/7/2025/01/Greve-global-e1737120993295.webp) <small>www.diarioleiria.pt</small>CGTP anuncia greve geral para 11 de dezembro

UGT Aprova Por Unanimidade Greve Geral A 11 De Dezembro - Diário Do Minho
-------------------------------------------------------------------------

 ![UGT aprova por unanimidade greve geral a 11 de dezembro - Diário do Minho](https://www.diariodominho.pt/storage/posts/greve-direito-a-greve_655b8a6d702c0_og.jpg) <small>www.diariodominho.pt</small>UGT aprova por unanimidade greve geral a 11 de dezembro - Diário do Minho

Pré-Aviso De Greve 11 E 12 De Dezembro
--------------------------------------

 ![Pré-Aviso de Greve 11 e 12 de dezembro](https://static.wixstatic.com/media/1029eb_b4cf39036f744ea9833c234b7b4b5af5~mv2.jpg/v1/fill/w_980,h_1386,al_c,q_85,usm_0.66_1.00_0.01,enc_avif,quality_auto/1029eb_b4cf39036f744ea9833c234b7b4b5af5~mv2.jpg) <small>www.aecadaval.com</small>Pré-Aviso de Greve 11 e 12 de dezembro

GREVE GERAL DIA 11 DEZEMBRO DE 2025 | FESAHT
--------------------------------------------

 ![GREVE GERAL DIA 11 DEZEMBRO DE 2025 | FESAHT](https://sindicatos.cgtp.pt/fesaht/wp-content/blogs.dir/52/files/sites/52/2025/12/11-DEZ-faz-greve-e-sai-a-Rua.jpg) <small>sindicatos.cgtp.pt</small>GREVE GERAL DIA 11 DEZEMBRO DE 2025 | FESAHT

Pré-Aviso De Greve 11 E 12 De Dezembro
--------------------------------------

 ![Pré-Aviso de Greve 11 e 12 de dezembro](https://static.wixstatic.com/media/1029eb_a6db1017a2334a9abf146e02d7454c28~mv2.png/v1/fill/w_770,h_395,al_c,lg_1,q_85/1029eb_a6db1017a2334a9abf146e02d7454c28~mv2.png) <small>www.aecadaval.com</small>Pré-Aviso de Greve 11 e 12 de dezembro

TCB | Pré-aviso De Greve A 11 De Dezembro - Portal Institucional
----------------------------------------------------------------

 ![TCB | Pré-aviso de greve a 11 de dezembro - Portal Institucional](https://www.cm-barreiro.pt/wp-content/uploads/2025/12/GREVE-11_DEZEMBRO_650px.png) <small>www.cm-barreiro.pt</small>TCB | Pré-aviso de greve a 11 de dezembro - Portal Institucional

Mais De 50 Sindicatos Aderem à Greve Geral Marcada Para 11 De Dezembro
----------------------------------------------------------------------

 ![Mais de 50 sindicatos aderem à greve geral marcada para 11 de dezembro](https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA1QBjfX.img?w=1200&h=800&m=4&q=70) <small>www.msn.com</small>Mais de 50 sindicatos aderem à greve geral marcada para 11 de dezembro

Greve Geral De 11 De Dezembro Pode Condicionar Rede De Transportes Dos SMTUC – SMTUC
------------------------------------------------------------------------------------

 ![Greve geral de 11 de dezembro pode condicionar rede de transportes dos SMTUC – SMTUC](https://www.smtuc.pt/wp-content/uploads/2025/12/DSC01477-copiar-Personalizar-scaled.jpg) <small>www.smtuc.pt</small>Greve geral de 11 de dezembro pode condicionar rede de transportes dos SMTUC – SMTUC

Agrupamento De Escolas De Mira - Pré - Aviso De Greve Para Os Dias 11 E 12 De Dezembro De 2025
----------------------------------------------------------------------------------------------

 ![Agrupamento de Escolas de Mira - Pré - aviso de greve para os dias 11 e 12 de dezembro de 2025](https://www.escolasdemira.pt/images/PR-_AVISO_DE_GREVE_para_os_dias_11_e_12_de_dezembro_de_2025.png) <small>www.escolasdemira.pt</small>Agrupamento de Escolas de Mira - Pré - aviso de greve para os dias 11 e 12 de dezembro de 2025

Quanto Vai Custar E Que Serviços Mínimos Estarão Abrangidos? Tudo O Que Precisa Saber Sobre A
---------------------------------------------------------------------------------------------

 ![Quanto vai custar e que serviços mínimos estarão abrangidos? Tudo o que precisa saber sobre a](https://cdn.sabado.pt/images/2025-11/img_980x653uu2025-11-14-13-24-53-750328.jpg) <small>www.sabado.pt</small>Quanto vai custar e que serviços mínimos estarão abrangidos? Tudo o que precisa saber sobre a ...

Greve Geral Contra Pacote Laboral A 11 De Dezembro (vídeo) – RTP Madeira
------------------------------------------------------------------------

 ![Greve geral contra pacote laboral a 11 de dezembro (vídeo) – RTP Madeira](https://madeira.rtp.pt/wp-content/uploads/2025/11/DOC.20251108.45998234.ACOT9063-scaled.jpg) <small>madeira.rtp.pt</small>Greve geral contra pacote laboral a 11 de dezembro (vídeo) – RTP Madeira

GREVE DIA 11 DE DEZEMBRO DE 2025 ADMINISTRAÇÃO PÚBLICA – SETOR PÚBLICO EMPRESARIAL – SETOR
------------------------------------------------------------------------------------------

 ![GREVE DIA 11 DE DEZEMBRO DE 2025 ADMINISTRAÇÃO PÚBLICA – SETOR PÚBLICO EMPRESARIAL – SETOR](https://www.stts.pt/wp-content/uploads/2025/12/Cartaz-2025-11-27-às-09.39.13_5014e264.jpg) <small>www.stts.pt</small>GREVE DIA 11 DE DEZEMBRO DE 2025 ADMINISTRAÇÃO PÚBLICA – SETOR PÚBLICO EMPRESARIAL – SETOR ...

A Greve Geral De 11 De Dezembro Em 38 Imagens – Observador
----------------------------------------------------------

 ![A greve geral de 11 de dezembro em 38 imagens – Observador](https://bordalo.observador.pt/v2/q:60/rs:fill:1440/c:4096:2730:nowe:0:0/plain/https://s3.observador.pt/wp-content/uploads/2025/12/11173228/dventura-greve-geral-11dez-41-scaled.jpg) <small>observador.pt</small>A greve geral de 11 de dezembro em 38 imagens – Observador

Greve Geral: Constrangimentos/limitações à Circulação Do Metro De Lisboa - Dia 10 De Dezembro A
-----------------------------------------------------------------------------------------------

 ![Greve geral: Constrangimentos/limitações à circulação do Metro de Lisboa - Dia 10 de dezembro a](https://www.metrolisboa.pt/institucional/wp-content/uploads/sites/2/2025/12/8_Greve_Noticia-1080x450-1-980x408.png) <small>www.metrolisboa.pt</small>Greve geral: Constrangimentos/limitações à circulação do Metro de Lisboa - Dia 10 de dezembro a ...

SPN - ESI — Participação Expressiva Na Greve Geral (11/dez)
-----------------------------------------------------------

 ![SPN - ESI — Participação expressiva na greve geral (11/dez)](https://www.spn.pt/Media/Default/_Profiles/ee10172b/dadfb8d0/ESI — Greve Geral (cartaz).jpg?v=639008760992974253) <small>www.spn.pt</small>SPN - ESI — Participação expressiva na greve geral (11/dez)

FNSTFPS Adere à Greve Geral De 11 De Dezembro - CGTP-IN
-------------------------------------------------------

 ![FNSTFPS adere à Greve Geral de 11 de Dezembro - CGTP-IN](https://www.cgtp.pt/images/accao-e-luta/2025/54910179541_10702918c8_c.jpg) <small>www.cgtp.pt</small>FNSTFPS adere à Greve Geral de 11 de Dezembro - CGTP-IN

Motivos Da Adesão à Greve Geral De 11 De Dezembro De 2025
---------------------------------------------------------

 ![Motivos da adesão à Greve Geral de 11 de dezembro de 2025](https://spzn.pt/uploads/noticias/big_1763717239_6728_SPZN_2025_site_novo_(17).png) <small>spzn.pt</small>Motivos da adesão à Greve Geral de 11 de dezembro de 2025

SINDEP - Greve Geral 11 De Dezembro
-----------------------------------

 ![SINDEP - Greve Geral 11 de dezembro](https://sindep.pt/images/cartaz_GREVE_GERAL_UGT.jpg) <small>sindep.pt</small>SINDEP - Greve Geral 11 de dezembro

Greve Geral A 11 De Dezembro. Comboios, Carris E Barcos Com Serviços Mínimos E Metro Excluído
---------------------------------------------------------------------------------------------

 ![Greve geral a 11 de dezembro. Comboios, Carris e barcos com serviços mínimos e metro excluído](https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA1RQwbO.img?w=860&h=472&m=4&q=87) <small>www.msn.com</small>Greve geral a 11 de dezembro. Comboios, Carris e barcos com serviços mínimos e metro excluído

greve geral: constrangimentos/limitações à circulação do metro de lisboa. Greve dia 11 de dezembro de 2025 administração pública – setor público empresarial – setor. greve geral: quem pode aderir, o que muda no salário e o que vai estar a funcionar
