---
title: "Vitinha Stats World Cup - Portugal&#039;s vitinha controls the ball during a world cup 2026 group f qualifying soccer match ..."
description: "Vitinha of portugal during the fifa world cup qatar 2022 group h... news photo"
date: "2026-11-04"
categories:
- "Uncategorized"
images:
- "https://c8.alamy.com/comp/3D55CYB/portugals-vitinha-during-the-2026-fifa-world-cup-european-qualifying-group-f-match-at-the-aviva-stadium-in-dublin-ireland-picture-date-thursday-november-13-2025-3D55CYB.jpg"
featuredImage: "https://pictures.tribuna.com/image/507d4cd4-299e-4378-9590-436a805e33c7?width=1920&amp;quality=70"
featured_image: "https://livesport-ott-images.ssl.cdn.cra.cz/r900xfq60/b62aca49-901d-4cae-8693-98245edd49d9.jpg"
image: "https://c8.alamy.com/comp/2KYY66W/qatar-02nd-dec-2022-doha-vitinha-of-portugal-during-the-fifa-world-cup-qatar-2022-group-h-match-between-south-korea-and-portugal-at-education-city-stadium-on-december-2-2022-in-doha-qatar-ap-dutch-height-maurice-of-stone-credit-anpalamy-live-news-2KYY66W.jpg"
---

If you are searching about Vitinha sets World Cup record with 54 perfect passes in draw against Colombia | AllFootball you've came to the right web. We have 35 Pics about Vitinha sets World Cup record with 54 perfect passes in draw against Colombia | AllFootball like Best in the world? Vitinha tops four major metrics against top midfielders in 2025/26 Champions, Their own Vitinha: Spurs' "future £100m" star must now start every game and also Portugal's Vitinha during the 2026 FIFA World Cup European Qualifying, Group F match at the. Here you go:

Vitinha Sets World Cup Record With 54 Perfect Passes In Draw Against Colombia | AllFootball
-------------------------------------------------------------------------------------------

 ![Vitinha sets World Cup record with 54 perfect passes in draw against Colombia | AllFootball](https://img.allfootballapp.com/www1/M00/11/1B/720x-/-/-/rBAAN2pAlsOAe0QCAAEf9o5O_k4721.jpg) <small>www.allfootballapp.com</small>Vitinha sets World Cup record with 54 perfect passes in draw against Colombia | AllFootball

Portugal's Vitinha During The 2026 FIFA World Cup European Qualifying, Group F Match At The
-------------------------------------------------------------------------------------------

 ![Portugal's Vitinha during the 2026 FIFA World Cup European Qualifying, Group F match at the](https://c8.alamy.com/comp/3D55CYB/portugals-vitinha-during-the-2026-fifa-world-cup-european-qualifying-group-f-match-at-the-aviva-stadium-in-dublin-ireland-picture-date-thursday-november-13-2025-3D55CYB.jpg) <small>www.alamy.com</small>Portugal's Vitinha during the 2026 FIFA World Cup European Qualifying, Group F match at the ...

Flashscore.com | Vitinha's Pass Accuracy Of 𝟗𝟓.𝟑% During The Club World Cup Means He Has
----------------------------------------------------------------------------------------

 ![Flashscore.com | Vitinha's pass accuracy of 𝟗𝟓.𝟑% during the Club World Cup means he has](https://lookaside.instagram.com/seo/google_widget/crawler/?media_id=3665854875245890794) <small>www.instagram.com</small>Flashscore.com | Vitinha's pass accuracy of 𝟗𝟓.𝟑% during the Club World Cup means he has ...

Vitinha Of Portugal Reacts After A World Cup 2026 Group F Qualifying Soccer Match Between
-----------------------------------------------------------------------------------------

 ![Vitinha of Portugal reacts after a World Cup 2026 group F qualifying soccer match between](https://c8.alamy.com/comp/3CWEJRN/vitinha-of-portugal-reacts-after-a-world-cup-2026-group-f-qualifying-soccer-match-between-portugal-and-ireland-in-lisbon-saturday-oct-11-2025-ap-photoarmando-franca-3CWEJRN.jpg) <small>www.alamy.com</small>Vitinha of Portugal reacts after a World Cup 2026 group F qualifying soccer match between ...

Champions League Team Of The Round: Mbappe Scores Four, Vitinha Hits Hat-trick | Flashscore.co.uk
-------------------------------------------------------------------------------------------------

 ![Champions League Team of the Round: Mbappe scores four, Vitinha hits hat-trick | Flashscore.co.uk](https://livesport-ott-images.ssl.cdn.cra.cz/r900xfq60/b787e292-0558-4f11-86ae-860f9e3a8726.jpg) <small>www.flashscore.co.uk</small>Champions League Team of the Round: Mbappe scores four, Vitinha hits hat-trick | Flashscore.co.uk

Vitinha Of Portugal Poses During The Official FIFA World Cup Qatar... News Photo - Getty Images
-----------------------------------------------------------------------------------------------

 ![Vitinha of Portugal poses during the official FIFA World Cup Qatar... News Photo - Getty Images](https://media.gettyimages.com/id/1443058101/photo/portugal-portraits-fifa-world-cup-qatar-2022.jpg?s=1024x1024&w=gi&k=20&c=Hi3D8astce2U-hJiXTG9uoFK1Qg8NU0qEhdEiRhNNvo=) <small>www.gettyimages.com</small>Vitinha of Portugal poses during the official FIFA World Cup Qatar... News Photo - Getty Images

Trading Cards Fifa World Cup 2026 VITINHA Nr.370 (Neu (gemäss Beschreibung)) In Sugiez Für CHF
----------------------------------------------------------------------------------------------

 ![Trading Cards Fifa World Cup 2026 VITINHA Nr.370 (Neu (gemäss Beschreibung)) in sugiez für CHF](https://img.ricardostatic.ch/images/9434c427-77c5-4d4d-8f0b-f7867821616a/t_1800x1350/trading-cards-fifa-world-cup-2026-vitinha-nr370) <small>www.ricardo.ch</small>Trading Cards Fifa World Cup 2026 VITINHA Nr.370 (Neu (gemäss Beschreibung)) in sugiez für CHF ...

Portugal's Vitinha Controls The Ball During A World Cup 2026 Group F Qualifying Soccer Match
--------------------------------------------------------------------------------------------

 ![Portugal's Vitinha controls the ball during a World Cup 2026 group F qualifying soccer match](https://c8.alamy.com/comp/3D5KP91/portugals-vitinha-controls-the-ball-during-a-world-cup-2026-group-f-qualifying-soccer-match-between-portugal-and-armenia-in-porto-portugal-sunday-nov-16-2025-ap-photoluis-vieira-3D5KP91.jpg) <small>www.alamy.com</small>Portugal's Vitinha controls the ball during a World Cup 2026 group F qualifying soccer match ...

Vitinha Stats: Goals, Assists &amp; Passing Data | Squawka
----------------------------------------------------------

 ![Vitinha Stats: Goals, Assists & Passing Data | Squawka](https://media.squawka.com/images/sites/13/2026/06/18134618/ChatGPT-Image-Jun-18-2026-at-06_45_44-PM.jpg) <small>www.squawka.com</small>Vitinha Stats: Goals, Assists &amp; Passing Data | Squawka

FlashFocus: Little Maestro Vitinha Reaching New Levels With PSG | Flashscore.co.uk
----------------------------------------------------------------------------------

 ![FlashFocus: Little maestro Vitinha reaching new levels with PSG | Flashscore.co.uk](https://livesport-ott-images.ssl.cdn.cra.cz/r900xfq60/b62aca49-901d-4cae-8693-98245edd49d9.jpg) <small>www.flashscore.co.uk</small>FlashFocus: Little maestro Vitinha reaching new levels with PSG | Flashscore.co.uk

Vitinha \[Gold\] #135 Prices | 2025 Panini Prizm FIFA Club World Cup | Soccer Cards
-----------------------------------------------------------------------------------

 ![Vitinha [Gold] #135 Prices | 2025 Panini Prizm FIFA Club World Cup | Soccer Cards](https://storage.googleapis.com/images.pricecharting.com/corrijokoskexc3r7qwq/1600.jpg) <small>www.sportscardspro.com</small>Vitinha \[Gold\] #135 Prices | 2025 Panini Prizm FIFA Club World Cup | Soccer Cards

Vitinha Of Portugal During The FIFA World Cup 2026, Qualifiers, Group F Football Match Between
----------------------------------------------------------------------------------------------

 ![Vitinha of Portugal during the FIFA World Cup 2026, Qualifiers, Group F football match between](https://c8.alamy.com/comp/3D5PKGM/vitinha-of-portugal-during-the-fifa-world-cup-2026-qualifiers-group-f-football-match-between-portugal-and-armenia-on-16-november-2025-at-estdio-do-drago-in-porto-portugal-3D5PKGM.jpg) <small>www.alamy.com</small>Vitinha of Portugal during the FIFA World Cup 2026, Qualifiers, Group F football match between ...

Vitinha-FIFA Club World Cup 2025 | Aukro
----------------------------------------

 ![Vitinha-FIFA Club World Cup 2025 | Aukro](https://cdn.aukro.cz/images/sk1767910363884/vitinha-fifa-club-world-cup-2025-253729777.jpeg) <small>aukro.cz</small>Vitinha-FIFA Club World Cup 2025 | Aukro

Top Scorer, Most Assists And All The Player Stats From The 2025 Club World Cup | DAZN News GB
---------------------------------------------------------------------------------------------

 ![Top scorer, most assists and all the player stats from the 2025 Club World Cup | DAZN News GB](https://cms-images.acc.indazn.com/di/library/DAZN_News/62/e6/vitinha-16x9_1cfqx3893ofgz1puvq0g7whoc7.jpg?t=-207595873&quality=80&w=750&h=422) <small>www.dazn.com</small>Top scorer, most assists and all the player stats from the 2025 Club World Cup | DAZN News GB

Their Own Vitinha: Spurs' "future £100m" Star Must Now Start Every Game
-----------------------------------------------------------------------

 ![Their own Vitinha: Spurs' "future £100m" star must now start every game](https://static0.footballfancastimages.com/wordpress/wp-content/uploads/2025/11/vitinha-vs-spurs-stats.jpg?q=49&fit=crop&w=825&dpr=2) <small>www.footballfancast.com</small>Their own Vitinha: Spurs' "future £100m" star must now start every game

'We Are Not Favourites': Vitinha On Portugal’s Status Ahead Of 2026 World Cup - Football
----------------------------------------------------------------------------------------

 !['We are not favourites': Vitinha on Portugal’s status ahead of 2026 World Cup - Football](https://pictures.tribuna.com/image/5ce33d70-6e4f-4b7a-80a3-85e7e2f600d9?width=1920&quality=70) <small>tribuna.com</small>'We are not favourites': Vitinha on Portugal’s status ahead of 2026 World Cup - Football ...

Vitinha Of Portugal During The FIFA World Cup Qatar 2022 Round Of 16... News Photo - Getty Images
-------------------------------------------------------------------------------------------------

 ![Vitinha of Portugal during the FIFA World Cup Qatar 2022 Round of 16... News Photo - Getty Images](https://media.gettyimages.com/id/1245424014/photo/portugal-v-switzerland-round-of-16-fifa-world-cup-qatar-2022.jpg?s=1024x1024&w=gi&k=20&c=Or0RxjKbt-I5XG6JAFWHfzo_v1MQW98Zexh_bTsUI6A=) <small>www.gettyimages.co.uk</small>Vitinha of Portugal during the FIFA World Cup Qatar 2022 Round of 16... News Photo - Getty Images

Vitinha: From Failed Wolves Loan To Becoming The World's Best Midfielder At PSG | Goal.com
------------------------------------------------------------------------------------------

 ![Vitinha: From failed Wolves loan to becoming the world's best midfielder at PSG | Goal.com](https://assets.goal.com/images/v3/blt85cdfe2c0dae1d0f/Header-Vitinha-16-9.jpg?auto=webp&format=pjpg&width=2048&quality=60) <small>www.goal.com</small>Vitinha: From failed Wolves loan to becoming the world's best midfielder at PSG | Goal.com

Vitinha Of Portugal Passes The Ball During The FIFA World Cup Round Of 32 Game Between Portugal
-----------------------------------------------------------------------------------------------

 ![Vitinha of Portugal passes the ball during the FIFA World Cup Round of 32 game between Portugal](https://l450v.alamy.com/450v/3erc617/portugals-vitinha-passes-the-ball-forward-during-the-fifa-world-cup-2026-group-k-match-between-portugal-and-congo-dr-at-houston-stadium-on-june-17-2026-in-houston-united-states-photo-by-torbjorn-tandedefodi-images-3erc617.jpg) <small>www.alamy.com</small>Vitinha of Portugal passes the ball during the FIFA World Cup Round of 32 game between Portugal ...

Portugal's Vitinha In Action During The FIFA World Cup European Qualifying Match At The Jose
--------------------------------------------------------------------------------------------

 ![Portugal's Vitinha in action during the FIFA World Cup European Qualifying match at the Jose](https://c8.alamy.com/comp/3CWEED6/portugals-vitinha-in-action-during-the-fifa-world-cup-european-qualifying-match-at-the-jose-alvalade-stadium-lisbon-picture-date-saturday-october-11-2025-3CWEED6.jpg) <small>www.alamy.com</small>Portugal's Vitinha in action during the FIFA World Cup European Qualifying match at the Jose ...

‘Portugal Has A Very Good Team And We're One Of The Favorites’: Vitinha On 2026 World Cup
-----------------------------------------------------------------------------------------

 ![‘Portugal has a very good team and we're one of the favorites’: Vitinha on 2026 World Cup](https://pictures.tribuna.com/image/507d4cd4-299e-4378-9590-436a805e33c7?width=1920&quality=70) <small>tribuna.com</small>‘Portugal has a very good team and we're one of the favorites’: Vitinha on 2026 World Cup ...

Qatar. 02nd Dec, 2022. DOHA - Vitinha Of Portugal During The FIFA World Cup Qatar 2022 Group H
----------------------------------------------------------------------------------------------

 ![Qatar. 02nd Dec, 2022. DOHA - Vitinha of Portugal during the FIFA World Cup Qatar 2022 group H](https://c8.alamy.com/comp/2KYY66W/qatar-02nd-dec-2022-doha-vitinha-of-portugal-during-the-fifa-world-cup-qatar-2022-group-h-match-between-south-korea-and-portugal-at-education-city-stadium-on-december-2-2022-in-doha-qatar-ap-dutch-height-maurice-of-stone-credit-anpalamy-live-news-2KYY66W.jpg) <small>www.alamy.com</small>Qatar. 02nd Dec, 2022. DOHA - Vitinha of Portugal during the FIFA World Cup Qatar 2022 group H ...

Paris Saint-Germain's Vitinha Celebrates Scoring His Side's Second Goal During The Club World
---------------------------------------------------------------------------------------------

 ![Paris Saint-Germain's Vitinha celebrates scoring his side's second goal during the Club World](https://c8.alamy.com/comp/3BJG4BK/paris-saint-germains-vitinha-celebrates-scoring-his-sides-second-goal-during-the-club-world-cup-group-b-soccer-match-between-psg-and-atletico-madrid-in-pasadena-calif-sunday-june-15-2025-ap-photojae-hong-3BJG4BK.jpg) <small>www.alamy.com</small>Paris Saint-Germain's Vitinha celebrates scoring his side's second goal during the Club World ...

Portugal's Vitinha During The 2026 FIFA World Cup European Qualifying, Group F Match At The
-------------------------------------------------------------------------------------------

 ![Portugal's Vitinha during the 2026 FIFA World Cup European Qualifying, Group F match at the](https://c8.alamy.com/comp/3D55CYY/portugals-vitinha-during-the-2026-fifa-world-cup-european-qualifying-group-f-match-at-the-aviva-stadium-in-dublin-ireland-picture-date-thursday-november-13-2025-3D55CYY.jpg) <small>www.alamy.com</small>Portugal's Vitinha during the 2026 FIFA World Cup European Qualifying, Group F match at the ...

Vitinha Of Portugal Poses During The Official FIFA World Cup Qatar... News Photo - Getty Images
-----------------------------------------------------------------------------------------------

 ![Vitinha of Portugal poses during the official FIFA World Cup Qatar... News Photo - Getty Images](https://media.gettyimages.com/id/1443058055/photo/portugal-portraits-fifa-world-cup-qatar-2022.jpg?s=1024x1024&w=gi&k=20&c=xh3lPlKdOlzvZo__E9Yiflidz7o1ISalkh-ZsxYTvkg=) <small>www.gettyimages.com</small>Vitinha of Portugal poses during the official FIFA World Cup Qatar... News Photo - Getty Images

Top 5 Debutants To Watch At FIFA World Cup 2026 Ft. Lamine Yamal, Vitinha | Football News
-----------------------------------------------------------------------------------------

 ![Top 5 debutants to watch at FIFA World Cup 2026 ft. Lamine Yamal, Vitinha | Football News](https://images.news9live.com/wp-content/uploads/2026/06/Vitinha-1536x1042.jpeg) <small>www.news9live.com</small>Top 5 debutants to watch at FIFA World Cup 2026 ft. Lamine Yamal, Vitinha | Football News ...

Vitinha Stats: Goals, Assists &amp; Passing Data | Squawka
----------------------------------------------------------

 ![Vitinha Stats: Goals, Assists & Passing Data | Squawka](https://media.squawka.com/images/sites/15/2026/06/18134238/ChatGPT-Image-Jun-18-2026-at-06_38_17-PM-1024x576.jpg) <small>www.squawka.com</small>Vitinha Stats: Goals, Assists &amp; Passing Data | Squawka

Portugal's Vitinha Attempts A Shot At Goal During A World Cup 2026 Group F Qualifying Soccer
--------------------------------------------------------------------------------------------

 ![Portugal's Vitinha attempts a shot at goal during a World Cup 2026 group F qualifying soccer](https://c8.alamy.com/comp/3CYE9X1/portugals-vitinha-attempts-a-shot-at-goal-during-a-world-cup-2026-group-f-qualifying-soccer-match-between-portugal-and-hungary-in-lisbon-tuesday-oct-14-2025-ap-photoarmando-franca-3CYE9X1.jpg) <small>www.alamy.com</small>Portugal's Vitinha attempts a shot at goal during a World Cup 2026 group F qualifying soccer ...

Vitinha Of Portugal During The FIFA World Cup Qatar 2022 Group H... News Photo - Getty Images
---------------------------------------------------------------------------------------------

 ![Vitinha of Portugal during the FIFA World Cup Qatar 2022 Group H... News Photo - Getty Images](https://media.gettyimages.com/id/1245375097/photo/korea-republic-v-portugal-group-h-fifa-world-cup-qatar-2022.jpg?s=1024x1024&w=gi&k=20&c=-MP9uWIdIqSXPhAFQXkw9Eq9vJITHaJ8quyIOmmMfBw=) <small>www.gettyimages.com</small>Vitinha of Portugal during the FIFA World Cup Qatar 2022 Group H... News Photo - Getty Images

Stars, Stats, And Standouts: Top Players From The 2025 FIFA Club World Cup
--------------------------------------------------------------------------

 ![Stars, Stats, and Standouts: Top Players from the 2025 FIFA Club World Cup](https://technosports.co.in/wp-content/uploads/2025/07/Vitinha-1-1024x683.webp) <small>technosports.co.in</small>Stars, Stats, and Standouts: Top Players from the 2025 FIFA Club World Cup

ðŸš¨Vitinha Wins Man Of The Match In FIFA Club World Cup Clash Against Athletic Club
------------------------------------------------------------------------------------

 ![ðŸš¨Vitinha Wins Man of the Match in FIFA Club World Cup Clash Against Athletic Club](https://lh7-rt.googleusercontent.com/docsz/AD_4nXeGUI-Aftq19waHELw5hch9z6N0z9vJcgqdphMfKG5kn0aCi_dlxCCbt8tor0MfQVgUph0HjgQmD6ZM-YP9t3LCNT-xGSJQPmaBqfN23vspO0xVsp9dJiHBVOHujhH3AdJd4TzMxg?key=FbGfJCazVpZAG58_9EceGg) <small>myblogpay.com</small>ðŸš¨Vitinha Wins Man of the Match in FIFA Club World Cup Clash Against Athletic Club

The Best Central Midfielders With High Potential In EA Sports FC 25: Career Mode
--------------------------------------------------------------------------------

 ![The Best Central Midfielders With High Potential In EA Sports FC 25: Career Mode](https://static1.thegamerimages.com/wordpress/wp-content/uploads/2024/10/vitinha-and-his-stats-in-ea-fc25.jpg) <small>www.thegamer.com</small>The Best Central Midfielders With High Potential In EA Sports FC 25: Career Mode

Atlanta, USA, 29th June 2025. Vitinha Of PSG During The Paris Saint Germain Vs Inter Miami CF
---------------------------------------------------------------------------------------------

 ![Atlanta, USA, 29th June 2025. Vitinha of PSG during the Paris Saint Germain vs Inter Miami CF](https://c8.alamy.com/comp/3BNP662/atlanta-usa-29th-june-2025-vitinha-of-psg-during-the-paris-saint-germain-vs-inter-miami-cf-fifa-club-world-cup-match-at-mercedes-benz-stadium-atlanta-picture-credit-should-read-jonathan-moscrop-sportimage-3BNP662.jpg) <small>www.alamy.com</small>Atlanta, USA, 29th June 2025. Vitinha of PSG during the Paris Saint Germain vs Inter Miami CF ...

Portugal At The 2026 FIFA World Cup: What You Need To Know
----------------------------------------------------------

 ![Portugal at the 2026 FIFA World Cup: What You Need to Know](https://www.futbolupdate.com/wp-content/uploads/2026/02/Vitinha-portugal-national-team-1024x768.jpg) <small>www.futbolupdate.com</small>Portugal at the 2026 FIFA World Cup: What You Need to Know

Best In The World? Vitinha Tops Four Major Metrics Against Top Midfielders In 2025/26 Champions
-----------------------------------------------------------------------------------------------

 ![Best in the world? Vitinha tops four major metrics against top midfielders in 2025/26 Champions](https://pictures.tribuna.com/image/cec6ec05-b9db-482d-86b2-a15d4a365640?width=1920&quality=70) <small>tribuna.com</small>Best in the world? Vitinha tops four major metrics against top midfielders in 2025/26 Champions ...

Paris saint-germain's vitinha celebrates scoring his side's second goal during the club world. Ðÿš¨vitinha wins man of the match in fifa club world cup clash against athletic club. Portugal's vitinha controls the ball during a world cup 2026 group f qualifying soccer match ...
