---
title: "Greve Geral No Brasil - O brasil chega a uma greve geral com altos níveis de desemprego"
description: "Trabalhadores do brasil preparam greve geral dia 28 de abril"
date: "2026-06-02"
categories:
- "Uncategorized"
images:
- "https://www.fecesc.org.br/siteprincipal/wp-content/uploads/2017/01/Greve-geral-1917-ok.jpg"
featuredImage: "https://cpp.org.br/wp-content/uploads/2019/06/IMG_5706-184.JPG"
featured_image: "https://www.jpn.up.pt/wp-content/uploads/2025/12/greve_geral1-1152x759.jpg"
image: "https://acervo.oglobo.globo.com/incoming/21264420-b29-b6c/imagemHorizontalFotogaleria/greve.jpg"
---

If you are searching about Metro do Porto "fortemente condicionado" no dia da greve geral - JPN you've visit to the right page. We have 35 Pictures about Metro do Porto "fortemente condicionado" no dia da greve geral - JPN like 2017 - 100 anos da greve geral no Brasil - FECESC, 1ª greve geral do país, em 1917, foi iniciada por mulheres e durou 30 dias - BBC News Brasil and also Às vésperas da greve geral, relembre 7 paralisações que marcaram a história do Brasil. Here you go:

Metro Do Porto "fortemente Condicionado" No Dia Da Greve Geral - JPN
--------------------------------------------------------------------

 ![Metro do Porto "fortemente condicionado" no dia da greve geral - JPN](https://www.jpn.up.pt/wp-content/uploads/2025/12/greve_geral1-1152x759.jpg) <small>www.jpn.up.pt</small>Metro do Porto "fortemente condicionado" no dia da greve geral - JPN

Greve Geral é Vitoriosa E Demonstra Acirramento Da Luta De Classes No Brasil – Sindibancários ES
------------------------------------------------------------------------------------------------

 ![Greve geral é vitoriosa e demonstra acirramento da luta de classes no Brasil – Sindibancários ES](https://www.bancarios-es.org.br/wp-content/uploads/2017/05/greve-geral-28deabril-3.jpg) <small>www.bancarios-es.org.br</small>Greve geral é vitoriosa e demonstra acirramento da luta de classes no Brasil – Sindibancários ES

Greve Geral De 1917: O Que Foi, As Principais Características E Causas - Toda Matéria
-------------------------------------------------------------------------------------

 ![Greve Geral de 1917: o que foi, as principais características e causas - Toda Matéria](https://static.todamateria.com.br/upload/gr/ev/greve-geral-de-1917-og.jpg) <small>www.todamateria.com.br</small>Greve Geral de 1917: o que foi, as principais características e causas - Toda Matéria

Imprensa Internacional Destaca Brasil; BBC Vê 1ª Greve Geral Em Mais De 2 Décadas - Pequenas
--------------------------------------------------------------------------------------------

 ![Imprensa internacional destaca Brasil; BBC vê 1ª greve geral em mais de 2 décadas - Pequenas](https://s2.glbimg.com/ZUv7xxUmP55dYzk4H9ue63xjTm0=/940x523/e.glbimg.com/og/ed/f/original/2017/04/28/33337301181_5a55568819_k.jpg) <small>revistapegn.globo.com</small>Imprensa internacional destaca Brasil; BBC vê 1ª greve geral em mais de 2 décadas - Pequenas ...

Contribuição Especial #28: A Greve Geral De 1903 No Rio De Janeiro
------------------------------------------------------------------

 ![Contribuição Especial #28: A Greve Geral de 1903 no Rio de Janeiro](https://i0.wp.com/lehmt.org/wp-content/uploads/2020/11/ce-riani-capa.jpg?w=1208&ssl=1) <small>lehmt.org</small>Contribuição Especial #28: A Greve Geral de 1903 no Rio de Janeiro

Greve Geral No Brasil: A Volta Da Centralidade Do Trabalho
----------------------------------------------------------

 ![Greve geral no Brasil: a volta da centralidade do trabalho](https://santosbancarios.com.br/tim.php?src=uploads/images/2017/04/greve-geral-no-brasil-a-volta-da-centralidade-do-trabalho-1493551799.jpg&w=1200) <small>santosbancarios.com.br</small>Greve geral no Brasil: a volta da centralidade do trabalho

O Direito De Greve No Brasil: Aspectos Culturais E Etimológicos | Jusbrasil
---------------------------------------------------------------------------

 ![O Direito de Greve no Brasil: aspectos culturais e etimológicos | Jusbrasil](https://imgs.jusbr.com/publications/images/fdbc0169a7e47eeb6063951f3df62590) <small>www.jusbrasil.com.br</small>O Direito de Greve no Brasil: aspectos culturais e etimológicos | Jusbrasil

Greve Geral: Confira Como Foram Os Protestos Desta Sexta No País | VEJA
-----------------------------------------------------------------------

 ![Greve geral: confira como foram os protestos desta sexta no país | VEJA](https://veja.abril.com.br/wp-content/uploads/2017/04/brasil-greve-1989-19890314-001.jpg?resize=2048) <small>veja.abril.com.br</small>Greve geral: confira como foram os protestos desta sexta no país | VEJA

Greve Geral No Brasil - FENPROF
-------------------------------

 ![Greve Geral no Brasil - FENPROF](https://www.fenprof.pt/media/download/FE38B050EEE04981C29238426DC9D2E0/imagem_2.jpg) <small>www.fenprof.pt</small>Greve Geral no Brasil - FENPROF

Greve Geral Juntou Centenas Nos Aliados. Governo Fala Em Adesão "inexpressiva" - JPN
------------------------------------------------------------------------------------

 ![Greve Geral juntou centenas nos Aliados. Governo fala em adesão "inexpressiva" - JPN](https://www.jpn.up.pt/wp-content/uploads/2025/12/greve_geral9.jpg) <small>www.jpn.up.pt</small>Greve Geral juntou centenas nos Aliados. Governo fala em adesão "inexpressiva" - JPN

2017 - 100 Anos Da Greve Geral No Brasil - FECESC
-------------------------------------------------

 ![2017 - 100 anos da greve geral no Brasil - FECESC](https://www.fecesc.org.br/siteprincipal/wp-content/uploads/2017/01/Greve-geral-1917-ok.jpg) <small>www.fecesc.org.br</small>2017 - 100 anos da greve geral no Brasil - FECESC

Como Estão As Negociações Para O Fim Da Greve Nas Universidades Federais | Brasil | Valor Econômico
---------------------------------------------------------------------------------------------------

 ![Como estão as negociações para o fim da greve nas universidades federais | Brasil | Valor Econômico](https://s2-valor.glbimg.com/GGpKdaKdVPWFJrk4ADf9JxSqfBE=/0x0:5472x3648/888x0/smart/filters:strip_icc()/i.s3.glbimg.com/v1/AUTH_63b422c2caee4269b8b34177e8876b93/internal_photos/bs/2024/Y/I/dlFxBfSY2VcFOHTkJPjQ/trbr8080.jpg) <small>valor.globo.com</small>Como estão as negociações para o fim da greve nas universidades federais | Brasil | Valor Econômico

Em Dia De Greve, Linha Privatizada E Elogiada Apresenta Falhas | Agência Brasil
-------------------------------------------------------------------------------

 ![Em dia de greve, linha privatizada e elogiada apresenta falhas | Agência Brasil](https://imagens.ebc.com.br/N92M-SJjf0ocGFvAMyM4rL7uldc=/1600x800/https://agenciabrasil.ebc.com.br/sites/default/files/thumbnails/image/assembleia_greve_07.jpg?itok=Vq4gG9T5) <small>agenciabrasil.ebc.com.br</small>Em dia de greve, linha privatizada e elogiada apresenta falhas | Agência Brasil

Greves Gerais No Brasil | Acervo
--------------------------------

 ![Greves gerais no Brasil | Acervo](https://acervo.oglobo.globo.com/incoming/21264420-b29-b6c/imagemHorizontalFotogaleria/greve.jpg) <small>acervo.oglobo.globo.com</small>Greves gerais no Brasil | Acervo

O Brasil Chega A Uma Greve Geral Com Altos Níveis De Desemprego
---------------------------------------------------------------

 ![O Brasil chega a uma greve geral com altos níveis de desemprego](https://uniglobalunion.org/wp-content/uploads/dia-14-de-junho-e-greve-geral-no-brasil-sinprocaxias1559914427-884779_1.jpg) <small>uniglobalunion.org</small>O Brasil chega a uma greve geral com altos níveis de desemprego

Vai Ter Greve Geral Em Junho Que Vai Parar O Brasil? - OENE
-----------------------------------------------------------

 ![Vai ter greve geral em junho que vai parar o Brasil? - OENE](https://oene.com.br/wp-content/uploads/2024/05/Greve.jpg) <small>oene.com.br</small>Vai ter greve geral em junho que vai parar o Brasil? - OENE

Às Vésperas Da Greve Geral, Relembre 7 Paralisações Que Marcaram A História Do Brasil
-------------------------------------------------------------------------------------

 ![Às vésperas da greve geral, relembre 7 paralisações que marcaram a história do Brasil](https://smetal.org.br/wp-content/uploads/2019/06/E112948-F00001-G426.jpeg) <small>smetal.org.br</small>Às vésperas da greve geral, relembre 7 paralisações que marcaram a história do Brasil

Há 100 Anos, Ocorria A Primeira Greve Geral No Brasil | Nova Escola
-------------------------------------------------------------------

 ![Há 100 anos, ocorria a primeira greve geral no Brasil | Nova Escola](https://nova-escola-producao.s3.amazonaws.com/2mWWWyKhRvvC2GmGkBXvV96JX5eUu2CqN773hMu8SDYn2aZxKS9pj5FcHN9d/grevegeralde1917-3.gif) <small>novaescola.org.br</small>Há 100 anos, ocorria a primeira greve geral no Brasil | Nova Escola

Greve Geral é Legítima, Diz Ministério Público Do Trabalho - Jornal O Globo
---------------------------------------------------------------------------

 ![Greve geral é legítima, diz Ministério Público do Trabalho - Jornal O Globo](https://ogimg.infoglobo.com.br/economia/21263727-67d-e72/FT1086A/760/greve.jpg) <small>oglobo.globo.com</small>Greve geral é legítima, diz Ministério Público do Trabalho - Jornal O Globo

Exposições | AEL - Arquivo Edgard Leuenroth
-------------------------------------------

 ![Exposições | AEL - Arquivo Edgard Leuenroth](https://ael.ifch.unicamp.br/pf-ael/2022-08/Centenário da greve geral no Brasil1.jpg) <small>ael.ifch.unicamp.br</small>Exposições | AEL - Arquivo Edgard Leuenroth

Greves Gerais No Brasil | Acervo
--------------------------------

 ![Greves gerais no Brasil | Acervo](https://acervo.oglobo.globo.com/incoming/21264424-a06-fe6/imagemHorizontalFotogaleria/greve.jpg) <small>acervo.oglobo.globo.com</small>Greves gerais no Brasil | Acervo

Greve Geral Juntou Centenas Nos Aliados. Governo Fala Em Adesão "inexpressiva" - JPN
------------------------------------------------------------------------------------

 ![Greve Geral juntou centenas nos Aliados. Governo fala em adesão "inexpressiva" - JPN](https://www.jpn.up.pt/wp-content/uploads/2025/12/greve_geral8.jpg) <small>www.jpn.up.pt</small>Greve Geral juntou centenas nos Aliados. Governo fala em adesão "inexpressiva" - JPN

Greve Geral No Brasil: Paralisação De 1917 Deixou Legado, Mas País Evoluiu Pouco, Dizem
---------------------------------------------------------------------------------------

 ![Greve geral no Brasil: paralisação de 1917 deixou legado, mas país evoluiu pouco, dizem](https://agenciadenoticias.uniceub.br/wp-content/uploads/2017/04/greve-operaria-i-republica.png) <small>agenciadenoticias.uniceub.br</small>Greve geral no Brasil: paralisação de 1917 deixou legado, mas país evoluiu pouco, dizem ...

Greve Geral De 28 De Abril Acontece 100 Anos Após Primeira Greve Geral Brasileira – Sindicato
---------------------------------------------------------------------------------------------

 ![Greve Geral de 28 de abril acontece 100 anos após primeira Greve Geral brasileira – Sindicato](http://www.secpf.com.br/site/wp-content/uploads/2017/05/030117-greve-geral-1917-2.jpg) <small>www.secpf.com.br</small>Greve Geral de 28 de abril acontece 100 anos após primeira Greve Geral brasileira – Sindicato ...

Greve Do Dia 14 De Junho Acontece 102 Anos Depois Da 1º Greve Geral
-------------------------------------------------------------------

 ![Greve do dia 14 de junho acontece 102 anos depois da 1º Greve Geral](https://sismmac.org.br/wp-content/uploads/2022/07/20190522_nossaslutas.jpg) <small>sismmac.org.br</small>Greve do dia 14 de junho acontece 102 anos depois da 1º Greve Geral

Trabalhadores Do Brasil Preparam Greve Geral Dia 28 De Abril - FECESC
---------------------------------------------------------------------

 ![Trabalhadores do Brasil preparam Greve Geral dia 28 de abril - FECESC](http://www.fecesc.org.br/siteprincipal/wp-content/uploads/2017/04/BANNER_SITE-greve_geral.jpg) <small>www.fecesc.org.br</small>Trabalhadores do Brasil preparam Greve Geral dia 28 de abril - FECESC

Greve Geral Ocorre Parcialmente Em Todo O Brasil - CPP - Centro Do Professorado Paulista
----------------------------------------------------------------------------------------

 ![Greve geral ocorre parcialmente em todo o Brasil - CPP - Centro do Professorado Paulista](https://cpp.org.br/wp-content/uploads/2019/06/IMG_5706-184.JPG) <small>cpp.org.br</small>Greve geral ocorre parcialmente em todo o Brasil - CPP - Centro do Professorado Paulista

Greve Geral No Brasil 2023
--------------------------

 ![Greve Geral no Brasil 2023](https://bacana.news/wp-content/uploads/2025/10/greve-geral-7.jpeg) <small>bacana.news</small>Greve Geral no Brasil 2023

Greve Geral De 1917 – Primeira Grande Greve No Brasil – Anarkio|Anarquia|Anarchy
--------------------------------------------------------------------------------

 ![Greve Geral de 1917 – Primeira grande greve no Brasil – Anarkio|Anarquia|Anarchy](https://anarkio.net/wp-content/uploads/2025/05/greve_001.png) <small>anarkio.net</small>Greve Geral de 1917 – Primeira grande greve no Brasil – Anarkio|Anarquia|Anarchy

Greve Geral: O Que Você Precisa Saber Sobre A Tentativa De Parar O País Pela 1ª Vez Em 20 Anos
----------------------------------------------------------------------------------------------

 ![Greve geral: o que você precisa saber sobre a tentativa de parar o país pela 1ª vez em 20 anos](https://ichef.bbci.co.uk/news/1024/branded_portuguese/11542/production/_95787907_931378-bancariosbc-9895.jpg) <small>www.bbc.com</small>Greve geral: o que você precisa saber sobre a tentativa de parar o país pela 1ª vez em 20 anos ...

Greve Geral No Brasil - FENPROF
-------------------------------

 ![Greve Geral no Brasil - FENPROF](https://www.fenprof.pt/media/download/4783602DAB73BB7D72DFB12734684365/screen_shot_2017-04-28_at_12-11-15.png) <small>www.fenprof.pt</small>Greve Geral no Brasil - FENPROF

1ª Greve Geral Do País, Em 1917, Foi Iniciada Por Mulheres E Durou 30 Dias - BBC News Brasil
--------------------------------------------------------------------------------------------

 ![1ª greve geral do país, em 1917, foi iniciada por mulheres e durou 30 dias - BBC News Brasil](https://ichef.bbci.co.uk/news/1024/branded_portuguese/93AA/production/_95820873_hi258p.jpg) <small>www.bbc.com</small>1ª greve geral do país, em 1917, foi iniciada por mulheres e durou 30 dias - BBC News Brasil

Como Foi A Greve Geral 2019 No Brasil: Principais Cidades E Protestos
---------------------------------------------------------------------

 ![Como foi a greve geral 2019 no Brasil: principais cidades e protestos](https://media.gazetadopovo.com.br/2019/06/14214937/como-foi-greve-geral-2019.jpg-960x540.jpg) <small>www.gazetadopovo.com.br</small>Como foi a greve geral 2019 no Brasil: principais cidades e protestos

Às Vésperas Da Greve Geral, Relembre 7 Paralisações Que Marcaram A História Do Brasil
-------------------------------------------------------------------------------------

 ![Às vésperas da greve geral, relembre 7 paralisações que marcaram a história do Brasil](https://smetal.org.br/wp-content/uploads/2019/06/E112948-F00001-G426-630x380.jpeg) <small>smetal.org.br</small>Às vésperas da greve geral, relembre 7 paralisações que marcaram a história do Brasil

Levante Popular Da Juventude - 100 ANOS DA PRIMEIRA GREVE GERAL NO BRASIL Em Julho De 1917
------------------------------------------------------------------------------------------

 ![Levante Popular da Juventude - 100 ANOS DA PRIMEIRA GREVE GERAL NO BRASIL Em julho de 1917](https://lookaside.fbsbx.com/lookaside/crawler/media/?media_id=1569483156450566) <small>www.facebook.com</small>Levante Popular da Juventude - 100 ANOS DA PRIMEIRA GREVE GERAL NO BRASIL Em julho de 1917 ...

Em dia de greve, linha privatizada e elogiada apresenta falhas. Metro do porto "fortemente condicionado" no dia da greve geral. Imprensa internacional destaca brasil; bbc vê 1ª greve geral em mais de 2 décadas
