---
title: "Kimberly Powell Musc Florence Sc - kimberly powell"
description: "Faculty staff"
date: "2026-02-20"
categories:
- "Uncategorized"
images:
- "https://www.getcare.muschealth.org/images/width=194,height=248,fit=cover/https://a.mktgcdn.com/p/Ez16s5P3XprqNrtCfEAQn285khdOdYy9xSWV3OGo-lY/1500x1793.jpg"
featuredImage: "https://media.licdn.com/dms/image/D5622AQEBItJYa-ypGw/feedshare-shrink_800/0/1708957758233?e=2147483647&amp;v=beta&amp;t=xMzVZhCGZYMoNSETCR7it3dpNlrrkZKiht8hIB45sdI"
featured_image: "https://media.licdn.com/dms/image/v2/D5622AQH-9yhDoWzSRg/feedshare-shrink_800/feedshare-shrink_800/0/1691613719431?e=2147483647&amp;v=beta&amp;t=V6h7FJjIMWbICbGHmyK-sIZnB8eFpxVdqNLLvCQujok"
image: "https://www.flochamber.com/wp-content/uploads/2025/02/MUSC-Hollings-1030x648.jpg"
---

If you are looking for Kimberly Powell on LinkedIn: #speakupsisawards2024 #susawards2024 #susawardsfinalist2024 #voteforme you've came to the right web. We have 35 Pictures about Kimberly Powell on LinkedIn: #speakupsisawards2024 #susawards2024 #susawardsfinalist2024 #voteforme like Kimberly Dawn Powell, FNP-BC - Florence, SC, MUSC - Proud to spotlight our incredible OB/GYN physicians, nurses and Women’s Pavilion and also About Us. Read more:

Kimberly Powell On LinkedIn: #speakupsisawards2024 #susawards2024 #susawardsfinalist2024 #voteforme
---------------------------------------------------------------------------------------------------

 ![Kimberly Powell on LinkedIn: #speakupsisawards2024 #susawards2024 #susawardsfinalist2024 #voteforme](https://media.licdn.com/dms/image/D4D22AQHnpcTAQwDtzg/feedshare-shrink_2048_1536/0/1710527087105?e=2147483647&v=beta&t=ABcsxN8h4u0sB8mJDrZKm9poz4E6UKa_kzE8Y0XAmbE) <small>www.linkedin.com</small>Kimberly Powell on LinkedIn: #speakupsisawards2024 #susawards2024 #susawardsfinalist2024 #voteforme

MUSC Annual Senior Expo At Charleston Area Convention Center – WCBD News 2
--------------------------------------------------------------------------

 ![MUSC annual senior expo at Charleston Area Convention Center – WCBD News 2](https://c104216-ucdn.mp.lura.live/expiretime=2082787200/4c08df6ce442fb11cc48e383369b19668d18a074c61810ffda3ef05a959d40d9/iupl_lin/491/D30/491D3060FB9B3B7768475E3D089BC47E.jpg) <small>www.counton2.com</small>MUSC annual senior expo at Charleston Area Convention Center – WCBD News 2

Kimberly Powell On LinkedIn: #regionsdei #womenshistorymonth #honoringlatrishajemison… | 72 Comments
----------------------------------------------------------------------------------------------------

 ![Kimberly Powell on LinkedIn: #regionsdei #womenshistorymonth #honoringlatrishajemison… | 72 comments](https://media.licdn.com/dms/image/D4E22AQFhHY-eTdeNUg/feedshare-shrink_2048_1536/0/1711763604506?e=2147483647&v=beta&t=y5E0BzT80MHCEbXxaauipEe7VGR3kCqAiWq1H00vSbM) <small>www.linkedin.com</small>Kimberly Powell on LinkedIn: #regionsdei #womenshistorymonth #honoringlatrishajemison… | 72 comments

Kimberly Powell Honored For Pioneering Work In Health Informatics And Gerontology
---------------------------------------------------------------------------------

 ![Kimberly Powell honored for pioneering work in health informatics and gerontology](https://nursing.missouri.edu/wp-content/uploads/2024/06/Kimberly-Powell-FAMIA-induction-1024x1024.png) <small>nursing.missouri.edu</small>Kimberly Powell honored for pioneering work in health informatics and gerontology

MUSC - Proud To Spotlight Our Incredible OB/GYN Physicians, Nurses And Women’s Pavilion
---------------------------------------------------------------------------------------

 ![MUSC - Proud to spotlight our incredible OB/GYN physicians, nurses and Women’s Pavilion](https://lookaside.fbsbx.com/lookaside/crawler/media/?media_id=1188988316601306) <small>www.facebook.com</small>MUSC - Proud to spotlight our incredible OB/GYN physicians, nurses and Women’s Pavilion ...

The Role Of Genetic Counselors In Healthcare Today | South Carolina Public Radio
--------------------------------------------------------------------------------

 ![The role of genetic counselors in healthcare today | South Carolina Public Radio](https://npr.brightspotcdn.com/dims4/default/a3f5f25/2147483647/strip/true/crop/342x480+0+0/resize/880x1235!/quality/90/?url=http%3A%2F%2Fnpr-brightspot.s3.amazonaws.com%2F8b%2F02%2Ff9575dac404abec9c79907d7efdf%2Ffoil-kimberly-2025.jpg) <small>www.southcarolinapublicradio.org</small>The role of genetic counselors in healthcare today | South Carolina Public Radio

Kimberly Powell
---------------

 ![Kimberly Powell](https://robbreport.com/wp-content/uploads/2025/03/56530266-E7BC-4572-A806-5A5BBF318742.jpeg) <small>robbreport.com</small>Kimberly Powell

Kimberly Powell - PhD, RN, FAMIA, FAAN | LinkedIn
-------------------------------------------------

 ![Kimberly Powell - PhD, RN, FAMIA, FAAN | LinkedIn](https://media.licdn.com/dms/image/v2/D4E03AQELNZTNqlomtw/profile-displayphoto-scale_200_200/B4EZiemXJLHoAY-/0/1755007513927?e=2147483647&v=beta&t=9aVHNfS1ADg7fyk_hbUBaCziZDNeQpkjMX0xwrnhkTQ) <small>www.linkedin.com</small>Kimberly Powell - PhD, RN, FAMIA, FAAN | LinkedIn

Kimberly Powell On LinkedIn: #bam #microsoftlife #non | 18 Comments
-------------------------------------------------------------------

 ![Kimberly Powell on LinkedIn: #bam #microsoftlife #non | 18 comments](https://media.licdn.com/dms/image/D5622AQFCzBGRKebqUw/feedshare-shrink_2048_1536/0/1702293686068?e=2147483647&v=beta&t=DIzM03st0R_O-XokLrq9eT1QYWLGlsxsEcz-y4-BSds) <small>www.linkedin.com</small>Kimberly Powell on LinkedIn: #bam #microsoftlife #non | 18 comments

Kimberly Powell On LinkedIn: #womenwholead #mentorship #success #thepurpledoorwellnesshouse…
--------------------------------------------------------------------------------------------

 ![Kimberly Powell on LinkedIn: #womenwholead #mentorship #success #thepurpledoorwellnesshouse…](https://media.licdn.com/dms/image/D4E22AQFEXBAgYvTBYg/feedshare-shrink_2048_1536/0/1716164335026?e=2147483647&v=beta&t=wOCsAhyrEMQHVUnhTT1IhqfJ_a6E7rx2TyyA5C6T2nQ) <small>www.linkedin.com</small>Kimberly Powell on LinkedIn: #womenwholead #mentorship #success #thepurpledoorwellnesshouse…

Rising Stars Program - MLA
--------------------------

 ![Rising Stars Program - MLA](https://www.mlanet.org/wp-content/uploads/emx_profile_photos/Kim-Powell-2024-b-scaled.jpg) <small>www.mlanet.org</small>Rising Stars Program - MLA

Kimberly Dawn Powell, FNP-BC Hospital Medicine In Florence, SC
--------------------------------------------------------------

 ![Kimberly Dawn Powell, FNP-BC Hospital Medicine in Florence, SC](https://www.getcare.muschealth.org/images/height=200,width=200,fit=contain/https://a.mktgcdn.com/p/MZtNyXWKtJuq7pHavqqRZ80iX7VFcx3qoxwF8vbHrsE/2100x2678.jpg) <small>www.getcare.muschealth.org</small>Kimberly Dawn Powell, FNP-BC Hospital Medicine in Florence, SC

About Us
--------

 ![About Us](https://img1.wsimg.com/isteam/ip/44d8c6eb-5847-48e2-aff5-373d62931250/blob.png/:/cr=t:0%25,l:0%25,w:100%25,h:67.46%25/rs=w:365,h:365,cg:true) <small>757wecare.org</small>About Us

MUSC Health Florence Medical Center Nurses Receive Palmetto Gold Award
----------------------------------------------------------------------

 ![MUSC Health Florence Medical Center nurses receive Palmetto Gold Award](https://bloximages.newyork1.vip.townnews.com/scnow.com/content/tncms/assets/v3/editorial/7/51/751caae6-654b-11e9-ada8-e37435cee750/5cbe3c0894bba.image.jpg?resize=1200%2C754) <small>scnow.com</small>MUSC Health Florence Medical Center nurses receive Palmetto Gold Award

Kimberly Powell - At | LinkedIn
-------------------------------

 ![Kimberly Powell - at | LinkedIn](https://media.licdn.com/dms/image/v2/C5603AQG7MpUq0T4ubw/profile-displayphoto-shrink_200_200/profile-displayphoto-shrink_200_200/0/1553727787738?e=2147483647&v=beta&t=5aWFBsSISKwU0iaM9MLju6yI0ZoozBkJ4deboxA6qnc) <small>www.linkedin.com</small>Kimberly Powell - at | LinkedIn

Kimberly Dawn Powell, FNP-BC - Florence, SC
-------------------------------------------

 ![Kimberly Dawn Powell, FNP-BC - Florence, SC](https://www.getcare.muschealth.org/images/width=194,height=248,fit=cover/https://a.mktgcdn.com/p/Ez16s5P3XprqNrtCfEAQn285khdOdYy9xSWV3OGo-lY/1500x1793.jpg) <small>www.getcare.muschealth.org</small>Kimberly Dawn Powell, FNP-BC - Florence, SC

Kimberly Powell Honored For Pioneering Work In Health Informatics And Gerontology
---------------------------------------------------------------------------------

 ![Kimberly Powell honored for pioneering work in health informatics and gerontology](https://nursing.missouri.edu/wp-content/uploads/2024/05/Congratulations.png) <small>nursing.missouri.edu</small>Kimberly Powell honored for pioneering work in health informatics and gerontology

Kimberly Powell On LinkedIn: I Am Honored To Have Been Nominated And Awarded The BAM WW - Gerald
------------------------------------------------------------------------------------------------

 ![Kimberly Powell on LinkedIn: I am honored to have been nominated and awarded the BAM WW - Gerald](https://media.licdn.com/dms/image/D5622AQHpO63Gdvh9pA/feedshare-shrink_2048_1536/0/1686869396106?e=2147483647&v=beta&t=br0qoF38jSsM6UDaZFY07EPc3IwdUveCofo65zD08K8) <small>www.linkedin.com</small>Kimberly Powell on LinkedIn: I am honored to have been nominated and awarded the BAM WW - Gerald ...

Kimberly Powell On LinkedIn: Had A Fantastic Time Hosting The PowerUp Strategic Educators
-----------------------------------------------------------------------------------------

 ![Kimberly Powell on LinkedIn: Had a fantastic time hosting the PowerUp Strategic Educators](https://media.licdn.com/dms/image/D5622AQEBItJYa-ypGw/feedshare-shrink_800/0/1708957758233?e=2147483647&v=beta&t=xMzVZhCGZYMoNSETCR7it3dpNlrrkZKiht8hIB45sdI) <small>www.linkedin.com</small>Kimberly Powell on LinkedIn: Had a fantastic time hosting the PowerUp Strategic Educators ...

\#muschealth #muscflorence | MUSC Health
----------------------------------------

 ![#muschealth #muscflorence | MUSC Health](https://media.licdn.com/dms/image/v2/D4D10AQH7oGdndmFAqQ/image-shrink_800/image-shrink_800/0/1724850013516?e=2147483647&v=beta&t=-uFiu3aTF3J01vYM9JlY-ldCl9tYeNX-7nZfV6hck8w) <small>www.linkedin.com</small>\#muschealth #muscflorence | MUSC Health

Florence Family Medicine Residency Leadership &amp; Faculty | MUSC Health
-------------------------------------------------------------------------

 ![Florence Family Medicine Residency Leadership & Faculty | MUSC Health](https://d3crna64wemw02.cloudfront.net/image/339713052848/image_5t24bean0927lcaq393p2iso20/-FJPG-S262) <small>muschealth.org</small>Florence Family Medicine Residency Leadership &amp; Faculty | MUSC Health

The Indiana Black Expo Is Happening Now! If You're In The Indianapolis Area, Come Visit. We're
----------------------------------------------------------------------------------------------

 ![The Indiana Black Expo is happening now! If you're in the Indianapolis area, come visit. We're](https://media.licdn.com/dms/image/v2/D5622AQGrtlKpHete3Q/feedshare-shrink_1280/feedshare-shrink_1280/0/1689291358476?e=2147483647&v=beta&t=cdPeRbEBHTdXKbZaTQlRm7oSRrrdnQstTKpCMeSYojM) <small>www.linkedin.com</small>The Indiana Black Expo is happening now! If you're in the Indianapolis area, come visit. We're ...

MUSC Patients And Visitors News | MUSC Health | Charleston SC
-------------------------------------------------------------

 ![MUSC Patients and Visitors News | MUSC Health | Charleston SC](https://muschealth.org/-/sm/news-center-media/news-center-images/2024-images/05/farley.jpg?h=666&w=1000&la=en&hash=D9D02471A81B0EC2FBCCEF7051D1B8BC) <small>muschealth.org</small>MUSC Patients and Visitors News | MUSC Health | Charleston SC

MUSC Presenting Sponsor Of SC7 - Who's On The Move
--------------------------------------------------

 ![MUSC presenting sponsor of SC7 - Who's On The Move](https://whosonthemove.com/wp-content/uploads/2022/01/MUSC-1.jpeg) <small>whosonthemove.com</small>MUSC presenting sponsor of SC7 - Who's On The Move

Kimberly Powell - SR Partner Technical Advisor | LinkedIn
---------------------------------------------------------

 ![Kimberly Powell - SR Partner Technical Advisor | LinkedIn](https://media.licdn.com/dms/image/v2/D5603AQGY1P7BMa4UrA/profile-displayphoto-shrink_200_200/profile-displayphoto-shrink_200_200/0/1709256150173?e=2147483647&v=beta&t=Sr6TwAk9jjQSdKtZX537kaHgDevPQ700DsIYeMP3l0Q) <small>www.linkedin.com</small>Kimberly Powell - SR Partner Technical Advisor | LinkedIn

MUSC Alumni | Charleston SC
---------------------------

 ![MUSC Alumni | Charleston SC](https://lookaside.fbsbx.com/lookaside/crawler/media/?media_id=1332988435297038) <small>www.facebook.com</small>MUSC Alumni | Charleston SC

Board Of Directors — Basic Needs Inc.
-------------------------------------

 ![Board of Directors — Basic Needs Inc.](https://images.squarespace-cdn.com/content/v1/63d48a2e85aa7959f69d2f27/58712eb8-621f-4cbe-b73b-a7e4fbbc934a/Powell_Kim+2005.jpg) <small>www.basicneedsmn.org</small>Board of Directors — Basic Needs Inc.

Kimberly Powell - Vendor Manager - Cricket Wireless | LinkedIn
--------------------------------------------------------------

 ![Kimberly Powell - Vendor Manager - Cricket Wireless | LinkedIn](https://media.licdn.com/dms/image/C4D03AQEM8l-ceokP0g/profile-displayphoto-shrink_800_800/0/1625234024608?e=2147483647&v=beta&t=yuTwtwzeWsuqXRr60NCGM4C3AmKB_OuM8b1Bwo7Epkk) <small>www.linkedin.com</small>Kimberly Powell - Vendor Manager - Cricket Wireless | LinkedIn

MUSC Featured On ChamberLink Radio – Greater Florence Chamber Of Commerce
-------------------------------------------------------------------------

 ![MUSC Featured On ChamberLink Radio – Greater Florence Chamber of Commerce](https://www.flochamber.com/wp-content/uploads/2025/02/MUSC-Hollings-1030x648.jpg) <small>www.flochamber.com</small>MUSC Featured On ChamberLink Radio – Greater Florence Chamber of Commerce

\#locinternships #libraryofcongress | Kimberly Powell, MBA, PMP
---------------------------------------------------------------

 ![#locinternships #libraryofcongress | Kimberly Powell, MBA, PMP](https://media.licdn.com/dms/image/v2/D5622AQH-9yhDoWzSRg/feedshare-shrink_800/feedshare-shrink_800/0/1691613719431?e=2147483647&v=beta&t=V6h7FJjIMWbICbGHmyK-sIZnB8eFpxVdqNLLvCQujok) <small>www.linkedin.com</small>\#locinternships #libraryofcongress | Kimberly Powell, MBA, PMP

Staff Highlights: A Rising Star Among Us – WHSC Library News
------------------------------------------------------------

 ![Staff Highlights: A Rising Star Among Us – WHSC Library News](https://scholarblogs.emory.edu/whscl-news/files/2023/03/Kim-Powell-0121-1024x819.jpg) <small>scholarblogs.emory.edu</small>Staff Highlights: A Rising Star Among Us – WHSC Library News

Faculty Staff | College Of Medicine
-----------------------------------

 ![Faculty Staff | College of Medicine](https://public.med.fsu.edu/images/Faculty/Kimberly.Powell.jpg) <small>public.med.fsu.edu</small>Faculty Staff | College of Medicine

\#757wecare | Kimberly Powell
-----------------------------

 ![#757wecare | Kimberly Powell](https://media.licdn.com/dms/image/v2/D4D22AQFoPHI57dXuRQ/feedshare-shrink_2048_1536/feedshare-shrink_2048_1536/0/1709090005554?e=2147483647&v=beta&t=7kDd4Z7xLRbPcEwOPEFQ8Peee78uFcqBa918VG8-KFM) <small>www.linkedin.com</small>\#757wecare | Kimberly Powell

Kimberly Powell (@KimbePowell) / Posts / X
------------------------------------------

 ![Kimberly Powell (@KimbePowell) / Posts / X](https://pbs.twimg.com/profile_banners/761310478345900032/1470346849) <small>x.com</small>Kimberly Powell (@KimbePowell) / Posts / X

Kimberly Powell - 757 We Care | LinkedIn
----------------------------------------

 ![Kimberly Powell - 757 We Care | LinkedIn](https://media.licdn.com/dms/image/v2/D4E03AQHTD2vp9bw-Fg/profile-displayphoto-shrink_200_200/profile-displayphoto-shrink_200_200/0/1711833604134?e=2147483647&v=beta&t=ze1oQ9t_2gdIDmAoHlyh4f0aYq9JcDpbwZ0yBzIkRo8) <small>www.linkedin.com</small>Kimberly Powell - 757 We Care | LinkedIn

\#locinternships #libraryofcongress. Musc health florence medical center nurses receive palmetto gold award. Faculty staff
