---
title: "Greve Geral Dia 11 Dezembro - Faq: os direitos dos docentes em dia de greve geral"
description: "Greve geral de 11 de dezembro em portugal: razões para participar"
date: "2026-05-27"
categories:
- "Uncategorized"
images:
- "https://bordalo.observador.pt/v2/q:60/rs:fill:1440/c:4096:2730:nowe:0:0/plain/https://s3.observador.pt/wp-content/uploads/2025/12/11173414/dventura-greve-geral-11dez-54-scaled.jpg"
featuredImage: "https://staticx.noticiasilimitadas.pt/jn/image.webp?brand=jn&amp;type=generate&amp;guid=fb434b13-2b30-4ab1-a6bc-4ddd86b96b14&amp;w=3840"
featured_image: "https://static.wixstatic.com/media/d0f32c_9ff1199ee2c34418af0094a43c516733~mv2.png/v1/fill/w_940,h_788,al_c,q_90,enc_avif,quality_auto/d0f32c_9ff1199ee2c34418af0094a43c516733~mv2.png"
image: "https://bordalo.observador.pt/v2/q:60/rs:fill:1440/c:4096:2730:nowe:0:0/plain/https://s3.observador.pt/wp-content/uploads/2025/12/11173327/dventura-greve-geral-11dez-48-scaled.jpg"
---

If you are looking for A greve geral de 11 de dezembro em 38 imagens – Observador you've came to the right page. We have 35 Pics about A greve geral de 11 de dezembro em 38 imagens – Observador like Greve Geral – 24 Horas – Dia 11 de Dezembro de 2025 – SINTTAV Sindicato Nacional dos, GREVE GERAL – Dia 11 de Dezembro | Sincomar - Sindicato de Capitães e Oficiais da Marinha Mercante and also A greve geral de 11 de dezembro em 38 imagens – Observador. Read more:

A Greve Geral De 11 De Dezembro Em 38 Imagens – Observador
----------------------------------------------------------

 ![A greve geral de 11 de dezembro em 38 imagens – Observador](https://bordalo.observador.pt/v2/q:60/rs:fill:1440/c:4096:2730:nowe:0:0/plain/https://s3.observador.pt/wp-content/uploads/2025/12/11173652/dventura-greve-geral-11dez-73-scaled.jpg) <small>observador.pt</small>A greve geral de 11 de dezembro em 38 imagens – Observador

A Greve Geral De 11 De Dezembro Em 38 Imagens – Observador
----------------------------------------------------------

 ![A greve geral de 11 de dezembro em 38 imagens – Observador](https://bordalo.observador.pt/v2/q:60/rs:fill:1440/c:4096:2730:nowe:0:0/plain/https://s3.observador.pt/wp-content/uploads/2025/12/11173246/dventura-greve-geral-11dez-43-scaled.jpg) <small>observador.pt</small>A greve geral de 11 de dezembro em 38 imagens – Observador

S.TO.P. Junta-se à Greve Geral De 11 De Dezembro Com Pré-aviso De Greve Para A Educação
---------------------------------------------------------------------------------------

 ![S.TO.P. junta-se à greve geral de 11 de dezembro com pré-aviso de greve para a educação](https://stop-sindicato.pt/wp-content/uploads/2025/11/S.TO_.P.-Cartaz-Greve-Geral-Educacao-11Dez2025_x1000-724x1024.png) <small>stop-sindicato.pt</small>S.TO.P. junta-se à greve geral de 11 de dezembro com pré-aviso de greve para a educação ...

A Greve Geral De 11 De Dezembro Em 38 Imagens – Observador
----------------------------------------------------------

 ![A greve geral de 11 de dezembro em 38 imagens – Observador](https://bordalo.observador.pt/v2/q:60/rs:fill:1440/c:4096:2730:nowe:0:0/plain/https://s3.observador.pt/wp-content/uploads/2025/12/11173414/dventura-greve-geral-11dez-54-scaled.jpg) <small>observador.pt</small>A greve geral de 11 de dezembro em 38 imagens – Observador

Greve Geral Em Portugal – 11 De Dezembro - FLEMACON
---------------------------------------------------

 ![Greve geral em Portugal – 11 de dezembro - FLEMACON](https://www.flemacon.org/wp-content/uploads/2025/12/WhatsApp-Image-2025-12-12-at-19.45.27-1-696x870.jpeg) <small>www.flemacon.org</small>Greve geral em Portugal – 11 de dezembro - FLEMACON

Motivos Da Adesão à Greve Geral De 11 De Dezembro De 2025
---------------------------------------------------------

 ![Motivos da adesão à Greve Geral de 11 de dezembro de 2025](https://spzn.pt/uploads/noticias/big_1763717239_6728_SPZN_2025_site_novo_(17).png) <small>spzn.pt</small>Motivos da adesão à Greve Geral de 11 de dezembro de 2025

A Greve Geral De 11 De Dezembro Em 38 Imagens – Observador
----------------------------------------------------------

 ![A greve geral de 11 de dezembro em 38 imagens – Observador](https://bordalo.observador.pt/v2/q:60/rs:fill:1440/c:4096:2730:nowe:0:0/plain/https://s3.observador.pt/wp-content/uploads/2025/12/11173327/dventura-greve-geral-11dez-48-scaled.jpg) <small>observador.pt</small>A greve geral de 11 de dezembro em 38 imagens – Observador

A Greve Geral De 11 De Dezembro Em 38 Imagens – Observador
----------------------------------------------------------

 ![A greve geral de 11 de dezembro em 38 imagens – Observador](https://bordalo.observador.pt/v2/q:60/rs:fill:1440/c:4096:2730:nowe:0:0/plain/https://s3.observador.pt/wp-content/uploads/2025/12/11173319/dventura-greve-geral-11dez-47-scaled.jpg) <small>observador.pt</small>A greve geral de 11 de dezembro em 38 imagens – Observador

SPGL - Greve Geral | 11 De Dezembro De 2025 (Piquetes, Concentrações E Manifestações)
-------------------------------------------------------------------------------------

 ![SPGL - Greve Geral | 11 de dezembro de 2025 (Piquetes, Concentrações e Manifestações)](https://www.spgl.pt/Media/Default/_Profiles/722d2b7d/68bcf4e1/IMG_2694.JPG?v=639010778412646835) <small>www.spgl.pt</small>SPGL - Greve Geral | 11 de dezembro de 2025 (Piquetes, Concentrações e Manifestações)

Todos à Greve Geral – 11 Dez. • Trabalhadores Unidos
----------------------------------------------------

 ![Todos à Greve Geral – 11 Dez. • Trabalhadores Unidos](https://trabalhadores-unidos.pt/wp-content/uploads/2025/12/capa-todos-gg.png) <small>trabalhadores-unidos.pt</small>Todos à Greve Geral – 11 Dez. • Trabalhadores Unidos

Greve Geral De 11 De Dezembro Em Portugal: Razões Para Participar
-----------------------------------------------------------------

 ![Greve Geral de 11 de dezembro em Portugal: razões para participar](https://sabiasque.pt/images/stories/2025/trabalho/20251209-greve-geral-11-dezembro-320x480.jpg) <small>sabiasque.pt</small>Greve Geral de 11 de dezembro em Portugal: razões para participar

VISEU - Esclarecimento E Mobilização Para A Greve Geral Marcada Para 11 De Dezembro - CGTP-IN
---------------------------------------------------------------------------------------------

 ![VISEU - Esclarecimento e mobilização para a Greve Geral marcada para 11 de Dezembro - CGTP-IN](https://www.cgtp.pt/images/accao-e-luta/2025/gg.jpg) <small>www.cgtp.pt</small>VISEU - Esclarecimento e mobilização para a Greve Geral marcada para 11 de Dezembro - CGTP-IN

A Greve Geral De 11 De Dezembro Em 38 Imagens – Observador
----------------------------------------------------------

 ![A greve geral de 11 de dezembro em 38 imagens – Observador](https://bordalo.observador.pt/v2/q:60/rs:fill:1440/c:4096:2730:nowe:0:0/plain/https://s3.observador.pt/wp-content/uploads/2025/12/11173618/dventura-greve-geral-11dez-69-scaled.jpg) <small>observador.pt</small>A greve geral de 11 de dezembro em 38 imagens – Observador

GREVE GERAL DE 11 DE DEZEMBRO DE 2025 – MANIFESTAÇÕES – LISBOA (VÍDEO) – EPHEMERA – Biblioteca E
------------------------------------------------------------------------------------------------

 ![GREVE GERAL DE 11 DE DEZEMBRO DE 2025 – MANIFESTAÇÕES – LISBOA (VÍDEO) – EPHEMERA – Biblioteca e](https://ephemerajpp.com/wp-content/uploads/2025/12/IMG_2182.jpg) <small>ephemerajpp.com</small>GREVE GERAL DE 11 DE DEZEMBRO DE 2025 – MANIFESTAÇÕES – LISBOA (VÍDEO) – EPHEMERA – Biblioteca e ...

GREVE GERAL – Dia 11 De Dezembro | Sincomar - Sindicato De Capitães E Oficiais Da Marinha Mercante
--------------------------------------------------------------------------------------------------

 ![GREVE GERAL – Dia 11 de Dezembro | Sincomar - Sindicato de Capitães e Oficiais da Marinha Mercante](https://sincomar.pt/wp-content/uploads/2025/12/2-cartaz-GREVE-GERAL-UGT-final.jpg) <small>sincomar.pt</small>GREVE GERAL – Dia 11 de Dezembro | Sincomar - Sindicato de Capitães e Oficiais da Marinha Mercante

UGT Aprova Por Unanimidade Greve Geral A 11 De Dezembro - Diário Do Minho
-------------------------------------------------------------------------

 ![UGT aprova por unanimidade greve geral a 11 de dezembro - Diário do Minho](https://www.diariodominho.pt/storage/posts/greve-direito-a-greve_655b8a6d702c0_og.jpg) <small>www.diariodominho.pt</small>UGT aprova por unanimidade greve geral a 11 de dezembro - Diário do Minho

🔴 Ao Minuto: Foi Assim A Greve Geral De 11 De Dezembro De 2025 - Renascença
---------------------------------------------------------------------------

 ![🔴 Ao minuto: Foi assim a greve geral de 11 de dezembro de 2025 - Renascença](https://images.rr.pt/geve-geral-de-11-de-dezembro-de-2025-na-assembleia-da-republica-foto-ricardo-fortunato-rr-31311c45c_socialshare.jpg) <small>rr.pt</small>🔴 Ao minuto: Foi assim a greve geral de 11 de dezembro de 2025 - Renascença

GREVE GERAL – Concentração Em Frente Da Câmara Municipal De Portimão – 11 Dezembro 8h30
---------------------------------------------------------------------------------------

 ![GREVE GERAL – Concentração em frente da Câmara Municipal de Portimão – 11 Dezembro 8h30](https://stop-sindicato.pt/wp-content/uploads/2025/12/S.TO_.P.-Cartaz-Protesto-CM-Portimao-GreveGeral-11Dez-8h30.png) <small>stop-sindicato.pt</small>GREVE GERAL – Concentração em frente da Câmara Municipal de Portimão – 11 Dezembro 8h30 ...

A Greve Geral De 11 De Dezembro Em 38 Imagens – Observador
----------------------------------------------------------

 ![A greve geral de 11 de dezembro em 38 imagens – Observador](https://bordalo.observador.pt/v2/q:60/rs:fill:1440/c:4096:2730:nowe:0:0/plain/https://s3.observador.pt/wp-content/uploads/2025/12/11173535/dventura-greve-geral-11dez-64-scaled.jpg) <small>observador.pt</small>A greve geral de 11 de dezembro em 38 imagens – Observador

FAQ: Os Direitos Dos Docentes Em Dia De Greve Geral - 11/12/2025
----------------------------------------------------------------

 ![FAQ: Os direitos dos docentes em dia de Greve Geral - 11/12/2025](https://static.wixstatic.com/media/d0f32c_9ff1199ee2c34418af0094a43c516733~mv2.png/v1/fill/w_940,h_788,al_c,q_90,enc_avif,quality_auto/d0f32c_9ff1199ee2c34418af0094a43c516733~mv2.png) <small>www.sprc.pt</small>FAQ: Os direitos dos docentes em dia de Greve Geral - 11/12/2025

📢 GREVE GERAL — 11 DE DEZEMBRO POSSO FAZER GREVE? Sim. E é Importante Que Saibas Porquê. Todos
----------------------------------------------------------------------------------------------

 ![📢 GREVE GERAL — 11 DE DEZEMBRO POSSO FAZER GREVE? Sim. E é importante que saibas porquê. Todos](https://lookaside.fbsbx.com/lookaside/crawler/media/?media_id=1185258557072905) <small>www.facebook.com</small>📢 GREVE GERAL — 11 DE DEZEMBRO POSSO FAZER GREVE? Sim. E é importante que saibas porquê. Todos ...

GREVE GERAL DIA 11 DEZEMBRO DE 2025 | FESAHT
--------------------------------------------

 ![GREVE GERAL DIA 11 DEZEMBRO DE 2025 | FESAHT](https://sindicatos.cgtp.pt/fesaht/wp-content/blogs.dir/52/files/sites/52/2025/12/11-DEZ-faz-greve-e-sai-a-Rua.jpg) <small>sindicatos.cgtp.pt</small>GREVE GERAL DIA 11 DEZEMBRO DE 2025 | FESAHT

SIPE - 📢 Motivações Para A Adesão à Greve Geral – 11 De Dezembro De 2025 O SIPE Está Envolvido
----------------------------------------------------------------------------------------------

 ![SIPE - 📢 Motivações para a adesão à Greve Geral – 11 de dezembro de 2025 O SIPE está envolvido](https://lookaside.fbsbx.com/lookaside/crawler/media/?media_id=1270541985109687) <small>www.facebook.com</small>SIPE - 📢 Motivações para a adesão à Greve Geral – 11 de dezembro de 2025 O SIPE está envolvido ...

A Greve Geral De 11 De Dezembro Em 38 Imagens – Observador
----------------------------------------------------------

 ![A greve geral de 11 de dezembro em 38 imagens – Observador](https://bordalo.observador.pt/v2/q:60/rs:fill:1440/c:4096:2730:nowe:0:0/plain/https://s3.observador.pt/wp-content/uploads/2025/12/11090822/dventura-greve-geral-11dez-8-scaled.jpg) <small>observador.pt</small>A greve geral de 11 de dezembro em 38 imagens – Observador

Greve Geral Pode Custar 792 Milhões De Euros à Economia - JN
------------------------------------------------------------

 ![Greve geral pode custar 792 milhões de euros à economia - JN](https://staticx.noticiasilimitadas.pt/jn/image.webp?brand=jn&type=generate&guid=fb434b13-2b30-4ab1-a6bc-4ddd86b96b14&w=3840) <small>www.jn.pt</small>Greve geral pode custar 792 milhões de euros à economia - JN

Greve Geral – 24 Horas – Dia 11 De Dezembro De 2025 – SINTTAV Sindicato Nacional Dos
------------------------------------------------------------------------------------

 ![Greve Geral – 24 Horas – Dia 11 de Dezembro de 2025 – SINTTAV Sindicato Nacional dos](https://sinttav.pt/wp-content/uploads/2025/11/pag-1.jpg) <small>sinttav.pt</small>Greve Geral – 24 Horas – Dia 11 de Dezembro de 2025 – SINTTAV Sindicato Nacional dos ...

Perguntas E Respostas Sobre A Greve Geral De 11 De Dezembro - SBC - Sindicato Nacional Dos
------------------------------------------------------------------------------------------

 ![Perguntas e respostas sobre a Greve Geral de 11 de dezembro - SBC - Sindicato Nacional dos](https://www.sibace.pt/wp-content/uploads/2025/11/greve-2-1170-x-400.png) <small>www.sibace.pt</small>Perguntas e respostas sobre a Greve Geral de 11 de dezembro - SBC - Sindicato Nacional dos ...

Fertagus &gt; Fertagus (pt) &gt; Viajar &gt; Comunicados E Campanhas &gt; Greve Geral 11 De Dezembro De 2025
------------------------------------------------------------------------------------------------------------

 ![Fertagus > Fertagus (pt) > Viajar > Comunicados e Campanhas > Greve Geral 11 de dezembro de 2025](https://www.fertagus.pt/portals/0/FTG-Greve-Geral-web-1253x886.jpg) <small>www.fertagus.pt</small>Fertagus &gt; Fertagus (pt) &gt; Viajar &gt; Comunicados e Campanhas &gt; Greve Geral 11 de dezembro de 2025

📢 O SinFAP Adere à GREVE GERAL De 11 De Dezembro! Perante Os Ataques Aos Direitos Laborais, Ao
----------------------------------------------------------------------------------------------

 ![📢 O SinFAP adere à GREVE GERAL de 11 de dezembro! Perante os ataques aos direitos laborais, ao](https://lookaside.fbsbx.com/lookaside/crawler/media/?media_id=774444148982826) <small>www.facebook.com</small>📢 O SinFAP adere à GREVE GERAL de 11 de dezembro! Perante os ataques aos direitos laborais, ao ...

Greve Geral Contra Pacote Laboral A 11 De Dezembro (vídeo) – RTP Madeira
------------------------------------------------------------------------

 ![Greve geral contra pacote laboral a 11 de dezembro (vídeo) – RTP Madeira](https://madeira.rtp.pt/wp-content/uploads/2025/11/DOC.20251108.45998234.ACOT9063-scaled.jpg) <small>madeira.rtp.pt</small>Greve geral contra pacote laboral a 11 de dezembro (vídeo) – RTP Madeira

GREVE GERAL – Dia 11 De Dezembro | Sincomar - Sindicato De Capitães E Oficiais Da Marinha Mercante
--------------------------------------------------------------------------------------------------

 ![GREVE GERAL – Dia 11 de Dezembro | Sincomar - Sindicato de Capitães e Oficiais da Marinha Mercante](https://sincomar.pt/wp-content/uploads/2025/12/greve-geral-1080x675.jpg) <small>sincomar.pt</small>GREVE GERAL – Dia 11 de Dezembro | Sincomar - Sindicato de Capitães e Oficiais da Marinha Mercante

Aviso Prévio De Greves - 11 E 12 De Dezembro 2025
-------------------------------------------------

 ![Aviso Prévio de Greves - 11 e 12 de dezembro 2025](https://aefernandopessoafeira.pt/images/noticias/2025/aviso-previo-de-greve/aviso-previo-de-greve.jpg) <small>aefernandopessoafeira.pt</small>Aviso Prévio de Greves - 11 e 12 de dezembro 2025

SDP Sul
-------

 ![SDP Sul](https://sdpsul.com/storage/publicacao/imagem_563_6929dba6ddf62.jpeg) <small>sdpsul.com</small>SDP Sul

Adere à Greve Geral Dia 11 De Dezembro
--------------------------------------

 ![Adere à Greve Geral dia 11 de dezembro](https://www.sep.org.pt/files/uploads/2025/11/SEP_GREVEGERAL_WEB_1-800x350.jpg) <small>www.sep.org.pt</small>Adere à Greve Geral dia 11 de dezembro

Greve Geral: Sindicato Dos Trabalhadores Em Funções Públicas Apela à Mobilização Para Dia 11 De
-----------------------------------------------------------------------------------------------

 ![Greve Geral: Sindicato dos Trabalhadores em Funções Públicas apela à mobilização para dia 11 de](https://acores.rtp.pt/wp-content/uploads/2025/11/greve_geral_11dez.jpg) <small>acores.rtp.pt</small>Greve Geral: Sindicato dos Trabalhadores em Funções Públicas apela à mobilização para dia 11 de ...

greve geral contra pacote laboral a 11 de dezembro (vídeo) – rtp madeira. A greve geral de 11 de dezembro em 38 imagens – observador. A greve geral de 11 de dezembro em 38 imagens – observador
