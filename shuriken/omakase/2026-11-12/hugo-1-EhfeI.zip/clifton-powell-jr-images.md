---
title: "Clifton Powell Jr Images - Actor clifton powell (c) attends the 18th annual bet awards at microsoft theater in los angeles ..."
description: "Sasha obama&#039;s boyfriend: clifton powell jr.&#039;s job, family, more"
date: "2026-05-04"
categories:
- "Uncategorized"
images:
- "https://media.gettyimages.com/id/111517335/photo/clifton-powell-jr-clifton-powell-and-mya-powell-at-the-world-premiere-of-screen-gems-first.jpg?s=612x612&amp;w=gi&amp;k=20&amp;c=_RMjlAAY87MzChEu-cv5XpS8RpJMJzolyMTKUFs4Imo="
featuredImage: "https://www.walikali.com/wp-content/uploads/2022/04/Clifton-Powell-Jr.jpg"
featured_image: "https://akns-images.eonline.com/eol_images/Entire_Site/2022322/rs_1200x1200-220422064403-1200-Sasha-Obama-Clifton-Powell.jpg?fit=around|1080:1080&amp;output-quality=90&amp;crop=1080:1080;center,top"
image: "https://www.usmagazine.com/wp-content/uploads/2022/04/Feature-Who-Is-Clifton-Powell-Jr-5-Things-to-Know-About-Sasha-Obama-Reported-Boyfriend.jpg?quality=86&amp;strip=all"
---

If you are looking for Clifton Powell Jr , Barack Obamas Tochter Sasha liebt Sohn eines Hollywoodstars – NTBA you've visit to the right page. We have 35 Images about Clifton Powell Jr , Barack Obamas Tochter Sasha liebt Sohn eines Hollywoodstars – NTBA like Who is Clifton Powell Jr.? What to know about Sasha Obama’s BF, Clifton Powell Gives Sound Advice to His Son on Dating Sasha Obama and also Clifton Powell Jr Net Worth, Wiki, Biography, Age, Girlfriend, Religion, Nationality, Photos. Here it is:

Clifton Powell Jr , Barack Obamas Tochter Sasha Liebt Sohn Eines Hollywoodstars – NTBA
--------------------------------------------------------------------------------------

 ![Clifton Powell Jr , Barack Obamas Tochter Sasha liebt Sohn eines Hollywoodstars – NTBA](https://pagesix.com/wp-content/uploads/sites/3/2022/04/who-is-clifton-powell-jr_23.jpg) <small>elbschul-eltern.de</small>Clifton Powell Jr , Barack Obamas Tochter Sasha liebt Sohn eines Hollywoodstars – NTBA

Clifton Powell Jr Net Worth, Wiki, Biography, Age, Girlfriend, Religion, Nationality, Photos
--------------------------------------------------------------------------------------------

 ![Clifton Powell Jr Net Worth, Wiki, Biography, Age, Girlfriend, Religion, Nationality, Photos](https://explorenetworth.com/wp-content/uploads/2022/04/Clifton-Powell-Jr-1536x864.jpg) <small>explorenetworth.com</small>Clifton Powell Jr Net Worth, Wiki, Biography, Age, Girlfriend, Religion, Nationality, Photos

Sasha Obama Is Dating Actor Clifton Powell’s Son - TheJasmineBRAND
------------------------------------------------------------------

 ![Sasha Obama Is Dating Actor Clifton Powell’s Son - theJasmineBRAND](https://thejasminebrand.com/wp-content/uploads/2022/04/Untitled-design-2022-04-21T133135.970-595x595.png) <small>thejasminebrand.com</small>Sasha Obama Is Dating Actor Clifton Powell’s Son - theJasmineBRAND

Sasha Obama Dating Clifton Powell Jr., Actor's Son: Report
----------------------------------------------------------

 ![Sasha Obama dating Clifton Powell Jr., actor's son: report](https://pagesix.com/wp-content/uploads/sites/3/2022/04/sasha-obama-clifton-powell-jr-04.jpg?quality=75&strip=all&w=1200) <small>pagesix.com</small>Sasha Obama dating Clifton Powell Jr., actor's son: report

Who Is Sasha Obama’s New Boyfriend, Clifton Powell Jr? Barack And Michelle’s Youngest Daughter
----------------------------------------------------------------------------------------------

 ![Who is Sasha Obama’s new boyfriend, Clifton Powell Jr? Barack and Michelle’s youngest daughter](https://cdn.i-scmp.com/sites/default/files/styles/768x768/public/d8/images/canvas/2022/05/10/6ef43b4b-632b-4209-b4b8-72181282b5ee_61cb537e.jpg?itok=r0SG8EVM&v=1652175020) <small>www.scmp.com</small>Who is Sasha Obama’s new boyfriend, Clifton Powell Jr? Barack and Michelle’s youngest daughter ...

MALIA And Clifton Powell Jr. Out At A Park In Los Angeles 04/24/2022 – HawtCelebs
---------------------------------------------------------------------------------

 ![MALIA and Clifton Powell Jr. Out at a Park in Los Angeles 04/24/2022 – HawtCelebs](https://www.hawtcelebs.com/wp-content/uploads/2022/04/malia-and-clifton-powell-jr.-out-at-a-park-in-los-angeles-04-24-2022-9.jpg) <small>www.hawtcelebs.com</small>MALIA and Clifton Powell Jr. Out at a Park in Los Angeles 04/24/2022 – HawtCelebs

Clifton Powell Jr. Net Worth: All About Sasha Obama's Boyfriend
---------------------------------------------------------------

 ![Clifton Powell Jr. Net Worth: All About Sasha Obama's Boyfriend](https://media.marketrealist.com/brand-img/pRgCWwmOI/0x0/clifton-powell-jr-dad-1650645137911.jpg) <small>marketrealist.com</small>Clifton Powell Jr. Net Worth: All About Sasha Obama's Boyfriend

Sasha Obama Is Dating The Son Of Actor Clifton Powell - Just Jared - Celebrity News And Gossip
----------------------------------------------------------------------------------------------

 ![Sasha Obama Is Dating the Son of Actor Clifton Powell - Just Jared - Celebrity News and Gossip](https://cdn.justjared.com/wp-content/uploads/headlines/2022/04/sasha-clif2.jpg) <small>www.justjared.com</small>Sasha Obama Is Dating the Son of Actor Clifton Powell - Just Jared - Celebrity News and Gossip ...

Sasha Obama Now Living In LA And Dating Actor Clifton Powell's Namesake Son | EURweb | Black
--------------------------------------------------------------------------------------------

 ![Sasha Obama Now Living in LA and Dating Actor Clifton Powell's Namesake Son | EURweb | Black](https://eurweb.com/wp-content/uploads/2022/04/Sasha-Obama-and-Clifton-Powell-Jr-Getty.jpg) <small>eurweb.com</small>Sasha Obama Now Living in LA and Dating Actor Clifton Powell's Namesake Son | EURweb | Black ...

Who Is Sasha Obama’s New Boyfriend, Clifton Powell Jr? Barack And Michelle’s Youngest Daughter
----------------------------------------------------------------------------------------------

 ![Who is Sasha Obama’s new boyfriend, Clifton Powell Jr? Barack and Michelle’s youngest daughter](https://cdn.i-scmp.com/sites/default/files/d8/images/canvas/2022/05/10/e66ad8bb-c5eb-473a-b297-f8069a27397d_d7491f3d.jpg) <small>www.scmp.com</small>Who is Sasha Obama’s new boyfriend, Clifton Powell Jr? Barack and Michelle’s youngest daughter ...

Sasha Obama Boyfriend: All About Clifton Powell Jr. (2026)
----------------------------------------------------------

 ![Sasha Obama Boyfriend: All About Clifton Powell Jr. (2026)](https://houseandwhips.com/wp-content/uploads/2026/06/sasha-obama-boyfriend-2026.jpg) <small>houseandwhips.com</small>Sasha Obama Boyfriend: All About Clifton Powell Jr. (2026)

Clifton Powell Jr. Height, Weight, Age, Family, Girlfriends, Facts
------------------------------------------------------------------

 ![Clifton Powell Jr. Height, Weight, Age, Family, Girlfriends, Facts](https://healthyceleb.com/wp-content/uploads/2022/04/Clifton-Powell-Jr.-as-seen-while-posing-for-a-picture.jpg) <small>healthyceleb.com</small>Clifton Powell Jr. Height, Weight, Age, Family, Girlfriends, Facts

379 Clifton Powell Stock Photos, High-Res Pictures, And Images - Getty Images
-----------------------------------------------------------------------------

 ![379 Clifton Powell Stock Photos, High-Res Pictures, and Images - Getty Images](https://media.gettyimages.com/id/111517335/photo/clifton-powell-jr-clifton-powell-and-mya-powell-at-the-world-premiere-of-screen-gems-first.jpg?s=612x612&w=gi&k=20&c=_RMjlAAY87MzChEu-cv5XpS8RpJMJzolyMTKUFs4Imo=) <small>www.gettyimages.co.uk</small>379 Clifton Powell Stock Photos, High-Res Pictures, and Images - Getty Images

Meet Sasha Obama's BOYFRIEND: Inside Daughter Of Former President Barack Obama's Budding New
--------------------------------------------------------------------------------------------

 ![Meet Sasha Obama's BOYFRIEND: Inside daughter of former President Barack Obama's budding new](https://i.dailymail.co.uk/1s/2022/04/21/19/56888479-10739881-_24_years_ago_you_came_into_the_world_and_you_changed_my_life_an-m-33_1650564731726.jpg) <small>www.dailymail.com</small>Meet Sasha Obama's BOYFRIEND: Inside daughter of former President Barack Obama's budding new ...

Actor Clifton Powell (C) Attends The 18th Annual BET Awards At Microsoft Theater In Los Angeles
-----------------------------------------------------------------------------------------------

 ![Actor Clifton Powell (C) attends the 18th annual BET Awards at Microsoft Theater in Los Angeles](https://c8.alamy.com/comp/TY8368/actor-clifton-powell-c-attends-the-18th-annual-bet-awards-at-microsoft-theater-in-los-angeles-on-june-24-2018-the-ceremony-celebrates-achievements-in-entertainment-and-honors-music-sports-television-and-movies-released-between-april-1-2017-and-march-31-2018-photo-by-gregg-deguireupi-TY8368.jpg) <small>www.alamy.com</small>Actor Clifton Powell (C) attends the 18th annual BET Awards at Microsoft Theater in Los Angeles ...

Clifton Powell Jr. Height, Weight, Age, Family, Girlfriends, Facts
------------------------------------------------------------------

 ![Clifton Powell Jr. Height, Weight, Age, Family, Girlfriends, Facts](https://healthyceleb.com/wp-content/uploads/2022/04/Clifton-Powell-Jr..jpg) <small>healthyceleb.com</small>Clifton Powell Jr. Height, Weight, Age, Family, Girlfriends, Facts

Who Is Clifton Powell Jr? Wiki, Net Worth, Biography, Age, Height, Girlfriend
-----------------------------------------------------------------------------

 ![Who is Clifton Powell Jr? Wiki, Net Worth, Biography, Age, Height, Girlfriend](https://www.walikali.com/wp-content/uploads/2022/04/Clifton-Powell-Jr.jpg) <small>www.walikali.com</small>Who is Clifton Powell Jr? Wiki, Net Worth, Biography, Age, Height, Girlfriend

Powell Jr Photos And Premium High Res Pictures - Getty Images
-------------------------------------------------------------

 ![Powell Jr Photos and Premium High Res Pictures - Getty Images](https://media.gettyimages.com/id/937951288/photo/clifton-powell-attends-insolved-history-life-of-a-king-atlanta-screening-at-martin-luther-king.jpg?s=612x612&w=gi&k=20&c=dDt3KdYV6x_ploOyQYAu-fCb3frm3Y3S82n1objvI-Y=) <small>www.gettyimages.com</small>Powell Jr Photos and Premium High Res Pictures - Getty Images

Sasha Obama Steps Out With Clifton Powell Jr. Amid Dating Rumors
----------------------------------------------------------------

 ![Sasha Obama Steps Out With Clifton Powell Jr. Amid Dating Rumors](https://akns-images.eonline.com/eol_images/Entire_Site/2022322/rs_1200x1200-220422064403-1200-Sasha-Obama-Clifton-Powell.jpg?fit=around|1080:1080&output-quality=90&crop=1080:1080;center,top) <small>www.eonline.com</small>Sasha Obama Steps Out With Clifton Powell Jr. Amid Dating Rumors

What Life Is Like For The Obama Sisters Today
---------------------------------------------

 ![What Life Is Like For The Obama Sisters Today](https://www.thelist.com/img/gallery/what-life-is-like-for-the-obama-sisters-today/sasha-is-dating-former-basketball-star-clifton-powell-jr-1673289690.jpg) <small>www.thelist.com</small>What Life Is Like For The Obama Sisters Today

Sasha Obama's Boyfriend: Clifton Powell Jr.'s Job, Family, More | Life &amp; Style
----------------------------------------------------------------------------------

 ![Sasha Obama's Boyfriend: Clifton Powell Jr.'s Job, Family, More | Life & Style](https://www.lifeandstylemag.com/wp-content/uploads/2022/12/Copy-of-Single-Bubble-White-2022-12-30T130131.373.jpg?fit=2400%2C2400&quality=86&strip=all) <small>www.lifeandstylemag.com</small>Sasha Obama's Boyfriend: Clifton Powell Jr.'s Job, Family, More | Life &amp; Style

Dette Gjør Malia Obama Og Sasha Obama I Dag
-------------------------------------------

 ![Dette gjør Malia Obama og Sasha Obama i dag](https://www.seher.no/images/81536769.jpg?imageId=81536769&x=6.7164179104478&y=3.1685678073511&cropw=64.179104477612&croph=64.131812420786&width=688&height=507&compression=80) <small>www.seher.no</small>Dette gjør Malia Obama og Sasha Obama i dag

Sasha Obama Is Reportedly Dating Clifton Powell Jr.
---------------------------------------------------

 ![Sasha Obama Is Reportedly Dating Clifton Powell Jr.](https://pyxis.nymag.com/v1/imgs/3d7/126/cc4ee26bccddb30de43489205b5dbe60f0-sasha-obama-clifton-powell-jr.rsquare.w700.jpg) <small>www.thecut.com</small>Sasha Obama Is Reportedly Dating Clifton Powell Jr.

Clifton Powell Gives Sound Advice To His Son On Dating Sasha Obama
------------------------------------------------------------------

 ![Clifton Powell Gives Sound Advice to His Son on Dating Sasha Obama](https://thesource.com/wp-content/uploads/2022/06/Clifton-Powell-Jr.-.jpg) <small>thesource.com</small>Clifton Powell Gives Sound Advice to His Son on Dating Sasha Obama

Who Is Clifton Powell Jr? Wiki, Net Worth, Biography, Age, Height, Girlfriend
-----------------------------------------------------------------------------

 ![Who is Clifton Powell Jr? Wiki, Net Worth, Biography, Age, Height, Girlfriend](https://www.walikali.com/wp-content/uploads/2022/04/Clifton-Powell-Jr-3.jpg) <small>www.walikali.com</small>Who is Clifton Powell Jr? Wiki, Net Worth, Biography, Age, Height, Girlfriend

Who Is Clifton Powell Jr.? What To Know About Sasha Obama’s BF
--------------------------------------------------------------

 ![Who is Clifton Powell Jr.? What to know about Sasha Obama’s BF](https://pagesix.com/wp-content/uploads/sites/3/2022/04/who-is-clifton-powell-jr_19.jpg?quality=75&strip=all&w=683) <small>pagesix.com</small>Who is Clifton Powell Jr.? What to know about Sasha Obama’s BF

Clifton Powell Jr Net Worth, Wiki, Biography, Age, Girlfriend, Religion, Nationality, Photos
--------------------------------------------------------------------------------------------

 ![Clifton Powell Jr Net Worth, Wiki, Biography, Age, Girlfriend, Religion, Nationality, Photos](https://explorenetworth.com/wp-content/uploads/2022/04/Clifton-Powell-Jr-1-1024x576.jpg) <small>explorenetworth.com</small>Clifton Powell Jr Net Worth, Wiki, Biography, Age, Girlfriend, Religion, Nationality, Photos

What To Know About Sasha Obama’s Reported BF Clifton Powell Jr. | Us Weekly
---------------------------------------------------------------------------

 ![What to Know About Sasha Obama’s Reported BF Clifton Powell Jr. | Us Weekly](https://www.usmagazine.com/wp-content/uploads/2022/04/Who-Is-Clifton-Powell-Jr-5-Things-to-Know-About-Sasha-Obama-Reported-Boyfriend-2.jpg?w=1200&quality=86&strip=all) <small>www.usmagazine.com</small>What to Know About Sasha Obama’s Reported BF Clifton Powell Jr. | Us Weekly

Clifton Powell Jr. Bio, Age, Height, Girlfriend, Net Worth, Wiki
----------------------------------------------------------------

 ![Clifton Powell Jr. Bio, Age, Height, Girlfriend, Net Worth, Wiki](https://wealthyspy.com/wp-content/uploads/2022/04/Clifton-Powell-Jr..jpg) <small>wealthyspy.com</small>Clifton Powell Jr. Bio, Age, Height, Girlfriend, Net Worth, Wiki

Powell Jr Photos And Premium High Res Pictures - Getty Images
-------------------------------------------------------------

 ![Powell Jr Photos and Premium High Res Pictures - Getty Images](https://media.gettyimages.com/id/937951292/photo/clifton-powell-attends-insolved-history-life-of-a-king-atlanta-screening-at-martin-luther-king.jpg?s=612x612&w=gi&k=20&c=8q-HnbrpJZTxzUCDWWOHEPKEpZVo_4JJ9YGMk_5WwEY=) <small>www.gettyimages.com</small>Powell Jr Photos and Premium High Res Pictures - Getty Images

Sasha, Filha De Barack Obama, é Vista Com O Namorado Pela Primeira Vez - Quem | QUEM News
-----------------------------------------------------------------------------------------

 ![Sasha, filha de Barack Obama, é vista com o namorado pela primeira vez - Quem | QUEM News](https://s2.glbimg.com/IOE4FlMJyQ1qLgZ3lNhk_MEXfqs=/e.glbimg.com/og/ed/f/original/2022/04/23/shu_sobras220422_01.jpg) <small>revistaquem.globo.com</small>Sasha, filha de Barack Obama, é vista com o namorado pela primeira vez - Quem | QUEM News

Who Is Clifton Powell Jr.? What To Know About Sasha Obama’s BF
--------------------------------------------------------------

 ![Who is Clifton Powell Jr.? What to know about Sasha Obama’s BF](https://pagesix.com/wp-content/uploads/sites/3/2022/04/who-is-clifton-powell-jr_24.jpg?quality=75&strip=all&w=2000) <small>pagesix.com</small>Who is Clifton Powell Jr.? What to know about Sasha Obama’s BF

Clifton Powell Jr. Wiki: Biography, Age, Height, Parents, Ethnicity, Girlfriend, Net Worth &amp; More
-----------------------------------------------------------------------------------------------------

 ![Clifton Powell Jr. Wiki: Biography, Age, Height, Parents, Ethnicity, Girlfriend, Net Worth & More](https://www.newsunzip.com/wp-content/uploads/2022/04/Clifton-Powell-Jr.-height-is-6-feet-5-inches.jpg) <small>www.newsunzip.com</small>Clifton Powell Jr. Wiki: Biography, Age, Height, Parents, Ethnicity, Girlfriend, Net Worth &amp; More

Clifton Powell Jr. Photos, News And Videos, Trivia And Quotes - FamousFix
-------------------------------------------------------------------------

 ![Clifton Powell Jr. Photos, News and Videos, Trivia and Quotes - FamousFix](https://www.usmagazine.com/wp-content/uploads/2022/04/Feature-Who-Is-Clifton-Powell-Jr-5-Things-to-Know-About-Sasha-Obama-Reported-Boyfriend.jpg?quality=86&strip=all) <small>www.famousfix.com</small>Clifton Powell Jr. Photos, News and Videos, Trivia and Quotes - FamousFix

Actor Clifton Powell (C) Attends The 18th Annual BET Awards At Microsoft Theater In Los Angeles
-----------------------------------------------------------------------------------------------

 ![Actor Clifton Powell (C) attends the 18th annual BET Awards at Microsoft Theater in Los Angeles](https://c8.alamy.com/comp/TY836B/actor-clifton-powell-c-attends-the-18th-annual-bet-awards-at-microsoft-theater-in-los-angeles-on-june-24-2018-the-ceremony-celebrates-achievements-in-entertainment-and-honors-music-sports-television-and-movies-released-between-april-1-2017-and-march-31-2018-photo-by-gregg-deguireupi-TY836B.jpg) <small>www.alamy.com</small>Actor Clifton Powell (C) attends the 18th annual BET Awards at Microsoft Theater in Los Angeles ...

Dette gjør malia obama og sasha obama i dag. Who is sasha obama’s new boyfriend, clifton powell jr? barack and michelle’s youngest daughter .... Sasha obama boyfriend: all about clifton powell jr. (2026)
