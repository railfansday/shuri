---
title: "Greve Geral Em Portugal 2026 - Portugal faz greve geral contra mudanças na lei trabalhista"
description: "Dados da adesão à greve geral"
date: "2026-07-06"
categories:
- "Uncategorized"
images:
- "https://classic.exame.com/wp-content/uploads/2016/09/size_960_16_9_2012-10-31t182117z_133313834.jpg"
featuredImage: "https://s2-valor.glbimg.com/4vR_2uY25dJGMy8ZVvqi2yGFVV0=/0x0:4000x2667/888x0/smart/filters:strip_icc()/i.s3.glbimg.com/v1/AUTH_63b422c2caee4269b8b34177e8876b93/internal_photos/bs/2026/i/K/IRKRylTBC6ihg48Gb0hw/457542349.jpg"
featured_image: "https://s2-valor.glbimg.com/4vR_2uY25dJGMy8ZVvqi2yGFVV0=/0x0:4000x2667/888x0/smart/filters:strip_icc()/i.s3.glbimg.com/v1/AUTH_63b422c2caee4269b8b34177e8876b93/internal_photos/bs/2026/i/K/IRKRylTBC6ihg48Gb0hw/457542349.jpg"
image: "https://www.cgtp.pt/images/images/2026/06/resolucao_grevegeral.jpg"
---

If you are searching about Manifestação em frente ao Parlamento resultou em seis detidos: tudo sobre a greve geral you've came to the right place. We have 35 Pics about Manifestação em frente ao Parlamento resultou em seis detidos: tudo sobre a greve geral like Greve geral em Portugal cancela voos e afeta serviços essenciais: sindicatos protestam contra, Greve contra reforma trabalhista em Portugal paralisa trens, reduz voos e fecha escolas | Mundo and also Greve contra reforma trabalhista em Portugal paralisa trens, reduz voos e fecha escolas | Mundo. Here you go:

Manifestação Em Frente Ao Parlamento Resultou Em Seis Detidos: Tudo Sobre A Greve Geral
---------------------------------------------------------------------------------------

 ![Manifestação em frente ao Parlamento resultou em seis detidos: tudo sobre a greve geral](https://cdn.sabado.pt/images/2025-12/img_1320x742uu2025-12-11-15-03-48-752830.jpg) <small>www.sabado.pt</small>Manifestação em frente ao Parlamento resultou em seis detidos: tudo sobre a greve geral ...

O Que Vai Parar Com A Greve Geral De 3 De Junho? - Portugal - SÁBADO
--------------------------------------------------------------------

 ![O que vai parar com a greve geral de 3 de junho? - Portugal - SÁBADO](https://cdn.sabado.pt/images/2026-05/img_980x653uu2026-05-21-18-26-04-766232.jpg) <small>www.sabado.pt</small>O que vai parar com a greve geral de 3 de junho? - Portugal - SÁBADO

Nacional - FENPROF
------------------

 ![Nacional - FENPROF](https://www.fenprof.pt/media/download/B73B952771368699555DF536CB47A576/grevegeral-3jun26.png?width=800&rxy=0.5) <small>www.fenprof.pt</small>Nacional - FENPROF

Greve Contra Reforma Trabalhista Em Portugal Paralisa Trens, Reduz Voos E Fecha Escolas | Mundo
-----------------------------------------------------------------------------------------------

 ![Greve contra reforma trabalhista em Portugal paralisa trens, reduz voos e fecha escolas | Mundo](https://s2-valor.glbimg.com/4vR_2uY25dJGMy8ZVvqi2yGFVV0=/0x0:4000x2667/888x0/smart/filters:strip_icc()/i.s3.glbimg.com/v1/AUTH_63b422c2caee4269b8b34177e8876b93/internal_photos/bs/2026/i/K/IRKRylTBC6ihg48Gb0hw/457542349.jpg) <small>valor.globo.com</small>Greve contra reforma trabalhista em Portugal paralisa trens, reduz voos e fecha escolas | Mundo ...

Manifestação Em Frente Ao Parlamento Resultou Em Seis Detidos: Tudo Sobre A Greve Geral
---------------------------------------------------------------------------------------

 ![Manifestação em frente ao Parlamento resultou em seis detidos: tudo sobre a greve geral](https://cdn.sabado.pt/images/2025-12/img_1320x743uu2025-12-11-10-18-26-752781.jpg) <small>www.sabado.pt</small>Manifestação em frente ao Parlamento resultou em seis detidos: tudo sobre a greve geral ...

Greve Histórica Em Portugal: Três Milhões Cruzam Os Braços Em Protesto Contra Medidas De
----------------------------------------------------------------------------------------

 ![Greve histórica em Portugal: três milhões cruzam os braços em protesto contra medidas de](https://ogimg.infoglobo.com.br/in/2920985-315-96f/FT1086A/760/Manifestante-no-Centro-de-Lisboa-na-primeira-greve-geral-em-mais-de-duas-decadasFrancisco-LeongAFP.jpg) <small>oglobo.globo.com</small>Greve histórica em Portugal: três milhões cruzam os braços em protesto contra medidas de ...

Greve Geral | Ações E Dados
---------------------------

 ![Greve Geral | Ações e dados](https://fne.pt/uploads/noticias/big_1765451399_8584_Design_sem_nome.png) <small>fne.pt</small>Greve Geral | Ações e dados

Maioria Dos Portugueses Diz Que Greve Geral Foi Justificada - Portugal - SÁBADO
-------------------------------------------------------------------------------

 ![Maioria dos portugueses diz que greve geral foi justificada - Portugal - SÁBADO](https://cdn.sabado.pt/images/2025-12/img_980x653uu2025-12-22-09-03-14-753915.jpg) <small>www.sabado.pt</small>Maioria dos portugueses diz que greve geral foi justificada - Portugal - SÁBADO

27 Março | Greve Dos Trabalhadores Das Empresas De Distribuição - CGTP-IN
-------------------------------------------------------------------------

 ![27 Março | greve dos trabalhadores das empresas de distribuição - CGTP-IN](https://www.cgtp.pt/images/images/2022/10/Aped.jpg) <small>www.cgtp.pt</small>27 Março | greve dos trabalhadores das empresas de distribuição - CGTP-IN

Portugal Faz Greve Geral Contra Mudanças Na Lei Trabalhista | G1
----------------------------------------------------------------

 ![Portugal faz greve geral contra mudanças na lei trabalhista | G1](https://s2-g1.glbimg.com/02TFp0WTXe014uO-QFFVxRua930=/5472x0/filters:format(jpeg)/https://i.s3.glbimg.com/v1/AUTH_59edd422c0c84a879bd37670ae4f538a/internal_photos/bs/2026/8/D/NHXiHRSYiCUPUHUimdMQ/2026-05-26t135550z-2088829895-rc21rkatd17q-rtrmadp-3-portugal-economy-primeminister.jpg) <small>g1.globo.com</small>Portugal faz greve geral contra mudanças na lei trabalhista | G1

Greve Geral Paralisa Portugal Contra Precarização De Direitos
-------------------------------------------------------------

 ![Greve geral paralisa Portugal contra precarização de direitos](https://pcdob.org.br/wp-content/uploads/2025/12/Ruas-de-Lisboa-foram-tomadas-por-trabalhadores-durante-a-greve-geral-Rafael-Medeiros-Esquerda.jpg) <small>pcdob.org.br</small>Greve geral paralisa Portugal contra precarização de direitos

Greve Geral Histórica Em Portugal Paralisa Transportes, Fecha Escolas E Pressiona Hospitais
-------------------------------------------------------------------------------------------

 ![Greve geral histórica em Portugal paralisa transportes, fecha escolas e pressiona hospitais](https://p2.trrsf.com/image/fget/cf/1200/630/middle/images.terra.com/2025/12/11/greve-ubj4bs8ccokh.png) <small>www.terra.com.br</small>Greve geral histórica em Portugal paralisa transportes, fecha escolas e pressiona hospitais

Metro Do Porto "fortemente Condicionado" No Dia Da Greve Geral - JPN
--------------------------------------------------------------------

 ![Metro do Porto "fortemente condicionado" no dia da greve geral - JPN](https://www.jpn.up.pt/wp-content/uploads/2025/12/greve_geral1-1152x759.jpg) <small>www.jpn.up.pt</small>Metro do Porto "fortemente condicionado" no dia da greve geral - JPN

GREVE GERAL - 3 JUNHO 2026 | Resolução - CGTP-IN
------------------------------------------------

 ![GREVE GERAL - 3 JUNHO 2026 | Resolução - CGTP-IN](https://www.cgtp.pt/images/images/2026/06/tiago-greve-geral.jpg) <small>www.cgtp.pt</small>GREVE GERAL - 3 JUNHO 2026 | Resolução - CGTP-IN

Mais De 50 Sindicatos Aderem à Greve Geral Marcada Para 11 De Dezembro
----------------------------------------------------------------------

 ![Mais de 50 sindicatos aderem à greve geral marcada para 11 de dezembro](https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA1QBjfX.img?w=1200&h=800&m=4&q=70) <small>www.msn.com</small>Mais de 50 sindicatos aderem à greve geral marcada para 11 de dezembro

Nacional - FENPROF
------------------

 ![Nacional - FENPROF](https://www.fenprof.pt/media/download/FA35D84EB902AC7A6FFE8691F2CE04D8/2026_05_16-manifestacao-ecd-2.jpeg?width=800&rxy=0.5) <small>www.fenprof.pt</small>Nacional - FENPROF

Portugal: Greve Geral - CIG: Confederación Intersindical Galega
---------------------------------------------------------------

 ![Portugal: Greve geral - CIG: Confederación Intersindical Galega](https://www.cig.gal/assets/images/0/20251212_greve.PT-c79520e0.jpg) <small>www.cig.gal</small>Portugal: Greve geral - CIG: Confederación Intersindical Galega

Greve Geral Paralisa Portugal Em Protesto Contra Reforma Trabalhista
--------------------------------------------------------------------

 ![Greve geral paralisa Portugal em protesto contra reforma trabalhista](https://p2.trrsf.com/image/fget/cf/1200/630/middle/images.terra.com/2026/06/03/greve-portugal-1k1txsf2tqcds.jpg) <small>www.terra.com.br</small>Greve geral paralisa Portugal em protesto contra reforma trabalhista

Greve Geral - 3 De Junho De 2026 | Concentrações - CGTP-IN
----------------------------------------------------------

 ![Greve Geral - 3 de Junho de 2026 | Concentrações - CGTP-IN](https://www.cgtp.pt/images/images/2026/05/CONCENTRACOES-GG.jpg) <small>www.cgtp.pt</small>Greve Geral - 3 de Junho de 2026 | Concentrações - CGTP-IN

AVISO PRÉVIO DE GREVE GERAL 3 JUNHO 2026 – STTS
-----------------------------------------------

 ![AVISO PRÉVIO DE GREVE GERAL 3 JUNHO 2026 – STTS](https://www.stts.pt/wp-content/uploads/2026/05/123654-1024x871.jpg) <small>www.stts.pt</small>AVISO PRÉVIO DE GREVE GERAL 3 JUNHO 2026 – STTS

UGT Vai Reunir-se Com Ministra Do Trabalho Mas Avisa Que "é Impossível Negociar" Sozinha A
------------------------------------------------------------------------------------------

 ![UGT vai reunir-se com ministra do Trabalho mas avisa que "é impossível negociar" sozinha a](https://img.iol.pt/image/id/693b2a1ad34e3caad84c47e9/1024.jpg) <small>cnnportugal.iol.pt</small>UGT vai reunir-se com ministra do Trabalho mas avisa que "é impossível negociar" sozinha a ...

Pré-Aviso De Greve – 17 De Abril De 2026 – AE António Correia De Oliveira
-------------------------------------------------------------------------

 ![Pré-Aviso de Greve – 17 de abril de 2026 – AE António Correia de Oliveira](https://www.acoliveira.pt/wp-content/uploads/2026/04/7e9f6ec4-4873-4685-897b-30c62aab02d6.png) <small>www.acoliveira.pt</small>Pré-Aviso de Greve – 17 de abril de 2026 – AE António Correia de Oliveira

AVISO PRÉVIO DE GREVE TRABALHADORES ADMINISTRAÇÃO PÚBLICA 16 DE MAIO 2025 – STTS
--------------------------------------------------------------------------------

 ![AVISO PRÉVIO DE GREVE TRABALHADORES ADMINISTRAÇÃO PÚBLICA 16 DE MAIO 2025 – STTS](https://www.stts.pt/wp-content/uploads/2025/05/CAPA.jpg) <small>www.stts.pt</small>AVISO PRÉVIO DE GREVE TRABALHADORES ADMINISTRAÇÃO PÚBLICA 16 DE MAIO 2025 – STTS

Portugal: Uma Grande Greve Geral Para Derrotar O Pacote Laboral - CIG: Confederación
------------------------------------------------------------------------------------

 ![Portugal: Uma grande greve geral para derrotar o pacote laboral - CIG: Confederación](https://www.cig.gal/assets/images/6/20251209_portugal.greve-34c19476.jpg) <small>www.cig.gal</small>Portugal: Uma grande greve geral para derrotar o pacote laboral - CIG: Confederación ...

Entenda Os Principais Pontos Da Reforma Trabalhista Que Provoca Greve Geral Em Portugal | G1
--------------------------------------------------------------------------------------------

 ![Entenda os principais pontos da reforma trabalhista que provoca greve geral em Portugal | G1](https://s2-g1.glbimg.com/uvHIX1RbKO_MglDnoelaL2WpgE8=/5348x0/filters:format(jpeg)/https://i.s3.glbimg.com/v1/AUTH_59edd422c0c84a879bd37670ae4f538a/internal_photos/bs/2026/k/7/EhXKIZSAyqu65hr4eX8w/2026-06-03t084738z-961950336-rc28mlaw0vp1-rtrmadp-3-portugal-labour-general-strike.jpg) <small>g1.globo.com</small>Entenda os principais pontos da reforma trabalhista que provoca greve geral em Portugal | G1

Greve Geral Em Portugal Cancela Voos E Afeta Serviços Essenciais: Sindicatos Protestam Contra
---------------------------------------------------------------------------------------------

 ![Greve geral em Portugal cancela voos e afeta serviços essenciais: sindicatos protestam contra](https://s2-oglobo.glbimg.com/CvxQoWQZKKpvDH4J2cFUaiQmndA=/7495x0/filters:format(jpeg)/https://i.s3.glbimg.com/v1/AUTH_da025474c0c44edd99332dddb09cabe8/internal_photos/bs/2026/7/Y/lvi32BSLCS92LGu03jAg/115141022-people-take-part-in-a-demonstration-in-lisbon-on-july-3-2026-called-by-the-main-unions-due.jpg) <small>oglobo.globo.com</small>Greve geral em Portugal cancela voos e afeta serviços essenciais: sindicatos protestam contra ...

Greve Geral: Trabalhadores Em Arquitetura Juntam-se à Paralisação - Portugal - SÁBADO
-------------------------------------------------------------------------------------

 ![Greve geral: Trabalhadores em arquitetura juntam-se à paralisação - Portugal - SÁBADO](https://cdn.sabado.pt/images/2026-05/img_980x653uu2026-05-21-15-24-22-766216.jpg) <small>www.sabado.pt</small>Greve geral: Trabalhadores em arquitetura juntam-se à paralisação - Portugal - SÁBADO

Dados Da Adesão à Greve Geral | 18h00 - CGTP-IN
-----------------------------------------------

 ![Dados da adesão à Greve Geral | 18h00 - CGTP-IN](https://www.cgtp.pt/images/images/2026/06/resolucao_grevegeral.jpg) <small>www.cgtp.pt</small>Dados da adesão à Greve Geral | 18h00 - CGTP-IN

Greve Geral Portuguesa De 2025 – Wikipédia, A Enciclopédia Livre
----------------------------------------------------------------

 ![Greve geral portuguesa de 2025 – Wikipédia, a enciclopédia livre](https://upload.wikimedia.org/wikipedia/commons/thumb/9/9c/Manifestação_Greve_Geral%2C_Lisboa%2C_Dez._2025_(54977121422).jpg/1280px-Manifestação_Greve_Geral%2C_Lisboa%2C_Dez._2025_(54977121422).jpg) <small>pt.wikipedia.org</small>Greve geral portuguesa de 2025 – Wikipédia, a enciclopédia livre

Imagens Do Dia De Greve Geral Em Portugal - Jornal O Globo
----------------------------------------------------------

 ![Imagens do dia de greve geral em Portugal - Jornal O Globo](https://ogimg.infoglobo.com.br/in/4387791-fd9-94b/FT1086A/760/foto2.jpg?posicaoFoto2) <small>oglobo.globo.com</small>Imagens do dia de greve geral em Portugal - Jornal O Globo

CGTP Entrega Hoje Pré-aviso De Greve Geral Para "derrotar O Pacote Laboral" - Portugal - SÁBADO
-----------------------------------------------------------------------------------------------

 ![CGTP entrega hoje pré-aviso de greve geral para "derrotar o pacote laboral" - Portugal - SÁBADO](https://cdn.sabado.pt/images/2026-05/img_1920x1080uu2026-05-01-16-01-52-764693.jpg) <small>www.sabado.pt</small>CGTP entrega hoje pré-aviso de greve geral para "derrotar o pacote laboral" - Portugal - SÁBADO

Greve Geral Em Portugal Cancela Voos E Afeta Serviços Essenciais: Sindicatos Protestam Contra
---------------------------------------------------------------------------------------------

 ![Greve geral em Portugal cancela voos e afeta serviços essenciais: sindicatos protestam contra](https://s2-oglobo.glbimg.com/v2dBefo5nA6123zd84VVF6ak66w=/0x0:4000x2667/600x0/smart/filters:strip_icc()/i.s3.glbimg.com/v1/AUTH_da025474c0c44edd99332dddb09cabe8/internal_photos/bs/2026/B/N/KyK9b9SxGWvADz8drB1g/457602277.jpg) <small>oglobo.globo.com</small>Greve geral em Portugal cancela voos e afeta serviços essenciais: sindicatos protestam contra ...

Greve Geral Paralisa Serviços Em Portugal Contra Reforma Trabalhista - Portal Em Tempo
--------------------------------------------------------------------------------------

 ![Greve geral paralisa serviços em Portugal contra reforma trabalhista - Portal Em Tempo](https://emtempo.com.br/wp-content/uploads/2026/06/greve-portugal.jpg) <small>emtempo.com.br</small>Greve geral paralisa serviços em Portugal contra reforma trabalhista - Portal Em Tempo

Manifestação Em Frente Ao Parlamento Resultou Em Seis Detidos: Tudo Sobre A Greve Geral
---------------------------------------------------------------------------------------

 ![Manifestação em frente ao Parlamento resultou em seis detidos: tudo sobre a greve geral](https://cdn.sabado.pt/images/2025-12/img_1200x676uu2025-12-11-12-44-17-752810.jpg) <small>www.sabado.pt</small>Manifestação em frente ao Parlamento resultou em seis detidos: tudo sobre a greve geral ...

Centrais Sindicais Preparam Nova Greve Geral Em Portugal | Exame
----------------------------------------------------------------

 ![Centrais sindicais preparam nova greve geral em Portugal | Exame](https://classic.exame.com/wp-content/uploads/2016/09/size_960_16_9_2012-10-31t182117z_133313834.jpg) <small>exame.com</small>Centrais sindicais preparam nova greve geral em Portugal | Exame

Manifestação em frente ao parlamento resultou em seis detidos: tudo sobre a greve geral. Entenda os principais pontos da reforma trabalhista que provoca greve geral em portugal. Mais de 50 sindicatos aderem à greve geral marcada para 11 de dezembro
