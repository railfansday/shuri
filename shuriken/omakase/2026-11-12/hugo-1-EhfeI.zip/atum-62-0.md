---
title: "Atum-6/2-0 - atum-6/2-0-ms-stk te connectivity raychem cable protection"
description: "Termocontraible atum 6/2-0 ( 6mm/2mm )con pasta 0.20mtrs"
date: "2026-03-29"
categories:
- "Uncategorized"
images:
- "https://http2.mlstatic.com/D_NQ_NP_669773-MLA91139399415_082025-O.webp"
featuredImage: "https://ce8dc832c.cloudimg.io/v7/_cdn_/0A/7F/90/00/0/653216_1.jpg?width=640&amp;height=480&amp;wat=1&amp;wat_url=_tme-wrk_%2Ftme_new.png&amp;wat_scale=100p&amp;ci_sign=0dadd26c6980f757122b7c7b52dc68a66dc3f3ca"
featured_image: "https://assets.rs-online.com/image/upload/v1525227553/70101276.jpg"
image: "https://www.te.com/content/dam/te-com/catalog/part/EM5/611/600/EM56116001-t2.jpg/jcr:content/renditions/product-small.png"
---

If you are searching about ATUM-6/2-0-STK TE Connectivity Raychem Cable Protection | Cables, Wires - Management | DigiKey you've visit to the right web. We have 35 Images about ATUM-6/2-0-STK TE Connectivity Raychem Cable Protection | Cables, Wires - Management | DigiKey like ATUM-6/2-0-STK Клеевая термоусадка самозатухающая Raychem, NB11652001, ATUM-6/2-0-STK TE Connectivity | Raychem Products | Heilind and also ATUM-6/2-0-STK | TE Connectivity Heat Shrink Tubing, Black 6 mm Sleeve Dia. x 1.2m Length, ATUM. Here you go:

ATUM-6/2-0-STK TE Connectivity Raychem Cable Protection | Cables, Wires - Management | DigiKey
----------------------------------------------------------------------------------------------

 ![ATUM-6/2-0-STK TE Connectivity Raychem Cable Protection | Cables, Wires - Management | DigiKey](https://media.digikey.com/photos/nophoto/pna_en_tmb.jpg) <small>www.digikey.com</small>ATUM-6/2-0-STK TE Connectivity Raychem Cable Protection | Cables, Wires - Management | DigiKey

ATUM-6/2-0-STK Клеевая термоусадка самозатухающая Raychem, NB11652001
---------------------------------------------------------------------

 ![ATUM-6/2-0-STK Клеевая термоусадка самозатухающая Raychem, NB11652001](https://s-motorsport.com/image/cache/catalog/Raychem/ATUM 3-1/Raychem ATUM-6 2-0-STK NB11652001-2000x2000.jpg) <small>s-motorsport.com</small>ATUM-6/2-0-STK Клеевая термоусадка самозатухающая Raychem, NB11652001

ATUM-6/2-0-MS-STK TE Connectivity Raychem Cable Protection | Cables, Wires - Management | DigiKey
-------------------------------------------------------------------------------------------------

 ![ATUM-6/2-0-MS-STK TE Connectivity Raychem Cable Protection | Cables, Wires - Management | DigiKey](https://media.digikey.com/photos/Tyco Raychem Photos/ATU062K.jpg) <small>www.digikey.com</small>ATUM-6/2-0-MS-STK TE Connectivity Raychem Cable Protection | Cables, Wires - Management | DigiKey

ATUM-6/2-0-STK : RAYCHEM ATUM 3:1 Heat Shrink Tubing | TE Connectivity
----------------------------------------------------------------------

 ![ATUM-6/2-0-STK : RAYCHEM ATUM 3:1 Heat Shrink Tubing | TE Connectivity](https://www.te.com/content/dam/te-com/catalog/part/EM5/611/600/EM56116001-t1.jpg/jcr:content/renditions/product-small.png?w=85) <small>www.te.com</small>ATUM-6/2-0-STK : RAYCHEM ATUM 3:1 Heat Shrink Tubing | TE Connectivity

ATUM-6/2-0-STK Heat Shrink Tubing By RAYCHEM CONNECTIVITY
---------------------------------------------------------

 ![ATUM-6/2-0-STK Heat Shrink Tubing by RAYCHEM CONNECTIVITY](https://cdn.radwell.com/productgoogleimages/cf054bf9e1344ba19a131778bed859f4.jpg) <small>www.radwell.com</small>ATUM-6/2-0-STK Heat Shrink Tubing by RAYCHEM CONNECTIVITY

ATUM-6/2-0-STK TE Connectivity Raychem Cable Protection | Cables, Wires - Management | DigiKey
----------------------------------------------------------------------------------------------

 ![ATUM-6/2-0-STK TE Connectivity Raychem Cable Protection | Cables, Wires - Management | DigiKey](https://mm.digikey.com/Volume0/opasdata/d220001/medias/images/630/ATUM-62-0-STK.jpg) <small>www.digikey.com</small>ATUM-6/2-0-STK TE Connectivity Raychem Cable Protection | Cables, Wires - Management | DigiKey

TE Connectivity ATUM-6/2-0-STK Heat Shrink Tubing - 4 Ft. Stick At SkyGeek.com
------------------------------------------------------------------------------

 ![TE Connectivity ATUM-6/2-0-STK Heat Shrink Tubing - 4 ft. Stick at SkyGeek.com](https://cdn11.bigcommerce.com/s-jifykode7m/images/stencil/1280x1280/products/15869/120854/SGP97922_1_main__13081.1617287781.jpg?c=1) <small>skygeek.com</small>TE Connectivity ATUM-6/2-0-STK Heat Shrink Tubing - 4 ft. Stick at SkyGeek.com

ATUM-6/2-0-STK Raychem - Te Connectivity, Adhesive Lined Heat Shrink Tubing, Dual Medium Wall, 3
------------------------------------------------------------------------------------------------

 ![ATUM-6/2-0-STK Raychem - Te Connectivity, Adhesive Lined Heat Shrink Tubing, Dual Medium Wall, 3](https://uk.farnell.com/productimages/large/en_GB/42246141.jpg) <small>uk.farnell.com</small>ATUM-6/2-0-STK Raychem - Te Connectivity, Adhesive Lined Heat Shrink Tubing, Dual Medium Wall, 3 ...

ATUM-6/2-0-MS-STK - Raychem - Te Connectivity - Adhesive Lined Heat Shrink Tubing, Medium Wall, 3:1
---------------------------------------------------------------------------------------------------

 ![ATUM-6/2-0-MS-STK - Raychem - Te Connectivity - Adhesive Lined Heat Shrink Tubing, Medium Wall, 3:1](https://www.newark.com/productimages/large/en_US/09J3922-20.jpg) <small>www.newark.com</small>ATUM-6/2-0-MS-STK - Raychem - Te Connectivity - Adhesive Lined Heat Shrink Tubing, Medium Wall, 3:1

ATUM-24/6-0-STK TE Connectivity | Raychem Products | Heilind
------------------------------------------------------------

 ![ATUM-24/6-0-STK TE Connectivity | Raychem Products | Heilind](https://sku-product-images.s3.us-east-2.amazonaws.com/RYC/RYCNB14032001.jpg) <small>www.heilind.com</small>ATUM-24/6-0-STK TE Connectivity | Raychem Products | Heilind

ATUM-6/2-0-STK Клеевая термоусадка самозатухающая Raychem, NB11652001
---------------------------------------------------------------------

 ![ATUM-6/2-0-STK Клеевая термоусадка самозатухающая Raychem, NB11652001](https://s-motorsport.com/image/cache/catalog/Raychem/ATUM 3-1/Raychem-ATUM 3-1-900x900.jpg) <small>s-motorsport.com</small>ATUM-6/2-0-STK Клеевая термоусадка самозатухающая Raychem, NB11652001

Termocontraible Atum 6/2-0 ( 6mm/2mm )con Pasta 0.20mtrs | MercadoLibre
-----------------------------------------------------------------------

 ![Termocontraible Atum 6/2-0 ( 6mm/2mm )con Pasta 0.20mtrs | MercadoLibre](https://http2.mlstatic.com/D_NQ_NP_669773-MLA91139399415_082025-O.webp) <small>www.mercadolibre.com.ar</small>Termocontraible Atum 6/2-0 ( 6mm/2mm )con Pasta 0.20mtrs | MercadoLibre

ATUM-6/2-0-STK NVent RAYCHEM | Tubo Termorretráctil NVent RAYCHEM Negro, Contracción 3:1, Ø 6mm
-----------------------------------------------------------------------------------------------

 ![ATUM-6/2-0-STK nVent RAYCHEM | Tubo termorretráctil nVent RAYCHEM Negro, contracción 3:1, Ø 6mm](https://res.cloudinary.com/rsc/image/upload/b_rgb:FFFFFF,c_pad,dpr_1.0,f_auto,q_auto,w_700/c_pad,w_700/Y0433222-01) <small>cl.rsdelivers.com</small>ATUM-6/2-0-STK nVent RAYCHEM | Tubo termorretráctil nVent RAYCHEM Negro, contracción 3:1, Ø 6mm ...

ATUM-6/2-0 | TE Connectivity Adhesive Lined Heat Shrink Tubing, Black 6mm Sleeve Dia. X 1.2m
--------------------------------------------------------------------------------------------

 ![ATUM-6/2-0 | TE Connectivity Adhesive Lined Heat Shrink Tubing, Black 6mm Sleeve Dia. x 1.2m](https://media.rs-online.com/F3161568-01.jpg) <small>uk.rs-online.com</small>ATUM-6/2-0 | TE Connectivity Adhesive Lined Heat Shrink Tubing, Black 6mm Sleeve Dia. x 1.2m ...

ATUM-6/2-0-STK | TE Connectivity Heat Shrink Tubing, Black 6 Mm Sleeve Dia. X 1.2m Length, ATUM
-----------------------------------------------------------------------------------------------

 ![ATUM-6/2-0-STK | TE Connectivity Heat Shrink Tubing, Black 6 mm Sleeve Dia. x 1.2m Length, ATUM](https://media.rs-online.com/image/upload/bo_1.5px_solid_white,b_auto,c_pad,dpr_2,f_auto,h_399,q_auto,w_710/c_pad,h_399,w_710/Y0487247-01?pgw=1) <small>my.rs-online.com</small>ATUM-6/2-0-STK | TE Connectivity Heat Shrink Tubing, Black 6 mm Sleeve Dia. x 1.2m Length, ATUM ...

ATUM-6/2-0-STK TE Connectivity Raychem Cable Protection | Kabel, Drähte - Management | DigiKey
----------------------------------------------------------------------------------------------

 ![ATUM-6/2-0-STK TE Connectivity Raychem Cable Protection | Kabel, Drähte - Management | DigiKey](https://media.digikey.com/pdf/Catalog Drawings/Heat Shrink/ATUM-62-0-STK.jpg) <small>www.digikey.de</small>ATUM-6/2-0-STK TE Connectivity Raychem Cable Protection | Kabel, Drähte - Management | DigiKey

ATUM Thin Wall Heatshrink
-------------------------

 ![ATUM Thin Wall Heatshrink](https://www.transnet.co.nz/images/Products/ATUM-6-2-0-STK_1.jpg) <small>www.transnet.co.nz</small>ATUM Thin Wall Heatshrink

TE Connectivity ATUM-6/2-0-STK Tubing, Heat Shrink,Adhesive Lined, Flame Retardant, Thin Wall
---------------------------------------------------------------------------------------------

 ![TE Connectivity ATUM-6/2-0-STK Tubing, Heat Shrink,Adhesive Lined, Flame Retardant, Thin Wall](https://assets.rs-online.com/image/upload/v1525227553/70101276.jpg) <small>us.rs-online.com</small>TE Connectivity ATUM-6/2-0-STK Tubing, Heat Shrink,Adhesive Lined, Flame Retardant, Thin Wall ...

レイケム ATUM-6/2-0-STK（カット品1.2m） 黒色 接着層付き 防水熱収縮チューブ 6.0→2.0mm : FA-Ubon Yahoo!店 - 通販 - Yahoo!ショッピング
------------------------------------------------------------------------------------------------

 ![レイケム ATUM-6/2-0-STK（カット品1.2m） 黒色 接着層付き 防水熱収縮チューブ 6.0→2.0mm : FA-Ubon Yahoo!店 - 通販 - Yahoo!ショッピング](https://item-shopping.c.yimg.jp/i/n/faubon_0878886) <small>store.shopping.yahoo.co.jp</small>レイケム ATUM-6/2-0-STK（カット品1.2m） 黒色 接着層付き 防水熱収縮チューブ 6.0→2.0mm : FA-Ubon Yahoo!店 - 通販 - Yahoo!ショッピング

ATUM-6/2-0-STK TE Connectivity Raychem Cable Protection | Heat Shrink Tubing | DigiKey
--------------------------------------------------------------------------------------

 ![ATUM-6/2-0-STK TE Connectivity Raychem Cable Protection | Heat Shrink Tubing | DigiKey](https://mm.digikey.com/Volume0/opasdata/d220001/derivates/3/003/226/041/MFG_ATUM-XX-X-0-SP_tmb(64x64).jpg) <small>www.digikey.com</small>ATUM-6/2-0-STK TE Connectivity Raychem Cable Protection | Heat Shrink Tubing | DigiKey

ATUM-6/2-0-STK TE Connectivity Raychem Cable Protection | Heat Shrink Tubing | DigiKey
--------------------------------------------------------------------------------------

 ![ATUM-6/2-0-STK TE Connectivity Raychem Cable Protection | Heat Shrink Tubing | DigiKey](https://mm.digikey.com/Volume0/opasdata/d220001/derivates/1/003/226/041/MFG_ATUM-XX-X-0-SP_sml(200x200).jpg) <small>www.digikey.com</small>ATUM-6/2-0-STK TE Connectivity Raychem Cable Protection | Heat Shrink Tubing | DigiKey

ATUM-6/2-0 TE Connectivity | TE Connectivity Heat Shrink Tubing, Black 6 Mm Sleeve Dia. X 1.2m
----------------------------------------------------------------------------------------------

 ![ATUM-6/2-0 TE Connectivity | TE Connectivity Heat Shrink Tubing, Black 6 mm Sleeve Dia. x 1.2m](https://res.cloudinary.com/rsc/image/upload/b_rgb:FFFFFF,c_pad,dpr_1.0,f_auto,q_auto,w_700/c_pad,w_700/F3161568-02) <small>ae.rsdelivers.com</small>ATUM-6/2-0 TE Connectivity | TE Connectivity Heat Shrink Tubing, Black 6 mm Sleeve Dia. x 1.2m ...

Qual O Melhor Atum Em Lata? - Estadão
-------------------------------------

 ![Qual o melhor atum em lata? - Estadão](https://www.estadao.com.br/resizer/v2/SKW2BB3PB5EZLOWVBD7J3I6DDY.PNG?quality=80&auth=92acfe0ac2091531de29a439f165240e50065da7c292fa2b34cb2de4994287ca&width=768) <small>www.estadao.com.br</small>Qual o melhor atum em lata? - Estadão

ATUM-6/2-0-STK TE Connectivity | Raychem Products | Heilind
-----------------------------------------------------------

 ![ATUM-6/2-0-STK TE Connectivity | Raychem Products | Heilind](https://sku-product-images.s3.us-east-2.amazonaws.com/RYC/RYCATUM-6-2-0-STK.jpg) <small>www.heilind.com</small>ATUM-6/2-0-STK TE Connectivity | Raychem Products | Heilind

ATUM-6/2-0-STK TE CONNECTIVITY - RAYCHEM, Adhesive Lined Heat Shrink Tubing, Dual Medium Wall, 3
------------------------------------------------------------------------------------------------

 ![ATUM-6/2-0-STK TE CONNECTIVITY - RAYCHEM, Adhesive Lined Heat Shrink Tubing, Dual Medium Wall, 3](https://uk.farnell.com/productimages/standard/en_GB/42246141.jpg) <small>uk.farnell.com</small>ATUM-6/2-0-STK TE CONNECTIVITY - RAYCHEM, Adhesive Lined Heat Shrink Tubing, Dual Medium Wall, 3 ...

ATUM-6/2-0-STK TE Connectivity Raychem Cable Protection | Cables, Wires - Management | DigiKey
----------------------------------------------------------------------------------------------

 ![ATUM-6/2-0-STK TE Connectivity Raychem Cable Protection | Cables, Wires - Management | DigiKey](https://mm.digikey.com/Volume0/opasdata/d220001/medias/images/707/ATU062K.jpg) <small>www.digikey.com</small>ATUM-6/2-0-STK TE Connectivity Raychem Cable Protection | Cables, Wires - Management | DigiKey

ATUM-6/2-0-STK TE Connectivity | Raychem Products | Heilind
-----------------------------------------------------------

 ![ATUM-6/2-0-STK TE Connectivity | Raychem Products | Heilind](https://sku-product-images.s3.us-east-2.amazonaws.com/AMP/AMP206061-2.jpg) <small>www.heilind.com</small>ATUM-6/2-0-STK TE Connectivity | Raychem Products | Heilind

ATUM-6/2-0-STK TE Connectivity Raychem Cable Protection | Heat Shrink Tubing | DigiKey
--------------------------------------------------------------------------------------

 ![ATUM-6/2-0-STK TE Connectivity Raychem Cable Protection | Heat Shrink Tubing | DigiKey](https://mm.digikey.com/Volume0/opasdata/d220001/derivates/1/003/209/407/ATU062K_sml.jpg) <small>www.digikey.com</small>ATUM-6/2-0-STK TE Connectivity Raychem Cable Protection | Heat Shrink Tubing | DigiKey

ATUM-6/2-0-STK : RAYCHEM ATUM 3:1 Heat Shrink Tubing | TE Connectivity
----------------------------------------------------------------------

 ![ATUM-6/2-0-STK : RAYCHEM ATUM 3:1 Heat Shrink Tubing | TE Connectivity](https://www.te.com/content/dam/te-com/catalog/part/EM5/611/600/EM56116001-t2.jpg/jcr:content/renditions/product-small.png) <small>www.te.com</small>ATUM-6/2-0-STK : RAYCHEM ATUM 3:1 Heat Shrink Tubing | TE Connectivity

ATUM-6/2-0-SP TE Connectivity Raychem Cable Protection $3.40136/ 1 SPQ, 2827 Original Parts In
----------------------------------------------------------------------------------------------

 ![ATUM-6/2-0-SP TE Connectivity Raychem Cable Protection $3.40136/ 1 SPQ, 2827 Original Parts in](https://res01.jakelectronics.com/80fimg/teconnectivityraychemcableprotection-atum620sp-8903.jpg) <small>www.jakelectronics.com</small>ATUM-6/2-0-SP TE Connectivity Raychem Cable Protection $3.40136/ 1 SPQ, 2827 Original Parts in ...

ATUM-6/2-0-STK TE Connectivity | Raychem Products | Heilind
-----------------------------------------------------------

 ![ATUM-6/2-0-STK TE Connectivity | Raychem Products | Heilind](https://sku-product-images.s3.us-east-2.amazonaws.com/AMP/1-1971875-7.jpg) <small>www.heilind.com</small>ATUM-6/2-0-STK TE Connectivity | Raychem Products | Heilind

ATUM-6/2-0-SP Datasheet PDF | Raychem - AiPCBA
----------------------------------------------

 ![ATUM-6/2-0-SP Datasheet PDF | Raychem - AiPCBA](https://oss-datasheet.findic.com/thumbnail/513F7EA6575D93FE8C55CFF78616155F-1.jpg) <small>www.aipcba.com</small>ATUM-6/2-0-SP Datasheet PDF | Raychem - AiPCBA

ATUM-6/2-0-STK Клеевая термоусадка самозатухающая Raychem, NB11652001
---------------------------------------------------------------------

 ![ATUM-6/2-0-STK Клеевая термоусадка самозатухающая Raychem, NB11652001](https://s-motorsport.com/image/cache/catalog/Raychem/ATUM 3-1/TE-Raychem-ATUM 3-1-900x900.jpg) <small>s-motorsport.com</small>ATUM-6/2-0-STK Клеевая термоусадка самозатухающая Raychem, NB11652001

ATUM-6/2-0-STK TE Connectivity Solutions GmbH - 热缩管 | 胶粘; 3: 1; 6mm; L: 1.2m; 黑色; 聚烯烃; 收缩后直径
--------------------------------------------------------------------------------------------

 ![ATUM-6/2-0-STK TE Connectivity Solutions GmbH - 热缩管 | 胶粘; 3: 1; 6mm; L: 1.2m; 黑色; 聚烯烃; 收缩后直径](https://ce8dc832c.cloudimg.io/v7/_cdn_/0A/7F/90/00/0/653216_1.jpg?width=640&height=480&wat=1&wat_url=_tme-wrk_%2Ftme_new.png&wat_scale=100p&ci_sign=0dadd26c6980f757122b7c7b52dc68a66dc3f3ca) <small>www.tme.eu</small>ATUM-6/2-0-STK TE Connectivity Solutions GmbH - 热缩管 | 胶粘; 3: 1; 6mm; L: 1.2m; 黑色; 聚烯烃; 收缩后直径 ...

ATUM-6/2-0-STK : RAYCHEM ATUM 3:1 Heat Shrink Tubing | TE Connectivity
----------------------------------------------------------------------

 ![ATUM-6/2-0-STK : RAYCHEM ATUM 3:1 Heat Shrink Tubing | TE Connectivity](https://www.te.com/content/dam/te-com/catalog/part/EM5/611/600/EM56116001-t3.jpg/jcr:content/renditions/product-small.png) <small>www.te.com</small>ATUM-6/2-0-STK : RAYCHEM ATUM 3:1 Heat Shrink Tubing | TE Connectivity

atum-6/2-0-stk клеевая термоусадка самозатухающая raychem, nb11652001. Qual o melhor atum em lata?. atum-24/6-0-stk te connectivity
