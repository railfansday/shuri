---
title: "Cantor Math - Five famous mathematicians and their contributions"
description: "Georg cantor was a german mathematician best known for developing set theory and introducing the"
date: "2026-08-30"
categories:
- "Uncategorized"
images:
- "https://image.slidesharecdn.com/cantorforshare-190320085549/85/Cantor-Infinity-theorems-2-320.jpg"
featuredImage: "https://c8.alamy.com/comp/2ADGPJH/georg-cantor-portrait-of-georg-cantor-1845-1918-german-mathematician-born-in-st-petersburg-russia-cantor-studied-in-berlin-germany-before-b-2ADGPJH.jpg"
featured_image: "https://www.smorescience.com/wp-content/uploads/2024/04/Georg_Cantor.png"
image: "https://image.slidesharecdn.com/sets-200603064149/85/Sets-3-320.jpg"
---

If you are searching about Sets | PPTX you've came to the right web. We have 31 Images about Sets | PPTX like Who Is the Greatest Mathematician in the World? | OxBright, Georg Cantor Portrait Image Source and also Cantor's infinity pairing proof. Diagram showing the pairing proof of the German mathematician. Here you go:

Sets | PPTX
-----------

 ![Sets | PPTX](https://image.slidesharecdn.com/sets-200603064149/85/Sets-3-320.jpg) <small>www.slideshare.net</small>Sets | PPTX

Cantor, German Mathematician Who Invented Set Theory – YSKUT
------------------------------------------------------------

 ![Cantor, German Mathematician Who Invented Set Theory – YSKUT](https://images.fineartamerica.com/images-medium-large-5/georg-cantor-german-mathematician-science-photo-library.jpg) <small>music.awo-kv-ffb.de</small>Cantor, German Mathematician Who Invented Set Theory – YSKUT

Cantor Set | PPTX
-----------------

 ![Cantor Set | PPTX](https://image.slidesharecdn.com/ppt-151211120926/75/Cantor-Set-3-2048.jpg) <small>www.slideshare.net</small>Cantor Set | PPTX

German Mathematician Georg Cantor At Halle University, Germany, 1894. News Photo - Getty Images
-----------------------------------------------------------------------------------------------

 ![German mathematician Georg Cantor at Halle University, Germany, 1894. News Photo - Getty Images](https://media.gettyimages.com/id/886667898/photo/georg-cantor.jpg?s=1024x1024&w=gi&k=20&c=o7M-l949qxL4QQdh_vqAWCVRJIFL0g9Z7Y2w7Y02FV8=) <small>www.gettyimages.com</small>German mathematician Georg Cantor at Halle University, Germany, 1894. News Photo - Getty Images

Georg Cantor Portrait Image Source
----------------------------------

 ![Georg Cantor Portrait Image Source](https://cdn.futura-sciences.com/sources/images/scientist/persov6/Cantor-1000.jpg) <small>ecency.com</small>Georg Cantor Portrait Image Source

Five Famous Mathematicians And Their Contributions - Smore Science
------------------------------------------------------------------

 ![Five Famous Mathematicians And Their Contributions - Smore Science](https://www.smorescience.com/wp-content/uploads/2024/04/Georg_Cantor.png) <small>www.smorescience.com</small>Five Famous Mathematicians And Their Contributions - Smore Science

Cantor Infinity Theorems | PPTX
-------------------------------

 ![Cantor Infinity theorems | PPTX](https://image.slidesharecdn.com/cantorforshare-190320085549/85/Cantor-Infinity-theorems-2-320.jpg) <small>www.slideshare.net</small>Cantor Infinity theorems | PPTX

Georg Cantor – Timeline Of Mathematics – Mathigon
-------------------------------------------------

 ![Georg Cantor – Timeline of Mathematics – Mathigon](https://static.mathigon.org/tiles/bio-cantor.jpg) <small>mathigon.org</small>Georg Cantor – Timeline of Mathematics – Mathigon

Georg Cantor - The Man Who Founded Set Theory
---------------------------------------------

 ![Georg Cantor - The Man Who Founded Set Theory](https://www.storyofmathematics.com/wp-content/uploads/2020/01/cantor_bijection.gif) <small>www.storyofmathematics.com</small>Georg Cantor - The Man Who Founded Set Theory

Presentation On Set In Discrete Mathe | PPTX
--------------------------------------------

 ![Presentation on set in discrete mathe | PPTX](https://image.slidesharecdn.com/presentationonsetindiscretemathe-181208074316/85/Presentation-on-set-in-discrete-mathe-4-320.jpg) <small>www.slideshare.net</small>Presentation on set in discrete mathe | PPTX

Sets In Math: Types, Operations, Venn Diagrams &amp; Relations
--------------------------------------------------------------

 ![Sets in Math: Types, Operations, Venn Diagrams & Relations](https://i0.wp.com/gauravtiwari.org/wp-content/uploads/2020/06/George-Cantor-1.jpg?fit=1160%2C1568&ssl=1) <small>gauravtiwari.org</small>Sets in Math: Types, Operations, Venn Diagrams &amp; Relations

Georg Cantor - Alchetron, The Free Social Encyclopedia
------------------------------------------------------

 ![Georg Cantor - Alchetron, The Free Social Encyclopedia](https://alchetron.com/cdn/georg-cantor-d3534101-f9a5-4e7b-8ed8-1eec388d44a-resize-750.jpeg) <small>alchetron.com</small>Georg Cantor - Alchetron, The Free Social Encyclopedia

George Cantor Photos And Premium High Res Pictures - Getty Images
-----------------------------------------------------------------

 ![George Cantor Photos and Premium High Res Pictures - Getty Images](https://media.gettyimages.com/id/141551125/photo/portrait-of-a-german-mathematician-and-founders-of-the-set-theory-georg-cantor-1890s.jpg?s=612x612&w=gi&k=20&c=f2IhHuQWoo6o68S21wZ4CNRRLQHn56fydhtvxInKSJc=) <small>www.gettyimages.com</small>George Cantor Photos and Premium High Res Pictures - Getty Images

Georg Cantor - History Of Math And Technology
---------------------------------------------

 ![Georg Cantor - History of Math and Technology](https://www.historymath.com/wp-content/uploads/2023/12/9995fa08-e72f-4b83-ac9a-00f9887617d3-780x614.jpg) <small>www.historymath.com</small>Georg Cantor - History of Math and Technology

Georg Cantor Was A German Mathematician Best Known For Developing Set Theory And Introducing The
------------------------------------------------------------------------------------------------

 ![Georg Cantor was a German mathematician best known for developing set theory and introducing the](https://c8.alamy.com/comp/J3FDHA/georg-cantor-was-a-german-mathematician-best-known-for-developing-J3FDHA.jpg) <small>www.alamy.com</small>Georg Cantor was a German mathematician best known for developing set theory and introducing the ...

Cantor Set | PPTX
-----------------

 ![Cantor Set | PPTX](https://image.slidesharecdn.com/ppt-151211120926/75/Cantor-Set-12-2048.jpg) <small>www.slideshare.net</small>Cantor Set | PPTX

Georg Cantor His Mathematics And The Philosophy Of The Infinite
---------------------------------------------------------------

 ![Georg Cantor His Mathematics and the Philosophy of the infinite](https://imgv2-1-f.scribdassets.com/img/document/117080162/original/b8a6940522/1562439278?v=1) <small>www.scribd.com</small>Georg Cantor His Mathematics and the Philosophy of the infinite

Cantor Set - GeeksforGeeks
--------------------------

 ![Cantor Set - GeeksforGeeks](https://media.geeksforgeeks.org/wp-content/uploads/20240523124436/Cantor-Set.png) <small>www.geeksforgeeks.org</small>Cantor Set - GeeksforGeeks

Georg Cantor - The Man Who Founded Set Theory
---------------------------------------------

 ![Georg Cantor - The Man Who Founded Set Theory](https://www.storyofmathematics.com/wp-content/uploads/2020/01/cantor.jpg) <small>www.storyofmathematics.com</small>Georg Cantor - The Man Who Founded Set Theory

On This Day - January 6, 1918 ️ We Remember Georg Cantor (1845–1918), The Brilliant German
------------------------------------------------------------------------------------------

 ![On This Day - January 6, 1918 ️ We remember Georg Cantor (1845–1918), the brilliant German](https://media.licdn.com/dms/image/v2/D5622AQHVqV8bHuP4GA/feedshare-shrink_1280/B56ZQ6bM6wHoAk-/0/1736147001370?e=2147483647&v=beta&t=V_0NJYmqAY8lB6kCoK_uTjM5W8hOTBY2dC8SiT3cSr4) <small>www.linkedin.com</small>On This Day - January 6, 1918 ️ We remember Georg Cantor (1845–1918), the brilliant German ...

SET THEORY AND LOGIC.pptx General Mathematicd | PPTX
----------------------------------------------------

 ![SET THEORY AND LOGIC.pptx General Mathematicd | PPTX](https://image.slidesharecdn.com/settheoryandlogic-240312020025-8cd55171/75/SET-THEORY-AND-LOGIC-pptx-General-Mathematicd-3-2048.jpg) <small>www.slideshare.net</small>SET THEORY AND LOGIC.pptx General Mathematicd | PPTX

HISTORY OF SETS.pptx
--------------------

 ![HISTORY OF SETS.pptx](https://image.slidesharecdn.com/historyofsets-220724054325-4af97a06/85/HISTORY-OF-SETS-pptx-3-320.jpg) <small>www.slideshare.net</small>HISTORY OF SETS.pptx

PPT - Georg Cantor PowerPoint Presentation, Free Download - ID:1956227
----------------------------------------------------------------------

 ![PPT - Georg Cantor PowerPoint Presentation, free download - ID:1956227](https://image1.slideserve.com/1956227/slide1-l.jpg) <small>www.slideserve.com</small>PPT - Georg Cantor PowerPoint Presentation, free download - ID:1956227

PPT - Cantor And Countability: PowerPoint Presentation, Free Download - ID:421134
---------------------------------------------------------------------------------

 ![PPT - Cantor and Countability: PowerPoint Presentation, free download - ID:421134](https://image4.slideserve.com/421134/georg-cantor-an-original-mathematician-l.jpg) <small>www.slideserve.com</small>PPT - Cantor and Countability: PowerPoint Presentation, free download - ID:421134

GEORG CANTOR (1845-1918). /nGerman Mathematician: Oil Over A Photograph Stock Photo - Alamy
-------------------------------------------------------------------------------------------

 ![GEORG CANTOR (1845-1918). /nGerman mathematician: oil over a photograph Stock Photo - Alamy](https://c8.alamy.com/comp/FF961X/georg-cantor-1845-1918-ngerman-mathematician-oil-over-a-photograph-FF961X.jpg) <small>www.alamy.com</small>GEORG CANTOR (1845-1918). /nGerman mathematician: oil over a photograph Stock Photo - Alamy

PPT - Exploring The Beauty Of Mathematics - Patterns, Logic, And Philosophy PowerPoint
--------------------------------------------------------------------------------------

 ![PPT - Exploring the Beauty of Mathematics - Patterns, Logic, and Philosophy PowerPoint](https://image4.slideserve.com/8878908/georg-cantor-created-set-theory-which-has-become-l.jpg) <small>www.slideserve.com</small>PPT - Exploring the Beauty of Mathematics - Patterns, Logic, and Philosophy PowerPoint ...

Who Is The Greatest Mathematician In The World? | OxBright
----------------------------------------------------------

 ![Who Is the Greatest Mathematician in the World? | OxBright](https://www.oxbright.org/wp-content/uploads/2023/12/georg-cantor.webp) <small>www.oxbright.org</small>Who Is the Greatest Mathematician in the World? | OxBright

Georg Cantor. Portrait Of Georg Cantor (1845- 1918), German Mathematician. Born In St
-------------------------------------------------------------------------------------

 ![Georg Cantor. Portrait of Georg Cantor (1845- 1918), German mathematician. Born in St](https://c8.alamy.com/comp/2ADGPJH/georg-cantor-portrait-of-georg-cantor-1845-1918-german-mathematician-born-in-st-petersburg-russia-cantor-studied-in-berlin-germany-before-b-2ADGPJH.jpg) <small>www.alamy.com</small>Georg Cantor. Portrait of Georg Cantor (1845- 1918), German mathematician. Born in St ...

Georg Cantor , German Mathematician, 1845-1918. Cantor As An Older Man, Date Unknown. Cantor Was
------------------------------------------------------------------------------------------------

 ![Georg Cantor , German mathematician, 1845-1918. Cantor as an older man, date unknown. Cantor was](https://hekint.org/wp-content/uploads/2021/04/georg-cantor.png) <small>hekint.org</small>Georg Cantor , German mathematician, 1845-1918. Cantor as an older man, date unknown. Cantor was ...

Cantor's Infinity Pairing Proof. Diagram Showing The Pairing Proof Of The German Mathematician
----------------------------------------------------------------------------------------------

 ![Cantor's infinity pairing proof. Diagram showing the pairing proof of the German mathematician](https://c8.alamy.com/comp/2ACCD5H/cantors-infinity-pairing-proof-diagram-showing-the-pairing-proof-of-the-german-mathematician-georg-cantor-1845-1918-which-demonstrated-that-the-i-2ACCD5H.jpg) <small>www.alamy.com</small>Cantor's infinity pairing proof. Diagram showing the pairing proof of the German mathematician ...

Georg Cantor, German Mathematician - Stock Image - C052/6934 - Science Photo Library
------------------------------------------------------------------------------------

 ![Georg Cantor, German mathematician - Stock Image - C052/6934 - Science Photo Library](https://media.sciencephoto.com/image/c0526934/800wm/C0526934-Georg_Cantor,_German_mathematician.jpg) <small>www.sciencephoto.com</small>Georg Cantor, German mathematician - Stock Image - C052/6934 - Science Photo Library

Georg cantor was a german mathematician best known for developing set theory and introducing the. Georg cantor. Cantor set
