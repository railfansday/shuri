---
title: "Kimberly Powell Nvidia - Nvidia vp kimberly powell announced resignation or remova... 2026"
description: "Kimberly powell&#039;s net worth (2026) &amp; nvidia salary revealed"
date: "2026-03-04"
categories:
- "Uncategorized"
images:
- "https://dnyuz.com/wp-content/uploads/2026/11/6af503aeb2c29afb4e56a013.webp"
featuredImage: "https://i.ytimg.com/vi/aqWvXbKxp3I/oar2.jpg?sqp=-oaymwEkCJUDENAFSFqQAgHyq4qpAxMIARUAAAAAJQAAyEI9AICiQ3gB&amp;rs=AOn4CLDsM9FYNM8j-H-uyArld8k-Bo916A"
featured_image: "https://img.etimg.com/thumb/msid-135754452,width-950,height-600,imgsize-130156,resizemode-75/jensen-huangs-former-partner-kimberly-powell-walks-the-show-floor-in-nvidia-videobr.jpg"
image: "https://images.inkl.com/s3/article/lead_image/24054567/kimberly-powell.png"
---

If you are looking for Kimberly Powell, vice-présidente de NVIDIA, a annoncé sa 2026 | Polymarket you've came to the right web. We have 35 Pictures about Kimberly Powell, vice-présidente de NVIDIA, a annoncé sa 2026 | Polymarket like Kimberly Powell Biography: Age, Nvidia Healthcare Career and the Jensen Huang Report – The, Kimberly Powell NVIDIA: Healthcare AI Executive Draws Attention Amid Jensen Huang Allegations and also Kimberly Powell's Net Worth (2026) &amp; NVIDIA Salary Revealed. Read more:

Kimberly Powell, Vice-présidente De NVIDIA, A Annoncé Sa 2026 | Polymarket
--------------------------------------------------------------------------

 ![Kimberly Powell, vice-présidente de NVIDIA, a annoncé sa 2026 | Polymarket](https://polymarket.com/api/og?eslug=nvidia-vp-kimberly-powell-announced-resignation-or-removal-byptptpt&locale=fr&tid=1794448439304) <small>polymarket.com</small>Kimberly Powell, vice-présidente de NVIDIA, a annoncé sa ... 2026 | Polymarket

Who Is Kimberly Powell, The Nvidia Exec Alleged To Have A Relationship With CEO Jensen Huang
--------------------------------------------------------------------------------------------

 ![Who is Kimberly Powell, the Nvidia exec alleged to have a relationship with CEO Jensen Huang](https://dnyuz.com/wp-content/uploads/2026/11/6af503aeb2c29afb4e56a013.webp) <small>dnyuz.com</small>Who is Kimberly Powell, the Nvidia exec alleged to have a relationship with CEO Jensen Huang ...

Watch: Jensen Huang’s Reported Extramarital Partner Kimberly Powell Walks The Show Floor In
-------------------------------------------------------------------------------------------

 ![Watch: Jensen Huang’s reported extramarital partner Kimberly Powell walks the show floor in](https://img.etimg.com/thumb/msid-135754452,width-950,height-600,imgsize-130156,resizemode-75/jensen-huangs-former-partner-kimberly-powell-walks-the-show-floor-in-nvidia-videobr.jpg) <small>economictimes.indiatimes.com</small>Watch: Jensen Huang’s reported extramarital partner Kimberly Powell walks the show floor in ...

Who Is Kimberly Powell, Nvidia Executive Who Had Affair With CEO Jensen Huang?
------------------------------------------------------------------------------

 ![Who Is Kimberly Powell, Nvidia Executive Who Had Affair With CEO Jensen Huang?](https://c.ndtvimg.com/2026-11/tc1q8iag_kimberly-powell_625x300_12_November_26.jpeg) <small>www.ndtv.com</small>Who Is Kimberly Powell, Nvidia Executive Who Had Affair With CEO Jensen Huang?

Kimberly Powell, Vice-présidente De NVIDIA, A Annoncé Sa 2026 | Polymarket
--------------------------------------------------------------------------

 ![Kimberly Powell, vice-présidente de NVIDIA, a annoncé sa 2026 | Polymarket](https://polymarket.com/api/og?eslug=nvidia-vp-kimberly-powell-announced-resignation-or-removal-byptptpt&locale=fr&tid=1794468275680) <small>polymarket.com</small>Kimberly Powell, vice-présidente de NVIDIA, a annoncé sa ... 2026 | Polymarket

Kimberly Powell's Nvidia Role Goes Beyond AI Chips As…
------------------------------------------------------

 ![Kimberly Powell's Nvidia Role Goes Beyond AI Chips as…](https://images.inkl.com/s3/article/lead_image/24054567/kimberly-powell.png) <small>www.inkl.com</small>Kimberly Powell's Nvidia Role Goes Beyond AI Chips as…

NVIDIA VP Kimberly Powell Announced Resignation Or Remova... 2026 | Polymarket
------------------------------------------------------------------------------

 ![NVIDIA VP Kimberly Powell announced resignation or remova... 2026 | Polymarket](https://polymarket.com/api/og?eslug=nvidia-vp-kimberly-powell-announced-resignation-or-removal-byptptpt&tid=1794451949571) <small>polymarket.com</small>NVIDIA VP Kimberly Powell announced resignation or remova... 2026 | Polymarket

Who Is Kimberly Powell? Meet The Nvidia Executive Named In Jensen Huang Affair Report
-------------------------------------------------------------------------------------

 ![Who is Kimberly Powell? Meet the Nvidia executive named in Jensen Huang affair report](https://news24online.com/wp-content/uploads/2026/11/Kimberly-Powell.jpg) <small>news24online.com</small>Who is Kimberly Powell? Meet the Nvidia executive named in Jensen Huang affair report

Who Is Nvidia Executive Kimberly Powell?
----------------------------------------

 ![Who is Nvidia executive Kimberly Powell?](https://s.yimg.com/lo/mysterio/api/c58baa14f593e47f688278dcb4da5e984c223a30f1c349f4beb6089d8dd61a36/lightyear_networkapi/resizefill_w1200%3Bquality_80%3Bformat_webp/https://d29szjachogqwa.cloudfront.net/images/user-uploaded/1070a53c-f6f7-4f75-a138-a807f870fc8c_1b11a1432935558595099303c1bb4ff595485c4e06dacdf78afa24a4aa4d9961.jpg) <small>ca.finance.yahoo.com</small>Who is Nvidia executive Kimberly Powell?

Who Is Kimberly Powell? What To Know About The Nvidia Executive – Hollywood Life
--------------------------------------------------------------------------------

 ![Who Is Kimberly Powell? What to Know About the Nvidia Executive – Hollywood Life](https://i0.wp.com/media.hollywoodlife.com/uploads/2026/11/jensen-1920x1920-1-e1794491821965.jpeg?resize=1200%2C675&quality=100&ssl=1) <small>hollywoodlife.com</small>Who Is Kimberly Powell? What to Know About the Nvidia Executive – Hollywood Life

Nvidia Is Preparing To Dismiss Huang – Details Of The Second Novel Have Been Revealed - Aroged
----------------------------------------------------------------------------------------------

 ![Nvidia is preparing to dismiss Huang – details of the second novel have been revealed - Aroged](https://cdn.3dnews.ru/assets/external/illustrations/2026/11/12/1151182/Untitled-2.jpg) <small>www.aroged.com</small>Nvidia is preparing to dismiss Huang – details of the second novel have been revealed - Aroged

Who Is Kimberly Powell? Nvidia Exec Alleged To Have Had Affair With CEO - Newsweek
----------------------------------------------------------------------------------

 ![Who is Kimberly Powell? Nvidia exec alleged to have had affair with CEO - Newsweek](https://assets.newsweek.com/wp-content/uploads/2026/11/Copy-of-3-2-circle-inset-left-2.png?w=1600&quality=80&webp=1) <small>www.newsweek.com</small>Who is Kimberly Powell? Nvidia exec alleged to have had affair with CEO - Newsweek

Who Is Kimberly Powell, The Nvidia Executive Linked To CEO Jensen Huang? | Republic World
-----------------------------------------------------------------------------------------

 ![Who Is Kimberly Powell, the Nvidia Executive Linked to CEO Jensen Huang? | Republic World](https://img.republicworld.com/all_images/2026/11/who-is-kimberly-powell-the-nvidia-executive-linked-to-ceo-jensen-huang-1794455712889-1280x720.webp?w=1280&h=720&q=75&format=webp) <small>www.republicworld.com</small>Who Is Kimberly Powell, the Nvidia Executive Linked to CEO Jensen Huang? | Republic World

Kimberly Powell Nvidia: Summit Exit After Huang Report
------------------------------------------------------

 ![Kimberly Powell Nvidia: Summit Exit After Huang Report](https://bitcoinfoundation.org/wp-content/uploads/2026/11/kimberly-powell-cancels-health-summit-appearance-after-nvidia-ceo-relationship-r.webp) <small>bitcoinfoundation.org</small>Kimberly Powell Nvidia: Summit Exit After Huang Report

Kimberly Powell's 18-Year Journey At Nvidia Draws Attention After Personal Links With CEO Jensen
------------------------------------------------------------------------------------------------

 ![Kimberly Powell's 18-Year Journey At Nvidia Draws Attention After Personal Links With CEO Jensen](https://images.thedailyjagran.com/images/2026/11/12/template/image/Kimberlypowell-1794456712201.webp) <small>www.thedailyjagran.com</small>Kimberly Powell's 18-Year Journey At Nvidia Draws Attention After Personal Links With CEO Jensen ...

NVIDIA VP Kimberly Powell Announced Resignation Or Remova... 2026 | Polymarket
------------------------------------------------------------------------------

 ![NVIDIA VP Kimberly Powell announced resignation or remova... 2026 | Polymarket](https://polymarket.com/api/og?eslug=nvidia-vp-kimberly-powell-announced-resignation-or-removal-byptptpt&tid=1794448118816) <small>polymarket.com</small>NVIDIA VP Kimberly Powell announced resignation or remova... 2026 | Polymarket

Kimberly Powell Nvidia #kimberlypowell #shorts #nvidia - YouTube
----------------------------------------------------------------

 ![kimberly powell nvidia #kimberlypowell #shorts #nvidia - YouTube](https://i.ytimg.com/vi/aqWvXbKxp3I/oar2.jpg?sqp=-oaymwEkCJUDENAFSFqQAgHyq4qpAxMIARUAAAAAJQAAyEI9AICiQ3gB&rs=AOn4CLDsM9FYNM8j-H-uyArld8k-Bo916A) <small>www.youtube.com</small>kimberly powell nvidia #kimberlypowell #shorts #nvidia - YouTube

Kimberly Powell's Net Worth (2026) &amp; NVIDIA Salary Revealed
---------------------------------------------------------------

 ![Kimberly Powell's Net Worth (2026) & NVIDIA Salary Revealed](https://celebsfortune.com/wp-content/uploads/2026/11/kimberly-powell-nvidia-salary-and-net-worth-2026.jpg) <small>celebsfortune.com</small>Kimberly Powell's Net Worth (2026) &amp; NVIDIA Salary Revealed

Kimberly Powell-Jensen Huang Alleged Affair: What Nvidia's Cod...
-----------------------------------------------------------------

 ![Kimberly Powell-Jensen Huang Alleged Affair: What Nvidia's Cod...](https://data.ibtimes.sg/en/full/99518/kimberly-powell.jpg?w=736) <small>www.ibtimes.sg</small>Kimberly Powell-Jensen Huang Alleged Affair: What Nvidia's Cod...

Kimberly Powell, Vice-présidente De NVIDIA, A Annoncé Sa 2026 | Polymarket
--------------------------------------------------------------------------

 ![Kimberly Powell, vice-présidente de NVIDIA, a annoncé sa 2026 | Polymarket](https://polymarket.com/api/og?eslug=nvidia-vp-kimberly-powell-announced-resignation-or-removal-byptptpt&locale=fr&tid=1794492203296) <small>polymarket.com</small>Kimberly Powell, vice-présidente de NVIDIA, a annoncé sa ... 2026 | Polymarket

Kimberly Powell, The Engineer Who Became Nvidia's Healthcare VP And Is Now Caught In The Jensen
-----------------------------------------------------------------------------------------------

 ![Kimberly Powell, the engineer who became Nvidia's healthcare VP and is now caught in the Jensen](https://www.asiaone.com/sites/default/files/styles/article_top_image/public/original_images/Nov2026/kimberly-powell-nvidia-facebook (1).jpg?itok=hIIek7fk) <small>www.asiaone.com</small>Kimberly Powell, the engineer who became Nvidia's healthcare VP and is now caught in the Jensen ...

Kimberly Powell, Vice-présidente De NVIDIA, A Annoncé Sa 2026 | Polymarket
--------------------------------------------------------------------------

 ![Kimberly Powell, vice-présidente de NVIDIA, a annoncé sa 2026 | Polymarket](https://polymarket.com/api/og?eslug=nvidia-vp-kimberly-powell-announced-resignation-or-removal-byptptpt&locale=fr&tid=1794477850955) <small>polymarket.com</small>Kimberly Powell, vice-présidente de NVIDIA, a annoncé sa ... 2026 | Polymarket

NVIDIA VP Kimberly Powell Announced Resignation Or Remova... 2026 | Polymarket
------------------------------------------------------------------------------

 ![NVIDIA VP Kimberly Powell announced resignation or remova... 2026 | Polymarket](https://polymarket.com/api/og?eslug=nvidia-vp-kimberly-powell-announced-resignation-or-removal-byptptpt&tid=1794481024899) <small>polymarket.com</small>NVIDIA VP Kimberly Powell announced resignation or remova... 2026 | Polymarket

Is Kimberly Powell Nvidia's New CEO? Latest Update - PopTV Culture
------------------------------------------------------------------

 ![Is Kimberly Powell Nvidia's New CEO? Latest Update - PopTV Culture](https://poptvculture.com/wp-content/uploads/2026/11/kimberly-powell.webp) <small>poptvculture.com</small>Is Kimberly Powell Nvidia's New CEO? Latest Update - PopTV Culture

Kimberly Powell Biography: Age, Nvidia Healthcare Career And The Jensen Huang Report – The
------------------------------------------------------------------------------------------

 ![Kimberly Powell Biography: Age, Nvidia Healthcare Career and the Jensen Huang Report – The](https://jaisalmernews.com/wp-content/uploads/2026/11/kimberly-powell-biography-cover.webp) <small>jaisalmernews.com</small>Kimberly Powell Biography: Age, Nvidia Healthcare Career and the Jensen Huang Report – The ...

Who Is Kimberly Powell? Nvidia Executive Who Had Affair With CEO Jensen Huang
-----------------------------------------------------------------------------

 ![Who Is Kimberly Powell? Nvidia Executive Who Had Affair With CEO Jensen Huang](https://c.ndtvimg.com/2026-11/atbds6hc_kimberly-powell_625x300_12_November_26.jpeg?im=FaceCrop,algorithm=dnn,width=1600,height=900) <small>www.ndtv.com</small>Who Is Kimberly Powell? Nvidia Executive Who Had Affair With CEO Jensen Huang

Kimberly Powell (Nvidia) Wiki, Age, Husband &amp; Salary
--------------------------------------------------------

 ![Kimberly Powell (Nvidia) Wiki, Age, Husband & Salary](https://wikiofcelebrities.com/wp-content/uploads/2026/11/Kimberly-Powell.webp) <small>wikiofcelebrities.com</small>Kimberly Powell (Nvidia) Wiki, Age, Husband &amp; Salary

NVIDIA VP Kimberly Powell Announced Resignation Or Remova... 2026 | Polymarket
------------------------------------------------------------------------------

 ![NVIDIA VP Kimberly Powell announced resignation or remova... 2026 | Polymarket](https://polymarket.com/api/og?eslug=nvidia-vp-kimberly-powell-announced-resignation-or-removal-byptptpt&tid=1794455931125) <small>polymarket.com</small>NVIDIA VP Kimberly Powell announced resignation or remova... 2026 | Polymarket

Kimberly Powell Biography: Age, Nvidia Healthcare Career And The Jensen Huang Report – The
------------------------------------------------------------------------------------------

 ![Kimberly Powell Biography: Age, Nvidia Healthcare Career and the Jensen Huang Report – The](https://jaisalmernews.com/wp-content/uploads/2026/11/kimberly-powell-nvidia-speaker.webp) <small>jaisalmernews.com</small>Kimberly Powell Biography: Age, Nvidia Healthcare Career and the Jensen Huang Report – The ...

NVIDIA VP Kimberly Powell Announced Resignation Or Remova... 2026 | Polymarket
------------------------------------------------------------------------------

 ![NVIDIA VP Kimberly Powell announced resignation or remova... 2026 | Polymarket](https://polymarket.com/api/og?eslug=nvidia-vp-kimberly-powell-announced-resignation-or-removal-byptptpt&tid=1794484687317) <small>polymarket.com</small>NVIDIA VP Kimberly Powell announced resignation or remova... 2026 | Polymarket

Kimberly Powell Nvidia Career: Before Nvidia, Kimberly Powell Was An Engineering Intern In
------------------------------------------------------------------------------------------

 ![Kimberly Powell Nvidia career: Before Nvidia, Kimberly Powell was an engineering intern in](https://img.etimg.com/thumb/msid-135774638,width-1200,height-900,imgsize-152718,overlay-economictimes/articleshow.jpg) <small>economictimes.indiatimes.com</small>Kimberly Powell Nvidia career: Before Nvidia, Kimberly Powell was an engineering intern in ...

Kimberly Powell: How Married Nvidia Healthcare VP Rose Through...
-----------------------------------------------------------------

 ![Kimberly Powell: How Married Nvidia Healthcare VP Rose Through...](https://data.ibtimes.sg/en/full/99508/kimberly-powell.jpg?w=736) <small>www.ibtimes.sg</small>Kimberly Powell: How Married Nvidia Healthcare VP Rose Through...

Who Is Kimberly Powell, The Powerful Executive At Nvidia?
---------------------------------------------------------

 ![Who is Kimberly Powell, the powerful executive at Nvidia?](https://voz.us/fotos-seo/31569/16x9.jpg?v=15288027-4843-3228-50-50-AFP__20261110__D6YZ8CQ__v1__HighRes__FilesTaiwanChinaUsSemiconductorsAiNvidia-wbom8g.jpg) <small>voz.us</small>Who is Kimberly Powell, the powerful executive at Nvidia?

Kimberly Powell NVIDIA: Healthcare AI Executive Draws Attention Amid Jensen Huang Allegations
---------------------------------------------------------------------------------------------

 ![Kimberly Powell NVIDIA: Healthcare AI Executive Draws Attention Amid Jensen Huang Allegations](https://bunjareecottages.com.au/wp-content/uploads/2026/11/kimberly-powell-nvidia.jpg) <small>bunjareecottages.com.au</small>Kimberly Powell NVIDIA: Healthcare AI Executive Draws Attention Amid Jensen Huang Allegations ...

Kimberly Powell's Net Worth (2026) &amp; NVIDIA Salary Revealed
---------------------------------------------------------------

 ![Kimberly Powell's Net Worth (2026) & NVIDIA Salary Revealed](https://celebsfortune.com/wp-content/uploads/2026/11/kimberly-powell-picture.jpg) <small>celebsfortune.com</small>Kimberly Powell's Net Worth (2026) &amp; NVIDIA Salary Revealed

Who is nvidia executive kimberly powell?. Nvidia vp kimberly powell announced resignation or remova... 2026. Kimberly powell, vice-présidente de nvidia, a annoncé sa ... 2026
