---
title: "Greve Geral 11 Dezembro Tap - Amanhã há greve da função pública (escolas podem fechar)"
description: "Sdp sul"
date: "2025-11-22"
categories:
- "Uncategorized"
images:
- "https://staticx.noticiasilimitadas.pt/jn/image.webp?brand=jn&amp;type=generate&amp;guid=fb434b13-2b30-4ab1-a6bc-4ddd86b96b14&amp;w=3840"
featuredImage: "https://lookaside.fbsbx.com/lookaside/crawler/media/?media_id=1636871247895391"
featured_image: "https://www.ste.pt/wp-content/uploads/2025/12/GreveGeral-Cartaz-scaled.jpg"
image: "https://bordalo.observador.pt/v2/q:60/rs:fill:1440/c:4096:2730:nowe:0:0/plain/https://s3.observador.pt/wp-content/uploads/2025/12/11173228/dventura-greve-geral-11dez-41-scaled.jpg"
---

If you are looking for Greve geral pode custar 792 milhões de euros à economia - JN you've came to the right web. We have 35 Pics about Greve geral pode custar 792 milhões de euros à economia - JN like Greve Geral – 24 Horas – Dia 11 de Dezembro de 2025 – SINTTAV Sindicato Nacional dos, Contratos, horários, parentalidade e despedimentos: novo ano antecipa revolução no trabalho and also FAQ: Os direitos dos docentes em dia de Greve Geral - 11/12/2025. Here you go:

Greve Geral Pode Custar 792 Milhões De Euros à Economia - JN
------------------------------------------------------------

 ![Greve geral pode custar 792 milhões de euros à economia - JN](https://staticx.noticiasilimitadas.pt/jn/image.webp?brand=jn&type=generate&guid=fb434b13-2b30-4ab1-a6bc-4ddd86b96b14&w=3840) <small>www.jn.pt</small>Greve geral pode custar 792 milhões de euros à economia - JN

A Greve Geral De 11 De Dezembro Em 38 Imagens – Observador
----------------------------------------------------------

 ![A greve geral de 11 de dezembro em 38 imagens – Observador](https://bordalo.observador.pt/v2/q:60/rs:fill:1440/c:4096:2730:nowe:0:0/plain/https://s3.observador.pt/wp-content/uploads/2025/12/11173228/dventura-greve-geral-11dez-41-scaled.jpg) <small>observador.pt</small>A greve geral de 11 de dezembro em 38 imagens – Observador

SDP Sul
-------

 ![SDP Sul](https://sdpsul.com/storage/publicacao/imagem_563_6929dba6ddf62.jpeg) <small>sdpsul.com</small>SDP Sul

Greve Geral Paralisa Transportes, Saúde E Educação No Porto - Expresso
----------------------------------------------------------------------

 ![Greve geral paralisa transportes, saúde e educação no Porto - Expresso](https://images.impresa.pt/expresso/2025-12-11-rds_15_greve-geral-2025-manifestacao-porto_rds_4314.jpg-f75ffda9/original) <small>expresso.pt</small>Greve geral paralisa transportes, saúde e educação no Porto - Expresso

VISEU - Esclarecimento E Mobilização Para A Greve Geral Marcada Para 11 De Dezembro - CGTP-IN
---------------------------------------------------------------------------------------------

 ![VISEU - Esclarecimento e mobilização para a Greve Geral marcada para 11 de Dezembro - CGTP-IN](https://www.cgtp.pt/images/accao-e-luta/2025/gg.jpg) <small>www.cgtp.pt</small>VISEU - Esclarecimento e mobilização para a Greve Geral marcada para 11 de Dezembro - CGTP-IN

Perguntas E Respostas Sobre A Greve Geral De 11 De Dezembro - SBC - Sindicato Nacional Dos
------------------------------------------------------------------------------------------

 ![Perguntas e respostas sobre a Greve Geral de 11 de dezembro - SBC - Sindicato Nacional dos](https://www.sibace.pt/wp-content/uploads/2025/11/greve-2-1170-x-400.png) <small>www.sibace.pt</small>Perguntas e respostas sobre a Greve Geral de 11 de dezembro - SBC - Sindicato Nacional dos ...

A Greve Geral De 11 De Dezembro Em 38 Imagens – Observador
----------------------------------------------------------

 ![A greve geral de 11 de dezembro em 38 imagens – Observador](https://bordalo.observador.pt/v2/q:60/rs:fill:1440/c:4096:2730:nowe:0:0/plain/https://s3.observador.pt/wp-content/uploads/2025/12/11173246/dventura-greve-geral-11dez-43-scaled.jpg) <small>observador.pt</small>A greve geral de 11 de dezembro em 38 imagens – Observador

Dos Transportes à Saúde, Lares E Prisões, Que Serviços Mínimos Estão Garantidos Para A Greve
--------------------------------------------------------------------------------------------

 ![Dos transportes à saúde, lares e prisões, que serviços mínimos estão garantidos para a greve](https://images.impresa.pt/expresso/2025-12-09-greve-geral.jpg-0c01f0f6/original) <small>expresso.pt</small>Dos transportes à saúde, lares e prisões, que serviços mínimos estão garantidos para a greve ...

Contratos, Horários, Parentalidade E Despedimentos: Novo Ano Antecipa Revolução No Trabalho
-------------------------------------------------------------------------------------------

 ![Contratos, horários, parentalidade e despedimentos: novo ano antecipa revolução no trabalho](https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA1SeBdr.img?w=768&h=432&m=6&x=469&y=335&s=55&d=55) <small>www.msn.com</small>Contratos, horários, parentalidade e despedimentos: novo ano antecipa revolução no trabalho

Greve Geral De 11 De Dezembro: Impacto Económico Estimado E Análise | Economia
------------------------------------------------------------------------------

 ![Greve Geral de 11 de Dezembro: Impacto Económico Estimado e Análise | Economia](https://i.headtopics.com/images/2025/12/6/publico/greve-geral-o-que-e-quem-abrange-e-como-funciona-greve-geral-o-que-e-quem-abrange-e-como-funciona-43970BF408A401F542300934033BEA05.webp?w=640) <small>ph.headtopics.com</small>Greve Geral de 11 de Dezembro: Impacto Económico Estimado e Análise | Economia

A Greve Geral De 11 De Dezembro Em 38 Imagens – Observador
----------------------------------------------------------

 ![A greve geral de 11 de dezembro em 38 imagens – Observador](https://bordalo.observador.pt/v2/q:60/rs:fill:1440/c:4096:2730:nowe:0:0/plain/https://s3.observador.pt/wp-content/uploads/2025/12/11090822/dventura-greve-geral-11dez-8-scaled.jpg) <small>observador.pt</small>A greve geral de 11 de dezembro em 38 imagens – Observador

Greve Geral — 11 De Dezembro — Contra O Pacote Laboral | Partido Comunista Português
------------------------------------------------------------------------------------

 ![Greve Geral — 11 de Dezembro — Contra o Pacote Laboral | Partido Comunista Português](https://www.pcp.pt/sites/default/files/imagecache/facebook_share/images/dossiers/greve_geral_11_dez_2025/capa.jpg) <small>www.pcp.pt</small>Greve Geral — 11 de Dezembro — Contra o Pacote Laboral | Partido Comunista Português

UGT Aprova Por Unanimidade Greve Geral A 11 De Dezembro - Diário Do Minho
-------------------------------------------------------------------------

 ![UGT aprova por unanimidade greve geral a 11 de dezembro - Diário do Minho](https://www.diariodominho.pt/storage/posts/greve-direito-a-greve_655b8a6d702c0_og.jpg) <small>www.diariodominho.pt</small>UGT aprova por unanimidade greve geral a 11 de dezembro - Diário do Minho

Greve Geral De 11 De Dezembro Em Portugal: Razões Para Participar
-----------------------------------------------------------------

 ![Greve Geral de 11 de dezembro em Portugal: razões para participar](https://sabiasque.pt/images/stories/2025/trabalho/20251209-greve-geral-11-dezembro-320x480.jpg) <small>sabiasque.pt</small>Greve Geral de 11 de dezembro em Portugal: razões para participar

Amanhã Há Greve Da Função Pública (escolas Podem Fechar)
--------------------------------------------------------

 ![Amanhã há greve da função pública (escolas podem fechar)](https://jornaldemafra.pt/wp-content/uploads/2025/12/greve-geral.webp) <small>jornaldemafra.pt</small>Amanhã há greve da função pública (escolas podem fechar)

GREVE GERAL | 11 DEZEMBRO 2025 - ATE
------------------------------------

 ![GREVE GERAL | 11 DEZEMBRO 2025 - ATE](https://www.ate.pt/wp-content/uploads/2025/12/Greve-geral-11.12.jpg) <small>www.ate.pt</small>GREVE GERAL | 11 DEZEMBRO 2025 - ATE

A Greve Geral De 11 De Dezembro Em 38 Imagens – Observador
----------------------------------------------------------

 ![A greve geral de 11 de dezembro em 38 imagens – Observador](https://bordalo.observador.pt/v2/q:60/rs:fill:1440/c:4096:2730:nowe:0:0/plain/https://s3.observador.pt/wp-content/uploads/2025/12/11173414/dventura-greve-geral-11dez-54-scaled.jpg) <small>observador.pt</small>A greve geral de 11 de dezembro em 38 imagens – Observador

Motivos Da Adesão à Greve Geral De 11 De Dezembro De 2025
---------------------------------------------------------

 ![Motivos da adesão à Greve Geral de 11 de dezembro de 2025](https://spzn.pt/uploads/noticias/big_1763717239_6728_SPZN_2025_site_novo_(17).png) <small>spzn.pt</small>Motivos da adesão à Greve Geral de 11 de dezembro de 2025

Selfecorp - Greve Geral Em Portugal No Dia 11 De Dezembro!!!! Voos Da TAP São Cancelados E Novas
------------------------------------------------------------------------------------------------

 ![Selfecorp - Greve geral em Portugal no dia 11 de dezembro!!!! Voos da TAP são cancelados e novas](https://lookaside.fbsbx.com/lookaside/crawler/media/?media_id=1636871247895391) <small>www.facebook.com</small>Selfecorp - Greve geral em Portugal no dia 11 de dezembro!!!! Voos da TAP são cancelados e novas ...

Política Em 2025: Entre Crises E Mudanças | RTP Antena 1
--------------------------------------------------------

 ![Política em 2025: entre crises e mudanças | RTP Antena 1](https://antena1.rtp.pt/wp-content/uploads/2024/09/Greve-geral-Pacote-laboral-Antena-1_jpg.jpg) <small>antena1.rtp.pt</small>Política em 2025: entre crises e mudanças | RTP Antena 1

Todos à Greve Geral – 11 Dez. • Trabalhadores Unidos
----------------------------------------------------

 ![Todos à Greve Geral – 11 Dez. • Trabalhadores Unidos](https://trabalhadores-unidos.pt/wp-content/uploads/2025/12/capa-todos-gg.png) <small>trabalhadores-unidos.pt</small>Todos à Greve Geral – 11 Dez. • Trabalhadores Unidos

FAQ: Os Direitos Dos Docentes Em Dia De Greve Geral - 11/12/2025
----------------------------------------------------------------

 ![FAQ: Os direitos dos docentes em dia de Greve Geral - 11/12/2025](https://static.wixstatic.com/media/d0f32c_9ff1199ee2c34418af0094a43c516733~mv2.png/v1/fill/w_940,h_788,al_c,q_90,enc_avif,quality_auto/d0f32c_9ff1199ee2c34418af0094a43c516733~mv2.png) <small>www.sprc.pt</small>FAQ: Os direitos dos docentes em dia de Greve Geral - 11/12/2025

SPGL - Greve Geral | 11 De Dezembro De 2025 (Piquetes, Concentrações E Manifestações)
-------------------------------------------------------------------------------------

 ![SPGL - Greve Geral | 11 de dezembro de 2025 (Piquetes, Concentrações e Manifestações)](https://www.spgl.pt/Media/Default/_Profiles/722d2b7d/68bcf4e1/IMG_2694.JPG?v=639010778412646835) <small>www.spgl.pt</small>SPGL - Greve Geral | 11 de dezembro de 2025 (Piquetes, Concentrações e Manifestações)

Greve Geral Em Portugal – 11 De Dezembro - FLEMACON
---------------------------------------------------

 ![Greve geral em Portugal – 11 de dezembro - FLEMACON](https://www.flemacon.org/wp-content/uploads/2025/12/WhatsApp-Image-2025-12-12-at-19.45.27-1-696x870.jpeg) <small>www.flemacon.org</small>Greve geral em Portugal – 11 de dezembro - FLEMACON

CGTP Anuncia Greve Geral Para 11 De Dezembro
--------------------------------------------

 ![CGTP anuncia greve geral para 11 de dezembro](https://www.lusa.pt/TEMP/IMAGES/780x1200/CACHE_780X1200_ANALOG_WATERMARKED_45998234_7085120_08112025053627.JPG) <small>www.lusa.pt</small>CGTP anuncia greve geral para 11 de dezembro

Greve Geral: TAP Cancela Voos No Dia 11 De Dezembro
---------------------------------------------------

 ![Greve Geral: TAP cancela voos no dia 11 de dezembro](https://aviacao.tv/wp-content/uploads/2025/11/Screenshot-2025-11-29-at-13.16.54.png) <small>aviacao.tv</small>Greve Geral: TAP cancela voos no dia 11 de dezembro

Greve Geral A 11 De Dezembro | Sindicato Dos Quadros Técnicos Do Estado
-----------------------------------------------------------------------

 ![Greve Geral a 11 de Dezembro | Sindicato dos Quadros Técnicos do Estado](https://www.ste.pt/wp-content/uploads/2025/12/GreveGeral-Cartaz-scaled.jpg) <small>www.ste.pt</small>Greve Geral a 11 de Dezembro | Sindicato dos Quadros Técnicos do Estado

Adere à Greve Geral Dia 11 De Dezembro
--------------------------------------

 ![Adere à Greve Geral dia 11 de dezembro](https://www.sep.org.pt/files/uploads/2025/11/SEP_GREVEGERAL_WEB_1-800x350.jpg) <small>www.sep.org.pt</small>Adere à Greve Geral dia 11 de dezembro

GREVE GERAL DIA 11 DEZEMBRO DE 2025 | FESAHT
--------------------------------------------

 ![GREVE GERAL DIA 11 DEZEMBRO DE 2025 | FESAHT](https://sindicatos.cgtp.pt/fesaht/wp-content/blogs.dir/52/files/sites/52/2025/12/11-DEZ-faz-greve-e-sai-a-Rua.jpg) <small>sindicatos.cgtp.pt</small>GREVE GERAL DIA 11 DEZEMBRO DE 2025 | FESAHT

GREVE GERAL DE 11 DE DEZEMBRO DE 2025 – MANIFESTAÇÕES – LISBOA (VÍDEO) – EPHEMERA – Biblioteca E
------------------------------------------------------------------------------------------------

 ![GREVE GERAL DE 11 DE DEZEMBRO DE 2025 – MANIFESTAÇÕES – LISBOA (VÍDEO) – EPHEMERA – Biblioteca e](https://ephemerajpp.com/wp-content/uploads/2025/12/IMG_2182.jpg) <small>ephemerajpp.com</small>GREVE GERAL DE 11 DE DEZEMBRO DE 2025 – MANIFESTAÇÕES – LISBOA (VÍDEO) – EPHEMERA – Biblioteca e ...

Mapa QZP Carenciados De 2025/26 – Despacho N.º 11200-A/2025 – Apoio à Deslocação – Sindicato S.TO.P.
----------------------------------------------------------------------------------------------------

 ![Mapa QZP carenciados de 2025/26 – Despacho n.º 11200-A/2025 – Apoio à deslocação – Sindicato S.TO.P.](https://stop-sindicato.pt/wp-content/uploads/2025/11/S.TO_.P.-Cartaz-Greve-Geral-Educacao-11Dez2025_x1000-768x1086.png) <small>stop-sindicato.pt</small>Mapa QZP carenciados de 2025/26 – Despacho n.º 11200-A/2025 – Apoio à deslocação – Sindicato S.TO.P.

Mais De 50 Sindicatos Aderem à Greve Geral Marcada Para 11 De Dezembro - SIC Notícias
-------------------------------------------------------------------------------------

 ![Mais de 50 sindicatos aderem à greve geral marcada para 11 de dezembro - SIC Notícias](https://images.impresa.pt/sicnot/2025-11-17-cgtp-pre-aviso-greve-82e19fc3-1/16x9/mw-1200) <small>sicnoticias.pt</small>Mais de 50 sindicatos aderem à greve geral marcada para 11 de dezembro - SIC Notícias

Category:General Strike 11 December 2025 (Portugal) - Wikimedia Commons
-----------------------------------------------------------------------

 ![Category:General strike 11 December 2025 (Portugal) - Wikimedia Commons](https://upload.wikimedia.org/wikipedia/commons/thumb/d/d1/Convocatórias_nas_ruas_sobre_a_Greve_Geral_de_7_de_dezembro_2025%2C_em_Portugal_07.jpg/960px-Convocatórias_nas_ruas_sobre_a_Greve_Geral_de_7_de_dezembro_2025%2C_em_Portugal_07.jpg) <small>commons.wikimedia.org</small>Category:General strike 11 December 2025 (Portugal) - Wikimedia Commons

Greve Geral – 24 Horas – Dia 11 De Dezembro De 2025 – SINTTAV Sindicato Nacional Dos
------------------------------------------------------------------------------------

 ![Greve Geral – 24 Horas – Dia 11 de Dezembro de 2025 – SINTTAV Sindicato Nacional dos](https://sinttav.pt/wp-content/uploads/2025/11/pag-1.jpg) <small>sinttav.pt</small>Greve Geral – 24 Horas – Dia 11 de Dezembro de 2025 – SINTTAV Sindicato Nacional dos ...

A Plataforma Já Marchavas Apoia A Greve Geral De 11 De Dezembro – Já Marchavas
------------------------------------------------------------------------------

 ![A Plataforma Já Marchavas apoia a Greve Geral de 11 de Dezembro – Já Marchavas](https://jamarchavas.pt/wp-content/uploads/2025/12/greve-geral-2025-1.jpg) <small>jamarchavas.pt</small>A Plataforma Já Marchavas apoia a Greve Geral de 11 de Dezembro – Já Marchavas

A greve geral de 11 de dezembro em 38 imagens – observador. A greve geral de 11 de dezembro em 38 imagens – observador. Sdp sul
