---
title: "Greve Geral 2026 2 De Outubro - Níveis de adesão à greve parcial de 26 de outubro"
description: "greve geral portuguesa de 2025 – wikipédia, a enciclopédia livre"
date: "2026-05-17"
categories:
- "Uncategorized"
images:
- "https://s2-oglobo.glbimg.com/CvxQoWQZKKpvDH4J2cFUaiQmndA=/7495x0/filters:format(jpeg)/https://i.s3.glbimg.com/v1/AUTH_da025474c0c44edd99332dddb09cabe8/internal_photos/bs/2026/7/Y/lvi32BSLCS92LGu03jAg/115141022-people-take-part-in-a-demonstration-in-lisbon-on-july-3-2026-called-by-the-main-unions-due.jpg"
featuredImage: "https://s2-oglobo.glbimg.com/V7Y8UJwANx11oJDI3S06BJ3H-IY=/1600x0/smart/filters:strip_icc()/i.s3.glbimg.com/v1/AUTH_da025474c0c44edd99332dddb09cabe8/internal_photos/bs/2024/7/b/SCOa79QxybJ0mnPp3zDg/afp-20240124-34gp483-v1-highres-argentinapoliticseconomynationalstrike.jpg"
featured_image: "https://staticx.noticiasilimitadas.pt/tsf/image.webp?brand=tsf&amp;type=generate&amp;guid=f2fd45e3-0eb3-424b-9e51-c41a22a41e1a&amp;w=3840"
image: "https://s2-oglobo.glbimg.com/V7Y8UJwANx11oJDI3S06BJ3H-IY=/1600x0/smart/filters:strip_icc()/i.s3.glbimg.com/v1/AUTH_da025474c0c44edd99332dddb09cabe8/internal_photos/bs/2024/7/b/SCOa79QxybJ0mnPp3zDg/afp-20240124-34gp483-v1-highres-argentinapoliticseconomynationalstrike.jpg"
---

If you are searching about Balanço da Greve Geral - CGTP-IN you've came to the right place. We have 35 Pics about Balanço da Greve Geral - CGTP-IN like Greve geral em Portugal cancela voos e afeta serviços essenciais: sindicatos protestam contra, Pré-Aviso de Greve – 17 de abril de 2026 – Página 2 – AE António Correia de Oliveira and also Greve geral em Portugal cancela voos e afeta serviços essenciais: sindicatos protestam contra. Here it is:

Balanço Da Greve Geral - CGTP-IN
--------------------------------

 ![Balanço da Greve Geral - CGTP-IN](https://www.cgtp.pt/images/images/2025/11/gg_banner2025.jpg) <small>www.cgtp.pt</small>Balanço da Greve Geral - CGTP-IN

Greve Geral Histórica Em Portugal Paralisa Transportes, Fecha Escolas E Pressiona Hospitais
-------------------------------------------------------------------------------------------

 ![Greve geral histórica em Portugal paralisa transportes, fecha escolas e pressiona hospitais](https://p2.trrsf.com/image/fget/cf/1200/630/middle/images.terra.com/2025/12/11/greve-ubj4bs8ccokh.png) <small>www.terra.com.br</small>Greve geral histórica em Portugal paralisa transportes, fecha escolas e pressiona hospitais

Aviso | Greves Em Junho De 2026 – AE António Correia De Oliveira
----------------------------------------------------------------

 ![Aviso | Greves em junho de 2026 – AE António Correia de Oliveira](https://www.acoliveira.pt/wp-content/uploads/2026/05/ChatGPT-Image-31_05_2026-22_43_43.png) <small>www.acoliveira.pt</small>Aviso | Greves em junho de 2026 – AE António Correia de Oliveira

Greve Nacional | 24 De Outubro - SPRA
-------------------------------------

 ![Greve Nacional | 24 de outubro - SPRA](https://www.spra.pt/wp-content/uploads/2025/10/cartaz-24-out-scaled.jpg) <small>www.spra.pt</small>Greve Nacional | 24 de outubro - SPRA

Nacional - FENPROF
------------------

 ![Nacional - FENPROF](https://www.fenprof.pt/media/download/B73B952771368699555DF536CB47A576/grevegeral-3jun26.png?width=800&rxy=0.5) <small>www.fenprof.pt</small>Nacional - FENPROF

27 De Outubro - Greve Nacional Da Administração Pública - CGTP-IN
-----------------------------------------------------------------

 ![27 de Outubro - Greve Nacional da Administração Pública - CGTP-IN](https://www.cgtp.pt/images/images/2017/10/171003_GreveFCcartazB.jpg) <small>www.cgtp.pt</small>27 de Outubro - Greve Nacional da Administração Pública - CGTP-IN

AVISO PRÉVIO DE GREVE GERAL 3 JUNHO 2026 – STTS
-----------------------------------------------

 ![AVISO PRÉVIO DE GREVE GERAL 3 JUNHO 2026 – STTS](https://www.stts.pt/wp-content/uploads/2026/05/123654-1024x871.jpg) <small>www.stts.pt</small>AVISO PRÉVIO DE GREVE GERAL 3 JUNHO 2026 – STTS

AVISO PRÉVIO DE GREVE TRABALHADORES ADMINISTRAÇÃO PÚBLICA 16 DE MAIO 2025 – STTS
--------------------------------------------------------------------------------

 ![AVISO PRÉVIO DE GREVE TRABALHADORES ADMINISTRAÇÃO PÚBLICA 16 DE MAIO 2025 – STTS](https://www.stts.pt/wp-content/uploads/2025/05/CAPA-972x1024.jpg) <small>www.stts.pt</small>AVISO PRÉVIO DE GREVE TRABALHADORES ADMINISTRAÇÃO PÚBLICA 16 DE MAIO 2025 – STTS

Pré-avisos De Greves De 2 E 3 De Março 2023
-------------------------------------------

 ![Pré-avisos de Greves de 2 e 3 de março 2023](https://fne.pt/uploads/rte/cartaz_greve_manif_2e3marco2023.jpeg) <small>fne.pt</small>Pré-avisos de Greves de 2 e 3 de março 2023

Greve Nacional De 2 De Dezembro: Transportes, Escolas, Aeroportos... As Informações
-----------------------------------------------------------------------------------

 ![Greve nacional de 2 de dezembro: transportes, escolas, aeroportos... as informações](https://cdn.sortiraparis.com/images/80/1467/1199124-greve-du-2-octobre-les-manifestations-prevues-a-paris-et-en-ile-de-france.jpg) <small>www.sortiraparis.com</small>Greve nacional de 2 de dezembro: transportes, escolas, aeroportos... as informações ...

O Que Se Sabe Sobre A Greve Dos Caminhoneiros Em 2026?
------------------------------------------------------

 ![O que se sabe sobre a greve dos caminhoneiros em 2026?](https://blog.proteautobrasil.com.br/wp-content/uploads/2026/03/19-03-GREVE.png) <small>blog.proteautobrasil.com.br</small>O que se sabe sobre a greve dos caminhoneiros em 2026?

CGTP Fala De Adesão Massiva à Greve Geral - TSF
-----------------------------------------------

 ![CGTP fala de adesão massiva à greve geral - TSF](https://staticx.noticiasilimitadas.pt/tsf/image.webp?brand=tsf&type=generate&guid=f2fd45e3-0eb3-424b-9e51-c41a22a41e1a&w=3840) <small>www.tsf.pt</small>CGTP fala de adesão massiva à greve geral - TSF

Greve Geral Em Portugal Cancela Voos E Afeta Serviços Essenciais: Sindicatos Protestam Contra
---------------------------------------------------------------------------------------------

 ![Greve geral em Portugal cancela voos e afeta serviços essenciais: sindicatos protestam contra](https://s2-oglobo.glbimg.com/CvxQoWQZKKpvDH4J2cFUaiQmndA=/7495x0/filters:format(jpeg)/https://i.s3.glbimg.com/v1/AUTH_da025474c0c44edd99332dddb09cabe8/internal_photos/bs/2026/7/Y/lvi32BSLCS92LGu03jAg/115141022-people-take-part-in-a-demonstration-in-lisbon-on-july-3-2026-called-by-the-main-unions-due.jpg) <small>oglobo.globo.com</small>Greve geral em Portugal cancela voos e afeta serviços essenciais: sindicatos protestam contra ...

PRÉ- AVISO DE GREVE – 23 E 24 De Outubro – AEC
----------------------------------------------

 ![PRÉ- AVISO DE GREVE – 23 e 24 de outubro – AEC](https://aeceleiros.pt/wp-content/uploads/2025/10/Greve_out2025_v1.png) <small>aeceleiros.pt</small>PRÉ- AVISO DE GREVE – 23 e 24 de outubro – AEC

Greve Geral Juntou Centenas Nos Aliados. Governo Fala Em Adesão "inexpressiva" - JPN
------------------------------------------------------------------------------------

 ![Greve Geral juntou centenas nos Aliados. Governo fala em adesão "inexpressiva" - JPN](https://www.jpn.up.pt/wp-content/uploads/2025/12/greve_geral9.jpg) <small>www.jpn.up.pt</small>Greve Geral juntou centenas nos Aliados. Governo fala em adesão "inexpressiva" - JPN

Pré-Aviso De Greve – 17 De Abril De 2026 – Página 2 – AE António Correia De Oliveira
------------------------------------------------------------------------------------

 ![Pré-Aviso de Greve – 17 de abril de 2026 – Página 2 – AE António Correia de Oliveira](https://www.acoliveira.pt/wp-content/uploads/2026/04/7e9f6ec4-4873-4685-897b-30c62aab02d6.png) <small>www.acoliveira.pt</small>Pré-Aviso de Greve – 17 de abril de 2026 – Página 2 – AE António Correia de Oliveira

GREVE GERAL - 3 JUNHO 2026 | Resolução - CGTP-IN
------------------------------------------------

 ![GREVE GERAL - 3 JUNHO 2026 | Resolução - CGTP-IN](https://www.cgtp.pt/images/images/2026/06/tiago-greve-geral.jpg) <small>www.cgtp.pt</small>GREVE GERAL - 3 JUNHO 2026 | Resolução - CGTP-IN

SINDEP - Greve Geral 11 De Dezembro
-----------------------------------

 ![SINDEP - Greve Geral 11 de dezembro](https://sindep.pt/images/cartaz_GREVE_GERAL_UGT.jpg) <small>sindep.pt</small>SINDEP - Greve Geral 11 de dezembro

AO MINUTO: Greve Geral Para O País. "Forte Adesão" E "impacto Fortíssimo"
-------------------------------------------------------------------------

 ![AO MINUTO: Greve geral para o país. "Forte adesão" e "impacto fortíssimo"](https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA1S86fG.img?w=1920&h=1080&m=4&q=100) <small>www.msn.com</small>AO MINUTO: Greve geral para o país. "Forte adesão" e "impacto fortíssimo"

Dados Recolhidos Até às 19h20 Demonstram Que A Greve Geral Parou O País - CGTP-IN
---------------------------------------------------------------------------------

 ![Dados recolhidos até às 19h20 demonstram que a Greve Geral parou o país - CGTP-IN](https://cgtp.pt/images/images/2026/06/Captura de ecra 2026-06-03 120926.png#joomlaImage:/local-images/images/2026/06/Captura de ecra 2026-06-03 120926.png?width=1162&height=610) <small>www.cgtp.pt</small>Dados recolhidos até às 19h20 demonstram que a Greve Geral parou o país - CGTP-IN

Greve Contra Reforma Trabalhista Em Portugal Paralisa Trens, Reduz Voos E Fecha Escolas | Mundo
-----------------------------------------------------------------------------------------------

 ![Greve contra reforma trabalhista em Portugal paralisa trens, reduz voos e fecha escolas | Mundo](https://s2-valor.glbimg.com/4vR_2uY25dJGMy8ZVvqi2yGFVV0=/0x0:4000x2667/888x0/smart/filters:strip_icc()/i.s3.glbimg.com/v1/AUTH_63b422c2caee4269b8b34177e8876b93/internal_photos/bs/2026/i/K/IRKRylTBC6ihg48Gb0hw/457542349.jpg) <small>valor.globo.com</small>Greve contra reforma trabalhista em Portugal paralisa trens, reduz voos e fecha escolas | Mundo ...

Qual O Valor Do Salário Mínimo Em 2024? Veja O Que Muda E Quando Começa A Valer
-------------------------------------------------------------------------------

 ![Qual o valor do salário mínimo em 2024? Veja o que muda e quando começa a valer](https://s2-oglobo.glbimg.com/V7Y8UJwANx11oJDI3S06BJ3H-IY=/1600x0/smart/filters:strip_icc()/i.s3.glbimg.com/v1/AUTH_da025474c0c44edd99332dddb09cabe8/internal_photos/bs/2024/7/b/SCOa79QxybJ0mnPp3zDg/afp-20240124-34gp483-v1-highres-argentinapoliticseconomynationalstrike.jpg) <small>oglobo.globo.com</small>Qual o valor do salário mínimo em 2024? Veja o que muda e quando começa a valer

Motivos Da Adesão à Greve Geral De 11 De Dezembro De 2025
---------------------------------------------------------

 ![Motivos da adesão à Greve Geral de 11 de dezembro de 2025](https://fne.pt/uploads/noticias/big_1763657174_7468_SiteGREVE11dez25.jpeg) <small>fne.pt</small>Motivos da adesão à Greve Geral de 11 de dezembro de 2025

Acesse Já O Boletim Da Greve #2! – Assufrgs
-------------------------------------------

 ![Acesse já o Boletim da Greve #2! – Assufrgs](https://www.assufrgs.org.br/wp-content/uploads/2026/04/Capa-site-3.0-1.png) <small>www.assufrgs.org.br</small>Acesse já o Boletim da Greve #2! – Assufrgs

OE2026 "dá Mais Força" à Greve Geral Da Frente Comum Dia 24 – Observador
------------------------------------------------------------------------

 ![OE2026 "dá mais força" à greve geral da Frente Comum dia 24 – Observador](https://wm.observador.pt/wm/l/https://bordalo.observador.pt/v2/rs:fill:770:403/c:2000:1124:nowe:0:105/q:70/f:webp/plain/https://s3.observador.pt/wp-content/uploads/2025/07/17130847/45338055.jpg?layer=obstop:T) <small>observador.pt</small>OE2026 "dá mais força" à greve geral da Frente Comum dia 24 – Observador

Greve Geral - CGTP-IN
---------------------

 ![Greve Geral - CGTP-IN](https://cgtp.pt/images/images/2026/06/Captura de ecra 2026-06-03 081313.png#joomlaImage:/local-images/images/2026/06/Captura de ecra 2026-06-03 081313.png?width=1099&height=554) <small>www.cgtp.pt</small>Greve Geral - CGTP-IN

Greve 2026 – SinTUFABC
----------------------

 ![Greve 2026 – SinTUFABC](https://sintufabc.org.br/wp/wp-content/uploads/2026/03/Template-para-feed-3.png) <small>sintufabc.org.br</small>Greve 2026 – SinTUFABC

Greve Geral Juntou Centenas Nos Aliados. Governo Fala Em Adesão "inexpressiva" - JPN
------------------------------------------------------------------------------------

 ![Greve Geral juntou centenas nos Aliados. Governo fala em adesão "inexpressiva" - JPN](https://www.jpn.up.pt/wp-content/uploads/2025/12/greve_geral8.jpg) <small>www.jpn.up.pt</small>Greve Geral juntou centenas nos Aliados. Governo fala em adesão "inexpressiva" - JPN

Greve Geral Fecha Dezenas De Escolas Na Região
----------------------------------------------

 ![Greve geral fecha dezenas de escolas na região](https://www.diarioviseu.pt/wp-content/uploads/sites/8/2025/12/Greve-geral2-e1765832007744.webp) <small>www.diarioviseu.pt</small>Greve geral fecha dezenas de escolas na região

FENPROF Emite Pré-aviso De Greve Para 27 De Outubro De 2023 E Junta-se Ao Protesto Dos
--------------------------------------------------------------------------------------

 ![FENPROF emite pré-aviso de greve para 27 de outubro de 2023 e junta-se ao protesto dos](https://www.spra.pt/wp-content/uploads/2023/10/cartaz-greve-fc-27-outubro-net-1-704x1024.jpg) <small>www.spra.pt</small>FENPROF emite pré-aviso de greve para 27 de outubro de 2023 e junta-se ao protesto dos ...

Greve Geral Portuguesa De 2025 – Wikipédia, A Enciclopédia Livre
----------------------------------------------------------------

 ![Greve geral portuguesa de 2025 – Wikipédia, a enciclopédia livre](https://upload.wikimedia.org/wikipedia/commons/thumb/9/9c/Manifestação_Greve_Geral%2C_Lisboa%2C_Dez._2025_(54977121422).jpg/1280px-Manifestação_Greve_Geral%2C_Lisboa%2C_Dez._2025_(54977121422).jpg) <small>pt.wikipedia.org</small>Greve geral portuguesa de 2025 – Wikipédia, a enciclopédia livre

Nacional - FENPROF
------------------

 ![Nacional - FENPROF](https://www.fenprof.pt/media/download/FA35D84EB902AC7A6FFE8691F2CE04D8/2026_05_16-manifestacao-ecd-2.jpeg?width=800&rxy=0.5) <small>www.fenprof.pt</small>Nacional - FENPROF

Níveis De Adesão à Greve Parcial De 26 De Outubro - Metropolitano De Lisboa
---------------------------------------------------------------------------

 ![Níveis de adesão à greve parcial de 26 de outubro - Metropolitano de Lisboa](https://www.metrolisboa.pt/institucional/wp-content/uploads/sites/2/2021/10/greve-26.10-adesao-img-comunicado.png) <small>www.metrolisboa.pt</small>Níveis de adesão à greve parcial de 26 de outubro - Metropolitano de Lisboa

GREVE GERAL - 3 JUNHO 2026 | Resolução - CGTP-IN
------------------------------------------------

 ![GREVE GERAL - 3 JUNHO 2026 | Resolução - CGTP-IN](https://www.cgtp.pt/images/images/2026/06/resolucao_grevegeral.jpg) <small>www.cgtp.pt</small>GREVE GERAL - 3 JUNHO 2026 | Resolução - CGTP-IN

Metro Do Porto "fortemente Condicionado" No Dia Da Greve Geral - JPN
--------------------------------------------------------------------

 ![Metro do Porto "fortemente condicionado" no dia da greve geral - JPN](https://www.jpn.up.pt/wp-content/uploads/2025/12/greve_geral1-1152x759.jpg) <small>www.jpn.up.pt</small>Metro do Porto "fortemente condicionado" no dia da greve geral - JPN

Motivos da adesão à greve geral de 11 de dezembro de 2025. greve geral juntou centenas nos aliados. governo fala em adesão "inexpressiva". Acesse já o boletim da greve #2! – assufrgs
