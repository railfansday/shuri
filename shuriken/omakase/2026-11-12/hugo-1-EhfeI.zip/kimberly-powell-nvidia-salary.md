---
title: "Kimberly Powell Nvidia Salary - kimberly powell, the engineer who became nvidia&#039;s healthcare vp and is now caught in the jensen ..."
description: "Who is kimberly powell? and why nvidia pays the ceo&#039;s kids $1m+"
date: "2026-01-16"
categories:
- "Uncategorized"
images:
- "https://celebsfortune.com/wp-content/uploads/2026/11/kimberly-powell-nvidia-salary-and-net-worth-2026.jpg"
featuredImage: "https://img.etimg.com/thumb/msid-135754452,width-950,height-600,imgsize-130156,resizemode-75/jensen-huangs-former-partner-kimberly-powell-walks-the-show-floor-in-nvidia-videobr.jpg"
featured_image: "https://jaisalmernews.com/wp-content/uploads/2026/11/kimberly-powell-biography-cover.webp"
image: "https://ocdn.eu/pulscms-transforms/1/i3dktkuTURBXy9kMWIzYzQ0Mi03YzY1LTQ0NTQtYWNjOC0wYjNlNjRmMTVjZmMuanBlZ5GTBc0DFs0Brg"
---

If you are searching about Chip giant Nvidia wants to bring robots to the hospital | Business Insider Africa you've came to the right page. We have 35 Images about Chip giant Nvidia wants to bring robots to the hospital | Business Insider Africa like Kimberly Powell's Net Worth (2026) &amp; NVIDIA Salary Revealed, Kimberly Powell (Nvidia) Wiki, Age, Husband &amp; Salary and also nvidia shares fall india: Latest News &amp; Videos, Photos about nvidia shares fall india | The. Read more:

Chip Giant Nvidia Wants To Bring Robots To The Hospital | Business Insider Africa
---------------------------------------------------------------------------------

 ![Chip giant Nvidia wants to bring robots to the hospital | Business Insider Africa](https://ocdn.eu/pulscms-transforms/1/i3dktkuTURBXy9kMWIzYzQ0Mi03YzY1LTQ0NTQtYWNjOC0wYjNlNjRmMTVjZmMuanBlZ5GTBc0DFs0Brg) <small>africa.businessinsider.com</small>Chip giant Nvidia wants to bring robots to the hospital | Business Insider Africa

Kimberly Powell: How Married Nvidia Healthcare VP Rose Through...
-----------------------------------------------------------------

 ![Kimberly Powell: How Married Nvidia Healthcare VP Rose Through...](https://data.ibtimes.sg/en/full/99508/kimberly-powell.jpg?w=736) <small>www.ibtimes.sg</small>Kimberly Powell: How Married Nvidia Healthcare VP Rose Through...

Who Is Kimberly Powell? Nvidia VP's Alleged Affair Amid Jensen Huang-Alice Huang Controversy
--------------------------------------------------------------------------------------------

 ![Who Is Kimberly Powell? Nvidia VP's Alleged Affair Amid Jensen Huang-Alice Huang Controversy](https://static.asianetnews.com/images/w-1280,h-720,format-jpg,imgid-01m76q64m4zjevjbkbpgq9dheh,imgname-kimberly-powell-who-is-she-jensen-huang-affair-controversy-nvidia-0-1794448233091.jpg) <small>newsable.asianetnews.com</small>Who Is Kimberly Powell? Nvidia VP's Alleged Affair Amid Jensen Huang-Alice Huang Controversy ...

Who Is Kimberly Powell? And Why Nvidia Pays The CEO's Kids $1M+ - YouTube
-------------------------------------------------------------------------

 ![Who Is Kimberly Powell? And Why Nvidia Pays the CEO's Kids $1M+ - YouTube](https://i.ytimg.com/vi/WGH6rP5q7Qs/maxresdefault.jpg) <small>www.youtube.com</small>Who Is Kimberly Powell? And Why Nvidia Pays the CEO's Kids $1M+ - YouTube

Who Is Kimberly Powell, The Nvidia Executive Linked To CEO Jensen Huang? | Republic World
-----------------------------------------------------------------------------------------

 ![Who Is Kimberly Powell, the Nvidia Executive Linked to CEO Jensen Huang? | Republic World](https://img.republicworld.com/all_images/2026/11/who-is-kimberly-powell-the-nvidia-executive-linked-to-ceo-jensen-huang-1794455712889-1280x720.webp?w=1280&h=720&q=75&format=webp) <small>www.republicworld.com</small>Who Is Kimberly Powell, the Nvidia Executive Linked to CEO Jensen Huang? | Republic World

L Vs Target Consumption: Latest News &amp; Videos, Photos About L Vs Target Consumption | The
---------------------------------------------------------------------------------------------

 ![l vs target consumption: Latest News & Videos, Photos about l vs target consumption | The](https://img.etimg.com/thumb/msid-135752104,width-100,height-75,resizemode-4/world/us/meet-kimberly-powell-what-to-know-about-the-nvidia-executive-and-her-reported-ties-to-jensen-huang.jpg) <small>economictimes.indiatimes.com</small>l vs target consumption: Latest News &amp; Videos, Photos about l vs target consumption | The ...

Asean's Non-interference Policy Hampers Joint Action On Forced Migration, Says Rights Body
------------------------------------------------------------------------------------------

 ![Asean's non-interference policy hampers joint action on forced migration, says rights body](https://i0.wp.com/asianewshub.com/wp-content/uploads/2026/11/kimberly-powell-nvidia.jpg?resize=825%2C575&quality=89&ssl=1) <small>asianewshub.com</small>Asean's non-interference policy hampers joint action on forced migration, says rights body

Who Is Kimberly Powell? Meet The Nvidia Executive Named In Jensen Huang Affair Report
-------------------------------------------------------------------------------------

 ![Who is Kimberly Powell? Meet the Nvidia executive named in Jensen Huang affair report](https://news24online.com/wp-content/uploads/2026/11/Kimberly-Powell.jpg) <small>news24online.com</small>Who is Kimberly Powell? Meet the Nvidia executive named in Jensen Huang affair report

Kimberly Powell Biography: Age, Nvidia Healthcare Career And The Jensen Huang Report – The
------------------------------------------------------------------------------------------

 ![Kimberly Powell Biography: Age, Nvidia Healthcare Career and the Jensen Huang Report – The](https://jaisalmernews.com/wp-content/uploads/2026/11/kimberly-powell-biography-cover.webp) <small>jaisalmernews.com</small>Kimberly Powell Biography: Age, Nvidia Healthcare Career and the Jensen Huang Report – The ...

Nvidia CEO’s Scandal Deepens As New Report Claims He…
-----------------------------------------------------

 ![Nvidia CEO’s Scandal Deepens As New Report Claims He…](https://static.boredpanda.com/blog/wp-content/uploads/2026/11/06-6af4fc1ce3d6f__700.jpg) <small>www.inkl.com</small>Nvidia CEO’s Scandal Deepens As New Report Claims He…

Watch: Jensen Huang’s Reported Extramarital Partner Kimberly Powell Walks The Show Floor In
-------------------------------------------------------------------------------------------

 ![Watch: Jensen Huang’s reported extramarital partner Kimberly Powell walks the show floor in](https://img.etimg.com/thumb/msid-135754452,width-950,height-600,imgsize-130156,resizemode-75/jensen-huangs-former-partner-kimberly-powell-walks-the-show-floor-in-nvidia-videobr.jpg) <small>economictimes.indiatimes.com</small>Watch: Jensen Huang’s reported extramarital partner Kimberly Powell walks the show floor in ...

Who Is Nvidia Executive Kimberly Powell?
----------------------------------------

 ![Who is Nvidia executive Kimberly Powell?](https://s.yimg.com/lo/mysterio/api/c58baa14f593e47f688278dcb4da5e984c223a30f1c349f4beb6089d8dd61a36/lightyear_networkapi/resizefill_w1200%3Bquality_80%3Bformat_webp/https://d29szjachogqwa.cloudfront.net/images/user-uploaded/1070a53c-f6f7-4f75-a138-a807f870fc8c_1b11a1432935558595099303c1bb4ff595485c4e06dacdf78afa24a4aa4d9961.jpg) <small>finance.yahoo.com</small>Who is Nvidia executive Kimberly Powell?

Kimberly Powell Nvidia: Summit Exit After Huang Report
------------------------------------------------------

 ![Kimberly Powell Nvidia: Summit Exit After Huang Report](https://bitcoinfoundation.org/wp-content/uploads/2026/11/kimberly-powell-cancels-health-summit-appearance-after-nvidia-ceo-relationship-r.webp) <small>bitcoinfoundation.org</small>Kimberly Powell Nvidia: Summit Exit After Huang Report

Nvidia's Kimberly Powell Is Leading The Chip Giant's Charge Into AI For Health Care - Bizwomen
----------------------------------------------------------------------------------------------

 ![Nvidia's Kimberly Powell is leading the chip giant's charge into AI for health care - Bizwomen](https://media.bizj.us/view/img/12968502/kimberlypowell-1*800xx9428-5303-0-491.jpg) <small>www.bizjournals.com</small>Nvidia's Kimberly Powell is leading the chip giant's charge into AI for health care - Bizwomen

Who's Hotter? Alice Huang Or Kimberly Powell? | Tech Industry - Blind
---------------------------------------------------------------------

 ![Who's Hotter? Alice Huang or Kimberly Powell? | Tech Industry - Blind](https://nypost.com/wp-content/uploads/sites/2/2026/09/comp-202921C79-B67F-46EE-829F-200091B8A009.jpg?quality=75&strip=all&w=1200) <small>www.teamblind.com</small>Who's Hotter? Alice Huang or Kimberly Powell? | Tech Industry - Blind

Kimberly Powell's Net Worth (2026) &amp; NVIDIA Salary Revealed
---------------------------------------------------------------

 ![Kimberly Powell's Net Worth (2026) & NVIDIA Salary Revealed](https://celebsfortune.com/wp-content/uploads/2026/11/kimberly-powell-picture.jpg) <small>celebsfortune.com</small>Kimberly Powell's Net Worth (2026) &amp; NVIDIA Salary Revealed

Kimberly Powell Nvidia Career: Before Nvidia, Kimberly Powell Was An Engineering Intern In
------------------------------------------------------------------------------------------

 ![Kimberly Powell Nvidia career: Before Nvidia, Kimberly Powell was an engineering intern in](https://img.etimg.com/thumb/msid-135774638,width-1200,height-900,imgsize-152718,overlay-economictimes/articleshow.jpg) <small>economictimes.indiatimes.com</small>Kimberly Powell Nvidia career: Before Nvidia, Kimberly Powell was an engineering intern in ...

Who Is Kimberly Powell? Nvidia Executive Who Had Affair With CEO Jensen Huang
-----------------------------------------------------------------------------

 ![Who Is Kimberly Powell? Nvidia Executive Who Had Affair With CEO Jensen Huang](https://c.ndtvimg.com/2026-11/atbds6hc_kimberly-powell_625x300_12_November_26.jpeg?im=FaceCrop,algorithm=dnn,width=1600,height=900) <small>www.ndtv.com</small>Who Is Kimberly Powell? Nvidia Executive Who Had Affair With CEO Jensen Huang

Jensen Huang Annual Salary: Latest News &amp; Videos, Photos About Jensen Huang Annual Salary | The
---------------------------------------------------------------------------------------------------

 ![jensen huang annual salary: Latest News & Videos, Photos about jensen huang annual salary | The](https://img.etimg.com/thumb/msid-135769516,width-100,height-75,resizemode-4/news/international/us/sunday-confidence-in-jensen-wednesday-preparing-to-oust-him-how-one-report-flipped-nvidias-board.jpg) <small>economictimes.indiatimes.com</small>jensen huang annual salary: Latest News &amp; Videos, Photos about jensen huang annual salary | The ...

NVIDIA VP Kimberly Powell Announced Resignation Or Remova... 2026 | Polymarket
------------------------------------------------------------------------------

 ![NVIDIA VP Kimberly Powell announced resignation or remova... 2026 | Polymarket](https://polymarket.com/api/og?eslug=nvidia-vp-kimberly-powell-announced-resignation-or-removal-byptptpt&tid=1794501219461) <small>polymarket.com</small>NVIDIA VP Kimberly Powell announced resignation or remova... 2026 | Polymarket

Who Is Kimberly Powell? What To Know About The Nvidia Executive – Hollywood Life
--------------------------------------------------------------------------------

 ![Who Is Kimberly Powell? What to Know About the Nvidia Executive – Hollywood Life](https://i0.wp.com/media.hollywoodlife.com/uploads/2026/11/jensen-1920x1920-1-e1794491821965.jpeg?resize=1200%2C675&quality=100&ssl=1) <small>hollywoodlife.com</small>Who Is Kimberly Powell? What to Know About the Nvidia Executive – Hollywood Life

Kimberly Powell's 18-Year Journey At Nvidia Draws Attention After Personal Links With CEO Jensen
------------------------------------------------------------------------------------------------

 ![Kimberly Powell's 18-Year Journey At Nvidia Draws Attention After Personal Links With CEO Jensen](https://images.thedailyjagran.com/images/2026/11/12/template/image/Kimberlypowell-1794456712201.webp) <small>www.thedailyjagran.com</small>Kimberly Powell's 18-Year Journey At Nvidia Draws Attention After Personal Links With CEO Jensen ...

Kimberly Powell-Jensen Huang Alleged Affair: What Nvidia's Cod...
-----------------------------------------------------------------

 ![Kimberly Powell-Jensen Huang Alleged Affair: What Nvidia's Cod...](https://data.ibtimes.sg/en/full/99518/kimberly-powell.jpg?w=736) <small>www.ibtimes.sg</small>Kimberly Powell-Jensen Huang Alleged Affair: What Nvidia's Cod...

Who Is Kimberly Powell, The Powerful Executive At Nvidia?
---------------------------------------------------------

 ![Who is Kimberly Powell, the powerful executive at Nvidia?](https://voz.us/fotos-seo/31569/16x9.jpg?v=15288027-4843-3228-50-50-AFP__20261110__D6YZ8CQ__v1__HighRes__FilesTaiwanChinaUsSemiconductorsAiNvidia-wbom8g.jpg) <small>voz.us</small>Who is Kimberly Powell, the powerful executive at Nvidia?

Who Is Kimberly Powell, Nvidia VP Linked To Huang's Second Alleged Affair? - En.tempo.co
----------------------------------------------------------------------------------------

 ![Who Is Kimberly Powell, Nvidia VP Linked to Huang's Second Alleged Affair? - En.tempo.co](https://statik.tempo.co/data/2026/11/12/id_1494184/1494184_720.jpg) <small>en.tempo.co</small>Who Is Kimberly Powell, Nvidia VP Linked to Huang's Second Alleged Affair? - En.tempo.co

Kimberly Powell, The Engineer Who Became Nvidia's Healthcare VP And Is Now Caught In The Jensen
-----------------------------------------------------------------------------------------------

 ![Kimberly Powell, the engineer who became Nvidia's healthcare VP and is now caught in the Jensen](https://www.asiaone.com/sites/default/files/styles/article_top_image/public/original_images/Nov2026/kimberly-powell-nvidia-facebook (1).jpg?itok=hIIek7fk) <small>www.asiaone.com</small>Kimberly Powell, the engineer who became Nvidia's healthcare VP and is now caught in the Jensen ...

Kimberly Powell (Nvidia) Wiki, Age, Husband &amp; Salary
--------------------------------------------------------

 ![Kimberly Powell (Nvidia) Wiki, Age, Husband & Salary](https://wikiofcelebrities.com/wp-content/uploads/2026/11/Kimberly-Powell.webp) <small>wikiofcelebrities.com</small>Kimberly Powell (Nvidia) Wiki, Age, Husband &amp; Salary

Who Is Kimberly Powell? Meet Nvidia Executive Linked To CEO Jensen Huang In Second Alleged
------------------------------------------------------------------------------------------

 ![Who Is Kimberly Powell? Meet Nvidia Executive Linked To CEO Jensen Huang In Second Alleged](https://images.etnownews.com/thumb/msid-156497895,thumbsize-134748,width-1280,height-720,resizemode-75/156497895.jpg) <small>www.etnownews.com</small>Who Is Kimberly Powell? Meet Nvidia Executive Linked To CEO Jensen Huang In Second Alleged ...

Nvidia: In 2008, She Joined Nvidia; 8 Years Later, She Was Promoted To Senior Director Of AI
--------------------------------------------------------------------------------------------

 ![Nvidia: In 2008, she joined Nvidia; 8 years later, she was promoted to senior director of AI](https://static.toiimg.com/thumb/msid-135757383,imgsize-202801,width-400,height-225,resizemode-4/kimberly-powell.jpg) <small>timesofindia.indiatimes.com</small>Nvidia: In 2008, she joined Nvidia; 8 years later, she was promoted to senior director of AI ...

Jensen Huang Stock Holdings: Latest News &amp; Videos, Photos About Jensen Huang Stock Holdings
-----------------------------------------------------------------------------------------------

 ![jensen huang stock holdings: Latest News & Videos, Photos about jensen huang stock holdings](https://img.etimg.com/thumb/msid-135769770,width-100,height-75,resizemode-4/news/international/world-news/151-billion-fortune-36-million-salary-how-jensen-huang-makes-his-money-at-nvidia.jpg) <small>economictimes.indiatimes.com</small>jensen huang stock holdings: Latest News &amp; Videos, Photos about jensen huang stock holdings ...

Kimberly Powell's Net Worth (2026) &amp; NVIDIA Salary Revealed
---------------------------------------------------------------

 ![Kimberly Powell's Net Worth (2026) & NVIDIA Salary Revealed](https://celebsfortune.com/wp-content/uploads/2026/11/kimberly-powell-nvidia-salary-and-net-worth-2026.jpg) <small>celebsfortune.com</small>Kimberly Powell's Net Worth (2026) &amp; NVIDIA Salary Revealed

Who Is Kimberly Powell, Nvidia Executive Who Had Affair With CEO Jensen Huang?
------------------------------------------------------------------------------

 ![Who Is Kimberly Powell, Nvidia Executive Who Had Affair With CEO Jensen Huang?](https://c.ndtvimg.com/2026-11/9ks3vb1s_kimberly-powell_625x300_12_November_26.jpeg?downsize=723:486) <small>www.ndtv.com</small>Who Is Kimberly Powell, Nvidia Executive Who Had Affair With CEO Jensen Huang?

Who Is Kimberly Powell? Nvidia Healthcare VP Named In…
------------------------------------------------------

 ![Who Is Kimberly Powell? Nvidia Healthcare VP Named in…](https://images.inkl.com/s3/article/lead_image/24052916/kimberly-powell.png) <small>www.inkl.com</small>Who Is Kimberly Powell? Nvidia Healthcare VP Named in…

Who Is Kimberly Powell, Nvidia Executive Who Had Affair With CEO Jensen Huang?
------------------------------------------------------------------------------

 ![Who Is Kimberly Powell, Nvidia Executive Who Had Affair With CEO Jensen Huang?](https://c.ndtvimg.com/2026-11/9ks3vb1s_kimberly-powell_625x300_12_November_26.jpeg?downsize=773:435) <small>www.ndtv.com</small>Who Is Kimberly Powell, Nvidia Executive Who Had Affair With CEO Jensen Huang?

Nvidia Shares Fall India: Latest News &amp; Videos, Photos About Nvidia Shares Fall India | The
-----------------------------------------------------------------------------------------------

 ![nvidia shares fall india: Latest News & Videos, Photos about nvidia shares fall india | The](https://img.etimg.com/thumb/msid-135768885,width-100,height-75,resizemode-4/news/international/us/nvidia-ceo-crisis-who-is-jay-puri-longtime-nvidia-vp-in-focus-as-jensen-huang-faces-scrutiny-over-alleged-affairs-with-alice-huang-and-kimberly-powell.jpg) <small>economictimes.indiatimes.com</small>nvidia shares fall india: Latest News &amp; Videos, Photos about nvidia shares fall india | The ...

Nvidia's kimberly powell is leading the chip giant's charge into ai for health care. Who is kimberly powell? meet the nvidia executive named in jensen huang affair report. kimberly powell nvidia career: before nvidia, kimberly powell was an engineering intern in ...
