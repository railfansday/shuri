---
title: "Greve Geral 11 Dezembro Porto - S.to.p. junta-se à greve geral de 11 de dezembro com pré-aviso de greve para a educação ..."
description: "S.to.p. junta-se à greve geral de 11 de dezembro com pré-aviso de greve para a educação ..."
date: "2026-06-24"
categories:
- "Uncategorized"
images:
- "https://stop-sindicato.pt/wp-content/uploads/2025/11/S.TO_.P.-Cartaz-Greve-Geral-Educacao-11Dez2025_x1000-724x1024.png"
featuredImage: "https://images.rr.pt/geve-geral-de-11-de-dezembro-de-2025-na-assembleia-da-republica-foto-ricardo-fortunato-rr-31311c45c_socialshare.jpg"
featured_image: "https://sabiasque.pt/images/stories/2025/trabalho/20251209-greve-geral-11-dezembro-320x480.jpg"
image: "https://i.headtopics.com/images/2025/12/6/publico/greve-geral-o-que-e-quem-abrange-e-como-funciona-greve-geral-o-que-e-quem-abrange-e-como-funciona-43970BF408A401F542300934033BEA05.webp?w=640"
---

If you are searching about Category:General strike 11 December 2025 (Portugal) - Wikimedia Commons you've came to the right place. We have 35 Pics about Category:General strike 11 December 2025 (Portugal) - Wikimedia Commons like Greve geral paralisa transportes, saúde e educação no Porto - Expresso, Sindicato apela aos jornalistas que participem na greve contra o pacote laboral and also Motivos da adesão à Greve Geral de 11 de dezembro de 2025. Read more:

Category:General Strike 11 December 2025 (Portugal) - Wikimedia Commons
-----------------------------------------------------------------------

 ![Category:General strike 11 December 2025 (Portugal) - Wikimedia Commons](https://upload.wikimedia.org/wikipedia/commons/thumb/d/d1/Convocatórias_nas_ruas_sobre_a_Greve_Geral_de_7_de_dezembro_2025%2C_em_Portugal_07.jpg/960px-Convocatórias_nas_ruas_sobre_a_Greve_Geral_de_7_de_dezembro_2025%2C_em_Portugal_07.jpg) <small>commons.wikimedia.org</small>Category:General strike 11 December 2025 (Portugal) - Wikimedia Commons

A Greve Geral De 11 De Dezembro Em 38 Imagens – Observador
----------------------------------------------------------

 ![A greve geral de 11 de dezembro em 38 imagens – Observador](https://bordalo.observador.pt/v2/q:60/rs:fill:1440/c:4096:2730:nowe:0:0/plain/https://s3.observador.pt/wp-content/uploads/2025/12/11090822/dventura-greve-geral-11dez-8-scaled.jpg) <small>observador.pt</small>A greve geral de 11 de dezembro em 38 imagens – Observador

Amanhã Há Greve Da Função Pública (escolas Podem Fechar)
--------------------------------------------------------

 ![Amanhã há greve da função pública (escolas podem fechar)](https://jornaldemafra.pt/wp-content/uploads/2025/12/greve-geral.webp) <small>jornaldemafra.pt</small>Amanhã há greve da função pública (escolas podem fechar)

🔴 Ao Minuto: Foi Assim A Greve Geral De 11 De Dezembro De 2025 - Renascença
---------------------------------------------------------------------------

 ![🔴 Ao minuto: Foi assim a greve geral de 11 de dezembro de 2025 - Renascença](https://images.rr.pt/geve-geral-de-11-de-dezembro-de-2025-na-assembleia-da-republica-foto-ricardo-fortunato-rr-31311c45c_socialshare.jpg) <small>rr.pt</small>🔴 Ao minuto: Foi assim a greve geral de 11 de dezembro de 2025 - Renascença

Direitos Nunca Garantidos Devem Empurrar Luta Para A Igualdade. CITE E CIG Elencam Razões - JN
----------------------------------------------------------------------------------------------

 ![Direitos nunca garantidos devem empurrar luta para a igualdade. CITE e CIG elencam razões - JN](https://staticx.noticiasilimitadas.pt/jn/image.webp?brand=jn&type=generate&guid=4c2b91d5-482b-4cca-8b99-149d0449db7d&w=3840) <small>www.jn.pt</small>Direitos nunca garantidos devem empurrar luta para a igualdade. CITE e CIG elencam razões - JN

VISEU - Esclarecimento E Mobilização Para A Greve Geral Marcada Para 11 De Dezembro - CGTP-IN
---------------------------------------------------------------------------------------------

 ![VISEU - Esclarecimento e mobilização para a Greve Geral marcada para 11 de Dezembro - CGTP-IN](https://www.cgtp.pt/images/accao-e-luta/2025/gg.jpg) <small>www.cgtp.pt</small>VISEU - Esclarecimento e mobilização para a Greve Geral marcada para 11 de Dezembro - CGTP-IN

A Greve Geral De 11 De Dezembro Em 38 Imagens – Observador
----------------------------------------------------------

 ![A greve geral de 11 de dezembro em 38 imagens – Observador](https://bordalo.observador.pt/v2/q:60/rs:fill:1440/c:4096:2730:nowe:0:0/plain/https://s3.observador.pt/wp-content/uploads/2025/12/11173414/dventura-greve-geral-11dez-54-scaled.jpg) <small>observador.pt</small>A greve geral de 11 de dezembro em 38 imagens – Observador

Greve Geral – 24 Horas – Dia 11 De Dezembro De 2025 – SINTTAV Sindicato Nacional Dos
------------------------------------------------------------------------------------

 ![Greve Geral – 24 Horas – Dia 11 de Dezembro de 2025 – SINTTAV Sindicato Nacional dos](https://sinttav.pt/wp-content/uploads/2025/11/pag-1.jpg) <small>sinttav.pt</small>Greve Geral – 24 Horas – Dia 11 de Dezembro de 2025 – SINTTAV Sindicato Nacional dos ...

FAQ: Os Direitos Dos Docentes Em Dia De Greve Geral - 11/12/2025
----------------------------------------------------------------

 ![FAQ: Os direitos dos docentes em dia de Greve Geral - 11/12/2025](https://static.wixstatic.com/media/d0f32c_9ff1199ee2c34418af0094a43c516733~mv2.png/v1/fill/w_940,h_788,al_c,q_90,enc_avif,quality_auto/d0f32c_9ff1199ee2c34418af0094a43c516733~mv2.png) <small>www.sprc.pt</small>FAQ: Os direitos dos docentes em dia de Greve Geral - 11/12/2025

Mais De 50 Sindicatos Aderem à Greve Geral Marcada Para 11 De Dezembro - SIC Notícias
-------------------------------------------------------------------------------------

 ![Mais de 50 sindicatos aderem à greve geral marcada para 11 de dezembro - SIC Notícias](https://images.impresa.pt/sicnot/2025-11-17-cgtp-pre-aviso-greve-82e19fc3-1/16x9/mw-1200) <small>sicnoticias.pt</small>Mais de 50 sindicatos aderem à greve geral marcada para 11 de dezembro - SIC Notícias

Após A Greve Geral De 11 De Dezembro Em Portugal - Mpr-nacional
---------------------------------------------------------------

 ![Após a Greve Geral de 11 de dezembro em Portugal - mpr-nacional](https://mpr-nacional.org/wp-content/uploads/2025/12/greve-geral-portugal-11-dezembro-1024x538.webp) <small>mpr-nacional.org</small>Após a Greve Geral de 11 de dezembro em Portugal - mpr-nacional

CGTP Anuncia Greve Geral Para 11 De Dezembro
--------------------------------------------

 ![CGTP anuncia greve geral para 11 de dezembro](https://www.lusa.pt/TEMP/IMAGES/780x1200/CACHE_780X1200_ANALOG_WATERMARKED_45998234_7085120_08112025053627.JPG) <small>www.lusa.pt</small>CGTP anuncia greve geral para 11 de dezembro

Sindicato Apela Aos Jornalistas Que Participem Na Greve Contra O Pacote Laboral
-------------------------------------------------------------------------------

 ![Sindicato apela aos jornalistas que participem na greve contra o pacote laboral](https://staticx.noticiasilimitadas.pt/jn/image.webp?brand=jn&type=generate&guid=fd8bd9f9-1087-408c-93ed-e558c269857d&w=3840) <small>www.jn.pt</small>Sindicato apela aos jornalistas que participem na greve contra o pacote laboral

Transportes, Hospitais, Escolas E Até Bancos. Que Setores Vão Ser Afetados Pela Greve Geral? – ECO
--------------------------------------------------------------------------------------------------

 ![Transportes, hospitais, escolas e até bancos. Que setores vão ser afetados pela greve geral? – ECO](https://ecoonline.s3.amazonaws.com/uploads/2025/12/46141990.jpg) <small>eco.sapo.pt</small>Transportes, hospitais, escolas e até bancos. Que setores vão ser afetados pela greve geral? – ECO

S.TO.P. Junta-se à Greve Geral De 11 De Dezembro Com Pré-aviso De Greve Para A Educação
---------------------------------------------------------------------------------------

 ![S.TO.P. junta-se à greve geral de 11 de dezembro com pré-aviso de greve para a educação](https://stop-sindicato.pt/wp-content/uploads/2025/11/S.TO_.P.-Cartaz-Greve-Geral-Educacao-11Dez2025_x1000-724x1024.png) <small>stop-sindicato.pt</small>S.TO.P. junta-se à greve geral de 11 de dezembro com pré-aviso de greve para a educação ...

Greve Geral — 11 De Dezembro — Contra O Pacote Laboral | Partido Comunista Português
------------------------------------------------------------------------------------

 ![Greve Geral — 11 de Dezembro — Contra o Pacote Laboral | Partido Comunista Português](https://www.pcp.pt/sites/default/files/imagecache/facebook_share/images/dossiers/greve_geral_11_dez_2025/capa.jpg) <small>www.pcp.pt</small>Greve Geral — 11 de Dezembro — Contra o Pacote Laboral | Partido Comunista Português

Dos Transportes à Saúde, Lares E Prisões, Que Serviços Mínimos Estão Garantidos Para A Greve
--------------------------------------------------------------------------------------------

 ![Dos transportes à saúde, lares e prisões, que serviços mínimos estão garantidos para a greve](https://images.impresa.pt/expresso/2025-12-09-greve-geral.jpg-0c01f0f6/original) <small>expresso.pt</small>Dos transportes à saúde, lares e prisões, que serviços mínimos estão garantidos para a greve ...

Greve Geral Em Portugal – 11 De Dezembro - FLEMACON
---------------------------------------------------

 ![Greve geral em Portugal – 11 de dezembro - FLEMACON](https://www.flemacon.org/wp-content/uploads/2025/12/WhatsApp-Image-2025-12-12-at-19.45.27-1-696x870.jpeg) <small>www.flemacon.org</small>Greve geral em Portugal – 11 de dezembro - FLEMACON

GREVE GERAL DIA 11 DEZEMBRO DE 2025 | FESAHT
--------------------------------------------

 ![GREVE GERAL DIA 11 DEZEMBRO DE 2025 | FESAHT](https://sindicatos.cgtp.pt/fesaht/wp-content/blogs.dir/52/files/sites/52/2025/12/11-DEZ-faz-greve-e-sai-a-Rua.jpg) <small>sindicatos.cgtp.pt</small>GREVE GERAL DIA 11 DEZEMBRO DE 2025 | FESAHT

Greve Geral Em Portugal Em Grande Destaque Na Imprensa Internacional - Sociedade - Correio Da Manhã
---------------------------------------------------------------------------------------------------

 ![Greve geral em Portugal em grande destaque na imprensa internacional - Sociedade - Correio da Manhã](https://cdn.cmjornal.pt/images/2025-12/img_1500x1000uu2025-12-10-22-06-51-2253721.jpg) <small>www.cmjornal.pt</small>Greve geral em Portugal em grande destaque na imprensa internacional - Sociedade - Correio da Manhã

A Greve Foi "um Estrondo" Político Mas "perderam Todos" - CNN Portugal
----------------------------------------------------------------------

 ![A greve foi "um estrondo" político mas "perderam todos" - CNN Portugal](https://img.iol.pt/image/id/693b2a1ad34e3caad84c47e9/1024.jpg) <small>cnnportugal.iol.pt</small>A greve foi "um estrondo" político mas "perderam todos" - CNN Portugal

Greve Geral De 11 De Dezembro Em Portugal: Razões Para Participar
-----------------------------------------------------------------

 ![Greve Geral de 11 de dezembro em Portugal: razões para participar](https://sabiasque.pt/images/stories/2025/trabalho/20251209-greve-geral-11-dezembro-320x480.jpg) <small>sabiasque.pt</small>Greve Geral de 11 de dezembro em Portugal: razões para participar

A Greve Geral De 11 De Dezembro Em 38 Imagens – Observador
----------------------------------------------------------

 ![A greve geral de 11 de dezembro em 38 imagens – Observador](https://bordalo.observador.pt/v2/q:60/rs:fill:1440/c:4096:2730:nowe:0:0/plain/https://s3.observador.pt/wp-content/uploads/2025/12/11173228/dventura-greve-geral-11dez-41-scaled.jpg) <small>observador.pt</small>A greve geral de 11 de dezembro em 38 imagens – Observador

SDP Sul
-------

 ![SDP Sul](https://sdpsul.com/storage/publicacao/imagem_563_6929dba6ddf62.jpeg) <small>sdpsul.com</small>SDP Sul

11 De Dezembro. Portugal Terá A Sua Primeira Greve Geral Em 12 Anos Contra O Pacote Laboral
-------------------------------------------------------------------------------------------

 ![11 de Dezembro. Portugal terá a sua primeira Greve Geral em 12 anos contra o pacote laboral](https://www.esquerdadiario.com.br/IMG/logo/imagem_do_whatsapp_de_2025-11-18_a_s_20.02_31_2e7bdf41.jpg?1763508227) <small>www.esquerdadiario.com.br</small>11 de Dezembro. Portugal terá a sua primeira Greve Geral em 12 anos contra o pacote laboral ...

Portugal Acordou Com Uma Verdadeira Greve Geral A 11 De Dezembro – Liga Internacional Socialista
------------------------------------------------------------------------------------------------

 ![Portugal acordou com uma verdadeira Greve Geral a 11 de dezembro – Liga Internacional Socialista](https://lis-isl.org/wp-content/uploads/2025/12/WhatsApp-Image-2025-12-12-at-5.03.03-PM-1-843x1024.jpeg) <small>lis-isl.org</small>Portugal acordou com uma verdadeira Greve Geral a 11 de dezembro – Liga Internacional Socialista

Motivos Da Adesão à Greve Geral De 11 De Dezembro De 2025
---------------------------------------------------------

 ![Motivos da adesão à Greve Geral de 11 de dezembro de 2025](https://spzn.pt/uploads/noticias/big_1763717239_6728_SPZN_2025_site_novo_(17).png) <small>spzn.pt</small>Motivos da adesão à Greve Geral de 11 de dezembro de 2025

Greve Geral De 11 De Dezembro: Impacto Económico Estimado E Análise | Economia
------------------------------------------------------------------------------

 ![Greve Geral de 11 de Dezembro: Impacto Económico Estimado e Análise | Economia](https://i.headtopics.com/images/2025/12/6/publico/greve-geral-o-que-e-quem-abrange-e-como-funciona-greve-geral-o-que-e-quem-abrange-e-como-funciona-43970BF408A401F542300934033BEA05.webp?w=640) <small>ph.headtopics.com</small>Greve Geral de 11 de Dezembro: Impacto Económico Estimado e Análise | Economia

Maioria Dos Portugueses Diz Que Greve Geral Foi Justificada - Portugal - SÁBADO
-------------------------------------------------------------------------------

 ![Maioria dos portugueses diz que greve geral foi justificada - Portugal - SÁBADO](https://cdn.sabado.pt/images/2025-12/img_980x653uu2025-12-22-09-03-14-753915.jpg) <small>www.sabado.pt</small>Maioria dos portugueses diz que greve geral foi justificada - Portugal - SÁBADO

Greve Geral Paralisa Transportes, Saúde E Educação No Porto - Expresso
----------------------------------------------------------------------

 ![Greve geral paralisa transportes, saúde e educação no Porto - Expresso](https://images.impresa.pt/expresso/2025-12-11-rds_15_greve-geral-2025-manifestacao-porto_rds_4314.jpg-f75ffda9/original) <small>expresso.pt</small>Greve geral paralisa transportes, saúde e educação no Porto - Expresso

GREVE GERAL – Dia 11 De Dezembro | Sincomar - Sindicato De Capitães E Oficiais Da Marinha Mercante
--------------------------------------------------------------------------------------------------

 ![GREVE GERAL – Dia 11 de Dezembro | Sincomar - Sindicato de Capitães e Oficiais da Marinha Mercante](https://sincomar.pt/wp-content/uploads/2025/12/2-cartaz-GREVE-GERAL-UGT-final.jpg) <small>sincomar.pt</small>GREVE GERAL – Dia 11 de Dezembro | Sincomar - Sindicato de Capitães e Oficiais da Marinha Mercante

Greve Geral Em Portugal – 11 De Dezembro - FLEMACON
---------------------------------------------------

 ![Greve geral em Portugal – 11 de dezembro - FLEMACON](https://www.flemacon.org/wp-content/uploads/2025/12/WhatsApp-Image-2025-12-12-at-19.45.27.jpeg) <small>www.flemacon.org</small>Greve geral em Portugal – 11 de dezembro - FLEMACON

A Greve Geral De 11 De Dezembro Em 38 Imagens – Observador
----------------------------------------------------------

 ![A greve geral de 11 de dezembro em 38 imagens – Observador](https://bordalo.observador.pt/v2/q:60/rs:fill:1440/c:4096:2730:nowe:0:0/plain/https://s3.observador.pt/wp-content/uploads/2025/12/11173319/dventura-greve-geral-11dez-47-scaled.jpg) <small>observador.pt</small>A greve geral de 11 de dezembro em 38 imagens – Observador

Grève Générale Au Portugal Le 11 Décembre 2025 — Idealista/news
---------------------------------------------------------------

 ![Grève générale au Portugal le 11 décembre 2025 — idealista/news](https://st3.idealista.pt/news/arquivos/styles/fullwidth_xl/public/2025-11/images/gettyimages-1464525441.jpg?VersionId=LRLZg6LIY2gNAOZWDAV4As4ZDJLKV8zz&h=ccb4b76f&itok=8bPFRGyM) <small>www.idealista.pt</small>Grève générale au Portugal le 11 décembre 2025 — idealista/news

A Greve Geral De 11 De Dezembro Em 38 Imagens – Observador
----------------------------------------------------------

 ![A greve geral de 11 de dezembro em 38 imagens – Observador](https://bordalo.observador.pt/v2/q:60/rs:fill:1440/c:4096:2730:nowe:0:0/plain/https://s3.observador.pt/wp-content/uploads/2025/12/11173246/dventura-greve-geral-11dez-43-scaled.jpg) <small>observador.pt</small>A greve geral de 11 de dezembro em 38 imagens – Observador

Portugal acordou com uma verdadeira greve geral a 11 de dezembro – liga internacional socialista. Greve geral – dia 11 de dezembro. A greve foi "um estrondo" político mas "perderam todos"
