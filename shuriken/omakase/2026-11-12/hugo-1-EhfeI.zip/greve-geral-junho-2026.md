---
title: "Greve Geral Junho 2026 - O que vai parar com a greve geral de 3 de junho?"
description: "Greve geral"
date: "2026-07-18"
categories:
- "Uncategorized"
images:
- "https://sabiasque.pt/images/stories/2026/trabalho/20260602-greve-geral-3-junho-1024x683.jpg"
featuredImage: "https://novo.aeermesinde.net/wp/wp-content/uploads/2026/06/WhatsApp-Image-2026-06-11-at-18.45.24-1024x1024.jpeg"
featured_image: "https://cdn.cmjornal.pt/images/2025-12/img_1500x1000uu2025-12-11-14-37-03-2253844.jpg"
image: "https://stianor.pt/wp-content/uploads/2026/05/faixa-rua-GG-35mx06-curvas_page-0001.jpg"
---

If you are searching about FNSTFPS já emitiu Aviso Prévio para a Greve Geral de 3 de Junho! - CGTP-IN you've came to the right web. We have 35 Pictures about FNSTFPS já emitiu Aviso Prévio para a Greve Geral de 3 de Junho! - CGTP-IN like GREVE GERAL - 3 JUNHO 2026 | Resolução - CGTP-IN, Comunicado SNMV – Greve Geral 3 junho 2026 – SNMV and also GREVE GERAL | 3 JUNHO - SINAPSA. Read more:

FNSTFPS Já Emitiu Aviso Prévio Para A Greve Geral De 3 De Junho! - CGTP-IN
--------------------------------------------------------------------------

 ![FNSTFPS já emitiu Aviso Prévio para a Greve Geral de 3 de Junho! - CGTP-IN](https://www.cgtp.pt/images/accao-e-luta/2026/05/greve-geral-funcao-publica.jpg) <small>www.cgtp.pt</small>FNSTFPS já emitiu Aviso Prévio para a Greve Geral de 3 de Junho! - CGTP-IN

Guia Para Almadenses : Como Sobreviver à Greve Geral - Almada Online
--------------------------------------------------------------------

 ![Guia para almadenses : como sobreviver à Greve Geral - Almada online](https://almadaonline.pt/wp-content/uploads/2026/06/GreveGeralStal.jpg) <small>almadaonline.pt</small>Guia para almadenses : como sobreviver à Greve Geral - Almada online

Greve Geral é Para Todos Os Trabalhadores! – Escola Portuguesa
--------------------------------------------------------------

 ![Greve Geral é para todos os trabalhadores! – Escola Portuguesa](https://escolapt.wordpress.com/wp-content/uploads/2026/05/706357188_18081656384561625_6623516586727525352_n.jpg) <small>escolapt.wordpress.com</small>Greve Geral é para todos os trabalhadores! – Escola Portuguesa

GREVE GERAL 3 JUNHO | Concentrações/Manifestações
-------------------------------------------------

 ![GREVE GERAL 3 JUNHO | Concentrações/Manifestações](https://www.stal.pt/images/2026/CONCENTRACOES-GG_Site.jpg#joomlaImage:/local-images/2026/CONCENTRACOES-GG_Site.jpg?width=1080&height=720) <small>www.stal.pt</small>GREVE GERAL 3 JUNHO | Concentrações/Manifestações

SPGL - Professores, Educadores E Investigadores Na Greve Geral | 3 De Junho 2026
--------------------------------------------------------------------------------

 ![SPGL - Professores, educadores e investigadores na Greve Geral | 3 de junho 2026](https://www.spgl.pt/Media/Default/_Profiles/7494e02c/a9d870bd/Flyer Greve Geral_page-0002.jpg?v=639147970017538180) <small>www.spgl.pt</small>SPGL - Professores, educadores e investigadores na Greve Geral | 3 de junho 2026

Comunicado SNMV – Greve Geral 3 Junho 2026 – SNMV
-------------------------------------------------

 ![Comunicado SNMV – Greve Geral 3 junho 2026 – SNMV](https://snmv.pt/wp-content/uploads/2026/06/qwqwqweqwq-724x1024.png) <small>snmv.pt</small>Comunicado SNMV – Greve Geral 3 junho 2026 – SNMV

AVISO PRÉVIO DE GREVE GERAL 3 JUNHO 2026 – STTS
-----------------------------------------------

 ![AVISO PRÉVIO DE GREVE GERAL 3 JUNHO 2026 – STTS](https://www.stts.pt/wp-content/uploads/2026/05/Imagem1-210x136.png) <small>www.stts.pt</small>AVISO PRÉVIO DE GREVE GERAL 3 JUNHO 2026 – STTS

PRÉ-AVISO DE GREVE – 15 DE JUNHO DE 2026
----------------------------------------

 ![PRÉ-AVISO DE GREVE – 15 DE JUNHO DE 2026](https://novo.aeermesinde.net/wp/wp-content/uploads/2026/06/WhatsApp-Image-2026-06-11-at-18.45.24-1024x1024.jpeg) <small>novo.aeermesinde.net</small>PRÉ-AVISO DE GREVE – 15 DE JUNHO DE 2026

GREVE GERAL | 3 JUNHO - SINAPSA
-------------------------------

 ![GREVE GERAL | 3 JUNHO - SINAPSA](https://sinapsa.pt/wp-content/uploads/2026/06/INFO49-scaled.jpg) <small>sinapsa.pt</small>GREVE GERAL | 3 JUNHO - SINAPSA

Metro Do Porto "fortemente Condicionado" No Dia Da Greve Geral - JPN
--------------------------------------------------------------------

 ![Metro do Porto "fortemente condicionado" no dia da greve geral - JPN](https://www.jpn.up.pt/wp-content/uploads/2025/12/greve_geral1-1152x759.jpg) <small>www.jpn.up.pt</small>Metro do Porto "fortemente condicionado" no dia da greve geral - JPN

"Estamos Há Nove Meses A Discutir O Pacote Laboral E Nada Mudou." CGTP Convoca Greve Geral Para
-----------------------------------------------------------------------------------------------

 !["Estamos há nove meses a discutir o pacote laboral e nada mudou." CGTP convoca greve geral para](https://staticx.noticiasilimitadas.pt/tsf/image.webp?brand=tsf&type=generate&guid=a9823cf8-2279-4119-9c62-ec9effb0d646&w=3840) <small>www.tsf.pt</small>"Estamos há nove meses a discutir o pacote laboral e nada mudou." CGTP convoca greve geral para ...

AVISO PRÉVIO DE GREVE GERAL 3 JUNHO 2026 – STTS
-----------------------------------------------

 ![AVISO PRÉVIO DE GREVE GERAL 3 JUNHO 2026 – STTS](https://www.stts.pt/wp-content/uploads/2026/05/123654.jpg) <small>www.stts.pt</small>AVISO PRÉVIO DE GREVE GERAL 3 JUNHO 2026 – STTS

Balanço Da Greve Geral - CGTP-IN
--------------------------------

 ![Balanço da Greve Geral - CGTP-IN](https://www.cgtp.pt/images/images/2025/11/gg_banner2025.jpg) <small>www.cgtp.pt</small>Balanço da Greve Geral - CGTP-IN

Greve Geral – Dia 3 De Junho - SPRA
-----------------------------------

 ![Greve Geral – dia 3 de junho - SPRA](https://www.spra.pt/wp-content/uploads/2026/05/Greve_Acores-768x1024.jpg) <small>www.spra.pt</small>Greve Geral – dia 3 de junho - SPRA

AVISO PRÉVIO DE GREVE TRABALHADORES NÃO DOCENTES 5 JUNHO 2026 – STTS
--------------------------------------------------------------------

 ![AVISO PRÉVIO DE GREVE TRABALHADORES NÃO DOCENTES 5 JUNHO 2026 – STTS](https://www.stts.pt/wp-content/uploads/2026/05/Imagem1.png) <small>www.stts.pt</small>AVISO PRÉVIO DE GREVE TRABALHADORES NÃO DOCENTES 5 JUNHO 2026 – STTS

DERROTAR O PACOTE LABORAL – GREVE GERAL 3 DE JUNHO – Plenário Online\_Teleperformance\_29 De Maio
-------------------------------------------------------------------------------------------------

 ![DERROTAR O PACOTE LABORAL – GREVE GERAL 3 DE JUNHO – Plenário Online_Teleperformance_29 de Maio](https://sinttav.pt/wp-content/uploads/2026/05/Panfleto-para-Site-e-Redes-Portugues-724x1024.jpg) <small>sinttav.pt</small>DERROTAR O PACOTE LABORAL – GREVE GERAL 3 DE JUNHO – Plenário Online\_Teleperformance\_29 de Maio ...

GREVE GERAL - 3 JUNHO 2026 | Resolução - CGTP-IN
------------------------------------------------

 ![GREVE GERAL - 3 JUNHO 2026 | Resolução - CGTP-IN](https://www.cgtp.pt/images/images/2026/06/tiago-greve-geral.jpg) <small>www.cgtp.pt</small>GREVE GERAL - 3 JUNHO 2026 | Resolução - CGTP-IN

NOTA INFORMATIVA Nº17/2026 - GREVE GERAL | 3 DE JUNHO DE 2026 - STI - Sindicato Dos
-----------------------------------------------------------------------------------

 ![NOTA INFORMATIVA Nº17/2026 - GREVE GERAL | 3 DE JUNHO DE 2026 - STI - Sindicato dos](https://stimpostos.pt/wp-content/uploads/2026/05/notas-informativas-2024-27.jpg) <small>stimpostos.pt</small>NOTA INFORMATIVA Nº17/2026 - GREVE GERAL | 3 DE JUNHO DE 2026 - STI - Sindicato dos ...

AVISO PRÉVIO DE GREVE TRABALHADORES ADMINISTRAÇÃO PÚBLICA 16 DE MAIO 2025 – STTS
--------------------------------------------------------------------------------

 ![AVISO PRÉVIO DE GREVE TRABALHADORES ADMINISTRAÇÃO PÚBLICA 16 DE MAIO 2025 – STTS](https://www.stts.pt/wp-content/uploads/2025/05/CAPA.jpg) <small>www.stts.pt</small>AVISO PRÉVIO DE GREVE TRABALHADORES ADMINISTRAÇÃO PÚBLICA 16 DE MAIO 2025 – STTS

Aviso Prévio De Greve Administração Pública – Setor Público Empresarial – IPSS 23 DE MARÇO DE
---------------------------------------------------------------------------------------------

 ![Aviso prévio de greve Administração Pública – Setor Público Empresarial – IPSS 23 DE MARÇO DE](https://www.stts.pt/wp-content/uploads/2026/03/CAPA.png) <small>www.stts.pt</small>Aviso prévio de greve Administração Pública – Setor Público Empresarial – IPSS 23 DE MARÇO DE ...

Greve Geral De 3 De Junho: O Que Está Em Causa, Quem Pode Aderir E Que Impacto Se Prevê
---------------------------------------------------------------------------------------

 ![Greve Geral de 3 de junho: o que está em causa, quem pode aderir e que impacto se prevê](https://sabiasque.pt/images/stories/2026/trabalho/20260602-greve-geral-3-junho-1024x683.jpg) <small>sabiasque.pt</small>Greve Geral de 3 de junho: o que está em causa, quem pode aderir e que impacto se prevê

Professores Deram Uma Forte Expressão à Greve Geral De 3 De Junho - FENPROF
---------------------------------------------------------------------------

 ![Professores deram uma forte expressão à Greve Geral de 3 de junho - FENPROF](https://www.fenprof.pt/media/download/6FDA79F0A62C1CB1E79A4D96032CBC0A/foto-greve-na-rua.jpg) <small>www.fenprof.pt</small>Professores deram uma forte expressão à Greve Geral de 3 de junho - FENPROF

Greve Geral – Derrotar O Pacote Laboral – 3 De Junho 2026 – SINTTAV Sindicato Nacional Dos
------------------------------------------------------------------------------------------

 ![Greve Geral – Derrotar o Pacote Laboral – 3 de Junho 2026 – SINTTAV Sindicato Nacional dos](https://sinttav.pt/wp-content/uploads/2026/05/Cartaz_Greve-Geral-Derrotar-o-Pacote-Laboral-3-de-Junho-2026.jpg) <small>sinttav.pt</small>Greve Geral – Derrotar o Pacote Laboral – 3 de Junho 2026 – SINTTAV Sindicato Nacional dos ...

Aviso | Greves Em Junho De 2026 – AE António Correia De Oliveira
----------------------------------------------------------------

 ![Aviso | Greves em junho de 2026 – AE António Correia de Oliveira](https://www.acoliveira.pt/wp-content/uploads/2026/05/ChatGPT-Image-31_05_2026-22_43_43.png) <small>www.acoliveira.pt</small>Aviso | Greves em junho de 2026 – AE António Correia de Oliveira

CGTP Convoca Greve Geral Para 3 De Junho - Sociedade - Correio Da Manhã
-----------------------------------------------------------------------

 ![CGTP convoca greve geral para 3 de junho - Sociedade - Correio da Manhã](https://cdn.cmjornal.pt/images/2025-12/img_1500x1000uu2025-12-11-14-37-03-2253844.jpg) <small>www.cmjornal.pt</small>CGTP convoca greve geral para 3 de junho - Sociedade - Correio da Manhã

Greve Geral - Manifestação - 30 De Junho - Seeb
-----------------------------------------------

 ![Greve Geral - Manifestação - 30 de Junho - Seeb](http://seeb.org.br/wp-content/uploads/2017/06/GREVE-GERAL-30-1-1024x1024.jpg) <small>seeb.org.br</small>Greve Geral - Manifestação - 30 de Junho - Seeb

Greve Geral - 3 De Junho De 2026 | Concentrações - CGTP-IN
----------------------------------------------------------

 ![Greve Geral - 3 de Junho de 2026 | Concentrações - CGTP-IN](https://www.cgtp.pt/images/images/2026/05/CONCENTRACOES-GG.jpg) <small>www.cgtp.pt</small>Greve Geral - 3 de Junho de 2026 | Concentrações - CGTP-IN

Pré-Aviso De Greve – 17 De Abril De 2026 – AE António Correia De Oliveira
-------------------------------------------------------------------------

 ![Pré-Aviso de Greve – 17 de abril de 2026 – AE António Correia de Oliveira](https://www.acoliveira.pt/wp-content/uploads/2026/04/7e9f6ec4-4873-4685-897b-30c62aab02d6.png) <small>www.acoliveira.pt</small>Pré-Aviso de Greve – 17 de abril de 2026 – AE António Correia de Oliveira

Greve Geral De 24 Horas No Dia 3 De Junho- Serviço De Transporte Afetado
------------------------------------------------------------------------

 ![Greve geral de 24 horas no dia 3 de junho- Serviço de transporte afetado](https://www.metrolisboa.pt/institucional/wp-content/uploads/sites/2/2026/06/greve-3-junho_1080x450.png) <small>www.metrolisboa.pt</small>Greve geral de 24 horas no dia 3 de junho- Serviço de transporte afetado

Greve Geral - 03 De Junho De 2026
---------------------------------

 ![Greve Geral - 03 de junho de 2026](https://cabeceirasdebasto.pt/files/46/46246.jpg) <small>cabeceirasdebasto.pt</small>Greve Geral - 03 de junho de 2026

O Que Vai Parar Com A Greve Geral De 3 De Junho? - Portugal - SÁBADO
--------------------------------------------------------------------

 ![O que vai parar com a greve geral de 3 de junho? - Portugal - SÁBADO](https://cdn.sabado.pt/images/2026-05/img_1200x676uu2026-05-21-18-26-04-766232.jpg) <small>www.sabado.pt</small>O que vai parar com a greve geral de 3 de junho? - Portugal - SÁBADO

Greve Geral - CGTP-IN
---------------------

 ![Greve Geral - CGTP-IN](https://www.cgtp.pt/images/images/2026/06/resolucao_grevegeral.jpg) <small>www.cgtp.pt</small>Greve Geral - CGTP-IN

Todos à Greve Geral – 3 De Junho De 2026
----------------------------------------

 ![Todos à Greve Geral – 3 de Junho de 2026](https://stianor.pt/wp-content/uploads/2026/05/faixa-rua-GG-35mx06-curvas_page-0001.jpg) <small>stianor.pt</small>Todos à Greve Geral – 3 de Junho de 2026

Greve Geral Em Lisboa A 3 De Junho: O Que Pára Na Cidade
--------------------------------------------------------

 ![Greve geral em Lisboa a 3 de Junho: o que pára na cidade](https://media.timeout.com/images/106411166/1372/772/image.jpg) <small>www.timeout.pt</small>Greve geral em Lisboa a 3 de Junho: o que pára na cidade

Greve Geral - CGTP-IN
---------------------

 ![Greve Geral - CGTP-IN](https://cgtp.pt/images/images/2026/06/Captura de ecra 2026-06-03 120926.png#joomlaImage:/local-images/images/2026/06/Captura de ecra 2026-06-03 120926.png?width=1162&height=610) <small>www.cgtp.pt</small>Greve Geral - CGTP-IN

Greve geral – dia 3 de junho. Aviso prévio de greve administração pública – setor público empresarial – ipss 23 de março de. Metro do porto "fortemente condicionado" no dia da greve geral
