---
title: "Greve Geral 2026 2 Outubro - O que se sabe sobre a greve dos caminhoneiros em 2026?"
description: "Pré-aviso de greve – 17 de abril de 2026 – página 2 – ae antónio correia de oliveira"
date: "2026-03-22"
categories:
- "Uncategorized"
images:
- "https://www.diarioviseu.pt/wp-content/uploads/sites/8/2025/12/Greve-geral2-e1765832007744.webp"
featuredImage: "https://static.wixstatic.com/media/1b0f0b_ae47f5124a53427f9cb76d9abc5ce95a~mv2.jpg/v1/fill/w_490,h_314,al_c,lg_1,q_80/1b0f0b_ae47f5124a53427f9cb76d9abc5ce95a~mv2.jpg"
featured_image: "https://cdn.sortiraparis.com/images/80/1467/1199124-greve-du-2-octobre-les-manifestations-prevues-a-paris-et-en-ile-de-france.jpg"
image: "https://www.cgtp.pt/images/images/2026/06/tiago-greve-geral.jpg"
---

If you are searching about Contratos, horários, parentalidade e despedimentos: novo ano antecipa revolução no trabalho you've visit to the right page. We have 35 Images about Contratos, horários, parentalidade e despedimentos: novo ano antecipa revolução no trabalho like Pré-Aviso de Greve – 17 de abril de 2026 – Página 2 – AE António Correia de Oliveira, Greve Geral | Ações e dados and also Greve geral histórica em Portugal paralisa transportes, fecha escolas e pressiona hospitais. Here it is:

Contratos, Horários, Parentalidade E Despedimentos: Novo Ano Antecipa Revolução No Trabalho
-------------------------------------------------------------------------------------------

 ![Contratos, horários, parentalidade e despedimentos: novo ano antecipa revolução no trabalho](https://img.iol.pt/image/id/693b2a1ad34e3caad84c47e9/1024.jpg) <small>tvi.iol.pt</small>Contratos, horários, parentalidade e despedimentos: novo ano antecipa revolução no trabalho ...

GREVE GERAL - 3 JUNHO 2026 | Resolução - CGTP-IN
------------------------------------------------

 ![GREVE GERAL - 3 JUNHO 2026 | Resolução - CGTP-IN](https://www.cgtp.pt/images/images/2026/06/tiago-greve-geral.jpg) <small>www.cgtp.pt</small>GREVE GERAL - 3 JUNHO 2026 | Resolução - CGTP-IN

AVISO PRÉVIO DE GREVE TRABALHADORES NÃO DOCENTES 5 JUNHO 2026 – STTS
--------------------------------------------------------------------

 ![AVISO PRÉVIO DE GREVE TRABALHADORES NÃO DOCENTES 5 JUNHO 2026 – STTS](https://www.stts.pt/wp-content/uploads/2026/05/Imagem1.png) <small>www.stts.pt</small>AVISO PRÉVIO DE GREVE TRABALHADORES NÃO DOCENTES 5 JUNHO 2026 – STTS

AVISO PRÉVIO DE GREVE GERAL 3 JUNHO 2026 – STTS
-----------------------------------------------

 ![AVISO PRÉVIO DE GREVE GERAL 3 JUNHO 2026 – STTS](https://www.stts.pt/wp-content/uploads/2026/05/123654-1024x871.jpg) <small>www.stts.pt</small>AVISO PRÉVIO DE GREVE GERAL 3 JUNHO 2026 – STTS

O Que Se Sabe Sobre A Greve Dos Caminhoneiros Em 2026?
------------------------------------------------------

 ![O que se sabe sobre a greve dos caminhoneiros em 2026?](https://blog.proteautobrasil.com.br/wp-content/uploads/2026/03/19-03-GREVE.png) <small>blog.proteautobrasil.com.br</small>O que se sabe sobre a greve dos caminhoneiros em 2026?

Greve Geral Fecha Dezenas De Escolas Na Região
----------------------------------------------

 ![Greve geral fecha dezenas de escolas na região](https://www.diarioviseu.pt/wp-content/uploads/sites/8/2025/12/Greve-geral2-e1765832007744.webp) <small>www.diarioviseu.pt</small>Greve geral fecha dezenas de escolas na região

SPGL - Greve Geral Da Administração Pública | 24 De Outubro 2025
----------------------------------------------------------------

 ![SPGL - Greve Geral da Administração Pública | 24 de outubro 2025](https://www.spgl.pt/Media/Default/_Profiles/3675b73a/58a5481d/Cartaz 24 Out_FENPROF_page-0001.jpg?v=638956052779715690) <small>www.spgl.pt</small>SPGL - Greve Geral da Administração Pública | 24 de outubro 2025

AO MINUTO: Greve Geral Para O País. "Forte Adesão" E "impacto Fortíssimo"
-------------------------------------------------------------------------

 ![AO MINUTO: Greve geral para o país. "Forte adesão" e "impacto fortíssimo"](https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA1S86fG.img?w=1920&h=1080&m=4&q=100) <small>www.msn.com</small>AO MINUTO: Greve geral para o país. "Forte adesão" e "impacto fortíssimo"

PRÉ- AVISO DE GREVE – 23 E 24 De Outubro – AEC
----------------------------------------------

 ![PRÉ- AVISO DE GREVE – 23 e 24 de outubro – AEC](https://aeceleiros.pt/wp-content/uploads/2025/10/Greve_out2025_v1.png) <small>aeceleiros.pt</small>PRÉ- AVISO DE GREVE – 23 e 24 de outubro – AEC

15 Minutos: Impacto Da Greve Geral Já Se Começou A Sentir No Setor Dos Transportes - SIC Notícias
-------------------------------------------------------------------------------------------------

 ![15 minutos: impacto da greve geral já se começou a sentir no setor dos transportes - SIC Notícias](https://images.impresa.pt/sicnot/2025-12-12-greve-geral-045a9380/1.91x1?wm=true&outputFormat=jpeg) <small>sicnoticias.pt</small>15 minutos: impacto da greve geral já se começou a sentir no setor dos transportes - SIC Notícias

Pré-Aviso De Greve – 17 De Abril De 2026 – Página 2 – AE António Correia De Oliveira
------------------------------------------------------------------------------------

 ![Pré-Aviso de Greve – 17 de abril de 2026 – Página 2 – AE António Correia de Oliveira](https://www.acoliveira.pt/wp-content/uploads/2026/04/7e9f6ec4-4873-4685-897b-30c62aab02d6.png) <small>www.acoliveira.pt</small>Pré-Aviso de Greve – 17 de abril de 2026 – Página 2 – AE António Correia de Oliveira

Manifestação Em Frente Ao Parlamento Resultou Em Seis Detidos: Tudo Sobre A Greve Geral
---------------------------------------------------------------------------------------

 ![Manifestação em frente ao Parlamento resultou em seis detidos: tudo sobre a greve geral](https://cdn.sabado.pt/images/2025-12/img_1320x742uu2025-12-11-15-03-48-752830.jpg) <small>www.sabado.pt</small>Manifestação em frente ao Parlamento resultou em seis detidos: tudo sobre a greve geral ...

Greve Geral - 3 De Junho De 2026 | Concentrações - CGTP-IN
----------------------------------------------------------

 ![Greve Geral - 3 de Junho de 2026 | Concentrações - CGTP-IN](https://www.cgtp.pt/images/images/2026/05/CONCENTRACOES-GG.jpg) <small>www.cgtp.pt</small>Greve Geral - 3 de Junho de 2026 | Concentrações - CGTP-IN

Greve Geral | Ações E Dados
---------------------------

 ![Greve Geral | Ações e dados](https://fne.pt/uploads/noticias/big_1765451399_8584_Design_sem_nome.png) <small>fne.pt</small>Greve Geral | Ações e dados

AVISO PRÉVIO DE GREVE TRABALHADORES ADMINISTRAÇÃO PÚBLICA 16 DE MAIO 2025 – STTS
--------------------------------------------------------------------------------

 ![AVISO PRÉVIO DE GREVE TRABALHADORES ADMINISTRAÇÃO PÚBLICA 16 DE MAIO 2025 – STTS](https://www.stts.pt/wp-content/uploads/2025/05/CAPA-972x1024.jpg) <small>www.stts.pt</small>AVISO PRÉVIO DE GREVE TRABALHADORES ADMINISTRAÇÃO PÚBLICA 16 DE MAIO 2025 – STTS

SINDEP - Greve Geral 11 De Dezembro
-----------------------------------

 ![SINDEP - Greve Geral 11 de dezembro](https://sindep.pt/images/cartaz_GREVE_GERAL_UGT.jpg) <small>sindep.pt</small>SINDEP - Greve Geral 11 de dezembro

Entre O Dever De Informar E A Adesão è Greve, Sindicato Dos Jornalistas Faz Balanço
-----------------------------------------------------------------------------------

 ![Entre o dever de informar e a adesão è greve, Sindicato dos Jornalistas faz balanço](https://eco.imgix.net/uploads/2025/12/cropped-greve-geral03.jpg) <small>eco.sapo.pt</small>Entre o dever de informar e a adesão è greve, Sindicato dos Jornalistas faz balanço ...

OE2026 "dá Mais Força" à Greve Geral Da Frente Comum Dia 24 – Observador
------------------------------------------------------------------------

 ![OE2026 "dá mais força" à greve geral da Frente Comum dia 24 – Observador](https://wm.observador.pt/wm/l/https://bordalo.observador.pt/v2/rs:fill:770:403/c:2000:1124:nowe:0:105/q:70/f:webp/plain/https://s3.observador.pt/wp-content/uploads/2025/07/17130847/45338055.jpg?layer=obstop:T) <small>observador.pt</small>OE2026 "dá mais força" à greve geral da Frente Comum dia 24 – Observador

GREVE GERAL DIA 11 DEZEMBRO DE 2025 | FESAHT
--------------------------------------------

 ![GREVE GERAL DIA 11 DEZEMBRO DE 2025 | FESAHT](https://sindicatos.cgtp.pt/fesaht/wp-content/blogs.dir/52/files/sites/52/2025/12/11-DEZ-faz-greve-e-sai-a-Rua.jpg) <small>sindicatos.cgtp.pt</small>GREVE GERAL DIA 11 DEZEMBRO DE 2025 | FESAHT

Dados Recolhidos Até às 19h20 Demonstram Que A Greve Geral Parou O País - CGTP-IN
---------------------------------------------------------------------------------

 ![Dados recolhidos até às 19h20 demonstram que a Greve Geral parou o país - CGTP-IN](https://cgtp.pt/images/images/2026/06/Captura de ecra 2026-06-03 120926.png#joomlaImage:/local-images/images/2026/06/Captura de ecra 2026-06-03 120926.png?width=1162&height=610) <small>www.cgtp.pt</small>Dados recolhidos até às 19h20 demonstram que a Greve Geral parou o país - CGTP-IN

JF 322, Outubro 2025 - Especial Greve Geral - FENPROF
-----------------------------------------------------

 ![JF 322, outubro 2025 - Especial Greve Geral - FENPROF](https://www.fenprof.pt/media/download/15F17E8F588460D269BD41A072E3C2D6/capajf-especial-gg-nov25.png) <small>www.fenprof.pt</small>JF 322, outubro 2025 - Especial Greve Geral - FENPROF

Frente Comum Diz Que Proposta De OE2026 "dá Mais Força" à Greve Geral De 24 De Outubro
--------------------------------------------------------------------------------------

 ![Frente Comum diz que proposta de OE2026 "dá mais força" à greve geral de 24 de outubro](https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA1Ohf0g.img?w=1280&h=720&m=4&q=75) <small>www.msn.com</small>Frente Comum diz que proposta de OE2026 "dá mais força" à greve geral de 24 de outubro

Aviso | Greves Em Junho De 2026 – AE António Correia De Oliveira
----------------------------------------------------------------

 ![Aviso | Greves em junho de 2026 – AE António Correia de Oliveira](https://www.acoliveira.pt/wp-content/uploads/2026/05/ChatGPT-Image-31_05_2026-22_43_43.png) <small>www.acoliveira.pt</small>Aviso | Greves em junho de 2026 – AE António Correia de Oliveira

Acesse Já O Boletim Da Greve #2! – Assufrgs
-------------------------------------------

 ![Acesse já o Boletim da Greve #2! – Assufrgs](https://www.assufrgs.org.br/wp-content/uploads/2026/04/Capa-site-3.0-1.png) <small>www.assufrgs.org.br</small>Acesse já o Boletim da Greve #2! – Assufrgs

Mais De 50 Sindicatos Aderem à Greve Geral Marcada Para 11 De Dezembro
----------------------------------------------------------------------

 ![Mais de 50 sindicatos aderem à greve geral marcada para 11 de dezembro](https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA1QBjfX.img?w=1200&h=800&m=4&q=70) <small>www.msn.com</small>Mais de 50 sindicatos aderem à greve geral marcada para 11 de dezembro

GREVE GERAL - 3 JUNHO 2026 | Resolução - CGTP-IN
------------------------------------------------

 ![GREVE GERAL - 3 JUNHO 2026 | Resolução - CGTP-IN](https://www.cgtp.pt/images/images/2026/06/resolucao_grevegeral.jpg) <small>www.cgtp.pt</small>GREVE GERAL - 3 JUNHO 2026 | Resolução - CGTP-IN

Aviso Prévio De Greve Administração Pública – Setor Público Empresarial – IPSS 23 DE MARÇO DE
---------------------------------------------------------------------------------------------

 ![Aviso prévio de greve Administração Pública – Setor Público Empresarial – IPSS 23 DE MARÇO DE](https://www.stts.pt/wp-content/uploads/2026/03/CAPA.png) <small>www.stts.pt</small>Aviso prévio de greve Administração Pública – Setor Público Empresarial – IPSS 23 DE MARÇO DE ...

Dez Razões Para A Greve Geral
-----------------------------

 ![Dez Razões Para a Greve Geral](https://static.wixstatic.com/media/1b0f0b_ae47f5124a53427f9cb76d9abc5ce95a~mv2.jpg/v1/fill/w_490,h_314,al_c,lg_1,q_80/1b0f0b_ae47f5124a53427f9cb76d9abc5ce95a~mv2.jpg) <small>www.sinpacel-rs.com.br</small>Dez Razões Para a Greve Geral

FENPROF Emite Pré-aviso De Greve Para 27 De Outubro De 2023 E Junta-se Ao Protesto Dos
--------------------------------------------------------------------------------------

 ![FENPROF emite pré-aviso de greve para 27 de outubro de 2023 e junta-se ao protesto dos](https://www.spra.pt/wp-content/uploads/2023/10/cartaz-greve-fc-27-outubro-net-1-704x1024.jpg) <small>www.spra.pt</small>FENPROF emite pré-aviso de greve para 27 de outubro de 2023 e junta-se ao protesto dos ...

Pré-avisos De Greves De 2 E 3 De Março 2023
-------------------------------------------

 ![Pré-avisos de Greves de 2 e 3 de março 2023](https://fne.pt/uploads/rte/cartaz_greve_manif_2e3marco2023.jpeg) <small>fne.pt</small>Pré-avisos de Greves de 2 e 3 de março 2023

Greve Nacional De 2 De Dezembro: Transportes, Escolas, Aeroportos... As Informações
-----------------------------------------------------------------------------------

 ![Greve nacional de 2 de dezembro: transportes, escolas, aeroportos... as informações](https://cdn.sortiraparis.com/images/80/1467/1199124-greve-du-2-octobre-les-manifestations-prevues-a-paris-et-en-ile-de-france.jpg) <small>www.sortiraparis.com</small>Greve nacional de 2 de dezembro: transportes, escolas, aeroportos... as informações ...

SPN - Greve Geral Com Forte Expressão Nos Professores (3/jun)
-------------------------------------------------------------

 ![SPN - Greve Geral com forte expressão nos professores (3/jun)](https://www.spn.pt/Media/Default/_Profiles/ee10172b/b4faa2e3/Fenprof — Greve Geral.jpg?v=639147783077642453) <small>www.spn.pt</small>SPN - Greve Geral com forte expressão nos professores (3/jun)

Greve Geral Histórica Em Portugal Paralisa Transportes, Fecha Escolas E Pressiona Hospitais
-------------------------------------------------------------------------------------------

 ![Greve geral histórica em Portugal paralisa transportes, fecha escolas e pressiona hospitais](https://p2.trrsf.com/image/fget/cf/1200/630/middle/images.terra.com/2025/12/11/greve-ubj4bs8ccokh.png) <small>www.terra.com.br</small>Greve geral histórica em Portugal paralisa transportes, fecha escolas e pressiona hospitais

Nacional - FENPROF
------------------

 ![Nacional - FENPROF](https://www.fenprof.pt/media/download/B73B952771368699555DF536CB47A576/grevegeral-3jun26.png?width=800&rxy=0.5) <small>www.fenprof.pt</small>Nacional - FENPROF

Destaques Da Greve Geral - CGTP-IN
----------------------------------

 ![Destaques da Greve Geral - CGTP-IN](https://cgtp.pt/images/images/2026/06/Captura de ecra 2026-06-03 075047.png#joomlaImage:/local-images/images/2026/06/Captura de ecra 2026-06-03 075047.png?width=1342&height=636) <small>www.cgtp.pt</small>Destaques da Greve Geral - CGTP-IN

Greve geral dia 11 dezembro de 2025. greve geral fecha dezenas de escolas na região. Entre o dever de informar e a adesão è greve, sindicato dos jornalistas faz balanço
