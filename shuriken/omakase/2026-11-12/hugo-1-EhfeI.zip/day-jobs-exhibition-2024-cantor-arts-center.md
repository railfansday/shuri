---
title: "Day Jobs Exhibition 2024 Cantor Arts Center - Day jobs"
description: "day jobs"
date: "2026-06-30"
categories:
- "Uncategorized"
images:
- "https://artishockrevista.com/wp-content/uploads/2023/06/23.02.23-Web-Day-Jobs-PR-12.jpg"
featuredImage: "https://news.stanford.edu/__data/assets/image/0027/135585/varieties/750w.jpeg"
featured_image: "https://artishockrevista.com/wp-content/uploads/2023/06/23.02.23-Web-Day-Jobs-PR-12.jpg"
image: "https://cmagazine.org/wp-content/uploads/2024/05/DSC00525-1200x675.jpg"
---

If you are looking for Cantor exhibition examines how day jobs influence art | Stanford Report you've visit to the right place. We have 35 Pictures about Cantor exhibition examines how day jobs influence art | Stanford Report like Day Jobs 2024 — Sandy Rodriguez, Cantor exhibition examines how day jobs influence art | Stanford Report and also Day Jobs | Cantor Arts Center Exhibitions. Here it is:

Cantor Exhibition Examines How Day Jobs Influence Art | Stanford Report
-----------------------------------------------------------------------

 ![Cantor exhibition examines how day jobs influence art | Stanford Report](https://news.stanford.edu/__data/assets/image/0024/135591/varieties/375w.jpeg) <small>news.stanford.edu</small>Cantor exhibition examines how day jobs influence art | Stanford Report

Day Jobs 2024 — Sandy Rodriguez
-------------------------------

 ![Day Jobs 2024 — Sandy Rodriguez](https://images.squarespace-cdn.com/content/v1/59b17be659cc68f4cec27ca8/5e9cb1ff-ffbd-4f8d-b076-438ea79a0264/03-03-2024-Cantor+Arts+Center-Day+Jobs-442.jpg) <small>www.studiosandyrodriguez.com</small>Day Jobs 2024 — Sandy Rodriguez

April 2024 Jobs Day Analysis - Joint Center
-------------------------------------------

 ![April 2024 Jobs Day Analysis - Joint Center](https://jointcenter.org/wp-content/uploads/2023/07/Jobs-Day-April-2024.png) <small>jointcenter.org</small>April 2024 Jobs Day Analysis - Joint Center

Day Jobs | Cantor Arts Center Exhibitions
-----------------------------------------

 ![Day Jobs | Cantor Arts Center Exhibitions](https://museum.stanford.edu/sites/default/files/styles/11_5_md/public/images/2024-03/slide1.jpg?itok=hqZWHXfE) <small>museum.stanford.edu</small>Day Jobs | Cantor Arts Center Exhibitions

'Day Jobs' At Cantor Arts Center: How Artists Earn A Living | Wallpaper\*
-------------------------------------------------------------------------

 !['Day Jobs' at Cantor Arts Center: how artists earn a living | Wallpaper*](https://cdn.mos.cms.futurecdn.net/UqaCEM4FEiCzgJMgtoQbTK-1280-80.jpg) <small>www.wallpaper.com</small>'Day Jobs' at Cantor Arts Center: how artists earn a living | Wallpaper\*

Cantor Exhibition Examines How Day Jobs Influence Art | Stanford Report
-----------------------------------------------------------------------

 ![Cantor exhibition examines how day jobs influence art | Stanford Report](https://news.stanford.edu/__data/assets/image/0025/135592/varieties/750w.jpeg) <small>news.stanford.edu</small>Cantor exhibition examines how day jobs influence art | Stanford Report

Cantor Exhibition Examines How Day Jobs Influence Art | Stanford Report
-----------------------------------------------------------------------

 ![Cantor exhibition examines how day jobs influence art | Stanford Report](https://news.stanford.edu/__data/assets/image/0026/135584/varieties/1024w.jpeg) <small>news.stanford.edu</small>Cantor exhibition examines how day jobs influence art | Stanford Report

Cantor Exhibition Examines How Day Jobs Influence Art | Stanford Report
-----------------------------------------------------------------------

 ![Cantor exhibition examines how day jobs influence art | Stanford Report](https://news.stanford.edu/__data/assets/image/0028/135586/varieties/750w.jpeg) <small>news.stanford.edu</small>Cantor exhibition examines how day jobs influence art | Stanford Report

Day Jobs 2024 — Sandy Rodriguez
-------------------------------

 ![Day Jobs 2024 — Sandy Rodriguez](https://images.squarespace-cdn.com/content/v1/59b17be659cc68f4cec27ca8/744eeb51-e0fa-4392-abe3-da1a6a8c4321/2024-03_Day+Jobs_GC-013-web.jpg) <small>www.studiosandyrodriguez.com</small>Day Jobs 2024 — Sandy Rodriguez

‘Day Jobs’ Looks At How Making A Living Can Inspire Making Art | Cantor Arts Center News
----------------------------------------------------------------------------------------

 ![‘Day Jobs’ looks at how making a living can inspire making art | Cantor Arts Center News](https://museum.stanford.edu/sites/default/files/styles/width_constrained_md/public/images/2024-03/legaltender-photo-narsiso-800w.jpg?itok=FVGaDfAz) <small>museum.stanford.edu</small>‘Day Jobs’ looks at how making a living can inspire making art | Cantor Arts Center News

Day Jobs | Cantor Arts Center Exhibitions
-----------------------------------------

 ![Day Jobs | Cantor Arts Center Exhibitions](https://museum.stanford.edu/sites/default/files/styles/11_5_md/public/images/2024-03/slide3.jpg?itok=kRzp2fz5) <small>museum.stanford.edu</small>Day Jobs | Cantor Arts Center Exhibitions

At The Blanton, Artists Find The Sublime At Whataburger And The Supreme Court
-----------------------------------------------------------------------------

 ![At the Blanton, Artists Find the Sublime at Whataburger and the Supreme Court](https://img.texasmonthly.com/2023/04/day-jobs-blanton-austin.jpg?auto=compress&crop=faces&fit=scale&fm=pjpg&h=640&ixlib=php-3.3.1&q=45&w=1024&wpsize=large) <small>www.texasmonthly.com</small>At the Blanton, Artists Find the Sublime at Whataburger and the Supreme Court

An Artist’s Success Is Often Tied To Their Status As Full-time Artists. The Current Exhibition
----------------------------------------------------------------------------------------------

 ![An artist’s success is often tied to their status as full-time artists. The current exhibition](https://media.licdn.com/dms/image/v2/D5622AQEbjKZsPSLzAg/feedshare-shrink_800/feedshare-shrink_800/0/1720211407703?e=2147483647&v=beta&t=tRGHxekSBWLpmTVbLGI7UmVIj4a97muVfGTr17E1v6k) <small>www.linkedin.com</small>An artist’s success is often tied to their status as full-time artists. The current exhibition ...

Day Jobs | Cantor Arts Center Exhibitions
-----------------------------------------

 ![Day Jobs | Cantor Arts Center Exhibitions](https://museum.stanford.edu/sites/default/files/images/2024-05/666a9382.jpg) <small>museum.stanford.edu</small>Day Jobs | Cantor Arts Center Exhibitions

Resources For Visitors To Campus - Stanford Arts
------------------------------------------------

 ![Resources for Visitors to Campus - Stanford Arts](https://arts.stanford.edu/wp-content/uploads/bb-plugin/cache/20191220_Cantor_OYYO-6508-square.jpg) <small>arts.stanford.edu</small>Resources for Visitors to Campus - Stanford Arts

Day Job At Cantor Arts Center
-----------------------------

 ![Day Job at Cantor Arts Center](https://www.metrosiliconvalley.com/wp-content/uploads/sites/16/2024/03/ARTS-MSV2410-Martinez-LegalTender.jpg) <small>www.metrosiliconvalley.com</small>Day Job at Cantor Arts Center

Day Jobs - The Brooklyn Rail
----------------------------

 ![Day Jobs - The Brooklyn Rail](https://brooklynrail.org/_next/image/?url=https:%2F%2Fstudio.brooklynrail.org%2Fassets%2Fb2f82f2a-4732-4155-920a-36876c66bff1&w=3840&q=75) <small>brooklynrail.org</small>Day Jobs - The Brooklyn Rail

Cantor Exhibition Examines How Day Jobs Influence Art | Stanford Report
-----------------------------------------------------------------------

 ![Cantor exhibition examines how day jobs influence art | Stanford Report](https://news.stanford.edu/__data/assets/image/0026/135593/20240307_Day_job_n6a3905.jpeg) <small>news.stanford.edu</small>Cantor exhibition examines how day jobs influence art | Stanford Report

Cantor Exhibition Examines How Day Jobs Influence Art | Stanford Report
-----------------------------------------------------------------------

 ![Cantor exhibition examines how day jobs influence art | Stanford Report](https://news.stanford.edu/__data/assets/image/0030/135588/varieties/1024w.jpeg) <small>news.stanford.edu</small>Cantor exhibition examines how day jobs influence art | Stanford Report

Day Jobs | Cantor Arts Center Exhibitions
-----------------------------------------

 ![Day Jobs | Cantor Arts Center Exhibitions](https://museum.stanford.edu/sites/default/files/images/2024-05/666a9383.jpg) <small>museum.stanford.edu</small>Day Jobs | Cantor Arts Center Exhibitions

Day Jobs | Cantor Arts Center Exhibitions
-----------------------------------------

 ![Day Jobs | Cantor Arts Center Exhibitions](https://museum.stanford.edu/sites/default/files/images/2024-05/666a9247.jpg) <small>museum.stanford.edu</small>Day Jobs | Cantor Arts Center Exhibitions

‘Day Jobs’ Wants To Dispel Romantic Notions Of Art Making | KQED
----------------------------------------------------------------

 ![‘Day Jobs’ Wants to Dispel Romantic Notions of Art Making | KQED](https://cdn.kqed.org/wp-content/uploads/sites/2/2024/04/2024-03_Day-Jobs_GC-029-web.jpg) <small>www.kqed.org</small>‘Day Jobs’ Wants to Dispel Romantic Notions of Art Making | KQED

Cantor Exhibition Examines How Day Jobs Influence Art | Stanford Report
-----------------------------------------------------------------------

 ![Cantor exhibition examines how day jobs influence art | Stanford Report](https://news.stanford.edu/__data/assets/image/0023/135590/20240307_Day_job_n6a3965.jpeg) <small>news.stanford.edu</small>Cantor exhibition examines how day jobs influence art | Stanford Report

Cantor Exhibition Examines How Day Jobs Influence Art | Stanford Report
-----------------------------------------------------------------------

 ![Cantor exhibition examines how day jobs influence art | Stanford Report](https://news.stanford.edu/__data/assets/image/0022/135562/varieties/400w.jpeg) <small>news.stanford.edu</small>Cantor exhibition examines how day jobs influence art | Stanford Report

On View At The Cantor Arts Center: Day Jobs – C Magazine
--------------------------------------------------------

 ![On View at the Cantor Arts Center: Day Jobs – C Magazine](https://cmagazine.org/wp-content/uploads/2024/05/DSC00540.jpg) <small>cmagazine.org</small>On View at the Cantor Arts Center: Day Jobs – C Magazine

‘Day Jobs’ Wants To Dispel Romantic Notions Of Art Making | KQED
----------------------------------------------------------------

 ![‘Day Jobs’ Wants to Dispel Romantic Notions of Art Making | KQED](https://cdn.kqed.org/wp-content/uploads/sites/2/2024/04/2024-03_Day-Jobs_GC-012-web-1020x680.jpg) <small>www.kqed.org</small>‘Day Jobs’ Wants to Dispel Romantic Notions of Art Making | KQED

Day Jobs | Cantor Arts Center Exhibitions
-----------------------------------------

 ![Day Jobs | Cantor Arts Center Exhibitions](https://museum.stanford.edu/sites/default/files/styles/11_5_md/public/images/2024-03/slide4.jpg?itok=_Rfkf6iQ) <small>museum.stanford.edu</small>Day Jobs | Cantor Arts Center Exhibitions

Day Jobs | Cantor Arts Center Exhibitions
-----------------------------------------

 ![Day Jobs | Cantor Arts Center Exhibitions](https://museum.stanford.edu/sites/default/files/images/2024-05/666a9249.jpg) <small>museum.stanford.edu</small>Day Jobs | Cantor Arts Center Exhibitions

Cantor Exhibition Examines How Day Jobs Influence Art | Stanford Report
-----------------------------------------------------------------------

 ![Cantor exhibition examines how day jobs influence art | Stanford Report](https://news.stanford.edu/__data/assets/image/0027/135594/20240307_Day_Job_N6A3897.jpg) <small>news.stanford.edu</small>Cantor exhibition examines how day jobs influence art | Stanford Report

Day Jobs | Cantor Arts Center Exhibitions
-----------------------------------------

 ![Day Jobs | Cantor Arts Center Exhibitions](https://museum.stanford.edu/sites/default/files/styles/11_5_md/public/images/2024-03/slide2.jpg?itok=WPkAOLHx) <small>museum.stanford.edu</small>Day Jobs | Cantor Arts Center Exhibitions

‘Day Jobs’ Wants To Dispel Romantic Notions Of Art Making | KQED
----------------------------------------------------------------

 ![‘Day Jobs’ Wants to Dispel Romantic Notions of Art Making | KQED](https://cdn.kqed.org/wp-content/uploads/sites/2/2024/04/2024-03_Day-Jobs_GC-089-web.jpg) <small>www.kqed.org</small>‘Day Jobs’ Wants to Dispel Romantic Notions of Art Making | KQED

Stanford Report On “Day Jobs” At The Cantor Arts Center Feat. Narsiso Martinez And Jay Lynn
-------------------------------------------------------------------------------------------

 ![Stanford Report on “Day Jobs” at the Cantor Arts Center feat. Narsiso Martinez and Jay Lynn](http://static1.squarespace.com/static/5fa196c157852a3ac79f4c49/60cb978468b25779b33534fd/65f369e0c7eeee0ddd02de88/1710541951835/Screenshot+2024-03-14+at+2.20.27+PM.png?format=1500w) <small>www.cjamesgallery.com</small>Stanford Report on “Day Jobs” at the Cantor Arts Center feat. Narsiso Martinez and Jay Lynn ...

Cantor Exhibition Examines How Day Jobs Influence Art | Stanford Report
-----------------------------------------------------------------------

 ![Cantor exhibition examines how day jobs influence art | Stanford Report](https://news.stanford.edu/__data/assets/image/0027/135585/varieties/750w.jpeg) <small>news.stanford.edu</small>Cantor exhibition examines how day jobs influence art | Stanford Report

DAY JOBS - Artishock Revista
----------------------------

 ![DAY JOBS - Artishock Revista](https://artishockrevista.com/wp-content/uploads/2023/06/23.02.23-Web-Day-Jobs-PR-12.jpg) <small>artishockrevista.com</small>DAY JOBS - Artishock Revista

On View At The Cantor Arts Center: Day Jobs – C Magazine
--------------------------------------------------------

 ![On View at the Cantor Arts Center: Day Jobs – C Magazine](https://cmagazine.org/wp-content/uploads/2024/05/DSC00525-1200x675.jpg) <small>cmagazine.org</small>On View at the Cantor Arts Center: Day Jobs – C Magazine

day jobs. On view at the cantor arts center: day jobs – c magazine. day jobs
