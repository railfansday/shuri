---
title: "Vitinha Stats Pes - Vítor machado ferreira pes 2021 stats"
description: "Tottenham star left frank &quot;raging&quot; at psg, he won&#039;t be playing against fulham"
date: "2026-05-11"
categories:
- "Uncategorized"
images:
- "https://pbs.twimg.com/media/HHtmzbAXAAMuj0_.jpg"
featuredImage: "https://static0.footballfancastimages.com/wordpress/wp-content/uploads/2025/11/vitinha-vs-spurs-stats.jpg?q=49&amp;fit=crop&amp;w=825&amp;dpr=2"
featured_image: "https://storage.ko-fi.com/cdn/useruploads/display/c00bccd8-8191-436a-9efc-2840b7e30a3a_vitinnhaa.jpg"
image: "https://i.ytimg.com/vi/gkPgWa1CnPY/maxresdefault.jpg"
---

If you are looking for Best in the world? Vitinha tops four major metrics against top midfielders in 2025/26 Champions you've visit to the right place. We have 35 Images about Best in the world? Vitinha tops four major metrics against top midfielders in 2025/26 Champions like Tottenham star left Frank "raging" at PSG, he won't be playing against Fulham, Vítinha eFootball 2022 Stats and also Vitinha Footballer Career Stats. Here you go:

Best In The World? Vitinha Tops Four Major Metrics Against Top Midfielders In 2025/26 Champions
-----------------------------------------------------------------------------------------------

 ![Best in the world? Vitinha tops four major metrics against top midfielders in 2025/26 Champions](https://pictures.tribuna.com/image/cec6ec05-b9db-482d-86b2-a15d4a365640?width=1920&quality=70) <small>tribuna.com</small>Best in the world? Vitinha tops four major metrics against top midfielders in 2025/26 Champions ...

PES 2021 Vitinha 2025 By Nach Facemaker, патчи и моды
-----------------------------------------------------

 ![PES 2021 Vitinha 2025 by Nach Facemaker, патчи и моды](https://pes-files.ru/_ld/645/07244851.jpg) <small>pes-files.ru</small>PES 2021 Vitinha 2025 by Nach Facemaker, патчи и моды

\[FACES\] PES 2021 Editor Game By Maquiavelo40 | Page 27 | Soccer Gaming
------------------------------------------------------------------------

 ![[FACES] PES 2021 editor game by maquiavelo40 | Page 27 | Soccer Gaming](https://soccergaming.com/forums/attachments/vitinha-jpg.214458/) <small>soccergaming.com</small>\[FACES\] PES 2021 editor game by maquiavelo40 | Page 27 | Soccer Gaming

Vitinha Ferreira @TiagoDiasPES (Porto, Wolverhampton, PSG) Face + Stats | PES 2021 - YouTube
--------------------------------------------------------------------------------------------

 ![Vitinha Ferreira @TiagoDiasPES (Porto, Wolverhampton, PSG) Face + Stats | PES 2021 - YouTube](https://i.ytimg.com/vi/4Qkeh5RudYg/maxresdefault.jpg) <small>www.youtube.com</small>Vitinha Ferreira @TiagoDiasPES (Porto, Wolverhampton, PSG) Face + Stats | PES 2021 - YouTube

Vitinha-fc-26 - Operation Sports
--------------------------------

 ![vitinha-fc-26 - Operation Sports](https://www.operationsports.com/wp-content/uploads/2025/09/vitinha-fc-26.jpg) <small>www.operationsports.com</small>vitinha-fc-26 - Operation Sports

KlipDraw | ¿Quién Es Vitinha, El Nuevo Jugador Del PSG?
-------------------------------------------------------

 ![KlipDraw | ¿Quién es Vitinha, el nuevo jugador del PSG?](https://www.klipdraw.com/blog/laravel-filemanager/photos/shares/2022/Vitinha PSG/Vitinha_Stats.PNG) <small>www.klipdraw.com</small>KlipDraw | ¿Quién es Vitinha, el nuevo jugador del PSG?

The Best Central Midfielders With High Potential In EA Sports FC 25: Career Mode
--------------------------------------------------------------------------------

 ![The Best Central Midfielders With High Potential In EA Sports FC 25: Career Mode](https://static1.thegamerimages.com/wordpress/wp-content/uploads/2024/10/vitinha-and-his-stats-in-ea-fc25.jpg) <small>www.thegamer.com</small>The Best Central Midfielders With High Potential In EA Sports FC 25: Career Mode

Vitinha - PES 2021 (PC MOD) - Buymeacoffee
------------------------------------------

 ![Vitinha - PES 2021 (PC MOD) - Buymeacoffee](https://img.buymeacoffee.com/api/?extras=dXJsPSZjcmVhdG9yPUpvNyUyMEZhY2VtYWtlciZkZXNpZ25fY29kZT0yJmRlc2lnbl9jb2xvcj0lMjM1RjdGRkYmc2x1Zz1KbzdGYWNlbWFrZXImaXNfY3JlYXRpbmc9Q3JlYXRpbmclMjBFZm9vdGJhbGwlMjBQRVMlMjBhbmQlMjBGSUZBJTIwZmFjZXMmZXh0cmFzX3RpdGxlPVZtbDBhVzVvWVNBdElGQkZVeUF5TURJeElDaFFReUJOVDBRcCZleHRyYXNfaW1hZ2U9YUhSMGNITTZMeTlqWkc0dVluVjViV1ZoWTI5bVptVmxMbU52YlM5MWNHeHZZV1J6TDNKbGQyRnlaSE12TWpBeU15MHdOUzB4TWk4eEx6RTNORE15TWw5RFQwWkdSUzV3Ym1kQU16QXdkMTh3WlM1M1pXSnc=) <small>www.buymeacoffee.com</small>Vitinha - PES 2021 (PC MOD) - Buymeacoffee

Vitinha EA FC 24 Ratings, Prices, And Cards - FUT.GG
----------------------------------------------------

 ![Vitinha EA FC 24 Ratings, Prices, and Cards - FUT.GG](https://game-assets.fut.gg/2024/new2-social-images/255253.5.webp?quality=100) <small>www.fut.gg</small>Vitinha EA FC 24 Ratings, Prices, and Cards - FUT.GG

🚨 119 OVR VITINHA STATS 🚨 177 Pace ⚡ 193 Passing 🎯 190 Dribbling 🥶 161 Defending 🛡️ Bro Is
------------------------------------------------------------------------------------------

 ![🚨 119 OVR VITINHA STATS 🚨 177 Pace ⚡ 193 Passing 🎯 190 Dribbling 🥶 161 Defending 🛡️ Bro is](https://pbs.twimg.com/media/HHpzrV_akAA6FoH.jpg) <small>x.com</small>🚨 119 OVR VITINHA STATS 🚨 177 Pace ⚡ 193 Passing 🎯 190 Dribbling 🥶 161 Defending 🛡️ Bro is ...

FlashFocus: Little Maestro Vitinha Reaching New Levels With PSG | Flashscore.co.uk
----------------------------------------------------------------------------------

 ![FlashFocus: Little maestro Vitinha reaching new levels with PSG | Flashscore.co.uk](https://livesport-ott-images.ssl.cdn.cra.cz/r900xfq60/b62aca49-901d-4cae-8693-98245edd49d9.jpg) <small>www.flashscore.co.uk</small>FlashFocus: Little maestro Vitinha reaching new levels with PSG | Flashscore.co.uk

Acualización STATS - Vitinha PES2013 (PSG / Portugal)🇵🇹 - YouTube
-----------------------------------------------------------------

 ![Acualización STATS - Vitinha PES2013 (PSG / Portugal)🇵🇹 - YouTube](https://i.ytimg.com/vi/gkPgWa1CnPY/maxresdefault.jpg) <small>www.youtube.com</small>Acualización STATS - Vitinha PES2013 (PSG / Portugal)🇵🇹 - YouTube

Vitinha Biography, Age, Height, PSG Career, Stats &amp; Net Worth
-----------------------------------------------------------------

 ![Vitinha Biography, Age, Height, PSG Career, Stats & Net Worth](https://playersbiography.com/wp-content/uploads/2026/06/Vitinha.png) <small>playersbiography.com</small>Vitinha Biography, Age, Height, PSG Career, Stats &amp; Net Worth

PEDRI ️ VITINHA 📊 Max Out Stats 🔥
---------------------------------

 ![PEDRI ️ VITINHA 📊 Max out stats 🔥](https://pbs.twimg.com/media/HINbdg5aQAATu-4.jpg) <small>x.com</small>PEDRI ️ VITINHA 📊 Max out stats 🔥

101 Rated Vitinha Best Training Guide - How To Train Vitinha In Efootball/PES 2026 - YouTube
--------------------------------------------------------------------------------------------

 ![101 Rated Vitinha Best Training Guide - How to train Vitinha in efootball/PES 2026 - YouTube](https://i.ytimg.com/vi/h7uSlOIsNK4/maxresdefault.jpg) <small>www.youtube.com</small>101 Rated Vitinha Best Training Guide - How to train Vitinha in efootball/PES 2026 - YouTube

Tottenham Star Left Frank "raging" At PSG, He Won't Be Playing Against Fulham
-----------------------------------------------------------------------------

 ![Tottenham star left Frank "raging" at PSG, he won't be playing against Fulham](https://static0.footballfancastimages.com/wordpress/wp-content/uploads/2025/11/vitinha-vs-spurs-stats.jpg?q=49&fit=crop&w=825&dpr=2) <small>www.footballfancast.com</small>Tottenham star left Frank "raging" at PSG, he won't be playing against Fulham

PES 2017 | \[Vitinha\] New Face Update 2026 - Ultra Realistic - YouTube
-----------------------------------------------------------------------

 ![PES 2017 | [Vitinha] New Face Update 2026 - Ultra Realistic - YouTube](https://i.ytimg.com/vi/WAGBv_OJWGQ/maxresdefault.jpg) <small>www.youtube.com</small>PES 2017 | \[Vitinha\] New Face Update 2026 - Ultra Realistic - YouTube

Wolves Fans’ Response To Vitinha Hat-trick Sums Everything Up Perfectly
-----------------------------------------------------------------------

 ![Wolves fans’ response to Vitinha hat-trick sums everything up perfectly](https://cdn1.molineux.news/uploads/2/2025/04/vitinha-517x750.jpg) <small>www.molineux.news</small>Wolves fans’ response to Vitinha hat-trick sums everything up perfectly

PES 2021 Vitinha #16.05.25 By Valentinlgs10, патчи и моды
---------------------------------------------------------

 ![PES 2021 Vitinha #16.05.25 by Valentinlgs10, патчи и моды](https://pes-files.ru/_ld/646/78060250.jpg) <small>pes-files.ru</small>PES 2021 Vitinha #16.05.25 by Valentinlgs10, патчи и моды

FREE Vitinha Progression Guide! Max Stats Build In EFootball #vitinha #psg #portugal #
--------------------------------------------------------------------------------------

 ![FREE Vitinha Progression Guide! Max Stats Build in eFootball #vitinha #psg #portugal #](https://i.ytimg.com/vi/BkQKuv653NE/oar2.jpg?sqp=-oaymwEkCJUDENAFSFqQAgHyq4qpAxMIARUAAAAAJQAAyEI9AICiQ3gB&rs=AOn4CLAnPQUlnPxyACFXxS4sgd9Y5_zXng&usqp=CCk) <small>www.youtube.com</small>FREE Vitinha Progression Guide! Max Stats Build in eFootball #vitinha #psg #portugal # ...

Vitinha - Peslife.id's Ko-fi Shop
---------------------------------

 ![Vitinha - Peslife.id's Ko-fi Shop](https://storage.ko-fi.com/cdn/useruploads/display/a6cc8384-6752-4c52-9d08-0d0a8973aa8d_1744024256525.jpg) <small>ko-fi.com</small>Vitinha - Peslife.id's Ko-fi Shop

Vítor Machado Ferreira PES 2021 Stats
-------------------------------------

 ![Vítor Machado Ferreira PES 2021 Stats](https://www.pesmaster.com/vitinha/pes-2021/player/135067/image.jpg) <small>www.pesmaster.com</small>Vítor Machado Ferreira PES 2021 Stats

Vitinha Footballer Career Stats
-------------------------------

 ![Vitinha Footballer Career Stats](https://lookaside.instagram.com/seo/google_widget/crawler/?media_id=3771596063749449771) <small>www.instagram.com</small>Vitinha Footballer Career Stats

Valoraciones De Futbolista: Vitinha En EA SPORTS FC™ 25
-------------------------------------------------------

 ![Valoraciones de futbolista: Vitinha en EA SPORTS FC™ 25](https://ratings-images-prod.pulse.ea.com/FC25/full/player-shields/es/255253.png?width=265) <small>www.ea.com</small>Valoraciones de futbolista: Vitinha en EA SPORTS FC™ 25

FACE DE VITINHA PARA PES 21 - SamuelLapetina's Ko-fi Shop
---------------------------------------------------------

 ![FACE DE VITINHA PARA PES 21 - SamuelLapetina's Ko-fi Shop](https://storage.ko-fi.com/cdn/useruploads/display/c00bccd8-8191-436a-9efc-2840b7e30a3a_vitinnhaa.jpg) <small>ko-fi.com</small>FACE DE VITINHA PARA PES 21 - SamuelLapetina's Ko-fi Shop

Vitinha EA FC 26 Ratings, Prices &amp; Cards - FUT.GG
-----------------------------------------------------

 ![Vitinha EA FC 26 Ratings, Prices & Cards - FUT.GG](https://game-assets.fut.gg/cdn-cgi/image/quality=85,format=auto,width=300/2025/futgg-player-item-card/25-100918549.a7dc253b0ea22db0d83ed5d4c7050d3c994c362e0f4b8385b8bfa15122d7ac4c.webp) <small>www.fut.gg</small>Vitinha EA FC 26 Ratings, Prices &amp; Cards - FUT.GG

Vitinha By Kodigo Facemaker (PES 2021) - Kodigo Facemaker's Ko-fi Shop
----------------------------------------------------------------------

 ![Vitinha by Kodigo Facemaker (PES 2021) - Kodigo Facemaker's Ko-fi Shop](https://storage.ko-fi.com/cdn/useruploads/display/fa391a74-bb45-4746-9947-4a086982edc4_preview1.png) <small>ko-fi.com</small>Vitinha by Kodigo Facemaker (PES 2021) - Kodigo Facemaker's Ko-fi Shop

Vitinha EA FC 26 Ratings, Prices, And Cards - FUT.GG
----------------------------------------------------

 ![Vitinha EA FC 26 Ratings, Prices, and Cards - FUT.GG](https://game-assets.fut.gg/cdn-cgi/image/quality=100,format=auto/2025/player-item-social-small/25-255253.b9f7895fabd283f72589e387c1694ee0873fef7e3e318b6e6ac0d5e91ff80378.webp) <small>www.fut.gg</small>Vitinha EA FC 26 Ratings, Prices, and Cards - FUT.GG

فیس Vitinha برای PES 2021 - آپدیت 24 اردیبهشت 1404 | مودینگ وی
--------------------------------------------------------------

 ![فیس Vitinha برای PES 2021 - آپدیت 24 اردیبهشت 1404 | مودینگ وی](https://moddingway.ir/wp-content/uploads/2025/05/PES-2021-Face-Vitinha-2025-By-Nach-Facemaker.png) <small>moddingway.ir</small>فیس Vitinha برای PES 2021 - آپدیت 24 اردیبهشت 1404 | مودینگ وی

KlipDraw | ¿Quién Es Vitinha, El Nuevo Jugador Del PSG?
-------------------------------------------------------

 ![KlipDraw | ¿Quién es Vitinha, el nuevo jugador del PSG?](https://www.klipdraw.com/blog/laravel-filemanager/photos/shares/2022/Vitinha PSG/Vitinha_PSG.PNG) <small>www.klipdraw.com</small>KlipDraw | ¿Quién es Vitinha, el nuevo jugador del PSG?

How To Train 105 Rated Vitinha In EFootball 2025, Vitinha Best Training Guide In Pes 2025 - YouTube
---------------------------------------------------------------------------------------------------

 ![How to train 105 rated Vitinha in eFootball 2025, Vitinha Best Training Guide in Pes 2025 - YouTube](https://i.ytimg.com/vi/4Vs-VnyKoC4/maxresdefault.jpg) <small>www.youtube.com</small>How to train 105 rated Vitinha in eFootball 2025, Vitinha Best Training Guide in Pes 2025 - YouTube

UEFA Champions League: Mbappe Bags Four Goals As Vitinha Stars For PSG | Flashscore.com
---------------------------------------------------------------------------------------

 ![UEFA Champions League: Mbappe bags four goals as Vitinha stars for PSG | Flashscore.com](https://livesport-ott-images.ssl.cdn.cra.cz/r900xfq60/b787e292-0558-4f11-86ae-860f9e3a8726.jpg) <small>www.flashscore.com</small>UEFA Champions League: Mbappe bags four goals as Vitinha stars for PSG | Flashscore.com

Vítinha EFootball 2022 Stats
----------------------------

 ![Vítinha eFootball 2022 Stats](https://www.pesmaster.com/ja/vitinha/efootball-2022/player/141885/image.jpg) <small>www.pesmaster.com</small>Vítinha eFootball 2022 Stats

📊 Pedri 🆚 Vitinha - Club Stats This Season: 🇪🇸 Pedri: 👕 40 Games ⚽️ 2 Goals 🎯 11 Assists 😳 76
---------------------------------------------------------------------------------------------

 ![📊 Pedri 🆚 Vitinha - Club Stats This Season: 🇪🇸 Pedri: 👕 40 games ⚽️ 2 goals 🎯 11 assists 😳 76](https://pbs.twimg.com/media/HHtmzbAXAAMuj0_.jpg) <small>x.com</small>📊 Pedri 🆚 Vitinha - Club Stats This Season: 🇪🇸 Pedri: 👕 40 games ⚽️ 2 goals 🎯 11 assists 😳 76 ...

How PSG Backed Vitinha Over Messi And Neymar To Become World's Best | Transfermarkt
-----------------------------------------------------------------------------------

 ![How PSG backed Vitinha over Messi and Neymar to become world's best | Transfermarkt](https://tmssl.akamaized.net/images/foto/newsansicht/vit-stats-1746614261-167352.png?lm=1746614267) <small>www.transfermarkt.com</small>How PSG backed Vitinha over Messi and Neymar to become world's best | Transfermarkt

How psg backed vitinha over messi and neymar to become world's best. Free vitinha progression guide! max stats build in efootball #vitinha #psg #portugal #. فیس vitinha برای pes 2021
