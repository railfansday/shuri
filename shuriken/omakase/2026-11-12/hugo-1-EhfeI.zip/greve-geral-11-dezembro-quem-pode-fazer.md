---
title: "Greve Geral 11 Dezembro Quem Pode Fazer - Perguntas e respostas sobre a greve geral de 11 de dezembro"
description: "Faq: os direitos dos docentes em dia de greve geral"
date: "2025-11-21"
categories:
- "Uncategorized"
images:
- "https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA1S3Lgf.img?w=768&amp;h=512&amp;m=6"
featuredImage: "https://cdn.sabado.pt/images/2013-05/img_1920x1080uu2013-05-30-19-15-03-73602.jpg"
featured_image: "https://www.spgl.pt/Media/Default/_Profiles/dd11bcb9/fe448ac2/greve.png?v=639011538614519944"
image: "https://www.acoliveira.pt/wp-content/uploads/2025/12/11.png"
---

If you are looking for SPGL - Greve Geral de 11 de dezembro | Saudação a todos os Educadores, Professores e Investigadores you've came to the right page. We have 35 Images about SPGL - Greve Geral de 11 de dezembro | Saudação a todos os Educadores, Professores e Investigadores like SPN - Fenprof — Adesão histórica à greve geral, SINDEP - Greve Geral 11 de dezembro and also Mais de 50 sindicatos aderem à greve geral marcada para 11 de dezembro. Here you go:

SPGL - Greve Geral De 11 De Dezembro | Saudação A Todos Os Educadores, Professores E Investigadores
---------------------------------------------------------------------------------------------------

 ![SPGL - Greve Geral de 11 de dezembro | Saudação a todos os Educadores, Professores e Investigadores](https://www.spgl.pt/Media/Default/_Profiles/dd11bcb9/fe448ac2/greve.png?v=639011538614519944) <small>www.spgl.pt</small>SPGL - Greve Geral de 11 de dezembro | Saudação a todos os Educadores, Professores e Investigadores

UGT - UGT Convoca Greve Geral Para 11 De Dezembro De 2025
---------------------------------------------------------

 ![UGT - UGT convoca Greve Geral para 11 de dezembro de 2025](https://www.ugt.pt/publicfiles/dvc3keu4ex9l4e2fizbuignqdef3jdmrhdwzogyd.png) <small>www.ugt.pt</small>UGT - UGT convoca Greve Geral para 11 de dezembro de 2025

SPGL - Greve Geral | 11 De Dezembro De 2025 (Piquetes, Concentrações E Manifestações)
-------------------------------------------------------------------------------------

 ![SPGL - Greve Geral | 11 de dezembro de 2025 (Piquetes, Concentrações e Manifestações)](https://www.spgl.pt/Media/Default/_Profiles/722d2b7d/68bcf4e1/IMG_2694.JPG?v=639010778412646835) <small>www.spgl.pt</small>SPGL - Greve Geral | 11 de dezembro de 2025 (Piquetes, Concentrações e Manifestações)

SPN - Fenprof — Adesão Histórica à Greve Geral
----------------------------------------------

 ![SPN - Fenprof — Adesão histórica à greve geral](https://www.spn.pt/Media/Default/_Profiles/ee10172b/82507d9/grevefenprof (6).jpeg?v=639010548582441113) <small>www.spn.pt</small>SPN - Fenprof — Adesão histórica à greve geral

Saiba Tudo Sobre A Greve Geral De Amanhã
----------------------------------------

 ![Saiba tudo sobre a greve geral de Amanhã](https://jornaldemafra.pt/wp-content/uploads/2025/12/greve-geral.webp) <small>jornaldemafra.pt</small>Saiba tudo sobre a greve geral de Amanhã

SINDEP - Greve Geral 11 De Dezembro
-----------------------------------

 ![SINDEP - Greve Geral 11 de dezembro](https://sindep.pt/images/cartaz_GREVE_GERAL_UGT.jpg) <small>sindep.pt</small>SINDEP - Greve Geral 11 de dezembro

Maioria Dos Portugueses Diz Que Greve Geral Foi Justificada - Portugal - SÁBADO
-------------------------------------------------------------------------------

 ![Maioria dos portugueses diz que greve geral foi justificada - Portugal - SÁBADO](https://cdn.sabado.pt/images/2025-12/img_980x653uu2025-12-22-09-03-14-753915.jpg) <small>www.sabado.pt</small>Maioria dos portugueses diz que greve geral foi justificada - Portugal - SÁBADO

GREVE GERAL DIA 11 DEZEMBRO DE 2025 | FESAHT
--------------------------------------------

 ![GREVE GERAL DIA 11 DEZEMBRO DE 2025 | FESAHT](https://sindicatos.cgtp.pt/fesaht/wp-content/blogs.dir/52/files/sites/52/2025/12/11-DEZ-faz-greve-e-sai-a-Rua.jpg) <small>sindicatos.cgtp.pt</small>GREVE GERAL DIA 11 DEZEMBRO DE 2025 | FESAHT

Fertagus &gt; Fertagus (pt) &gt; Viajar &gt; Comunicados E Campanhas &gt; Greve Geral 11 De Dezembro De 2025
------------------------------------------------------------------------------------------------------------

 ![Fertagus > Fertagus (pt) > Viajar > Comunicados e Campanhas > Greve Geral 11 de dezembro de 2025](https://www.fertagus.pt/portals/0/FTG-Greve-Geral-web-1253x886.jpg) <small>www.fertagus.pt</small>Fertagus &gt; Fertagus (pt) &gt; Viajar &gt; Comunicados e Campanhas &gt; Greve Geral 11 de dezembro de 2025

Mais De 50 Sindicatos Aderem à Greve Geral Marcada Para 11 De Dezembro
----------------------------------------------------------------------

 ![Mais de 50 sindicatos aderem à greve geral marcada para 11 de dezembro](https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA1QBjfX.img?w=1200&h=800&m=4&q=70) <small>www.msn.com</small>Mais de 50 sindicatos aderem à greve geral marcada para 11 de dezembro

Greve Histórica Em Portugal: Três Milhões Cruzam Os Braços Em Protesto Contra Medidas De
----------------------------------------------------------------------------------------

 ![Greve histórica em Portugal: três milhões cruzam os braços em protesto contra medidas de](https://ogimg.infoglobo.com.br/in/2920985-315-96f/FT1086A/Manifestante-no-Centro-de-Lisboa-na-primeira-greve-geral-em-mais-de-duas-decadasFrancisco-LeongAFP.jpg) <small>oglobo.globo.com</small>Greve histórica em Portugal: três milhões cruzam os braços em protesto contra medidas de ...

CIL Apoia A Greve Geral Do Próximo Dia 11 De Dezembro - CGTP-IN
---------------------------------------------------------------

 ![CIL apoia a Greve Geral do próximo dia 11 de Dezembro - CGTP-IN](https://www.cgtp.pt/images/accao-e-luta/2025/54909309207_62b0afa28f_o1.jpg) <small>www.cgtp.pt</small>CIL apoia a Greve Geral do próximo dia 11 de Dezembro - CGTP-IN

Greve Geral Pode Custar 792 Milhões De Euros à Economia - JN
------------------------------------------------------------

 ![Greve geral pode custar 792 milhões de euros à economia - JN](https://staticx.noticiasilimitadas.pt/jn/image.webp?brand=jn&type=generate&guid=fb434b13-2b30-4ab1-a6bc-4ddd86b96b14&w=3840) <small>www.jn.pt</small>Greve geral pode custar 792 milhões de euros à economia - JN

Agrupamento De Escolas De Mira - Pré - Aviso De Greve Para Os Dias 11 E 12 De Dezembro De 2025
----------------------------------------------------------------------------------------------

 ![Agrupamento de Escolas de Mira - Pré - aviso de greve para os dias 11 e 12 de dezembro de 2025](https://www.escolasdemira.pt/images/PR-_AVISO_DE_GREVE_para_os_dias_11_e_12_de_dezembro_de_2025.png) <small>www.escolasdemira.pt</small>Agrupamento de Escolas de Mira - Pré - aviso de greve para os dias 11 e 12 de dezembro de 2025

📢 GREVE GERAL — 11 DE DEZEMBRO POSSO FAZER GREVE? Sim. E é Importante Que Saibas Porquê. Todos
----------------------------------------------------------------------------------------------

 ![📢 GREVE GERAL — 11 DE DEZEMBRO POSSO FAZER GREVE? Sim. E é importante que saibas porquê. Todos](https://lookaside.fbsbx.com/lookaside/crawler/media/?media_id=1185258557072905) <small>www.facebook.com</small>📢 GREVE GERAL — 11 DE DEZEMBRO POSSO FAZER GREVE? Sim. E é importante que saibas porquê. Todos ...

TCB | Pré-aviso De Greve A 11 De Dezembro - Portal Institucional
----------------------------------------------------------------

 ![TCB | Pré-aviso de greve a 11 de dezembro - Portal Institucional](https://www.cm-barreiro.pt/wp-content/uploads/2025/12/GREVE-11_DEZEMBRO_1920px-1536x920.jpg) <small>www.cm-barreiro.pt</small>TCB | Pré-aviso de greve a 11 de dezembro - Portal Institucional

Informações | Greve Geral De 11 Dezembro
----------------------------------------

 ![Informações | Greve Geral de 11 dezembro](https://fne.pt/uploads/noticias/big_1764325137_7603_InfoGreve.jpeg) <small>fne.pt</small>Informações | Greve Geral de 11 dezembro

Greve Geral: Quem Pode Aderir, O Que Muda No Salário E O Que Vai Estar A Funcionar - JN
---------------------------------------------------------------------------------------

 ![Greve geral: quem pode aderir, o que muda no salário e o que vai estar a funcionar - JN](https://staticx.noticiasilimitadas.pt/jn/image.webp?brand=jn&type=generate&guid=4a9e034d-f191-4476-908a-d05d2af1a846&w=3840) <small>www.jn.pt</small>Greve geral: quem pode aderir, o que muda no salário e o que vai estar a funcionar - JN

SPN - Fenprof — Adesão Histórica à Greve Geral
----------------------------------------------

 ![SPN - Fenprof — Adesão histórica à greve geral](https://www.spn.pt/Media/Default/Info/68000/500/60/7/grevegeral11dez_cartaz.jpg) <small>www.spn.pt</small>SPN - Fenprof — Adesão histórica à greve geral

GREVE GERAL | 11 DEZEMBRO 2025 - ATE
------------------------------------

 ![GREVE GERAL | 11 DEZEMBRO 2025 - ATE](https://www.ate.pt/wp-content/uploads/2025/12/Greve-geral-11.12.jpg) <small>www.ate.pt</small>GREVE GERAL | 11 DEZEMBRO 2025 - ATE

O Patrão Pode Perguntar-me Se Vou Fazer Greve? Perco O Subsídio De Refeição? E Se A Empresa Fechar?
---------------------------------------------------------------------------------------------------

 ![O patrão pode perguntar-me se vou fazer greve? Perco o subsídio de refeição? E se a empresa fechar?](https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA1S3Lgf.img?w=768&h=512&m=6) <small>www.msn.com</small>O patrão pode perguntar-me se vou fazer greve? Perco o subsídio de refeição? E se a empresa fechar?

Aviso – Pré-Avisos De Greve | 11 E 12 De Dezembro De 2025 – AE António Correia De Oliveira
------------------------------------------------------------------------------------------

 ![Aviso – Pré-Avisos de Greve | 11 e 12 de dezembro de 2025 – AE António Correia de Oliveira](https://www.acoliveira.pt/wp-content/uploads/2025/12/11.png) <small>www.acoliveira.pt</small>Aviso – Pré-Avisos de Greve | 11 e 12 de dezembro de 2025 – AE António Correia de Oliveira

A Greve Geral é Já A 11 De Dezembro: O Que A Motiva, Quem Pode Aderir E Quais Os Direitos?
------------------------------------------------------------------------------------------

 ![A greve geral é já a 11 de dezembro: o que a motiva, quem pode aderir e quais os direitos?](https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA1RPs2I.img?w=1200&h=800&m=4&q=70) <small>www.msn.com</small>A greve geral é já a 11 de dezembro: o que a motiva, quem pode aderir e quais os direitos?

TCB | Pré-aviso De Greve A 11 De Dezembro - Portal Institucional
----------------------------------------------------------------

 ![TCB | Pré-aviso de greve a 11 de dezembro - Portal Institucional](https://www.cm-barreiro.pt/wp-content/uploads/2025/12/GREVE-11_DEZEMBRO_650px.png) <small>www.cm-barreiro.pt</small>TCB | Pré-aviso de greve a 11 de dezembro - Portal Institucional

Greves Gerais? "Os Trabalhadores Unem-se Quando A Ofensiva é Grande"
--------------------------------------------------------------------

 ![Greves gerais? "Os trabalhadores unem-se quando a ofensiva é grande"](https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA24x2oz.img?w=768&h=432&m=6) <small>www.msn.com</small>Greves gerais? "Os trabalhadores unem-se quando a ofensiva é grande"

Pré-Aviso De Greve 11 E 12 De Dezembro
--------------------------------------

 ![Pré-Aviso de Greve 11 e 12 de dezembro](https://static.wixstatic.com/media/1029eb_a6db1017a2334a9abf146e02d7454c28~mv2.png/v1/fill/w_770,h_395,al_c,lg_1,q_85/1029eb_a6db1017a2334a9abf146e02d7454c28~mv2.png) <small>www.aecadaval.com</small>Pré-Aviso de Greve 11 e 12 de dezembro

FAQ: Os Direitos Dos Docentes Em Dia De Greve Geral - 11/12/2025
----------------------------------------------------------------

 ![FAQ: Os direitos dos docentes em dia de Greve Geral - 11/12/2025](https://static.wixstatic.com/media/d0f32c_9ff1199ee2c34418af0094a43c516733~mv2.png/v1/fill/w_940,h_788,al_c,q_90,enc_avif,quality_auto/d0f32c_9ff1199ee2c34418af0094a43c516733~mv2.png) <small>www.sprc.pt</small>FAQ: Os direitos dos docentes em dia de Greve Geral - 11/12/2025

UGT Avança Para Greve Geral A 11 De Dezembro
--------------------------------------------

 ![UGT avança para greve geral a 11 de dezembro](https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA1Q3P3K.img?w=860&h=471&m=4&q=87) <small>www.msn.com</small>UGT avança para greve geral a 11 de dezembro

Fesete Vai Aderir à Greve Geral De 11 De Dezembro - Portugal - SÁBADO
---------------------------------------------------------------------

 ![Fesete vai aderir à greve geral de 11 de dezembro - Portugal - SÁBADO](https://cdn.sabado.pt/images/2013-05/img_1920x1080uu2013-05-30-19-15-03-73602.jpg) <small>www.sabado.pt</small>Fesete vai aderir à greve geral de 11 de dezembro - Portugal - SÁBADO

VISEU - Esclarecimento E Mobilização Para A Greve Geral Marcada Para 11 De Dezembro - CGTP-IN
---------------------------------------------------------------------------------------------

 ![VISEU - Esclarecimento e mobilização para a Greve Geral marcada para 11 de Dezembro - CGTP-IN](https://www.cgtp.pt/images/accao-e-luta/2025/gg.jpg) <small>www.cgtp.pt</small>VISEU - Esclarecimento e mobilização para a Greve Geral marcada para 11 de Dezembro - CGTP-IN

Pré-Aviso De Greve 11 E 12 De Dezembro
--------------------------------------

 ![Pré-Aviso de Greve 11 e 12 de dezembro](https://static.wixstatic.com/media/1029eb_b4cf39036f744ea9833c234b7b4b5af5~mv2.jpg/v1/fill/w_980,h_1386,al_c,q_85,usm_0.66_1.00_0.01,enc_avif,quality_auto/1029eb_b4cf39036f744ea9833c234b7b4b5af5~mv2.jpg) <small>www.aecadaval.com</small>Pré-Aviso de Greve 11 e 12 de dezembro

FNSTFPS Adere à Greve Geral De 11 De Dezembro - CGTP-IN
-------------------------------------------------------

 ![FNSTFPS adere à Greve Geral de 11 de Dezembro - CGTP-IN](https://www.cgtp.pt/images/accao-e-luta/2025/54910179541_10702918c8_c.jpg) <small>www.cgtp.pt</small>FNSTFPS adere à Greve Geral de 11 de Dezembro - CGTP-IN

CGTP Anuncia Greve Geral Para 11 De Dezembro
--------------------------------------------

 ![CGTP anuncia greve geral para 11 de dezembro](https://www.lusa.pt/TEMP/IMAGES/780x1200/CACHE_780X1200_ANALOG_WATERMARKED_45998234_7085120_08112025053627.JPG) <small>www.lusa.pt</small>CGTP anuncia greve geral para 11 de dezembro

Perguntas E Respostas Sobre A Greve Geral De 11 De Dezembro - SBC - Sindicato Nacional Dos
------------------------------------------------------------------------------------------

 ![Perguntas e respostas sobre a Greve Geral de 11 de dezembro - SBC - Sindicato Nacional dos](https://www.sibace.pt/wp-content/uploads/2025/11/greve-2-1170-x-400.png) <small>www.sibace.pt</small>Perguntas e respostas sobre a Greve Geral de 11 de dezembro - SBC - Sindicato Nacional dos ...

Motivos Da Adesão à Greve Geral De 11 De Dezembro De 2025
---------------------------------------------------------

 ![Motivos da adesão à Greve Geral de 11 de dezembro de 2025](https://spzn.pt/uploads/noticias/big_1763717239_6728_SPZN_2025_site_novo_(17).png) <small>spzn.pt</small>Motivos da adesão à Greve Geral de 11 de dezembro de 2025

Pré-aviso de greve 11 e 12 de dezembro. greve geral. Perguntas e respostas sobre a greve geral de 11 de dezembro
