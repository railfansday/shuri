---
title: "Atum-19/6-0-stk - Atum 19xd3 somt 060204"
description: "Atum-19/6-0-stk te connectivity / raychem"
date: "2026-03-09"
categories:
- "Uncategorized"
images:
- "https://img1.findic.com/m145/atum-196-0-stk-0fyb3dtY-ejPkgPn8o.jpg"
featuredImage: "https://www.te.com/content/dam/te-com/catalog/part/EM5/611/600/EM56116001-t4.jpg/jcr:content/renditions/product-small.png?w=85"
featured_image: "https://www.akko.com.tr/Userfiles/Products/Models/ATUM-19XD5-SP..-060204.jpg"
image: "https://www.belmar.pt/wp-content/uploads/2020/07/atum-1024x683.png"
---

If you are looking for ATUM-6/2-0-STK TE Connectivity Raychem Cable Protection | Cables, Wires - Management | DigiKey you've visit to the right page. We have 35 Pictures about ATUM-6/2-0-STK TE Connectivity Raychem Cable Protection | Cables, Wires - Management | DigiKey like ATUM-19/6-0-STK TE Connectivity - Heat shrink sleeve | glued; 3: 1; 19mm; L: 1.2m; black, ATUM-19/6-0-STK | Gaine thermorétractable, Noir Polyoléfine Chemelex, , Rétreint 3:1 Diam. 19 mm and also ATUM-19/6-0-STK : RAYCHEM ATUM 3:1 Heat Shrink Tubing | TE Connectivity. Here you go:

ATUM-6/2-0-STK TE Connectivity Raychem Cable Protection | Cables, Wires - Management | DigiKey
----------------------------------------------------------------------------------------------

 ![ATUM-6/2-0-STK TE Connectivity Raychem Cable Protection | Cables, Wires - Management | DigiKey](https://mm.digikey.com/Volume0/opasdata/d220001/medias/images/707/ATU062K.jpg) <small>www.digikey.com</small>ATUM-6/2-0-STK TE Connectivity Raychem Cable Protection | Cables, Wires - Management | DigiKey

ATUM-19/6-0-STK : RAYCHEM ATUM 3:1 Heat Shrink Tubing | TE Connectivity
-----------------------------------------------------------------------

 ![ATUM-19/6-0-STK : RAYCHEM ATUM 3:1 Heat Shrink Tubing | TE Connectivity](https://www.te.com/content/dam/te-com/catalog/part/EM5/611/600/EM56116001-t4.jpg/jcr:content/renditions/product-small.png?w=220) <small>www.te.com</small>ATUM-19/6-0-STK : RAYCHEM ATUM 3:1 Heat Shrink Tubing | TE Connectivity

Raychem ATUM 19/6-0 - трубка термоусаживаемая гибкая с двойной стенкой цена, купить 120610-00004
------------------------------------------------------------------------------------------------

 ![Raychem ATUM 19/6-0 - трубка термоусаживаемая гибкая с двойной стенкой цена, купить 120610-00004](https://skomplekt.com/files/uploads/product_1655910/main_img_p1655910_popup.jpg) <small>skomplekt.com</small>Raychem ATUM 19/6-0 - трубка термоусаживаемая гибкая с двойной стенкой цена, купить 120610-00004 ...

ATUM-19/6-0-STK : RAYCHEM ATUM 3:1 Heat Shrink Tubing | TE Connectivity
-----------------------------------------------------------------------

 ![ATUM-19/6-0-STK : RAYCHEM ATUM 3:1 Heat Shrink Tubing | TE Connectivity](https://www.te.com/content/dam/te-com/catalog/part/EM5/611/600/EM56116001-t1.jpg/jcr:content/renditions/product-high-res.png?w=300) <small>www.te.com</small>ATUM-19/6-0-STK : RAYCHEM ATUM 3:1 Heat Shrink Tubing | TE Connectivity

Pack Atum – Belmar | Conservas
------------------------------

 ![Pack Atum – Belmar | Conservas](https://www.belmar.pt/wp-content/uploads/2020/07/atum-1024x683.png) <small>www.belmar.pt</small>Pack Atum – Belmar | Conservas

ATUM-19/6-0-STK : RAYCHEM ATUM 3:1 Heat Shrink Tubing | TE Connectivity
-----------------------------------------------------------------------

 ![ATUM-19/6-0-STK : RAYCHEM ATUM 3:1 Heat Shrink Tubing | TE Connectivity](https://www.te.com/content/dam/te-com/catalog/part/EM5/611/600/EM56116001-t4.jpg/jcr:content/renditions/product-small.png?w=85) <small>www.te.com</small>ATUM-19/6-0-STK : RAYCHEM ATUM 3:1 Heat Shrink Tubing | TE Connectivity

Raychem ATUM 19/6 High-Shrink Ratio 3:1, Adhesive-Lined Polyolefin Tubing - Black |Heat Shrink
----------------------------------------------------------------------------------------------

 ![Raychem ATUM 19/6 High-Shrink Ratio 3:1, Adhesive-Lined Polyolefin Tubing - Black |Heat Shrink](https://eadn-wc04-1925978.nxedge.io/cdn/media/catalog/product/cache/c7b67f1ce99d1caa405d0fe7ed968970/_/t/_tubing_raychem-atum.jpg) <small>www.lapptannehill.com</small>Raychem ATUM 19/6 High-Shrink Ratio 3:1, Adhesive-Lined Polyolefin Tubing - Black |Heat Shrink ...

TE Connectivity(泰科电子) 阻燃型聚烯烃热缩管 19/6mm 3:1 110℃ 双壁 黑色【价格 采购 图片】-立创MRO工业品
------------------------------------------------------------------------

 ![TE Connectivity(泰科电子) 阻燃型聚烯烃热缩管 19/6mm 3:1 110℃ 双壁 黑色【价格 采购 图片】-立创MRO工业品](https://alimg.szlcsc.com/upload/public/product/source/20240529/8DAA85C64F04581247C3EF0D9B4AF5A9.jpg) <small>item.szlcsc.com</small>TE Connectivity(泰科电子) 阻燃型聚烯烃热缩管 19/6mm 3:1 110℃ 双壁 黑色【价格 采购 图片】-立创MRO工业品

【楽天市場】レイケム ATUM-19/6-0-STK(1.2M) 接着層付き 防水 熱収縮チューブ カット品 黒色 19.0MM--6.0MM クロ：FAUbon 楽天市場店
---------------------------------------------------------------------------------------

 ![【楽天市場】レイケム ATUM-19/6-0-STK(1.2M) 接着層付き 防水 熱収縮チューブ カット品 黒色 19.0MM--6.0MM クロ：FAUbon 楽天市場店](https://thumbnail.image.rakuten.co.jp/@0_mall/faubon/cabinet/image2/atum_raychem.jpg?_ex=200x200&s=0&r=1) <small>item.rakuten.co.jp</small>【楽天市場】レイケム ATUM-19/6-0-STK(1.2M) 接着層付き 防水 熱収縮チューブ カット品 黒色 19.0MM--6.0MM クロ：FAUbon 楽天市場店

ATUM-19/6-0-STK TE Connectivity - Heat Shrink Sleeve | Glued; 3: 1; 19mm; L: 1.2m; Black
----------------------------------------------------------------------------------------

 ![ATUM-19/6-0-STK TE Connectivity - Heat shrink sleeve | glued; 3: 1; 19mm; L: 1.2m; black](https://ce8dc832c.cloudimg.io/v7/_cdn_/8C/7E/90/00/0/649160_1.jpg?width=640&height=480&wat=1&wat_url=_tme-wrk_%2Ftme_new.png&wat_scale=100p&ci_sign=7de41316e2a861e7570fcf01f74056efec0750ea) <small>www.tme.com</small>ATUM-19/6-0-STK TE Connectivity - Heat shrink sleeve | glued; 3: 1; 19mm; L: 1.2m; black ...

ATUM-19/6-0-100MM | Gaine Thermorétractable, Noir Polyoléfine NVent RAYCHEM, , Rétreint 3:1 Diam
------------------------------------------------------------------------------------------------

 ![ATUM-19/6-0-100MM | Gaine thermorétractable, Noir Polyoléfine nVent RAYCHEM, , Rétreint 3:1 Diam](https://media.rs-online.com/image/upload/bo_1.5px_solid_white,b_auto,c_pad,dpr_2,f_auto,h_399,q_auto,w_710/c_pad,h_399,w_710/Y0349823-01?pgw=1) <small>fr.rs-online.com</small>ATUM-19/6-0-100MM | Gaine thermorétractable, Noir Polyoléfine nVent RAYCHEM, , Rétreint 3:1 Diam ...

ATUM-19/6-0-STK : RAYCHEM ATUM 3:1 Heat Shrink Tubing | TE Connectivity
-----------------------------------------------------------------------

 ![ATUM-19/6-0-STK : RAYCHEM ATUM 3:1 Heat Shrink Tubing | TE Connectivity](https://www.te.com/content/dam/te-com/catalog/part/EM5/611/600/EM56116001-t1.jpg/jcr:content/renditions/product-small.png) <small>www.te.com</small>ATUM-19/6-0-STK : RAYCHEM ATUM 3:1 Heat Shrink Tubing | TE Connectivity

ATUM-19/6-0-STK RAYCHEM - TE CONNECTIVITY, Adhesive Lined Heat Shrink Tubing, Dual Medium Wall
----------------------------------------------------------------------------------------------

 ![ATUM-19/6-0-STK RAYCHEM - TE CONNECTIVITY, Adhesive Lined Heat Shrink Tubing, Dual Medium Wall](https://au.element14.com/productimages/standard/en_GB/42246982.jpg) <small>au.element14.com</small>ATUM-19/6-0-STK RAYCHEM - TE CONNECTIVITY, Adhesive Lined Heat Shrink Tubing, Dual Medium Wall ...

ATUM-19/6-0-STK : RAYCHEM ATUM 3:1 Heat Shrink Tubing | TE Connectivity
-----------------------------------------------------------------------

 ![ATUM-19/6-0-STK : RAYCHEM ATUM 3:1 Heat Shrink Tubing | TE Connectivity](https://www.te.com/content/dam/te-com/catalog/part/EM5/611/600/EM56116001-t4.jpg/jcr:content/renditions/product-small.png) <small>www.te.com</small>ATUM-19/6-0-STK : RAYCHEM ATUM 3:1 Heat Shrink Tubing | TE Connectivity

ATUM-19/6-0-STK TE Connectivity / Raychem | Mouser France
---------------------------------------------------------

 ![ATUM-19/6-0-STK TE Connectivity / Raychem | Mouser France](https://www.mouser.fr/images/tycoelectronics/images/NB09012001_SPL.jpg) <small>www.mouser.fr</small>ATUM-19/6-0-STK TE Connectivity / Raychem | Mouser France

ATUM-6/2-0-STK Heat Shrink Tubing By RAYCHEM CONNECTIVITY
---------------------------------------------------------

 ![ATUM-6/2-0-STK Heat Shrink Tubing by RAYCHEM CONNECTIVITY](https://cdn.radwell.com/productgoogleimages/cf054bf9e1344ba19a131778bed859f4.jpg) <small>www.radwell.com</small>ATUM-6/2-0-STK Heat Shrink Tubing by RAYCHEM CONNECTIVITY

ATUM-6/2-0-MS-STK TE Connectivity Raychem Cable Protection | Cables, Wires - Management | DigiKey
-------------------------------------------------------------------------------------------------

 ![ATUM-6/2-0-MS-STK TE Connectivity Raychem Cable Protection | Cables, Wires - Management | DigiKey](https://media.digikey.com/photos/Tyco Raychem Photos/ATU062K.jpg) <small>www.digikey.com</small>ATUM-6/2-0-MS-STK TE Connectivity Raychem Cable Protection | Cables, Wires - Management | DigiKey

ATUM-19/6-0-STK | TE Connectivity PO热缩管, 黑色, 1.2m长, Φ19 Mm, 收缩径6 Mm, ATUM系列 | RS
--------------------------------------------------------------------------------

 ![ATUM-19/6-0-STK | TE Connectivity PO热缩管, 黑色, 1.2m长, Φ19 mm, 收缩径6 mm, ATUM系列 | RS](https://media.rs-online.com/f_auto,q_auto,bo_1.5px_solid_white,b_auto,c_pad,dpr_2,h_399,w_710/c_pad,h_399,w_710/Y0487253-01?pgw=1) <small>www.rsonline.cn</small>ATUM-19/6-0-STK | TE Connectivity PO热缩管, 黑色, 1.2m长, Φ19 mm, 收缩径6 mm, ATUM系列 | RS

ATUM-19/6-0-STK | Tubo Termorretráctil TE Connectivity De Poliolefina Negro, Contracción 3:1, Ø
-----------------------------------------------------------------------------------------------

 ![ATUM-19/6-0-STK | Tubo termorretráctil TE Connectivity de Poliolefina Negro, contracción 3:1, Ø](https://media.rs-online.com/image/upload/bo_1.5px_solid_white,b_auto,c_pad,dpr_2,f_auto,h_399,q_auto,w_710/c_pad,h_399,w_710/F7822074-01?pgw=1) <small>es.rs-online.com</small>ATUM-19/6-0-STK | Tubo termorretráctil TE Connectivity de Poliolefina Negro, contracción 3:1, Ø ...

ATUM 19XD3 SOMT 060204 - ATUM DRILL - AKKO METAL WORKING TOOLS | Cutting Tools ‎| CNC Cutting
---------------------------------------------------------------------------------------------

 ![ATUM 19XD3 SOMT 060204 - ATUM DRILL - AKKO METAL WORKING TOOLS | Cutting Tools ‎| CNC Cutting](https://www.akko.com.tr/Userfiles/Products/Models/ATUM-19XD3-SOMT-060204.jpg) <small>www.akko.com.tr</small>ATUM 19XD3 SOMT 060204 - ATUM DRILL - AKKO METAL WORKING TOOLS | Cutting Tools ‎| CNC Cutting ...

ATUM-19/6-0 | TE Connectivity Heat Shrink Tubing, Black 19 Mm Sleeve Dia. X 1.2m Length 3:1
-------------------------------------------------------------------------------------------

 ![ATUM-19/6-0 | TE Connectivity Heat Shrink Tubing, Black 19 mm Sleeve Dia. x 1.2m Length 3:1](https://media.rs-online.com/image/upload/bo_1.5px_solid_white,b_auto,c_pad,dpr_2,f_auto,h_399,q_auto,w_710/c_pad,h_399,w_710/F3161596-01?pgw=1) <small>uk.rs-online.com</small>ATUM-19/6-0 | TE Connectivity Heat Shrink Tubing, Black 19 mm Sleeve Dia. x 1.2m Length 3:1 ...

ATUM-19/6-0-STK | Gaine Thermorétractable, Noir Polyoléfine Chemelex, , Rétreint 3:1 Diam. 19 Mm
------------------------------------------------------------------------------------------------

 ![ATUM-19/6-0-STK | Gaine thermorétractable, Noir Polyoléfine Chemelex, , Rétreint 3:1 Diam. 19 mm](https://media.rs-online.com/image/upload/bo_1.5px_solid_white,b_auto,c_pad,dpr_2,f_auto,h_399,q_auto,w_710/c_pad,h_399,w_710/Y0433209-01?pgw=1) <small>fr.rs-online.com</small>ATUM-19/6-0-STK | Gaine thermorétractable, Noir Polyoléfine Chemelex, , Rétreint 3:1 Diam. 19 mm ...

ATUM-19/6-0-STK : RAYCHEM ATUM 3:1 Heat Shrink Tubing | TE Connectivity
-----------------------------------------------------------------------

 ![ATUM-19/6-0-STK : RAYCHEM ATUM 3:1 Heat Shrink Tubing | TE Connectivity](https://www.te.com/content/dam/te-com/catalog/part/EM5/611/600/EM56116001-t3.jpg/jcr:content/renditions/product-small.png?w=85) <small>www.te.com</small>ATUM-19/6-0-STK : RAYCHEM ATUM 3:1 Heat Shrink Tubing | TE Connectivity

ATUM-19/6-0-STK TE Connectivity | Raychem Products | ICC
--------------------------------------------------------

 ![ATUM-19/6-0-STK TE Connectivity | Raychem Products | ICC](https://sku-product-images.s3.us-east-2.amazonaws.com/AMP/521838-2.jpg) <small>www.connecticc.com</small>ATUM-19/6-0-STK TE Connectivity | Raychem Products | ICC

Raychem 대리점 Korea 한국 - FindIC
-----------------------------

 ![Raychem 대리점 Korea 한국 - FindIC](https://img1.findic.com/m145/atum-196-0-stk-0fyb3dtY-ejPkgPn8o.jpg) <small>www.findic.kr</small>Raychem 대리점 Korea 한국 - FindIC

M23053/4-304-0 ATUM STK Per TE Connectivity | Termoretraibili | Arrow.com
-------------------------------------------------------------------------

 ![M23053/4-304-0 ATUM STK per TE Connectivity | Termoretraibili | Arrow.com](https://static6.arrow.com/aropdfconversion/arrowimages/f9cf9d543095b66291c67d3764b07c2be90f4972/m230534-304.jpg) <small>www.arrow.com</small>M23053/4-304-0 ATUM STK per TE Connectivity | Termoretraibili | Arrow.com

ATUM 19XD5 SP.. 060204 - TAKMA UÇLU MATKAPLAR - AKKO METAL WORKING TOOLS | Cutting Tools ‎| CNC
-----------------------------------------------------------------------------------------------

 ![ATUM 19XD5 SP.. 060204 - TAKMA UÇLU MATKAPLAR - AKKO METAL WORKING TOOLS | Cutting Tools ‎| CNC](https://www.akko.com.tr/Userfiles/Products/Models/ATUM-19XD5-SP..-060204.jpg) <small>www.akko.com.tr</small>ATUM 19XD5 SP.. 060204 - TAKMA UÇLU MATKAPLAR - AKKO METAL WORKING TOOLS | Cutting Tools ‎| CNC ...

ATUM Thin Wall Heatshrink
-------------------------

 ![ATUM Thin Wall Heatshrink](https://www.transnet.co.nz/images/Products/ATUM-6-2-0-STK_1.jpg) <small>www.transnet.co.nz</small>ATUM Thin Wall Heatshrink

ATUM-19/6-0-STK : RAYCHEM ATUM 3:1 Heat Shrink Tubing | TE Connectivity
-----------------------------------------------------------------------

 ![ATUM-19/6-0-STK : RAYCHEM ATUM 3:1 Heat Shrink Tubing | TE Connectivity](https://www.te.com/content/dam/te-com/catalog/part/EM5/611/600/EM56116001-t3.jpg/jcr:content/renditions/product-small.png?w=220) <small>www.te.com</small>ATUM-19/6-0-STK : RAYCHEM ATUM 3:1 Heat Shrink Tubing | TE Connectivity

Raychem Krympeslange ATUM 19/6-1,2 M Med Lim | Billig
-----------------------------------------------------

 ![Raychem Krympeslange ATUM 19/6-1,2 m med lim | Billig](https://www.proshop.dk/Images/915x900/2769350_eb63986b4b46.jpg) <small>www.proshop.dk</small>Raychem Krympeslange ATUM 19/6-1,2 m med lim | Billig

ATUM-19/6-0 TE Connectivity | TE Connectivity Heat Shrink Tubing, Black 19 Mm Sleeve Dia. X 1.2m
------------------------------------------------------------------------------------------------

 ![ATUM-19/6-0 TE Connectivity | TE Connectivity Heat Shrink Tubing, Black 19 mm Sleeve Dia. x 1.2m](https://res.cloudinary.com/rsc/image/upload/b_rgb:FFFFFF,c_pad,dpr_1.0,f_auto,q_auto,w_700/c_pad,w_700/F2027697-01) <small>in.rsdelivers.com</small>ATUM-19/6-0 TE Connectivity | TE Connectivity Heat Shrink Tubing, Black 19 mm Sleeve Dia. x 1.2m ...

ATUM-6/2-0-STK Клеевая термоусадка самозатухающая Raychem, NB11652001
---------------------------------------------------------------------

 ![ATUM-6/2-0-STK Клеевая термоусадка самозатухающая Raychem, NB11652001](https://s-motorsport.com/image/cache/catalog/Raychem/ATUM 3-1/TE-Raychem-ATUM 3-1-900x900.jpg) <small>s-motorsport.com</small>ATUM-6/2-0-STK Клеевая термоусадка самозатухающая Raychem, NB11652001

ATUM-19/6-0-STK Raychem - Te Connectivity, Adhesive Lined Heat Shrink Tubing, Dual Medium Wall
----------------------------------------------------------------------------------------------

 ![ATUM-19/6-0-STK Raychem - Te Connectivity, Adhesive Lined Heat Shrink Tubing, Dual Medium Wall](https://uk.farnell.com/productimages/large/en_GB/42246982.jpg) <small>uk.farnell.com</small>ATUM-19/6-0-STK Raychem - Te Connectivity, Adhesive Lined Heat Shrink Tubing, Dual Medium Wall ...

1" Raychem ATUM Heat Shrink Adhesive Lined Tubing – KSV Looms
-------------------------------------------------------------

 ![1" Raychem ATUM Heat Shrink Adhesive Lined Tubing – KSV Looms](https://www.ksvlooms.com/cdn/shop/files/1-raychem-atum-heat-shrink-adhesive-lined-tubing-148.webp?v=1717767697&width=4096) <small>www.ksvlooms.com</small>1" Raychem ATUM Heat Shrink Adhesive Lined Tubing – KSV Looms

KRÜGER EN-ATUM-19/6-0-1200 CN5491-000 | Hms-shop24.de
-----------------------------------------------------

 ![KRÜGER EN-ATUM-19/6-0-1200 CN5491-000 | hms-shop24.de](https://hms-shop24.de/media/image/product/974514/lg/raychem-schrumpfschlauch-doppelwandig-halbsteif-mit-kleber-19-6-mm-laenge-en-atum-19-6-0-1200-item_2187241.jpg) <small>hms-shop24.de</small>KRÜGER EN-ATUM-19/6-0-1200 CN5491-000 | hms-shop24.de

atum-19/6-0-stk : raychem atum 3:1 heat shrink tubing. Atum-19/6-0. Atum-6/2-0-stk клеевая термоусадка самозатухающая raychem, nb11652001
