---
title: "Atum-32/8-0-stk - Raychem atum 32/8-0"
description: "atum-32/8-0-sp : raychem atum 4:1 heat shrink tubing"
date: "2026-07-03"
categories:
- "Uncategorized"
images:
- "https://skomplekt.com/files/uploads/product_1655913/main_img_p1655913_popup.jpg"
featuredImage: "https://skomplekt.com/files/uploads/product_1655913/main_img_p1655913_popup.jpg"
featured_image: "https://eadn-wc04-1925978.nxedge.io/cdn/media/catalog/product/cache/a7b707b5b82b05683a3f029c98969ced/_/t/_tubing_raychem-atum.jpg"
image: "https://i.ebayimg.com/images/g/RLoAAOSwEvpg3MM5/s-l1600.jpg"
---

If you are searching about ATUM heatshrink size 32/8 (32.0mm down to 8.0mm) you've visit to the right web. We have 35 Pictures about ATUM heatshrink size 32/8 (32.0mm down to 8.0mm) like RAYCHEM ATUM-32/8-0-STK Heat Shrinkable Tubing Polyolefin Black Stick BAG OF 10 | eBay, RAYCHEM ATUM-32/8-0-STK Heat Shrinkable Tubing Polyolefin Black Stick BAG OF 10 | eBay and also ATUM-32/8-0 | TE Connectivity Heat Shrink Tubing, Black 32 mm Sleeve Dia. x 1.2m Length 4:1. Here you go:

ATUM Heatshrink Size 32/8 (32.0mm Down To 8.0mm)
------------------------------------------------

 ![ATUM heatshrink size 32/8 (32.0mm down to 8.0mm)](https://hilltop-products.co.uk/media/catalog/product/cache/6d2ffb848796335b7eb82cc8e3ea4df5/a/t/atum_ps.png) <small>hilltop-products.co.uk</small>ATUM heatshrink size 32/8 (32.0mm down to 8.0mm)

Raychem熱縮套管 - ATUM-32/8-0-STK - TYCO/RAYCHEM (中國 貿易商) - 端子、連接器 - 電子元器件 產品 「自助貿易」
--------------------------------------------------------------------------------

 ![raychem熱縮套管 - ATUM-32/8-0-STK - TYCO/RAYCHEM (中國 貿易商) - 端子、連接器 - 電子元器件 產品 「自助貿易」](https://img.diytrade.com/smimg/1006846/11623087-5502899-0/raychem熱縮套管/33f0.jpg) <small>tc.diytrade.com</small>raychem熱縮套管 - ATUM-32/8-0-STK - TYCO/RAYCHEM (中國 貿易商) - 端子、連接器 - 電子元器件 產品 「自助貿易」

Raychem Atum-32/8-0-stk 10pcs (4 Ft) New/unused Surplus Ccg | MercadoLibre
--------------------------------------------------------------------------

 ![Raychem Atum-32/8-0-stk 10pcs (4 Ft) New/unused Surplus Ccg | MercadoLibre](https://http2.mlstatic.com/D_NQ_NP_898443-MLM79521707729_092024-O.webp) <small>www.mercadolibre.com.mx</small>Raychem Atum-32/8-0-stk 10pcs (4 Ft) New/unused Surplus Ccg | MercadoLibre

Raychem ATUM Tubing 4:1 – KSV Looms
-----------------------------------

 ![Raychem ATUM Tubing 4:1 – KSV Looms](https://www.ksvlooms.com/cdn/shop/files/1-4-raychem-atum-heat-shrink-adhesive-lined-tubing-887.webp?v=1756159522&width=950) <small>www.ksvlooms.com</small>Raychem ATUM Tubing 4:1 – KSV Looms

\[图\]供应现货瑞侃双壁管ATUM-32/8-0-STK，维库电子市场网
-------------------------------------

 ![[图]供应现货瑞侃双壁管ATUM-32/8-0-STK，维库电子市场网](https://www.dzsc.com/uploadfile/company/671705/s201231313329217.jpg) <small>product.dzsc.com</small>\[图\]供应现货瑞侃双壁管ATUM-32/8-0-STK，维库电子市场网

Raychem ATUM 32/8-0 - трубка термоусаживаемая гибкая с двойной стенкой цена, купить 120610-00008
------------------------------------------------------------------------------------------------

 ![Raychem ATUM 32/8-0 - трубка термоусаживаемая гибкая с двойной стенкой цена, купить 120610-00008](https://skomplekt.com/files/uploads/product_1655913/main_img_p1655913_popup.jpg) <small>skomplekt.com</small>Raychem ATUM 32/8-0 - трубка термоусаживаемая гибкая с двойной стенкой цена, купить 120610-00008 ...

RAYCHEM ATUM-32/8-0-STK Heat Shrinkable Tubing Polyolefin Black Stick BAG OF 10 | EBay
--------------------------------------------------------------------------------------

 ![RAYCHEM ATUM-32/8-0-STK Heat Shrinkable Tubing Polyolefin Black Stick BAG OF 10 | eBay](https://i.ebayimg.com/images/g/6QcAAOSwueVg3MM6/s-l1600.jpg) <small>www.ebay.com</small>RAYCHEM ATUM-32/8-0-STK Heat Shrinkable Tubing Polyolefin Black Stick BAG OF 10 | eBay

ATUM-32/8-0-STK TE Connectivity Raychem Cable Protection | Cables, Wires - Management | DigiKey
-----------------------------------------------------------------------------------------------

 ![ATUM-32/8-0-STK TE Connectivity Raychem Cable Protection | Cables, Wires - Management | DigiKey](https://media.digikey.com/photos/nophoto/pna_en_tmb.jpg) <small>www.digikey.com</small>ATUM-32/8-0-STK TE Connectivity Raychem Cable Protection | Cables, Wires - Management | DigiKey

レイケム ATUM-32/8-0-STK（カット品1.2m） 黒色 接着層付き 防水熱収縮チューブ 32.0→8.0mm : FA-Ubon Yahoo!店 - 通販 - Yahoo!ショッピング
--------------------------------------------------------------------------------------------------

 ![レイケム ATUM-32/8-0-STK（カット品1.2m） 黒色 接着層付き 防水熱収縮チューブ 32.0→8.0mm : FA-Ubon Yahoo!店 - 通販 - Yahoo!ショッピング](https://item-shopping.c.yimg.jp/i/n/faubon_0878882) <small>store.shopping.yahoo.co.jp</small>レイケム ATUM-32/8-0-STK（カット品1.2m） 黒色 接着層付き 防水熱収縮チューブ 32.0→8.0mm : FA-Ubon Yahoo!店 - 通販 - Yahoo!ショッピング

Raychem热缩套管 - ATUM-32/8-0-STK - TYCO/RAYCHEM (中国 江苏省 贸易商) - 端子、连接器 - 电子元器件 产品 「自助贸易」
------------------------------------------------------------------------------------

 ![raychem热缩套管 - ATUM-32/8-0-STK - TYCO/RAYCHEM (中国 江苏省 贸易商) - 端子、连接器 - 电子元器件 产品 「自助贸易」](https://img.diytrade.com/smimg/1006846/11623085-5502898-0/raychem热缩套管/e263.jpg) <small>cn.diytrade.com</small>raychem热缩套管 - ATUM-32/8-0-STK - TYCO/RAYCHEM (中国 江苏省 贸易商) - 端子、连接器 - 电子元器件 产品 「自助贸易」

常备库存 ATUM-32/8-0-STK-阿里巴巴
-------------------------

 ![常备库存 ATUM-32/8-0-STK-阿里巴巴](https://cbu01.alicdn.com/img/ibank/2020/105/276/13933672501_988176765.jpg) <small>detail.1688.com</small>常备库存 ATUM-32/8-0-STK-阿里巴巴

ATUM-24/6-0-STK TE Connectivity | Raychem Products | ICC
--------------------------------------------------------

 ![ATUM-24/6-0-STK TE Connectivity | Raychem Products | ICC](https://sku-product-images.s3.us-east-2.amazonaws.com/RYC/RYCNB14032001.jpg) <small>www.connecticc.com</small>ATUM-24/6-0-STK TE Connectivity | Raychem Products | ICC

ATUM-32/8-0-STK TE Connectivity Raychem Cable Protection | Heat Shrink Tubing | DigiKey
---------------------------------------------------------------------------------------

 ![ATUM-32/8-0-STK TE Connectivity Raychem Cable Protection | Heat Shrink Tubing | DigiKey](https://mm.digikey.com/Volume0/opasdata/d220001/derivates/3/003/226/041/MFG_ATUM-XX-X-0-SP_tmb(64x64).jpg) <small>www.digikey.com</small>ATUM-32/8-0-STK TE Connectivity Raychem Cable Protection | Heat Shrink Tubing | DigiKey

ATUM-32/8-0-STK TE Connectivity / Raychem | Mouser Europa
---------------------------------------------------------

 ![ATUM-32/8-0-STK TE Connectivity / Raychem | Mouser Europa](https://eu.mouser.com/images/tycoelectronics/images/NB09012001_SPL.jpg) <small>eu.mouser.com</small>ATUM-32/8-0-STK TE Connectivity / Raychem | Mouser Europa

ATUM-32/8-0-STK TE Connectivity / Raychem - Heat Shrink Tubing - Distributors, Price Comparison
-----------------------------------------------------------------------------------------------

 ![ATUM-32/8-0-STK TE Connectivity / Raychem - Heat Shrink Tubing - Distributors, Price Comparison](https://sigma.octopart.com/160262279/image/Raychem-ATUM-32-8-0-STK.jpg) <small>octopart.com</small>ATUM-32/8-0-STK TE Connectivity / Raychem - Heat Shrink Tubing - Distributors, Price Comparison ...

TE Connectivity HTAT-32/8-0-STK Raychem, Adhesive Lined Tubing, 32-8mm I/d, HTAT-32/8-0-STK
-------------------------------------------------------------------------------------------

 ![TE Connectivity HTAT-32/8-0-STK Raychem, Adhesive lined tubing, 32-8mm i/d, HTAT-32/8-0-STK](https://assets.rs-online.com/image/upload/v1524809095/70296237.jpg) <small>us.rs-online.com</small>TE Connectivity HTAT-32/8-0-STK Raychem, Adhesive lined tubing, 32-8mm i/d, HTAT-32/8-0-STK

ATUM-32/8-0-STK | Raychem Heat-Shrink Tubing Polyolefin, 8 32mm, Black, 1.2m | Distrelec
----------------------------------------------------------------------------------------

 ![ATUM-32/8-0-STK | Raychem Heat-Shrink Tubing Polyolefin, 8 32mm, Black, 1.2m | Distrelec](https://media.distrelec.com/Web/WebShopImages/landscape_large/_t/if/schrumpfschlauche-halogenfrei-w-1-h.jpg) <small>www.distrelec.biz</small>ATUM-32/8-0-STK | Raychem Heat-Shrink Tubing Polyolefin, 8 ... 32mm, Black, 1.2m | Distrelec ...

ATUM-32/8-0 | TE Connectivity Heat Shrink Tubing, Black 32 Mm Sleeve Dia. X 1.2m Length 4:1
-------------------------------------------------------------------------------------------

 ![ATUM-32/8-0 | TE Connectivity Heat Shrink Tubing, Black 32 mm Sleeve Dia. x 1.2m Length 4:1](https://media.rs-online.com/image/upload/bo_1.5px_solid_white,b_auto,c_pad,dpr_2,f_auto,h_399,q_auto,w_710/c_pad,h_399,w_710/R3161675-01?pgw=1) <small>uk.rs-online.com</small>ATUM-32/8-0 | TE Connectivity Heat Shrink Tubing, Black 32 mm Sleeve Dia. x 1.2m Length 4:1 ...

Raychem ATUM 32/8 High-Shrink Ratio 4:1, Adhesive-Lined Polyolefin Tubing - Black |Heat Shrink
----------------------------------------------------------------------------------------------

 ![Raychem ATUM 32/8 High-Shrink Ratio 4:1, Adhesive-Lined Polyolefin Tubing - Black |Heat Shrink](https://eadn-wc04-1925978.nxedge.io/cdn/media/catalog/product/cache/a7b707b5b82b05683a3f029c98969ced/_/t/_tubing_raychem-atum.jpg) <small>www.lapptannehill.com</small>Raychem ATUM 32/8 High-Shrink Ratio 4:1, Adhesive-Lined Polyolefin Tubing - Black |Heat Shrink ...

Rurka Termokurczliwa Z Klejem 4: 1 32mm L: 1,2m Czarny ATUM ATUM-32/8-0-STK – TE Connectivity
---------------------------------------------------------------------------------------------

 ![Rurka termokurczliwa z klejem 4: 1 32mm L: 1,2m czarny ATUM ATUM-32/8-0-STK – TE Connectivity](https://www.tim.pl/api/v1/assets/resize/eyJzb3VyY2UiOiIwMDAxLTAwMDE4LTc4OTM2LzAwMDEtMDAwMTgtNzg5MzZfMV9wci5qcGc/ZXRhZz04OTZiOGJiYzkzZWU2NWNjYWNkMjEyZGQ4MGYzYWExZCIsInF1YWxpdHkiOjkwLCJ3aWR0aCI6MTIwMCwiaGVpZ2h0Ijo2NzUsIndhdGVybWFyayI6IiIsImZvcm1hdCI6IndlYnAifQ==) <small>www.tim.pl</small>Rurka termokurczliwa z klejem 4: 1 32mm L: 1,2m czarny ATUM ATUM-32/8-0-STK – TE Connectivity ...

ATUM-32/8-0-SP : RAYCHEM ATUM 4:1 Heat Shrink Tubing | TE Connectivity
----------------------------------------------------------------------

 ![ATUM-32/8-0-SP : RAYCHEM ATUM 4:1 Heat Shrink Tubing | TE Connectivity](https://www.te.com/content/dam/te-com/catalog/part/EM5/611/600/EM56116001-t1.jpg/jcr:content/renditions/product-high-res.png) <small>www.te.com</small>ATUM-32/8-0-SP : RAYCHEM ATUM 4:1 Heat Shrink Tubing | TE Connectivity

ATUM-32/8-0-STK TE Connectivity / Raychem | Mouser
--------------------------------------------------

 ![ATUM-32/8-0-STK TE Connectivity / Raychem | Mouser](https://www.mouser.com/images/marketingid/2025/df/149183685.jpg?v=081226.0648) <small>www.mouser.com</small>ATUM-32/8-0-STK TE Connectivity / Raychem | Mouser

ATUM-32/8-0-SP : RAYCHEM ATUM 4:1 Heat Shrink Tubing | TE Connectivity
----------------------------------------------------------------------

 ![ATUM-32/8-0-SP : RAYCHEM ATUM 4:1 Heat Shrink Tubing | TE Connectivity](https://www.te.com/content/dam/te-com/catalog/part/EM5/611/600/EM56116001-t1.jpg/jcr:content/renditions/product-small.png) <small>www.te.com</small>ATUM-32/8-0-SP : RAYCHEM ATUM 4:1 Heat Shrink Tubing | TE Connectivity

ATUM-32/8-0-STK | Tubos Termorretráctiles TE Connectivity De Poliolefina Negro, Ø 32 Mm, Long. 1
------------------------------------------------------------------------------------------------

 ![ATUM-32/8-0-STK | Tubos termorretráctiles TE Connectivity de Poliolefina Negro, Ø 32 mm, long. 1](https://media.rs-online.com/image/upload/bo_1.5px_solid_white,b_auto,c_pad,dpr_2,f_auto,h_399,q_auto,w_710/c_pad,h_399,w_710/Y0487194-01?pgw=1) <small>es.rs-online.com</small>ATUM-32/8-0-STK | Tubos termorretráctiles TE Connectivity de Poliolefina Negro, Ø 32 mm, long. 1 ...

ATUM-32/8-0-STK TE Connectivity | Raychem Products | Heilind
------------------------------------------------------------

 ![ATUM-32/8-0-STK TE Connectivity | Raychem Products | Heilind](https://sku-product-images.s3.us-east-2.amazonaws.com/AMP/1658527-6.jpg) <small>www.heilind.com</small>ATUM-32/8-0-STK TE Connectivity | Raychem Products | Heilind

RAYCHEM ATUM-32/8-0-STK Heat Shrinkable Tubing Polyolefin Black Stick BAG OF 10 | EBay
--------------------------------------------------------------------------------------

 ![RAYCHEM ATUM-32/8-0-STK Heat Shrinkable Tubing Polyolefin Black Stick BAG OF 10 | eBay](https://i.ebayimg.com/images/g/RLoAAOSwEvpg3MM5/s-l1600.jpg) <small>www.ebay.com</small>RAYCHEM ATUM-32/8-0-STK Heat Shrinkable Tubing Polyolefin Black Stick BAG OF 10 | eBay

ATUM-32/8-0 | TE Connectivity Adhesive Lined Heat Shrink Tubing, Black 32mm Sleeve Dia. X 1.2m
----------------------------------------------------------------------------------------------

 ![ATUM-32/8-0 | TE Connectivity Adhesive Lined Heat Shrink Tubing, Black 32mm Sleeve Dia. x 1.2m](https://media.rs-online.com/R3161675-01.jpg) <small>uk.rs-online.com</small>ATUM-32/8-0 | TE Connectivity Adhesive Lined Heat Shrink Tubing, Black 32mm Sleeve Dia. x 1.2m ...

ATUM-32/8-0-STK TE Connectivity - Heat Shrink Sleeve | Glued; 4: 1; 32mm; L: 1.2m; Black
----------------------------------------------------------------------------------------

 ![ATUM-32/8-0-STK TE Connectivity - Heat shrink sleeve | glued; 4: 1; 32mm; L: 1.2m; black](https://ce8dc832c.cloudimg.io/v7/_cdn_/F9/7F/90/00/0/653215_1.jpg?width=640&height=480&wat=1&wat_url=_tme-wrk_%2Ftme_new.png&wat_scale=100p&ci_sign=c38b89057a41b7f34129793c34043973cfde677c) <small>www.tme.eu</small>ATUM-32/8-0-STK TE Connectivity - Heat shrink sleeve | glued; 4: 1; 32mm; L: 1.2m; black ...

ATUM-32/8-0-STK TE Connectivity | Raychem Products | ICC
--------------------------------------------------------

 ![ATUM-32/8-0-STK TE Connectivity | Raychem Products | ICC](https://sku-product-images.s3.us-east-2.amazonaws.com/AMP/3-520117-2.jpg) <small>www.connecticc.com</small>ATUM-32/8-0-STK TE Connectivity | Raychem Products | ICC

ATUM-32/8-0-STK TE Connectivity Raychem Cable Protection | Heat Shrink Tubing | DigiKey
---------------------------------------------------------------------------------------

 ![ATUM-32/8-0-STK TE Connectivity Raychem Cable Protection | Heat Shrink Tubing | DigiKey](https://mm.digikey.com/Volume0/opasdata/d220001/derivates/1/003/226/041/MFG_ATUM-XX-X-0-SP_sml(200x200).jpg) <small>www.digikey.com</small>ATUM-32/8-0-STK TE Connectivity Raychem Cable Protection | Heat Shrink Tubing | DigiKey

ATUM-32/8-0-STK TE Connectivity Raychem Cable Protection | Cables, Wires - Management | DigiKey
-----------------------------------------------------------------------------------------------

 ![ATUM-32/8-0-STK TE Connectivity Raychem Cable Protection | Cables, Wires - Management | DigiKey](https://mm.digikey.com/Volume0/opasdata/d220001/medias/images/2506/ATUM-32^8-0-STK.jpg) <small>www.digikey.com</small>ATUM-32/8-0-STK TE Connectivity Raychem Cable Protection | Cables, Wires - Management | DigiKey

ATUM-32/8-0-STK TE Connectivity / Raychem | Mouser
--------------------------------------------------

 ![ATUM-32/8-0-STK TE Connectivity / Raychem | Mouser](https://www.mouser.com/images/tycoelectronics/sm/NB09012001_SPL.jpg?nosprite) <small>www.mouser.com</small>ATUM-32/8-0-STK TE Connectivity / Raychem | Mouser

ATUM-32/8-0-STK Heat Shrink Tubing By RAYCHEM CONNECTIVITY
----------------------------------------------------------

 ![ATUM-32/8-0-STK Heat Shrink Tubing by RAYCHEM CONNECTIVITY](https://cdn.radwell.com/productgoogleimages/8acaf8a8d0cd4086b935a201d726ef94.jpg) <small>www.radwell.com</small>ATUM-32/8-0-STK Heat Shrink Tubing by RAYCHEM CONNECTIVITY

ATUM-32/8-0-STK TE Connectivity | Raychem Products | Heilind
------------------------------------------------------------

 ![ATUM-32/8-0-STK TE Connectivity | Raychem Products | Heilind](https://sku-product-images.s3.us-east-2.amazonaws.com/AMP/204370-8.png) <small>www.heilind.com</small>ATUM-32/8-0-STK TE Connectivity | Raychem Products | Heilind

Raychem热缩套管 - ATUM-32/8-0-STK - TYCO/RAYCHEM (中国 江苏省 贸易商) - 端子、连接器 - 电子元器件 产品 「自助贸易」
------------------------------------------------------------------------------------

 ![raychem热缩套管 - ATUM-32/8-0-STK - TYCO/RAYCHEM (中国 江苏省 贸易商) - 端子、连接器 - 电子元器件 产品 「自助贸易」](https://img.diytrade.com/smimg/1006846/11623083-5502897-0/raychem热缩套管/6b92.jpg) <small>cn.diytrade.com</small>raychem热缩套管 - ATUM-32/8-0-STK - TYCO/RAYCHEM (中国 江苏省 贸易商) - 端子、连接器 - 电子元器件 产品 「自助贸易」

atum-32/8-0-stk te connectivity raychem cable protection. Atum-32/8-0-stk te connectivity raychem cable protection. Raychem atum-32/8-0-stk heat shrinkable tubing polyolefin black stick bag of 10
