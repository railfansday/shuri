---
title: "Greve Geral Portugal 2026 - Greve geral a 3 de junho"
description: "portugal: forte mobilisation pour la grève générale contre la réforme du code du travail"
date: "2026-04-04"
categories:
- "Uncategorized"
images:
- "https://s2-oglobo.glbimg.com/ae-of62TGgzgGWKo2Kqip1BMKGs=/0x0:7495x4999/888x0/smart/filters:strip_icc()/i.s3.glbimg.com/v1/AUTH_da025474c0c44edd99332dddb09cabe8/internal_photos/bs/2026/7/Y/lvi32BSLCS92LGu03jAg/115141022-people-take-part-in-a-demonstration-in-lisbon-on-july-3-2026-called-by-the-main-unions-due.jpg"
featuredImage: "https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA1QBjfX.img?w=1200&amp;h=800&amp;m=4&amp;q=70"
featured_image: "https://www.acoliveira.pt/wp-content/uploads/2026/04/7e9f6ec4-4873-4685-897b-30c62aab02d6.png"
image: "https://ogimg.infoglobo.com.br/in/4387791-fd9-94b/FT1086A/760/foto2.jpg?posicaoFoto2"
---

If you are looking for Au Portugal, une grève générale spectaculaire contre la réforme du Code du travail - Force Ouvrière you've came to the right page. We have 35 Pics about Au Portugal, une grève générale spectaculaire contre la réforme du Code du travail - Force Ouvrière like STML | Trabalhadores do Município de Lisboa também aderem à Greve Geral - CGTP-IN, Portugal faz greve geral contra mudanças na lei trabalhista | G1 and also Portugal para com greve geral: o que está por trás dos protestos contra a reforma trabalhista. Read more:

Au Portugal, Une Grève Générale Spectaculaire Contre La Réforme Du Code Du Travail - Force Ouvrière
---------------------------------------------------------------------------------------------------

 ![Au Portugal, une grève générale spectaculaire contre la réforme du Code du travail - Force Ouvrière](https://www.force-ouvriere.fr/local/adapt-img/960/10x/IMG/jpg/16-600423563_18381989923144979_7467412231589491680_n.jpg?1767691685) <small>www.force-ouvriere.fr</small>Au Portugal, une grève générale spectaculaire contre la réforme du Code du travail - Force Ouvrière

Greve Geral Em Portugal Contra Reforma Trabalhista Paralisa Trens, Voos E Escolas - Avenue
------------------------------------------------------------------------------------------

 ![Greve geral em Portugal contra reforma trabalhista paralisa trens, voos e escolas - Avenue](https://connection.avenue.us/wp-content/uploads/2026/06/2026-06-03T141214Z_1_LYNXMPEM5214U_RTROPTP_4_PORTUGAL-LABOUR-GENERAL-STRIKE-1024x683.jpg) <small>connection.avenue.us</small>Greve geral em Portugal contra reforma trabalhista paralisa trens, voos e escolas - Avenue ...

Imagens Do Dia De Greve Geral Em Portugal - Jornal O Globo
----------------------------------------------------------

 ![Imagens do dia de greve geral em Portugal - Jornal O Globo](https://ogimg.infoglobo.com.br/in/4387791-fd9-94b/FT1086A/760/foto2.jpg?posicaoFoto2) <small>oglobo.globo.com</small>Imagens do dia de greve geral em Portugal - Jornal O Globo

Mais De 50 Sindicatos Aderem à Greve Geral Marcada Para 11 De Dezembro
----------------------------------------------------------------------

 ![Mais de 50 sindicatos aderem à greve geral marcada para 11 de dezembro](https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA1QBjfX.img?w=1200&h=800&m=4&q=70) <small>www.msn.com</small>Mais de 50 sindicatos aderem à greve geral marcada para 11 de dezembro

CGTP Entrega Hoje Pré-aviso De Greve Geral Para "derrotar O Pacote Laboral" - Portugal - SÁBADO
-----------------------------------------------------------------------------------------------

 ![CGTP entrega hoje pré-aviso de greve geral para "derrotar o pacote laboral" - Portugal - SÁBADO](https://cdn.sabado.pt/images/2026-05/img_1920x1080uu2026-05-01-16-01-52-764693.jpg) <small>www.sabado.pt</small>CGTP entrega hoje pré-aviso de greve geral para "derrotar o pacote laboral" - Portugal - SÁBADO

Pré-Aviso De Greve – 17 De Abril De 2026 – Página 2 – AE António Correia De Oliveira
------------------------------------------------------------------------------------

 ![Pré-Aviso de Greve – 17 de abril de 2026 – Página 2 – AE António Correia de Oliveira](https://www.acoliveira.pt/wp-content/uploads/2026/04/7e9f6ec4-4873-4685-897b-30c62aab02d6.png) <small>www.acoliveira.pt</small>Pré-Aviso de Greve – 17 de abril de 2026 – Página 2 – AE António Correia de Oliveira

Portugal: Uma Grande Greve Geral Para Derrotar O Pacote Laboral - CIG: Confederación
------------------------------------------------------------------------------------

 ![Portugal: Uma grande greve geral para derrotar o pacote laboral - CIG: Confederación](https://www.cig.gal/assets/images/6/20251209_portugal.greve-34c19476.jpg) <small>www.cig.gal</small>Portugal: Uma grande greve geral para derrotar o pacote laboral - CIG: Confederación ...

Nacional - FENPROF
------------------

 ![Nacional - FENPROF](https://www.fenprof.pt/media/download/FA35D84EB902AC7A6FFE8691F2CE04D8/2026_05_16-manifestacao-ecd-2.jpeg?width=800&rxy=0.5) <small>www.fenprof.pt</small>Nacional - FENPROF

Manifestação Em Frente Ao Parlamento Resultou Em Seis Detidos: Tudo Sobre A Greve Geral
---------------------------------------------------------------------------------------

 ![Manifestação em frente ao Parlamento resultou em seis detidos: tudo sobre a greve geral](https://cdn.sabado.pt/images/2025-12/img_1200x676uu2025-12-11-12-44-17-752810.jpg) <small>www.sabado.pt</small>Manifestação em frente ao Parlamento resultou em seis detidos: tudo sobre a greve geral ...

Portugal Para Com Greve Geral: O Que Está Por Trás Dos Protestos Contra A Reforma Trabalhista
---------------------------------------------------------------------------------------------

 ![Portugal para com greve geral: o que está por trás dos protestos contra a reforma trabalhista](https://imigrar.org/wp-content/uploads/2026/06/PZER2BKEB5BETFWX6625KVBAUU-scaled.jpg) <small>imigrar.org</small>Portugal para com greve geral: o que está por trás dos protestos contra a reforma trabalhista ...

Greve Geral - 3 De Junho De 2026 | Concentrações - CGTP-IN
----------------------------------------------------------

 ![Greve Geral - 3 de Junho de 2026 | Concentrações - CGTP-IN](https://www.cgtp.pt/images/images/2026/05/CONCENTRACOES-GG.jpg) <small>www.cgtp.pt</small>Greve Geral - 3 de Junho de 2026 | Concentrações - CGTP-IN

Dados Da Adesão à Greve Geral | 18h00 - CGTP-IN
-----------------------------------------------

 ![Dados da adesão à Greve Geral | 18h00 - CGTP-IN](https://www.cgtp.pt/images/images/2026/06/resolucao_grevegeral.jpg) <small>www.cgtp.pt</small>Dados da adesão à Greve Geral | 18h00 - CGTP-IN

O Que Vai Parar Com A Greve Geral De 3 De Junho? - Portugal - SÁBADO
--------------------------------------------------------------------

 ![O que vai parar com a greve geral de 3 de junho? - Portugal - SÁBADO](https://cdn.sabado.pt/images/2026-05/img_980x653uu2026-05-21-18-26-04-766232.jpg) <small>www.sabado.pt</small>O que vai parar com a greve geral de 3 de junho? - Portugal - SÁBADO

Greve Geral A 3 De Junho
------------------------

 ![Greve Geral a 3 de junho](https://jornaldemafra.pt/wp-content/uploads/2026/06/Greve-geral-2026.webp) <small>jornaldemafra.pt</small>Greve Geral a 3 de junho

Professores Deram Uma Forte Expressão à Greve Geral De 3 De Junho - FENPROF
---------------------------------------------------------------------------

 ![Professores deram uma forte expressão à Greve Geral de 3 de junho - FENPROF](https://www.fenprof.pt/media/download/6FDA79F0A62C1CB1E79A4D96032CBC0A/foto-greve-na-rua.jpg) <small>www.fenprof.pt</small>Professores deram uma forte expressão à Greve Geral de 3 de junho - FENPROF

Portugal Volta A Parar: Greve Geral Mobiliza Trabalhadores Contra Alterações à Lei Laboral
------------------------------------------------------------------------------------------

 ![Portugal volta a parar: greve geral mobiliza trabalhadores contra alterações à lei laboral](https://pressnet.pt/app/uploads/2026/06/image-8.png) <small>pressnet.pt</small>Portugal volta a parar: greve geral mobiliza trabalhadores contra alterações à lei laboral ...

Portugal Faz Greve Geral Contra Mudanças Na Lei Trabalhista | G1
----------------------------------------------------------------

 ![Portugal faz greve geral contra mudanças na lei trabalhista | G1](https://s2-g1.glbimg.com/02TFp0WTXe014uO-QFFVxRua930=/5472x0/filters:format(jpeg)/https://i.s3.glbimg.com/v1/AUTH_59edd422c0c84a879bd37670ae4f538a/internal_photos/bs/2026/8/D/NHXiHRSYiCUPUHUimdMQ/2026-05-26t135550z-2088829895-rc21rkatd17q-rtrmadp-3-portugal-economy-primeminister.jpg) <small>g1.globo.com</small>Portugal faz greve geral contra mudanças na lei trabalhista | G1

AVISO PRÉVIO DE GREVE GERAL 3 JUNHO 2026 – STTS
-----------------------------------------------

 ![AVISO PRÉVIO DE GREVE GERAL 3 JUNHO 2026 – STTS](https://www.stts.pt/wp-content/uploads/2026/05/Imagem1-210x136.png) <small>www.stts.pt</small>AVISO PRÉVIO DE GREVE GERAL 3 JUNHO 2026 – STTS

Manifestação Em Frente Ao Parlamento Resultou Em Seis Detidos: Tudo Sobre A Greve Geral
---------------------------------------------------------------------------------------

 ![Manifestação em frente ao Parlamento resultou em seis detidos: tudo sobre a greve geral](https://cdn.sabado.pt/images/2025-12/img_1320x742uu2025-12-11-15-03-48-752830.jpg) <small>www.sabado.pt</small>Manifestação em frente ao Parlamento resultou em seis detidos: tudo sobre a greve geral ...

Portugal: Forte Mobilisation Pour La Grève Générale Contre La Réforme Du Code Du Travail - RFI
----------------------------------------------------------------------------------------------

 ![Portugal: forte mobilisation pour la grève générale contre la réforme du Code du travail - RFI](https://s.rfi.fr/media/display/9c74931a-d6be-11f0-ba2c-005056a97e36/w:1280/p:16x9/000-87UN6EK.jpg) <small>www.rfi.fr</small>Portugal: forte mobilisation pour la grève générale contre la réforme du Code du travail - RFI

Greve Geral Em Portugal Cancela Voos E Afeta Serviços Essenciais: Sindicatos Protestam Contra
---------------------------------------------------------------------------------------------

 ![Greve geral em Portugal cancela voos e afeta serviços essenciais: sindicatos protestam contra](https://s2-oglobo.glbimg.com/ae-of62TGgzgGWKo2Kqip1BMKGs=/0x0:7495x4999/888x0/smart/filters:strip_icc()/i.s3.glbimg.com/v1/AUTH_da025474c0c44edd99332dddb09cabe8/internal_photos/bs/2026/7/Y/lvi32BSLCS92LGu03jAg/115141022-people-take-part-in-a-demonstration-in-lisbon-on-july-3-2026-called-by-the-main-unions-due.jpg) <small>oglobo.globo.com</small>Greve geral em Portugal cancela voos e afeta serviços essenciais: sindicatos protestam contra ...

Greve Geral Paralisa Portugal Contra Precarização De Direitos
-------------------------------------------------------------

 ![Greve geral paralisa Portugal contra precarização de direitos](https://pcdob.org.br/wp-content/uploads/2025/12/Ruas-de-Lisboa-foram-tomadas-por-trabalhadores-durante-a-greve-geral-Rafael-Medeiros-Esquerda.jpg) <small>pcdob.org.br</small>Greve geral paralisa Portugal contra precarização de direitos

Greve Contra Reforma Trabalhista Em Portugal Paralisa Trens, Reduz Voos E Fecha Escolas | Mundo
-----------------------------------------------------------------------------------------------

 ![Greve contra reforma trabalhista em Portugal paralisa trens, reduz voos e fecha escolas | Mundo](https://s2-valor.glbimg.com/4vR_2uY25dJGMy8ZVvqi2yGFVV0=/0x0:4000x2667/888x0/smart/filters:strip_icc()/i.s3.glbimg.com/v1/AUTH_63b422c2caee4269b8b34177e8876b93/internal_photos/bs/2026/i/K/IRKRylTBC6ihg48Gb0hw/457542349.jpg) <small>valor.globo.com</small>Greve contra reforma trabalhista em Portugal paralisa trens, reduz voos e fecha escolas | Mundo ...

AVISO PRÉVIO DE GREVE TRABALHADORES ADMINISTRAÇÃO PÚBLICA 16 DE MAIO 2025 – STTS
--------------------------------------------------------------------------------

 ![AVISO PRÉVIO DE GREVE TRABALHADORES ADMINISTRAÇÃO PÚBLICA 16 DE MAIO 2025 – STTS](https://www.stts.pt/wp-content/uploads/2025/05/CAPA.jpg) <small>www.stts.pt</small>AVISO PRÉVIO DE GREVE TRABALHADORES ADMINISTRAÇÃO PÚBLICA 16 DE MAIO 2025 – STTS

Greve Geral Histórica Em Portugal Paralisa Transportes, Fecha Escolas E Pressiona Hospitais
-------------------------------------------------------------------------------------------

 ![Greve geral histórica em Portugal paralisa transportes, fecha escolas e pressiona hospitais](https://p2.trrsf.com/image/fget/cf/1200/630/middle/images.terra.com/2025/12/11/greve-ubj4bs8ccokh.png) <small>www.terra.com.br</small>Greve geral histórica em Portugal paralisa transportes, fecha escolas e pressiona hospitais

AVISO PRÉVIO DE GREVE GERAL 3 JUNHO 2026 – STTS
-----------------------------------------------

 ![AVISO PRÉVIO DE GREVE GERAL 3 JUNHO 2026 – STTS](https://www.stts.pt/wp-content/uploads/2026/05/123654-1024x871.jpg) <small>www.stts.pt</small>AVISO PRÉVIO DE GREVE GERAL 3 JUNHO 2026 – STTS

Dados Recolhidos Até às 19h20 Demonstram Que A Greve Geral Parou O País - CGTP-IN
---------------------------------------------------------------------------------

 ![Dados recolhidos até às 19h20 demonstram que a Greve Geral parou o país - CGTP-IN](https://www.cgtp.pt/images/images/2025/11/gg_banner2025.jpg) <small>www.cgtp.pt</small>Dados recolhidos até às 19h20 demonstram que a Greve Geral parou o país - CGTP-IN

Dados Recolhidos Até às 19h20 Demonstram Que A Greve Geral Parou O País - CGTP-IN
---------------------------------------------------------------------------------

 ![Dados recolhidos até às 19h20 demonstram que a Greve Geral parou o país - CGTP-IN](https://cgtp.pt/images/images/2026/06/Captura de ecra 2026-06-03 120926.png#joomlaImage:/local-images/images/2026/06/Captura de ecra 2026-06-03 120926.png?width=1162&height=610) <small>www.cgtp.pt</small>Dados recolhidos até às 19h20 demonstram que a Greve Geral parou o país - CGTP-IN

Greve Geral Paralisa Serviços Em Portugal Contra Reforma Trabalhista - Portal Em Tempo
--------------------------------------------------------------------------------------

 ![Greve geral paralisa serviços em Portugal contra reforma trabalhista - Portal Em Tempo](https://emtempo.com.br/wp-content/uploads/2026/06/greve-portugal.jpg) <small>emtempo.com.br</small>Greve geral paralisa serviços em Portugal contra reforma trabalhista - Portal Em Tempo

SPGL - Professores, Educadores E Investigadores Na Greve Geral | 3 De Junho 2026
--------------------------------------------------------------------------------

 ![SPGL - Professores, educadores e investigadores na Greve Geral | 3 de junho 2026](https://www.spgl.pt/Media/Default/_Profiles/7494e02c/a9d870bd/Flyer Greve Geral_page-0001.jpg?v=639147970016913172) <small>www.spgl.pt</small>SPGL - Professores, educadores e investigadores na Greve Geral | 3 de junho 2026

STML | Trabalhadores Do Município De Lisboa Também Aderem à Greve Geral - CGTP-IN
---------------------------------------------------------------------------------

 ![STML | Trabalhadores do Município de Lisboa também aderem à Greve Geral - CGTP-IN](https://www.cgtp.pt/images/images/2026/06/tiago-greve-geral.jpg) <small>www.cgtp.pt</small>STML | Trabalhadores do Município de Lisboa também aderem à Greve Geral - CGTP-IN

Greve Histórica Em Portugal: Três Milhões Cruzam Os Braços Em Protesto Contra Medidas De
----------------------------------------------------------------------------------------

 ![Greve histórica em Portugal: três milhões cruzam os braços em protesto contra medidas de](https://ogimg.infoglobo.com.br/in/2920985-315-96f/FT1086A/Manifestante-no-Centro-de-Lisboa-na-primeira-greve-geral-em-mais-de-duas-decadasFrancisco-LeongAFP.jpg) <small>oglobo.globo.com</small>Greve histórica em Portugal: três milhões cruzam os braços em protesto contra medidas de ...

Aviso Prévio De Greve Administração Pública – Setor Público Empresarial – IPSS 23 DE MARÇO DE
---------------------------------------------------------------------------------------------

 ![Aviso prévio de greve Administração Pública – Setor Público Empresarial – IPSS 23 DE MARÇO DE](https://www.stts.pt/wp-content/uploads/2026/03/CAPA.png) <small>www.stts.pt</small>Aviso prévio de greve Administração Pública – Setor Público Empresarial – IPSS 23 DE MARÇO DE ...

Greve Geral Paralisa Portugal Em Protesto Contra Reforma Trabalhista
--------------------------------------------------------------------

 ![Greve geral paralisa Portugal em protesto contra reforma trabalhista](https://p2.trrsf.com/image/fget/cf/1200/630/middle/images.terra.com/2026/06/03/greve-portugal-1k1txsf2tqcds.jpg) <small>www.terra.com.br</small>Greve geral paralisa Portugal em protesto contra reforma trabalhista

Category:General Strike 11 December 2025 (Portugal) - Wikimedia Commons
-----------------------------------------------------------------------

 ![Category:General strike 11 December 2025 (Portugal) - Wikimedia Commons](https://upload.wikimedia.org/wikipedia/commons/thumb/d/d1/Convocatórias_nas_ruas_sobre_a_Greve_Geral_de_7_de_dezembro_2025%2C_em_Portugal_07.jpg/960px-Convocatórias_nas_ruas_sobre_a_Greve_Geral_de_7_de_dezembro_2025%2C_em_Portugal_07.jpg) <small>commons.wikimedia.org</small>Category:General strike 11 December 2025 (Portugal) - Wikimedia Commons

Greve geral paralisa portugal em protesto contra reforma trabalhista. Aviso prévio de greve geral 3 junho 2026 – stts. Cgtp entrega hoje pré-aviso de greve geral para "derrotar o pacote laboral"
