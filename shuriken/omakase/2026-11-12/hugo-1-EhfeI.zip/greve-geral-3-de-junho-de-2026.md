---
title: "Greve Geral 3 De Junho De 2026 - Comunicado snmv – greve geral 3 junho 2026 – snmv"
description: "Cgtp convoca greve geral para 3 de junho"
date: "2026-10-16"
categories:
- "Uncategorized"
images:
- "https://cgtp.pt/images/images/2026/06/Captura de ecra 2026-06-03 120926.png#joomlaImage:/local-images/images/2026/06/Captura de ecra 2026-06-03 120926.png?width=1162&amp;height=610"
featuredImage: "https://www.fenprof.pt/media/download/510F5035E5C8AED530130C74C48BB00C/2026_05_16-manif-ecd-spra1.jpg?width=800&amp;rxy=0.5"
featured_image: "https://cdn.sabado.pt/images/2026-05/img_1200x676uu2026-05-21-18-26-04-766232.jpg"
image: "https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA229tFU.img?w=1440&amp;h=960&amp;m=4&amp;q=84"
---

If you are searching about Greve Geral - CGTP-IN you've visit to the right web. We have 35 Images about Greve Geral - CGTP-IN like Comunicado SNMV – Greve Geral 3 junho 2026 – SNMV, Greve Geral – dia 3 de junho - SPRA and also CGTP convoca greve geral para 3 de junho, UGT não exclui. Read more:

Greve Geral - CGTP-IN
---------------------

 ![Greve Geral - CGTP-IN](https://www.cgtp.pt/images/images/2026/06/resolucao_grevegeral.jpg) <small>www.cgtp.pt</small>Greve Geral - CGTP-IN

CGTP Anuncia No Dia Do Trabalhador Nova Greve Geral No Dia 3 De Junho
---------------------------------------------------------------------

 ![CGTP anuncia no Dia do Trabalhador nova greve geral no dia 3 de junho](https://staticx.noticiasilimitadas.pt/jn/image.webp?brand=jn&type=generate&guid=7ff89168-6db6-48c6-a848-7f6391614ee9&w=3840) <small>www.jn.pt</small>CGTP anuncia no Dia do Trabalhador nova greve geral no dia 3 de junho

Greve Geral - 03 De Junho De 2026
---------------------------------

 ![Greve Geral - 03 de junho de 2026](https://cabeceirasdebasto.pt/files/46/46246.jpg) <small>cabeceirasdebasto.pt</small>Greve Geral - 03 de junho de 2026

Greve Geral – Dia 3 De Junho - SPRA
-----------------------------------

 ![Greve Geral – dia 3 de junho - SPRA](https://www.spra.pt/wp-content/uploads/2026/05/Greve_Acores-768x1024.jpg) <small>www.spra.pt</small>Greve Geral – dia 3 de junho - SPRA

GREVE GERAL - 3 JUNHO 2026 | Resolução - CGTP-IN
------------------------------------------------

 ![GREVE GERAL - 3 JUNHO 2026 | Resolução - CGTP-IN](https://www.cgtp.pt/images/images/2026/06/tiago-greve-geral.jpg) <small>www.cgtp.pt</small>GREVE GERAL - 3 JUNHO 2026 | Resolução - CGTP-IN

Comunicado SNMV – Greve Geral 3 Junho 2026 – SNMV
-------------------------------------------------

 ![Comunicado SNMV – Greve Geral 3 junho 2026 – SNMV](https://snmv.pt/wp-content/uploads/2026/06/qwqwqweqwq-724x1024.png) <small>snmv.pt</small>Comunicado SNMV – Greve Geral 3 junho 2026 – SNMV

Greve Geral Em Lisboa A 3 De Junho: O Que Pára Na Cidade
--------------------------------------------------------

 ![Greve geral em Lisboa a 3 de Junho: o que pára na cidade](https://media.timeout.com/images/106411166/image.jpg) <small>www.timeout.pt</small>Greve geral em Lisboa a 3 de Junho: o que pára na cidade

Greve Geral – Dia 3 De Junho - SPRA
-----------------------------------

 ![Greve Geral – dia 3 de junho - SPRA](https://www.spra.pt/wp-content/uploads/2026/05/banner-gg2026-1.jpg) <small>www.spra.pt</small>Greve Geral – dia 3 de junho - SPRA

Greve Geral - 3 De Junho De 2026 | Concentrações - CGTP-IN
----------------------------------------------------------

 ![Greve Geral - 3 de Junho de 2026 | Concentrações - CGTP-IN](https://www.cgtp.pt/images/images/2026/05/CONCENTRACOES-GG.jpg) <small>www.cgtp.pt</small>Greve Geral - 3 de Junho de 2026 | Concentrações - CGTP-IN

A Greve Geral De 3 De Junho é Para Todos Os Trabalhadores
---------------------------------------------------------

 ![A greve geral de 3 de junho é para todos os trabalhadores](https://www.sep.org.pt/files/uploads/2026/05/SEP_03_JUNHO-04.jpg) <small>www.sep.org.pt</small>A greve geral de 3 de junho é para todos os trabalhadores

Greve Geral De 24 Horas No Dia 3 De Junho- Serviço De Transporte Afetado
------------------------------------------------------------------------

 ![Greve geral de 24 horas no dia 3 de junho- Serviço de transporte afetado](https://www.metrolisboa.pt/institucional/wp-content/uploads/sites/2/2026/06/greve-3-junho_1080x450.png) <small>www.metrolisboa.pt</small>Greve geral de 24 horas no dia 3 de junho- Serviço de transporte afetado

CGTP Convoca Greve Geral Para 3 De Junho, UGT Não Exclui
--------------------------------------------------------

 ![CGTP convoca greve geral para 3 de junho, UGT não exclui](https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA229tFU.img?w=1440&h=960&m=4&q=84) <small>www.msn.com</small>CGTP convoca greve geral para 3 de junho, UGT não exclui

MAIO É FESTA! MAIO É LUTA! GREVE GERAL - 3 DE JUNHO — União Dos Sindicatos De Lisboa - USL/CGTP-IN
--------------------------------------------------------------------------------------------------

 ![MAIO É FESTA! MAIO É LUTA! GREVE GERAL - 3 DE JUNHO — União dos Sindicatos de Lisboa - USL/CGTP-IN](https://uniaolisboa-cgtp.pt/images/stories/uniao_imgs/2026/202605/IMG_4310.jpeg) <small>uniaolisboa-cgtp.pt</small>MAIO É FESTA! MAIO É LUTA! GREVE GERAL - 3 DE JUNHO — União dos Sindicatos de Lisboa - USL/CGTP-IN

Transportes, Escolas E Hospitais: O Que Esperar Da Greve De 3 De Junho - Dinheiro - SÁBADO
------------------------------------------------------------------------------------------

 ![Transportes, escolas e hospitais: o que esperar da greve de 3 de junho - Dinheiro - SÁBADO](https://cdn.sabado.pt/images/2026-05/img_980x653uu2026-05-30-11-36-15-766875.jpg) <small>www.sabado.pt</small>Transportes, escolas e hospitais: o que esperar da greve de 3 de junho - Dinheiro - SÁBADO

CGTP Avança Com Greve Geral Para 3 De Junho
-------------------------------------------

 ![CGTP avança com greve geral para 3 de junho](https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA229Sqw.img?w=1200&h=800&m=4&q=70) <small>www.msn.com</small>CGTP avança com greve geral para 3 de junho

FNSTFPS Já Emitiu Aviso Prévio Para A Greve Geral De 3 De Junho! - CGTP-IN
--------------------------------------------------------------------------

 ![FNSTFPS já emitiu Aviso Prévio para a Greve Geral de 3 de Junho! - CGTP-IN](https://www.cgtp.pt/images/accao-e-luta/2026/05/greve-geral-funcao-publica.jpg) <small>www.cgtp.pt</small>FNSTFPS já emitiu Aviso Prévio para a Greve Geral de 3 de Junho! - CGTP-IN

Nacional - FENPROF
------------------

 ![Nacional - FENPROF](https://www.fenprof.pt/media/download/510F5035E5C8AED530130C74C48BB00C/2026_05_16-manif-ecd-spra1.jpg?width=800&rxy=0.5) <small>www.fenprof.pt</small>Nacional - FENPROF

AVISO PRÉVIO DE GREVE GERAL 3 JUNHO 2026 – STTS
-----------------------------------------------

 ![AVISO PRÉVIO DE GREVE GERAL 3 JUNHO 2026 – STTS](https://www.stts.pt/wp-content/uploads/2026/05/123654.jpg) <small>www.stts.pt</small>AVISO PRÉVIO DE GREVE GERAL 3 JUNHO 2026 – STTS

Aviso | Greves Em Junho De 2026 – AE António Correia De Oliveira
----------------------------------------------------------------

 ![Aviso | Greves em junho de 2026 – AE António Correia de Oliveira](https://www.acoliveira.pt/wp-content/uploads/2026/05/ChatGPT-Image-31_05_2026-22_43_43.png) <small>www.acoliveira.pt</small>Aviso | Greves em junho de 2026 – AE António Correia de Oliveira

SPGL - Professores, Educadores E Investigadores Na Greve Geral | 3 De Junho 2026
--------------------------------------------------------------------------------

 ![SPGL - Professores, educadores e investigadores na Greve Geral | 3 de junho 2026](https://www.spgl.pt/Media/Default/_Profiles/7494e02c/a9d870bd/Flyer Greve Geral_page-0002.jpg?v=639147970017538180) <small>www.spgl.pt</small>SPGL - Professores, educadores e investigadores na Greve Geral | 3 de junho 2026

Dados Recolhidos Até às 19h20 Demonstram Que A Greve Geral Parou O País - CGTP-IN
---------------------------------------------------------------------------------

 ![Dados recolhidos até às 19h20 demonstram que a Greve Geral parou o país - CGTP-IN](https://cgtp.pt/images/images/2026/06/Captura de ecra 2026-06-03 120926.png#joomlaImage:/local-images/images/2026/06/Captura de ecra 2026-06-03 120926.png?width=1162&height=610) <small>www.cgtp.pt</small>Dados recolhidos até às 19h20 demonstram que a Greve Geral parou o país - CGTP-IN

AVISO PRÉVIO DE GREVE TRABALHADORES ADMINISTRAÇÃO PÚBLICA 16 DE MAIO 2025 – STTS
--------------------------------------------------------------------------------

 ![AVISO PRÉVIO DE GREVE TRABALHADORES ADMINISTRAÇÃO PÚBLICA 16 DE MAIO 2025 – STTS](https://www.stts.pt/wp-content/uploads/2025/05/CAPA.jpg) <small>www.stts.pt</small>AVISO PRÉVIO DE GREVE TRABALHADORES ADMINISTRAÇÃO PÚBLICA 16 DE MAIO 2025 – STTS

Greve Geral De 3 De Junho: O Que Está Em Causa, Quem Pode Aderir E Que Impacto Se Prevê
---------------------------------------------------------------------------------------

 ![Greve Geral de 3 de junho: o que está em causa, quem pode aderir e que impacto se prevê](https://sabiasque.pt/images/stories/2026/trabalho/20260602-greve-geral-3-junho-1024x683.jpg) <small>sabiasque.pt</small>Greve Geral de 3 de junho: o que está em causa, quem pode aderir e que impacto se prevê

GREVE GERAL DE 3 DE JUNHO – AS FAQ EM IMAGENS – Spzs Site
---------------------------------------------------------

 ![GREVE GERAL DE 3 DE JUNHO – AS FAQ EM IMAGENS – spzs site](http://www.spzs.pt/wp-content/uploads/2026/05/faq-gg-24.jpeg) <small>www.spzs.pt</small>GREVE GERAL DE 3 DE JUNHO – AS FAQ EM IMAGENS – spzs site

Professores Deram Uma Forte Expressão à Greve Geral De 3 De Junho - FENPROF
---------------------------------------------------------------------------

 ![Professores deram uma forte expressão à Greve Geral de 3 de junho - FENPROF](https://www.fenprof.pt/media/download/6FDA79F0A62C1CB1E79A4D96032CBC0A/foto-greve-na-rua.jpg) <small>www.fenprof.pt</small>Professores deram uma forte expressão à Greve Geral de 3 de junho - FENPROF

CGTP Convoca Greve Geral Para Dia 3 De Junho E UGT Poderá Aderir
----------------------------------------------------------------

 ![CGTP convoca greve geral para dia 3 de junho e UGT poderá aderir](https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA22c4u7.img?w=1024&h=576&m=4&q=81) <small>www.msn.com</small>CGTP convoca greve geral para dia 3 de junho e UGT poderá aderir

AVISO PRÉVIO DE GREVE GERAL 3 JUNHO 2026 – STTS
-----------------------------------------------

 ![AVISO PRÉVIO DE GREVE GERAL 3 JUNHO 2026 – STTS](https://www.stts.pt/wp-content/uploads/2026/05/Imagem1-210x136.png) <small>www.stts.pt</small>AVISO PRÉVIO DE GREVE GERAL 3 JUNHO 2026 – STTS

CGTP Confirma: Nova Greve Geral Convocada Para 3 De Junho
---------------------------------------------------------

 ![CGTP confirma: nova greve geral convocada para 3 de junho](https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA229V01.img?w=768&h=512&m=6&x=156&y=111&s=591&d=188) <small>www.msn.com</small>CGTP confirma: nova greve geral convocada para 3 de junho

NOTA INFORMATIVA Nº17/2026 - GREVE GERAL | 3 DE JUNHO DE 2026 - STI - Sindicato Dos
-----------------------------------------------------------------------------------

 ![NOTA INFORMATIVA Nº17/2026 - GREVE GERAL | 3 DE JUNHO DE 2026 - STI - Sindicato dos](https://stimpostos.pt/wp-content/uploads/2026/05/notas-informativas-2024-27.jpg) <small>stimpostos.pt</small>NOTA INFORMATIVA Nº17/2026 - GREVE GERAL | 3 DE JUNHO DE 2026 - STI - Sindicato dos ...

GREVE GERAL 3 JUNHO | Concentrações/Manifestações
-------------------------------------------------

 ![GREVE GERAL 3 JUNHO | Concentrações/Manifestações](https://www.stal.pt/images/2026/CONCENTRACOES-GG_Site.jpg#joomlaImage:/local-images/2026/CONCENTRACOES-GG_Site.jpg?width=1080&height=720) <small>www.stal.pt</small>GREVE GERAL 3 JUNHO | Concentrações/Manifestações

Balanço Da Greve Geral - CGTP-IN
--------------------------------

 ![Balanço da Greve Geral - CGTP-IN](https://www.cgtp.pt/images/images/2025/11/gg_banner2025.jpg) <small>www.cgtp.pt</small>Balanço da Greve Geral - CGTP-IN

CGTP Convoca Greve Geral Para 3 De Junho
----------------------------------------

 ![CGTP convoca greve geral para 3 de junho](https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA229ere.img?w=1920&h=1080&m=4&q=75) <small>www.msn.com</small>CGTP convoca greve geral para 3 de junho

O Que Vai Parar Com A Greve Geral De 3 De Junho? - Portugal - SÁBADO
--------------------------------------------------------------------

 ![O que vai parar com a greve geral de 3 de junho? - Portugal - SÁBADO](https://cdn.sabado.pt/images/2026-05/img_1200x676uu2026-05-21-18-26-04-766232.jpg) <small>www.sabado.pt</small>O que vai parar com a greve geral de 3 de junho? - Portugal - SÁBADO

AVISO PRÉVIO DE GREVE GERAL 3 JUNHO 2026 – STTS
-----------------------------------------------

 ![AVISO PRÉVIO DE GREVE GERAL 3 JUNHO 2026 – STTS](https://www.stts.pt/wp-content/uploads/2026/05/Imagem1-86x64.png) <small>www.stts.pt</small>AVISO PRÉVIO DE GREVE GERAL 3 JUNHO 2026 – STTS

CGTP Convoca Greve Geral Para 3 De Junho — DNOTICIAS.PT
-------------------------------------------------------

 ![CGTP convoca greve geral para 3 de Junho — DNOTICIAS.PT](https://static-storage.dnoticias.pt/www-assets.dnoticias.pt/images/configuration/fb-9/logoDOC.20260113.46344276._APS0968_Fh0mFJ0.JPEG) <small>www.dnoticias.pt</small>CGTP convoca greve geral para 3 de Junho — DNOTICIAS.PT

greve geral. Aviso prévio de greve geral 3 junho 2026 – stts. Cgtp convoca greve geral para 3 de junho — dnoticias.pt
