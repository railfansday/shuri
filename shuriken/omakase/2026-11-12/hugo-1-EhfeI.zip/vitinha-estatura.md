---
title: "Vitinha Estatura - Vitinha height revealed—is psg’s midfield star really that short?"
description: "vitinha volta a treinar e pode reforçar o psg na semifinal da champions contra o bayern"
date: "2026-04-20"
categories:
- "Uncategorized"
images:
- "https://livesport-ott-images.ssl.cdn.cra.cz/r900xfq60/cac5bc38-cbf0-45ca-80f3-d6b361a0b274.jpg"
featuredImage: "https://cdn-img.staticzz.com/img/jogadores/new/12/84/421284_vitinha_20260617030911.png"
featured_image: "https://www.zerozero.pt/img/noticias/523/imgS300I1015523T20251230103117.jpg"
image: "https://sportal365images.com/process/smp-images-production/abola.pt/04092025/29b8545b-a088-4e9e-80e8-23fe3c68c4be.jpg?operations=crop(0:79:3718:2170),autocrop(1200:630)"
---

If you are searching about Vitinha fully fit to start as PSG have full-strength squad for Bayern clash – L'Equipe you've visit to the right page. We have 35 Pictures about Vitinha fully fit to start as PSG have full-strength squad for Bayern clash – L'Equipe like Vitinha agradece elogios de Zidane: «Fico muito contente» | A Bola, Roberto Martínez aponta Vitinha à Bola de Ouro: «Se não ganhar agora, tem o potencial para and also Roberto Martínez aponta Vitinha à Bola de Ouro: «Se não ganhar agora, tem o potencial para. Here you go:

Vitinha Fully Fit To Start As PSG Have Full-strength Squad For Bayern Clash – L'Equipe
--------------------------------------------------------------------------------------

 ![Vitinha fully fit to start as PSG have full-strength squad for Bayern clash – L'Equipe](https://pictures.tribuna.com/image/9574e2a3-f131-41ae-b4f2-2b1ee6c4a35d?width=1920&quality=70) <small>tribuna.com</small>Vitinha fully fit to start as PSG have full-strength squad for Bayern clash – L'Equipe ...

Vitinha Height, Weight, Age, Girlfriend, Family
-----------------------------------------------

 ![Vitinha Height, Weight, Age, Girlfriend, Family](https://healthyceleb.com/wp-content/uploads/2023/09/Vitinha-as-seen-in-a-picture-that-was-taken-in-September-2023-at-Parc-Des-Princes.jpg) <small>healthyceleb.com</small>Vitinha Height, Weight, Age, Girlfriend, Family

Real Madrid Interest In PSG Star Confirmed As Transfer Looks Impossible
-----------------------------------------------------------------------

 ![Real Madrid Interest in PSG Star Confirmed as Transfer Looks Impossible](https://icdn.psgtalk.com/wp-content/uploads/2025/04/vitinha-psg-v-arsenal-ucl-2025.jpg) <small>psgtalk.com</small>Real Madrid Interest in PSG Star Confirmed as Transfer Looks Impossible

Vitinha: «Chego No Melhor Momento Da Carreira» | A Bola
-------------------------------------------------------

 ![Vitinha: «Chego no melhor momento da carreira» | A Bola](https://sportal365images.com/process/smp-images-production/abola.pt/14062024/9c38a43c-fffe-4636-90ff-3b7b5b801f4b.jpeg?operations=crop(370:202:4500:2525),autocrop(1200:630)) <small>www.abola.pt</small>Vitinha: «Chego no melhor momento da carreira» | A Bola

PSG - "Le Match Le Plus Important De Ma Carrière", Les Mots Forts De Vitinha Avant La Finale De
-----------------------------------------------------------------------------------------------

 ![PSG - "Le Match le plus important de ma carrière", les mots forts de Vitinha avant la finale de](https://photos.madeinparisiens.com/ligue-1/2024/zoom/l1-20240917112850-2986.jpg) <small>madeinparisiens.ouest-france.fr</small>PSG - "Le Match le plus important de ma carrière", les mots forts de Vitinha avant la finale de ...

«Vitinha Representa Aquilo Que é A Excelência Da Seleção» | A Bola
------------------------------------------------------------------

 ![«Vitinha representa aquilo que é a excelência da seleção» | A Bola](https://sportal365images.com/process/smp-images-production/abola.pt/04092025/29b8545b-a088-4e9e-80e8-23fe3c68c4be.jpg?operations=crop(0:79:3718:2170),autocrop(1200:630)) <small>www.abola.pt</small>«Vitinha representa aquilo que é a excelência da seleção» | A Bola

Vitinha’s Real Height Revealed, Why His Size Doesn’t Match His Skillset - FEAST Online Magazine
-----------------------------------------------------------------------------------------------

 ![Vitinha’s Real Height Revealed, Why His Size Doesn’t Match His Skillset - FEAST Online Magazine](https://www.feastmagazine.org/wp-content/uploads/2025/06/vitinha-height.jpg) <small>www.feastmagazine.org</small>Vitinha’s Real Height Revealed, Why His Size Doesn’t Match His Skillset - FEAST Online Magazine ...

FlashFocus: Vitinha, O Pequeno Maestro Que Demorou A Atingir O Caminho Do Sucesso | Flashscore
----------------------------------------------------------------------------------------------

 ![FlashFocus: Vitinha, o pequeno maestro que demorou a atingir o caminho do sucesso | Flashscore](https://livesport-ott-images.ssl.cdn.cra.cz/r900xfq60/cac5bc38-cbf0-45ca-80f3-d6b361a0b274.jpg) <small>www.flashscore.com.br</small>FlashFocus: Vitinha, o pequeno maestro que demorou a atingir o caminho do sucesso | Flashscore ...

Vitinha Diz Que Não Pensa Na Bola De Ouro E Olha Para Mundial De Clubes 2025: «As Forças Já Não
-----------------------------------------------------------------------------------------------

 ![Vitinha diz que não pensa na Bola de Ouro e olha para Mundial de Clubes 2025: «As forças já não](https://images.daznservices.com/di/library/DAZN_News/77/f8/vitinha_1qnmohnzj6icd1t2v5c1oqxg5r.jpeg?t=1702470167) <small>www.dazn.com</small>Vitinha diz que não pensa na Bola de Ouro e olha para Mundial de Clubes 2025: «As forças já não ...

Luis Enrique Explica Substituição De Vitinha Na Primeira Parte Diante Do Auxerre: «Sentiu Algo»
-----------------------------------------------------------------------------------------------

 ![Luis Enrique explica substituição de Vitinha na primeira parte diante do Auxerre: «Sentiu algo»](https://binny-bolanarede.b-cdn.net/wp-content/uploads/2025/09/Vitinha-PSG.jpg) <small>bolanarede.pt</small>Luis Enrique explica substituição de Vitinha na primeira parte diante do Auxerre: «Sentiu algo»

Vitinha - Wikipedia
-------------------

 ![Vitinha - Wikipedia](https://upload.wikimedia.org/wikipedia/commons/thumb/4/44/Vitinha_USMNT_v_Portugal_Mar_31_2026-50_(cropped).jpg/960px-Vitinha_USMNT_v_Portugal_Mar_31_2026-50_(cropped).jpg) <small>en.wikipedia.org</small>Vitinha - Wikipedia

Is Vitinha PSG’s Best Player? - The Athletic
--------------------------------------------

 ![Is Vitinha PSG’s best player? - The Athletic](https://static01.nyt.com/athletic/uploads/wp/2025/04/09083552/Vitinha-1024x683.jpg?width=1920&quality=70&auto=webp) <small>www.nytimes.com</small>Is Vitinha PSG’s best player? - The Athletic

PSG - Vitinha élu Personnalité De L'année 2025 Au Portugal
----------------------------------------------------------

 ![PSG - Vitinha élu personnalité de l'année 2025 au Portugal](https://photos.madeinparisiens.com/ligue-des-champions/2025/zoom/ldc-20251127082832-7302.jpg) <small>madeinparisiens.ouest-france.fr</small>PSG - Vitinha élu personnalité de l'année 2025 au Portugal

Vitinha Agradece Elogios De Zidane: «Fico Muito Contente» | A Bola
------------------------------------------------------------------

 ![Vitinha agradece elogios de Zidane: «Fico muito contente» | A Bola](https://sportal365images.com/process/smp-images-production/abola.pt/13102025/33ddd85d-f944-4f51-9c81-ae8e5d291c0d.jpg?operations=scale(860:574)) <small>www.abola.pt</small>Vitinha agradece elogios de Zidane: «Fico muito contente» | A Bola

Vitinha Volta A Treinar E Pode Reforçar O PSG Na Semifinal Da Champions Contra O Bayern
---------------------------------------------------------------------------------------

 ![Vitinha volta a treinar e pode reforçar o PSG na semifinal da Champions contra o Bayern](https://tntsports.cl/__export/1772728249888/sites/esporteinterativo/img/2026/03/05/vitinha_psg.jpg_293361798.jpg) <small>tntsports.com.br</small>Vitinha volta a treinar e pode reforçar o PSG na semifinal da Champions contra o Bayern

La Cláusula Descendente De Vitinha: El Real Madrid Lo Tiene Apuntado
--------------------------------------------------------------------

 ![La cláusula descendente de Vitinha: el Real Madrid lo tiene apuntado](https://e01-xlk-ue-marca.uecdn.es/uploads/2025/08/08/6895d43049e71.jpeg) <small>www.marca.com</small>La cláusula descendente de Vitinha: el Real Madrid lo tiene apuntado

Vitinha | Paris SG
------------------

 ![Vitinha | Paris SG](https://www.footballdatabase.eu/images/photos/players/2024/a_335/335640.jpg) <small>www.footballdatabase.eu</small>Vitinha | Paris SG

Vitinha Descarta Saída Para O Real Madrid: «Não é O Melhor Para Mim Neste Momento»
----------------------------------------------------------------------------------

 ![Vitinha descarta saída para o Real Madrid: «Não é o melhor para mim neste momento»](https://cdn-img.staticzz.com/img/jogadores/new/12/84/421284_vitinha_20260617030911.png) <small>www.zerozero.pt</small>Vitinha descarta saída para o Real Madrid: «Não é o melhor para mim neste momento»

Vitinha Biography, Age, Height, PSG Career, Stats &amp; Net Worth
-----------------------------------------------------------------

 ![Vitinha Biography, Age, Height, PSG Career, Stats & Net Worth](https://playersbiography.com/wp-content/uploads/2026/06/Vitinha-768x420.png) <small>playersbiography.com</small>Vitinha Biography, Age, Height, PSG Career, Stats &amp; Net Worth

Vitinha :: 2025/2026 - Portugal - Ficha E Estatísticas Do Jogador
-----------------------------------------------------------------

 ![Vitinha :: 2025/2026 - Portugal - Ficha e Estatísticas do Jogador](https://www.zerozero.pt/img/noticias/523/imgS300I1015523T20251230103117.jpg) <small>www.zerozero.pt</small>Vitinha :: 2025/2026 - Portugal - Ficha e Estatísticas do Jogador

Who Replaces Vitinha? PSG Face Midfield Dilemma Ahead Of Bayern Munich Clash — Tribuna.com
------------------------------------------------------------------------------------------

 ![Who replaces Vitinha? PSG face midfield dilemma ahead of Bayern Munich clash — Tribuna.com](https://pictures.tribuna.com/image/cb95b2b6-2c23-4aec-8e92-d886336ebf7c?width=1920&quality=70) <small>tribuna.com</small>Who replaces Vitinha? PSG face midfield dilemma ahead of Bayern Munich clash — Tribuna.com

Vitinha Sulla Sfida Del Portogallo Contro La Germania, Sull'affiatamento Della Squadra E I Sogni
------------------------------------------------------------------------------------------------

 ![Vitinha sulla sfida del Portogallo contro la Germania, sull'affiatamento della squadra e i sogni](https://editorial.uefa.com/resources/029a-1de93d03920e-c3e68b6132f6-1000/portugal_v_denmark_-_uefa_nations_league_quarterfinal_leg_two.jpeg) <small>it.uefa.com</small>Vitinha sulla sfida del Portogallo contro la Germania, sull'affiatamento della squadra e i sogni ...

Vitinha, Do PSG, Revela A Importância Do Mundial Para O PSG
-----------------------------------------------------------

 ![Vitinha, do PSG, revela a importância do Mundial para o PSG](https://p2.trrsf.com/image/fget/cf/1200/630/middle/images.terra.com/2025/07/10/4714276-vitinha-em-acao-pelo-psg.jpg) <small>www.terra.com.br</small>Vitinha, do PSG, revela a importância do Mundial para o PSG

Vitinha Player Stats - Sportsmen Height
---------------------------------------

 ![Vitinha Player Stats - Sportsmen Height](https://sportsmanheight.com/wp-content/uploads/2022/11/5-12.png) <small>sportsmanheight.com</small>Vitinha Player Stats - Sportsmen Height

Real Madrid Terá Que Pagar R$ 558 Milhões Para Tirar Vitinha Do PSG
-------------------------------------------------------------------

 ![Real Madrid terá que pagar R$ 558 milhões para tirar Vitinha do PSG](https://media.somosfanaticos.fans/wp-content/uploads/sites/17/2025/08/07115305/PSG-esta-disposto-a-vender-Vitinha-ao-Real-Madrid-por-R-828-milhoes-scaled-e1754578466233-1024x577-1024x577.webp) <small>somosfanaticos.fans</small>Real Madrid terá que pagar R$ 558 milhões para tirar Vitinha do PSG

Vitinha | Portugal | UEFA EURO 2024 | UEFA.com
----------------------------------------------

 ![Vitinha | Portugal | UEFA EURO 2024 | UEFA.com](https://img.uefa.com/imgml/TP/players/3/2024/cutoff/250101444.png) <small>www.uefa.com</small>Vitinha | Portugal | UEFA EURO 2024 | UEFA.com

¿El Próximo Galáctico? El Real Madrid Inicia La Persecución De Vitinha, Del PSG, En Un Intento
----------------------------------------------------------------------------------------------

 ![¿El próximo galáctico? El Real Madrid inicia la persecución de Vitinha, del PSG, en un intento](https://assets.goal.com/images/v3/blt4840a76194cf2250/Vitinha.jpeg?auto=webp&format=pjpg&width=3840&quality=60) <small>www.goal.com</small>¿El próximo galáctico? El Real Madrid inicia la persecución de Vitinha, del PSG, en un intento ...

Vitinha: PSG| Height| Stats| Messi| How Tall Is| Age| Real Madrid - Sportsjone
------------------------------------------------------------------------------

 ![Vitinha: PSG| Height| Stats| Messi| How tall is| Age| Real madrid - sportsjone](https://sportsjone.com/wp-content/uploads/2026/05/images-2026-05-31T140851.587.jpeg) <small>sportsjone.com</small>Vitinha: PSG| Height| Stats| Messi| How tall is| Age| Real madrid - sportsjone

PSG: Vitinha é O MVP Da Taça Da Intercontinental
------------------------------------------------

 ![PSG: Vitinha é o MVP da Taça da Intercontinental](https://binny-bolanarede.b-cdn.net/wp-content/uploads/2025/12/Vitinha-PSG.jpg) <small>bolanarede.pt</small>PSG: Vitinha é o MVP da Taça da Intercontinental

Vitinha Height Revealed—Is PSG’s Midfield Star Really That Short?
-----------------------------------------------------------------

 ![Vitinha Height Revealed—Is PSG’s Midfield Star Really That Short?](https://wealthfuture.co.uk/wp-content/uploads/2025/06/Vitinha-Height.jpg) <small>wealthfuture.co.uk</small>Vitinha Height Revealed—Is PSG’s Midfield Star Really That Short?

Sélections : Vitinha Brillant Et Taille Patron Avec Le Portugal | CulturePSG
----------------------------------------------------------------------------

 ![Sélections : Vitinha brillant et taille patron avec le Portugal | CulturePSG](http://media.culturepsg.com/image/news/vitinha_dos_210528_psg_barca_uefa_10042024.jpg) <small>www.culturepsg.com</small>Sélections : Vitinha brillant et taille patron avec le Portugal | CulturePSG

The 30 World-Class Players In 2025 - Lentedesportiva
----------------------------------------------------

 ![The 30 World-Class players in 2025 - Lentedesportiva](https://lentedesportiva.com/wp-content/uploads/2025/02/shutterstock_2394529789.jpg) <small>lentedesportiva.com</small>The 30 World-Class players in 2025 - Lentedesportiva

Ex-Real Madrid E A Luta Pela Bola De Ouro: «Tem De Estar Entre Vitinha E Hakimi»
--------------------------------------------------------------------------------

 ![Ex-Real Madrid e a luta pela Bola de Ouro: «Tem de estar entre Vitinha e Hakimi»](https://binny-bolanarede.b-cdn.net/wp-content/uploads/2025/04/Vitinha-PSG.jpg) <small>bolanarede.pt</small>Ex-Real Madrid e a luta pela Bola de Ouro: «Tem de estar entre Vitinha e Hakimi»

«Vitinha Consegue Fazer O Que Eu Fazia, é Um Dos Melhores...» | MAISFUTEBOL
---------------------------------------------------------------------------

 ![«Vitinha consegue fazer o que eu fazia, é um dos melhores...» | MAISFUTEBOL](https://img.iol.pt/image/id/697a7091d34e92a344982509/1024) <small>maisfutebol.iol.pt</small>«Vitinha consegue fazer o que eu fazia, é um dos melhores...» | MAISFUTEBOL

Roberto Martínez Aponta Vitinha à Bola De Ouro: «Se Não Ganhar Agora, Tem O Potencial Para
------------------------------------------------------------------------------------------

 ![Roberto Martínez aponta Vitinha à Bola de Ouro: «Se não ganhar agora, tem o potencial para](https://binny-bolanarede.b-cdn.net/wp-content/uploads/2025/03/Vitinha-1.jpg) <small>bolanarede.pt</small>Roberto Martínez aponta Vitinha à Bola de Ouro: «Se não ganhar agora, tem o potencial para ...

vitinha diz que não pensa na bola de ouro e olha para mundial de clubes 2025: «as forças já não .... Vitinha volta a treinar e pode reforçar o psg na semifinal da champions contra o bayern. Luis enrique explica substituição de vitinha na primeira parte diante do auxerre: «sentiu algo»
