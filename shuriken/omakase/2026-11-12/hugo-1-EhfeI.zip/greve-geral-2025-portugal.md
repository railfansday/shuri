---
title: "Greve Geral 2025 Portugal - portugal faz greve geral contra mudanças na lei trabalhista"
description: "A greve foi &quot;um estrondo&quot; político mas &quot;perderam todos&quot;"
date: "2026-02-05"
categories:
- "Uncategorized"
images:
- "https://s.rfi.fr/media/display/074d4efc-d66a-11f0-a540-005056bfb2b6/w:1024/p:16x9/AP25345021595048.jpg"
featuredImage: "https://imigrar.org/wp-content/uploads/2026/06/PZER2BKEB5BETFWX6625KVBAUU-scaled.jpg"
featured_image: "http://s2.glbimg.com/ZUExOsOl0gAvO4PiXsCWeFjUu5s=/1200x630/s.glbimg.com/jo/g1/f/original/2010/11/24/greve-portugal.jpg"
image: "https://rapportsdeforce.fr/wp-content/uploads/2025/12/Grevegeneraleportugallast.jpeg"
---

If you are searching about Manifestação em frente ao Parlamento resultou em seis detidos: tudo sobre a greve geral you've visit to the right place. We have 35 Pictures about Manifestação em frente ao Parlamento resultou em seis detidos: tudo sobre a greve geral like SPN - Fenprof — Adesão histórica à greve geral, Greve geral paralisa Portugal contra precarização de direitos and also Eurodreams de 17 de novembro de 2025. Here you go:

Manifestação Em Frente Ao Parlamento Resultou Em Seis Detidos: Tudo Sobre A Greve Geral
---------------------------------------------------------------------------------------

 ![Manifestação em frente ao Parlamento resultou em seis detidos: tudo sobre a greve geral](https://cdn.sabado.pt/images/2025-12/img_1200x676uu2025-12-11-12-44-17-752810.jpg) <small>www.sabado.pt</small>Manifestação em frente ao Parlamento resultou em seis detidos: tudo sobre a greve geral ...

Greves Gerais Em Portugal — Instituto +Liberdade
------------------------------------------------

 ![Greves Gerais em Portugal — Instituto +Liberdade](https://maisliberdade.pt/site/assets/files/9774/greve_geral.1000x0.png) <small>maisliberdade.pt</small>Greves Gerais em Portugal — Instituto +Liberdade

SPN - Fenprof — Adesão Histórica à Greve Geral
----------------------------------------------

 ![SPN - Fenprof — Adesão histórica à greve geral](https://www.spn.pt/Media/Default/Info/68000/500/60/7/grevegeral11dez_cartaz.jpg) <small>www.spn.pt</small>SPN - Fenprof — Adesão histórica à greve geral

Eurodreams De 17 De Novembro De 2025
------------------------------------

 ![Eurodreams de 17 de novembro de 2025](https://jornaldemafra.pt/wp-content/uploads/2025/12/greve-geral.webp) <small>jornaldemafra.pt</small>Eurodreams de 17 de novembro de 2025

Category:General Strike 11 December 2025 (Portugal) - Wikimedia Commons
-----------------------------------------------------------------------

 ![Category:General strike 11 December 2025 (Portugal) - Wikimedia Commons](https://upload.wikimedia.org/wikipedia/commons/thumb/d/d1/Convocatórias_nas_ruas_sobre_a_Greve_Geral_de_7_de_dezembro_2025%2C_em_Portugal_07.jpg/960px-Convocatórias_nas_ruas_sobre_a_Greve_Geral_de_7_de_dezembro_2025%2C_em_Portugal_07.jpg) <small>commons.wikimedia.org</small>Category:General strike 11 December 2025 (Portugal) - Wikimedia Commons

A Greve Foi "um Estrondo" Político Mas "perderam Todos" - CNN Portugal
----------------------------------------------------------------------

 ![A greve foi "um estrondo" político mas "perderam todos" - CNN Portugal](https://img.iol.pt/image/id/693b2a1ad34e3caad84c47e9/1024.jpg) <small>cnnportugal.iol.pt</small>A greve foi "um estrondo" político mas "perderam todos" - CNN Portugal

Greve Geral Em Portugal Em Grande Destaque Na Imprensa Internacional - Sociedade - Correio Da Manhã
---------------------------------------------------------------------------------------------------

 ![Greve geral em Portugal em grande destaque na imprensa internacional - Sociedade - Correio da Manhã](https://cdn.cmjornal.pt/images/2025-12/img_1500x1000uu2025-12-10-22-06-51-2253721.jpg) <small>www.cmjornal.pt</small>Greve geral em Portugal em grande destaque na imprensa internacional - Sociedade - Correio da Manhã

Manifestação Em Frente Ao Parlamento Resultou Em Seis Detidos: Tudo Sobre A Greve Geral
---------------------------------------------------------------------------------------

 ![Manifestação em frente ao Parlamento resultou em seis detidos: tudo sobre a greve geral](https://cdn.sabado.pt/images/2025-12/img_1320x742uu2025-12-11-15-03-48-752830.jpg) <small>www.sabado.pt</small>Manifestação em frente ao Parlamento resultou em seis detidos: tudo sobre a greve geral ...

AVISO PRÉVIO DE GREVE TRABALHADORES ADMINISTRAÇÃO PÚBLICA 16 DE MAIO 2025 – STTS
--------------------------------------------------------------------------------

 ![AVISO PRÉVIO DE GREVE TRABALHADORES ADMINISTRAÇÃO PÚBLICA 16 DE MAIO 2025 – STTS](https://www.stts.pt/wp-content/uploads/2025/05/CAPA.jpg) <small>www.stts.pt</small>AVISO PRÉVIO DE GREVE TRABALHADORES ADMINISTRAÇÃO PÚBLICA 16 DE MAIO 2025 – STTS

Após Greve Geral, Governo De Portugal Anuncia Mudanças Em Reforma Trabalhista | Mundo | Valor
---------------------------------------------------------------------------------------------

 ![Após greve geral, governo de Portugal anuncia mudanças em reforma trabalhista | Mundo | Valor](https://s2-valor.glbimg.com/FwlMh6T3npfdP2o2v2QtI5w-MhQ=/0x0:6000x4000/984x0/smart/filters:strip_icc()/i.s3.glbimg.com/v1/AUTH_63b422c2caee4269b8b34177e8876b93/internal_photos/bs/2025/w/k/f0BnZRR2OAqILiSqtVBw/ap25345380649592.jpg) <small>valor.globo.com</small>Após greve geral, governo de Portugal anuncia mudanças em reforma trabalhista | Mundo | Valor ...

Portugal: Greve Geral - CIG: Confederación Intersindical Galega
---------------------------------------------------------------

 ![Portugal: Greve geral - CIG: Confederación Intersindical Galega](https://www.cig.gal/assets/images/0/20251212_greve.PT-c79520e0.jpg) <small>www.cig.gal</small>Portugal: Greve geral - CIG: Confederación Intersindical Galega

Greve Geral Histórica Em Portugal Paralisa Transportes, Fecha Escolas E Pressiona Hospitais
-------------------------------------------------------------------------------------------

 ![Greve geral histórica em Portugal paralisa transportes, fecha escolas e pressiona hospitais](https://s.rfi.fr/media/display/074d4efc-d66a-11f0-a540-005056bfb2b6/w:1024/p:16x9/AP25345021595048.jpg) <small>www.rfi.fr</small>Greve geral histórica em Portugal paralisa transportes, fecha escolas e pressiona hospitais ...

Greve Geral Portuguesa De 2025 – Wikipédia, A Enciclopédia Livre
----------------------------------------------------------------

 ![Greve geral portuguesa de 2025 – Wikipédia, a enciclopédia livre](https://upload.wikimedia.org/wikipedia/commons/thumb/9/9c/Manifestação_Greve_Geral%2C_Lisboa%2C_Dez._2025_(54977121422).jpg/1280px-Manifestação_Greve_Geral%2C_Lisboa%2C_Dez._2025_(54977121422).jpg) <small>pt.wikipedia.org</small>Greve geral portuguesa de 2025 – Wikipédia, a enciclopédia livre

G1 - Portugal Entra Em Greve Geral Contra Medidas De Austeridade - Notícias Em Economia E Negócios
--------------------------------------------------------------------------------------------------

 ![G1 - Portugal entra em greve geral contra medidas de austeridade - notícias em Economia e Negócios](http://s2.glbimg.com/ZUExOsOl0gAvO4PiXsCWeFjUu5s=/1200x630/s.glbimg.com/jo/g1/f/original/2010/11/24/greve-portugal.jpg) <small>g1.globo.com</small>G1 - Portugal entra em greve geral contra medidas de austeridade - notícias em Economia e Negócios

Greve Geral Deverá Ter Impacto Inferior A 0,1% Do PIB – ECO
-----------------------------------------------------------

 ![Greve geral deverá ter impacto inferior a 0,1% do PIB – ECO](https://eco.imgix.net/uploads/2025/12/cropped-46141990-scaled.jpg) <small>eco.sapo.pt</small>Greve geral deverá ter impacto inferior a 0,1% do PIB – ECO

GREVE GERAL DE 11 DE DEZEMBRO DE 2025 – MANIFESTAÇÕES – LISBOA (VÍDEO) – EPHEMERA – Biblioteca E
------------------------------------------------------------------------------------------------

 ![GREVE GERAL DE 11 DE DEZEMBRO DE 2025 – MANIFESTAÇÕES – LISBOA (VÍDEO) – EPHEMERA – Biblioteca e](https://ephemerajpp.com/wp-content/uploads/2025/12/IMG_2182.jpg) <small>ephemerajpp.com</small>GREVE GERAL DE 11 DE DEZEMBRO DE 2025 – MANIFESTAÇÕES – LISBOA (VÍDEO) – EPHEMERA – Biblioteca e ...

O Que Vai Parar Com A Greve Geral De 3 De Junho? - Portugal - SÁBADO
--------------------------------------------------------------------

 ![O que vai parar com a greve geral de 3 de junho? - Portugal - SÁBADO](https://cdn.sabado.pt/images/2026-05/img_980x653uu2026-05-21-18-26-04-766232.jpg) <small>www.sabado.pt</small>O que vai parar com a greve geral de 3 de junho? - Portugal - SÁBADO

Manifestação Em Frente Ao Parlamento Resultou Em Seis Detidos: Tudo Sobre A Greve Geral
---------------------------------------------------------------------------------------

 ![Manifestação em frente ao Parlamento resultou em seis detidos: tudo sobre a greve geral](https://cdn.sabado.pt/images/2025-12/img_1320x743uu2025-12-11-10-18-26-752781.jpg) <small>www.sabado.pt</small>Manifestação em frente ao Parlamento resultou em seis detidos: tudo sobre a greve geral ...

FECTRANS | Cresce A Mobilização Para A Greve Geral - CGTP-IN
------------------------------------------------------------

 ![FECTRANS | Cresce a mobilização para a Greve Geral - CGTP-IN](https://www.cgtp.pt/images/accao-e-luta/2025/Logotipo_GG.png) <small>www.cgtp.pt</small>FECTRANS | Cresce a mobilização para a Greve Geral - CGTP-IN

Au Portugal, Appel à La Grève Générale Contre « L’une Des Plus Grandes Attaques Jamais Menées
---------------------------------------------------------------------------------------------

 ![Au Portugal, appel à la grève générale contre « l’une des plus grandes attaques jamais menées](https://rapportsdeforce.fr/wp-content/uploads/2025/12/Grevegeneraleportugallast.jpeg) <small>rapportsdeforce.fr</small>Au Portugal, appel à la grève générale contre « l’une des plus grandes attaques jamais menées ...

Portugal: Uma Grande Greve Geral Para Derrotar O Pacote Laboral - CIG: Confederación
------------------------------------------------------------------------------------

 ![Portugal: Uma grande greve geral para derrotar o pacote laboral - CIG: Confederación](https://www.cig.gal/assets/images/6/20251209_portugal.greve-34c19476.jpg) <small>www.cig.gal</small>Portugal: Uma grande greve geral para derrotar o pacote laboral - CIG: Confederación ...

Portugal Faz Greve Geral Contra Mudanças Na Lei Trabalhista | G1
----------------------------------------------------------------

 ![Portugal faz greve geral contra mudanças na lei trabalhista | G1](https://s2-g1.glbimg.com/02TFp0WTXe014uO-QFFVxRua930=/5472x0/filters:format(jpeg)/https://i.s3.glbimg.com/v1/AUTH_59edd422c0c84a879bd37670ae4f538a/internal_photos/bs/2026/8/D/NHXiHRSYiCUPUHUimdMQ/2026-05-26t135550z-2088829895-rc21rkatd17q-rtrmadp-3-portugal-economy-primeminister.jpg) <small>g1.globo.com</small>Portugal faz greve geral contra mudanças na lei trabalhista | G1

Motivos Da Adesão à Greve Geral De 11 De Dezembro De 2025
---------------------------------------------------------

 ![Motivos da adesão à Greve Geral de 11 de dezembro de 2025](https://spzn.pt/uploads/noticias/big_1763717239_6728_SPZN_2025_site_novo_(17).png) <small>spzn.pt</small>Motivos da adesão à Greve Geral de 11 de dezembro de 2025

CGTP Entrega Hoje Pré-aviso De Greve Geral Para "derrotar O Pacote Laboral" - Portugal - SÁBADO
-----------------------------------------------------------------------------------------------

 ![CGTP entrega hoje pré-aviso de greve geral para "derrotar o pacote laboral" - Portugal - SÁBADO](https://cdn.sabado.pt/images/2026-05/img_1920x1080uu2026-05-01-16-01-52-764693.jpg) <small>www.sabado.pt</small>CGTP entrega hoje pré-aviso de greve geral para "derrotar o pacote laboral" - Portugal - SÁBADO

Metro Do Porto "fortemente Condicionado" No Dia Da Greve Geral - JPN
--------------------------------------------------------------------

 ![Metro do Porto "fortemente condicionado" no dia da greve geral - JPN](https://www.jpn.up.pt/wp-content/uploads/2025/12/greve_geral1-1152x759.jpg) <small>www.jpn.up.pt</small>Metro do Porto "fortemente condicionado" no dia da greve geral - JPN

Greve Geral Paralisa Portugal Contra Precarização De Direitos
-------------------------------------------------------------

 ![Greve geral paralisa Portugal contra precarização de direitos](https://pcdob.org.br/wp-content/uploads/2025/12/Ruas-de-Lisboa-foram-tomadas-por-trabalhadores-durante-a-greve-geral-Rafael-Medeiros-Esquerda.jpg) <small>pcdob.org.br</small>Greve geral paralisa Portugal contra precarização de direitos

Maioria Dos Portugueses Diz Que Greve Geral Foi Justificada - Portugal - SÁBADO
-------------------------------------------------------------------------------

 ![Maioria dos portugueses diz que greve geral foi justificada - Portugal - SÁBADO](https://cdn.sabado.pt/images/2025-12/img_980x653uu2025-12-22-09-03-14-753915.jpg) <small>www.sabado.pt</small>Maioria dos portugueses diz que greve geral foi justificada - Portugal - SÁBADO

SPGL - Greve Geral | 11 De Dezembro De 2025 (Piquetes, Concentrações E Manifestações)
-------------------------------------------------------------------------------------

 ![SPGL - Greve Geral | 11 de dezembro de 2025 (Piquetes, Concentrações e Manifestações)](https://www.spgl.pt/Media/Default/_Profiles/722d2b7d/68bcf4e1/IMG_2694.JPG?v=639010778412646835) <small>www.spgl.pt</small>SPGL - Greve Geral | 11 de dezembro de 2025 (Piquetes, Concentrações e Manifestações)

Greve Histórica Em Portugal: Três Milhões Cruzam Os Braços Em Protesto Contra Medidas De
----------------------------------------------------------------------------------------

 ![Greve histórica em Portugal: três milhões cruzam os braços em protesto contra medidas de](https://ogimg.infoglobo.com.br/in/2920985-315-96f/FT1086A/760/Manifestante-no-Centro-de-Lisboa-na-primeira-greve-geral-em-mais-de-duas-decadasFrancisco-LeongAFP.jpg) <small>oglobo.globo.com</small>Greve histórica em Portugal: três milhões cruzam os braços em protesto contra medidas de ...

Greve Geral Histórica Em Portugal Paralisa Transportes, Fecha Escolas E Pressiona Hospitais
-------------------------------------------------------------------------------------------

 ![Greve geral histórica em Portugal paralisa transportes, fecha escolas e pressiona hospitais](https://s.rfi.fr/media/display/074d4efc-d66a-11f0-a540-005056bfb2b6/w:1024/p:9x16/AP25345021595048.jpg) <small>www.rfi.fr</small>Greve geral histórica em Portugal paralisa transportes, fecha escolas e pressiona hospitais ...

Greve Geral Histórica Em Portugal Paralisa Transportes, Fecha Escolas E Pressiona Hospitais
-------------------------------------------------------------------------------------------

 ![Greve geral histórica em Portugal paralisa transportes, fecha escolas e pressiona hospitais](https://p2.trrsf.com/image/fget/cf/1200/630/middle/images.terra.com/2025/12/11/greve-ubj4bs8ccokh.png) <small>www.terra.com.br</small>Greve geral histórica em Portugal paralisa transportes, fecha escolas e pressiona hospitais

Documentos Greve 2025
---------------------

 ![Documentos Greve 2025](https://www.mais.pt/galeriadeimagens/Conteudos/Avulso/cartaz GREVE GERAL mais.jpg) <small>www.mais.pt</small>Documentos Greve 2025

Imagens Do Dia De Greve Geral Em Portugal - Jornal O Globo
----------------------------------------------------------

 ![Imagens do dia de greve geral em Portugal - Jornal O Globo](https://ogimg.infoglobo.com.br/in/4387791-fd9-94b/FT1086A/760/foto2.jpg?posicaoFoto2) <small>oglobo.globo.com</small>Imagens do dia de greve geral em Portugal - Jornal O Globo

Portugal: Greve Geral Paralisa Transportes, Escolas E Hospitais
---------------------------------------------------------------

 ![Portugal: greve geral paralisa transportes, escolas e hospitais](https://i.metroimg.com/oM7Sj2wb-sLnTI8EKYSBtaNNRMq-GOUZgRc4WofMfRQ/w:900/q:85/f:webp/plain/https://images.metroimg.com/2025/12/11065554/greve-portugal.jpg) <small>www.metropoles.com</small>Portugal: greve geral paralisa transportes, escolas e hospitais

Portugal Para Com Greve Geral: O Que Está Por Trás Dos Protestos Contra A Reforma Trabalhista
---------------------------------------------------------------------------------------------

 ![Portugal para com greve geral: o que está por trás dos protestos contra a reforma trabalhista](https://imigrar.org/wp-content/uploads/2026/06/PZER2BKEB5BETFWX6625KVBAUU-scaled.jpg) <small>imigrar.org</small>Portugal para com greve geral: o que está por trás dos protestos contra a reforma trabalhista ...

Greve histórica em portugal: três milhões cruzam os braços em protesto contra medidas de. greve histórica em portugal: três milhões cruzam os braços em protesto contra medidas de .... Metro do porto "fortemente condicionado" no dia da greve geral
