---
title: "Kimberly Powell Newport News - kimberly powell on linkedin: had a fantastic time hosting the powerup strategic educators ..."
description: "We&#039;re here! the indiana black expo! hall h, booth 1447! come visit us!"
date: "2026-08-17"
categories:
- "Uncategorized"
images:
- "https://media.bizj.us/view/img/12968502/kimberlypowell-1*1200xx9428-5303-0-491.jpg"
featuredImage: "https://media.licdn.com/dms/image/v2/D5622AQGrtlKpHete3Q/feedshare-shrink_1280/feedshare-shrink_1280/0/1689291358476?e=2147483647&amp;v=beta&amp;t=cdPeRbEBHTdXKbZaTQlRm7oSRrrdnQstTKpCMeSYojM"
featured_image: "https://www.genengnews.com/wp-content/uploads/2023/11/Kimberly-Powell-NVIDIA-CROPPED11111.jpg"
image: "https://media.licdn.com/dms/image/v2/C5603AQG7MpUq0T4ubw/profile-displayphoto-shrink_200_200/profile-displayphoto-shrink_200_200/0/1553727787738?e=2147483647&amp;v=beta&amp;t=5aWFBsSISKwU0iaM9MLju6yI0ZoozBkJ4deboxA6qnc"
---

If you are searching about Kimberly Powell on LinkedIn: I am honored to have been nominated and awarded the BAM WW - Gerald you've visit to the right place. We have 34 Images about Kimberly Powell on LinkedIn: I am honored to have been nominated and awarded the BAM WW - Gerald like Kimberly Powell on LinkedIn: #speakupsisawards2024 #susawards2024 #susawardsfinalist2024 #voteforme, Exclusive Interview with Kimberly Powell, VP and General Manager of NVIDIA Healthcare - MarkTechPost and also Kimberly Powell - PhD, RN, FAMIA, FAAN | LinkedIn. Here it is:

Kimberly Powell On LinkedIn: I Am Honored To Have Been Nominated And Awarded The BAM WW - Gerald
------------------------------------------------------------------------------------------------

 ![Kimberly Powell on LinkedIn: I am honored to have been nominated and awarded the BAM WW - Gerald](https://media.licdn.com/dms/image/D5622AQHpO63Gdvh9pA/feedshare-shrink_2048_1536/0/1686869396106?e=2147483647&v=beta&t=br0qoF38jSsM6UDaZFY07EPc3IwdUveCofo65zD08K8) <small>www.linkedin.com</small>Kimberly Powell on LinkedIn: I am honored to have been nominated and awarded the BAM WW - Gerald ...

The Indiana Black Expo Is Happening Now! If You're In The Indianapolis Area, Come Visit. We're
----------------------------------------------------------------------------------------------

 ![The Indiana Black Expo is happening now! If you're in the Indianapolis area, come visit. We're](https://media.licdn.com/dms/image/v2/D5622AQGrtlKpHete3Q/feedshare-shrink_1280/feedshare-shrink_1280/0/1689291358476?e=2147483647&v=beta&t=cdPeRbEBHTdXKbZaTQlRm7oSRrrdnQstTKpCMeSYojM) <small>www.linkedin.com</small>The Indiana Black Expo is happening now! If you're in the Indianapolis area, come visit. We're ...

Kimberly Powell - Keynote - Ohio Genealogical Society
-----------------------------------------------------

 ![Kimberly Powell - Keynote - Ohio Genealogical Society](https://www.ogs.org/wp-content/uploads/2026/02/Powell-Kimberly-2.png) <small>www.ogs.org</small>Kimberly Powell - Keynote - Ohio Genealogical Society

Nvidia's Kimberly Powell Is Leading The Chip Giant's Charge Into AI For Health Care - San
-----------------------------------------------------------------------------------------

 ![Nvidia's Kimberly Powell is leading the chip giant's charge into AI for health care - San](https://media.bizj.us/view/img/12968502/kimberlypowell-1*1200xx9428-5303-0-491.jpg) <small>www.bizjournals.com</small>Nvidia's Kimberly Powell is leading the chip giant's charge into AI for health care - San ...

Kim Powell Leaves KTVK 3/KPHO 5 Phoenix – PNW Broadcasting History &amp; Current Affairs
----------------------------------------------------------------------------------------

 ![Kim Powell Leaves KTVK 3/KPHO 5 Phoenix – PNW Broadcasting History & Current Affairs](https://qzvx.com/wp-content/uploads/2022/08/Kim-Powell-AZFAMILY3and5.png) <small>www.qzvx.com</small>Kim Powell Leaves KTVK 3/KPHO 5 Phoenix – PNW Broadcasting History &amp; Current Affairs

Kimberly Powell - Vendor Manager - Cricket Wireless | LinkedIn
--------------------------------------------------------------

 ![Kimberly Powell - Vendor Manager - Cricket Wireless | LinkedIn](https://media.licdn.com/dms/image/C4D03AQEM8l-ceokP0g/profile-displayphoto-shrink_800_800/0/1625234024608?e=2147483647&v=beta&t=yuTwtwzeWsuqXRr60NCGM4C3AmKB_OuM8b1Bwo7Epkk) <small>www.linkedin.com</small>Kimberly Powell - Vendor Manager - Cricket Wireless | LinkedIn

Kim Powell | Papaly
-------------------

 ![Kim Powell | Papaly](https://s3.amazonaws.com/topdesk/users/profile_photos/000/232/348/thumbnail/open-uri20170103-696-av04o9.jpg?1483458906) <small>papaly.com</small>Kim Powell | Papaly

Kimberly Powell - PhD, RN, FAMIA, FAAN | LinkedIn
-------------------------------------------------

 ![Kimberly Powell - PhD, RN, FAMIA, FAAN | LinkedIn](https://media.licdn.com/dms/image/v2/D4E03AQELNZTNqlomtw/profile-displayphoto-scale_200_200/B4EZiemXJLHoAY-/0/1755007513927?e=2147483647&v=beta&t=9aVHNfS1ADg7fyk_hbUBaCziZDNeQpkjMX0xwrnhkTQ) <small>www.linkedin.com</small>Kimberly Powell - PhD, RN, FAMIA, FAAN | LinkedIn

Generative AI Is Revolutionizing Healthcare, From Drug Discovery To Diagnostics And Post-op Care
------------------------------------------------------------------------------------------------

 ![Generative AI is revolutionizing healthcare, from drug discovery to diagnostics and post-op care](https://media.licdn.com/dms/image/v2/D4D22AQHI7fbK1GV1QQ/feedshare-shrink_2048_1536/feedshare-shrink_2048_1536/0/1717762363344?e=2147483647&v=beta&t=HcXrmL3078ePC82LlnhipxGpfpS2lI088q7m0yCHQ0I) <small>pe.linkedin.com</small>Generative AI is revolutionizing healthcare, from drug discovery to diagnostics and post-op care ...

Hear From Kimberly Powell, Sr. Director Of Deep Learning, On The Highlights Of #CVPR2017
----------------------------------------------------------------------------------------

 ![Hear from Kimberly Powell, Sr. Director of Deep Learning, on the highlights of #CVPR2017](https://lookaside.fbsbx.com/lookaside/crawler/media/?media_id=10155005906623253&get_thumbnail=1) <small>www.facebook.com</small>Hear from Kimberly Powell, Sr. Director of Deep Learning, on the highlights of #CVPR2017 ...

Nvidia Expands AI Ambitions In Healthcare; Aims To Transform Hospitals With Robotics – Digital
----------------------------------------------------------------------------------------------

 ![Nvidia expands AI ambitions in healthcare; aims to transform hospitals with robotics – Digital](https://digitaleconomymag.com/wp-content/uploads/2024/11/Nvidia-Kimberly-Powel.png) <small>digitaleconomymag.com</small>Nvidia expands AI ambitions in healthcare; aims to transform hospitals with robotics – Digital ...

Meet The Team – The Zone
------------------------

 ![Meet the Team – The Zone](https://www.thezoneafterschool.com/media/kimberly-powell.jpg) <small>www.thezoneafterschool.com</small>Meet the Team – The Zone

From The Office To The Lab, Amgen Uses AI Tools To Unlock Innovation | Amgen
----------------------------------------------------------------------------

 ![From the Office to the Lab, Amgen Uses AI Tools to Unlock Innovation | Amgen](https://www.amgen.com/stories/2024/05/-/media/Themes/CorporateAffairs/amgen-com/amgen-com/Images/stories/2024/05-21-From-the-Office-to-the-Lab-Amgen-Uses-AI-Tools-to-Unlock-Innovation/powell.png) <small>www.amgen.com</small>From the Office to the Lab, Amgen Uses AI Tools to Unlock Innovation | Amgen

Exclusive Interview With Kimberly Powell, VP And General Manager Of NVIDIA Healthcare - MarkTechPost
----------------------------------------------------------------------------------------------------

 ![Exclusive Interview with Kimberly Powell, VP and General Manager of NVIDIA Healthcare - MarkTechPost](https://www.marktechpost.com/wp-content/uploads/2022/04/Interview-2.png) <small>www.marktechpost.com</small>Exclusive Interview with Kimberly Powell, VP and General Manager of NVIDIA Healthcare - MarkTechPost

Kimberly Powell On LinkedIn: Had A Fantastic Time Hosting The PowerUp Strategic Educators
-----------------------------------------------------------------------------------------

 ![Kimberly Powell on LinkedIn: Had a fantastic time hosting the PowerUp Strategic Educators](https://media.licdn.com/dms/image/D5622AQEBItJYa-ypGw/feedshare-shrink_800/0/1708957758233?e=2147483647&v=beta&t=xMzVZhCGZYMoNSETCR7it3dpNlrrkZKiht8hIB45sdI) <small>www.linkedin.com</small>Kimberly Powell on LinkedIn: Had a fantastic time hosting the PowerUp Strategic Educators ...

NVIDIA Powers Up In Drug Discovery
----------------------------------

 ![NVIDIA Powers Up in Drug Discovery](https://genengnews.com/wp-content/uploads/2020/10/Kimberly-Powell_avatar_1511719112-200x200-1.jpg) <small>www.genengnews.com</small>NVIDIA Powers Up in Drug Discovery

Kimberly Powell - SR Partner Technical Advisor | LinkedIn
---------------------------------------------------------

 ![Kimberly Powell - SR Partner Technical Advisor | LinkedIn](https://media.licdn.com/dms/image/v2/D5603AQGY1P7BMa4UrA/profile-displayphoto-shrink_200_200/profile-displayphoto-shrink_200_200/0/1709256150173?e=2147483647&v=beta&t=Sr6TwAk9jjQSdKtZX537kaHgDevPQ700DsIYeMP3l0Q) <small>www.linkedin.com</small>Kimberly Powell - SR Partner Technical Advisor | LinkedIn

Kimberly Powell's Instagram, Twitter &amp; Facebook On IDCrawl
--------------------------------------------------------------

 ![Kimberly Powell's Instagram, Twitter & Facebook on IDCrawl](https://i1.rgstatic.net/ii/profile.image/807870794842112-1569622815790_Q512/Kimberly-Powell-11.jpg) <small>www.idcrawl.com</small>Kimberly Powell's Instagram, Twitter &amp; Facebook on IDCrawl

\#empoweredwomen #communityimpact #phenomenalwomen #womenshistorymonth | Kimberly Powell | 44
---------------------------------------------------------------------------------------------

 ![#empoweredwomen #communityimpact #phenomenalwomen #womenshistorymonth | Kimberly Powell | 44](https://media.licdn.com/dms/image/v2/D5622AQHzvHlVIEBvrQ/feedshare-shrink_2048_1536/B56ZSmw5dBHwAo-/0/1737964624292?e=2147483647&v=beta&t=mRF7qjLB8dzdUaTYWW_iR0EaNMz81GXoXMkNFL-t-Fk) <small>www.linkedin.com</small>\#empoweredwomen #communityimpact #phenomenalwomen #womenshistorymonth | Kimberly Powell | 44 ...

Kimberly Powell Honored For Pioneering Work In Health Informatics And Gerontology
---------------------------------------------------------------------------------

 ![Kimberly Powell honored for pioneering work in health informatics and gerontology](https://nursing.missouri.edu/wp-content/uploads/2024/05/Congratulations.png) <small>nursing.missouri.edu</small>Kimberly Powell honored for pioneering work in health informatics and gerontology

Welcome To The Team Kimberly Powell ! | Kelvin Kam
--------------------------------------------------

 ![Welcome to the team Kimberly Powell ! | Kelvin Kam](https://media.licdn.com/dms/image/v2/D5622AQFyslA_bU6SmQ/feedshare-shrink_2048_1536/feedshare-shrink_2048_1536/0/1701478818727?e=2147483647&v=beta&t=DJkohkKyaZ_7xCO8qbg4sbuEXtvwp1Ue88oRp9zZehw) <small>www.linkedin.com</small>Welcome to the team Kimberly Powell ! | Kelvin Kam

What Can Health Care Learn From Self-Driving Cars? | Johns Hopkins Medicine
---------------------------------------------------------------------------

 ![What Can Health Care Learn from Self-Driving Cars? | Johns Hopkins Medicine](https://www.hopkinsmedicine.org/-/media/images/articles/2018/03/kimberly_powell.jpeg?h=640&iar=0&w=640&hash=1741F5E78A512573722D6BEAB32D9288) <small>www.hopkinsmedicine.org</small>What Can Health Care Learn from Self-Driving Cars? | Johns Hopkins Medicine

About Us
--------

 ![About Us](https://img1.wsimg.com/isteam/ip/44d8c6eb-5847-48e2-aff5-373d62931250/blob.png/:/cr=t:0%25,l:0%25,w:100%25,h:67.46%25/rs=w:365,h:365,cg:true) <small>757wecare.org</small>About Us

\#locinternships #libraryofcongress | Kimberly Powell, MBA, PMP
---------------------------------------------------------------

 ![#locinternships #libraryofcongress | Kimberly Powell, MBA, PMP](https://media.licdn.com/dms/image/v2/D5622AQH-9yhDoWzSRg/feedshare-shrink_800/feedshare-shrink_800/0/1691613719431?e=2147483647&v=beta&t=V6h7FJjIMWbICbGHmyK-sIZnB8eFpxVdqNLLvCQujok) <small>www.linkedin.com</small>\#locinternships #libraryofcongress | Kimberly Powell, MBA, PMP

Kimberly Powell On LinkedIn: #speakupsisawards2024 #susawards2024 #susawardsfinalist2024 #voteforme
---------------------------------------------------------------------------------------------------

 ![Kimberly Powell on LinkedIn: #speakupsisawards2024 #susawards2024 #susawardsfinalist2024 #voteforme](https://media.licdn.com/dms/image/D4D22AQHnpcTAQwDtzg/feedshare-shrink_2048_1536/0/1710527087105?e=2147483647&v=beta&t=ABcsxN8h4u0sB8mJDrZKm9poz4E6UKa_kzE8Y0XAmbE) <small>www.linkedin.com</small>Kimberly Powell on LinkedIn: #speakupsisawards2024 #susawards2024 #susawardsfinalist2024 #voteforme

Kimberly Powell Honored For Pioneering Work In Health Informatics And Gerontology
---------------------------------------------------------------------------------

 ![Kimberly Powell honored for pioneering work in health informatics and gerontology](https://nursing.missouri.edu/wp-content/uploads/2024/06/Kimberly-Powell-FAMIA-induction.png) <small>nursing.missouri.edu</small>Kimberly Powell honored for pioneering work in health informatics and gerontology

Kimberly Powell - At | LinkedIn
-------------------------------

 ![Kimberly Powell - at | LinkedIn](https://media.licdn.com/dms/image/v2/C5603AQG7MpUq0T4ubw/profile-displayphoto-shrink_200_200/profile-displayphoto-shrink_200_200/0/1553727787738?e=2147483647&v=beta&t=5aWFBsSISKwU0iaM9MLju6yI0ZoozBkJ4deboxA6qnc) <small>www.linkedin.com</small>Kimberly Powell - at | LinkedIn

Kimberly Powell Inducted As Fellow Of The American Medical Informatics Association, Announced As
------------------------------------------------------------------------------------------------

 ![Kimberly Powell inducted as Fellow of the American Medical Informatics Association, announced as](https://showme.missouri.edu/wp-content/uploads/2024/06/071124_PowellFeature-940x529.jpg) <small>showme.missouri.edu</small>Kimberly Powell inducted as Fellow of the American Medical Informatics Association, announced as ...

GTC 2025 – Announcements And Live Updates | NVIDIA Blog
-------------------------------------------------------

 ![GTC 2025 – Announcements and Live Updates | NVIDIA Blog](https://blogs.nvidia.com/wp-content/uploads/2025/03/kptalk-1280x960.jpg) <small>blogs.nvidia.com</small>GTC 2025 – Announcements and Live Updates | NVIDIA Blog

We're Here! The Indiana Black Expo! Hall H, Booth 1447! Come Visit Us! | Kimberly Powell
----------------------------------------------------------------------------------------

 ![We're here! The Indiana Black Expo! Hall H, booth 1447! Come visit us! | Kimberly Powell](https://media.licdn.com/dms/image/v2/D5622AQG_Iha5ZShNxQ/feedshare-shrink_2048_1536/feedshare-shrink_2048_1536/0/1689354648155?e=2147483647&v=beta&t=tO0eWpxk-SFUhmapMMCOBpe5SUV4oVhyiIhxUpW5z_k) <small>www.linkedin.com</small>We're here! The Indiana Black Expo! Hall H, booth 1447! Come visit us! | Kimberly Powell

How AI Is Revolutionizing Healthcare With Kimberly Powell Of NVIDIA – Health Podcast Network
--------------------------------------------------------------------------------------------

 ![How AI Is Revolutionizing Healthcare with Kimberly Powell of NVIDIA – Health Podcast Network](https://megaphone.imgix.net/podcasts/25c5f82c-2777-11f0-9b28-f39167168459/image/07e90bf930a6aa2fc971ce0501ed371e.png?ixlib=rails-4.3.1&max-w=3000&max-h=3000&fit=crop&auto=format,compress) <small>healthpodcastnetwork.com</small>How AI Is Revolutionizing Healthcare with Kimberly Powell of NVIDIA – Health Podcast Network

Meet The Church Staff | New Beginnings
--------------------------------------

 ![Meet the Church Staff | New Beginnings](https://newbeginningfgbc.com/wp-content/uploads/2023/06/kimberly-morton-powell_new_square.jpg) <small>newbeginningfgbc.com</small>Meet the Church Staff | New Beginnings

Nvidia Looks To Genentech For Its Next Leap In AI Drug Discovery
----------------------------------------------------------------

 ![Nvidia Looks to Genentech for Its Next Leap in AI Drug Discovery](https://www.genengnews.com/wp-content/uploads/2023/11/Kimberly-Powell-NVIDIA-CROPPED11111.jpg) <small>www.genengnews.com</small>Nvidia Looks to Genentech for Its Next Leap in AI Drug Discovery

Powell Named Director Of The Zone | News | Norfolkdailynews.com
---------------------------------------------------------------

 ![Powell named director of The Zone | News | norfolkdailynews.com](https://bloximages.newyork1.vip.townnews.com/norfolkdailynews.com/content/tncms/assets/v3/editorial/f/83/f83d0020-0e14-11ef-a9de-2fdc188fbbc4/663ce55b7e24c.image.jpg?resize=400%2C293) <small>norfolkdailynews.com</small>Powell named director of The Zone | News | norfolkdailynews.com

Generative ai is revolutionizing healthcare, from drug discovery to diagnostics and post-op care. About us. Kimberly powell on linkedin: #speakupsisawards2024 #susawards2024 #susawardsfinalist2024 #voteforme
