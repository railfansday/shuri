---
title: "Atum Raychem - raychem atum 4:1"
description: "atum-6/2-0-stk клеевая термоусадка самозатухающая raychem, nb11652001"
date: "2026-05-05"
categories:
- "Uncategorized"
images:
- "https://www.ksvlooms.com/cdn/shop/files/1-raychem-atum-heat-shrink-adhesive-lined-tubing-148.webp?v=1717767697&amp;width=4096"
featuredImage: "https://sku-product-images.s3.us-east-2.amazonaws.com/RYC/RYCNB14032001.jpg"
featured_image: "https://www.prowireusa.com/content/58556/6IN-ATUM-24-6.webp"
image: "https://www.cablecraft.co.uk/media/catalog/product/a/t/atum-heat-shrink-adhesive.png?quality=80&amp;bg-color=255,255,255&amp;fit=bounds&amp;height=&amp;width="
---

If you are searching about 【楽天市場】レイケム ATUM-4/1-0-STK(カット品1.2m) 黒色 接着層付き 防水熱収縮チューブ 4.0→1.0mm：FAUbon 楽天市場店 you've came to the right place. We have 35 Pics about 【楽天市場】レイケム ATUM-4/1-0-STK(カット品1.2m) 黒色 接着層付き 防水熱収縮チューブ 4.0→1.0mm：FAUbon 楽天市場店 like ATUM-24/8-0-STK : RAYCHEM ATUM 3:1 Heat Shrink Tubing | TE Connectivity, Raychem ATUM 4:1 and also ATUM-24/8-2-STK TE Connectivity Raychem Cable Protection | Cables, Wires - Management | DigiKey. Read more:

【楽天市場】レイケム ATUM-4/1-0-STK(カット品1.2m) 黒色 接着層付き 防水熱収縮チューブ 4.0→1.0mm：FAUbon 楽天市場店
-----------------------------------------------------------------------------

 ![【楽天市場】レイケム ATUM-4/1-0-STK(カット品1.2m) 黒色 接着層付き 防水熱収縮チューブ 4.0→1.0mm：FAUbon 楽天市場店](https://shop.r10s.jp/faubon/cabinet/image2/atum_raychem.jpg) <small>item.rakuten.co.jp</small>【楽天市場】レイケム ATUM-4/1-0-STK(カット品1.2m) 黒色 接着層付き 防水熱収縮チューブ 4.0→1.0mm：FAUbon 楽天市場店

Raychem ATUM 4:1
----------------

 ![Raychem ATUM 4:1](https://www.prowireusa.com/content/58550/ATUM-4-1-KIT-2.webp) <small>www.prowireusa.com</small>Raychem ATUM 4:1

Raychem ATUM 4:1
----------------

 ![Raychem ATUM 4:1](https://www.prowireusa.com/content/58556/6IN-ATUM-24-6.webp) <small>www.prowireusa.com</small>Raychem ATUM 4:1

Raychem Krympslang ATUM 8 Mm
----------------------------

 ![Raychem Krympslang ATUM 8 mm](https://devpresta2.motospeed.se/1989-large_default/raychem-krympslang-atum-8-mm.jpg) <small>devpresta2.motospeed.se</small>Raychem Krympslang ATUM 8 mm

Raychem ATUM – Kit – PT Motorsport
----------------------------------

 ![Raychem ATUM – Kit – PT Motorsport](https://www.ptmotorsport.com.au/wp-content/uploads/2023/10/IGP5156-416x628.png) <small>www.ptmotorsport.com.au</small>Raychem ATUM – Kit – PT Motorsport

ATUM-12/3-2-STK RAYCHEM - TE CONNECTIVITY, Adhesive Lined Heat Shrink Tubing, Dual Medium Wall
----------------------------------------------------------------------------------------------

 ![ATUM-12/3-2-STK RAYCHEM - TE CONNECTIVITY, Adhesive Lined Heat Shrink Tubing, Dual Medium Wall](https://tr.farnell.com/productimages/standard/en_GB/42266388.jpg) <small>tr.farnell.com</small>ATUM-12/3-2-STK RAYCHEM - TE CONNECTIVITY, Adhesive Lined Heat Shrink Tubing, Dual Medium Wall ...

ATUM-6/2-0-STK Клеевая термоусадка самозатухающая Raychem, NB11652001
---------------------------------------------------------------------

 ![ATUM-6/2-0-STK Клеевая термоусадка самозатухающая Raychem, NB11652001](https://s-motorsport.com/image/cache/catalog/Raychem/ATUM 3-1/Raychem-ATUM 3-1-900x900.jpg) <small>s-motorsport.com</small>ATUM-6/2-0-STK Клеевая термоусадка самозатухающая Raychem, NB11652001

1" Raychem ATUM Heat Shrink Adhesive Lined Tubing – KSV Looms
-------------------------------------------------------------

 ![1" Raychem ATUM Heat Shrink Adhesive Lined Tubing – KSV Looms](https://www.ksvlooms.com/cdn/shop/files/1-raychem-atum-heat-shrink-adhesive-lined-tubing-148.webp?v=1717767697&width=4096) <small>www.ksvlooms.com</small>1" Raychem ATUM Heat Shrink Adhesive Lined Tubing – KSV Looms

5/8" Raychem ATUM Heat Shrink Adhesive Lined Tubing, 1ft Length (6" X – KSV Looms
---------------------------------------------------------------------------------

 ![5/8" Raychem ATUM Heat Shrink Adhesive Lined Tubing, 1ft length (6" x – KSV Looms](https://www.ksvlooms.com/cdn/shop/files/5-8-raychem-atum-heat-shrink-adhesive-lined-tubing-908.webp?v=1756159523&width=4096) <small>www.ksvlooms.com</small>5/8" Raychem ATUM Heat Shrink Adhesive Lined Tubing, 1ft length (6" x – KSV Looms

NEW RAYCHEM ATUM-24/6-6" 6" LENGTH 4:1 HEAT SHRINK TUBING | EBay
----------------------------------------------------------------

 ![NEW RAYCHEM ATUM-24/6-6" 6" LENGTH 4:1 HEAT SHRINK TUBING | eBay](https://i.ebayimg.com/images/g/ARgAAOSwUvhdrGcU/s-l1600.jpg) <small>www.ebay.com</small>NEW RAYCHEM ATUM-24/6-6" 6" LENGTH 4:1 HEAT SHRINK TUBING | eBay

ATUM-12/4-0-STK TE Connectivity Raychem Cable Protection | Cables, Alambres - Administración
--------------------------------------------------------------------------------------------

 ![ATUM-12/4-0-STK TE Connectivity Raychem Cable Protection | Cables, alambres - administración](https://media.digikey.com/photos/Tyco Raychem Photos/ATU124K.jpg) <small>www.digikey.com.mx</small>ATUM-12/4-0-STK TE Connectivity Raychem Cable Protection | Cables, alambres - administración ...

Raychem ATUM – Kit – PT Motorsport
----------------------------------

 ![Raychem ATUM – Kit – PT Motorsport](https://www.ptmotorsport.com.au/wp-content/uploads/2023/10/IGP5155-1536x1018.png) <small>www.ptmotorsport.com.au</small>Raychem ATUM – Kit – PT Motorsport

ATUM-9/3-0-STK TE Connectivity / Raychem - Datasheet PDF &amp; Technical Specs
------------------------------------------------------------------------------

 ![ATUM-9/3-0-STK TE Connectivity / Raychem - Datasheet PDF & Technical Specs](https://sigma.octopart.com/138752121/image/TE-Connectivity-ATUM-9-3-0-STK.jpg) <small>partsearch.io</small>ATUM-9/3-0-STK TE Connectivity / Raychem - Datasheet PDF &amp; Technical Specs

Raychem ATUM – Glue Lined Heat Shrink – PT Motorsport
-----------------------------------------------------

 ![Raychem ATUM – Glue Lined heat shrink – PT Motorsport](https://www.ptmotorsport.com.au/wp-content/uploads/2023/08/IGP4913-768x509.jpg) <small>www.ptmotorsport.com.au</small>Raychem ATUM – Glue Lined heat shrink – PT Motorsport

ATUM-6/2-0-STK Клеевая термоусадка самозатухающая Raychem, NB11652001
---------------------------------------------------------------------

 ![ATUM-6/2-0-STK Клеевая термоусадка самозатухающая Raychem, NB11652001](https://s-motorsport.com/image/cache/catalog/Raychem/ATUM 3-1/TE-Raychem-ATUM 3-1-900x900.jpg) <small>s-motorsport.com</small>ATUM-6/2-0-STK Клеевая термоусадка самозатухающая Raychem, NB11652001

Raychem ATUM 40/13 - Endura Supply
----------------------------------

 ![Raychem ATUM 40/13 - Endura Supply](https://endurasupply.com/media/images/raychem-atum-40-13.jpg) <small>endurasupply.com</small>Raychem ATUM 40/13 - Endura Supply

RAYCHEM ATUM-32/8-0-STK Heat Shrinkable Tubing Polyolefin Black Stick BAG OF 10 | EBay
--------------------------------------------------------------------------------------

 ![RAYCHEM ATUM-32/8-0-STK Heat Shrinkable Tubing Polyolefin Black Stick BAG OF 10 | eBay](https://i.ebayimg.com/images/g/6QcAAOSwueVg3MM6/s-l1600.jpg) <small>www.ebay.com</small>RAYCHEM ATUM-32/8-0-STK Heat Shrinkable Tubing Polyolefin Black Stick BAG OF 10 | eBay

Raychem ATUM 4:1
----------------

 ![Raychem ATUM 4:1](https://www.prowireusa.com/content/59115/ATUM-16-4.webp) <small>www.prowireusa.com</small>Raychem ATUM 4:1

Raychem ATUM 4:1
----------------

 ![Raychem ATUM 4:1](https://www.prowireusa.com/content/62090/ATUM-52-13.webp) <small>www.prowireusa.com</small>Raychem ATUM 4:1

Raychem Raychem ATUM 3/1 High-Shrink Ratio 3:1, Adhesive-Lined Polyolefin Tubing - Black |Heat
----------------------------------------------------------------------------------------------

 ![Raychem Raychem ATUM 3/1 High-Shrink Ratio 3:1, Adhesive-Lined Polyolefin Tubing - Black |Heat](https://eadn-wc04-1925978.nxedge.io/cdn/media/catalog/product/cache/a7b707b5b82b05683a3f029c98969ced/_/t/_tubing_raychem-atum.jpg) <small>www.lapptannehill.com</small>Raychem Raychem ATUM 3/1 High-Shrink Ratio 3:1, Adhesive-Lined Polyolefin Tubing - Black |Heat ...

Raychem ATUM Heat Shrink Tubing (Adhesive Lined) | Race Spec
------------------------------------------------------------

 ![Raychem ATUM Heat Shrink Tubing (Adhesive Lined) | Race Spec](https://racespeconline.com/cdn/shop/products/tubing-raychem-atum-1_1200x.jpg?v=1472747755) <small>racespeconline.com</small>Raychem ATUM Heat Shrink Tubing (Adhesive Lined) | Race Spec

Raychem ATUM 4:1
----------------

 ![Raychem ATUM 4:1](https://www.prowireusa.com/content/59114/ATUM12-3-0-STK  TE Connectivity.webp) <small>www.prowireusa.com</small>Raychem ATUM 4:1

ATUM-24/8-2-STK TE Connectivity Raychem Cable Protection | Cables, Wires - Management | DigiKey
-----------------------------------------------------------------------------------------------

 ![ATUM-24/8-2-STK TE Connectivity Raychem Cable Protection | Cables, Wires - Management | DigiKey](https://media.digikey.com/Photos/TE Connectivity/ATUM-24^6-0-STK.jpg) <small>www.digikey.com</small>ATUM-24/8-2-STK TE Connectivity Raychem Cable Protection | Cables, Wires - Management | DigiKey

ATUM-8/2-0-STK TE Connectivity Raychem Cable Protection | Cables, Alambres - Administración
-------------------------------------------------------------------------------------------

 ![ATUM-8/2-0-STK TE Connectivity Raychem Cable Protection | Cables, alambres - administración](https://media.digikey.com/photos/Tyco Photos/ATUM-8^2-0-STK.JPG) <small>www.digikey.com.mx</small>ATUM-8/2-0-STK TE Connectivity Raychem Cable Protection | Cables, alambres - administración ...

ATUM 3:1 Raychem / TE Connectivity Adhesive Lined Heat Shrink Tubing - PMG Company
----------------------------------------------------------------------------------

 ![ATUM 3:1 Raychem / TE Connectivity Adhesive Lined Heat Shrink Tubing - PMG Company](https://www.pmgcompanyonline.com/wp-content/uploads/2020/04/ATUM-3-1.jpg) <small>www.pmgcompanyonline.com</small>ATUM 3:1 Raychem / TE Connectivity Adhesive Lined Heat Shrink Tubing - PMG Company

ATUM-24/8-0-STK : RAYCHEM ATUM 3:1 Heat Shrink Tubing | TE Connectivity
-----------------------------------------------------------------------

 ![ATUM-24/8-0-STK : RAYCHEM ATUM 3:1 Heat Shrink Tubing | TE Connectivity](https://www.te.com/content/dam/te-com/catalog/part/EM5/611/600/EM56116001-t1.jpg/jcr:content/renditions/product-high-res.png) <small>www.te.com</small>ATUM-24/8-0-STK : RAYCHEM ATUM 3:1 Heat Shrink Tubing | TE Connectivity

ATUM-6/2-0-STK TE Connectivity Raychem Cable Protection | Cables, Wires - Management | DigiKey
----------------------------------------------------------------------------------------------

 ![ATUM-6/2-0-STK TE Connectivity Raychem Cable Protection | Cables, Wires - Management | DigiKey](https://media.digikey.com/photos/Tyco Raychem Photos/ATU062K.jpg) <small>www.digikey.com</small>ATUM-6/2-0-STK TE Connectivity Raychem Cable Protection | Cables, Wires - Management | DigiKey

Raychem ATUM Krimpkous Met Lijm - Idetrading.com
------------------------------------------------

 ![Raychem ATUM krimpkous met lijm - Idetrading.com](https://118.wpcdnnode.com/idetrading.com/wp-content/uploads/2025/06/raychem-atum.jpg) <small>idetrading.com</small>Raychem ATUM krimpkous met lijm - Idetrading.com

ATUM-9/3-0-STK TE Connectivity Raychem Cable Protection | Cables, Wires - Management | DigiKey
----------------------------------------------------------------------------------------------

 ![ATUM-9/3-0-STK TE Connectivity Raychem Cable Protection | Cables, Wires - Management | DigiKey](https://media.digikey.com/photos/Tyco Raychem Photos/ATU093K.jpg) <small>www.digikey.co.uk</small>ATUM-9/3-0-STK TE Connectivity Raychem Cable Protection | Cables, Wires - Management | DigiKey

Raychem ATUM, 12-4mm Dual Wall Adhesive Lined Heat Shrink Tubing - 1.2M Length
------------------------------------------------------------------------------

 ![Raychem ATUM, 12-4mm Dual Wall Adhesive Lined Heat Shrink Tubing - 1.2M Length](https://www.cablecraft.co.uk/media/catalog/product/a/t/atum-heat-shrink-adhesive.png?quality=80&bg-color=255,255,255&fit=bounds&height=&width=) <small>www.cablecraft.co.uk</small>Raychem ATUM, 12-4mm Dual Wall Adhesive Lined Heat Shrink Tubing - 1.2M Length

ATUM-12/4-0-STK TE CONNECTIVITY - RAYCHEM, Adhesive Lined Heat Shrink Tubing, 3:1, 0.472
----------------------------------------------------------------------------------------

 ![ATUM-12/4-0-STK TE CONNECTIVITY - RAYCHEM, Adhesive Lined Heat Shrink Tubing, 3:1, 0.472](https://uk.farnell.com/productimages/standard/en_GB/3236574-40.jpg) <small>uk.farnell.com</small>ATUM-12/4-0-STK TE CONNECTIVITY - RAYCHEM, Adhesive Lined Heat Shrink Tubing, 3:1, 0.472 ...

RAYCHEM ATUM Heat Shrink - ATUM-8/2-0-SP
----------------------------------------

 ![RAYCHEM ATUM Heat Shrink - ATUM-8/2-0-SP](https://hilltop-products.co.uk/media/catalog/product/cache/6d2ffb848796335b7eb82cc8e3ea4df5/a/t/atum_new_2015_3_3nd.jpg) <small>hilltop-products.co.uk</small>RAYCHEM ATUM Heat Shrink - ATUM-8/2-0-SP

ATUM-24/6-0-STK TE Connectivity | Raychem Products | Heilind
------------------------------------------------------------

 ![ATUM-24/6-0-STK TE Connectivity | Raychem Products | Heilind](https://sku-product-images.s3.us-east-2.amazonaws.com/RYC/RYCNB14032001.jpg) <small>www.heilind.com</small>ATUM-24/6-0-STK TE Connectivity | Raychem Products | Heilind

Raychem ATUM – Glue Lined Heat Shrink – PT Motorsport
-----------------------------------------------------

 ![Raychem ATUM – Glue Lined heat shrink – PT Motorsport](https://www.ptmotorsport.com.au/wp-content/uploads/2023/08/IGP4914-1024x679.jpg) <small>www.ptmotorsport.com.au</small>Raychem ATUM – Glue Lined heat shrink – PT Motorsport

Raychem美国瑞侃ATUM热缩管ATUM-12/4-0-STK热收缩绝缘套管进口-淘宝Taobao | 天猫Tmall
-------------------------------------------------------------

 ![Raychem美国瑞侃ATUM热缩管ATUM-12/4-0-STK热收缩绝缘套管进口-淘宝Taobao | 天猫Tmall](https://img.alicdn.com/imgextra/i2/1049709076/O1CN01XHQWKe2GurpGXI6r9_!!1049709076.jpg_q50s50.jpg_.webp) <small>www.taobao.com</small>Raychem美国瑞侃ATUM热缩管ATUM-12/4-0-STK热收缩绝缘套管进口-淘宝Taobao | 天猫Tmall

Raychem atum 4:1. Raychem atum-32/8-0-stk heat shrinkable tubing polyolefin black stick bag of 10. raychem atum – kit – pt motorsport
