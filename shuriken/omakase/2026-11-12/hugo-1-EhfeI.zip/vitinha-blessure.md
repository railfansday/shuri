---
title: "Vitinha Blessure - Vitinha: stats, goals and matches 2026/27"
description: "The incredible data behind psg&#039;s midfield superstar vitinha"
date: "2026-02-04"
categories:
- "Uncategorized"
images:
- "https://www.poznavach.com/cache/images/players/902029.png?v=3"
featuredImage: "https://pictures.tribuna.com/image/f6116150-749e-406c-8366-70fef009982f?width=1920&amp;quality=70"
featured_image: "https://img.emisorasunidas.com/upload/2026/11/17161D524C42456D15100F55524940781F151B18544340791D1E1F-1200x800.jpg"
image: "https://one-versus-one.com/img/ogimage.png"
---

If you are looking for How Portugal Will Line Up At The 2026 World Cup Ronaldo And Vitinha | Teachpic you've visit to the right web. We have 35 Pictures about How Portugal Will Line Up At The 2026 World Cup Ronaldo And Vitinha | Teachpic like Vitinha of Paris Saint-Germain goes down with injury during the UEFA Champions League Last 16, 'It was a tricky match': Vitinha reflects on the narrow win over Troyes - Football | Tribuna.com and also Vitinha: stats, goals and matches 2026/27 | Poznavach. Here you go:

How Portugal Will Line Up At The 2026 World Cup Ronaldo And Vitinha | Teachpic
------------------------------------------------------------------------------

 ![How Portugal Will Line Up At The 2026 World Cup Ronaldo And Vitinha | Teachpic](https://prod-media.beinsports.com/image/Portugal Cristiano Ronaldo.1080.jpg) <small>teachpic.com</small>How Portugal Will Line Up At The 2026 World Cup Ronaldo And Vitinha | Teachpic

🚨 𝐎𝐅𝐅𝐈𝐂𝐈𝐀𝐋: 𝟐𝟎𝟐𝟔 𝐓𝐄𝐀𝐌 𝐎𝐅 𝐓𝐇𝐄 𝐘𝐄𝐀𝐑! 🌎⭐️ 🧤 Raya; 🛡️ Hakimi, Cubarsí, Nuno Mendes; ⚙️ Rodri
----------------------------------------------------------------------------------------

 ![🚨 𝐎𝐅𝐅𝐈𝐂𝐈𝐀𝐋: 𝟐𝟎𝟐𝟔 𝐓𝐄𝐀𝐌 𝐎𝐅 𝐓𝐇𝐄 𝐘𝐄𝐀𝐑! 🌎⭐️ 🧤 Raya; 🛡️ Hakimi, Cubarsí, Nuno Mendes; ⚙️ Rodri](https://lookaside.fbsbx.com/lookaside/crawler/media/?media_id=122128923975310993) <small>www.facebook.com</small>🚨 𝐎𝐅𝐅𝐈𝐂𝐈𝐀𝐋: 𝟐𝟎𝟐𝟔 𝐓𝐄𝐀𝐌 𝐎𝐅 𝐓𝐇𝐄 𝐘𝐄𝐀𝐑! 🌎⭐️ 🧤 Raya; 🛡️ Hakimi, Cubarsí, Nuno Mendes; ⚙️ Rodri ...

Vitinha - YouTube
-----------------

 ![Vitinha - YouTube](https://i.ytimg.com/vi/O1_eJl3wrVs/maxresdefault.jpg?sqp=-oaymwEoCIAKENAF8quKqQMcGADwAQH4AbYIgAK4CIoCDAgAEAEYUCBlKC8wDw==&rs=AOn4CLB4DLgOtwFxk2-tfJmpz-KdqqVTiw) <small>www.youtube.com</small>Vitinha - YouTube

Eusebio Or Cristiano Ronaldo? Vitinha Makes His Pick For Portugal's Greatest Ever — Tribuna.com
-----------------------------------------------------------------------------------------------

 ![Eusebio or Cristiano Ronaldo? Vitinha makes his pick for Portugal's greatest ever — Tribuna.com](https://pictures.tribuna.com/image/f6116150-749e-406c-8366-70fef009982f?width=1920&quality=70) <small>tribuna.com</small>Eusebio or Cristiano Ronaldo? Vitinha makes his pick for Portugal's greatest ever — Tribuna.com

Vitinha - YouTube
-----------------

 ![vitinha - YouTube](https://i.ytimg.com/vi/qgVuXAxM2-Y/oar2.jpg?sqp=-oaymwEoCJUDENAFSFqQAgHyq4qpAxcIARUAAAAAJQAAyEI9AICiQ3gBuAL3GA==&rs=AOn4CLAAmQdPtXp56QvaATX5hNu9XZqP_A) <small>www.youtube.com</small>vitinha - YouTube

How Portugal Will Line Up At The 2026 World Cup Ronaldo And Vitinha | Teachpic
------------------------------------------------------------------------------

 ![How Portugal Will Line Up At The 2026 World Cup Ronaldo And Vitinha | Teachpic](https://media.assettype.com/outlookindia/2024-10-30/2i2gymgg/vitinha_cristiano_ronaldo_1f664f696qrko1kfqzawwi6mwd.jpg?w=560&auto=format%2Ccompress&fit=max&format=webp&dpr=1.0) <small>teachpic.com</small>How Portugal Will Line Up At The 2026 World Cup Ronaldo And Vitinha | Teachpic

PSG's Luis Enrique: Vitinha Deserved Higher Ballon D'Or Ranking - ESPN
----------------------------------------------------------------------

 ![PSG's Luis Enrique: Vitinha deserved higher Ballon d'Or ranking - ESPN](https://a4.espncdn.com/combiner/i?img=%2Fphoto%2F2026%2F1029%2Fr1738175_1296x729_16-9.jpg) <small>www.espn.co.uk</small>PSG's Luis Enrique: Vitinha deserved higher Ballon d'Or ranking - ESPN

How Portugal Will Line Up At The 2026 World Cup Ronaldo And Vitinha | Teachpic
------------------------------------------------------------------------------

 ![How Portugal Will Line Up At The 2026 World Cup Ronaldo And Vitinha | Teachpic](https://media.gettyimages.com/id/2233975552/photo/hungary-v-portugal-fifa-world-cup-2026-qualifier.jpg?s=1024x1024&w=gi&k=20&c=ojj3oAdMMUX6ii-mOMWB5VNz2lrL-0q0auWe-kGg1dU=) <small>teachpic.com</small>How Portugal Will Line Up At The 2026 World Cup Ronaldo And Vitinha | Teachpic

Vitinha Of Paris Saint-Germain Goes Down With Injury During The UEFA Champions League Last 16
---------------------------------------------------------------------------------------------

 ![Vitinha of Paris Saint-Germain goes down with injury during the UEFA Champions League Last 16](https://c8.alamy.com/comp/3A24BMW/vitinha-of-paris-saint-germain-goes-down-with-injury-during-the-uefa-champions-league-last-16-match-liverpool-vs-paris-saint-germain-at-anfield-liverpool-united-kingdom-11th-march-2025-photo-by-mark-cosgrovenews-images-3A24BMW.jpg) <small>www.alamy.com</small>Vitinha of Paris Saint-Germain goes down with injury during the UEFA Champions League Last 16 ...

Vitinha: FC Porto's Faith In Youth That Sérgio Conceição Recalls | OneFootball
------------------------------------------------------------------------------

 ![Vitinha: FC Porto's faith in youth that Sérgio Conceição recalls | OneFootball](https://photobooth-api.onefootball.com/api/screenshot//v2/photobooth/cms/en/43690472%3Fdate=2026-11-12) <small>onefootball.com</small>Vitinha: FC Porto's faith in youth that Sérgio Conceição recalls | OneFootball

GOL DE TIRO LIBRE DE VITINHA PSG VS ATM. | Comando Thrash
---------------------------------------------------------

 ![GOL DE TIRO LIBRE DE VITINHA PSG VS ATM. | Comando Thrash](https://lookaside.fbsbx.com/lookaside/crawler/media/?media_id=1035230035987183) <small>www.facebook.com</small>GOL DE TIRO LIBRE DE VITINHA PSG VS ATM. | Comando Thrash

PSG: Vitinha’s Future Is Taking Shape
-------------------------------------

 ![PSG: Vitinha’s future is taking shape](https://frenchfootballweekly.com/wp-content/uploads/2023/07/French-Football-Weekly.jpg) <small>frenchfootballweekly.com</small>PSG: Vitinha’s future is taking shape

Real Madrid Suffer Vitinha Transfer Setback As Jorge Mendes Stance Emerges - Sports Mole
----------------------------------------------------------------------------------------

 ![Real Madrid suffer Vitinha transfer setback as Jorge Mendes stance emerges - Sports Mole](https://www.sportsmole.co.uk/thumbor/qZLIVKtLxiP6QziccdnZiJgZ0TQ=/720x410/smart/filters:format(webp)/https://sportsmole-media-prod.s3.gra.io.cloud.ovh.net/uploads/2026/10/vitinha-real-6addd5dad4116461765567.jpg) <small>www.sportsmole.co.uk</small>Real Madrid suffer Vitinha transfer setback as Jorge Mendes stance emerges - Sports Mole

Vitinha Vs Richardson | Compare Players
---------------------------------------

 ![Vitinha vs Richardson | Compare players](https://one-versus-one.com/img/ogimage.png) <small>one-versus-one.com</small>Vitinha vs Richardson | Compare players

VITINHA 122 Overs Review – FC Mobile 2027 Player Breakdown | TikTok
-------------------------------------------------------------------

 ![VITINHA 122 Overs Review – FC Mobile 2027 Player Breakdown | TikTok](https://www.tiktok.com/api/img/?itemId=7702074136289348872&location=0&aid=1988) <small>www.tiktok.com</small>VITINHA 122 Overs Review – FC Mobile 2027 Player Breakdown | TikTok

Vítinha Statistics 2026/27 – Goals, Assists, Career | Spor Radar
----------------------------------------------------------------

 ![Vítinha Statistics 2026/27 – Goals, Assists, Career | Spor Radar](https://media.api-sports.io/football/players/281408.png) <small>sporradar.com</small>Vítinha Statistics 2026/27 – Goals, Assists, Career | Spor Radar

Vitinha Stats 2026/27 — Market Value, Goals, Trophies &amp; Rating | Golazo
---------------------------------------------------------------------------

 ![Vitinha Stats 2026/27 — Market Value, Goals, Trophies & Rating | Golazo](https://golazoapp.io/play/og.png?t=Vitinha+in+numbers&e=📊) <small>golazoapp.io</small>Vitinha Stats 2026/27 — Market Value, Goals, Trophies &amp; Rating | Golazo

Is Vitinha PSG’s Best Player? - The Athletic
--------------------------------------------

 ![Is Vitinha PSG’s best player? - The Athletic](https://static01.nyt.com/athletic/uploads/wp/2025/04/09083552/Vitinha-1024x683.jpg?width=1920&quality=70&auto=webp) <small>www.nytimes.com</small>Is Vitinha PSG’s best player? - The Athletic

I Hope Ronaldo Returns To Portugal Squad: Vitinha | The Daily Star
------------------------------------------------------------------

 ![I hope Ronaldo returns to Portugal squad: Vitinha | The Daily Star](https://www.thedailystar.net/sites/default/files/styles/portrait_455x600/public/2026-10/Vitinha.jpg) <small>www.thedailystar.net</small>I hope Ronaldo returns to Portugal squad: Vitinha | The Daily Star

Vítinha Statistics 2026/27 – Goals, Assists, Career | Spor Radar
----------------------------------------------------------------

 ![Vítinha Statistics 2026/27 – Goals, Assists, Career | Spor Radar](https://sporradar.com/brand/og-default.png) <small>sporradar.com</small>Vítinha Statistics 2026/27 – Goals, Assists, Career | Spor Radar

Vitinha: Stats, Goals And Matches 2026/27 | Poznavach
-----------------------------------------------------

 ![Vitinha: stats, goals and matches 2026/27 | Poznavach](https://www.poznavach.com/cache/images/players/902029.png?v=3) <small>www.poznavach.com</small>Vitinha: stats, goals and matches 2026/27 | Poznavach

Pedri Vs Vitinha Big Chances Created Full Career | StatMuse
-----------------------------------------------------------

 ![Pedri Vs Vitinha Big Chances Created Full Career | StatMuse](https://cdn.statmuse.com/forge-v2/aHR0cHM6Ly9jZG4uc3RhdG11c2UuY29tL2ltZy9mYy9wbGF5ZXJzL2JhcmNlbG9uYS1wZWRyaTIwMjYtLXhhM3lxd210LnBuZz9iZz1DNTAwNDMmdD10d2l0dGVy.png) <small>www.statmuse.com</small>Pedri Vs Vitinha Big Chances Created Full Career | StatMuse

CHAMPION 2x 🏆🏆 On X: "@MacSpace\_\_ Du Coup Sadiki Au PSG, ça Passe Devant Neves Vitinha Ruiz ?" / X
----------------------------------------------------------------------------------------------------

 ![CHAMPION 2x 🏆🏆 on X: "@MacSpace__ Du coup Sadiki au PSG, ça passe devant Neves Vitinha Ruiz ?" / X](https://pbs.twimg.com/profile_images/2061430317202698240/wF2d8wMO_400x400.jpg) <small>x.com</small>CHAMPION 2x 🏆🏆 on X: "@MacSpace\_\_ Du coup Sadiki au PSG, ça passe devant Neves Vitinha Ruiz ?" / X

'It Was A Tricky Match': Vitinha Reflects On The Narrow Win Over Troyes - Football | Tribuna.com
------------------------------------------------------------------------------------------------

 !['It was a tricky match': Vitinha reflects on the narrow win over Troyes - Football | Tribuna.com](https://pictures.tribuna.com/image/2aa36899-ce67-455f-adc2-0d18e427c898?width=1920&quality=70) <small>tribuna.com</small>'It was a tricky match': Vitinha reflects on the narrow win over Troyes - Football | Tribuna.com

Vitinha - YouTube
-----------------

 ![vitinha - YouTube](https://i.ytimg.com/vi/qgVuXAxM2-Y/maxres2.jpg?sqp=-oaymwEoCIAKENAF8quKqQMcGADwAQH4Ac4FgAKACooCDAgAEAEYOiBBKH8wDw==&rs=AOn4CLBuHwuKmKTIZn5GaS5hb8G1NOvxgg) <small>www.youtube.com</small>vitinha - YouTube

Vitinha: PSG’s Most Important Player Under Luis Enrique? | TikTok
-----------------------------------------------------------------

 ![Vitinha: PSG’s Most Important Player Under Luis Enrique? | TikTok](https://www.tiktok.com/api/img/?itemId=7705833934348700960&location=0&aid=1988) <small>www.tiktok.com</small>Vitinha: PSG’s Most Important Player Under Luis Enrique? | TikTok

Real Madrid Interest In PSG Star Confirmed As Transfer Looks Impossible
-----------------------------------------------------------------------

 ![Real Madrid Interest in PSG Star Confirmed as Transfer Looks Impossible](https://icdn.psgtalk.com/wp-content/uploads/2025/04/vitinha-psg-v-arsenal-ucl-2025.jpg) <small>psgtalk.com</small>Real Madrid Interest in PSG Star Confirmed as Transfer Looks Impossible

Pedri, Vitinha And Declan Rice – Stats This Season | Daniel Mbam CFC
--------------------------------------------------------------------

 ![Pedri, Vitinha and Declan Rice – Stats This Season | Daniel Mbam CFC](https://lookaside.fbsbx.com/lookaside/crawler/media/?media_id=122145720165107222) <small>www.facebook.com</small>Pedri, Vitinha and Declan Rice – Stats This Season | Daniel Mbam CFC

I Hope Ronaldo Returns To Portugal Squad: Vitinha | The Daily Star
------------------------------------------------------------------

 ![I hope Ronaldo returns to Portugal squad: Vitinha | The Daily Star](https://www.thedailystar.net/sites/default/files/styles/big_1/public/2026-10/Vitinha-Ronaldo.jpg?h=1eea4cb0) <small>www.thedailystar.net</small>I hope Ronaldo returns to Portugal squad: Vitinha | The Daily Star

Vitinha's Hat Trick Helps PSG Rally Twice To Beat Tottenham In Champions League
-------------------------------------------------------------------------------

 ![Vitinha's hat trick helps PSG rally twice to beat Tottenham in Champions League](https://www.tsn.ca/resizer/v2/ZVOKUDHDBDLVNLFWDGQJTGA64M.jpg?smart=true&auth=28e18fcde563ca3f4c93d05adcc35e7f7eb45188fe07b3896366836c4b4dc9c7&width=1400&height=787) <small>www.tsn.ca</small>Vitinha's hat trick helps PSG rally twice to beat Tottenham in Champions League

Vitinha: From Failed Wolves Loan To Becoming The World's Best Midfielder At PSG | Goal.com US
---------------------------------------------------------------------------------------------

 ![Vitinha: From failed Wolves loan to becoming the world's best midfielder at PSG | Goal.com US](https://assets.goal.com/images/v3/blt85cdfe2c0dae1d0f/Header-Vitinha-16-9.jpg) <small>www.goal.com</small>Vitinha: From failed Wolves loan to becoming the world's best midfielder at PSG | Goal.com US

Vitinha's Goal Helps PSG Topple Barcelona In A Classic; Manchester City, Liverpool Earn Wins In
-----------------------------------------------------------------------------------------------

 ![Vitinha's goal helps PSG topple Barcelona in a classic; Manchester City, Liverpool earn wins in](https://s.yimg.com/lo/mysterio/api/ef005af34b91c4ededea4a33618376c3b1a9209f7e4d319416fcb252e183d295/lightyear_networkapi/resizefill_w1200_h675%3Bquality_80%3Bformat_webp/https://d29szjachogqwa.cloudfront.net/images/2026-10/31345198-e4d3-44a6-9e7d-5cd56009eb9a) <small>sports.yahoo.com</small>Vitinha's goal helps PSG topple Barcelona in a classic; Manchester City, Liverpool earn wins in ...

Vitinha Y Joao Félix Encabezan Convocatoria De Portugal
-------------------------------------------------------

 ![Vitinha y Joao Félix encabezan convocatoria de Portugal](https://img.emisorasunidas.com/upload/2026/11/17161D524C42456D15100F55524940781F151B18544340791D1E1F-1200x800.jpg) <small>emisorasunidas.com</small>Vitinha y Joao Félix encabezan convocatoria de Portugal

'Exceptional, Almost Unique!' - Vitinha Told He Has 'no Limits' And Should Aim For Ballon D'Or
----------------------------------------------------------------------------------------------

 !['Exceptional, almost unique!' - Vitinha told he has 'no limits' and should aim for Ballon d'Or](https://assets.goal.com/images/v3/blt4840a76194cf2250/Vitinha.jpeg?auto=webp&format=pjpg&width=1920&quality=60) <small>www.goal.com</small>'Exceptional, almost unique!' - Vitinha told he has 'no limits' and should aim for Ballon d'Or ...

The Incredible Data Behind PSG's Midfield Superstar Vitinha
-----------------------------------------------------------

 ![The Incredible Data Behind PSG's Midfield Superstar Vitinha](https://deweb-519a7.b-cdn.net/post-images/a7d3aae3-e7f1-4191-a643-b6af2982f07d.jpeg?width=1080) <small>roundtable.io</small>The Incredible Data Behind PSG's Midfield Superstar Vitinha

Vitinha of paris saint-germain goes down with injury during the uefa champions league last 16. Real madrid interest in psg star confirmed as transfer looks impossible. vitinha's hat trick helps psg rally twice to beat tottenham in champions league
