---
title: "Cf Estrela Amadora Vs Sporting Cp - Daniel braganca of sporting cp celebrates after scoring a goal during... news photo"
description: "Kikas 98 of estrela da amadora and eduardo quaresma 72 of sporting cp fighting for possession ..."
date: "2026-03-17"
categories:
- "Uncategorized"
images:
- "https://c8.alamy.com/comp/2YF858M/lisboa-portugal-01st-nov-2024-assistant-coach-luis-silva-of-cf-estrela-da-amadora-seen-during-the-match-between-sporting-cp-and-cf-estrela-da-amadora-for-the-liga-portugal-betclic-at-estadio-jose-alvalade-final-score-sporting-cp-5-1-cf-estrela-da-amadora-photo-by-david-martinssopa-imagessipa-usa-credit-sipa-usalamy-live-news-2YF858M.jpg"
featuredImage: "https://i.ytimg.com/vi/WyDD-HjwGog/maxresdefault.jpg"
featured_image: "https://c8.alamy.com/comp/3A928JW/amadoraportugalmarch-29th-2025-gyokeres-9-sporting-cp-in-action-during-the-liga-portugal-betclic-game-between-cf-estrela-da-amadora-vs-sporting-cp-estadio-jose-gomes-amadora-on-29th-march-2025-joo-bravo-spp-3A928JW.jpg"
image: "https://c8.alamy.com/comp/2YEXK3J/portugal-01st-nov-2024-viktor-gyokeres-forward-of-sporting-cp-and-rben-lima-defender-of-estrela-amadora-during-the-liga-portugal-betclic-match-between-sporting-cp-and-cf-estrela-amadora-at-estadio-jose-de-alvalade-on-november-01th-2024-in-lisbon-portugal-liga-portugal-betclic-sporting-cp-vs-cf-estrela-amadora-valter-gouveiaspp-credit-spp-sport-press-photo-alamy-live-news-2YEXK3J.jpg"
---

If you are looking for Goncalo Inacio of Sporting CP tries to escape Aloisio Souza of CF... News Photo - Getty Images you've visit to the right place. We have 35 Pictures about Goncalo Inacio of Sporting CP tries to escape Aloisio Souza of CF... News Photo - Getty Images like Amadora,Portugal,March 29th, 2025: Gyokeres (9 Sporting CP) in action during the Liga Portugal, Resumo | Liga Portugal: Sporting CP 4-0 CF Estrela da Amadora - YouTube and also Nani of CF Estrela da Amadora fights for the ball with Geovany Quenda... News Photo - Getty Images. Here you go:

Goncalo Inacio Of Sporting CP Tries To Escape Aloisio Souza Of CF... News Photo - Getty Images
----------------------------------------------------------------------------------------------

 ![Goncalo Inacio of Sporting CP tries to escape Aloisio Souza of CF... News Photo - Getty Images](https://media.gettyimages.com/id/1765588653/photo/sporting-cp-v-estrela-amadora-liga-portugal-bwin.jpg?s=1024x1024&w=gi&k=20&c=xE11EbOGrcQ_vMFed0sbeGDv6_hwmgygZKuP-mhxK-A=) <small>www.gettyimages.com</small>Goncalo Inacio of Sporting CP tries to escape Aloisio Souza of CF... News Photo - Getty Images

Highlight Sporting CP Vs CF Estrela Amadora SAD
-----------------------------------------------

 ![Highlight Sporting CP vs CF Estrela Amadora SAD](https://img.thesports.com/match/gif/cover/1056234148-177594088835472095.png) <small>www.fifadata.com</small>Highlight Sporting CP vs CF Estrela Amadora SAD

Lisboa, Portugal. 01st Nov, 2024. Assistant Coach Luis Silva Of CF Estrela Da Amadora Seen
------------------------------------------------------------------------------------------

 ![Lisboa, Portugal. 01st Nov, 2024. Assistant Coach Luis Silva of CF Estrela da Amadora seen](https://c8.alamy.com/comp/2YF858M/lisboa-portugal-01st-nov-2024-assistant-coach-luis-silva-of-cf-estrela-da-amadora-seen-during-the-match-between-sporting-cp-and-cf-estrela-da-amadora-for-the-liga-portugal-betclic-at-estadio-jose-alvalade-final-score-sporting-cp-5-1-cf-estrela-da-amadora-photo-by-david-martinssopa-imagessipa-usa-credit-sipa-usalamy-live-news-2YF858M.jpg) <small>www.alamy.com</small>Lisboa, Portugal. 01st Nov, 2024. Assistant Coach Luis Silva of CF Estrela da Amadora seen ...

Amadora,Portugal,March 29th, 2025: Gyokeres (9 Sporting CP) In Action During The Liga Portugal
----------------------------------------------------------------------------------------------

 ![Amadora,Portugal,March 29th, 2025: Gyokeres (9 Sporting CP) in action during the Liga Portugal](https://c8.alamy.com/comp/3A928JW/amadoraportugalmarch-29th-2025-gyokeres-9-sporting-cp-in-action-during-the-liga-portugal-betclic-game-between-cf-estrela-da-amadora-vs-sporting-cp-estadio-jose-gomes-amadora-on-29th-march-2025-joo-bravo-spp-3A928JW.jpg) <small>www.alamy.com</small>Amadora,Portugal,March 29th, 2025: Gyokeres (9 Sporting CP) in action during the Liga Portugal ...

Sporting CP Vs CF Estrela Da Amadora In Lisboa - 01 Nov 2024 Daniel Braganca Of Sporting CP With
------------------------------------------------------------------------------------------------

 ![Sporting CP Vs CF Estrela da Amadora in Lisboa - 01 Nov 2024 Daniel Braganca of Sporting CP with](https://cdn.imago-images.com/bild/sp/1053373202/s.jpg) <small>www.imago-images.com</small>Sporting CP Vs CF Estrela da Amadora in Lisboa - 01 Nov 2024 Daniel Braganca of Sporting CP with

Portugal. 01st Nov, 2024. Viktor Gyokeres Forward Of Sporting CP And Rúben Lima Defender Of
-------------------------------------------------------------------------------------------

 ![Portugal. 01st Nov, 2024. Viktor Gyokeres forward of Sporting CP and Rúben Lima defender of](https://c8.alamy.com/comp/2YEXK3J/portugal-01st-nov-2024-viktor-gyokeres-forward-of-sporting-cp-and-rben-lima-defender-of-estrela-amadora-during-the-liga-portugal-betclic-match-between-sporting-cp-and-cf-estrela-amadora-at-estadio-jose-de-alvalade-on-november-01th-2024-in-lisbon-portugal-liga-portugal-betclic-sporting-cp-vs-cf-estrela-amadora-valter-gouveiaspp-credit-spp-sport-press-photo-alamy-live-news-2YEXK3J.jpg) <small>www.alamy.com</small>Portugal. 01st Nov, 2024. Viktor Gyokeres forward of Sporting CP and Rúben Lima defender of ...

Sporting CP Vs Estrela Amadora Live Match Today | SCP Vs ESA Live Football Match 2023 Live - YouTube
----------------------------------------------------------------------------------------------------

 ![Sporting CP Vs Estrela Amadora Live Match Today | SCP Vs ESA Live Football Match 2023 Live - YouTube](https://i.ytimg.com/vi/iB0Num4LMzc/maxresdefault.jpg) <small>www.youtube.com</small>Sporting CP Vs Estrela Amadora Live Match Today | SCP Vs ESA Live Football Match 2023 Live - YouTube

Lisbon, Portugal. 01st Nov, 2024. Team Of Estrela Amadora Seen In Action During Liga Portugal
---------------------------------------------------------------------------------------------

 ![Lisbon, Portugal. 01st Nov, 2024. Team of Estrela Amadora seen in action during Liga Portugal](https://c8.alamy.com/comp/2YF8RM0/lisbon-portugal-01st-nov-2024-team-of-estrela-amadora-seen-in-action-during-liga-portugal-game-between-teams-of-sporting-cp-and-cf-estrela-amadora-at-estadio-jose-alvalade-final-score-sporting-cp-5-1-cf-estrela-amadora-photo-by-maciej-rogowskisopa-imagessipa-usa-credit-sipa-usaalamy-live-news-2YF8RM0.jpg) <small>www.alamy.com</small>Lisbon, Portugal. 01st Nov, 2024. Team of Estrela Amadora seen in action during Liga Portugal ...

Estrela Da Amadora Vs Sporting CP - Live Score, Predicted Lineups And H2H Stats
-------------------------------------------------------------------------------

 ![Estrela da Amadora vs Sporting CP - live score, predicted lineups and H2H stats](https://www.fotmob.com/match/preview?matchId=4844417) <small>www.fotmob.com</small>Estrela da Amadora vs Sporting CP - live score, predicted lineups and H2H stats

Portugal. 01st Nov, 2024. Nani Forward Of Estrela Amadora Reacts During The Liga Portugal
-----------------------------------------------------------------------------------------

 ![Portugal. 01st Nov, 2024. Nani forward of Estrela Amadora reacts during the Liga Portugal](https://l450v.alamy.com/450v/2yexew2/portugal-01st-nov-2024-nani-forward-of-estrela-amadora-reacts-during-the-liga-portugal-betclic-match-between-sporting-cp-and-cf-estrela-amadora-at-estadio-jose-de-alvalade-on-november-01th-2024-in-lisbon-portugal-liga-portugal-betclic-sporting-cp-vs-cf-estrela-amadora-valter-gouveiaspp-credit-spp-sport-press-photo-alamy-live-news-2yexew2.jpg) <small>www.alamy.com</small>Portugal. 01st Nov, 2024. Nani forward of Estrela Amadora reacts during the Liga Portugal ...

Francisco Trincao De Sporting CP Avec Danilo Veiga De CF Estrela Da Amadora En Action Lors Du
---------------------------------------------------------------------------------------------

 ![Francisco Trincao de Sporting CP avec Danilo Veiga de CF Estrela da Amadora en action lors du](https://c8.alamy.com/compfr/2yf7wpx/francisco-trincao-de-sporting-cp-avec-danilo-veiga-de-cf-estrela-da-amadora-en-action-lors-du-match-entre-sporting-cp-et-cf-estrela-da-amadora-pour-la-liga-portugal-betclic-a-l-estadio-jose-alvalade-score-final-sporting-cp-5-1-cf-estrela-da-amadora-2yf7wpx.jpg) <small>www.alamyimages.fr</small>Francisco Trincao de Sporting CP avec Danilo Veiga de CF Estrela da Amadora en action lors du ...

Vlog: Sporting CP 3 Vs 2 CF Estrela Da Amadora (Liga Portugal Betclic 23/24) - YouTube
--------------------------------------------------------------------------------------

 ![Vlog: Sporting CP 3 vs 2 CF Estrela da Amadora (Liga Portugal Betclic 23/24) - YouTube](https://i.ytimg.com/vi/geN2H_8Jnfw/maxresdefault.jpg) <small>www.youtube.com</small>Vlog: Sporting CP 3 vs 2 CF Estrela da Amadora (Liga Portugal Betclic 23/24) - YouTube

Kikas Of CF Estrela Da Amadora Scores CF Estrela Da Amadora Second... News Photo - Getty Images
-----------------------------------------------------------------------------------------------

 ![Kikas of CF Estrela da Amadora scores CF Estrela da Amadora second... News Photo - Getty Images](https://media.gettyimages.com/id/1765373022/photo/sporting-cp-v-estrela-amadora-liga-portugal-bwin.jpg?s=1024x1024&w=gi&k=20&c=q6Nsr0rtmmrqFQxtAi-z6QzexABchjRzKUKr0HajZAM=) <small>www.gettyimages.co.uk</small>Kikas of CF Estrela da Amadora scores CF Estrela da Amadora second... News Photo - Getty Images

Luis Suarez 97 Of Sporting CP Celebrates After Scoring During The Liga Portugal Match Between
---------------------------------------------------------------------------------------------

 ![Luis Suarez 97 of Sporting CP celebrates after scoring during the Liga Portugal match between](https://c8.alamy.com/comp/3D8FGMF/luis-suarez-97-of-sporting-cp-celebrates-after-scoring-during-the-liga-portugal-match-between-sporting-cp-vs-estrela-da-amadora-at-estadio-jose-alvalade-on-november-30th2025-photo-by-joao-bravosports-press-photo-3D8FGMF.jpg) <small>www.alamy.com</small>Luis Suarez 97 of Sporting CP celebrates after scoring during the Liga Portugal match between ...

Estrela Amadora Vs Sporting CP EM DIRETO | Liga Portugal 25/26 | EM DIRETO NA GAMEPLAY PES 2021
-----------------------------------------------------------------------------------------------

 ![Estrela Amadora vs Sporting CP EM DIRETO | Liga Portugal 25/26 | EM DIRETO NA GAMEPLAY PES 2021](https://i.ytimg.com/vi/fjLsUL887oM/maxresdefault.jpg) <small>www.youtube.com</small>Estrela Amadora vs Sporting CP EM DIRETO | Liga Portugal 25/26 | EM DIRETO NA GAMEPLAY PES 2021 ...

Resumo | Liga Portugal: CF Estrela Da Amadora 0-1 Sporting CP - YouTube
-----------------------------------------------------------------------

 ![Resumo | Liga Portugal: CF Estrela da Amadora 0-1 Sporting CP - YouTube](https://i.ytimg.com/vi/twHCWfQ0SCw/maxresdefault.jpg) <small>www.youtube.com</small>Resumo | Liga Portugal: CF Estrela da Amadora 0-1 Sporting CP - YouTube

Viktor Gyokeres Of Sporting CP In Action During The Liga Portugal... News Photo - Getty Images
----------------------------------------------------------------------------------------------

 ![Viktor Gyokeres of Sporting CP in action during the Liga Portugal... News Photo - Getty Images](https://media.gettyimages.com/id/2181645712/photo/sporting-cp-v-cf-estrela-da-amadora-liga-portugal-betclic.jpg?s=1024x1024&w=gi&k=20&c=pQSHkBU1QxQDR9JnFatynVanZJ6QzkPKyr7WUe2HLVw=) <small>www.gettyimages.com</small>Viktor Gyokeres of Sporting CP in action during the Liga Portugal... News Photo - Getty Images

CF Estrela Amadora Vs Sporting CP B Live Score, H2H And Lineups | Sofascore
---------------------------------------------------------------------------

 ![CF Estrela Amadora vs Sporting CP B live score, H2H and lineups | Sofascore](https://img.sofascore.com/api/v1/event/12532658/share-image/16x9) <small>www.sofascore.com</small>CF Estrela Amadora vs Sporting CP B live score, H2H and lineups | Sofascore

Geovany Quenda Of Sporting CP Looks On During The Liga Portugal Betclic Match Between CF Estrela
------------------------------------------------------------------------------------------------

 ![Geovany Quenda of Sporting CP looks on during the Liga Portugal Betclic match between CF Estrela](https://c8.alamy.com/comp/3E82F58/geovany-quenda-of-sporting-cp-looks-on-during-the-liga-portugal-betclic-match-between-cf-estrela-da-amadora-and-sporting-cp-at-estadio-jose-de-gomes-on-april-11th-2026-in-amadora-portugal-liga-portugal-betclic-cf-estrela-da-amadora-vs-sporting-cp-valter-gouveiaspp-3E82F58.jpg) <small>www.alamy.com</small>Geovany Quenda of Sporting CP looks on during the Liga Portugal Betclic match between CF Estrela ...

Lisbon, Portugal . 29th Mar, 2025. Amadora, Portugal, March 29th, 2025: Gyokeres (9 Sporting CP
-----------------------------------------------------------------------------------------------

 ![Lisbon, Portugal . 29th Mar, 2025. Amadora, Portugal, March 29th, 2025: Gyokeres (9 Sporting CP](https://c8.alamy.com/comp/3A928MT/lisbon-portugal-29th-mar-2025-amadora-portugal-march-29th-2025-gyokeres-9-sporting-cp-in-action-during-the-liga-portugal-betclic-game-between-cf-estrela-da-amadora-vs-sporting-cp-estadio-jose-gomes-amadora-on-29th-march-2025-joo-bravo-spp-credit-spp-sport-press-photo-alamy-live-news-3A928MT.jpg) <small>www.alamy.com</small>Lisbon, Portugal . 29th Mar, 2025. Amadora, Portugal, March 29th, 2025: Gyokeres (9 Sporting CP ...

Resumo | Liga Portugal: Sporting CP 4-0 CF Estrela Da Amadora - YouTube
-----------------------------------------------------------------------

 ![Resumo | Liga Portugal: Sporting CP 4-0 CF Estrela da Amadora - YouTube](https://i.ytimg.com/vi/WyDD-HjwGog/maxresdefault.jpg) <small>www.youtube.com</small>Resumo | Liga Portugal: Sporting CP 4-0 CF Estrela da Amadora - YouTube

Sporting Vs Estrela Amadora - Highlight | Liga Portugal 2025/26
---------------------------------------------------------------

 ![Sporting vs Estrela Amadora - Highlight | Liga Portugal 2025/26](https://thumbor.prod.vidiocdn.com/Pstmg0W2GLyPvL3cp6m0sHmO3hk=/1280x720/filters:quality(70)/vidio-web-prod-video/uploads/video/image/9103890/sporting-vs-estrela-amadora-highlight-liga-portugal-2025-26-e03487.jpg) <small>www.vidio.com</small>Sporting vs Estrela Amadora - Highlight | Liga Portugal 2025/26

Sporting CP Vs Estrela Da Amadora (1 Nov 2024) 🔥 Video Highlights - FootyRoom
-----------------------------------------------------------------------------

 ![Sporting CP vs Estrela da Amadora (1 Nov 2024) 🔥 Video Highlights - FootyRoom](https://i.ytimg.com/vi/vLbYqqJXM7o/maxresdefault.jpg) <small>footyroom.co</small>Sporting CP vs Estrela da Amadora (1 Nov 2024) 🔥 Video Highlights - FootyRoom

Lisboa, Portugal. 01st Nov, 2024. Sporting CP Fans Seen During The Match Between Sporting CP And
------------------------------------------------------------------------------------------------

 ![Lisboa, Portugal. 01st Nov, 2024. Sporting CP fans seen during the match between Sporting CP and](https://c8.alamy.com/comp/2YF84KH/lisboa-portugal-01st-nov-2024-sporting-cp-fans-seen-during-the-match-between-sporting-cp-and-cf-estrela-da-amadora-for-the-liga-portugal-betclic-at-estadio-jose-alvalade-final-score-sporting-cp-5-1-cf-estrela-da-amadora-photo-by-david-martinssopa-imagessipa-usa-credit-sipa-usaalamy-live-news-2YF84KH.jpg) <small>www.alamy.com</small>Lisboa, Portugal. 01st Nov, 2024. Sporting CP fans seen during the match between Sporting CP and ...

Kikas 98 Of Estrela Da Amadora And Eduardo Quaresma 72 Of Sporting CP Fighting For Possession
---------------------------------------------------------------------------------------------

 ![Kikas 98 of Estrela da Amadora and Eduardo Quaresma 72 of Sporting CP fighting for possession](https://c8.alamy.com/comp/3D8FDJR/kikas-98-of-estrela-da-amadora-and-eduardo-quaresma-72-of-sporting-cp-fighting-for-possession-during-the-liga-portugal-match-between-sporting-cp-vs-estrela-da-amadora-at-estadio-jose-alvalade-on-november-30th2025-photo-by-joao-bravosports-press-photo-3D8FDJR.jpg) <small>www.alamy.com</small>Kikas 98 of Estrela da Amadora and Eduardo Quaresma 72 of Sporting CP fighting for possession ...

Portugal. 01st Nov, 2024. Nani Forward Of Estrela Amadora Reacts During The Liga Portugal
-----------------------------------------------------------------------------------------

 ![Portugal. 01st Nov, 2024. Nani forward of Estrela Amadora reacts during the Liga Portugal](https://c8.alamy.com/comp/2YEXET5/portugal-01st-nov-2024-nani-forward-of-estrela-amadora-reacts-during-the-liga-portugal-betclic-match-between-sporting-cp-and-cf-estrela-amadora-at-estadio-jose-de-alvalade-on-november-01th-2024-in-lisbon-portugal-liga-portugal-betclic-sporting-cp-vs-cf-estrela-amadora-valter-gouveiaspp-credit-spp-sport-press-photo-alamy-live-news-2YEXET5.jpg) <small>www.alamy.com</small>Portugal. 01st Nov, 2024. Nani forward of Estrela Amadora reacts during the Liga Portugal ...

Sporting CP Vs CF Estrela Da Amadora 2024 - 2025 Primeira Liga
--------------------------------------------------------------

 ![Sporting CP vs CF Estrela da Amadora 2024 - 2025 Primeira Liga](https://imgs.ticombo.com/tc-images-main/thumbnail/events/sports/sporting-cp-vs-cf-estrela-da-amadora-2024-2025-primeira-liga/thumbnail-48dabb16-badc-4055-96c9-f850705ad812.png) <small>www.ticombo.com</small>Sporting CP vs CF Estrela da Amadora 2024 - 2025 Primeira Liga

Daniel Braganca Of Sporting CP Celebrates After Scoring A Goal During... News Photo - Getty Images
--------------------------------------------------------------------------------------------------

 ![Daniel Braganca of Sporting CP celebrates after scoring a goal during... News Photo - Getty Images](https://media.gettyimages.com/id/1765339593/photo/sporting-cp-v-cf-estrela-da-amadora-liga-portugal-betclic.jpg?s=1024x1024&w=gi&k=20&c=FLOgkyepnd4N32NrCbk4CXc2NXQ8ArTbYpkG8ZftKLI=) <small>www.gettyimages.co.uk</small>Daniel Braganca of Sporting CP celebrates after scoring a goal during... News Photo - Getty Images

Sporting CP Vs. Estrela Da Amadora 2023-2024 | Footballia
---------------------------------------------------------

 ![Sporting CP vs. Estrela da Amadora 2023-2024 | Footballia](https://footballia.eu/cache/matches/f2ed4bf1265279e42d2c83744d763b81.png) <small>footballia.eu</small>Sporting CP vs. Estrela da Amadora 2023-2024 | Footballia

Nani Of CF Estrela Da Amadora Fights For The Ball With Geovany Quenda... News Photo - Getty Images
--------------------------------------------------------------------------------------------------

 ![Nani of CF Estrela da Amadora fights for the ball with Geovany Quenda... News Photo - Getty Images](https://media.gettyimages.com/id/2181647877/photo/sporting-cp-v-estrela-da-amadora-liga-portugal-betclic.jpg?s=1024x1024&w=gi&k=20&c=IR8Y_3Uv4ncQXLjbpeV8lmrMbfG6L-YqLXQVZ-UQZIA=) <small>www.gettyimages.com</small>Nani of CF Estrela da Amadora fights for the ball with Geovany Quenda... News Photo - Getty Images

Lisbon, Portugal . 29th Mar, 2025. Amadora, Portugal, March 29th, 2025: Flares In The Pitch
-------------------------------------------------------------------------------------------

 ![Lisbon, Portugal . 29th Mar, 2025. Amadora, Portugal, March 29th, 2025: Flares in the pitch](https://c8.alamy.com/comp/3A91N3W/lisbon-portugal-29th-mar-2025-amadora-portugal-march-29th-2025-flares-in-the-pitch-during-the-liga-portugal-betclic-game-between-cf-estrela-da-amadora-vs-sporting-cp-estadio-jose-gomes-amadora-on-29th-march-2025-joo-bravo-spp-credit-spp-sport-press-photo-alamy-live-news-3A91N3W.jpg) <small>www.alamy.com</small>Lisbon, Portugal . 29th Mar, 2025. Amadora, Portugal, March 29th, 2025: Flares in the pitch ...

(G-d) Viktor Gyokeres Du Sporting CP Avec Francisco Reis Ferreira Ferro Du CF Estrela Da Amadora
------------------------------------------------------------------------------------------------

 ![(G-d) Viktor Gyokeres du Sporting CP avec Francisco Reis Ferreira Ferro du CF Estrela da Amadora](https://c8.alamy.com/compfr/2yf7wxk/g-d-viktor-gyokeres-du-sporting-cp-avec-francisco-reis-ferreira-ferro-du-cf-estrela-da-amadora-en-action-lors-du-match-entre-le-sporting-cp-et-le-cf-estrela-da-amadora-pour-la-liga-portugal-betclic-a-l-estadio-jose-alvalade-score-final-sporting-cp-5-1-cf-estrela-da-amadora-2yf7wxk.jpg) <small>www.alamyimages.fr</small>(G-d) Viktor Gyokeres du Sporting CP avec Francisco Reis Ferreira Ferro du CF Estrela da Amadora ...

Portugal. 01st Nov, 2024. Viktor Gyokeres Forward Of Sporting CP Penalty During The Liga
----------------------------------------------------------------------------------------

 ![Portugal. 01st Nov, 2024. Viktor Gyokeres forward of Sporting CP penalty during the Liga](https://c8.alamy.com/comp/2YEXE0J/portugal-01st-nov-2024-viktor-gyokeres-forward-of-sporting-cp-penalty-during-the-liga-portugal-betclic-match-between-sporting-cp-and-cf-estrela-amadora-at-estadio-jose-de-alvalade-on-november-01th-2024-in-lisbon-portugal-liga-portugal-betclic-sporting-cp-vs-cf-estrela-amadora-valter-gouveiaspp-credit-spp-sport-press-photo-alamy-live-news-2YEXE0J.jpg) <small>www.alamy.com</small>Portugal. 01st Nov, 2024. Viktor Gyokeres forward of Sporting CP penalty during the Liga ...

Bilhetes CF Estrela Da Amadora Vs Sporting CP – Liga Portugal 25/26 Betclic 29ª Jornada – Núcleo
------------------------------------------------------------------------------------------------

 ![Bilhetes CF Estrela da Amadora vs Sporting CP – Liga Portugal 25/26 Betclic 29ª jornada – Núcleo](https://www.solardonorte.org/wp-content/uploads/2026/04/produto-estrela-1536x847.png) <small>www.solardonorte.org</small>Bilhetes CF Estrela da Amadora vs Sporting CP – Liga Portugal 25/26 Betclic 29ª jornada – Núcleo ...

Hidemasa Morita Of Sporting CP With Nani Of CF Estrela Da Amadora In... News Photo - Getty Images
-------------------------------------------------------------------------------------------------

 ![Hidemasa Morita of Sporting CP with Nani of CF Estrela da Amadora in... News Photo - Getty Images](https://media.gettyimages.com/id/2181647834/photo/sporting-cp-v-cf-estrela-da-amadora-liga-portugal-betclic.jpg?s=1024x1024&w=gi&k=20&c=QGSy10ieLWcGgBoc-orBR2MOjqSb2M_V65jmnmV2bec=) <small>www.gettyimages.com</small>Hidemasa Morita of Sporting CP with Nani of CF Estrela da Amadora in... News Photo - Getty Images

estrela da amadora vs sporting cp. Lisboa, portugal. 01st nov, 2024. sporting cp fans seen during the match between sporting cp and .... Daniel braganca of sporting cp celebrates after scoring a goal during... news photo
