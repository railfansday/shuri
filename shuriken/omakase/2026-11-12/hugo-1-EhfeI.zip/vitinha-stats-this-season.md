---
title: "Vitinha Stats This Season - The next galactico? real madrid begin pursuit of psg&#039;s vitinha in bid to bring balance back to ..."
description: "Vitinha ea fc 26 ratings, prices &amp; cards"
date: "2026-08-27"
categories:
- "Uncategorized"
images:
- "https://game-assets.fut.gg/cdn-cgi/image/quality=85,format=auto,width=300/2025/futgg-player-item-card/25-67364117.891b077e2769af18c7c9be3acce4170f1f7685a0791acb6c98d5b590cd7215af.webp"
featuredImage: "https://pbs.twimg.com/media/HHln2j9WYAUr1P8.jpg"
featured_image: "https://cdn1.molineux.news/uploads/2/2025/04/vitinha-517x750.jpg"
image: "https://pbs.twimg.com/media/HHtmzbAXAAMuj0_.jpg"
---

If you are looking for Vitinha Stats And Performance: Complete Player Breakdown - Metro League you've came to the right web. We have 35 Pics about Vitinha Stats And Performance: Complete Player Breakdown - Metro League like Best in the world? Vitinha tops four major metrics against top midfielders in 2025/26 Champions, Tottenham star left Frank "raging" at PSG, he won't be playing against Fulham and also Tottenham star left Frank "raging" at PSG, he won't be playing against Fulham. Read more:

Vitinha Stats And Performance: Complete Player Breakdown - Metro League
-----------------------------------------------------------------------

 ![Vitinha Stats And Performance: Complete Player Breakdown - Metro League](https://www.metroleague.org/wp-content/uploads/2026/06/Vitinha-Stats-And-Performance.jpg) <small>www.metroleague.org</small>Vitinha Stats And Performance: Complete Player Breakdown - Metro League

The Next Galactico? Real Madrid Begin Pursuit Of PSG's Vitinha In Bid To Bring Balance Back To
----------------------------------------------------------------------------------------------

 ![The next Galactico? Real Madrid begin pursuit of PSG's Vitinha in bid to bring balance back to](https://assets.goal.com/images/v3/blt4840a76194cf2250/Vitinha.jpeg?auto=webp&format=pjpg&width=3840&quality=60) <small>www.goal.com</small>The next Galactico? Real Madrid begin pursuit of PSG's Vitinha in bid to bring balance back to ...

Vitinha Stats: Goals, Assists &amp; Passing Data | Squawka
----------------------------------------------------------

 ![Vitinha Stats: Goals, Assists & Passing Data | Squawka](https://media.squawka.com/images/sites/13/2026/06/18134618/ChatGPT-Image-Jun-18-2026-at-06_45_44-PM.jpg) <small>www.squawka.com</small>Vitinha Stats: Goals, Assists &amp; Passing Data | Squawka

Vitinha EA FC 26 Ratings, Prices, And Cards - FUT.GG
----------------------------------------------------

 ![Vitinha EA FC 26 Ratings, Prices, and Cards - FUT.GG](https://game-assets.fut.gg/cdn-cgi/image/quality=100,format=auto/2025/player-item-social-small/25-255253.b9f7895fabd283f72589e387c1694ee0873fef7e3e318b6e6ac0d5e91ff80378.webp) <small>www.fut.gg</small>Vitinha EA FC 26 Ratings, Prices, and Cards - FUT.GG

Vitinha Ya Tiene Su Balón... Aunque No Sea De Oro: "No Pensaba Que Sería Capaz"
-------------------------------------------------------------------------------

 ![Vitinha ya tiene su balón... aunque no sea de Oro: "No pensaba que sería capaz"](https://objetos-xlk.estaticos-marca.com/uploads/2025/11/27/692819ae18286.png) <small>www.marca.com</small>Vitinha ya tiene su balón... aunque no sea de Oro: "No pensaba que sería capaz"

Vitinha EA FC 26 Ratings, Prices &amp; Cards - FUT.GG
-----------------------------------------------------

 ![Vitinha EA FC 26 Ratings, Prices & Cards - FUT.GG](https://game-assets.fut.gg/cdn-cgi/image/quality=85,format=auto,width=300/2025/futgg-player-item-card/25-100918549.a7dc253b0ea22db0d83ed5d4c7050d3c994c362e0f4b8385b8bfa15122d7ac4c.webp) <small>www.fut.gg</small>Vitinha EA FC 26 Ratings, Prices &amp; Cards - FUT.GG

Is Vitinha PSG’s Best Player? - The Athletic
--------------------------------------------

 ![Is Vitinha PSG’s best player? - The Athletic](https://static01.nyt.com/athletic/uploads/wp/2025/04/09083552/Vitinha-1024x683.jpg?width=1920&quality=70&auto=webp) <small>www.nytimes.com</small>Is Vitinha PSG’s best player? - The Athletic

Enzo Fernández Vs Vitinha — Stats This Season: Chelsea Vs PSG #football #short #viral #
---------------------------------------------------------------------------------------

 ![Enzo Fernández vs Vitinha — Stats this season: Chelsea vs PSG #football #short #viral #](https://i.ytimg.com/vi/KarQZhUcy3k/oardefault.jpg?sqp=-oaymwEkCJUDENAFSFqQAgHyq4qpAxMIARUAAAAAJQAAyEI9AICiQ3gB&rs=AOn4CLDm-_Ly7MpmgMp_mk9JU2kg2mcFxA&usqp=CCk) <small>www.youtube.com</small>Enzo Fernández vs Vitinha — Stats this season: Chelsea vs PSG #football #short #viral # ...

The Key Stats Ahead Of Bayern And PSG's Mammoth Champions League Clash | Flashscore.co.uk
-----------------------------------------------------------------------------------------

 ![The key stats ahead of Bayern and PSG's mammoth Champions League clash | Flashscore.co.uk](https://livesport-ott-images.ssl.cdn.cra.cz/r900xfq60/4e00a23c-2d8c-4bb2-ae82-d335cf032fc6.jpg) <small>www.flashscore.co.uk</small>The key stats ahead of Bayern and PSG's mammoth Champions League clash | Flashscore.co.uk

Vitinha Leads PSG Players With Most Matches Played In 2025 Season - Magic Paname
--------------------------------------------------------------------------------

 ![Vitinha Leads PSG Players with Most Matches Played in 2025 Season - Magic Paname](https://magicpaname.com/wp-content/uploads/2026/01/vitinha-leads-psg-players-with-most-matches-played-in-2025-1024x576.jpg) <small>magicpaname.com</small>Vitinha Leads PSG Players with Most Matches Played in 2025 Season - Magic Paname

Yamal, Vitinha, Neuer 🔥 Matchday Stats Under The Microscope 🔬 @FedExEurope | #FedExPerformanceZone
--------------------------------------------------------------------------------------------------

 ![Yamal, Vitinha, Neuer 🔥 Matchday stats under the microscope 🔬 @FedExEurope | #FedExPerformanceZone](https://pbs.twimg.com/media/HFjdkdebkAAgdJJ.jpg) <small>x.com</small>Yamal, Vitinha, Neuer 🔥 Matchday stats under the microscope 🔬 @FedExEurope | #FedExPerformanceZone

Vitinha Already Has BETTER Stats This Season Than In All Of Last Season… 🤯🔥 - YouTube
-------------------------------------------------------------------------------------

 ![Vitinha already has BETTER stats this season than in all of last season… 🤯🔥 - YouTube](https://i.ytimg.com/vi/6Sn5-vtME6k/oar2.jpg?sqp=-oaymwEkCJUDENAFSFqQAgHyq4qpAxMIARUAAAAAJQAAyEI9AICiQ3gB&rs=AOn4CLD-ms-HBTmvXkW1YKGMT8v1hRlEJw) <small>www.youtube.com</small>Vitinha already has BETTER stats this season than in all of last season… 🤯🔥 - YouTube

How PSG Backed Vitinha Over Messi And Neymar To Become World's Best | Transfermarkt
-----------------------------------------------------------------------------------

 ![How PSG backed Vitinha over Messi and Neymar to become world's best | Transfermarkt](https://tmssl.akamaized.net/images/foto/newsansicht/vit-stats-1746614261-167352.png?lm=1746614267) <small>www.transfermarkt.co.uk</small>How PSG backed Vitinha over Messi and Neymar to become world's best | Transfermarkt

📊 Pedri 🆚 Vitinha - Club Stats This Season: 🇪🇸 Pedri: 👕 40 Games ⚽️ 2 Goals 🎯 11 Assists 😳 76
---------------------------------------------------------------------------------------------

 ![📊 Pedri 🆚 Vitinha - Club Stats This Season: 🇪🇸 Pedri: 👕 40 games ⚽️ 2 goals 🎯 11 assists 😳 76](https://pbs.twimg.com/media/HHtmzbAXAAMuj0_.jpg) <small>x.com</small>📊 Pedri 🆚 Vitinha - Club Stats This Season: 🇪🇸 Pedri: 👕 40 games ⚽️ 2 goals 🎯 11 assists 😳 76 ...

🚨🔵 LIGUE 1 TEAM OF THE SEASON OFFICIAL STATS 🌟🏆 Vitinha Leads With 97 👀 Dembele Only 95 🤐 Thoughts?
---------------------------------------------------------------------------------------------------

 ![🚨🔵 LIGUE 1 TEAM OF THE SEASON OFFICIAL STATS 🌟🏆 Vitinha leads with 97 👀 Dembele only 95 🤐 Thoughts?](https://pbs.twimg.com/media/HHln2j9WYAUr1P8.jpg) <small>x.com</small>🚨🔵 LIGUE 1 TEAM OF THE SEASON OFFICIAL STATS 🌟🏆 Vitinha leads with 97 👀 Dembele only 95 🤐 Thoughts?

Vitinha Biography, Age, Height, PSG Career, Stats &amp; Net Worth
-----------------------------------------------------------------

 ![Vitinha Biography, Age, Height, PSG Career, Stats & Net Worth](https://playersbiography.com/wp-content/uploads/2026/06/Vitinha.png) <small>playersbiography.com</small>Vitinha Biography, Age, Height, PSG Career, Stats &amp; Net Worth

Vitinha Analysis: PSG Midfield Metronome’s Availability Key In Champions League Showdown With
---------------------------------------------------------------------------------------------

 ![Vitinha analysis: PSG midfield metronome’s availability key in Champions League showdown with](https://media.squawka.com/images/2026/04/27103623/player_-pitch-3-stats-2-1-819x1024.jpg) <small>www.squawka.com</small>Vitinha analysis: PSG midfield metronome’s availability key in Champions League showdown with ...

FREE Vitinha Progression Guide! Max Stats Build In EFootball #vitinha #psg #portugal #
--------------------------------------------------------------------------------------

 ![FREE Vitinha Progression Guide! Max Stats Build in eFootball #vitinha #psg #portugal #](https://i.ytimg.com/vi/BkQKuv653NE/oar2.jpg?sqp=-oaymwEkCJUDENAFSFqQAgHyq4qpAxMIARUAAAAAJQAAyEI9AICiQ3gB&rs=AOn4CLAnPQUlnPxyACFXxS4sgd9Y5_zXng&usqp=CCk) <small>www.youtube.com</small>FREE Vitinha Progression Guide! Max Stats Build in eFootball #vitinha #psg #portugal # ...

KlipDraw | ¿Quién Es Vitinha, El Nuevo Jugador Del PSG?
-------------------------------------------------------

 ![KlipDraw | ¿Quién es Vitinha, el nuevo jugador del PSG?](https://www.klipdraw.com/blog/laravel-filemanager/photos/shares/2022/Vitinha PSG/Vitinha_Stats.PNG) <small>www.klipdraw.com</small>KlipDraw | ¿Quién es Vitinha, el nuevo jugador del PSG?

Vitinha Has Broken The Record For The Most Passes Ever Completed In A Single UEFA Champions
-------------------------------------------------------------------------------------------

 ![Vitinha has broken the record for the most passes ever completed in a single UEFA Champions](https://pbs.twimg.com/media/HHujTHGXYAAPegP.jpg) <small>x.com</small>Vitinha has broken the record for the most passes ever completed in a single UEFA Champions ...

Vitinha - Goal Stats For 2025/2026 - Champions League, Total Goals In All Competitions, Match
---------------------------------------------------------------------------------------------

 ![Vitinha - Goal Stats for 2025/2026 - Champions League, Total Goals in All Competitions, Match](https://pictures.tribuna.com/image/23180562-0ad0-4056-ac79-75d29bfe30dc?width=1920&quality=70) <small>tribuna.com</small>Vitinha - Goal Stats for 2025/2026 - Champions League, Total Goals in All Competitions, Match ...

PSG - Le Regard Très Lucide De Vitinha Sur Le Début De Saison Du PSG
--------------------------------------------------------------------

 ![PSG - Le regard très lucide de Vitinha sur le début de saison du PSG](https://photos.madeinparisiens.com/ligue-des-champions/2025/zoom/ldc-20251127082832-7302.jpg) <small>madeinparisiens.ouest-france.fr</small>PSG - Le regard très lucide de Vitinha sur le début de saison du PSG

The Best Central Midfielders With High Potential In EA Sports FC 25: Career Mode
--------------------------------------------------------------------------------

 ![The Best Central Midfielders With High Potential In EA Sports FC 25: Career Mode](https://static1.thegamerimages.com/wordpress/wp-content/uploads/2024/10/vitinha-and-his-stats-in-ea-fc25.jpg) <small>www.thegamer.com</small>The Best Central Midfielders With High Potential In EA Sports FC 25: Career Mode

Vitinha 2024 - Crazy Skills, Assists &amp; Goals - PSG | HD - YouTube
---------------------------------------------------------------------

 ![Vitinha 2024 - Crazy Skills, Assists & Goals - PSG | HD - YouTube](https://i.ytimg.com/vi/Jk7MfO3_ADQ/maxresdefault.jpg) <small>www.youtube.com</small>Vitinha 2024 - Crazy Skills, Assists &amp; Goals - PSG | HD - YouTube

Vitinha Stats 2024/2025 Season: How Many Goals, Assists And Appearances
-----------------------------------------------------------------------

 ![Vitinha Stats 2024/2025 Season: How many goals, assists and appearances](https://pictures.tribuna.com/image/8e407214-8d9f-4fdf-8190-a4e34ad00f7b?width=1920&quality=70) <small>tribuna.com</small>Vitinha Stats 2024/2025 Season: How many goals, assists and appearances

Vitinha Footballer Career Stats
-------------------------------

 ![Vitinha Footballer Career Stats](https://lookaside.instagram.com/seo/google_widget/crawler/?media_id=3771596063749449771) <small>www.instagram.com</small>Vitinha Footballer Career Stats

Tottenham Star Left Frank "raging" At PSG, He Won't Be Playing Against Fulham
-----------------------------------------------------------------------------

 ![Tottenham star left Frank "raging" at PSG, he won't be playing against Fulham](https://static0.footballfancastimages.com/wordpress/wp-content/uploads/2025/11/vitinha-vs-spurs-stats.jpg?q=49&fit=crop&w=825&dpr=2) <small>www.footballfancast.com</small>Tottenham star left Frank "raging" at PSG, he won't be playing against Fulham

FlashFocus: Little Maestro Vitinha Reaching New Levels With PSG | Flashscore.co.uk
----------------------------------------------------------------------------------

 ![FlashFocus: Little maestro Vitinha reaching new levels with PSG | Flashscore.co.uk](https://livesport-ott-images.ssl.cdn.cra.cz/r900xfq60/b62aca49-901d-4cae-8693-98245edd49d9.jpg) <small>www.flashscore.co.uk</small>FlashFocus: Little maestro Vitinha reaching new levels with PSG | Flashscore.co.uk

Best In The World? Vitinha Tops Four Major Metrics Against Top Midfielders In 2025/26 Champions
-----------------------------------------------------------------------------------------------

 ![Best in the world? Vitinha tops four major metrics against top midfielders in 2025/26 Champions](https://pictures.tribuna.com/image/cec6ec05-b9db-482d-86b2-a15d4a365640?width=1920&quality=70) <small>tribuna.com</small>Best in the world? Vitinha tops four major metrics against top midfielders in 2025/26 Champions ...

Prince William 'really Impressed' By Champions League Star Since He Left Wolves In 2021
---------------------------------------------------------------------------------------

 ![Prince William 'really impressed' by Champions League star since he left Wolves in 2021](https://cdn1.molineux.news/uploads/2/2025/04/vitinha-1-875x1024.jpg) <small>www.molineux.news</small>Prince William 'really impressed' by Champions League star since he left Wolves in 2021

VITINHA UCL ️ UTOTS 📊 Max Out Stats 🔥
-------------------------------------

 ![VITINHA UCL ️ UTOTS 📊 Max out stats 🔥](https://pbs.twimg.com/media/HJ5o5k7a4AAVVdg.jpg) <small>x.com</small>VITINHA UCL ️ UTOTS 📊 Max out stats 🔥

Vitinha EA FC 26 Ratings, Prices &amp; Cards - FUT.GG
-----------------------------------------------------

 ![Vitinha EA FC 26 Ratings, Prices & Cards - FUT.GG](https://game-assets.fut.gg/cdn-cgi/image/quality=85,format=auto,width=300/2025/futgg-player-item-card/25-117695765.7a9a3ff9990684f8ea73b5d7ff606adbdb6d8afc6ebd5d37e9b8e097a83ae031.webp) <small>www.fut.gg</small>Vitinha EA FC 26 Ratings, Prices &amp; Cards - FUT.GG

Wolves Fans’ Response To Vitinha Hat-trick Sums Everything Up Perfectly
-----------------------------------------------------------------------

 ![Wolves fans’ response to Vitinha hat-trick sums everything up perfectly](https://cdn1.molineux.news/uploads/2/2025/04/vitinha-517x750.jpg) <small>www.molineux.news</small>Wolves fans’ response to Vitinha hat-trick sums everything up perfectly

Champions League Team Of The Round: Mbappe Scores Four, Vitinha Hits Hat-trick | Flashscore.co.uk
-------------------------------------------------------------------------------------------------

 ![Champions League Team of the Round: Mbappe scores four, Vitinha hits hat-trick | Flashscore.co.uk](https://livesport-ott-images.ssl.cdn.cra.cz/r900xfq60/b787e292-0558-4f11-86ae-860f9e3a8726.jpg) <small>www.flashscore.co.uk</small>Champions League Team of the Round: Mbappe scores four, Vitinha hits hat-trick | Flashscore.co.uk

Vitinha EA FC 26 Ratings, Prices &amp; Cards - FUT.GG
-----------------------------------------------------

 ![Vitinha EA FC 26 Ratings, Prices & Cards - FUT.GG](https://game-assets.fut.gg/cdn-cgi/image/quality=85,format=auto,width=300/2025/futgg-player-item-card/25-67364117.891b077e2769af18c7c9be3acce4170f1f7685a0791acb6c98d5b590cd7215af.webp) <small>www.fut.gg</small>Vitinha EA FC 26 Ratings, Prices &amp; Cards - FUT.GG

The next galactico? real madrid begin pursuit of psg's vitinha in bid to bring balance back to. Yamal, vitinha, neuer 🔥 matchday stats under the microscope 🔬 @fedexeurope. Prince william 'really impressed' by champions league star since he left wolves in 2021
