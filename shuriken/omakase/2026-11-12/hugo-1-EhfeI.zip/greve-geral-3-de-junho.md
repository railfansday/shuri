---
title: "Greve Geral 3 De Junho - A greve geral de 3 de junho é para todos os trabalhadores"
description: "Aviso prévio de greve geral 3 junho 2026 – stts"
date: "2026-11-08"
categories:
- "Uncategorized"
images:
- "https://staticx.noticiasilimitadas.pt/jn/image.webp?brand=jn&amp;type=generate&amp;guid=7ff89168-6db6-48c6-a848-7f6391614ee9&amp;w=3840"
featuredImage: "https://www.fenprof.pt/media/download/6FDA79F0A62C1CB1E79A4D96032CBC0A/foto-greve-na-rua.jpg"
featured_image: "https://www.cgtp.pt/images/images/2026/06/resolucao_grevegeral.jpg"
image: "https://www.cgtp.pt/images/accao-e-luta/2026/05/greve-geral-funcao-publica.jpg"
---

If you are searching about CGTP convoca greve geral para 3 de junho e UGT só decide novas formas de luta após última you've visit to the right page. We have 35 Pics about CGTP convoca greve geral para 3 de junho e UGT só decide novas formas de luta após última like Greve Geral – dia 3 de junho - SPRA, FNSTFPS já emitiu Aviso Prévio para a Greve Geral de 3 de Junho! - CGTP-IN and also 3 JUNHO | GREVE GERAL CONTRA O PACOTE LABORAL - Sindicato dos Trabalhadores do Comércio. Here it is:

CGTP Convoca Greve Geral Para 3 De Junho E UGT Só Decide Novas Formas De Luta Após última
-----------------------------------------------------------------------------------------

 ![CGTP convoca greve geral para 3 de junho e UGT só decide novas formas de luta após última](https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA229grU.img?w=768&h=422&m=6) <small>www.msn.com</small>CGTP convoca greve geral para 3 de junho e UGT só decide novas formas de luta após última ...

Greve Geral – Dia 3 De Junho - SPRA
-----------------------------------

 ![Greve Geral – dia 3 de junho - SPRA](https://www.spra.pt/wp-content/uploads/2026/05/Greve_Acores-768x1024.jpg) <small>www.spra.pt</small>Greve Geral – dia 3 de junho - SPRA

CGTP Convoca Greve Geral Para 3 De Junho, UGT Não Exclui
--------------------------------------------------------

 ![CGTP convoca greve geral para 3 de junho, UGT não exclui](https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA229tFU.img?w=1440&h=960&m=4&q=84) <small>www.msn.com</small>CGTP convoca greve geral para 3 de junho, UGT não exclui

AVISO PRÉVIO DE GREVE GERAL 3 JUNHO 2026 – STTS
-----------------------------------------------

 ![AVISO PRÉVIO DE GREVE GERAL 3 JUNHO 2026 – STTS](https://www.stts.pt/wp-content/uploads/2026/05/123654.jpg) <small>www.stts.pt</small>AVISO PRÉVIO DE GREVE GERAL 3 JUNHO 2026 – STTS

Greve Geral De 3 De Junho: O Que Está Em Causa, Quem Pode Aderir E Que Impacto Se Prevê
---------------------------------------------------------------------------------------

 ![Greve Geral de 3 de junho: o que está em causa, quem pode aderir e que impacto se prevê](https://sabiasque.pt/images/stories/2026/trabalho/20260602-greve-geral-3-junho-1024x683.jpg) <small>sabiasque.pt</small>Greve Geral de 3 de junho: o que está em causa, quem pode aderir e que impacto se prevê

GREVE GERAL - 3 JUNHO 2026 | Resolução - CGTP-IN
------------------------------------------------

 ![GREVE GERAL - 3 JUNHO 2026 | Resolução - CGTP-IN](https://www.cgtp.pt/images/images/2026/06/tiago-greve-geral.jpg) <small>www.cgtp.pt</small>GREVE GERAL - 3 JUNHO 2026 | Resolução - CGTP-IN

3 JUNHO | GREVE GERAL CONTRA O PACOTE LABORAL - Sindicato Dos Trabalhadores Do Comércio
---------------------------------------------------------------------------------------

 ![3 JUNHO | GREVE GERAL CONTRA O PACOTE LABORAL - Sindicato dos Trabalhadores do Comércio](https://image.jimcdn.com/app/cms/image/transf/dimension=origxorig:format=jpg/path/s3820655f8d987127/image/i5e5b75974b65d8a9/version/1779378127/image.jpg) <small>www.cesp.pt</small>3 JUNHO | GREVE GERAL CONTRA O PACOTE LABORAL - Sindicato dos Trabalhadores do Comércio ...

CGTP Avança Com Greve Geral Para 3 De Junho
-------------------------------------------

 ![CGTP avança com greve geral para 3 de junho](https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA229Sqw.img?w=1200&h=800&m=4&q=70) <small>www.msn.com</small>CGTP avança com greve geral para 3 de junho

Greve Geral é Para Todos Os Trabalhadores! – Escola Portuguesa
--------------------------------------------------------------

 ![Greve Geral é para todos os trabalhadores! – Escola Portuguesa](https://escolapt.wordpress.com/wp-content/uploads/2026/05/706357188_18081656384561625_6623516586727525352_n.jpg) <small>escolapt.wordpress.com</small>Greve Geral é para todos os trabalhadores! – Escola Portuguesa

Greve Geral – Derrotar O Pacote Laboral – 3 De Junho 2026 – SINTTAV Sindicato Nacional Dos
------------------------------------------------------------------------------------------

 ![Greve Geral – Derrotar o Pacote Laboral – 3 de Junho 2026 – SINTTAV Sindicato Nacional dos](https://sinttav.pt/wp-content/uploads/2026/05/Cartaz_Greve-Geral-Derrotar-o-Pacote-Laboral-3-de-Junho-2026.jpg) <small>sinttav.pt</small>Greve Geral – Derrotar o Pacote Laboral – 3 de Junho 2026 – SINTTAV Sindicato Nacional dos ...

Greve Geral Em Lisboa A 3 De Junho: O Que Pára Na Cidade
--------------------------------------------------------

 ![Greve geral em Lisboa a 3 de Junho: o que pára na cidade](https://media.timeout.com/images/106411166/image.jpg) <small>www.timeout.pt</small>Greve geral em Lisboa a 3 de Junho: o que pára na cidade

3 De Junho: Dia Nacional De Luta Pela Retomada De Negociações Com Educação Federal Em Greve
-------------------------------------------------------------------------------------------

 ![3 de junho: Dia Nacional de Luta pela retomada de negociações com Educação Federal em greve](https://www.andes.org.br/img/midias/1a208cc2305a3c74c97903345cc44643_1717025565.png) <small>www.andes.org.br</small>3 de junho: Dia Nacional de Luta pela retomada de negociações com Educação Federal em greve

Greve Geral De 24 Horas No Dia 3 De Junho- Serviço De Transporte Afetado
------------------------------------------------------------------------

 ![Greve geral de 24 horas no dia 3 de junho- Serviço de transporte afetado](https://www.metrolisboa.pt/institucional/wp-content/uploads/sites/2/2026/06/greve-3-junho_1080x450.png) <small>www.metrolisboa.pt</small>Greve geral de 24 horas no dia 3 de junho- Serviço de transporte afetado

GREVE GERAL 3 JUNHO | Concentrações/Manifestações
-------------------------------------------------

 ![GREVE GERAL 3 JUNHO | Concentrações/Manifestações](https://www.stal.pt/images/2026/CONCENTRACOES-GG_Site.jpg#joomlaImage:/local-images/2026/CONCENTRACOES-GG_Site.jpg?width=1080&height=720) <small>www.stal.pt</small>GREVE GERAL 3 JUNHO | Concentrações/Manifestações

FNSTFPS Já Emitiu Aviso Prévio Para A Greve Geral De 3 De Junho! - CGTP-IN
--------------------------------------------------------------------------

 ![FNSTFPS já emitiu Aviso Prévio para a Greve Geral de 3 de Junho! - CGTP-IN](https://www.cgtp.pt/images/accao-e-luta/2026/05/greve-geral-funcao-publica.jpg) <small>www.cgtp.pt</small>FNSTFPS já emitiu Aviso Prévio para a Greve Geral de 3 de Junho! - CGTP-IN

3 JUNHO | GREVE GERAL CONTRA O PACOTE LABORAL - Sindicato Dos Trabalhadores Do Comércio
---------------------------------------------------------------------------------------

 ![3 JUNHO | GREVE GERAL CONTRA O PACOTE LABORAL - Sindicato dos Trabalhadores do Comércio](https://image.jimcdn.com/app/cms/image/transf/dimension=4000x3000:format=jpg/path/s3820655f8d987127/image/i4ba186dc42d4f07e/version/1778075119/3-junho-greve-geral-contra-o-pacote-laboral.jpg) <small>www.cesp.pt</small>3 JUNHO | GREVE GERAL CONTRA O PACOTE LABORAL - Sindicato dos Trabalhadores do Comércio ...

Greve Geral - 03 De Junho De 2026
---------------------------------

 ![Greve Geral - 03 de junho de 2026](https://cabeceirasdebasto.pt/files/46/46246.jpg) <small>cabeceirasdebasto.pt</small>Greve Geral - 03 de junho de 2026

Greve Geral - 3 De Junho De 2026 | Concentrações - CGTP-IN
----------------------------------------------------------

 ![Greve Geral - 3 de Junho de 2026 | Concentrações - CGTP-IN](https://www.cgtp.pt/images/images/2026/05/CONCENTRACOES-GG.jpg) <small>www.cgtp.pt</small>Greve Geral - 3 de Junho de 2026 | Concentrações - CGTP-IN

Greve Geral Em Setúbal Anunciada Para 3 De Junho
------------------------------------------------

 ![Greve Geral em Setúbal Anunciada para 3 de Junho](https://diariodistrito.sapo.pt/wp-content/uploads/2025/11/Captura-de-ecra-2025-11-07-as-23.38.24-780x470.png) <small>diariodistrito.sapo.pt</small>Greve Geral em Setúbal Anunciada para 3 de Junho

CGTP Anuncia No Dia Do Trabalhador Nova Greve Geral No Dia 3 De Junho
---------------------------------------------------------------------

 ![CGTP anuncia no Dia do Trabalhador nova greve geral no dia 3 de junho](https://staticx.noticiasilimitadas.pt/jn/image.webp?brand=jn&type=generate&guid=7ff89168-6db6-48c6-a848-7f6391614ee9&w=3840) <small>www.jn.pt</small>CGTP anuncia no Dia do Trabalhador nova greve geral no dia 3 de junho

Greve Geral Ameaça Parar Parte Do País: 10 Perguntas E Respostas Sobre A Paralisação De 3 De Junho
--------------------------------------------------------------------------------------------------

 ![Greve geral ameaça parar parte do país: 10 perguntas e respostas sobre a paralisação de 3 de junho](https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA24x1vf.img?w=1200&h=800&m=4&q=70) <small>www.msn.com</small>Greve geral ameaça parar parte do país: 10 perguntas e respostas sobre a paralisação de 3 de junho

CGTP Convoca Greve Geral Para Dia 3 De Junho E UGT Poderá Aderir
----------------------------------------------------------------

 ![CGTP convoca greve geral para dia 3 de junho e UGT poderá aderir](https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA22c4u7.img?w=1024&h=576&m=4&q=81) <small>www.msn.com</small>CGTP convoca greve geral para dia 3 de junho e UGT poderá aderir

O Que Vai Parar Com A Greve Geral De 3 De Junho? - Portugal - SÁBADO
--------------------------------------------------------------------

 ![O que vai parar com a greve geral de 3 de junho? - Portugal - SÁBADO](https://cdn.sabado.pt/images/2026-05/img_640x426uu2026-05-21-18-26-04-766232.jpg) <small>www.sabado.pt</small>O que vai parar com a greve geral de 3 de junho? - Portugal - SÁBADO

SNTCT Entrega Pré-avisos De Greve Geral De 3 Junho - CGTP-IN
------------------------------------------------------------

 ![SNTCT entrega pré-avisos de Greve Geral de 3 Junho - CGTP-IN](https://www.cgtp.pt/images/accao-e-luta/2025/sntct1.jpg) <small>www.cgtp.pt</small>SNTCT entrega pré-avisos de Greve Geral de 3 Junho - CGTP-IN

GREVE GERAL | 3 JUNHO - SINAPSA
-------------------------------

 ![GREVE GERAL | 3 JUNHO - SINAPSA](https://sinapsa.pt/wp-content/uploads/2026/06/INFO49-scaled.jpg) <small>sinapsa.pt</small>GREVE GERAL | 3 JUNHO - SINAPSA

Professores Deram Uma Forte Expressão à Greve Geral De 3 De Junho - FENPROF
---------------------------------------------------------------------------

 ![Professores deram uma forte expressão à Greve Geral de 3 de junho - FENPROF](https://www.fenprof.pt/media/download/6FDA79F0A62C1CB1E79A4D96032CBC0A/foto-greve-na-rua.jpg) <small>www.fenprof.pt</small>Professores deram uma forte expressão à Greve Geral de 3 de junho - FENPROF

Greve Geral De 3 De Junho Paralisa Transportes E Aeroportos Em Todo O País - SIC Notícias
-----------------------------------------------------------------------------------------

 ![Greve geral de 3 de junho paralisa transportes e aeroportos em todo o país - SIC Notícias](https://images.impresa.pt/sicnot/2025-11-11-greve-geral-f7feb127-1/1.91x1?wm=true&outputFormat=jpeg) <small>sicnoticias.pt</small>Greve geral de 3 de junho paralisa transportes e aeroportos em todo o país - SIC Notícias

SPN - Greve Geral Com Forte Expressão Nos Professores (3/jun)
-------------------------------------------------------------

 ![SPN - Greve Geral com forte expressão nos professores (3/jun)](https://www.spn.pt/Media/Default/Info/71000/800/10/5/Fenprof — Greve Geral.jpg) <small>www.spn.pt</small>SPN - Greve Geral com forte expressão nos professores (3/jun)

GREVE GERAL - 3 JUNHO 2026 | Resolução - CGTP-IN
------------------------------------------------

 ![GREVE GERAL - 3 JUNHO 2026 | Resolução - CGTP-IN](https://www.cgtp.pt/images/images/2026/06/resolucao_grevegeral.jpg) <small>www.cgtp.pt</small>GREVE GERAL - 3 JUNHO 2026 | Resolução - CGTP-IN

A Greve Geral De 3 De Junho é Para Todos Os Trabalhadores
---------------------------------------------------------

 ![A greve geral de 3 de junho é para todos os trabalhadores](https://www.sep.org.pt/files/uploads/2026/05/SEP_03_JUNHO-04.jpg) <small>www.sep.org.pt</small>A greve geral de 3 de junho é para todos os trabalhadores

CGTP Confirma: Nova Greve Geral Convocada Para 3 De Junho
---------------------------------------------------------

 ![CGTP confirma: nova greve geral convocada para 3 de junho](https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA229tnW.img?w=1280&h=853&m=4&q=75) <small>www.msn.com</small>CGTP confirma: nova greve geral convocada para 3 de junho

AVISO PRÉVIO DE GREVE GERAL 3 JUNHO 2026 – STTS
-----------------------------------------------

 ![AVISO PRÉVIO DE GREVE GERAL 3 JUNHO 2026 – STTS](https://www.stts.pt/wp-content/uploads/2026/05/Imagem1-210x136.png) <small>www.stts.pt</small>AVISO PRÉVIO DE GREVE GERAL 3 JUNHO 2026 – STTS

NOTA INFORMATIVA Nº17/2026 - GREVE GERAL | 3 DE JUNHO DE 2026 - STI - Sindicato Dos
-----------------------------------------------------------------------------------

 ![NOTA INFORMATIVA Nº17/2026 - GREVE GERAL | 3 DE JUNHO DE 2026 - STI - Sindicato dos](https://stimpostos.pt/wp-content/uploads/2026/05/notas-informativas-2024-27.jpg) <small>stimpostos.pt</small>NOTA INFORMATIVA Nº17/2026 - GREVE GERAL | 3 DE JUNHO DE 2026 - STI - Sindicato dos ...

CGTP Convoca Greve Geral Para 3 De Junho
----------------------------------------

 ![CGTP convoca greve geral para 3 de junho](https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA229ere.img?w=1920&h=1080&m=4&q=75) <small>www.msn.com</small>CGTP convoca greve geral para 3 de junho

"Estamos Há Nove Meses A Discutir O Pacote Laboral E Nada Mudou." CGTP Convoca Greve Geral Para
-----------------------------------------------------------------------------------------------

 !["Estamos há nove meses a discutir o pacote laboral e nada mudou." CGTP convoca greve geral para](https://staticx.noticiasilimitadas.pt/tsf/image.webp?brand=tsf&type=generate&guid=a9823cf8-2279-4119-9c62-ec9effb0d646&w=3840) <small>www.tsf.pt</small>"Estamos há nove meses a discutir o pacote laboral e nada mudou." CGTP convoca greve geral para ...

Greve geral de 3 de junho paralisa transportes e aeroportos em todo o país. greve geral 3 junho. A greve geral de 3 de junho é para todos os trabalhadores
