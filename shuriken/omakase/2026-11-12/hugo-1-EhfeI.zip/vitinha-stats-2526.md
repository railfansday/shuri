---
title: "Vitinha Stats 25/26 - Vitinha ea fc 26 ratings, prices &amp; cards"
description: "Pedri vs vitinha — club stats (2024/25): #pedri #vitinha"
date: "2026-08-13"
categories:
- "Uncategorized"
images:
- "https://static0.thegamerimages.com/wordpress/wp-content/uploads/2024/10/vitinha-and-his-stats-in-ea-fc25.jpg?q=70&amp;fit=crop&amp;w=825&amp;dpr=1"
featuredImage: "https://pictures.tribuna.com/image/cec6ec05-b9db-482d-86b2-a15d4a365640?width=1920&amp;quality=70"
featured_image: "https://pictures.tribuna.com/image/cec6ec05-b9db-482d-86b2-a15d4a365640?width=1920&amp;quality=70"
image: "https://game-assets.fut.gg/cdn-cgi/image/quality=85,format=auto,width=300/2025/futgg-player-item-card/25-100918549.a7dc253b0ea22db0d83ed5d4c7050d3c994c362e0f4b8385b8bfa15122d7ac4c.webp"
---

If you are looking for Pedri vs Vitinha — Club stats (2024/25): #pedri #vitinha - YouTube you've visit to the right web. We have 35 Pics about Pedri vs Vitinha — Club stats (2024/25): #pedri #vitinha - YouTube like Best in the world? Vitinha tops four major metrics against top midfielders in 2025/26 Champions, ¡ESTA EVOLUCIÓN ES INCREÍBLE! 🔥 94 VITINHA FC 25 INMORTALS REVIEW - YouTube and also The Best Central Midfielders With High Potential In EA Sports FC 25: Career Mode. Here it is:

Pedri Vs Vitinha — Club Stats (2024/25): #pedri #vitinha - YouTube
------------------------------------------------------------------

 ![Pedri vs Vitinha — Club stats (2024/25): #pedri #vitinha - YouTube](https://i.ytimg.com/vi/xyRSEI-WIP0/oar2.jpg?sqp=-oaymwEkCJUDENAFSFqQAgHyq4qpAxMIARUAAAAAJQAAyEI9AICiQ3gB&rs=AOn4CLBGAZYfip2VmjXg7Sj7TzUZP8y70w) <small>www.youtube.com</small>Pedri vs Vitinha — Club stats (2024/25): #pedri #vitinha - YouTube

Vitinha EA FC 26 Ratings, Prices, And Cards - FUT.GG
----------------------------------------------------

 ![Vitinha EA FC 26 Ratings, Prices, and Cards - FUT.GG](https://game-assets.fut.gg/cdn-cgi/image/quality=100,format=auto/2025/player-item-social-small/25-255253.b9f7895fabd283f72589e387c1694ee0873fef7e3e318b6e6ac0d5e91ff80378.webp) <small>www.fut.gg</small>Vitinha EA FC 26 Ratings, Prices, and Cards - FUT.GG

Official Cards Vitinha PSG 2025-26 Topps Flagship UEFA Club Competitions Cards
------------------------------------------------------------------------------

 ![Official Cards Vitinha PSG 2025-26 Topps Flagship UEFA Club Competitions Cards](https://www.euro-soccer-cards.com/177657-large_default/vitinha-psg-46-ucc-flagship-2025-26.jpg) <small>www.euro-soccer-cards.com</small>Official Cards Vitinha PSG 2025-26 Topps Flagship UEFA Club Competitions Cards

Tottenham Star Left Frank "raging" At PSG, He Won't Be Playing Against Fulham
-----------------------------------------------------------------------------

 ![Tottenham star left Frank "raging" at PSG, he won't be playing against Fulham](https://static0.footballfancastimages.com/wordpress/wp-content/uploads/2025/11/vitinha-vs-spurs-stats.jpg?q=49&fit=crop&w=825&dpr=2) <small>www.footballfancast.com</small>Tottenham star left Frank "raging" at PSG, he won't be playing against Fulham

Topps Match Attax 25/26 Vitinha Infinity IN 8 (Neu (gemäss Beschreibung)) In Zürich Für CHF 5.5
-----------------------------------------------------------------------------------------------

 ![Topps Match Attax 25/26 Vitinha Infinity IN 8 (Neu (gemäss Beschreibung)) in Zürich für CHF 5.5](https://img.ricardostatic.ch/images/d0c1427e-0637-4021-a9ae-23b72f8b86d5/t_1800x1350/topps-match-attax-2526-vitinha-infinity-in-8) <small>www.ricardo.ch</small>Topps Match Attax 25/26 Vitinha Infinity IN 8 (Neu (gemäss Beschreibung)) in Zürich für CHF 5.5 ...

Top 10 Center Midfielders In EA FC 26
-------------------------------------

 ![Top 10 Center Midfielders in EA FC 26](https://cdn.gameboost.com/cms-uploads/images/2025-09-23/9a155f55-cb1d-4981-bb31-3ac575c22952.webp) <small>gameboost.com</small>Top 10 Center Midfielders in EA FC 26

Vitinha EA FC 26 Ratings, Prices, And Cards - FUT.GG
----------------------------------------------------

 ![Vitinha EA FC 26 Ratings, Prices, and Cards - FUT.GG](https://game-assets.fut.gg/cdn-cgi/image/quality=85,format=auto,width=200/2025/futgg-player-item-card/25-134472981.a72edb45d49d5dd1a2f5186c26e601830fd6655a32947c5db8de1e25a6f9a3ae.webp) <small>www.fut.gg</small>Vitinha EA FC 26 Ratings, Prices, and Cards - FUT.GG

Vitinha EA FC 26 Ratings, Prices, And Cards - FUT.GG
----------------------------------------------------

 ![Vitinha EA FC 26 Ratings, Prices, and Cards - FUT.GG](https://game-assets.fut.gg/cdn-cgi/image/quality=85,format=auto,width=200/2026/futgg-player-item-card/26-84141333.ab7f8a9548dbeb079610188d4caf35d42c08746aa88f07a14b8d900aa21439c4.webp) <small>www.fut.gg</small>Vitinha EA FC 26 Ratings, Prices, and Cards - FUT.GG

Classic - 📊 Rodri’s Ballon D’Or Stats 🆚 Vitinha’s 2024/25 Stats: 🇵🇹 Vitinha: 👕 61 Games ⚽ 8
-------------------------------------------------------------------------------------------

 ![Classic - 📊 Rodri’s Ballon d’Or stats 🆚 Vitinha’s 2024/25 stats: 🇵🇹 Vitinha: 👕 61 games ⚽ 8](https://lookaside.fbsbx.com/lookaside/crawler/media/?media_id=122181668804315200) <small>www.facebook.com</small>Classic - 📊 Rodri’s Ballon d’Or stats 🆚 Vitinha’s 2024/25 stats: 🇵🇹 Vitinha: 👕 61 games ⚽ 8 ...

Vitinha EA FC 26 Ratings, Prices &amp; Cards - FUT.GG
-----------------------------------------------------

 ![Vitinha EA FC 26 Ratings, Prices & Cards - FUT.GG](https://game-assets.fut.gg/cdn-cgi/image/quality=85,format=auto,width=300/2025/futgg-player-item-card/25-50586901.1a4ddffdaa98b3247bb016a1f12ad9f608759fc4359b634331ce2151a4c98287.webp) <small>www.fut.gg</small>Vitinha EA FC 26 Ratings, Prices &amp; Cards - FUT.GG

Vitinha EA FC 26 Ratings, Prices &amp; Cards - FUT.GG
-----------------------------------------------------

 ![Vitinha EA FC 26 Ratings, Prices & Cards - FUT.GG](https://game-assets.fut.gg/cdn-cgi/image/quality=85,format=auto,width=300/2025/futgg-player-item-card/25-84141333.3cf7fe65ff9b4df59afb36cc7d4e3dd24b1e7b2dabd6bfe2da5574cf31808243.webp) <small>www.fut.gg</small>Vitinha EA FC 26 Ratings, Prices &amp; Cards - FUT.GG

Vitinha EA FC 25 Ratings, Prices, And Cards - FUT.GG
----------------------------------------------------

 ![Vitinha EA FC 25 Ratings, Prices, and Cards - FUT.GG](https://game-assets.fut.gg/2024/player-item-social-small/24-255253.e99298d9016bfa18924853d79768e244deb05b217b206c94933ceb80cce6abe8.webp?quality=100) <small>www.fut.gg</small>Vitinha EA FC 25 Ratings, Prices, and Cards - FUT.GG

FC 25: Is The Vitinha Footies SBC Worth It
------------------------------------------

 ![FC 25: Is the Vitinha Footies SBC Worth It](https://assets.mmoexp.com/images/202507/78b163661a429f0168d3b8d9728bda6c3596ce07.jpg) <small>www.mmoexp.com</small>FC 25: Is the Vitinha Footies SBC Worth It

Vitinha FC 26 Best Midfield Guide
---------------------------------

 ![Vitinha FC 26 Best Midfield Guide](https://www.u7buy.com/blog/wp-content/uploads/6a15b5f26ee91dba9b7a5031-4.png) <small>www.u7buy.com</small>Vitinha FC 26 Best Midfield Guide

Vitinha EA FC 26 Ratings, Prices &amp; Cards - FUT.GG
-----------------------------------------------------

 ![Vitinha EA FC 26 Ratings, Prices & Cards - FUT.GG](https://game-assets.fut.gg/cdn-cgi/image/quality=85,format=auto,width=300/2025/futgg-player-item-card/25-117695765.7a9a3ff9990684f8ea73b5d7ff606adbdb6d8afc6ebd5d37e9b8e097a83ae031.webp) <small>www.fut.gg</small>Vitinha EA FC 26 Ratings, Prices &amp; Cards - FUT.GG

Vitinha | Portugal | UEFA EURO 2024 | UEFA.com
----------------------------------------------

 ![Vitinha | Portugal | UEFA EURO 2024 | UEFA.com](https://img.uefa.com/imgml/TP/players/3/2024/cutoff/250101444.png) <small>www.uefa.com</small>Vitinha | Portugal | UEFA EURO 2024 | UEFA.com

The Best Central Midfielders With High Potential In EA Sports FC 25: Career Mode
--------------------------------------------------------------------------------

 ![The Best Central Midfielders With High Potential In EA Sports FC 25: Career Mode](https://static0.thegamerimages.com/wordpress/wp-content/uploads/2024/10/vitinha-and-his-stats-in-ea-fc25.jpg?q=70&fit=crop&w=825&dpr=1) <small>www.thegamer.com</small>The Best Central Midfielders With High Potential In EA Sports FC 25: Career Mode

Best In The World? Vitinha Tops Four Major Metrics Against Top Midfielders In 2025/26 Champions
-----------------------------------------------------------------------------------------------

 ![Best in the world? Vitinha tops four major metrics against top midfielders in 2025/26 Champions](https://pictures.tribuna.com/image/cec6ec05-b9db-482d-86b2-a15d4a365640?width=1920&quality=70) <small>tribuna.com</small>Best in the world? Vitinha tops four major metrics against top midfielders in 2025/26 Champions ...

Valoraciones De Futbolista: Vitinha En EA SPORTS FC™ 25
-------------------------------------------------------

 ![Valoraciones de futbolista: Vitinha en EA SPORTS FC™ 25](https://ratings-images-prod.pulse.ea.com/FC25/full/player-shields/es/255253.png?width=265) <small>www.ea.com</small>Valoraciones de futbolista: Vitinha en EA SPORTS FC™ 25

Vitinha - 2025-26 UCL Topps NOW® - Card 56 - PR: 474
----------------------------------------------------

 ![Vitinha - 2025-26 UCL Topps NOW® - Card 56 - PR: 474](https://cdn.shopify.com/s/files/1/0662/9749/5709/files/32f4f3f3af4a3ad3aed1292b65f5b943a68af271_ARTCL_16C2S_26TN_00566.jpg?v=1771446505) <small>www.topps.com</small>Vitinha - 2025-26 UCL Topps NOW® - Card 56 - PR: 474

FlashFocus: Little Maestro Vitinha Reaching New Levels With PSG | Flashscore.co.uk
----------------------------------------------------------------------------------

 ![FlashFocus: Little maestro Vitinha reaching new levels with PSG | Flashscore.co.uk](https://livesport-ott-images.ssl.cdn.cra.cz/r900xfq60/b62aca49-901d-4cae-8693-98245edd49d9.jpg) <small>www.flashscore.co.uk</small>FlashFocus: Little maestro Vitinha reaching new levels with PSG | Flashscore.co.uk

🏮 UTOTS 26 OFFICIAL STATS 🏮 VITINHA 119 CM 🔥
--------------------------------------------

 ![🏮 UTOTS 26 OFFICIAL STATS 🏮 VITINHA 119 CM 🔥](https://pbs.twimg.com/media/HJX0J_ybwAAWNNk.jpg) <small>x.com</small>🏮 UTOTS 26 OFFICIAL STATS 🏮 VITINHA 119 CM 🔥

Consigue Ahora Vitinha PSG Master Topps Stickers Champions League 2025/26
-------------------------------------------------------------------------

 ![Consigue ahora Vitinha PSG Master Topps Stickers Champions League 2025/26](https://www.euro-soccer-cards.com/171893-thickbox_default/vitinha-master-psg-360-topps-ucl-25-26.jpg) <small>www.euro-soccer-cards.com</small>Consigue ahora Vitinha PSG Master Topps Stickers Champions League 2025/26

Vitinha EA FC 26 Ratings, Prices &amp; Cards - FUT.GG
-----------------------------------------------------

 ![Vitinha EA FC 26 Ratings, Prices & Cards - FUT.GG](https://game-assets.fut.gg/cdn-cgi/image/quality=85,format=auto,width=300/2025/futgg-player-item-card/25-255253.02fa04a8c7f1789db7dbedf1a3605c5fe6a3cba87316ed1da207ddf88d93b428.webp) <small>www.fut.gg</small>Vitinha EA FC 26 Ratings, Prices &amp; Cards - FUT.GG

¡ESTA EVOLUCIÓN ES INCREÍBLE! 🔥 94 VITINHA FC 25 INMORTALS REVIEW - YouTube
---------------------------------------------------------------------------

 ![¡ESTA EVOLUCIÓN ES INCREÍBLE! 🔥 94 VITINHA FC 25 INMORTALS REVIEW - YouTube](https://i.ytimg.com/vi/GN5E97zhzE8/maxresdefault.jpg) <small>www.youtube.com</small>¡ESTA EVOLUCIÓN ES INCREÍBLE! 🔥 94 VITINHA FC 25 INMORTALS REVIEW - YouTube

236 Vitinha PSG Base | Match Attax 2025/26 – LukeSolve.com
----------------------------------------------------------

 ![236 Vitinha PSG Base | Match Attax 2025/26 – LukeSolve.com](https://lukesolve.com/cdn/shop/files/236_Vitinha_PSG_Base_-_Topps_Premier_League_2026_9569e322-60eb-4893-9d01-5b34dbd6e180.jpg?v=1764263928) <small>lukesolve.com</small>236 Vitinha PSG Base | Match Attax 2025/26 – LukeSolve.com

VITINHA ALL ACTION HERO Match Attax 25/26 Card # 372. NEW £3.29 - PicClick UK
-----------------------------------------------------------------------------

 ![VITINHA ALL ACTION HERO Match Attax 25/26 Card # 372. NEW £3.29 - PicClick UK](https://www.picclickimg.com/7DcAAeSwCFZo6b9w/Vitinha-ALL-ACTION-HERO-Match-Attax-25-26-Card.webp) <small>picclick.co.uk</small>VITINHA ALL ACTION HERO Match Attax 25/26 Card # 372. NEW £3.29 - PicClick UK

Vitinha EA FC 26 Ratings, Prices, And Cards - FUT.GG
----------------------------------------------------

 ![Vitinha EA FC 26 Ratings, Prices, and Cards - FUT.GG](https://game-assets.fut.gg/cdn-cgi/image/quality=100,format=auto/2026/player-item-social-small/26-263829.8fa1d6cf9cfa868a870006a0abf22ff2888c11aa410fbd3c3b7d5ad1332c5bd2.webp) <small>www.fut.gg</small>Vitinha EA FC 26 Ratings, Prices, and Cards - FUT.GG

Vitinha - Skills, Goals, Assists &amp; Passes | PSG | 2025/26 - YouTube
-----------------------------------------------------------------------

 ![Vitinha - Skills, Goals, Assists & Passes | PSG | 2025/26 - YouTube](https://i.ytimg.com/vi/d_R7EioJKH0/maxresdefault.jpg) <small>www.youtube.com</small>Vitinha - Skills, Goals, Assists &amp; Passes | PSG | 2025/26 - YouTube

Vitinha Has Broken The Record For The Most Passes Ever Completed In A Single UEFA Champions
-------------------------------------------------------------------------------------------

 ![Vitinha has broken the record for the most passes ever completed in a single UEFA Champions](https://pbs.twimg.com/media/HHujTHGXYAAPegP.jpg) <small>x.com</small>Vitinha has broken the record for the most passes ever completed in a single UEFA Champions ...

Vitinha - 2025-26 UCL Topps NOW® - Card 142
-------------------------------------------

 ![Vitinha - 2025-26 UCL Topps NOW® - Card 142](https://cdn.shopify.com/s/files/1/0680/2912/0697/files/d70c8c9cd19dbd7afc4e9565c7e0e2f89d2b20dc_ARTCL_16C2S_26TN_01424_UCL_ToppsNow___Vitinha_Paris_Saint_Germain.jpg?v=1780239702) <small>fr.topps.com</small>Vitinha - 2025-26 UCL Topps NOW® - Card 142

Vitinha EA FC 26 Ratings, Prices, And Cards - FUT.GG
----------------------------------------------------

 ![Vitinha EA FC 26 Ratings, Prices, and Cards - FUT.GG](https://game-assets.fut.gg/cdn-cgi/image/quality=80,format=auto,width=200/2023/cards/futgg-cards/50595477.webp) <small>www.fut.gg</small>Vitinha EA FC 26 Ratings, Prices, and Cards - FUT.GG

Vitinha EA FC 26 Ratings, Prices &amp; Cards - FUT.GG
-----------------------------------------------------

 ![Vitinha EA FC 26 Ratings, Prices & Cards - FUT.GG](https://game-assets.fut.gg/cdn-cgi/image/quality=85,format=auto,width=300/2025/futgg-player-item-card/25-100918549.a7dc253b0ea22db0d83ed5d4c7050d3c994c362e0f4b8385b8bfa15122d7ac4c.webp) <small>www.fut.gg</small>Vitinha EA FC 26 Ratings, Prices &amp; Cards - FUT.GG

Vitinha EA FC 26 Ratings, Prices, And Cards - FUT.GG
----------------------------------------------------

 ![Vitinha EA FC 26 Ratings, Prices, and Cards - FUT.GG](https://game-assets.fut.gg/cdn-cgi/image/quality=85,format=auto,width=200/2024/futgg-player-item-card/24-255253.7a394e6dea02f87b46c13783989f533ef0596d8325be85ef67705ab77d75d6d2.webp) <small>www.fut.gg</small>Vitinha EA FC 26 Ratings, Prices, and Cards - FUT.GG

Vitinha - Stats 25/26 | Transfermarkt
-------------------------------------

 ![Vitinha - Stats 25/26 | Transfermarkt](https://img.a.transfermarkt.technology/portrait/big/487469-1749415169.jpg?lm=1) <small>www.transfermarkt.co.uk</small>Vitinha - Stats 25/26 | Transfermarkt

The best central midfielders with high potential in ea sports fc 25: career mode. ¡esta evolución es increíble! 🔥 94 vitinha fc 25 inmortals review. Fc 25: is the vitinha footies sbc worth it
