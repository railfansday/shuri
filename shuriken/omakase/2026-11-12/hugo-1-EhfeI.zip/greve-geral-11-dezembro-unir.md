---
title: "Greve Geral 11 Dezembro Unir - A greve geral de 11 de dezembro em 38 imagens – observador"
description: "A greve geral de 11 de dezembro em 38 imagens – observador"
date: "2025-12-16"
categories:
- "Uncategorized"
images:
- "https://staticx.noticiasilimitadas.pt/jn/image.webp?brand=jn&amp;type=generate&amp;guid=fb434b13-2b30-4ab1-a6bc-4ddd86b96b14&amp;w=3840"
featuredImage: "https://www.ate.pt/wp-content/uploads/2025/12/Greve-geral-11.12.jpg"
featured_image: "https://bordalo.observador.pt/v2/q:60/rs:fill:1440/c:4096:2730:nowe:0:0/plain/https://s3.observador.pt/wp-content/uploads/2025/12/11173414/dventura-greve-geral-11dez-54-scaled.jpg"
image: "https://spzn.pt/uploads/noticias/big_1763717239_6728_SPZN_2025_site_novo_(17).png"
---

If you are looking for A greve geral de 11 de dezembro em 38 imagens – Observador you've visit to the right place. We have 35 Pics about A greve geral de 11 de dezembro em 38 imagens – Observador like Greve Geral – 24 Horas – Dia 11 de Dezembro de 2025 – SINTTAV Sindicato Nacional dos, Greve Geral a 11 de Dezembro | Sindicato dos Quadros Técnicos do Estado and also GREVE GERAL – Concentração em frente da Câmara Municipal de Portimão – 11 Dezembro 8h30. Here it is:

A Greve Geral De 11 De Dezembro Em 38 Imagens – Observador
----------------------------------------------------------

 ![A greve geral de 11 de dezembro em 38 imagens – Observador](https://bordalo.observador.pt/v2/q:60/rs:fill:1440/c:4096:2730:nowe:0:0/plain/https://s3.observador.pt/wp-content/uploads/2025/12/11173652/dventura-greve-geral-11dez-73-scaled.jpg) <small>observador.pt</small>A greve geral de 11 de dezembro em 38 imagens – Observador

Perguntas E Respostas Sobre A Greve Geral De 11 De Dezembro - SBC - Sindicato Nacional Dos
------------------------------------------------------------------------------------------

 ![Perguntas e respostas sobre a Greve Geral de 11 de dezembro - SBC - Sindicato Nacional dos](https://www.sibace.pt/wp-content/uploads/2025/11/greve-2-1170-x-400.png) <small>www.sibace.pt</small>Perguntas e respostas sobre a Greve Geral de 11 de dezembro - SBC - Sindicato Nacional dos ...

Greve Geral Contra Pacote Laboral A 11 De Dezembro (vídeo) – RTP Madeira
------------------------------------------------------------------------

 ![Greve geral contra pacote laboral a 11 de dezembro (vídeo) – RTP Madeira](https://madeira.rtp.pt/wp-content/uploads/2025/11/DOC.20251108.45998234.ACOT9063-scaled.jpg) <small>madeira.rtp.pt</small>Greve geral contra pacote laboral a 11 de dezembro (vídeo) – RTP Madeira

GREVE GERAL DIA 11 DEZEMBRO DE 2025 | FESAHT
--------------------------------------------

 ![GREVE GERAL DIA 11 DEZEMBRO DE 2025 | FESAHT](https://sindicatos.cgtp.pt/fesaht/wp-content/blogs.dir/52/files/sites/52/2025/12/11-DEZ-faz-greve-e-sai-a-Rua.jpg) <small>sindicatos.cgtp.pt</small>GREVE GERAL DIA 11 DEZEMBRO DE 2025 | FESAHT

A Greve Geral De 11 De Dezembro Em 38 Imagens – Observador
----------------------------------------------------------

 ![A greve geral de 11 de dezembro em 38 imagens – Observador](https://bordalo.observador.pt/v2/q:60/rs:fill:1440/c:4096:2730:nowe:0:0/plain/https://s3.observador.pt/wp-content/uploads/2025/12/11173228/dventura-greve-geral-11dez-41-scaled.jpg) <small>observador.pt</small>A greve geral de 11 de dezembro em 38 imagens – Observador

Transportes, Hospitais, Escolas E Até Bancos. Que Setores Vão Ser Afetados Pela Greve Geral? – ECO
--------------------------------------------------------------------------------------------------

 ![Transportes, hospitais, escolas e até bancos. Que setores vão ser afetados pela greve geral? – ECO](https://ecoonline.s3.amazonaws.com/uploads/2025/12/46141990.jpg) <small>eco.sapo.pt</small>Transportes, hospitais, escolas e até bancos. Que setores vão ser afetados pela greve geral? – ECO

Greve Geral De 11 De Dezembro: Impacto Económico Estimado E Análise | Economia
------------------------------------------------------------------------------

 ![Greve Geral de 11 de Dezembro: Impacto Económico Estimado e Análise | Economia](https://i.headtopics.com/images/2025/12/6/publico/greve-geral-o-que-e-quem-abrange-e-como-funciona-greve-geral-o-que-e-quem-abrange-e-como-funciona-43970BF408A401F542300934033BEA05.webp?w=640) <small>ph.headtopics.com</small>Greve Geral de 11 de Dezembro: Impacto Económico Estimado e Análise | Economia

Todos à Greve Geral – 11 Dez. • Trabalhadores Unidos
----------------------------------------------------

 ![Todos à Greve Geral – 11 Dez. • Trabalhadores Unidos](https://trabalhadores-unidos.pt/wp-content/uploads/2025/12/capa-todos-gg.png) <small>trabalhadores-unidos.pt</small>Todos à Greve Geral – 11 Dez. • Trabalhadores Unidos

VISEU - Esclarecimento E Mobilização Para A Greve Geral Marcada Para 11 De Dezembro - CGTP-IN
---------------------------------------------------------------------------------------------

 ![VISEU - Esclarecimento e mobilização para a Greve Geral marcada para 11 de Dezembro - CGTP-IN](https://www.cgtp.pt/images/accao-e-luta/2025/gg.jpg) <small>www.cgtp.pt</small>VISEU - Esclarecimento e mobilização para a Greve Geral marcada para 11 de Dezembro - CGTP-IN

UGT Aprova Por Unanimidade Greve Geral A 11 De Dezembro - Diário Do Minho
-------------------------------------------------------------------------

 ![UGT aprova por unanimidade greve geral a 11 de dezembro - Diário do Minho](https://www.diariodominho.pt/storage/posts/greve-direito-a-greve_655b8a6d702c0_og.jpg) <small>www.diariodominho.pt</small>UGT aprova por unanimidade greve geral a 11 de dezembro - Diário do Minho

A Greve Geral De 11 De Dezembro Em 38 Imagens – Observador
----------------------------------------------------------

 ![A greve geral de 11 de dezembro em 38 imagens – Observador](https://bordalo.observador.pt/v2/q:60/rs:fill:1440/c:4096:2730:nowe:0:0/plain/https://s3.observador.pt/wp-content/uploads/2025/12/11173414/dventura-greve-geral-11dez-54-scaled.jpg) <small>observador.pt</small>A greve geral de 11 de dezembro em 38 imagens – Observador

Greve Geral Pode Custar 792 Milhões De Euros à Economia - JN
------------------------------------------------------------

 ![Greve geral pode custar 792 milhões de euros à economia - JN](https://staticx.noticiasilimitadas.pt/jn/image.webp?brand=jn&type=generate&guid=fb434b13-2b30-4ab1-a6bc-4ddd86b96b14&w=3840) <small>www.jn.pt</small>Greve geral pode custar 792 milhões de euros à economia - JN

Motivos Da Adesão à Greve Geral De 11 De Dezembro De 2025
---------------------------------------------------------

 ![Motivos da adesão à Greve Geral de 11 de dezembro de 2025](https://spzn.pt/uploads/noticias/big_1763717239_6728_SPZN_2025_site_novo_(17).png) <small>spzn.pt</small>Motivos da adesão à Greve Geral de 11 de dezembro de 2025

Greve Geral – 24 Horas – Dia 11 De Dezembro De 2025 – SINTTAV Sindicato Nacional Dos
------------------------------------------------------------------------------------

 ![Greve Geral – 24 Horas – Dia 11 de Dezembro de 2025 – SINTTAV Sindicato Nacional dos](https://sinttav.pt/wp-content/uploads/2025/11/pag-1.jpg) <small>sinttav.pt</small>Greve Geral – 24 Horas – Dia 11 de Dezembro de 2025 – SINTTAV Sindicato Nacional dos ...

Climáximo Apoia A Greve Geral - Climaximo
-----------------------------------------

 ![Climáximo apoia a Greve Geral - Climaximo](https://www.climaximo.pt/wp-content/uploads/2025/12/Greve-Geral3-819x1024.png) <small>www.climaximo.pt</small>Climáximo apoia a Greve Geral - Climaximo

ASSIFECO ADERE À GREVE GERAL DE 11 DE DEZEMBRO — ASSIFECO
---------------------------------------------------------

 ![ASSIFECO ADERE À GREVE GERAL DE 11 DE DEZEMBRO — ASSIFECO](https://www.assifeco.pt/images/2025/12/05/USI BANNER_thumbnail.jpg) <small>www.assifeco.pt</small>ASSIFECO ADERE À GREVE GERAL DE 11 DE DEZEMBRO — ASSIFECO

Amanhã Há Greve Da Função Pública (escolas Podem Fechar)
--------------------------------------------------------

 ![Amanhã há greve da função pública (escolas podem fechar)](https://jornaldemafra.pt/wp-content/uploads/2025/12/greve-geral.webp) <small>jornaldemafra.pt</small>Amanhã há greve da função pública (escolas podem fechar)

Agrupamento De Escolas De Mira - Pré - Aviso De Greve Para Os Dias 11 E 12 De Dezembro De 2025
----------------------------------------------------------------------------------------------

 ![Agrupamento de Escolas de Mira - Pré - aviso de greve para os dias 11 e 12 de dezembro de 2025](https://www.escolasdemira.pt/images/PR-_AVISO_DE_GREVE_para_os_dias_11_e_12_de_dezembro_de_2025.png) <small>www.escolasdemira.pt</small>Agrupamento de Escolas de Mira - Pré - aviso de greve para os dias 11 e 12 de dezembro de 2025

Sindicato Apela Aos Jornalistas Que Participem Na Greve Contra O Pacote Laboral
-------------------------------------------------------------------------------

 ![Sindicato apela aos jornalistas que participem na greve contra o pacote laboral](https://staticx.noticiasilimitadas.pt/jn/image.webp?brand=jn&type=generate&guid=fd8bd9f9-1087-408c-93ed-e558c269857d&w=3840) <small>www.jn.pt</small>Sindicato apela aos jornalistas que participem na greve contra o pacote laboral

Greve Geral A 11 De Dezembro | Sindicato Dos Quadros Técnicos Do Estado
-----------------------------------------------------------------------

 ![Greve Geral a 11 de Dezembro | Sindicato dos Quadros Técnicos do Estado](https://www.ste.pt/wp-content/uploads/2025/12/GreveGeral-Cartaz-scaled.jpg) <small>www.ste.pt</small>Greve Geral a 11 de Dezembro | Sindicato dos Quadros Técnicos do Estado

GREVE GERAL DE 11 DE DEZEMBRO DE 2025 – MANIFESTAÇÕES – LISBOA (VÍDEO) – EPHEMERA – Biblioteca E
------------------------------------------------------------------------------------------------

 ![GREVE GERAL DE 11 DE DEZEMBRO DE 2025 – MANIFESTAÇÕES – LISBOA (VÍDEO) – EPHEMERA – Biblioteca e](https://ephemerajpp.com/wp-content/uploads/2025/12/IMG_2182.jpg) <small>ephemerajpp.com</small>GREVE GERAL DE 11 DE DEZEMBRO DE 2025 – MANIFESTAÇÕES – LISBOA (VÍDEO) – EPHEMERA – Biblioteca e ...

GREVE GERAL | 11 DEZEMBRO 2025 - ATE
------------------------------------

 ![GREVE GERAL | 11 DEZEMBRO 2025 - ATE](https://www.ate.pt/wp-content/uploads/2025/12/Greve-geral-11.12.jpg) <small>www.ate.pt</small>GREVE GERAL | 11 DEZEMBRO 2025 - ATE

S.TO.P. Junta-se à Greve Geral De 11 De Dezembro Com Pré-aviso De Greve Para A Educação
---------------------------------------------------------------------------------------

 ![S.TO.P. junta-se à greve geral de 11 de dezembro com pré-aviso de greve para a educação](https://stop-sindicato.pt/wp-content/uploads/2025/11/S.TO_.P.-Cartaz-Greve-Geral-Educacao-11Dez2025_x1000-724x1024.png) <small>stop-sindicato.pt</small>S.TO.P. junta-se à greve geral de 11 de dezembro com pré-aviso de greve para a educação ...

Greve Geral De 11 De Dezembro Em Portugal: Razões Para Participar
-----------------------------------------------------------------

 ![Greve Geral de 11 de dezembro em Portugal: razões para participar](https://sabiasque.pt/images/stories/2025/trabalho/20251209-greve-geral-11-dezembro-320x480.jpg) <small>sabiasque.pt</small>Greve Geral de 11 de dezembro em Portugal: razões para participar

FAQ: Os Direitos Dos Docentes Em Dia De Greve Geral - 11/12/2025
----------------------------------------------------------------

 ![FAQ: Os direitos dos docentes em dia de Greve Geral - 11/12/2025](https://static.wixstatic.com/media/d0f32c_9ff1199ee2c34418af0094a43c516733~mv2.png/v1/fill/w_940,h_788,al_c,q_90,enc_avif,quality_auto/d0f32c_9ff1199ee2c34418af0094a43c516733~mv2.png) <small>www.sprc.pt</small>FAQ: Os direitos dos docentes em dia de Greve Geral - 11/12/2025

Dos Transportes à Saúde, Lares E Prisões, Que Serviços Mínimos Estão Garantidos Para A Greve
--------------------------------------------------------------------------------------------

 ![Dos transportes à saúde, lares e prisões, que serviços mínimos estão garantidos para a greve](https://images.impresa.pt/expresso/2025-12-09-greve-geral.jpg-0c01f0f6/original) <small>expresso.pt</small>Dos transportes à saúde, lares e prisões, que serviços mínimos estão garantidos para a greve ...

Adere à Greve Geral Dia 11 De Dezembro
--------------------------------------

 ![Adere à Greve Geral dia 11 de dezembro](https://www.sep.org.pt/files/uploads/2025/11/SEP_GREVEGERAL_WEB_1-800x350.jpg) <small>www.sep.org.pt</small>Adere à Greve Geral dia 11 de dezembro

A Greve Geral De 11 De Dezembro Em 38 Imagens – Observador
----------------------------------------------------------

 ![A greve geral de 11 de dezembro em 38 imagens – Observador](https://bordalo.observador.pt/v2/q:60/rs:fill:1440/c:4096:2730:nowe:0:0/plain/https://s3.observador.pt/wp-content/uploads/2025/12/11173246/dventura-greve-geral-11dez-43-scaled.jpg) <small>observador.pt</small>A greve geral de 11 de dezembro em 38 imagens – Observador

A Greve Geral De 11 De Dezembro Em 38 Imagens – Observador
----------------------------------------------------------

 ![A greve geral de 11 de dezembro em 38 imagens – Observador](https://bordalo.observador.pt/v2/q:60/rs:fill:1440/c:4096:2730:nowe:0:0/plain/https://s3.observador.pt/wp-content/uploads/2025/12/11090822/dventura-greve-geral-11dez-8-scaled.jpg) <small>observador.pt</small>A greve geral de 11 de dezembro em 38 imagens – Observador

SDP Sul
-------

 ![SDP Sul](https://sdpsul.com/storage/publicacao/imagem_563_6929dba6ddf62.jpeg) <small>sdpsul.com</small>SDP Sul

A Greve Geral De 11 De Dezembro Em 38 Imagens – Observador
----------------------------------------------------------

 ![A greve geral de 11 de dezembro em 38 imagens – Observador](https://bordalo.observador.pt/v2/q:60/rs:fill:1440/c:4096:2730:nowe:0:0/plain/https://s3.observador.pt/wp-content/uploads/2025/12/11173618/dventura-greve-geral-11dez-69-scaled.jpg) <small>observador.pt</small>A greve geral de 11 de dezembro em 38 imagens – Observador

Greve Geral — 11 De Dezembro — Contra O Pacote Laboral | Partido Comunista Português
------------------------------------------------------------------------------------

 ![Greve Geral — 11 de Dezembro — Contra o Pacote Laboral | Partido Comunista Português](https://www.pcp.pt/sites/default/files/imagecache/facebook_share/images/dossiers/greve_geral_11_dez_2025/capa.jpg) <small>www.pcp.pt</small>Greve Geral — 11 de Dezembro — Contra o Pacote Laboral | Partido Comunista Português

GREVE GERAL – Concentração Em Frente Da Câmara Municipal De Portimão – 11 Dezembro 8h30
---------------------------------------------------------------------------------------

 ![GREVE GERAL – Concentração em frente da Câmara Municipal de Portimão – 11 Dezembro 8h30](https://stop-sindicato.pt/wp-content/uploads/2025/12/S.TO_.P.-Cartaz-Protesto-CM-Portimao-GreveGeral-11Dez-8h30.png) <small>stop-sindicato.pt</small>GREVE GERAL – Concentração em frente da Câmara Municipal de Portimão – 11 Dezembro 8h30 ...

Greve Geral: CGTP Entrega Pré-aviso, Depois De UGT Admitir Polongar Paralisação - SIC Notícias
----------------------------------------------------------------------------------------------

 ![Greve geral: CGTP entrega pré-aviso, depois de UGT admitir polongar paralisação - SIC Notícias](https://images.impresa.pt/sicnot/2025-11-17-cgtp-pre-aviso-greve-82e19fc3-1/16x9/mw-1200) <small>sicnoticias.pt</small>Greve geral: CGTP entrega pré-aviso, depois de UGT admitir polongar paralisação - SIC Notícias

Fertagus &gt; Fertagus (pt) &gt; Viajar &gt; Comunicados E Campanhas &gt; Greve Geral 11 De Dezembro De 2025
------------------------------------------------------------------------------------------------------------

 ![Fertagus > Fertagus (pt) > Viajar > Comunicados e Campanhas > Greve Geral 11 de dezembro de 2025](https://www.fertagus.pt/portals/0/FTG-Greve-Geral-web-1253x886.jpg) <small>www.fertagus.pt</small>Fertagus &gt; Fertagus (pt) &gt; Viajar &gt; Comunicados e Campanhas &gt; Greve Geral 11 de dezembro de 2025

A greve geral de 11 de dezembro em 38 imagens – observador. greve geral dia 11 dezembro de 2025. Agrupamento de escolas de mira
