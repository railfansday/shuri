---
title: "Greve Geral 17 Abril 2026 - 15 minutos: impacto da greve geral já se começou a sentir no setor dos transportes"
description: "Veja a últimas notícias da greve 2026"
date: "2026-01-06"
categories:
- "Uncategorized"
images:
- "https://www.spn.pt/Media/Default/Info/60000/700/90/7/greveap-17maio24.jpeg"
featuredImage: "https://cdn.sabado.pt/images/2025-12/img_1320x742uu2025-12-11-15-03-48-752830.jpg"
featured_image: "https://aeterrasave.net/wp-content/uploads/2026/04/Greve-17-de-Abril-2026.png"
image: "https://www.spn.pt/Media/Default/Info/68000/500/60/7/grevegeral11dez_cartaz.jpg"
---

If you are searching about Greve Geral juntou centenas nos Aliados. Governo fala em adesão "inexpressiva" - JPN you've came to the right place. We have 35 Pictures about Greve Geral juntou centenas nos Aliados. Governo fala em adesão "inexpressiva" - JPN like Pré-Aviso de Greve – 17 de abril de 2026 – AE António Correia de Oliveira, Professores(as) da UFPB aprovam indicativo de greve sem data e paralisação no dia 17 de abril and also SPN - Greves distritais — Norte com forte adesão!. Here it is:

Greve Geral Juntou Centenas Nos Aliados. Governo Fala Em Adesão "inexpressiva" - JPN
------------------------------------------------------------------------------------

 ![Greve Geral juntou centenas nos Aliados. Governo fala em adesão "inexpressiva" - JPN](https://www.jpn.up.pt/wp-content/uploads/2025/12/greve_geral8.jpg) <small>www.jpn.up.pt</small>Greve Geral juntou centenas nos Aliados. Governo fala em adesão "inexpressiva" - JPN

Pré-aviso De Greve 17 De Abril De 2026 – AE Terras Do Ave
---------------------------------------------------------

 ![Pré-aviso de greve 17 de abril de 2026 – AE Terras do Ave](https://aeterrasave.net/wp-content/uploads/2026/04/Greve-17-de-Abril-2026.png) <small>aeterrasave.net</small>Pré-aviso de greve 17 de abril de 2026 – AE Terras do Ave

Dados Recolhidos Até às 19h20 Demonstram Que A Greve Geral Parou O País - CGTP-IN
---------------------------------------------------------------------------------

 ![Dados recolhidos até às 19h20 demonstram que a Greve Geral parou o país - CGTP-IN](https://cgtp.pt/images/images/2026/06/Captura de ecra 2026-06-03 120926.png#joomlaImage:/local-images/images/2026/06/Captura de ecra 2026-06-03 120926.png?width=1162&height=610) <small>www.cgtp.pt</small>Dados recolhidos até às 19h20 demonstram que a Greve Geral parou o país - CGTP-IN

Greve No Dia 17 De Abril De 2026 Para Pessoal Docente E Não Docente – Agrupamento De Escolas Da
-----------------------------------------------------------------------------------------------

 ![Greve no dia 17 de abril de 2026 para Pessoal Docente e Não Docente – Agrupamento de Escolas da](https://www.aezuff.org/extranet/http://www.aezuff.org/extranet/wp-content/uploads/2012/10//2026/04/Greve.jpg) <small>www.aezuff.org</small>Greve no dia 17 de abril de 2026 para Pessoal Docente e Não Docente – Agrupamento de Escolas da ...

AO MINUTO: Greve Geral Para O País. "Forte Adesão" E "impacto Fortíssimo"
-------------------------------------------------------------------------

 ![AO MINUTO: Greve geral para o país. "Forte adesão" e "impacto fortíssimo"](https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA1S86fG.img?w=1920&h=1080&m=4&q=100) <small>www.msn.com</small>AO MINUTO: Greve geral para o país. "Forte adesão" e "impacto fortíssimo"

SPGL - Professores, Educadores E Investigadores Na Greve Geral | 3 De Junho 2026
--------------------------------------------------------------------------------

 ![SPGL - Professores, educadores e investigadores na Greve Geral | 3 de junho 2026](https://www.spgl.pt/Media/Default/_Profiles/7494e02c/a9d870bd/Flyer Greve Geral_page-0001.jpg?v=639147970016913172) <small>www.spgl.pt</small>SPGL - Professores, educadores e investigadores na Greve Geral | 3 de junho 2026

AVISO À COMUNIDADE EDUCATIVA – GREVE | 17 De Abril De 2026
----------------------------------------------------------

 ![AVISO À COMUNIDADE EDUCATIVA – GREVE | 17 de abril de 2026](https://aealcabideche.pt/images/Aviso_à_Comunidade_Educativa_-_Greve.png) <small>aealcabideche.pt</small>AVISO À COMUNIDADE EDUCATIVA – GREVE | 17 de abril de 2026

15 Minutos: Impacto Da Greve Geral Já Se Começou A Sentir No Setor Dos Transportes - SIC Notícias
-------------------------------------------------------------------------------------------------

 ![15 minutos: impacto da greve geral já se começou a sentir no setor dos transportes - SIC Notícias](https://images.impresa.pt/sicnot/2025-12-12-greve-geral-045a9380/1.91x1?wm=true&outputFormat=jpeg) <small>sicnoticias.pt</small>15 minutos: impacto da greve geral já se começou a sentir no setor dos transportes - SIC Notícias

Agenda De Greve – 22 A 27 De Abril – Assufrgs
---------------------------------------------

 ![Agenda de Greve – 22 a 27 de abril – Assufrgs](https://www.assufrgs.org.br/wp-content/uploads/2026/03/Capa-site-3.0-5.png) <small>www.assufrgs.org.br</small>Agenda de Greve – 22 a 27 de abril – Assufrgs

AVISO PRÉVIO DE GREVE TRABALHADORES ADMINISTRAÇÃO PÚBLICA 16 DE MAIO 2025 – STTS
--------------------------------------------------------------------------------

 ![AVISO PRÉVIO DE GREVE TRABALHADORES ADMINISTRAÇÃO PÚBLICA 16 DE MAIO 2025 – STTS](https://www.stts.pt/wp-content/uploads/2025/05/CAPA.jpg) <small>www.stts.pt</small>AVISO PRÉVIO DE GREVE TRABALHADORES ADMINISTRAÇÃO PÚBLICA 16 DE MAIO 2025 – STTS

GREVE 2026 – Sinasefe RN
------------------------

 ![GREVE 2026 – Sinasefe RN](https://www.sinasefern.org.br/wp-content/uploads/2026/04/WhatsApp-Image-2026-04-22-at-16.07.32.jpeg) <small>www.sinasefern.org.br</small>GREVE 2026 – Sinasefe RN

SINAPSA Adere à Greve Geral - CGTP-IN
-------------------------------------

 ![SINAPSA adere à Greve Geral - CGTP-IN](https://www.cgtp.pt/images/accao-e-luta/2026/05/INFO41_MAIO2026.png) <small>www.cgtp.pt</small>SINAPSA adere à Greve Geral - CGTP-IN

Greve Geral Histórica Em Portugal Paralisa Transportes, Fecha Escolas E Pressiona Hospitais
-------------------------------------------------------------------------------------------

 ![Greve geral histórica em Portugal paralisa transportes, fecha escolas e pressiona hospitais](https://p2.trrsf.com/image/fget/cf/1200/630/middle/images.terra.com/2025/12/11/greve-ubj4bs8ccokh.png) <small>www.terra.com.br</small>Greve geral histórica em Portugal paralisa transportes, fecha escolas e pressiona hospitais

Greve Geral | Ações E Dados
---------------------------

 ![Greve Geral | Ações e dados](https://fne.pt/uploads/noticias/big_1765451399_8584_Design_sem_nome.png) <small>fne.pt</small>Greve Geral | Ações e dados

STAL Avança Com Aviso De Greve Para Manifestação Nacional Da CGTP-IN
--------------------------------------------------------------------

 ![STAL avança com aviso de greve para Manifestação Nacional da CGTP-IN](https://www.stal.pt/images/2026/Manif_17Abril.jpeg) <small>www.stal.pt</small>STAL avança com aviso de greve para Manifestação Nacional da CGTP-IN

Pré Aviso De Greve Dos TCB A 17 De Abril - Portal Institucional
---------------------------------------------------------------

 ![Pré Aviso de Greve dos TCB a 17 de abril - Portal Institucional](https://www.cm-barreiro.pt/wp-content/uploads/2026/04/POST-GERAL-GREVE_1920px.jpg?x14808) <small>www.cm-barreiro.pt</small>Pré Aviso de Greve dos TCB a 17 de abril - Portal Institucional

SINDEP - Greve Geral 11 De Dezembro
-----------------------------------

 ![SINDEP - Greve Geral 11 de dezembro](https://sindep.pt/images/cartaz_GREVE_GERAL_UGT.jpg) <small>sindep.pt</small>SINDEP - Greve Geral 11 de dezembro

Metro Do Porto "fortemente Condicionado" No Dia Da Greve Geral - JPN
--------------------------------------------------------------------

 ![Metro do Porto "fortemente condicionado" no dia da greve geral - JPN](https://www.jpn.up.pt/wp-content/uploads/2025/12/greve_geral1-1152x759.jpg) <small>www.jpn.up.pt</small>Metro do Porto "fortemente condicionado" no dia da greve geral - JPN

AVISO - Greve - Pré-aviso - 17 De Abril De 2026 (6ª Feira) - Agrupamento De Escolas De Pombal
---------------------------------------------------------------------------------------------

 ![AVISO - Greve - pré-aviso - 17 de abril de 2026 (6ª feira) - Agrupamento de Escolas de Pombal](https://www.aepombal.edu.pt/wp-content/uploads/2026/04/20260417_DGAEP_greves-comunicadas-768x365.png) <small>www.aepombal.edu.pt</small>AVISO - Greve - pré-aviso - 17 de abril de 2026 (6ª feira) - Agrupamento de Escolas de Pombal

SPN - Fenprof — Adesão Histórica à Greve Geral
----------------------------------------------

 ![SPN - Fenprof — Adesão histórica à greve geral](https://www.spn.pt/Media/Default/Info/68000/500/60/7/grevegeral11dez_cartaz.jpg) <small>www.spn.pt</small>SPN - Fenprof — Adesão histórica à greve geral

Professores: Greve Por Distritos Durante 18 Dias úteis, De 17 De Abril A 12 De Maio - CGTP-IN
---------------------------------------------------------------------------------------------

 ![Professores: Greve por distritos durante 18 dias úteis, de 17 de abril a 12 de maio - CGTP-IN](https://www.cgtp.pt/images/accao-e-luta/2023/03/Greve_por_distritos_durante_18_dias_úteis_de_17_de_abril_a_12_de_maio.jpg) <small>www.cgtp.pt</small>Professores: Greve por distritos durante 18 dias úteis, de 17 de abril a 12 de maio - CGTP-IN

GREVE DA EDUCAÇÃO – ANDES Disponibiliza ônibus De Fortaleza A Brasília Para Ato Nacional No Dia
-----------------------------------------------------------------------------------------------

 ![GREVE DA EDUCAÇÃO – ANDES disponibiliza ônibus de Fortaleza a Brasília para ato nacional no dia](https://www.adufc.org.br/wp-content/uploads/2024/04/Informe-2023-Modelo-Quadrado.png) <small>www.adufc.org.br</small>GREVE DA EDUCAÇÃO – ANDES disponibiliza ônibus de Fortaleza a Brasília para ato nacional no dia ...

AETCF: Pré-aviso De Greve Da Função Pública Para 17 De Abril 2026
-----------------------------------------------------------------

 ![AETCF: Pré-aviso de Greve da Função Pública para 17 de abril 2026](https://www.aetcf.pt/pluginfile.php/16/mod_forum/post/2094/prevaviso_greve_17abri26.png) <small>www.aetcf.pt</small>AETCF: Pré-aviso de Greve da Função Pública para 17 de abril 2026

STML | Trabalhadores Do Município De Lisboa Também Aderem à Greve Geral - CGTP-IN
---------------------------------------------------------------------------------

 ![STML | Trabalhadores do Município de Lisboa também aderem à Greve Geral - CGTP-IN](https://www.cgtp.pt/images/images/2026/06/tiago-greve-geral.jpg) <small>www.cgtp.pt</small>STML | Trabalhadores do Município de Lisboa também aderem à Greve Geral - CGTP-IN

Pré-Aviso De Greve – 17 De Abril De 2026 – AE António Correia De Oliveira
-------------------------------------------------------------------------

 ![Pré-Aviso de Greve – 17 de abril de 2026 – AE António Correia de Oliveira](https://www.acoliveira.pt/wp-content/uploads/2026/04/7e9f6ec4-4873-4685-897b-30c62aab02d6.png) <small>www.acoliveira.pt</small>Pré-Aviso de Greve – 17 de abril de 2026 – AE António Correia de Oliveira

Aviso | Greves Em Junho De 2026 – AE António Correia De Oliveira
----------------------------------------------------------------

 ![Aviso | Greves em junho de 2026 – AE António Correia de Oliveira](https://www.acoliveira.pt/wp-content/uploads/2026/05/ChatGPT-Image-31_05_2026-22_43_43.png) <small>www.acoliveira.pt</small>Aviso | Greves em junho de 2026 – AE António Correia de Oliveira

Mais De 50 Sindicatos Aderem à Greve Geral Marcada Para 11 De Dezembro
----------------------------------------------------------------------

 ![Mais de 50 sindicatos aderem à greve geral marcada para 11 de dezembro](https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA1QBjfX.img?w=1200&h=800&m=4&q=70) <small>www.msn.com</small>Mais de 50 sindicatos aderem à greve geral marcada para 11 de dezembro

Manifestação Em Frente Ao Parlamento Resultou Em Seis Detidos: Tudo Sobre A Greve Geral
---------------------------------------------------------------------------------------

 ![Manifestação em frente ao Parlamento resultou em seis detidos: tudo sobre a greve geral](https://cdn.sabado.pt/images/2025-12/img_1320x742uu2025-12-11-15-03-48-752830.jpg) <small>www.sabado.pt</small>Manifestação em frente ao Parlamento resultou em seis detidos: tudo sobre a greve geral ...

SPN - Greves Distritais — Norte Com Forte Adesão!
-------------------------------------------------

 ![SPN - Greves distritais — Norte com forte adesão!](https://www.spn.pt/Media/Default/Info/55000/900/30/0/17a_greve_Porto.jpg) <small>www.spn.pt</small>SPN - Greves distritais — Norte com forte adesão!

SPN - Docentes Na Greve Da Administração Pública (17/mai)
---------------------------------------------------------

 ![SPN - Docentes na Greve da Administração Pública (17/mai)](https://www.spn.pt/Media/Default/Info/60000/700/90/7/greveap-17maio24.jpeg) <small>www.spn.pt</small>SPN - Docentes na Greve da Administração Pública (17/mai)

Greve Da Administração Pública Marcada Para 17 De Abril — DNOTICIAS.PT
----------------------------------------------------------------------

 ![Greve da Administração Pública marcada para 17 de Abril — DNOTICIAS.PT](https://static-storage.dnoticias.pt/www-assets.dnoticias.pt/images/configuration/fb-9/logoWhatsApp_Image_2025-10-24_at_10.56.44_eFMSccu.JPEG) <small>www.dnoticias.pt</small>Greve da Administração Pública marcada para 17 de Abril — DNOTICIAS.PT

Professores(as) Da UFPB Aprovam Indicativo De Greve Sem Data E Paralisação No Dia 17 De Abril
---------------------------------------------------------------------------------------------

 ![Professores(as) da UFPB aprovam indicativo de greve sem data e paralisação no dia 17 de abril](https://www.adufpb.org.br/site/wp-content/uploads/2024/04/2024.04.03-assembleia-indicativo-de-greve-5-scaled.jpg) <small>www.adufpb.org.br</small>Professores(as) da UFPB aprovam indicativo de greve sem data e paralisação no dia 17 de abril ...

Veja A últimas Notícias Da Greve 2026 - Sindifes-MG
---------------------------------------------------

 ![Veja a últimas notícias da Greve 2026 - Sindifes-MG](https://site-wp.sfo3.digitaloceanspaces.com/wp-content/uploads/2025/12/10115923/IMG_2230-2048x1366-1.jpeg) <small>sindifes.org.br</small>Veja a últimas notícias da Greve 2026 - Sindifes-MG

Greve Geral Paralisa Portugal Contra Precarização De Direitos
-------------------------------------------------------------

 ![Greve geral paralisa Portugal contra precarização de direitos](https://pcdob.org.br/wp-content/uploads/2025/12/Ruas-de-Lisboa-foram-tomadas-por-trabalhadores-durante-a-greve-geral-Rafael-Medeiros-Esquerda.jpg) <small>pcdob.org.br</small>Greve geral paralisa Portugal contra precarização de direitos

Greve Geral Juntou Centenas Nos Aliados. Governo Fala Em Adesão "inexpressiva" - JPN
------------------------------------------------------------------------------------

 ![Greve Geral juntou centenas nos Aliados. Governo fala em adesão "inexpressiva" - JPN](https://www.jpn.up.pt/wp-content/uploads/2025/12/greve_geral9.jpg) <small>www.jpn.up.pt</small>Greve Geral juntou centenas nos Aliados. Governo fala em adesão "inexpressiva" - JPN

Aetcf: pré-aviso de greve da função pública para 17 de abril 2026. Ao minuto: greve geral para o país. "forte adesão" e "impacto fortíssimo". greve da educação – andes disponibiliza ônibus de fortaleza a brasília para ato nacional no dia ...
