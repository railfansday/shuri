---
title: "Quando Joga O Porto Benfica - benfica vs porto"
description: "Fc porto 5"
date: "2026-11-09"
categories:
- "Uncategorized"
images:
- "https://media.slbenfica.pt/-/media/benficadp/images/departamento-de-comunicacao/2025/futebol/competicoes/taca-de-portugal/quartos-de-final-fc-porto-benfica/jogo/richard-rios-1-thumbnail.jpg?la=pt-pt&amp;v=639040222790000000&amp;hash=1CEA144B53C6C0FBC134B492BC9C8A71"
featuredImage: "https://golo.fm/wp-content/uploads/2024/03/Porto-vs-Benfica-03032024-20H30-CAPA.png"
featured_image: "https://bordalo.observador.pt/v2/q:60/rs:fill:980/c:1200:674:nowe:0:0/plain/https://s3.observador.pt/wp-content/uploads/2024/11/08181815/prognostico-benfica-porto.jpg"
image: "https://thumbor.prod.vidiocdn.com/8DfK2r3pvcS36QsgWLEj_1V04iM=/1280x720/filters:quality(70)/vidio-web-prod-video/uploads/video/image/7683866/hl-babak-1-potuguese-league-benfica-vs-porto-67142d.jpg"
---

If you are looking for Benfica vs Porto EN VIVO: ¿Dónde ver O Clássico por Primeira Liga? you've visit to the right web. We have 35 Images about Benfica vs Porto EN VIVO: ¿Dónde ver O Clássico por Primeira Liga? like Liga Portugal - Empate entre SL Benfica B e FC Porto B, Benfica x Porto: onde assistir, horário e escalações do jogo pelo Campeonato Português and also Benfica 🆚 Porto | “Chocolate” argentino em goleada da águia | GoalPoint. Here you go:

Benfica Vs Porto EN VIVO: ¿Dónde Ver O Clássico Por Primeira Liga?
------------------------------------------------------------------

 ![Benfica vs Porto EN VIVO: ¿Dónde ver O Clássico por Primeira Liga?](https://ds-images.bolavip.com/news/image?src=https:%2F%2Fimages.redgol.cl%2Fjpg%2Ffull%2FRDG_20230928_RDG_144001_porto_benfica-scaled-e1695941062600.jpg&width=1200&height=740) <small>redgol.cl</small>Benfica vs Porto EN VIVO: ¿Dónde ver O Clássico por Primeira Liga?

Benfica-FC Porto Joga-se A 8 De Março às 18h00. Sporting Vai A Braga No Dia Anterior - TSF
------------------------------------------------------------------------------------------

 ![Benfica-FC Porto joga-se a 8 de março às 18h00. Sporting vai a Braga no dia anterior - TSF](https://staticx.noticiasilimitadas.pt/tsf/image.webp?brand=tsf&type=generate&guid=7c437590-c5fb-47d1-b7c8-50a587b03479&w=3840) <small>www.tsf.pt</small>Benfica-FC Porto joga-se a 8 de março às 18h00. Sporting vai a Braga no dia anterior - TSF

Benfica 🆚 Porto | Águia Supera Dragão Com Decisão De Di María | GoalPoint
-------------------------------------------------------------------------

 ![Benfica 🆚 Porto | Águia supera dragão com decisão de Di María | GoalPoint](https://goalpoint.pt/wp-content/uploads/2023/09/GoalPoint-Benfica-Porto-Primeira-Liga-202324.jpg) <small>goalpoint.pt</small>Benfica 🆚 Porto | Águia supera dragão com decisão de Di María | GoalPoint

FC Porto Benfica Resumo Alargado Liga Betclic - SL Benfica
----------------------------------------------------------

 ![FC Porto Benfica Resumo Alargado Liga Betclic - SL Benfica](https://media.slbenfica.pt/-/media/benficadp/images/departamento-de-comunicacao/2025/futebol/competicoes/liga-betclic/8-jornada-fc-porto-benfica/jogo/lukebakio-1-new.jpg?h=725&w=1208&v=638953055690000000&hash=D875750D447A6781D67FC65DDAC648EA) <small>www.slbenfica.pt</small>FC Porto Benfica Resumo Alargado Liga Betclic - SL Benfica

Visão | Benfica E FC Porto Na Abertura Da Jornada Em Jogo Com 'vista' Para O Título
-----------------------------------------------------------------------------------

 ![Visão | Benfica e FC Porto na abertura da jornada em jogo com 'vista' para o título](https://images.trustinnews.pt/uploads/sites/5/2023/04/39698673_wm.jpg) <small>visao.pt</small>Visão | Benfica e FC Porto na abertura da jornada em jogo com 'vista' para o título

Jogo Em Direto FC Porto Benfica Taça Portugal - SL Benfica
----------------------------------------------------------

 ![Jogo em Direto FC Porto Benfica Taça Portugal - SL Benfica](https://media.slbenfica.pt/-/media/benficadp/images/departamento-de-comunicacao/2021/futebol/equipa-a/competicoes/taca-de-portugal/5-eliminatoria-fc-porto-benfica/jogo/grimaldo-classico-thumbnail.jpg?la=pt-pt&v=637758950320000000&hash=8AF9FBDBF7C7FBA9BE16EBF5371971E9) <small>www.slbenfica.pt</small>Jogo em Direto FC Porto Benfica Taça Portugal - SL Benfica

FC Porto 0 - 1 SL Benfica (Relato) Ll Abertura Da Jornada 10 Da I Liga - Golo FM | A Primeira
---------------------------------------------------------------------------------------------

 ![FC Porto 0 - 1 SL Benfica (Relato) ll Abertura da Jornada 10 da I Liga - Golo FM | A Primeira](https://golo.fm/wp-content/uploads/2022/10/Porto-vs-Benfica-21102022-20h15-Capa.png) <small>golo.fm</small>FC Porto 0 - 1 SL Benfica (Relato) ll Abertura da Jornada 10 da I Liga - Golo FM | A Primeira ...

Prognóstico Benfica Vs FC Porto – Liga Portugal
-----------------------------------------------

 ![Prognóstico Benfica vs FC Porto – Liga Portugal](https://bordalo.observador.pt/v2/q:60/rs:fill:980/c:1200:674:nowe:0:0/plain/https://s3.observador.pt/wp-content/uploads/2024/11/08181815/prognostico-benfica-porto.jpg) <small>observador.pt</small>Prognóstico Benfica vs FC Porto – Liga Portugal

FC Porto Benfica Liga Bwin Futebol Imagens - SL Benfica
-------------------------------------------------------

 ![FC Porto Benfica Liga Bwin Futebol Imagens - SL Benfica](https://media.slbenfica.pt/-/media/benficadp/images/departamento-de-comunicacao/2022/galeria-de-fotos/outubro-2022/21/fc-porto-benfica-10-jornada-liga-bwin/classico-galeria-(15).jpg?v=638019882650000000) <small>www.slbenfica.pt</small>FC Porto Benfica Liga Bwin Futebol Imagens - SL Benfica

Onde Assistir Benfica Vs Porto: Canal E Informações | Actualizado Octubre 2026
------------------------------------------------------------------------------

 ![Onde Assistir Benfica vs Porto: Canal e Informações | Actualizado octubre 2026](https://cssjoao.pt/wp-content/uploads/2024/12/liga-24-25-jornada-11-f09f94b4-benfica-vs-porto-f09f94b5-antevisao-e2978f-o-onze-do-benfica-para-o-classico.jpg) <small>cssjoao.pt</small>Onde Assistir Benfica vs Porto: Canal e Informações | Actualizado octubre 2026

AO VIVO - Porto X Benfica
-------------------------

 ![AO VIVO - Porto x Benfica](https://esportenewsmundo.com.br/wp-content/uploads/2022/10/fbl-por-liga-porto-benfica-1.jpg) <small>esportenewsmundo.com.br</small>AO VIVO - Porto x Benfica

Benfica X FC Porto: Onde Assistir E Provável 11
-----------------------------------------------

 ![Benfica x FC Porto: Onde Assistir e Provável 11](https://bordalo.observador.pt/v2/q:60/rs:fill:980/c:3000:1687:nowe:0:156/plain/https://s3.observador.pt/wp-content/uploads/2023/09/29215939/20230929filipeamorim2371.jpg) <small>observador.pt</small>Benfica x FC Porto: Onde Assistir e Provável 11

Os Horários Da 25.ª Jornada Da Liga Portugal Betclic
----------------------------------------------------

 ![Os horários da 25.ª jornada da Liga Portugal Betclic](https://www.zerozero.pt/wimg/n1063410b/1354343-ja-ha-horarios-da-25-jornada-do-campeonato-veja-quando-se-jo.jpg) <small>www.zerozero.pt</small>Os horários da 25.ª jornada da Liga Portugal Betclic

Benfica FC Porto Bruno Lage Pós-jogo Liga - SL Benfica
------------------------------------------------------

 ![Benfica FC Porto Bruno Lage Pós-jogo Liga - SL Benfica](https://media.slbenfica.pt/-/media/benficadp/images/departamento-de-comunicacao/2024/futebol/competicoes/liga-betclic/11-jornada-benfica-fc-porto/jogo/kokcu-1-thumbnail.jpg?la=pt-pt&v=638668723940000000&hash=0CA6897E55CD4FE57C3CC7F8B7906AE7) <small>www.slbenfica.pt</small>Benfica FC Porto Bruno Lage Pós-jogo Liga - SL Benfica

FC Porto 5-0 Benfica :: Liga Portugal Betclic 2023/24 :: Ficha Do Jogo :: Ogol.com.br
-------------------------------------------------------------------------------------

 ![FC Porto 5-0 Benfica :: Liga Portugal Betclic 2023/24 :: Ficha do Jogo :: ogol.com.br](https://www.ogol.com.br/img/galerias/347/1108347_med_liga_portugal_betclic_fc_porto_x_benfica.jpg.jpg) <small>www.ogol.com.br</small>FC Porto 5-0 Benfica :: Liga Portugal Betclic 2023/24 :: Ficha do Jogo :: ogol.com.br

Prognóstico Benfica X Porto - Liga Portugal (08/03/2026)
--------------------------------------------------------

 ![Prognóstico Benfica x Porto - Liga Portugal (08/03/2026)](https://bordalo.observador.pt/v2/q:60/rs:fill:980/c:1927:1084:nowe:0:0/plain/https://s3.observador.pt/wp-content/uploads/2026/03/07092209/prognostico-benfica-porto.jpg) <small>observador.pt</small>Prognóstico Benfica x Porto - Liga Portugal (08/03/2026)

Benfica X Porto: Onde Assistir, Horário E Escalações Do Jogo Pelo Campeonato Português
--------------------------------------------------------------------------------------

 ![Benfica x Porto: onde assistir, horário e escalações do jogo pelo Campeonato Português](https://lncimg.lance.com.br/uploads/2022/10/21/63530d8cc749b.jpeg) <small>www.lance.com.br</small>Benfica x Porto: onde assistir, horário e escalações do jogo pelo Campeonato Português

Benfica Vs Porto: Transmissão, 11 Iniciais, Horários, Classificação E Palpites Para Aposta
------------------------------------------------------------------------------------------

 ![Benfica vs Porto: Transmissão, 11 iniciais, horários, classificação e palpites para aposta](https://imagens.ne10.uol.com.br/veiculos/_midias/jpg/2023/09/28/benfica_e_porto_fizeram_a_final_da_supertaca_de_portugal_23_24-24443779.jpg?6515cdac437f4) <small>interior.ne10.uol.com.br</small>Benfica vs Porto: Transmissão, 11 iniciais, horários, classificação e palpites para aposta

SL Benfica 1 - 2 FC Porto (Relato) | Jornada 27 Da I Liga - Golo FM | A Primeira Rádio Desporto
-----------------------------------------------------------------------------------------------

 ![SL Benfica 1 - 2 FC Porto (Relato) | Jornada 27 da I Liga - Golo FM | A Primeira Rádio Desporto](https://golo.fm/wp-content/uploads/2023/04/Benfica-vs-FC-Porto-07042023-18H-CAPA.png) <small>golo.fm</small>SL Benfica 1 - 2 FC Porto (Relato) | Jornada 27 da I Liga - Golo FM | A Primeira Rádio Desporto

Benfica José Mourinho FC Porto Pós-jogo Taça - SL Benfica
---------------------------------------------------------

 ![Benfica José Mourinho FC Porto Pós-jogo Taça - SL Benfica](https://media.slbenfica.pt/-/media/benficadp/images/departamento-de-comunicacao/2025/futebol/competicoes/taca-de-portugal/quartos-de-final-fc-porto-benfica/jogo/richard-rios-1-thumbnail.jpg?la=pt-pt&v=639040222790000000&hash=1CEA144B53C6C0FBC134B492BC9C8A71) <small>www.slbenfica.pt</small>Benfica José Mourinho FC Porto Pós-jogo Taça - SL Benfica

ZAP Garante A Transmissão Em Directo Do Clássico "FC Porto Vs SL Benfica", Nesta Sexta-feira
--------------------------------------------------------------------------------------------

 ![ZAP garante a transmissão em directo do clássico "FC Porto Vs SL Benfica", nesta sexta-feira](https://mozentretenimento.co.mz/wp-content/uploads/2022/10/af_mz-banner_sm-1080x1080-liga_bwin-porto_x_benfica.png) <small>mozentretenimento.co.mz</small>ZAP garante a transmissão em directo do clássico "FC Porto Vs SL Benfica", nesta sexta-feira ...

Porto Vs Benfica : La Rivalité Du Football Portugais
----------------------------------------------------

 ![Porto vs Benfica : La rivalité du football portugais](https://populaction.com/wp-content/uploads/2025/10/porto-vs-benfica-175.jpeg) <small>populaction.com</small>Porto vs Benfica : La rivalité du football portugais

Benfica 🆚 Porto | “Chocolate” Argentino Em Goleada Da águia | GoalPoint
-----------------------------------------------------------------------

 ![Benfica 🆚 Porto | “Chocolate” argentino em goleada da águia | GoalPoint](https://goalpoint.pt/wp-content/uploads/2024/11/GoalPoint-2024-11-10-Benfica-Porto-Primeira-Liga-202425-90m.jpg) <small>goalpoint.pt</small>Benfica 🆚 Porto | “Chocolate” argentino em goleada da águia | GoalPoint

Benfica Vs Porto - Highlights | Liga Portugal 2023/24
-----------------------------------------------------

 ![Benfica vs Porto - Highlights | Liga Portugal 2023/24](https://thumbor.prod.vidiocdn.com/8DfK2r3pvcS36QsgWLEj_1V04iM=/1280x720/filters:quality(70)/vidio-web-prod-video/uploads/video/image/7683866/hl-babak-1-potuguese-league-benfica-vs-porto-67142d.jpg) <small>www.vidio.com</small>Benfica vs Porto - Highlights | Liga Portugal 2023/24

PRIMEIRA LIGA: CLÁSSICO BENFICA-PORTO JOGA-SE DIA 8 DE MARÇO ÀS 18 HORAS | JORNALONLINE
---------------------------------------------------------------------------------------

 ![PRIMEIRA LIGA: CLÁSSICO BENFICA-PORTO JOGA-SE DIA 8 DE MARÇO ÀS 18 HORAS | JORNALONLINE](https://jornalonline.pt/wp-content/uploads/2026/02/primeira-liga-classico-benfica-porto-joga-se-dia-8-de-marco-as-18-horas-1000x600-1.png) <small>jornalonline.pt</small>PRIMEIRA LIGA: CLÁSSICO BENFICA-PORTO JOGA-SE DIA 8 DE MARÇO ÀS 18 HORAS | JORNALONLINE

Sexta-feira Santa Brindada Com O Clássico Em Portugal: Benfica E FC Porto – RNA
-------------------------------------------------------------------------------

 ![Sexta-feira Santa brindada com o clássico em Portugal: Benfica e FC Porto – RNA](https://rna.ao/rna.ao/wp-content/uploads/2023/04/Benfica-vs-Porto-1.jpg) <small>rna.ao</small>Sexta-feira Santa brindada com o clássico em Portugal: Benfica e FC Porto – RNA

"FC Porto Joga Em Casa, Tem Os Adeptos E Está Confiante. Tem Algum Favoritismo Contra O Benfica"
------------------------------------------------------------------------------------------------

 !["FC Porto joga em casa, tem os adeptos e está confiante. Tem algum favoritismo contra o Benfica"](https://staticx.noticiasilimitadas.pt/oj/image.webp?brand=oj&type=generate&guid=da1fa4d1-a0e7-4e8c-b2c7-23febff6fae7&w=3840) <small>www.ojogo.pt</small>"FC Porto joga em casa, tem os adeptos e está confiante. Tem algum favoritismo contra o Benfica"

FC Porto-Benfica Joga-se A Um Domingo, Dia 6 De Abril, às 20h30 - Renascença
----------------------------------------------------------------------------

 ![FC Porto-Benfica joga-se a um domingo, dia 6 de abril, às 20h30 - Renascença](https://images.rr.pt/43889784468178a919e7defaultlarge_1024.jpg) <small>rr.pt</small>FC Porto-Benfica joga-se a um domingo, dia 6 de abril, às 20h30 - Renascença

Benfica-FC Porto: Os Principais Momentos Do Jogo - SIC Notícias
---------------------------------------------------------------

 ![Benfica-FC Porto: os principais momentos do jogo - SIC Notícias](https://images.impresa.pt/sicnot/2022-05-07-benfica-vs-fc-porto/original) <small>sicnoticias.pt</small>Benfica-FC Porto: os principais momentos do jogo - SIC Notícias

Afinal, Quando Se Vai Jogar O FC Porto-Benfica Na Taça De Portugal? | A Bola
----------------------------------------------------------------------------

 ![Afinal, quando se vai jogar o FC Porto-Benfica na Taça de Portugal? | A Bola](https://sportal365images.com/process/smp-images-production/abola.pt/18122025/46fe17de-fd44-4c45-b0f6-65dac5f2baf1.jpg?operations=crop(0:221:4066:2932)) <small>www.abola.pt</small>Afinal, quando se vai jogar o FC Porto-Benfica na Taça de Portugal? | A Bola

FC Porto 5 - 0 SL Benfica (Relato) | Jornada 24 Da I Liga - Golo FM | A Primeira Rádio Desporto
-----------------------------------------------------------------------------------------------

 ![FC Porto 5 - 0 SL Benfica (Relato) | Jornada 24 da I Liga - Golo FM | A Primeira Rádio Desporto](https://golo.fm/wp-content/uploads/2024/03/Porto-vs-Benfica-03032024-20H30-CAPA.png) <small>golo.fm</small>FC Porto 5 - 0 SL Benfica (Relato) | Jornada 24 da I Liga - Golo FM | A Primeira Rádio Desporto

Liga Portugal - Empate Entre SL Benfica B E FC Porto B
------------------------------------------------------

 ![Liga Portugal - Empate entre SL Benfica B e FC Porto B](https://www.ligaportugal.pt/backoffice/assets/Post_Resultado_630cf1b443.jpg) <small>www.ligaportugal.pt</small>Liga Portugal - Empate entre SL Benfica B e FC Porto B

SL Benfica 1 - 0 FC Porto (Relato) | Jornada 7 Da I Liga - Golo FM | A Primeira Rádio Desporto
----------------------------------------------------------------------------------------------

 ![SL Benfica 1 - 0 FC Porto (Relato) | Jornada 7 da I Liga - Golo FM | A Primeira Rádio Desporto](https://golo.fm/wp-content/uploads/2023/09/Benfica-vs-FC-Porto-29092023-20h15-CAPA.png) <small>golo.fm</small>SL Benfica 1 - 0 FC Porto (Relato) | Jornada 7 da I Liga - Golo FM | A Primeira Rádio Desporto

Clássico: Benfica E FC Porto Frente A Frente Este Domingo! - Golo FM | A Primeira Rádio Desporto
------------------------------------------------------------------------------------------------

 ![Clássico: Benfica e FC Porto frente a frente este domingo! - Golo FM | A Primeira Rádio Desporto](https://golo.fm/wp-content/uploads/2026/03/Benfica-e-FC-Porto.jpg) <small>golo.fm</small>Clássico: Benfica e FC Porto frente a frente este domingo! - Golo FM | A Primeira Rádio Desporto

🔴 BENFICA VS PORTO 🔵 (SUPERTAÇA 23-24) O Ponto Fraco Do Porto Que O Benfica Vai Ter De
--------------------------------------------------------------------------------------

 ![🔴 BENFICA VS PORTO 🔵 (SUPERTAÇA 23-24) O ponto fraco do Porto que o Benfica vai ter de](https://i.ytimg.com/vi/jdrQ-yg8yRg/maxresdefault.jpg) <small>www.youtube.com</small>🔴 BENFICA VS PORTO 🔵 (SUPERTAÇA 23-24) O ponto fraco do Porto que o Benfica vai ter de ...

Primeira liga: clássico benfica-porto joga-se dia 8 de março às 18 horas. Sl benfica 1. Benfica x porto: onde assistir, horário e escalações do jogo pelo campeonato português
