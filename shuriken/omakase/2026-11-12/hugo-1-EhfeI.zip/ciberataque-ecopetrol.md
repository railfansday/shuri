---
title: "Ciberataque Ecopetrol - Industrias petroleras y energéticas, las más afectadas por ciberataques en latinoamérica"
description: "Ecopetrol confirma ciberataque con robo de datos y extorsión a la compañía"
date: "2026-01-18"
categories:
- "Uncategorized"
images:
- "https://img.canal1.com.co/wp-content/uploads/2026/07/17213702/ecopetrol-revela-intento-de-extorsion-tras-ciberataque.jpg?format=auto&amp;width=640"
featuredImage: "https://d2yoo3qu6vrk5d.cloudfront.net/pulzo-lite/images-resized/PP5249367A-h-o.jpg"
featured_image: "https://d2anbic24wxii4.cloudfront.net/uploads/small_article_43744_main_98bc765bfc.png"
image: "https://estaticos.elcolombiano.com/binrepository/785x590/-494c-129/1280d720/none/11101/UJMH/diseno-sin-titulo-57_51231698_20260728114018.jpg"
---

If you are looking for Ciberataque a Ecopetrol: 15 compañías del grupo empresarial están afectadas you've visit to the right page. We have 35 Images about Ciberataque a Ecopetrol: 15 compañías del grupo empresarial están afectadas like Ciberataque a Ecopetrol: 15 compañías del grupo empresarial están afectadas, Ecopetrol confirma ciberataque con robo de datos y extorsión a la compañía and also Ecopetrol: Últimas noticias económicas de Ecopetrol. Here it is:

Ciberataque A Ecopetrol: 15 Compañías Del Grupo Empresarial Están Afectadas
---------------------------------------------------------------------------

 ![Ciberataque a Ecopetrol: 15 compañías del grupo empresarial están afectadas](https://www.vanguardia.com/resizer/v2/ciberataque-a-ecopetrol-15-empresas-del-grupo-empresarial-estan-afectadas-6WUNZANLVRESZLZZXFFG2GEFPI.jpg?auth=177340f49af642d4ba4ba9e60400790f030cead8604f955b3c8bf2e6d3c2ebde&smart=true&width=1200&height=800&quality=70) <small>www.vanguardia.com</small>Ciberataque a Ecopetrol: 15 compañías del grupo empresarial están afectadas

Ecopetrol Activa Nuevos Protocolos Tras Publicación Ilegal De Información Robada En Ciberataque
-----------------------------------------------------------------------------------------------

 ![Ecopetrol activa nuevos protocolos tras publicación ilegal de información robada en ciberataque](https://imagenes2.eltiempo.com/files/image_1200_535/uploads/2026/07/28/6a68b99742c30.png) <small>www.eltiempo.com</small>Ecopetrol activa nuevos protocolos tras publicación ilegal de información robada en ciberataque ...

Ecopetrol Confirma Ciberataque Con Robo De Datos Y Extorsión A La Compañía
--------------------------------------------------------------------------

 ![Ecopetrol confirma ciberataque con robo de datos y extorsión a la compañía](https://www.valoraanalitik.com/wp-content/uploads/2025/11/Ecopetrol.jpg) <small>www.valoraanalitik.com</small>Ecopetrol confirma ciberataque con robo de datos y extorsión a la compañía

Junta Directiva De Ecopetrol Asegura Que No Autorizó El Otrosí Que Tiene Contra Las Cuerdas A Su
------------------------------------------------------------------------------------------------

 ![Junta directiva de Ecopetrol asegura que no autorizó el otrosí que tiene contra las cuerdas a su](https://www.semana.com/resizer/v2/M2AADU62MREMVHBB53O2CLUG4Q.jpg?smart=true&auth=2a981a2c57c24bbfcc3e6b947a0bcf7cebebfa49c1809dc3805ef529a5320479&width=1280&height=720) <small>www.semana.com</small>Junta directiva de Ecopetrol asegura que no autorizó el otrosí que tiene contra las cuerdas a su ...

Ciberataque A Ecopetrol: Filtran Información De 15 Empresas Del Grupo
---------------------------------------------------------------------

 ![Ciberataque a Ecopetrol: filtran información de 15 empresas del grupo](https://www.eluniversal.com.co/resizer/v2/ecopetrol-MQPOUWLPDFF4ZOSCXMVT2KXMHU.jpg?auth=8bbe27fc5ba4583e0d15b41a84411c99f6ef21881f4a7871c1b6d81db2e3f8ce&smart=true&width=1200&height=801&quality=70) <small>www.eluniversal.com.co</small>Ciberataque a Ecopetrol: filtran información de 15 empresas del grupo

Industrias Petroleras Y Energéticas, Las Más Afectadas Por Ciberataques En Latinoamérica
----------------------------------------------------------------------------------------

 ![Industrias petroleras y energéticas, las más afectadas por ciberataques en Latinoamérica](https://www.eluniversal.com.mx/resizer/v2/L7MXCJM3GBDYFCE6BUHAKUOK2I.jpg?auth=8fe16f3d142aa58a1dcd9cd47be595363e4aea283d609287136888e53ad4837a) <small>www.eluniversal.com.mx</small>Industrias petroleras y energéticas, las más afectadas por ciberataques en Latinoamérica ...

Ministerio De Justicia Sufrió Ciberataque Ransomware, Similar Al De Ecopetrol | Justicia
----------------------------------------------------------------------------------------

 ![Ministerio de Justicia sufrió ciberataque ransomware, similar al de Ecopetrol | Justicia](https://caracol.com.co/resizer/v2/MBMMJNPII5E6NFEPUSSIQ7SA5U.png?auth=55563615babd3d3398089f00a5ca6ad3dd219e6ad1130f122c99bb7fd4b144cc&quality=70&width=1200&height=675&smart=true) <small>caracol.com.co</small>Ministerio de Justicia sufrió ciberataque ransomware, similar al de Ecopetrol | Justicia ...

Hackean A Ecopetrol: Empresa Confirma Acceso Ilegal A Miles De Cuentas Y Amenaza De Extorsión
---------------------------------------------------------------------------------------------

 ![Hackean a Ecopetrol: empresa confirma acceso ilegal a miles de cuentas y amenaza de extorsión](https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA289T4u.img?w=768&h=432&m=6) <small>www.msn.com</small>Hackean a Ecopetrol: empresa confirma acceso ilegal a miles de cuentas y amenaza de extorsión

Carlos Gustavo Cano Revela Cómo Petro Lo Sacó De La Presidencia De La Junta De Ecopetrol En 24 Horas
----------------------------------------------------------------------------------------------------

 ![Carlos Gustavo Cano revela cómo Petro lo sacó de la presidencia de la junta de Ecopetrol en 24 horas](https://www.las2orillas.co/wp-content/uploads/2022/10/Ecopetrol-1.jpeg) <small>www.las2orillas.co</small>Carlos Gustavo Cano revela cómo Petro lo sacó de la presidencia de la junta de Ecopetrol en 24 horas

¿Ciberataque A Ecopetrol? Publican Información De 15 Empresas Del Grupo Y La Compañía Pide
------------------------------------------------------------------------------------------

 ![¿Ciberataque a Ecopetrol? Publican información de 15 empresas del grupo y la compañía pide](https://estaticos.elcolombiano.com/binrepository/785x590/-494c-129/1280d720/none/11101/UJMH/diseno-sin-titulo-57_51231698_20260728114018.jpg) <small>www.elcolombiano.com</small>¿Ciberataque a Ecopetrol? Publican información de 15 empresas del grupo y la compañía pide ...

Ecopetrol Confirma Ciberataque: Acceso Ilegal A 3.300 Cuentas
-------------------------------------------------------------

 ![Ecopetrol confirma ciberataque: acceso ilegal a 3.300 cuentas](https://imagenes.portafolio.co/files/image_1200_600/uploads/2024/05/29/66578217eb621.jpeg) <small>www.portafolio.co</small>Ecopetrol confirma ciberataque: acceso ilegal a 3.300 cuentas

Ecopetrol: En Medio De Guerra Interna Y Filtración De Datos Se Eligió Nueva Junta
---------------------------------------------------------------------------------

 ![Ecopetrol: en medio de guerra interna y filtración de datos se eligió nueva junta](https://imagenes2.eltiempo.com/files/og_thumbnail/files/fp/uploads/2024/03/22/65fe13ada9af9.r_d.1777-1921-0.jpeg) <small>www.eltiempo.com</small>Ecopetrol: en medio de guerra interna y filtración de datos se eligió nueva junta

Ciberataque A Ecopetrol: 15 Empresas Del Grupo Afectadas Y Hackers Están Extorsionando Tras
-------------------------------------------------------------------------------------------

 ![Ciberataque a Ecopetrol: 15 empresas del grupo afectadas y hackers están extorsionando tras](https://estaticos.elcolombiano.com/binrepository/848x565/34c0/780d565/none/11101/RVER/ecopetrol-hackeo_51155609_20260717203712.jpg) <small>www.elcolombiano.com</small>Ciberataque a Ecopetrol: 15 empresas del grupo afectadas y hackers están extorsionando tras ...

Ecopetrol Fortalecerá Exploración Y Evalúa Negocios En Venezuela
----------------------------------------------------------------

 ![Ecopetrol fortalecerá exploración y evalúa negocios en Venezuela](https://cronicadelquindio.com/wp-content/uploads/2026/04/Copia-de-MEDIDAS-WEB-WORDPRESS-44-scaled.webp) <small>www.cronicadelquindio.com</small>Ecopetrol fortalecerá exploración y evalúa negocios en Venezuela

Robo A Ecopetrol: Nombres De Empresarios Implicados En Billonario Desfalco
--------------------------------------------------------------------------

 ![Robo a Ecopetrol: nombres de empresarios implicados en billonario desfalco](https://d2yoo3qu6vrk5d.cloudfront.net/pulzo-lite/images-resized/PP2929962-h-o.jpg) <small>www.pulzo.com</small>Robo a Ecopetrol: nombres de empresarios implicados en billonario desfalco

Ciberataque A Ecopetrol: ¿qué Se Sabe Del Acceso A Datos?
---------------------------------------------------------

 ![Ciberataque a Ecopetrol: ¿qué se sabe del acceso a datos?](https://files.lafm.com.co/media/news-images/2025/11/14/131144/ecopetrol-2-1200x675.jpg?w=1200) <small>www.lafm.com.co</small>Ciberataque a Ecopetrol: ¿qué se sabe del acceso a datos?

Ciberataque A Podemos: Roban Los Datos De Los Inscritos Y De Gestión Económica
------------------------------------------------------------------------------

 ![Ciberataque a Podemos: roban los datos de los inscritos y de gestión económica](https://www.catalunyapress.es/images/showid/6814545) <small>www.catalunyapress.es</small>Ciberataque a Podemos: roban los datos de los inscritos y de gestión económica

Ciberataque A Ecopetrol: Qué Información Fue Filtrada Tras El Ataque A 15 Empresas Del Grupo
--------------------------------------------------------------------------------------------

 ![Ciberataque a Ecopetrol: qué información fue filtrada tras el ataque a 15 empresas del grupo](https://d2anbic24wxii4.cloudfront.net/uploads/small_article_43744_main_98bc765bfc.png) <small>cambiocolombia.com</small>Ciberataque a Ecopetrol: qué información fue filtrada tras el ataque a 15 empresas del grupo ...

Ecopetrol Denuncia Ciberataque: Hackean Información De 15 Empresas Del Grupo Y Extorsión - Focus
------------------------------------------------------------------------------------------------

 ![Ecopetrol denuncia ciberataque: hackean información de 15 empresas del grupo y extorsión - Focus](https://focusnoticias.com/wp-content/uploads/2026/07/ecopetrol.jpg) <small>focusnoticias.com</small>Ecopetrol denuncia ciberataque: hackean información de 15 empresas del grupo y extorsión - Focus ...

Ecopetrol Revela Intento De Extorsión Tras Ciberataque - Canal 1
----------------------------------------------------------------

 ![Ecopetrol revela intento de extorsión tras ciberataque - Canal 1](https://img.canal1.com.co/wp-content/uploads/2026/07/17213702/ecopetrol-revela-intento-de-extorsion-tras-ciberataque.jpg?format=auto&width=640) <small>canal1.com.co</small>Ecopetrol revela intento de extorsión tras ciberataque - Canal 1

Ecopetrol Denuncia Robo De Información En 15 Firmas Tras Ciberataque | El Nuevo Siglo
-------------------------------------------------------------------------------------

 ![Ecopetrol denuncia robo de información en 15 firmas tras ciberataque | El Nuevo Siglo](https://www.elnuevosiglo.com.co/sites/default/files/2026-07/Ecopetrol denuncia robo de información en 15 firmas tras ciberataque.png) <small>www.elnuevosiglo.com.co</small>Ecopetrol denuncia robo de información en 15 firmas tras ciberataque | El Nuevo Siglo

Ecopetrol: Fiscalía Investiga Ciberataque Y Filtración De Datos
---------------------------------------------------------------

 ![Ecopetrol: Fiscalía investiga ciberataque y filtración de datos](https://imagenes.portafolio.co/files/main_image_800_600/files/fp/uploads/2026/07/06/6a4bc56196ad0.r_d.402-265.png) <small>www.portafolio.co</small>Ecopetrol: Fiscalía investiga ciberataque y filtración de datos

Salen Dos Vicepresidentes De Ecopetrol
--------------------------------------

 ![Salen dos vicepresidentes de Ecopetrol](https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA28c2Fc.img?w=768&h=432&m=6) <small>www.msn.com</small>Salen dos vicepresidentes de Ecopetrol

Ecopetrol: Últimas Noticias Económicas De Ecopetrol
---------------------------------------------------

 ![Ecopetrol: Últimas noticias económicas de Ecopetrol](https://img.lalr.co/cms/2026/01/20103627/447849425-1.jpg) <small>www.larepublica.co</small>Ecopetrol: Últimas noticias económicas de Ecopetrol

Ecopetrol Anuncia Cambios Directivos Y En Vicepresidencias De La Compañía - Canal 1
-----------------------------------------------------------------------------------

 ![Ecopetrol anuncia cambios directivos y en vicepresidencias de la compañía - Canal 1](https://images.canal1.com.co/wp-content/uploads/2022/11/30153736/Ecopetrol.jpg) <small>canal1.com.co</small>Ecopetrol anuncia cambios directivos y en vicepresidencias de la compañía - Canal 1

Ecopetrol: Fiscalía Investiga Ciberataque Y Filtración De Datos
---------------------------------------------------------------

 ![Ecopetrol: Fiscalía investiga ciberataque y filtración de datos](https://imagenes.portafolio.co/files/image_1200_600/files/fp/uploads/2026/03/24/69c28501ef109.r_d.1500-1000.jpeg) <small>www.portafolio.co</small>Ecopetrol: Fiscalía investiga ciberataque y filtración de datos

Ecopetrol Neutralizó Intento De Ciberataque Con Ransomware Que Afectó Datos De 3.300 Usuarios
---------------------------------------------------------------------------------------------

 ![Ecopetrol neutralizó intento de ciberataque con ransomware que afectó datos de 3.300 usuarios](https://www.elheraldo.co/resizer/v2/FRGYA73H6JHKXEY32WDCYD2YK4.jpg?auth=507084e5d73854add57613d05a30dfe94fe7447cceddbbb32f5bb17ec08560a7&smart=true&width=1200&height=675&quality=70) <small>www.elheraldo.co</small>Ecopetrol neutralizó intento de ciberataque con ransomware que afectó datos de 3.300 usuarios ...

Ecopetrol Activa Nuevos Protocolos Tras Publicación Ilegal De Información Robada En Ciberataque
-----------------------------------------------------------------------------------------------

 ![Ecopetrol activa nuevos protocolos tras publicación ilegal de información robada en ciberataque](https://imagenes2.eltiempo.com/files/image_600_455/uploads/2026/06/20/6a36ff316e7e7.jpeg) <small>www.eltiempo.com</small>Ecopetrol activa nuevos protocolos tras publicación ilegal de información robada en ciberataque ...

Ataque Delincuencial A Infraestructura De Ecopetrol - YouTube
-------------------------------------------------------------

 ![Ataque delincuencial a infraestructura de Ecopetrol - YouTube](https://i.ytimg.com/vi/5d0im2tOHKU/maxresdefault.jpg?sqp=-oaymwEmCIAKENAF8quKqQMa8AEB-AH-CYAC0AWKAgwIABABGDYgSyhyMA8=&rs=AOn4CLCtZ0vKV3YmqL9U1Nb7RtJuxv0cvA) <small>www.youtube.com</small>Ataque delincuencial a infraestructura de Ecopetrol - YouTube

Estos Son Los Nuevos Nombramientos Que Designó Ecopetrol En La Rama Administrativa
----------------------------------------------------------------------------------

 ![Estos son los nuevos nombramientos que designó Ecopetrol en la rama administrativa](https://img.lalr.co/cms/2023/07/26063027/Ecopetrol-2-1.png) <small>www.larepublica.co</small>Estos son los nuevos nombramientos que designó Ecopetrol en la rama administrativa

Ecopetrol Sufrió Hackeo Y Le Robaron 3.300 Cuentas De 15 Empresas
-----------------------------------------------------------------

 ![Ecopetrol sufrió hackeo y le robaron 3.300 cuentas de 15 empresas](https://d2yoo3qu6vrk5d.cloudfront.net/pulzo-lite/images-resized/PP5249367A-h-o.jpg) <small>www.pulzo.com</small>Ecopetrol sufrió hackeo y le robaron 3.300 cuentas de 15 empresas

Alerta Por Ciberataque España: Caos Logístico Y Falta De Peritos - Academia Internacional
-----------------------------------------------------------------------------------------

 ![Alerta por ciberataque España: Caos logístico y falta de peritos - Academia Internacional](https://academiacriminalistica.com/wp-content/uploads/2026/03/ciberataque-espana-1024x683.webp) <small>academiacriminalistica.com</small>Alerta por ciberataque España: Caos logístico y falta de peritos - Academia Internacional ...

Robo A Ecopetrol: Así Era La Elaborada Operación Para Exportar Petróleo Ilegal Y Así Va La
------------------------------------------------------------------------------------------

 ![Robo a Ecopetrol: así era la elaborada operación para exportar petróleo ilegal y así va la](https://estaticos.elcolombiano.com/binrepository/780x565/0c0/780d565/none/11101/VYFW/ecopetrol-robo_42913824_20230727062057.jpg) <small>www.elcolombiano.com</small>Robo a Ecopetrol: así era la elaborada operación para exportar petróleo ilegal y así va la ...

Ecopetrol Confirma Ciberataque: Acceso Ilegal A 3.300 Cuentas
-------------------------------------------------------------

 ![Ecopetrol confirma ciberataque: acceso ilegal a 3.300 cuentas](https://imagenes.portafolio.co/files/main_image_800_600/files/fp/uploads/2025/11/12/6915001dac82d.r_d.838-402.png) <small>www.portafolio.co</small>Ecopetrol confirma ciberataque: acceso ilegal a 3.300 cuentas

Ecopetrol Confirma Ciberataque Con Robo De Datos Y Extorsión A La Compañía
--------------------------------------------------------------------------

 ![Ecopetrol confirma ciberataque con robo de datos y extorsión a la compañía](https://www.valoraanalitik.com/wp-content/uploads/2026/07/Ecopetrol-confirma-ciberataque-con-robo-de-datos-y-extorsion-a-la-compania.jpg) <small>www.valoraanalitik.com</small>Ecopetrol confirma ciberataque con robo de datos y extorsión a la compañía

¿ciberataque a ecopetrol? publican información de 15 empresas del grupo y la compañía pide. ecopetrol sufrió hackeo y le robaron 3.300 cuentas de 15 empresas. ecopetrol confirma ciberataque: acceso ilegal a 3.300 cuentas
