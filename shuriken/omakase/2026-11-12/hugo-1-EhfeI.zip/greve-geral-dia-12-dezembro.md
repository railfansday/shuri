---
title: "Greve Geral Dia 12 Dezembro - Aviso à comunidade educativa – greve"
description: "Sdp sul"
date: "2026-05-09"
categories:
- "Uncategorized"
images:
- "https://images.impresa.pt/expresso/2025-11-27-greve-geral-anuncio-para-a-realizacao-de-greve-a-11-de-dezembro-marques-pombal--9b289114/original"
featuredImage: "https://static.wixstatic.com/media/d0f32c_9ff1199ee2c34418af0094a43c516733~mv2.png/v1/fill/w_940,h_788,al_c,q_90,enc_avif,quality_auto/d0f32c_9ff1199ee2c34418af0094a43c516733~mv2.png"
featured_image: "https://www.escolasdemira.pt/images/PR-_AVISO_DE_GREVE_para_os_dias_11_e_12_de_dezembro_de_2025.png"
image: "https://ecoonline.s3.amazonaws.com/uploads/2025/12/46141990.jpg"
---

If you are looking for Greve geral vista das ruas: manhã cinzenta, autocarros vazios e um país que abrandou o passo you've visit to the right page. We have 35 Pictures about Greve geral vista das ruas: manhã cinzenta, autocarros vazios e um país que abrandou o passo like Depois da Greve Geral, mais uma paralisação marcada para 12 de dezembro | A Bola, UGT vai reunir-se com ministra do Trabalho mas avisa que "é impossível negociar" sozinha a and also Aviso Prévio de Greves - 11 e 12 de dezembro 2025. Read more:

Greve Geral Vista Das Ruas: Manhã Cinzenta, Autocarros Vazios E Um País Que Abrandou O Passo
--------------------------------------------------------------------------------------------

 ![Greve geral vista das ruas: manhã cinzenta, autocarros vazios e um país que abrandou o passo](https://images.impresa.pt/expresso/2025-12-11-fox_greve_geral_0018.jpg-6e16cd12-1) <small>expresso.pt</small>Greve geral vista das ruas: manhã cinzenta, autocarros vazios e um país que abrandou o passo ...

Greve Geral Em Portugal – 11 De Dezembro - FLEMACON
---------------------------------------------------

 ![Greve geral em Portugal – 11 de dezembro - FLEMACON](https://www.flemacon.org/wp-content/uploads/2025/12/WhatsApp-Image-2025-12-12-at-19.45.27-1-696x870.jpeg) <small>www.flemacon.org</small>Greve geral em Portugal – 11 de dezembro - FLEMACON

11 De Dezembro. Portugal Terá A Sua Primeira Greve Geral Em 12 Anos Contra O Pacote Laboral
-------------------------------------------------------------------------------------------

 ![11 de Dezembro. Portugal terá a sua primeira Greve Geral em 12 anos contra o pacote laboral](https://www.esquerdadiario.com.br/IMG/logo/imagem_do_whatsapp_de_2025-11-18_a_s_20.02_31_2e7bdf41.jpg?1763508227) <small>www.esquerdadiario.com.br</small>11 de Dezembro. Portugal terá a sua primeira Greve Geral em 12 anos contra o pacote laboral ...

CGIL: Greve Geral No Dia 12 De Dezembro Para Protestar Contra A Lei Orçamental - Rádio Miróbriga
------------------------------------------------------------------------------------------------

 ![CGIL: greve geral no dia 12 de dezembro para protestar contra a lei orçamental - Rádio Miróbriga](https://www.radiom24.pt/wp-content/uploads/2025/11/CGIL-greve-geral-no-dia-12-de-dezembro-para-protestar.jpg) <small>www.radiom24.pt</small>CGIL: greve geral no dia 12 de dezembro para protestar contra a lei orçamental - Rádio Miróbriga

Transportes, Hospitais, Escolas E Até Bancos. Que Setores Vão Ser Afetados Pela Greve Geral? – ECO
--------------------------------------------------------------------------------------------------

 ![Transportes, hospitais, escolas e até bancos. Que setores vão ser afetados pela greve geral? – ECO](https://ecoonline.s3.amazonaws.com/uploads/2025/12/46141990.jpg) <small>eco.sapo.pt</small>Transportes, hospitais, escolas e até bancos. Que setores vão ser afetados pela greve geral? – ECO

FAQ: Os Direitos Dos Docentes Em Dia De Greve Geral - 11/12/2025
----------------------------------------------------------------

 ![FAQ: Os direitos dos docentes em dia de Greve Geral - 11/12/2025](https://static.wixstatic.com/media/d0f32c_9ff1199ee2c34418af0094a43c516733~mv2.png/v1/fill/w_940,h_788,al_c,q_90,enc_avif,quality_auto/d0f32c_9ff1199ee2c34418af0094a43c516733~mv2.png) <small>www.sprc.pt</small>FAQ: Os direitos dos docentes em dia de Greve Geral - 11/12/2025

SDP Sul
-------

 ![SDP Sul](https://sdpsul.com/storage/publicacao/imagem_563_6929dba6ddf62.jpeg) <small>sdpsul.com</small>SDP Sul

15 Minutos: Impacto Da Greve Geral Já Se Começou A Sentir No Setor Dos Transportes - SIC Notícias
-------------------------------------------------------------------------------------------------

 ![15 minutos: impacto da greve geral já se começou a sentir no setor dos transportes - SIC Notícias](https://images.impresa.pt/sicnot/2025-12-12-greve-geral-045a9380/1.91x1?wm=true&outputFormat=jpeg) <small>sicnoticias.pt</small>15 minutos: impacto da greve geral já se começou a sentir no setor dos transportes - SIC Notícias

Greve Geral Juntou Centenas Nos Aliados. Governo Fala Em Adesão "inexpressiva" - JPN
------------------------------------------------------------------------------------

 ![Greve Geral juntou centenas nos Aliados. Governo fala em adesão "inexpressiva" - JPN](https://www.jpn.up.pt/wp-content/uploads/2025/12/greve_geral9.jpg) <small>www.jpn.up.pt</small>Greve Geral juntou centenas nos Aliados. Governo fala em adesão "inexpressiva" - JPN

Após Greve Geral, Sindicatos Querem «rasgar» Pacote Laboral | OLN - Aveiro On Line News
---------------------------------------------------------------------------------------

 ![Após greve geral, sindicatos querem «rasgar» pacote laboral | OLN - Aveiro On Line News](https://oln.pt/wp-content/uploads/2025/12/manif51.jpg) <small>oln.pt</small>Após greve geral, sindicatos querem «rasgar» pacote laboral | OLN - Aveiro On Line News

SPN - Fenprof — Adesão Histórica à Greve Geral
----------------------------------------------

 ![SPN - Fenprof — Adesão histórica à greve geral](https://www.spn.pt/Media/Default/Info/68000/500/60/7/grevegeral11dez_cartaz.jpg) <small>www.spn.pt</small>SPN - Fenprof — Adesão histórica à greve geral

Greve: Pré-aviso De Greve Para Dia 12 De Novembro - APEVI | Associação De Pais Da Escola Da
-------------------------------------------------------------------------------------------

 ![Greve: Pré-aviso de greve para dia 12 de Novembro - APEVI | Associação de Pais da Escola da](https://apevi.pt/wp-content/uploads/2021/11/2021-11-12-greve-stal.png) <small>apevi.pt</small>Greve: Pré-aviso de greve para dia 12 de Novembro - APEVI | Associação de Pais da Escola da ...

Pré-avisos De Greve – Dias 11 E 12 De Dezembro 2025 – AE Terras Do Ave
----------------------------------------------------------------------

 ![Pré-avisos de greve – dias 11 e 12 de dezembro 2025 – AE Terras do Ave](https://aeterrasave.net/wp-content/uploads/2025/12/Greves-11-e-12-dezembro.png) <small>aeterrasave.net</small>Pré-avisos de greve – dias 11 e 12 de dezembro 2025 – AE Terras do Ave

Greve Geral E Surreal – Hoje Macau
----------------------------------

 ![Greve geral e surreal – Hoje Macau](https://hojemacau.com.mo/wp-content/uploads/2025/12/greve-geral-lisboa.jpg) <small>hojemacau.com.mo</small>Greve geral e surreal – Hoje Macau

Motivos Da Adesão à Greve Geral De 11 De Dezembro De 2025
---------------------------------------------------------

 ![Motivos da adesão à Greve Geral de 11 de dezembro de 2025](https://spzn.pt/uploads/noticias/big_1763717239_6728_SPZN_2025_site_novo_(17).png) <small>spzn.pt</small>Motivos da adesão à Greve Geral de 11 de dezembro de 2025

Greve Geral Juntou Centenas Nos Aliados. Governo Fala Em Adesão "inexpressiva" - JPN
------------------------------------------------------------------------------------

 ![Greve Geral juntou centenas nos Aliados. Governo fala em adesão "inexpressiva" - JPN](https://www.jpn.up.pt/wp-content/uploads/2025/12/greve_geral8.jpg) <small>www.jpn.up.pt</small>Greve Geral juntou centenas nos Aliados. Governo fala em adesão "inexpressiva" - JPN

Concurso Externo Extraordinário De Docentes 2025/2026 – 28 De Outubro A 14 De Novembro – Aviso
----------------------------------------------------------------------------------------------

 ![Concurso Externo Extraordinário de Docentes 2025/2026 – 28 de outubro a 14 de novembro – Aviso](https://stop-sindicato.pt/wp-content/uploads/2025/11/S.TO_.P.-Cartaz-Greve-Geral-Educacao-11Dez2025_x1000-768x1086.png) <small>stop-sindicato.pt</small>Concurso Externo Extraordinário de Docentes 2025/2026 – 28 de outubro a 14 de novembro – Aviso ...

UGT Vai Reunir-se Com Ministra Do Trabalho Mas Avisa Que "é Impossível Negociar" Sozinha A
------------------------------------------------------------------------------------------

 ![UGT vai reunir-se com ministra do Trabalho mas avisa que "é impossível negociar" sozinha a](https://img.iol.pt/image/id/693b2a1ad34e3caad84c47e9/1024.jpg) <small>cnnportugal.iol.pt</small>UGT vai reunir-se com ministra do Trabalho mas avisa que "é impossível negociar" sozinha a ...

Aviso Prévio De Greves - 11 E 12 De Dezembro 2025
-------------------------------------------------

 ![Aviso Prévio de Greves - 11 e 12 de dezembro 2025](https://aefernandopessoafeira.pt/images/noticias/2025/aviso-previo-de-greve/aviso-previo-de-greve.jpg) <small>aefernandopessoafeira.pt</small>Aviso Prévio de Greves - 11 e 12 de dezembro 2025

Pré-Aviso De Greve 11 E 12 De Dezembro
--------------------------------------

 ![Pré-Aviso de Greve 11 e 12 de dezembro](https://static.wixstatic.com/media/1029eb_a6db1017a2334a9abf146e02d7454c28~mv2.png/v1/fill/w_770,h_395,al_c,lg_1,q_85/1029eb_a6db1017a2334a9abf146e02d7454c28~mv2.png) <small>www.aecadaval.com</small>Pré-Aviso de Greve 11 e 12 de dezembro

Greve Geral A 11 De Dezembro | Sindicato Dos Quadros Técnicos Do Estado
-----------------------------------------------------------------------

 ![Greve Geral a 11 de Dezembro | Sindicato dos Quadros Técnicos do Estado](https://www.ste.pt/wp-content/uploads/2025/12/GreveGeral-Cartaz-scaled.jpg) <small>www.ste.pt</small>Greve Geral a 11 de Dezembro | Sindicato dos Quadros Técnicos do Estado

AVISO À COMUNIDADE EDUCATIVA – GREVE | 11 E 12 De Dezembro De 2025
------------------------------------------------------------------

 ![AVISO À COMUNIDADE EDUCATIVA – GREVE | 11 e 12 de dezembro de 2025](https://aealcabideche.pt/images/Informações/2025-2026/Greve_11_12_dezembro.png) <small>aealcabideche.pt</small>AVISO À COMUNIDADE EDUCATIVA – GREVE | 11 e 12 de dezembro de 2025

Greve Geral. Metro De Lisboa Prevê Paralisação Do Serviço E Encerramento Das Estações – ECO
-------------------------------------------------------------------------------------------

 ![Greve Geral. Metro de Lisboa prevê paralisação do serviço e encerramento das estações – ECO](https://eco.imgix.net/uploads/2025/12/thumb-1.jpg) <small>eco.sapo.pt</small>Greve Geral. Metro de Lisboa prevê paralisação do serviço e encerramento das estações – ECO

Comunicado E Esclarecimentos - Greve Semana 12-17 Dezembro - YouTube
--------------------------------------------------------------------

 ![Comunicado e Esclarecimentos - Greve Semana 12-17 Dezembro - YouTube](https://i.ytimg.com/vi/CoRuIZF3jRU/maxresdefault.jpg) <small>www.youtube.com</small>Comunicado e Esclarecimentos - Greve Semana 12-17 Dezembro - YouTube

Greve Geral Paralisa Portugal Contra Precarização De Direitos
-------------------------------------------------------------

 ![Greve geral paralisa Portugal contra precarização de direitos](https://pcdob.org.br/wp-content/uploads/2025/12/Ruas-de-Lisboa-foram-tomadas-por-trabalhadores-durante-a-greve-geral-Rafael-Medeiros-Esquerda.jpg) <small>pcdob.org.br</small>Greve geral paralisa Portugal contra precarização de direitos

Sindicatos Independentes Aderem à Greve Geral Pela Primeira Vez E Juntam-se à UGT E CGTP - Expresso
---------------------------------------------------------------------------------------------------

 ![Sindicatos independentes aderem à greve geral pela primeira vez e juntam-se à UGT e CGTP - Expresso](https://images.impresa.pt/expresso/2025-11-27-greve-geral-anuncio-para-a-realizacao-de-greve-a-11-de-dezembro-marques-pombal--9b289114/original) <small>expresso.pt</small>Sindicatos independentes aderem à greve geral pela primeira vez e juntam-se à UGT e CGTP - Expresso

Agrupamento De Escolas De Mira - Pré - Aviso De Greve Para Os Dias 11 E 12 De Dezembro De 2025
----------------------------------------------------------------------------------------------

 ![Agrupamento de Escolas de Mira - Pré - aviso de greve para os dias 11 e 12 de dezembro de 2025](https://www.escolasdemira.pt/images/PR-_AVISO_DE_GREVE_para_os_dias_11_e_12_de_dezembro_de_2025.png) <small>www.escolasdemira.pt</small>Agrupamento de Escolas de Mira - Pré - aviso de greve para os dias 11 e 12 de dezembro de 2025

Agora é GREVE GERAL!
--------------------

 ![Agora é GREVE GERAL!](https://jundiagora.com.br/wp-content/uploads/2023/01/greve-geral.jpg) <small>jundiagora.com.br</small>Agora é GREVE GERAL!

Depois Da Greve Geral, Mais Uma Paralisação Marcada Para 12 De Dezembro | A Bola
--------------------------------------------------------------------------------

 ![Depois da Greve Geral, mais uma paralisação marcada para 12 de dezembro | A Bola](https://sportal365images.com/process/smp-images-production/abola.pt/09122025/6efc249f-1534-4fe0-94ae-f9c29c518ecd.webp?operations=scale(860:574)) <small>www.abola.pt</small>Depois da Greve Geral, mais uma paralisação marcada para 12 de dezembro | A Bola

FENPROF Fará Avaliação Da Adesão à Greve, Pelas 11h30 De Dia 12, Junto à EB 2.3 Marquesa De
-------------------------------------------------------------------------------------------

 ![FENPROF fará avaliação da adesão à greve, pelas 11h30 de dia 12, junto à EB 2.3 Marquesa de](https://www.fenprof.pt/media/download/7DAA3F336B31A82D27D0CF5E99371080/cartazgreve12_nov.png) <small>www.fenprof.pt</small>FENPROF fará avaliação da adesão à greve, pelas 11h30 de dia 12, junto à EB 2.3 Marquesa de ...

As Maiores Greves Gerais Que O Brasil Já Viu | Exame
----------------------------------------------------

 ![As maiores greves gerais que o Brasil já viu | Exame](https://classic.exame.com/wp-content/uploads/2017/04/1986-greve-geral-12-de-dezembro.jpg) <small>exame.com</small>As maiores greves gerais que o Brasil já viu | Exame

FENPROF Converge Com Os Restantes Setores Da Administração Pública E Envia Pré-aviso De Greve
---------------------------------------------------------------------------------------------

 ![FENPROF converge com os restantes setores da Administração Pública e envia pré-aviso de greve](https://www.fenprof.pt/media/download/6724C9782B10A339D0E76BFD41D4E50B/greveap_12nov21.jpg) <small>www.fenprof.pt</small>FENPROF converge com os restantes setores da Administração Pública e envia pré-aviso de greve ...

Greve Geral: Escolas Fechadas, Transportes Parados E Impacto Nacional
---------------------------------------------------------------------

 ![Greve Geral: Escolas Fechadas, Transportes Parados e Impacto Nacional](https://media.assettype.com/dn%2F2025-12-11%2F9hy4apil%2Fgreve-geral.jpg?w=768&auto=format%2Ccompress) <small>www.dn.pt</small>Greve Geral: Escolas Fechadas, Transportes Parados e Impacto Nacional

Unificar As Lutas, Rumo à Construção Da Greve Geral - Liga Internacional Dos TrabalhadoresLiga
----------------------------------------------------------------------------------------------

 ![Unificar as lutas, rumo à construção da greve geral - Liga Internacional dos TrabalhadoresLiga](https://litci.org/pt/wp-content/uploads/2022/11/Portugal.jpeg) <small>litci.org</small>Unificar as lutas, rumo à construção da greve geral - Liga Internacional dos TrabalhadoresLiga ...

Saiba Tudo Sobre A Greve Geral De Amanhã
----------------------------------------

 ![Saiba tudo sobre a greve geral de Amanhã](https://jornaldemafra.pt/wp-content/uploads/2025/12/greve-geral.webp) <small>jornaldemafra.pt</small>Saiba tudo sobre a greve geral de Amanhã

As maiores greves gerais que o brasil já viu. Saiba tudo sobre a greve geral de amanhã. Greve geral: escolas fechadas, transportes parados e impacto nacional
