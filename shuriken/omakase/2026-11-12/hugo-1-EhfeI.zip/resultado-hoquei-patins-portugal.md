---
title: "Resultado Hoquei Patins Portugal - Hóquei em patins: resultados, classificação e próxima jornada"
description: "Parlamento felicita hóquei e canoagem por resultados obtidos – observador"
date: "2026-09-22"
categories:
- "Uncategorized"
images:
- "https://images.impresa.pt/sicnot/2025-09-06-portugal-hoquei-patins-europeu-.jpg-bc010317/original"
featuredImage: "https://livesport-ott-images.ssl.cdn.cra.cz/r1200xfq60/4f55eb8f-122e-4e57-8a75-276291d152d1.jpeg"
featured_image: "https://livesport-ott-images.ssl.cdn.cra.cz/r1200xfq60/8e07ce90-a43f-46f1-98d9-557610ca2c83.jpeg"
image: "https://livesport-ott-images.ssl.cdn.cra.cz/r1200xfq60/91e55642-70b3-4f20-baaf-3b90fc0a92cf.jpeg"
---

If you are looking for Portugal conquista torneio Golden Cat - JN you've visit to the right place. We have 35 Pics about Portugal conquista torneio Golden Cat - JN like Portugal supera França e conquista título europeu de hóquei em patins - Hóquei em Patins, Portugal conquista pela 22ª vez o Campeonato da Europa de Hóquei em Patins - RFI and also Hóquei em patins: As declarações após o Portugal - Espanha (2-2, 3-2 g.p) | Flashscore.pt. Here it is:

Portugal Conquista Torneio Golden Cat - JN
------------------------------------------

 ![Portugal conquista torneio Golden Cat - JN](https://staticx.noticiasilimitadas.pt/jn/image.webp?brand=jn&type=generate&guid=b92d86e9-47bf-451d-acc5-6d1afb5ebea3&w=3840) <small>www.jn.pt</small>Portugal conquista torneio Golden Cat - JN

Hóquei Em Patins: Resultados, Classificação E Próxima Jornada
-------------------------------------------------------------

 ![Hóquei em patins: resultados, classificação e próxima jornada](https://staticx.noticiasilimitadas.pt/oj/image.webp?brand=oj&type=generate&guid=1ef4d259-fc5a-4f10-a288-a7f500387c2f&w=3840) <small>www.ojogo.pt</small>Hóquei em patins: resultados, classificação e próxima jornada

Hóquei Em Patins: As Declarações Após O Portugal - Espanha (2-2, 3-2 G.p) | Flashscore.pt
-----------------------------------------------------------------------------------------

 ![Hóquei em patins: As declarações após o Portugal - Espanha (2-2, 3-2 g.p) | Flashscore.pt](https://livesport-ott-images.ssl.cdn.cra.cz/r1200xfq60/97cb2f6f-df41-4381-8523-45b5bdefd57c.jpeg) <small>www.flashscore.pt</small>Hóquei em patins: As declarações após o Portugal - Espanha (2-2, 3-2 g.p) | Flashscore.pt

Hóquei Em Patins: Resultados Dos 16 Avos De Final Da Taça De Portugal
---------------------------------------------------------------------

 ![Hóquei em patins: resultados dos 16 avos de final da Taça de Portugal](https://staticx.noticiasilimitadas.pt/oj/image.webp?brand=oj&type=generate&guid=b560c601-ebb2-47c3-8ae3-2bd723d74072&w=3840) <small>www.ojogo.pt</small>Hóquei em patins: resultados dos 16 avos de final da Taça de Portugal

Portugal Vence França E Já Tem Adversário Nas Meias De Final Do Mundial De Hóquei Em Patins
-------------------------------------------------------------------------------------------

 ![Portugal vence França e já tem adversário nas meias de final do Mundial de Hóquei em Patins](https://binny-bolanarede.b-cdn.net/wp-content/uploads/2024/03/FPP_4333-scaled-1.jpg) <small>bolanarede.pt</small>Portugal vence França e já tem adversário nas meias de final do Mundial de Hóquei em Patins

Hóquei Em Patins: Final Four Da Taça De Portugal Sem Equipas Do Minho | E24.pt
------------------------------------------------------------------------------

 ![Hóquei em Patins: Final Four da Taça de Portugal sem equipas do Minho | e24.pt](https://e24.pt/wp-content/uploads/2025/03/hoquei-em-patins-1-819x1024.jpeg) <small>e24.pt</small>Hóquei em Patins: Final Four da Taça de Portugal sem equipas do Minho | e24.pt

Hóquei Em Patins: Portugal Lidera Grupo A Do Europeu - O Atleta
---------------------------------------------------------------

 ![Hóquei em patins: Portugal lidera grupo A do Europeu - O Atleta](https://oatleta.pt/wp-content/uploads/2023/07/FPP.jpg) <small>oatleta.pt</small>Hóquei em patins: Portugal lidera grupo A do Europeu - O Atleta

Portugal Derrota Espanha Nos Penáltis E Avança Para A Final Do Europeu De Hóquei Em Patins
------------------------------------------------------------------------------------------

 ![Portugal derrota Espanha nos penáltis e avança para a final do Europeu de Hóquei em patins](https://cdn.cmjornal.pt/images/2025-09/img_1500x1000uu2025-09-06-00-16-07-2233548.png) <small>www.cmjornal.pt</small>Portugal derrota Espanha nos penáltis e avança para a final do Europeu de Hóquei em patins ...

Portugal Vence Grupo A Do Europeu De Hóquei Em Patins De Sub-19 | Flashscore.pt
-------------------------------------------------------------------------------

 ![Portugal vence Grupo A do Europeu de hóquei em patins de sub-19 | Flashscore.pt](https://livesport-ott-images.ssl.cdn.cra.cz/r1200xfq60/04e59b1b-f1c8-4068-afd4-89f687304f71.jpeg) <small>www.flashscore.pt</small>Portugal vence Grupo A do Europeu de hóquei em patins de sub-19 | Flashscore.pt

Mundial Hóquei Em Patins. Portugal Vence França E Está Nas Meias Finais
-----------------------------------------------------------------------

 ![Mundial Hóquei em Patins. Portugal vence França e está nas meias finais](https://cdn-images.rtp.pt/icm/images/c6/c67bb2a7c461580ea5f2034d034103ef_N.jpg?) <small>www.rtp.pt</small>Mundial Hóquei em Patins. Portugal vence França e está nas meias finais

Hóquei Em Patins: FC Porto Conquista (3-2) A Taça De Portugal | Flashscore.pt
-----------------------------------------------------------------------------

 ![Hóquei em patins: FC Porto conquista (3-2) a Taça de Portugal | Flashscore.pt](https://livesport-ott-images.ssl.cdn.cra.cz/r1200xfq60/7a7326e3-711f-4e2f-8687-c8c25473cb41.jpeg) <small>www.flashscore.pt</small>Hóquei em patins: FC Porto conquista (3-2) a Taça de Portugal | Flashscore.pt

Hóquei Em Patins: Portugal Com “único Objetivo” De Ser Campeão | Flashscore.pt
------------------------------------------------------------------------------

 ![Hóquei em patins: Portugal com “único objetivo” de ser campeão | Flashscore.pt](https://livesport-ott-images.ssl.cdn.cra.cz/r1200xfq60/7cfdb855-accc-4fce-8655-e69d1fc2f968.jpeg) <small>www.flashscore.pt</small>Hóquei em patins: Portugal com “único objetivo” de ser campeão | Flashscore.pt

Hóquei Em Patins: Sporting Vence Póvoa (4-0) E Está Na Final Da Taça De Portugal | Flashscore.pt
------------------------------------------------------------------------------------------------

 ![Hóquei em patins: Sporting vence Póvoa (4-0) e está na final da Taça de Portugal | Flashscore.pt](https://livesport-ott-images.ssl.cdn.cra.cz/r900xfq60/8403d780-0e2e-46e9-af68-54c47bb43d2c.jpeg) <small>www.flashscore.pt</small>Hóquei em patins: Sporting vence Póvoa (4-0) e está na final da Taça de Portugal | Flashscore.pt

Parlamento Felicita Hóquei E Canoagem Por Resultados Obtidos – Observador
-------------------------------------------------------------------------

 ![Parlamento felicita hóquei e canoagem por resultados obtidos – Observador](https://bordalo.observador.pt/v2/q:60/rs:fill:980/c:2000:1121:nowe:0:0/plain/https://s3.observador.pt/wp-content/uploads/2025/09/06233526/45612606.jpg) <small>observador.pt</small>Parlamento felicita hóquei e canoagem por resultados obtidos – Observador

Hóquei Em Patins: As Declarações Dos Protagonistas Após O Portugal-Itália (4-1) | Flashscore.pt
-----------------------------------------------------------------------------------------------

 ![Hóquei em patins: As declarações dos protagonistas após o Portugal-Itália (4-1) | Flashscore.pt](https://livesport-ott-images.ssl.cdn.cra.cz/r1200xfq60/a0a18377-4caa-4bd1-87c4-62c0ac9191ea.jpeg) <small>www.flashscore.pt</small>Hóquei em patins: As declarações dos protagonistas após o Portugal-Itália (4-1) | Flashscore.pt

Hóquei Em Patins: Declarações Após O Espanha-Portugal (7-2) Na Final Do Europeu Feminino
----------------------------------------------------------------------------------------

 ![Hóquei em patins: Declarações após o Espanha-Portugal (7-2) na final do Europeu feminino](https://livesport-ott-images.ssl.cdn.cra.cz/r1200xfq60/e66d21a8-6092-4c9b-8728-951de92cd8a1.jpeg) <small>www.flashscore.pt</small>Hóquei em patins: Declarações após o Espanha-Portugal (7-2) na final do Europeu feminino ...

Hóquei Em Patins: Portugal Perde Frente à Espanha (3-1) E Continua Maré Negra No Euro
-------------------------------------------------------------------------------------

 ![Hóquei em patins: Portugal perde frente à Espanha (3-1) e continua maré negra no Euro](https://livesport-ott-images.ssl.cdn.cra.cz/r1200xfq60/631856a2-c314-4ffc-9889-f10c140c45d2.jpeg) <small>www.flashscore.pt</small>Hóquei em patins: Portugal perde frente à Espanha (3-1) e continua maré negra no Euro ...

Portugal Conquista Pela 22ª Vez O Campeonato Da Europa De Hóquei Em Patins - RFI
--------------------------------------------------------------------------------

 ![Portugal conquista pela 22ª vez o Campeonato da Europa de Hóquei em Patins - RFI](https://s.rfi.fr/media/display/34ec323a-8bf9-11f0-9f49-005056a97e36/w:1024/p:16x9/DOC-20250907-45612869-MAR-7756.jpg) <small>www.rfi.fr</small>Portugal conquista pela 22ª vez o Campeonato da Europa de Hóquei em Patins - RFI

Hóquei Em Patins: Portugal Vence Espanha (4-2) E Está Nas Meias-finais Da Taça Das Nações
-----------------------------------------------------------------------------------------

 ![Hóquei em patins: Portugal vence Espanha (4-2) e está nas meias-finais da Taça das Nações](https://livesport-ott-images.ssl.cdn.cra.cz/r1200xfq60/91e55642-70b3-4f20-baaf-3b90fc0a92cf.jpeg) <small>www.flashscore.pt</small>Hóquei em patins: Portugal vence Espanha (4-2) e está nas meias-finais da Taça das Nações ...

Benfica Tojal Final Taça Portugal Hóquei Fotos - SL Benfica
-----------------------------------------------------------

 ![Benfica Tojal Final Taça Portugal Hóquei Fotos - SL Benfica](https://media.slbenfica.pt/-/media/benficadp/images/departamento-de-comunicacao/2023/galeria-de-fotos/julho-2024/14/taca-de-portugal-hoquei-feminino/taca-de-portugal-(12).jpg?v=638565740060000000) <small>www.slbenfica.pt</small>Benfica Tojal Final Taça Portugal Hóquei Fotos - SL Benfica

Hóquei Em Patins: Portugal Campeão Do Mundo E Angola No 6° Lugar - Desporto
---------------------------------------------------------------------------

 ![Hóquei em Patins: Portugal campeão do Mundo e Angola no 6° lugar - Desporto](https://s.rfi.fr/media/display/eeeaf066-10cd-11ea-9b5d-005056a99247/portugal_-_hoquei_em_patins_-_mundial.jpg) <small>www.rfi.fr</small>Hóquei em Patins: Portugal campeão do Mundo e Angola no 6° lugar - Desporto

Hóquei Em Patins. Portugal é Campeão Da Europa - Renascença
-----------------------------------------------------------

 ![Hóquei em patins. Portugal é campeão da Europa - Renascença](https://images.rr.pt/45612608193640ad63fedefaultlarge_1024.jpg) <small>rr.pt</small>Hóquei em patins. Portugal é campeão da Europa - Renascença

Hóquei Em Patins: Resultados Dos Oitavos De Final Da Taça De Portugal
---------------------------------------------------------------------

 ![Hóquei em patins: resultados dos oitavos de final da Taça de Portugal](https://staticx.noticiasilimitadas.pt/oj/2709ff79-e842-4d23-b44d-daf256277151_1200x675.jpg) <small>www.ojogo.pt</small>Hóquei em patins: resultados dos oitavos de final da Taça de Portugal

Portugal é Campeão Da Europa De Sub-23 De Hóquei Em Patins
----------------------------------------------------------

 ![Portugal é campeão da Europa de Sub-23 de Hóquei em Patins](https://binny-bolanarede.b-cdn.net/wp-content/uploads/2025/04/Portugal-Sub-23-Hoquei-Patins.jpeg) <small>bolanarede.pt</small>Portugal é campeão da Europa de Sub-23 de Hóquei em Patins

Hóquei Em Patins: Espanha Vence Portugal (4-2) E é Campeã Da Europa | Flashscore.pt
-----------------------------------------------------------------------------------

 ![Hóquei em patins: Espanha vence Portugal (4-2) e é campeã da Europa | Flashscore.pt](https://livesport-ott-images.ssl.cdn.cra.cz/r1200xfq60/4f55eb8f-122e-4e57-8a75-276291d152d1.jpeg) <small>www.flashscore.pt</small>Hóquei em patins: Espanha vence Portugal (4-2) e é campeã da Europa | Flashscore.pt

Hóquei Em Patins: Sporting Não Vai Além Do Empate No Dérbi Com O Benfica E Cede 2.º Lugar Ao FC
-----------------------------------------------------------------------------------------------

 ![Hóquei em patins: Sporting não vai além do empate no dérbi com o Benfica e cede 2.º lugar ao FC](https://cdn.record.pt/images/2026-04/img_1200x721uu2026-04-20-20-58-10-2434335.jpg) <small>www.record.pt</small>Hóquei em patins: Sporting não vai além do empate no dérbi com o Benfica e cede 2.º lugar ao FC ...

Europeu De Hóquei Em Patins: Paulo Freitas Justifica Desaire Com "eficácia" | Flashscore.pt
-------------------------------------------------------------------------------------------

 ![Europeu de hóquei em patins: Paulo Freitas justifica desaire com "eficácia" | Flashscore.pt](https://livesport-ott-images.ssl.cdn.cra.cz/r1200xfq60/e2bbe4a0-be89-4ae9-8a7d-b00707adc7b6.jpeg) <small>www.flashscore.pt</small>Europeu de hóquei em patins: Paulo Freitas justifica desaire com "eficácia" | Flashscore.pt

Portugal é Campeão Europeu De Hóquei Em Patins - SIC Notícias
-------------------------------------------------------------

 ![Portugal é campeão europeu de hóquei em patins - SIC Notícias](https://images.impresa.pt/sicnot/2025-09-06-portugal-hoquei-patins-europeu-.jpg-bc010317/original) <small>sicnoticias.pt</small>Portugal é campeão europeu de hóquei em patins - SIC Notícias

Hóquei Em Patins: Portugal Goleia Inglaterra (10-0) No Europeu Sub-17 Feminino | Flashscore.pt
----------------------------------------------------------------------------------------------

 ![Hóquei em patins: Portugal goleia Inglaterra (10-0) no Europeu sub-17 feminino | Flashscore.pt](https://livesport-ott-images.ssl.cdn.cra.cz/r1200xfq60/8e07ce90-a43f-46f1-98d9-557610ca2c83.jpeg) <small>www.flashscore.pt</small>Hóquei em patins: Portugal goleia Inglaterra (10-0) no Europeu sub-17 feminino | Flashscore.pt

Portugal Supera França E Conquista Título Europeu De Hóquei Em Patins - Hóquei Em Patins
----------------------------------------------------------------------------------------

 ![Portugal supera França e conquista título europeu de hóquei em patins - Hóquei em Patins](https://cdn.record.pt/images/2025-09/img_920x518uu2025-09-07-07-49-59-2388370.jpg) <small>www.record.pt</small>Portugal supera França e conquista título europeu de hóquei em patins - Hóquei em Patins ...

Portugal Termina Em Segundo Lugar O Euro De Hóquei Em Patins Feminino
---------------------------------------------------------------------

 ![Portugal termina em segundo lugar o Euro de Hóquei em Patins Feminino](https://binny-bolanarede.b-cdn.net/wp-content/uploads/2025/09/Portugal-hoquei-feminino.jpg) <small>bolanarede.pt</small>Portugal termina em segundo lugar o Euro de Hóquei em Patins Feminino

Espanha-Portugal, 3-1 - Hóquei Em Patins - Jornal Record
--------------------------------------------------------

 ![Espanha-Portugal, 3-1 - Hóquei em Patins - Jornal Record](https://cdn.record.pt/images/2025-09/img_1200x721uu2025-09-03-23-15-45-2387748.jpg) <small>www.record.pt</small>Espanha-Portugal, 3-1 - Hóquei em Patins - Jornal Record

Hóquei Em Patins: Portugal Defronta França Com A ‘mira’ Na Final Do Europeu | Flashscore.pt
-------------------------------------------------------------------------------------------

 ![Hóquei em Patins: Portugal defronta França com a ‘mira’ na final do Europeu | Flashscore.pt](https://livesport-ott-images.ssl.cdn.cra.cz/r1200xfq60/d944a834-6c7b-4900-aad1-f5fe56fbd316.jpeg) <small>www.flashscore.pt</small>Hóquei em Patins: Portugal defronta França com a ‘mira’ na final do Europeu | Flashscore.pt

Hóquei Em Patins: Portugal Perde Com Argentina (1-3) E Está Fora Da Taça Das Nações | Flashscore.pt
---------------------------------------------------------------------------------------------------

 ![Hóquei em patins: Portugal perde com Argentina (1-3) e está fora da Taça das Nações | Flashscore.pt](https://livesport-ott-images.ssl.cdn.cra.cz/r1200xfq60/7729e48c-a038-43c8-889d-228fa6713b8b.jpeg) <small>www.flashscore.pt</small>Hóquei em patins: Portugal perde com Argentina (1-3) e está fora da Taça das Nações | Flashscore.pt

Portugal Venceu Chile E Fica Em Primeiro Do Grupo No Mundial De Hóquei Em Patins | Rádio Geice
----------------------------------------------------------------------------------------------

 ![Portugal venceu Chile e fica em primeiro do grupo no Mundial de hóquei em patins | Rádio Geice](https://radiogeice.com/wp-content/uploads/2022/11/portugal-hoquei-2.jpg) <small>radiogeice.com</small>Portugal venceu Chile e fica em primeiro do grupo no Mundial de hóquei em patins | Rádio Geice

Portugal supera frança e conquista título europeu de hóquei em patins. Hóquei em patins: as declarações dos protagonistas após o portugal-itália (4-1). portugal é campeão da europa de sub-23 de hóquei em patins
