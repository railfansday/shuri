---
title: "Greve Geral 3 De Junho 2026 Porto - Fnstfps já emitiu aviso prévio para a greve geral de 3 de junho!"
description: "Metro do porto &quot;fortemente condicionado&quot; no dia da greve geral"
date: "2026-07-22"
categories:
- "Uncategorized"
images:
- "https://www.spgl.pt/Media/Default/_Profiles/7494e02c/a9d870bd/Flyer Greve Geral_page-0002.jpg?v=639147970017538180"
featuredImage: "https://sinapsa.pt/wp-content/uploads/2026/06/INFO49-scaled.jpg"
featured_image: "https://www.cgtp.pt/images/images/2026/05/CONCENTRACOES-GG.jpg"
image: "https://www.jpn.up.pt/wp-content/uploads/2025/12/greve_geral1-1152x759.jpg"
---

If you are searching about Dados recolhidos até às 19h20 demonstram que a Greve Geral parou o país - CGTP-IN you've visit to the right page. We have 35 Pictures about Dados recolhidos até às 19h20 demonstram que a Greve Geral parou o país - CGTP-IN like GREVE GERAL - 3 JUNHO 2026 | Resolução - CGTP-IN, Greve Geral - 3 de Junho de 2026 | Concentrações - CGTP-IN and also Transportes, escolas e hospitais: o que esperar da greve de 3 de junho - Dinheiro - SÁBADO. Here it is:

Dados Recolhidos Até às 19h20 Demonstram Que A Greve Geral Parou O País - CGTP-IN
---------------------------------------------------------------------------------

 ![Dados recolhidos até às 19h20 demonstram que a Greve Geral parou o país - CGTP-IN](https://cgtp.pt/images/images/2026/06/Captura de ecra 2026-06-03 120926.png#joomlaImage:/local-images/images/2026/06/Captura de ecra 2026-06-03 120926.png?width=1162&height=610) <small>www.cgtp.pt</small>Dados recolhidos até às 19h20 demonstram que a Greve Geral parou o país - CGTP-IN

CGTP Convoca Greve Geral Para 3 De Junho - Portugal - SÁBADO
------------------------------------------------------------

 ![CGTP convoca greve geral para 3 de junho - Portugal - SÁBADO](https://cdn.sabado.pt/images/2026-05/img_1920x1080uu2026-05-01-08-54-55-764661.jpg) <small>www.sabado.pt</small>CGTP convoca greve geral para 3 de junho - Portugal - SÁBADO

GREVE GERAL - 3 JUNHO 2026 | Resolução - CGTP-IN
------------------------------------------------

 ![GREVE GERAL - 3 JUNHO 2026 | Resolução - CGTP-IN](https://www.cgtp.pt/images/images/2026/06/tiago-greve-geral.jpg) <small>www.cgtp.pt</small>GREVE GERAL - 3 JUNHO 2026 | Resolução - CGTP-IN

CGTP Convoca Greve Geral Para 3 De Junho, UGT Não Exclui
--------------------------------------------------------

 ![CGTP convoca greve geral para 3 de junho, UGT não exclui](https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA229tFU.img?w=1440&h=960&m=4&q=84) <small>www.msn.com</small>CGTP convoca greve geral para 3 de junho, UGT não exclui

AVISO PRÉVIO DE GREVE GERAL 3 JUNHO 2026 – STTS
-----------------------------------------------

 ![AVISO PRÉVIO DE GREVE GERAL 3 JUNHO 2026 – STTS](https://www.stts.pt/wp-content/uploads/2026/05/Imagem1-86x64.png) <small>www.stts.pt</small>AVISO PRÉVIO DE GREVE GERAL 3 JUNHO 2026 – STTS

Greve Geral De 3 De Junho: O Que Está Em Causa, Quem Pode Aderir E Que Impacto Se Prevê
---------------------------------------------------------------------------------------

 ![Greve Geral de 3 de junho: o que está em causa, quem pode aderir e que impacto se prevê](https://sabiasque.pt/images/stories/2026/trabalho/20260602-greve-geral-3-junho-1024x683.jpg) <small>sabiasque.pt</small>Greve Geral de 3 de junho: o que está em causa, quem pode aderir e que impacto se prevê

Aviso | Greves Em Junho De 2026 – AE António Correia De Oliveira
----------------------------------------------------------------

 ![Aviso | Greves em junho de 2026 – AE António Correia de Oliveira](https://www.acoliveira.pt/wp-content/uploads/2026/05/ChatGPT-Image-31_05_2026-22_43_43.png) <small>www.acoliveira.pt</small>Aviso | Greves em junho de 2026 – AE António Correia de Oliveira

Nacional - FENPROF
------------------

 ![Nacional - FENPROF](https://www.fenprof.pt/media/download/510F5035E5C8AED530130C74C48BB00C/2026_05_16-manif-ecd-spra1.jpg?width=1200&rxy=0.5,0.5&token=2kOJePBdk812vkJog3s9Ds0ky8nF%2FgY1wJt2krWJDVA%3D) <small>www.fenprof.pt</small>Nacional - FENPROF

O Que Vai Parar Com A Greve Geral De 3 De Junho? - Portugal - SÁBADO
--------------------------------------------------------------------

 ![O que vai parar com a greve geral de 3 de junho? - Portugal - SÁBADO](https://cdn.sabado.pt/images/2026-05/img_1200x676uu2026-05-21-18-26-04-766232.jpg) <small>www.sabado.pt</small>O que vai parar com a greve geral de 3 de junho? - Portugal - SÁBADO

Greve Geral Já Provoca Constrangimentos Na Circulação De Comboios - CGTP-IN
---------------------------------------------------------------------------

 ![Greve geral já provoca constrangimentos na circulação de comboios - CGTP-IN](https://www.cgtp.pt/images/images/2025/11/gg_banner2025.jpg) <small>www.cgtp.pt</small>Greve geral já provoca constrangimentos na circulação de comboios - CGTP-IN

Greve Contra Reforma Trabalhista Em Portugal Paralisa Trens, Reduz Voos E Fecha Escolas | Mundo
-----------------------------------------------------------------------------------------------

 ![Greve contra reforma trabalhista em Portugal paralisa trens, reduz voos e fecha escolas | Mundo](https://s2-valor.glbimg.com/4vR_2uY25dJGMy8ZVvqi2yGFVV0=/0x0:4000x2667/888x0/smart/filters:strip_icc()/i.s3.glbimg.com/v1/AUTH_63b422c2caee4269b8b34177e8876b93/internal_photos/bs/2026/i/K/IRKRylTBC6ihg48Gb0hw/457542349.jpg) <small>valor.globo.com</small>Greve contra reforma trabalhista em Portugal paralisa trens, reduz voos e fecha escolas | Mundo ...

Transportes, Escolas E Hospitais: O Que Esperar Da Greve De 3 De Junho - Dinheiro - SÁBADO
------------------------------------------------------------------------------------------

 ![Transportes, escolas e hospitais: o que esperar da greve de 3 de junho - Dinheiro - SÁBADO](https://cdn.sabado.pt/images/2026-05/img_980x653uu2026-05-30-11-36-15-766875.jpg) <small>www.sabado.pt</small>Transportes, escolas e hospitais: o que esperar da greve de 3 de junho - Dinheiro - SÁBADO

Dos Transportes às Escolas, Onde Se Vai Sentir A Greve Geral De Dia 3 De Junho? – ECO
-------------------------------------------------------------------------------------

 ![Dos transportes às escolas, onde se vai sentir a greve geral de dia 3 de junho? – ECO](https://eco.imgix.net/uploads/2026/05/cropped-whatsapp-image-2026-05-28-at-112408-1.jpeg?mark64=aHR0cHM6Ly9lY28uaW1naXgubmV0L0VDT193YXRlcm1hcmsucG5nP2ZtPXBuZw%3D%3D&markscale=33&markalign=center,left&w=1200) <small>eco.sapo.pt</small>Dos transportes às escolas, onde se vai sentir a greve geral de dia 3 de junho? – ECO

Greve Geral - 3 De Junho De 2026 | Concentrações - CGTP-IN
----------------------------------------------------------

 ![Greve Geral - 3 de Junho de 2026 | Concentrações - CGTP-IN](https://www.cgtp.pt/images/images/2026/05/CONCENTRACOES-GG.jpg) <small>www.cgtp.pt</small>Greve Geral - 3 de Junho de 2026 | Concentrações - CGTP-IN

Greve Geral – Dia 3 De Junho - SPRA
-----------------------------------

 ![Greve Geral – dia 3 de junho - SPRA](https://www.spra.pt/wp-content/uploads/2026/05/Greve_Acores-768x1024.jpg) <small>www.spra.pt</small>Greve Geral – dia 3 de junho - SPRA

NOTA INFORMATIVA Nº17/2026 - GREVE GERAL | 3 DE JUNHO DE 2026 - STI - Sindicato Dos
-----------------------------------------------------------------------------------

 ![NOTA INFORMATIVA Nº17/2026 - GREVE GERAL | 3 DE JUNHO DE 2026 - STI - Sindicato dos](https://stimpostos.pt/wp-content/uploads/2026/05/notas-informativas-2024-27.jpg) <small>stimpostos.pt</small>NOTA INFORMATIVA Nº17/2026 - GREVE GERAL | 3 DE JUNHO DE 2026 - STI - Sindicato dos ...

CGTP Convoca Greve Geral Para 3 De Junho - CNN Portugal
-------------------------------------------------------

 ![CGTP convoca greve geral para 3 de junho - CNN Portugal](https://img.iol.pt/preset/69668cf0d34e92a344976120/og/cnn) <small>cnnportugal.iol.pt</small>CGTP convoca greve geral para 3 de junho - CNN Portugal

Greve Geral De 3 De Junho Ameaça Paralisar O País: Que Setores Serão Impactados?
--------------------------------------------------------------------------------

 ![Greve geral de 3 de junho ameaça paralisar o país: que setores serão impactados?](https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA24BPMf.img?w=800&h=450&m=4&q=75) <small>www.msn.com</small>Greve geral de 3 de junho ameaça paralisar o país: que setores serão impactados?

CGTP Convoca Greve Geral Para Dia 3 De Junho E UGT Poderá Aderir
----------------------------------------------------------------

 ![CGTP convoca greve geral para dia 3 de junho e UGT poderá aderir](https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA22c4u7.img?w=1024&h=576&m=4&q=81) <small>www.msn.com</small>CGTP convoca greve geral para dia 3 de junho e UGT poderá aderir

CGTP Convoca Greve Geral Para 3 De Junho
----------------------------------------

 ![CGTP convoca greve geral para 3 de junho](https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA229ere.img?w=1920&h=1080&m=4&q=75) <small>www.msn.com</small>CGTP convoca greve geral para 3 de junho

Metro Do Porto "fortemente Condicionado" No Dia Da Greve Geral - JPN
--------------------------------------------------------------------

 ![Metro do Porto "fortemente condicionado" no dia da greve geral - JPN](https://www.jpn.up.pt/wp-content/uploads/2025/12/greve_geral1-1152x759.jpg) <small>www.jpn.up.pt</small>Metro do Porto "fortemente condicionado" no dia da greve geral - JPN

Professores Deram Uma Forte Expressão à Greve Geral De 3 De Junho - FENPROF
---------------------------------------------------------------------------

 ![Professores deram uma forte expressão à Greve Geral de 3 de junho - FENPROF](https://www.fenprof.pt/media/download/6FDA79F0A62C1CB1E79A4D96032CBC0A/foto-greve-na-rua.jpg) <small>www.fenprof.pt</small>Professores deram uma forte expressão à Greve Geral de 3 de junho - FENPROF

CGTP Convoca Greve Geral Para 3 De Junho - Sociedade - Correio Da Manhã
-----------------------------------------------------------------------

 ![CGTP convoca greve geral para 3 de junho - Sociedade - Correio da Manhã](https://cdn.cmjornal.pt/images/2025-12/img_1500x1000uu2025-12-11-14-37-03-2253844.jpg) <small>www.cmjornal.pt</small>CGTP convoca greve geral para 3 de junho - Sociedade - Correio da Manhã

Nacional - FENPROF
------------------

 ![Nacional - FENPROF](https://www.fenprof.pt/media/download/B73B952771368699555DF536CB47A576/grevegeral-3jun26.png?width=1200&rxy=0.5,0.5&token=2kOJePBdk812vkJog3s9Ds0ky8nF%2FgY1wJt2krWJDVA%3D) <small>www.fenprof.pt</small>Nacional - FENPROF

Greve Geral De 24 Horas No Dia 3 De Junho- Serviço De Transporte Afetado
------------------------------------------------------------------------

 ![Greve geral de 24 horas no dia 3 de junho- Serviço de transporte afetado](https://www.metrolisboa.pt/institucional/wp-content/uploads/sites/2/2026/06/greve-3-junho_1080x450.png) <small>www.metrolisboa.pt</small>Greve geral de 24 horas no dia 3 de junho- Serviço de transporte afetado

FNSTFPS Já Emitiu Aviso Prévio Para A Greve Geral De 3 De Junho! - CGTP-IN
--------------------------------------------------------------------------

 ![FNSTFPS já emitiu Aviso Prévio para a Greve Geral de 3 de Junho! - CGTP-IN](https://www.cgtp.pt/images/accao-e-luta/2026/05/greve-geral-funcao-publica.jpg) <small>www.cgtp.pt</small>FNSTFPS já emitiu Aviso Prévio para a Greve Geral de 3 de Junho! - CGTP-IN

CGTP Entrega Na Segunda-feira Pré-aviso Da Greve Geral De 3 De Junho - Portugal - SÁBADO
----------------------------------------------------------------------------------------

 ![CGTP entrega na segunda-feira pré-aviso da greve geral de 3 de junho - Portugal - SÁBADO](https://cdn.sabado.pt/images/2026-05/img_1920x1080uu2026-05-08-13-51-22-765157.jpg) <small>www.sabado.pt</small>CGTP entrega na segunda-feira pré-aviso da greve geral de 3 de junho - Portugal - SÁBADO

Sindicatos Do Algarve Já Estão A Preparar A Greve Geral De 3 De Junho - CGTP-IN
-------------------------------------------------------------------------------

 ![Sindicatos do Algarve já estão a preparar a Greve Geral de 3 de Junho - CGTP-IN](https://www.cgtp.pt/images/accao-e-luta/2026/algarve1.jpg) <small>www.cgtp.pt</small>Sindicatos do Algarve já estão a preparar a Greve Geral de 3 de Junho - CGTP-IN

SPGL - Professores, Educadores E Investigadores Na Greve Geral | 3 De Junho 2026
--------------------------------------------------------------------------------

 ![SPGL - Professores, educadores e investigadores na Greve Geral | 3 de junho 2026](https://www.spgl.pt/Media/Default/_Profiles/7494e02c/a9d870bd/Flyer Greve Geral_page-0002.jpg?v=639147970017538180) <small>www.spgl.pt</small>SPGL - Professores, educadores e investigadores na Greve Geral | 3 de junho 2026

CGTP Avança Com Greve Geral Para 3 De Junho
-------------------------------------------

 ![CGTP avança com greve geral para 3 de junho](https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA229Sqw.img?w=1200&h=800&m=4&q=70) <small>www.msn.com</small>CGTP avança com greve geral para 3 de junho

AVISO PRÉVIO DE GREVE GERAL 3 JUNHO 2026 – STTS
-----------------------------------------------

 ![AVISO PRÉVIO DE GREVE GERAL 3 JUNHO 2026 – STTS](https://www.stts.pt/wp-content/uploads/2026/05/Imagem1-210x136.png) <small>www.stts.pt</small>AVISO PRÉVIO DE GREVE GERAL 3 JUNHO 2026 – STTS

GREVE GERAL | 3 JUNHO - SINAPSA
-------------------------------

 ![GREVE GERAL | 3 JUNHO - SINAPSA](https://sinapsa.pt/wp-content/uploads/2026/06/INFO49-scaled.jpg) <small>sinapsa.pt</small>GREVE GERAL | 3 JUNHO - SINAPSA

AVISO PRÉVIO DE GREVE GERAL 3 JUNHO 2026 – STTS
-----------------------------------------------

 ![AVISO PRÉVIO DE GREVE GERAL 3 JUNHO 2026 – STTS](https://www.stts.pt/wp-content/uploads/2026/05/123654.jpg) <small>www.stts.pt</small>AVISO PRÉVIO DE GREVE GERAL 3 JUNHO 2026 – STTS

GREVE GERAL - 3 JUNHO 2026 | Resolução - CGTP-IN
------------------------------------------------

 ![GREVE GERAL - 3 JUNHO 2026 | Resolução - CGTP-IN](https://www.cgtp.pt/images/images/2026/06/resolucao_grevegeral.jpg) <small>www.cgtp.pt</small>GREVE GERAL - 3 JUNHO 2026 | Resolução - CGTP-IN

Greve Geral Em Lisboa A 3 De Junho: O Que Pára Na Cidade
--------------------------------------------------------

 ![Greve geral em Lisboa a 3 de Junho: o que pára na cidade](https://media.timeout.com/images/106411166/750/422/image.jpg) <small>www.timeout.pt</small>Greve geral em Lisboa a 3 de Junho: o que pára na cidade

greve geral. Cgtp convoca greve geral para 3 de junho. Dados recolhidos até às 19h20 demonstram que a greve geral parou o país
