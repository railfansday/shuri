---
title: "Greve Geral 11 De Dezembro - Sindicatos independentes aderem à greve geral pela primeira vez e juntam-se à ugt e cgtp"
description: "greve geral dia 11 dezembro de 2025"
date: "2026-05-26"
categories:
- "Uncategorized"
images:
- "https://sdpsul.com/storage/publicacao/imagem_563_6929dba6ddf62.jpeg"
featuredImage: "https://lookaside.fbsbx.com/lookaside/crawler/media/?media_id=1634621500842359"
featured_image: "https://www.pcp.pt/sites/default/files/imagecache/facebook_share/images/dossiers/greve_geral_11_dez_2025/capa.jpg"
image: "https://images.impresa.pt/sicnot/2025-09-24-manif-protesto-cgtp-51d0ff36/original"
---

If you are looking for GREVE GERAL DIA 11 DEZEMBRO DE 2025 | FESAHT you've visit to the right page. We have 35 Images about GREVE GERAL DIA 11 DEZEMBRO DE 2025 | FESAHT like SINDEP - Greve Geral 11 de dezembro, Greve geral pode custar 792 milhões de euros à economia - JN and also Greve geral: CGTP entrega pré-aviso, depois de UGT admitir polongar paralisação - SIC Notícias. Here it is:

GREVE GERAL DIA 11 DEZEMBRO DE 2025 | FESAHT
--------------------------------------------

 ![GREVE GERAL DIA 11 DEZEMBRO DE 2025 | FESAHT](https://sindicatos.cgtp.pt/fesaht/wp-content/blogs.dir/52/files/sites/52/2025/12/11-DEZ-faz-greve-e-sai-a-Rua.jpg) <small>sindicatos.cgtp.pt</small>GREVE GERAL DIA 11 DEZEMBRO DE 2025 | FESAHT

SINDEP - Greve Geral 11 De Dezembro
-----------------------------------

 ![SINDEP - Greve Geral 11 de dezembro](https://sindep.pt/images/cartaz_GREVE_GERAL_UGT.jpg) <small>sindep.pt</small>SINDEP - Greve Geral 11 de dezembro

Greve Geral — 11 De Dezembro — Contra O Pacote Laboral | Partido Comunista Português
------------------------------------------------------------------------------------

 ![Greve Geral — 11 de Dezembro — Contra o Pacote Laboral | Partido Comunista Português](https://www.pcp.pt/sites/default/files/imagecache/facebook_share/images/dossiers/greve_geral_11_dez_2025/capa.jpg) <small>www.pcp.pt</small>Greve Geral — 11 de Dezembro — Contra o Pacote Laboral | Partido Comunista Português

Sindicatos Independentes Aderem à Greve Geral Pela Primeira Vez E Juntam-se à UGT E CGTP - Expresso
---------------------------------------------------------------------------------------------------

 ![Sindicatos independentes aderem à greve geral pela primeira vez e juntam-se à UGT e CGTP - Expresso](https://images.impresa.pt/expresso/2025-11-27-greve-geral-anuncio-para-a-realizacao-de-greve-a-11-de-dezembro-marques-pombal--9b289114/original) <small>expresso.pt</small>Sindicatos independentes aderem à greve geral pela primeira vez e juntam-se à UGT e CGTP - Expresso

Porque Vai Haver Greve Geral? O Que Acham Os Portugueses Do Protesto? - Renascença
----------------------------------------------------------------------------------

 ![Porque vai haver greve geral? O que acham os portugueses do protesto? - Renascença](https://images.rr.pt/4449961918951bc2b3d5defaultlarge_1024.JPG) <small>rr.pt</small>Porque vai haver greve geral? O que acham os portugueses do protesto? - Renascença

UGT Aprova Greve Geral Com A CGTP A 11 De Dezembro - Renascença
---------------------------------------------------------------

 ![UGT aprova greve geral com a CGTP a 11 de dezembro - Renascença](https://images.rr.pt/459977534574ce6982fcdefaultlarge_1024.JPG) <small>rr.pt</small>UGT aprova greve geral com a CGTP a 11 de dezembro - Renascença

CGTP E UGT Convocam Greve Geral Para 11 De Dezembro
---------------------------------------------------

 ![CGTP e UGT convocam greve geral para 11 de dezembro](https://cdn-images.rtp.pt/icm/noticias/images/9d/9d70424fbde54f53aa0f6db19a9f7213?w=860&q=90&rect=0,0,1500,822w=860&q=90) <small>www.rtp.pt</small>CGTP e UGT convocam greve geral para 11 de dezembro

JORNAL - GREVE GERAL AVANÇA NO DIA 11. SEXTA-FEIRA CONTA COM NOVA GREVE A Greve Geral Que Se
--------------------------------------------------------------------------------------------

 ![JORNAL - GREVE GERAL AVANÇA NO DIA 11. SEXTA-FEIRA CONTA COM NOVA GREVE A greve geral que se](https://lookaside.fbsbx.com/lookaside/crawler/media/?media_id=1634621500842359) <small>www.facebook.com</small>JORNAL - GREVE GERAL AVANÇA NO DIA 11. SEXTA-FEIRA CONTA COM NOVA GREVE A greve geral que se ...

CGTP E UGT Anunciam Greve Geral Para 11 De Dezembro - TSF
---------------------------------------------------------

 ![CGTP e UGT anunciam greve geral para 11 de dezembro - TSF](https://staticx.noticiasilimitadas.pt/tsf/image.webp?brand=tsf&type=generate&guid=d992b342-086f-47ed-806a-cf01c02ec067&w=3840) <small>www.tsf.pt</small>CGTP e UGT anunciam greve geral para 11 de dezembro - TSF

CGTP Anuncia Greve Geral Para 11 De Dezembro - SIC Notícias
-----------------------------------------------------------

 ![CGTP anuncia greve geral para 11 de dezembro - SIC Notícias](https://images.impresa.pt/sicnot/2025-09-24-manif-protesto-cgtp-51d0ff36/original) <small>sicnoticias.pt</small>CGTP anuncia greve geral para 11 de dezembro - SIC Notícias

A Greve Geral De 11 De Dezembro Em 38 Imagens – Observador
----------------------------------------------------------

 ![A greve geral de 11 de dezembro em 38 imagens – Observador](https://bordalo.observador.pt/v2/q:60/rs:fill:1440/c:4096:2730:nowe:0:0/plain/https://s3.observador.pt/wp-content/uploads/2025/12/11173228/dventura-greve-geral-11dez-41-scaled.jpg) <small>observador.pt</small>A greve geral de 11 de dezembro em 38 imagens – Observador

UGT Aprova Por Unanimidade Greve Geral A 11 De Dezembro - Diário Do Minho
-------------------------------------------------------------------------

 ![UGT aprova por unanimidade greve geral a 11 de dezembro - Diário do Minho](https://www.diariodominho.pt/storage/posts/greve-direito-a-greve_655b8a6d702c0_og.jpg) <small>www.diariodominho.pt</small>UGT aprova por unanimidade greve geral a 11 de dezembro - Diário do Minho

CGTP E UGT Convocam Greve Geral Para 11 De Dezembro - Expresso
--------------------------------------------------------------

 ![CGTP e UGT convocam greve geral para 11 de dezembro - Expresso](https://images.impresa.pt/expresso/2025-11-08-manifestacao-contra-legislacao-laboral-427ac8b8-1/original) <small>expresso.pt</small>CGTP e UGT convocam greve geral para 11 de dezembro - Expresso

GREVE GERAL DE 11 DE DEZEMBRO DE 2025 – MANIFESTAÇÕES – LISBOA (VÍDEO) – EPHEMERA – Biblioteca E
------------------------------------------------------------------------------------------------

 ![GREVE GERAL DE 11 DE DEZEMBRO DE 2025 – MANIFESTAÇÕES – LISBOA (VÍDEO) – EPHEMERA – Biblioteca e](https://ephemerajpp.com/wp-content/uploads/2025/12/IMG_2182.jpg) <small>ephemerajpp.com</small>GREVE GERAL DE 11 DE DEZEMBRO DE 2025 – MANIFESTAÇÕES – LISBOA (VÍDEO) – EPHEMERA – Biblioteca e ...

Greve Geral Pode Custar 792 Milhões De Euros à Economia - JN
------------------------------------------------------------

 ![Greve geral pode custar 792 milhões de euros à economia - JN](https://staticx.noticiasilimitadas.pt/jn/image.webp?brand=jn&type=generate&guid=fb434b13-2b30-4ab1-a6bc-4ddd86b96b14&w=3840) <small>www.jn.pt</small>Greve geral pode custar 792 milhões de euros à economia - JN

CGTP E UGT Avançam Para Greve Geral A 11 De Dezembro
----------------------------------------------------

 ![CGTP e UGT avançam para greve geral a 11 de dezembro](https://cdn-images.rtp.pt/icm/noticias/images/9c/9cc08b7ef9071a995ca0507e7081a472?w=860&q=90&rect=0,106,1249,685) <small>www.rtp.pt</small>CGTP e UGT avançam para greve geral a 11 de dezembro

Transportes, Hospitais, Escolas E Até Bancos. Que Setores Vão Ser Afetados Pela Greve Geral? – ECO
--------------------------------------------------------------------------------------------------

 ![Transportes, hospitais, escolas e até bancos. Que setores vão ser afetados pela greve geral? – ECO](https://ecoonline.s3.amazonaws.com/uploads/2025/12/46141990.jpg) <small>eco.sapo.pt</small>Transportes, hospitais, escolas e até bancos. Que setores vão ser afetados pela greve geral? – ECO

S.TO.P. Junta-se à Greve Geral De 11 De Dezembro Com Pré-aviso De Greve Para A Educação
---------------------------------------------------------------------------------------

 ![S.TO.P. junta-se à greve geral de 11 de dezembro com pré-aviso de greve para a educação](https://stop-sindicato.pt/wp-content/uploads/2025/11/S.TO_.P.-Cartaz-Greve-Geral-Educacao-11Dez2025_x1000-724x1024.png) <small>stop-sindicato.pt</small>S.TO.P. junta-se à greve geral de 11 de dezembro com pré-aviso de greve para a educação ...

De Quem é O Meu Trabalho? - By Diogo Augusto - Fragmentos
---------------------------------------------------------

 ![De quem é o meu trabalho? - by Diogo Augusto - Fragmentos](https://substackcdn.com/image/fetch/$s_!XXAX!,f_auto,q_auto:good,fl_progressive:steep/https://substack-post-media.s3.amazonaws.com/public/images/d17e3e84-ae0f-4705-ad40-6923a8e44676_6000x4000.jpeg) <small>osfragmentos.substack.com</small>De quem é o meu trabalho? - by Diogo Augusto - Fragmentos

GREVE GERAL DE 11 DE DEZEMBRO DE 2025 – A CGTP NAS MANIFESTAÇÕES – LISBOA – EPHEMERA
------------------------------------------------------------------------------------

 ![GREVE GERAL DE 11 DE DEZEMBRO DE 2025 – A CGTP NAS MANIFESTAÇÕES – LISBOA – EPHEMERA](https://ephemerajpp.com/wp-content/uploads/2025/12/IMG_2228.jpg) <small>ephemerajpp.com</small>GREVE GERAL DE 11 DE DEZEMBRO DE 2025 – A CGTP NAS MANIFESTAÇÕES – LISBOA – EPHEMERA ...

VISEU - Esclarecimento E Mobilização Para A Greve Geral Marcada Para 11 De Dezembro - CGTP-IN
---------------------------------------------------------------------------------------------

 ![VISEU - Esclarecimento e mobilização para a Greve Geral marcada para 11 de Dezembro - CGTP-IN](https://www.cgtp.pt/images/accao-e-luta/2025/gg.jpg) <small>www.cgtp.pt</small>VISEU - Esclarecimento e mobilização para a Greve Geral marcada para 11 de Dezembro - CGTP-IN

Greve Geral Em Portugal – 11 De Dezembro - FLEMACON
---------------------------------------------------

 ![Greve geral em Portugal – 11 de dezembro - FLEMACON](https://www.flemacon.org/wp-content/uploads/2025/12/WhatsApp-Image-2025-12-12-at-19.45.27.jpeg) <small>www.flemacon.org</small>Greve geral em Portugal – 11 de dezembro - FLEMACON

CGTP E UGT Convocam Greve Geral Para 11 De Dezembro - JN
--------------------------------------------------------

 ![CGTP e UGT convocam greve geral para 11 de dezembro - JN](https://staticx.noticiasilimitadas.pt/jn/image.webp?brand=jn&type=generate&guid=44b944fb-8886-457b-a19f-bdc9053848ef&w=3840) <small>www.jn.pt</small>CGTP e UGT convocam greve geral para 11 de dezembro - JN

Secretário-geral Da CGTP Confirma Greve Geral Para Dia 11 De Dezembro - Política - Correio Da Manhã
---------------------------------------------------------------------------------------------------

 ![Secretário-geral da CGTP confirma greve geral para dia 11 de dezembro - Política - Correio da Manhã](https://cdn.cmjornal.pt/images/2025-11/img_1500x1000uu2025-11-08-16-56-10-2246799.jpg) <small>www.cmjornal.pt</small>Secretário-geral da CGTP confirma greve geral para dia 11 de dezembro - Política - Correio da Manhã

Professores Juntam-se à Greve Geral De 11 De Dezembro - Renascença
------------------------------------------------------------------

 ![Professores juntam-se à greve geral de 11 de dezembro - Renascença](https://images.rr.pt/43916780140003a4d292defaultlarge_1024.JPG) <small>rr.pt</small>Professores juntam-se à greve geral de 11 de dezembro - Renascença

Motivos Da Adesão à Greve Geral De 11 De Dezembro De 2025
---------------------------------------------------------

 ![Motivos da adesão à Greve Geral de 11 de dezembro de 2025](https://spzn.pt/uploads/noticias/big_1763717239_6728_SPZN_2025_site_novo_(17).png) <small>spzn.pt</small>Motivos da adesão à Greve Geral de 11 de dezembro de 2025

A Greve Geral De 11 De Dezembro Em 38 Imagens – Observador
----------------------------------------------------------

 ![A greve geral de 11 de dezembro em 38 imagens – Observador](https://bordalo.observador.pt/v2/q:60/rs:fill:1440/c:4096:2734:nowe:0:0/plain/https://s3.observador.pt/wp-content/uploads/2025/12/11191541/dv1-7571-scaled.jpeg) <small>observador.pt</small>A greve geral de 11 de dezembro em 38 imagens – Observador

Só O Apagão Teve Uma Quebra Económica Superior à Do Dia Da Greve
----------------------------------------------------------------

 ![Só o apagão teve uma quebra económica superior à do dia da greve](https://staticx.noticiasilimitadas.pt/jn/image.webp?brand=jn&type=generate&guid=4e3db1cf-6cbb-45e3-9b4c-2a812da11678&w=3840) <small>www.jn.pt</small>Só o apagão teve uma quebra económica superior à do dia da greve

Greve Geral: CGTP Entrega Pré-aviso, Depois De UGT Admitir Polongar Paralisação - SIC Notícias
----------------------------------------------------------------------------------------------

 ![Greve geral: CGTP entrega pré-aviso, depois de UGT admitir polongar paralisação - SIC Notícias](https://images.impresa.pt/sicnot/2025-11-17-cgtp-pre-aviso-greve-82e19fc3-1/16x9/mw-1200) <small>sicnoticias.pt</small>Greve geral: CGTP entrega pré-aviso, depois de UGT admitir polongar paralisação - SIC Notícias

SDP Sul
-------

 ![SDP Sul](https://sdpsul.com/storage/publicacao/imagem_563_6929dba6ddf62.jpeg) <small>sdpsul.com</small>SDP Sul

O Patrão Pode Perguntar-me Se Vou Fazer Greve? Perco O Subsídio De Refeição? E Se A Empresa
-------------------------------------------------------------------------------------------

 ![O patrão pode perguntar-me se vou fazer greve? Perco o subsídio de refeição? E se a empresa](https://img.iol.pt/image/id/639cc0300cf2aea78582cbff/) <small>cnnportugal.iol.pt</small>O patrão pode perguntar-me se vou fazer greve? Perco o subsídio de refeição? E se a empresa ...

CGTP Anuncia Greve Geral Para 11 De Dezembro
--------------------------------------------

 ![CGTP anuncia greve geral para 11 de dezembro](https://www.lusa.pt/TEMP/IMAGES/780x1200/CACHE_780X1200_ANALOG_WATERMARKED_45998234_7085120_08112025053627.JPG) <small>www.lusa.pt</small>CGTP anuncia greve geral para 11 de dezembro

CGTP Entrega Pré-aviso Da Greve Geral Para 11 De Dezembro | CGTP | PÚBLICO
--------------------------------------------------------------------------

 ![CGTP entrega pré-aviso da greve geral para 11 de Dezembro | CGTP | PÚBLICO](https://imagens.publico.pt/imagens.aspx/2045742?tp=UH&db=IMAGENS&type=JPG&share=1&o=BarraFacebook_Publico.png) <small>www.publico.pt</small>CGTP entrega pré-aviso da greve geral para 11 de Dezembro | CGTP | PÚBLICO

CIL Apoia A Greve Geral Do Próximo Dia 11 De Dezembro - CGTP-IN
---------------------------------------------------------------

 ![CIL apoia a Greve Geral do próximo dia 11 de Dezembro - CGTP-IN](https://www.cgtp.pt/images/accao-e-luta/2025/54909309207_62b0afa28f_o1.jpg) <small>www.cgtp.pt</small>CIL apoia a Greve Geral do próximo dia 11 de Dezembro - CGTP-IN

Greve Geral Para 11 De Dezembro Convocada Pela CGTP E UGT - Valpaços Online
---------------------------------------------------------------------------

 ![Greve geral para 11 de dezembro convocada pela CGTP e UGT - Valpaços Online](https://valpacosonline.pt/wp-content/uploads/2025/11/gg91125.webp) <small>valpacosonline.pt</small>Greve geral para 11 de dezembro convocada pela CGTP e UGT - Valpaços Online

Cgtp e ugt convocam greve geral para 11 de dezembro. Sdp sul. Professores juntam-se à greve geral de 11 de dezembro
