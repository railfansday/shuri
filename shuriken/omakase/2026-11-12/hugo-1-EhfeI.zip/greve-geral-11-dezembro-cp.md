---
title: "Greve Geral 11 Dezembro Cp - Faq: os direitos dos docentes em dia de greve geral"
description: "greve geral paralisa transportes, saúde e educação no porto"
date: "2026-11-02"
categories:
- "Uncategorized"
images:
- "https://www.flemacon.org/wp-content/uploads/2025/12/WhatsApp-Image-2025-12-12-at-19.45.27-1-696x870.jpeg"
featuredImage: "https://www.cm-barreiro.pt/wp-content/uploads/2025/12/GREVE-11_DEZEMBRO_1920px-1536x920.jpg"
featured_image: "https://www.pcp.pt/sites/default/files/imagecache/facebook_share/images/dossiers/greve_geral_11_dez_2025/capa.jpg"
image: "https://ecoonline.s3.amazonaws.com/uploads/2025/12/46141990.jpg"
---

If you are looking for SDP Sul you've came to the right place. We have 35 Pictures about SDP Sul like Greve Geral – 24 Horas – Dia 11 de Dezembro de 2025 – SINTTAV Sindicato Nacional dos, Greve Geral de 11 de dezembro – UGT MADEIRA and also CGTP anuncia greve geral para 11 de dezembro. Here it is:

SDP Sul
-------

 ![SDP Sul](https://sdpsul.com/storage/publicacao/imagem_563_6929dba6ddf62.jpeg) <small>sdpsul.com</small>SDP Sul

VISEU - Esclarecimento E Mobilização Para A Greve Geral Marcada Para 11 De Dezembro - CGTP-IN
---------------------------------------------------------------------------------------------

 ![VISEU - Esclarecimento e mobilização para a Greve Geral marcada para 11 de Dezembro - CGTP-IN](https://www.cgtp.pt/images/accao-e-luta/2025/gg.jpg) <small>www.cgtp.pt</small>VISEU - Esclarecimento e mobilização para a Greve Geral marcada para 11 de Dezembro - CGTP-IN

Greve Geral Em Portugal – 11 De Dezembro - FLEMACON
---------------------------------------------------

 ![Greve geral em Portugal – 11 de dezembro - FLEMACON](https://www.flemacon.org/wp-content/uploads/2025/12/WhatsApp-Image-2025-12-12-at-19.45.27-1-696x870.jpeg) <small>www.flemacon.org</small>Greve geral em Portugal – 11 de dezembro - FLEMACON

Greve Geral Pode Custar 792 Milhões De Euros à Economia - JN
------------------------------------------------------------

 ![Greve geral pode custar 792 milhões de euros à economia - JN](https://staticx.noticiasilimitadas.pt/jn/image.webp?brand=jn&type=generate&guid=fb434b13-2b30-4ab1-a6bc-4ddd86b96b14&w=3840) <small>www.jn.pt</small>Greve geral pode custar 792 milhões de euros à economia - JN

S.TO.P. Junta-se à Greve Geral De 11 De Dezembro Com Pré-aviso De Greve Para A Educação
---------------------------------------------------------------------------------------

 ![S.TO.P. junta-se à greve geral de 11 de dezembro com pré-aviso de greve para a educação](https://stop-sindicato.pt/wp-content/uploads/2025/11/S.TO_.P.-Cartaz-Greve-Geral-Educacao-11Dez2025_x1000-724x1024.png) <small>stop-sindicato.pt</small>S.TO.P. junta-se à greve geral de 11 de dezembro com pré-aviso de greve para a educação ...

Fertagus &gt; Fertagus (pt) &gt; Viajar &gt; Comunicados E Campanhas &gt; Greve Geral 11 De Dezembro De 2025
------------------------------------------------------------------------------------------------------------

 ![Fertagus > Fertagus (pt) > Viajar > Comunicados e Campanhas > Greve Geral 11 de dezembro de 2025](https://www.fertagus.pt/portals/0/FTG-Greve-Geral-web-1253x886.jpg) <small>www.fertagus.pt</small>Fertagus &gt; Fertagus (pt) &gt; Viajar &gt; Comunicados e Campanhas &gt; Greve Geral 11 de dezembro de 2025

A Greve Geral De 11 De Dezembro Em 38 Imagens – Observador
----------------------------------------------------------

 ![A greve geral de 11 de dezembro em 38 imagens – Observador](https://bordalo.observador.pt/v2/q:60/rs:fill:1440/c:4096:2730:nowe:0:0/plain/https://s3.observador.pt/wp-content/uploads/2025/12/11173228/dventura-greve-geral-11dez-41-scaled.jpg) <small>observador.pt</small>A greve geral de 11 de dezembro em 38 imagens – Observador

Amanhã Há Greve Da Função Pública (escolas Podem Fechar)
--------------------------------------------------------

 ![Amanhã há greve da função pública (escolas podem fechar)](https://jornaldemafra.pt/wp-content/uploads/2025/12/greve-geral.webp) <small>jornaldemafra.pt</small>Amanhã há greve da função pública (escolas podem fechar)

Perguntas E Respostas Sobre A Greve Geral De 11 De Dezembro - SBC - Sindicato Nacional Dos
------------------------------------------------------------------------------------------

 ![Perguntas e respostas sobre a Greve Geral de 11 de dezembro - SBC - Sindicato Nacional dos](https://www.sibace.pt/wp-content/uploads/2025/11/greve-2-1170-x-400.png) <small>www.sibace.pt</small>Perguntas e respostas sobre a Greve Geral de 11 de dezembro - SBC - Sindicato Nacional dos ...

CGTP Anuncia Greve Geral Para 11 De Dezembro
--------------------------------------------

 ![CGTP anuncia greve geral para 11 de dezembro](https://www.lusa.pt/TEMP/IMAGES/780x1200/CACHE_780X1200_ANALOG_WATERMARKED_45998234_7085120_08112025053627.JPG) <small>www.lusa.pt</small>CGTP anuncia greve geral para 11 de dezembro

GREVE GERAL – Concentração Em Frente Da Câmara Municipal De Portimão – 11 Dezembro 8h30
---------------------------------------------------------------------------------------

 ![GREVE GERAL – Concentração em frente da Câmara Municipal de Portimão – 11 Dezembro 8h30](https://stop-sindicato.pt/wp-content/uploads/2025/12/S.TO_.P.-Cartaz-Protesto-CM-Portimao-GreveGeral-11Dez-8h30.png) <small>stop-sindicato.pt</small>GREVE GERAL – Concentração em frente da Câmara Municipal de Portimão – 11 Dezembro 8h30 ...

Mais De 50 Sindicatos Aderem à Greve Geral Marcada Para 11 De Dezembro - SIC Notícias
-------------------------------------------------------------------------------------

 ![Mais de 50 sindicatos aderem à greve geral marcada para 11 de dezembro - SIC Notícias](https://images.impresa.pt/sicnot/2025-11-17-cgtp-pre-aviso-greve-82e19fc3-1/16x9/mw-1200) <small>sicnoticias.pt</small>Mais de 50 sindicatos aderem à greve geral marcada para 11 de dezembro - SIC Notícias

📢 GREVE GERAL — 11 DE DEZEMBRO POSSO FAZER GREVE? Sim. E é Importante Que Saibas Porquê. Todos
----------------------------------------------------------------------------------------------

 ![📢 GREVE GERAL — 11 DE DEZEMBRO POSSO FAZER GREVE? Sim. E é importante que saibas porquê. Todos](https://lookaside.fbsbx.com/lookaside/crawler/media/?media_id=1185258557072905) <small>www.facebook.com</small>📢 GREVE GERAL — 11 DE DEZEMBRO POSSO FAZER GREVE? Sim. E é importante que saibas porquê. Todos ...

GREVE GERAL DE 11 DE DEZEMBRO DE 2025 – MANIFESTAÇÕES – LISBOA (VÍDEO) – EPHEMERA – Biblioteca E
------------------------------------------------------------------------------------------------

 ![GREVE GERAL DE 11 DE DEZEMBRO DE 2025 – MANIFESTAÇÕES – LISBOA (VÍDEO) – EPHEMERA – Biblioteca e](https://ephemerajpp.com/wp-content/uploads/2025/12/IMG_2182.jpg) <small>ephemerajpp.com</small>GREVE GERAL DE 11 DE DEZEMBRO DE 2025 – MANIFESTAÇÕES – LISBOA (VÍDEO) – EPHEMERA – Biblioteca e ...

GREVE GERAL DIA 11 DEZEMBRO DE 2025 | FESAHT
--------------------------------------------

 ![GREVE GERAL DIA 11 DEZEMBRO DE 2025 | FESAHT](https://sindicatos.cgtp.pt/fesaht/wp-content/blogs.dir/52/files/sites/52/2025/12/11-DEZ-faz-greve-e-sai-a-Rua.jpg) <small>sindicatos.cgtp.pt</small>GREVE GERAL DIA 11 DEZEMBRO DE 2025 | FESAHT

FAQ: Os Direitos Dos Docentes Em Dia De Greve Geral - 11/12/2025
----------------------------------------------------------------

 ![FAQ: Os direitos dos docentes em dia de Greve Geral - 11/12/2025](https://static.wixstatic.com/media/d0f32c_9ff1199ee2c34418af0094a43c516733~mv2.png/v1/fill/w_940,h_788,al_c,q_90,enc_avif,quality_auto/d0f32c_9ff1199ee2c34418af0094a43c516733~mv2.png) <small>www.sprc.pt</small>FAQ: Os direitos dos docentes em dia de Greve Geral - 11/12/2025

Dos Transportes à Saúde, Lares E Prisões, Que Serviços Mínimos Estão Garantidos Para A Greve
--------------------------------------------------------------------------------------------

 ![Dos transportes à saúde, lares e prisões, que serviços mínimos estão garantidos para a greve](https://images.impresa.pt/expresso/2025-12-09-greve-geral.jpg-0c01f0f6/original) <small>expresso.pt</small>Dos transportes à saúde, lares e prisões, que serviços mínimos estão garantidos para a greve ...

Contratos, Horários, Parentalidade E Despedimentos: Novo Ano Antecipa Revolução No Trabalho
-------------------------------------------------------------------------------------------

 ![Contratos, horários, parentalidade e despedimentos: novo ano antecipa revolução no trabalho](https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA1SeBdr.img?w=768&h=432&m=6&x=469&y=335&s=55&d=55) <small>www.msn.com</small>Contratos, horários, parentalidade e despedimentos: novo ano antecipa revolução no trabalho

Greve Geral – 24 Horas – Dia 11 De Dezembro De 2025 – SINTTAV Sindicato Nacional Dos
------------------------------------------------------------------------------------

 ![Greve Geral – 24 Horas – Dia 11 de Dezembro de 2025 – SINTTAV Sindicato Nacional dos](https://sinttav.pt/wp-content/uploads/2025/11/pag-1.jpg) <small>sinttav.pt</small>Greve Geral – 24 Horas – Dia 11 de Dezembro de 2025 – SINTTAV Sindicato Nacional dos ...

Transportes, Hospitais, Escolas E Até Bancos. Que Setores Vão Ser Afetados Pela Greve Geral? – ECO
--------------------------------------------------------------------------------------------------

 ![Transportes, hospitais, escolas e até bancos. Que setores vão ser afetados pela greve geral? – ECO](https://ecoonline.s3.amazonaws.com/uploads/2025/12/46141990.jpg) <small>eco.sapo.pt</small>Transportes, hospitais, escolas e até bancos. Que setores vão ser afetados pela greve geral? – ECO

Greve Geral De 11 De Dezembro – UGT MADEIRA
-------------------------------------------

 ![Greve Geral de 11 de dezembro – UGT MADEIRA](https://www.ugt.pt/publicfiles/d0b1baa907190cd7253e353893dcc34837999b11.jpg) <small>ugtmadeira.pt</small>Greve Geral de 11 de dezembro – UGT MADEIRA

GREVE GERAL – Protesto Em Frente Da Escola Secundária De Caneças – 11 Dezembro 8h00 – Sindicato
-----------------------------------------------------------------------------------------------

 ![GREVE GERAL – Protesto em frente da Escola Secundária de Caneças – 11 Dezembro 8h00 – Sindicato](https://stop-sindicato.pt/wp-content/uploads/2025/12/S.TO_.P.-Cartaz-Protesto-AE-Canecas-GreveGeral-11Dez-8h-1086x1536.png) <small>stop-sindicato.pt</small>GREVE GERAL – Protesto em frente da Escola Secundária de Caneças – 11 Dezembro 8h00 – Sindicato ...

Climáximo Apoia A Greve Geral - Climaximo
-----------------------------------------

 ![Climáximo apoia a Greve Geral - Climaximo](https://www.climaximo.pt/wp-content/uploads/2025/12/Greve-Geral3-819x1024.png) <small>www.climaximo.pt</small>Climáximo apoia a Greve Geral - Climaximo

Adere à Greve Geral Dia 11 De Dezembro
--------------------------------------

 ![Adere à Greve Geral dia 11 de dezembro](https://www.sep.org.pt/files/uploads/2025/11/SEP_GREVEGERAL_WEB_1-800x350.jpg) <small>www.sep.org.pt</small>Adere à Greve Geral dia 11 de dezembro

ASSIFECO ADERE À GREVE GERAL DE 11 DE DEZEMBRO — ASSIFECO
---------------------------------------------------------

 ![ASSIFECO ADERE À GREVE GERAL DE 11 DE DEZEMBRO — ASSIFECO](https://www.assifeco.pt/images/2025/12/05/USI BANNER_thumbnail.jpg) <small>www.assifeco.pt</small>ASSIFECO ADERE À GREVE GERAL DE 11 DE DEZEMBRO — ASSIFECO

Greve Geral De 11 De Dezembro Em Portugal: Razões Para Participar
-----------------------------------------------------------------

 ![Greve Geral de 11 de dezembro em Portugal: razões para participar](https://sabiasque.pt/images/stories/2025/trabalho/20251209-greve-geral-11-dezembro-320x480.jpg) <small>sabiasque.pt</small>Greve Geral de 11 de dezembro em Portugal: razões para participar

Greve Geral De 11 De Dezembro Pressiona Governo Português
---------------------------------------------------------

 ![Greve Geral de 11 de dezembro pressiona governo português](https://radiopeaobrasil.com.br/wp-content/uploads/2025/12/dvc3keu4ex9l4e2fizbuignqdef3jdmrhdwzogyd.png) <small>radiopeaobrasil.com.br</small>Greve Geral de 11 de dezembro pressiona governo português

GREVE GERAL | 11 DEZEMBRO 2025 - ATE
------------------------------------

 ![GREVE GERAL | 11 DEZEMBRO 2025 - ATE](https://www.ate.pt/wp-content/uploads/2025/12/Greve-geral-11.12.jpg) <small>www.ate.pt</small>GREVE GERAL | 11 DEZEMBRO 2025 - ATE

Pré-Aviso De Greve 11 E 12 De Dezembro
--------------------------------------

 ![Pré-Aviso de Greve 11 e 12 de dezembro](https://static.wixstatic.com/media/1029eb_b4cf39036f744ea9833c234b7b4b5af5~mv2.jpg/v1/fill/w_980,h_1386,al_c,q_85,usm_0.66_1.00_0.01,enc_avif,quality_auto/1029eb_b4cf39036f744ea9833c234b7b4b5af5~mv2.jpg) <small>www.aecadaval.com</small>Pré-Aviso de Greve 11 e 12 de dezembro

Greve Geral De 11 De Dezembro: Impacto Económico Estimado E Análise | Economia
------------------------------------------------------------------------------

 ![Greve Geral de 11 de Dezembro: Impacto Económico Estimado e Análise | Economia](https://i.headtopics.com/images/2025/12/6/publico/greve-geral-o-que-e-quem-abrange-e-como-funciona-greve-geral-o-que-e-quem-abrange-e-como-funciona-43970BF408A401F542300934033BEA05.webp?w=640) <small>ph.headtopics.com</small>Greve Geral de 11 de Dezembro: Impacto Económico Estimado e Análise | Economia

Greve Geral Paralisa Transportes, Saúde E Educação No Porto - Expresso
----------------------------------------------------------------------

 ![Greve geral paralisa transportes, saúde e educação no Porto - Expresso](https://images.impresa.pt/expresso/2025-12-11-rds_15_greve-geral-2025-manifestacao-porto_rds_4314.jpg-f75ffda9/original) <small>expresso.pt</small>Greve geral paralisa transportes, saúde e educação no Porto - Expresso

Greve Geral — 11 De Dezembro — Contra O Pacote Laboral | Partido Comunista Português
------------------------------------------------------------------------------------

 ![Greve Geral — 11 de Dezembro — Contra o Pacote Laboral | Partido Comunista Português](https://www.pcp.pt/sites/default/files/imagecache/facebook_share/images/dossiers/greve_geral_11_dez_2025/capa.jpg) <small>www.pcp.pt</small>Greve Geral — 11 de Dezembro — Contra o Pacote Laboral | Partido Comunista Português

Motivos Da Adesão à Greve Geral De 11 De Dezembro De 2025
---------------------------------------------------------

 ![Motivos da adesão à Greve Geral de 11 de dezembro de 2025](https://spzn.pt/uploads/noticias/big_1763717239_6728_SPZN_2025_site_novo_(17).png) <small>spzn.pt</small>Motivos da adesão à Greve Geral de 11 de dezembro de 2025

TCB | Pré-aviso De Greve A 11 De Dezembro - Portal Institucional
----------------------------------------------------------------

 ![TCB | Pré-aviso de greve a 11 de dezembro - Portal Institucional](https://www.cm-barreiro.pt/wp-content/uploads/2025/12/GREVE-11_DEZEMBRO_1920px-1536x920.jpg) <small>www.cm-barreiro.pt</small>TCB | Pré-aviso de greve a 11 de dezembro - Portal Institucional

A Greve Geral De 11 De Dezembro Em 38 Imagens – Observador
----------------------------------------------------------

 ![A greve geral de 11 de dezembro em 38 imagens – Observador](https://bordalo.observador.pt/v2/q:60/rs:fill:1440/c:4096:2730:nowe:0:0/plain/https://s3.observador.pt/wp-content/uploads/2025/12/11090822/dventura-greve-geral-11dez-8-scaled.jpg) <small>observador.pt</small>A greve geral de 11 de dezembro em 38 imagens – Observador

S.to.p. junta-se à greve geral de 11 de dezembro com pré-aviso de greve para a educação .... Contratos, horários, parentalidade e despedimentos: novo ano antecipa revolução no trabalho. Mais de 50 sindicatos aderem à greve geral marcada para 11 de dezembro
