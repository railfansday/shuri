---
title: "Cantor Colburn Llp - Cantor colburn adds 11 new attorneys and patent agents to strengthen intellectual property"
description: "2023 korea-us ip forum and pct roundtable"
date: "2026-10-03"
categories:
- "Uncategorized"
images:
- "https://media.licdn.com/dms/image/D4E05AQGVkBXIes1clQ/videocover-high/0/1690477726086?e=2147483647&amp;v=beta&amp;t=NVabY-5JlVGn-S9z93xB7Lm_TDvbBcOnRB8kEl8FTRU"
featuredImage: "https://www.cantorcolburn.com/assets/htmlimages/Cantor Colburn Congratulations to AECM Spirit of Achievement 2025.png"
featured_image: "https://www.cantorcolburn.com/assets/htmlimages/Cantor Colburn Congratulations to AECM Spirit of Achievement 2025.png"
image: "https://media.licdn.com/dms/image/C5622AQGj0wUKcmDBKg/feedshare-shrink_2048_1536/0/1655945053432?e=2147483647&amp;v=beta&amp;t=xeSucBtsWUzUEv_-SU1PebnKCWX_lfUkmXwainDf2uM"
---

If you are looking for Cantor Colburn LLP on LinkedIn: #teamcantorcolburn #intellectualproperty #patents #trademarks you've came to the right place. We have 35 Pics about Cantor Colburn LLP on LinkedIn: #teamcantorcolburn #intellectualproperty #patents #trademarks like Cantor Colburn Continues Growth, Adding Experienced Patent Attorneys and Agent in Chemistry, Cantor Colburn LLP on LinkedIn: Cantor Colburn Recognized in “Best Law Firms” by U.S. News and also Cantor Colburn. Here it is:

Cantor Colburn LLP On LinkedIn: #teamcantorcolburn #intellectualproperty #patents #trademarks
---------------------------------------------------------------------------------------------

 ![Cantor Colburn LLP on LinkedIn: #teamcantorcolburn #intellectualproperty #patents #trademarks](https://media.licdn.com/dms/image/D4E22AQFWVlMNg8Uh7w/feedshare-shrink_2048_1536/0/1704396519970?e=2147483647&v=beta&t=wHetKe76n3uMJR3MQUnU_Wq2XwnhJjlNZyNBjvdnMhY) <small>www.linkedin.com</small>Cantor Colburn LLP on LinkedIn: #teamcantorcolburn #intellectualproperty #patents #trademarks ...

Cantor Colburn
--------------

 ![Cantor Colburn](https://images.crunchbase.com/image/upload/c_pad,h_256,w_256,f_auto,q_auto:eco,dpr_1/v1416894795/df9cxum9ym9ysootidz2.png) <small>www.crunchbase.com</small>Cantor Colburn

Cantor Colburn Super Lawyers 2025: Cantor Colburn
-------------------------------------------------

 ![Cantor Colburn Super Lawyers 2025: Cantor Colburn](https://www.cantorcolburn.com/assets/htmlimages/Super Lawyers 2025 just photos.png) <small>www.cantorcolburn.com</small>Cantor Colburn Super Lawyers 2025: Cantor Colburn

Cantor Colburn LLP On LinkedIn: Congratulations To Our IP STARS (Managing IP) 2021 Michael
------------------------------------------------------------------------------------------

 ![Cantor Colburn LLP on LinkedIn: Congratulations to our IP STARS (Managing IP) 2021 Michael](https://media.licdn.com/dms/image/C4E22AQHbjNijAdCu8Q/feedshare-shrink_2048_1536/0/1626874672740?e=2147483647&v=beta&t=J05YhbTbvlbDe8MFSwCVBfrWOpHXhHTp8YN82lBNC9o) <small>www.linkedin.com</small>Cantor Colburn LLP on LinkedIn: Congratulations to our IP STARS (Managing IP) 2021 Michael ...

Cantor Colburn LLP (@CantorColburn) / Posts / X
-----------------------------------------------

 ![Cantor Colburn LLP (@CantorColburn) / Posts / X](https://pbs.twimg.com/media/FGB0WJxXwAEhVwh.jpg) <small>x.com</small>Cantor Colburn LLP (@CantorColburn) / Posts / X

Cantor Colburn Sponsors 2018 UConn Patent: Cantor Colburn
---------------------------------------------------------

 ![Cantor Colburn Sponsors 2018 UConn Patent: Cantor Colburn](https://www.cantorcolburn.com/assets/htmlimages/Cantor_Michael_bio.jpg) <small>www.cantorcolburn.com</small>Cantor Colburn Sponsors 2018 UConn Patent: Cantor Colburn

Cantor Colburn LLP On LinkedIn: #tradesecrets #ai #artificialintelligence #intellectualproperty
-----------------------------------------------------------------------------------------------

 ![Cantor Colburn LLP on LinkedIn: #tradesecrets #ai #artificialintelligence #intellectualproperty](https://media.licdn.com/dms/image/v2/D4D22AQG6wziQ_0uYYQ/feedshare-shrink_800/feedshare-shrink_800/0/1733524880005?e=2147483647&v=beta&t=bgOCZ4y5fuaX8QioJ5bMRC4K_baCnD8e6SGL1UwEG8Y) <small>www.linkedin.com</small>Cantor Colburn LLP on LinkedIn: #tradesecrets #ai #artificialintelligence #intellectualproperty

Cantor Colburn LLP On LinkedIn: Working Examples In Patent Applications: How Much Detail To Include?
----------------------------------------------------------------------------------------------------

 ![Cantor Colburn LLP on LinkedIn: Working examples in patent applications: how much detail to include?](https://media.licdn.com/dms/image/D4E10AQEc4a4gCMQIvQ/image-shrink_1280/0/1704715208788?e=2147483647&v=beta&t=6dNRbVst40esq_ys6xqV6HvaD6Fjh9ypmqmzVIjQjTk) <small>www.linkedin.com</small>Cantor Colburn LLP on LinkedIn: Working examples in patent applications: how much detail to include?

Cantor Colburn
--------------

 ![Cantor Colburn](https://images.crunchbase.com/image/upload/c_lpad,h_256,w_256,f_auto,q_auto:eco,dpr_1/v1416894795/df9cxum9ym9ysootidz2.png) <small>www.crunchbase.com</small>Cantor Colburn

Cantor Colburn LLP On LinkedIn: #intellectualproperty #jointventures #agreements #iptransactions
------------------------------------------------------------------------------------------------

 ![Cantor Colburn LLP on LinkedIn: #intellectualproperty #jointventures #agreements #iptransactions](https://media.licdn.com/dms/image/D4E22AQERrr8FxMrmgA/feedshare-shrink_2048_1536/0/1712167711409?e=2147483647&v=beta&t=PuY2szS25GQuSFowadmD0TaIA2kbu7Q-1UJzzIC9G6E) <small>www.linkedin.com</small>Cantor Colburn LLP on LinkedIn: #intellectualproperty #jointventures #agreements #iptransactions

\#teamcantorcolburn | Cantor Colburn LLP
----------------------------------------

 ![#teamcantorcolburn | Cantor Colburn LLP](https://media.licdn.com/dms/image/v2/D4E22AQGonvJY_nwUBg/feedshare-shrink_1280/B4EZu80_1gHkAs-/0/1768399568874?e=2147483647&v=beta&t=ck_lJNw50UW24VQaG9ygHfPWup8BRXIKq6F5LQw0lMk) <small>www.linkedin.com</small>\#teamcantorcolburn | Cantor Colburn LLP

Cantor Colburn LLP On LinkedIn: #teamcantorcolburn
--------------------------------------------------

 ![Cantor Colburn LLP on LinkedIn: #teamcantorcolburn](https://media.licdn.com/dms/image/D4E05AQGVkBXIes1clQ/videocover-high/0/1690477726086?e=2147483647&v=beta&t=NVabY-5JlVGn-S9z93xB7Lm_TDvbBcOnRB8kEl8FTRU) <small>www.linkedin.com</small>Cantor Colburn LLP on LinkedIn: #teamcantorcolburn

Cantor Colburn LLP On LinkedIn: #teamcantorcolburn #intellectualproperty #patent #trademark #iplaw…
---------------------------------------------------------------------------------------------------

 ![Cantor Colburn LLP on LinkedIn: #teamcantorcolburn #intellectualproperty #patent #trademark #iplaw…](https://media.licdn.com/dms/image/D4D22AQGoTRvEyf0JNA/feedshare-shrink_2048_1536/0/1681915556039?e=2147483647&v=beta&t=BQU5OcZzUtFyUXJfGY8flseuvTtFXT0LcITMEMGoL3o) <small>www.linkedin.com</small>Cantor Colburn LLP on LinkedIn: #teamcantorcolburn #intellectualproperty #patent #trademark #iplaw…

Cantor Colburn LLP On LinkedIn: #intellectualproperty #duediligence #ipduediligence #acquisition
------------------------------------------------------------------------------------------------

 ![Cantor Colburn LLP on LinkedIn: #intellectualproperty #duediligence #ipduediligence #acquisition](https://media.licdn.com/dms/image/C4D22AQF-sl5NR4yqMQ/feedshare-shrink_2048_1536/0/1676577917284?e=2147483647&v=beta&t=bnJqFoVNNFk7a7Ne5M6uga_2sXJbWFU7uYBUoWWyr1E) <small>www.linkedin.com</small>Cantor Colburn LLP on LinkedIn: #intellectualproperty #duediligence #ipduediligence #acquisition ...

Cantor Colburn LLP On LinkedIn: #teamcantorcolburn #intellectualproperty #patentlaw #patents #
----------------------------------------------------------------------------------------------

 ![Cantor Colburn LLP on LinkedIn: #teamcantorcolburn #intellectualproperty #patentlaw #patents #](https://media.licdn.com/dms/image/v2/D4E22AQH1dvL25ni9ZQ/feedshare-shrink_2048_1536/feedshare-shrink_2048_1536/0/1679945637391?e=2147483647&v=beta&t=9csFDINX2gu-zjiAzBHHzLT5rSkqRcIN5p2lxITQboY) <small>www.linkedin.com</small>Cantor Colburn LLP on LinkedIn: #teamcantorcolburn #intellectualproperty #patentlaw #patents # ...

Cantor Colburn Adds 11 New Attorneys And Patent Agents To Strengthen Intellectual Property
------------------------------------------------------------------------------------------

 ![Cantor Colburn Adds 11 New Attorneys and Patent Agents to Strengthen Intellectual Property](https://ipwatchdog.com/wp-content/uploads/2023/09/Cantor-Colburn-Logo-Square1-copy.jpg) <small>ipwatchdog.com</small>Cantor Colburn Adds 11 New Attorneys and Patent Agents to Strengthen Intellectual Property ...

Enforceable Nondisclosure Agreements: Protecting Trade Secrets And Other Confidential Business
----------------------------------------------------------------------------------------------

 ![Enforceable Nondisclosure Agreements: Protecting Trade Secrets and Other Confidential Business](https://www.cantorcolburn.com/assets/htmlimages/Bomzer Trade Secrets Agreements Strafford January 2024.png) <small>www.cantorcolburn.com</small>Enforceable Nondisclosure Agreements: Protecting Trade Secrets and Other Confidential Business ...

Tong Kim, Ph.D.: Cantor Colburn
-------------------------------

 ![Tong Kim, Ph.D.: Cantor Colburn](https://www.cantorcolburn.com/assets/images/743_profile.png) <small>www.cantorcolburn.com</small>Tong Kim, Ph.D.: Cantor Colburn

IP Stars 2025: Cantor Colburn
-----------------------------

 ![IP Stars 2025: Cantor Colburn](https://www.cantorcolburn.com/assets/htmlimages/IP Stars 2025 LinkedIn.png) <small>www.cantorcolburn.com</small>IP Stars 2025: Cantor Colburn

2023 Ten Most Well-Respected Law Firms: Cantor Colburn
------------------------------------------------------

 ![2023 Ten Most Well-Respected Law Firms: Cantor Colburn](https://www.cantorcolburn.com/assets/htmlimages/Award Winning Law Firm 2023 -Cantor Colburn.png) <small>www.cantorcolburn.com</small>2023 Ten Most Well-Respected Law Firms: Cantor Colburn

\#teamcantorcolburn #intellectualproperty #judgesdinner2023 #judgesdinner | Cantor Colburn LLP
----------------------------------------------------------------------------------------------

 ![#teamcantorcolburn #intellectualproperty #judgesdinner2023 #judgesdinner | Cantor Colburn LLP](https://media.licdn.com/dms/image/v2/D4E22AQGae5Agrx9JZw/feedshare-shrink_2048_1536/feedshare-shrink_2048_1536/0/1680554514536?e=2147483647&v=beta&t=JL8G_N2hV3-kKOykHPmIb3vGgySw6YJl_xLMFZf4IyI) <small>www.linkedin.com</small>\#teamcantorcolburn #intellectualproperty #judgesdinner2023 #judgesdinner | Cantor Colburn LLP

Dave S. Christensen | Cantor Colburn LLP
----------------------------------------

 ![Dave S. Christensen | Cantor Colburn LLP](https://media.licdn.com/dms/image/v2/C4E22AQEZOqoVtXffbg/feedshare-shrink_800/feedshare-shrink_800/0/1566502253468?e=2147483647&v=beta&t=nPfPQtaq1u1E0KSJMcGm-HHPqWxeeT50hZ7mwukCSOs) <small>www.linkedin.com</small>Dave S. Christensen | Cantor Colburn LLP

Cantor Colburn LLP On LinkedIn: #intellectualproperty #michigan #mackinac #icle
-------------------------------------------------------------------------------

 ![Cantor Colburn LLP on LinkedIn: #intellectualproperty #michigan #mackinac #icle](https://media.licdn.com/dms/image/C4D22AQHxVIcFfGwmpg/feedshare-shrink_2048_1536/0/1658243202529?e=2147483647&v=beta&t=AthQoXu9FWN1pzfVEWVQ_l_X0ejWh4l9pkFCo_Wux8w) <small>www.linkedin.com</small>Cantor Colburn LLP on LinkedIn: #intellectualproperty #michigan #mackinac #icle

Albert Einstein College Of Medicine Spirit Of Achievement Luncheon 2025: Cantor Colburn
---------------------------------------------------------------------------------------

 ![Albert Einstein College of Medicine Spirit of Achievement Luncheon 2025: Cantor Colburn](https://www.cantorcolburn.com/assets/htmlimages/Cantor Colburn Congratulations to AECM Spirit of Achievement 2025.png) <small>www.cantorcolburn.com</small>Albert Einstein College of Medicine Spirit of Achievement Luncheon 2025: Cantor Colburn

Top Ranking In ANDA Litigation: Cantor Colburn
----------------------------------------------

 ![Top Ranking in ANDA Litigation: Cantor Colburn](https://www.cantorcolburn.com/assets/htmlimages/patexia anda 2024 linkedin.png) <small>www.cantorcolburn.com</small>Top Ranking in ANDA Litigation: Cantor Colburn

2023 Korea-US IP Forum And PCT Roundtable | Cantor Colburn LLP
--------------------------------------------------------------

 ![2023 Korea-US IP Forum and PCT Roundtable | Cantor Colburn LLP](https://media.licdn.com/dms/image/sync/v2/D4E27AQH6tDyXJ8WtEQ/articleshare-shrink_800/articleshare-shrink_800/0/1711600708991?e=2147483647&v=beta&t=oB4M3quzILRwkNJc76kt9Rik6wfgYuvixSeBq8TtCgc) <small>www.linkedin.com</small>2023 Korea-US IP Forum and PCT Roundtable | Cantor Colburn LLP

Cantor Colburn LLP On LinkedIn: #ipstars #intellectualproperty
--------------------------------------------------------------

 ![Cantor Colburn LLP on LinkedIn: #ipstars #intellectualproperty](https://media.licdn.com/dms/image/C5622AQGj0wUKcmDBKg/feedshare-shrink_2048_1536/0/1655945053432?e=2147483647&v=beta&t=xeSucBtsWUzUEv_-SU1PebnKCWX_lfUkmXwainDf2uM) <small>www.linkedin.com</small>Cantor Colburn LLP on LinkedIn: #ipstars #intellectualproperty

Benjamin Cantor On LinkedIn: Benjamin Cantor Recognized As A Rising Star By INTA
--------------------------------------------------------------------------------

 ![Benjamin Cantor on LinkedIn: Benjamin Cantor Recognized as a Rising Star by INTA](https://media.licdn.com/dms/image/sync/D4D27AQGwTDi0bCaj_A/articleshare-shrink_800/0/1714657827191?e=2147483647&v=beta&t=uhZBbNSKl1Euv5rlp8Q2UQSa884y_gXBEVH0UZdAT8U) <small>www.linkedin.com</small>Benjamin Cantor on LinkedIn: Benjamin Cantor Recognized as a Rising Star by INTA

Our Offices: Cantor Colburn
---------------------------

 ![Our Offices: Cantor Colburn](https://www.cantorcolburn.com/assets/images/249.jpeg) <small>www.cantorcolburn.com</small>Our Offices: Cantor Colburn

Cantor Colburn LLP On LinkedIn: Cantor Colburn Recognized In “Best Law Firms” By U.S. News
------------------------------------------------------------------------------------------

 ![Cantor Colburn LLP on LinkedIn: Cantor Colburn Recognized in “Best Law Firms” by U.S. News](https://media.licdn.com/dms/image/v2/C5634AQELQXPXnhVHzw/ugc-proxy-shrink_800/ugc-proxy-shrink_800/0/1598486102085?e=2147483647&v=beta&t=3ZS2FApNHMCruwXgiKGCIw-H-67BsUCJt1dj8s7IBCs) <small>www.linkedin.com</small>Cantor Colburn LLP on LinkedIn: Cantor Colburn Recognized in “Best Law Firms” by U.S. News ...

Cantor Colburn LLP | LinkedIn
-----------------------------

 ![Cantor Colburn LLP | LinkedIn](https://media.licdn.com/dms/image/v2/D4E0BAQEC1IMnQbIkwg/company-logo_200_200/company-logo_200_200/0/1719854608485/cantor_colburn_llp_logo?e=2147483647&v=beta&t=03TbBh89yOztxQqBB9hiJZf4w6jUEh_gKqhID1YtW-8) <small>www.linkedin.com</small>Cantor Colburn LLP | LinkedIn

\#teamcantorcolburn | Cantor Colburn LLP
----------------------------------------

 ![#teamcantorcolburn | Cantor Colburn LLP](https://media.licdn.com/dms/image/v2/D4E22AQHOt8P7kFVAMw/feedshare-shrink_800/B4EZStud3zHcAg-/0/1738081427847?e=2147483647&v=beta&t=vMcsMYylOfL3hjQK6-iTsXM1KU6KufdjZI36c7GBvYE) <small>www.linkedin.com</small>\#teamcantorcolburn | Cantor Colburn LLP

The 2026 Invention Convention Florida: Cantor Colburn
-----------------------------------------------------

 ![The 2026 Invention Convention Florida: Cantor Colburn](https://www.cantorcolburn.com/assets/htmlimages/Kincaid_David_high.jpg) <small>www.cantorcolburn.com</small>The 2026 Invention Convention Florida: Cantor Colburn

Cantor Colburn Continues Growth, Adding Experienced Patent Attorneys And Agent In Chemistry
-------------------------------------------------------------------------------------------

 ![Cantor Colburn Continues Growth, Adding Experienced Patent Attorneys and Agent in Chemistry](https://ipwatchdog.com/wp-content/uploads/2023/04/Cantor-Colburn-LLP-logo.jpeg) <small>ipwatchdog.com</small>Cantor Colburn Continues Growth, Adding Experienced Patent Attorneys and Agent in Chemistry ...

Cantor Colburn Welcomes Patent Attorneys LeRoy Ashley III And Jonathan Staudt: Cantor Colburn
---------------------------------------------------------------------------------------------

 ![Cantor Colburn Welcomes Patent Attorneys LeRoy Ashley III and Jonathan Staudt: Cantor Colburn](https://www.cantorcolburn.com/assets/htmlimages/Ashley Staudt Spotlight.png) <small>www.cantorcolburn.com</small>Cantor Colburn Welcomes Patent Attorneys LeRoy Ashley III and Jonathan Staudt: Cantor Colburn

Cantor colburn llp on linkedin: #tradesecrets #ai #artificialintelligence #intellectualproperty. Cantor colburn continues growth, adding experienced patent attorneys and agent in chemistry. Cantor colburn llp (@cantorcolburn) / posts / x
