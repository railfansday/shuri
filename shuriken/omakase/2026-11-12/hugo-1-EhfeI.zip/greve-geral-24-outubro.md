---
title: "Greve Geral 24 Outubro - greve (24h): dia 25 outubro"
description: "Frente comum anuncia greve da função pública em 24 de outubro"
date: "2025-12-28"
categories:
- "Uncategorized"
images:
- "https://pcdob.org.br/wp-content/uploads/2025/12/Ruas-de-Lisboa-foram-tomadas-por-trabalhadores-durante-a-greve-geral-Rafael-Medeiros-Esquerda.jpg"
featuredImage: "https://aetrofa.com/wp-content/uploads/2025/10/Informacao_725_26_signed-scaled.jpg"
featured_image: "https://www.cgtp.pt/images/images/2025/12/diario_gg/diario-banner.jpg"
image: "https://aeceleiros.pt/wp-content/uploads/2025/10/Greve_out2025_v1.png"
---

If you are looking for SPN - Greve da Administração Pública com impacto nas escolas! you've came to the right place. We have 35 Images about SPN - Greve da Administração Pública com impacto nas escolas! like Greve Nacional | 24 de outubro - SPRA, Administração Pública em greve no próximo dia 24 de Outubro. - CGTP-IN and also Greve Geral juntou centenas nos Aliados. Governo fala em adesão "inexpressiva" - JPN. Read more:

SPN - Greve Da Administração Pública Com Impacto Nas Escolas!
-------------------------------------------------------------

 ![SPN - Greve da Administração Pública com impacto nas escolas!](https://spn.pt/Media/Default/Info/68000/100/50/7/greve24out (4).jpg) <small>spn.pt</small>SPN - Greve da Administração Pública com impacto nas escolas!

Os Inspetores Tributários E Aduaneiros Aderem à Greve Nacional Dos Trabalhadores Da
-----------------------------------------------------------------------------------

 ![Os Inspetores Tributários e Aduaneiros aderem à Greve Nacional dos Trabalhadores da](https://apit.pt/wp-content/uploads/2023/10/greve-3.jpg) <small>apit.pt</small>Os Inspetores Tributários e Aduaneiros aderem à Greve Nacional dos Trabalhadores da ...

PRÉ- AVISO DE GREVE – 23 E 24 De Outubro – AEC
----------------------------------------------

 ![PRÉ- AVISO DE GREVE – 23 e 24 de outubro – AEC](https://aeceleiros.pt/wp-content/uploads/2025/10/Greve_out2025_v1.png) <small>aeceleiros.pt</small>PRÉ- AVISO DE GREVE – 23 e 24 de outubro – AEC

Greve Geral Juntou Centenas Nos Aliados. Governo Fala Em Adesão "inexpressiva" - JPN
------------------------------------------------------------------------------------

 ![Greve Geral juntou centenas nos Aliados. Governo fala em adesão "inexpressiva" - JPN](https://www.jpn.up.pt/wp-content/uploads/2025/12/greve_geral9.jpg) <small>www.jpn.up.pt</small>Greve Geral juntou centenas nos Aliados. Governo fala em adesão "inexpressiva" - JPN

Pré-avisos De Greve 23 E 24 De Outubro De 2025 – AE Terras Do Ave
-----------------------------------------------------------------

 ![Pré-avisos de greve 23 e 24 de outubro de 2025 – AE Terras do Ave](https://aeterrasave.net/wp-content/uploads/2025/10/Greve23-24.png) <small>aeterrasave.net</small>Pré-avisos de greve 23 e 24 de outubro de 2025 – AE Terras do Ave

TCB | Pré-aviso De Greve A 24 Outubro - Portal Institucional
------------------------------------------------------------

 ![TCB | Pré-aviso de greve a 24 outubro - Portal Institucional](https://www.cm-barreiro.pt/wp-content/uploads/2025/10/GREVE-24_OUTUBRO_850px.png) <small>www.cm-barreiro.pt</small>TCB | Pré-aviso de greve a 24 outubro - Portal Institucional

Pré-Aviso De Greve – 24-10-2025 (atualização) - Agrupamento De Escolas Da Lousã
-------------------------------------------------------------------------------

 ![Pré-Aviso de Greve – 24-10-2025 (atualização) - Agrupamento de Escolas da Lousã](https://escolas.aglousa.com/wp-content/uploads/2019/06/greve.png) <small>escolas.aglousa.com</small>Pré-Aviso de Greve – 24-10-2025 (atualização) - Agrupamento de Escolas da Lousã

Frente Comum Diz Que Proposta De OE2026 "dá Mais Força" à Greve Geral De 24 De Outubro
--------------------------------------------------------------------------------------

 ![Frente Comum diz que proposta de OE2026 "dá mais força" à greve geral de 24 de outubro](https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA1Ohf0g.img?w=1280&h=720&m=4&q=75) <small>www.msn.com</small>Frente Comum diz que proposta de OE2026 "dá mais força" à greve geral de 24 de outubro

Imagens Do Dia De Greve Geral Em Portugal - Jornal O Globo
----------------------------------------------------------

 ![Imagens do dia de greve geral em Portugal - Jornal O Globo](https://ogimg.infoglobo.com.br/in/4387791-fd9-94b/FT1086A/760/foto2.jpg?posicaoFoto2) <small>oglobo.globo.com</small>Imagens do dia de greve geral em Portugal - Jornal O Globo

Greve Da Administração Pública – 23 E 24 De Outubro | AET
---------------------------------------------------------

 ![Greve da Administração Pública – 23 e 24 de outubro | AET](https://aetrofa.com/wp-content/uploads/2025/10/Informacao_725_26_signed-scaled.jpg) <small>aetrofa.com</small>Greve da Administração Pública – 23 e 24 de outubro | AET

Frente Comum. Proposta De OE “dá Mais Força” à Greve Geral De 24 De Outubro – ECO
---------------------------------------------------------------------------------

 ![Frente Comum. Proposta de OE “dá mais força” à greve geral de 24 de outubro – ECO](https://eco.imgix.net/uploads/2025/10/cropped-45727205-scaled.jpg?mark64=aHR0cHM6Ly9lY28uaW1naXgubmV0L0VDT193YXRlcm1hcmsucG5nP2ZtPXBuZw%3D%3D&markscale=33&markalign=center,left&w=1200) <small>eco.sapo.pt</small>Frente Comum. Proposta de OE “dá mais força” à greve geral de 24 de outubro – ECO

Greve 2024: Pauta De Reivindicações – Sinasefe RN
-------------------------------------------------

 ![Greve 2024: pauta de reivindicações – Sinasefe RN](https://sinasefe.org.br/site/wp-content/uploads/sites/3/2024/04/grevepautaredes-1024x1024.jpg) <small>www.sinasefern.org.br</small>Greve 2024: pauta de reivindicações – Sinasefe RN

Diário Da Greve Geral - CGTP-IN
-------------------------------

 ![Diário da Greve Geral - CGTP-IN](https://www.cgtp.pt/images/images/2025/12/diario_gg/diario-banner.jpg) <small>www.cgtp.pt</small>Diário da Greve Geral - CGTP-IN

Greve Geral: O Que Você Precisa Saber Sobre A Tentativa De Parar O País Pela 1ª Vez Em 20 Anos
----------------------------------------------------------------------------------------------

 ![Greve geral: o que você precisa saber sobre a tentativa de parar o país pela 1ª vez em 20 anos](https://ichef.bbci.co.uk/news/1024/branded_portuguese/11542/production/_95787907_931378-bancariosbc-9895.jpg) <small>www.bbc.com</small>Greve geral: o que você precisa saber sobre a tentativa de parar o país pela 1ª vez em 20 anos ...

CGTP Fala De Adesão Massiva à Greve Geral - TSF
-----------------------------------------------

 ![CGTP fala de adesão massiva à greve geral - TSF](https://staticx.noticiasilimitadas.pt/tsf/image.webp?brand=tsf&type=generate&guid=f2fd45e3-0eb3-424b-9e51-c41a22a41e1a&w=3840) <small>www.tsf.pt</small>CGTP fala de adesão massiva à greve geral - TSF

Greve 2024: Dados De Adesão Atualizados - SINASEFE
--------------------------------------------------

 ![Greve 2024: dados de adesão atualizados - SINASEFE](https://sinasefe.org.br/site/wp-content/uploads/sites/3/2024/04/20240402tabelagreve-600x325.jpg) <small>sinasefe.org.br</small>Greve 2024: dados de adesão atualizados - SINASEFE

FENPROF Emite Pré-aviso De Greve Para 27 De Outubro De 2023 E Junta-se Ao Protesto Dos
--------------------------------------------------------------------------------------

 ![FENPROF emite pré-aviso de greve para 27 de outubro de 2023 e junta-se ao protesto dos](https://www.spra.pt/wp-content/uploads/2023/10/cartaz-greve-fc-27-outubro-net-1-704x1024.jpg) <small>www.spra.pt</small>FENPROF emite pré-aviso de greve para 27 de outubro de 2023 e junta-se ao protesto dos ...

GREVE NACIONAL DOS MÉDICOS | 24 DE OUTUBRO - Sindicato Dos Médicos Do Norte
---------------------------------------------------------------------------

 ![GREVE NACIONAL DOS MÉDICOS | 24 DE OUTUBRO - Sindicato dos Médicos do Norte](https://www.sindicatomedicosnorte.pt/wp-content/uploads/2025/10/greve-nacional-dos-medicos-24-de-outubro.jpg) <small>www.sindicatomedicosnorte.pt</small>GREVE NACIONAL DOS MÉDICOS | 24 DE OUTUBRO - Sindicato dos Médicos do Norte

Pré-avisos Para Greve Na Função Pública (e Não Só) Esta 6ª
----------------------------------------------------------

 ![Pré-avisos para greve na Função Pública (e não só) esta 6ª](https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA1ZfPnB.img?w=768&h=512&m=6) <small>www.msn.com</small>Pré-avisos para greve na Função Pública (e não só) esta 6ª

Frente Comum Anuncia Greve Da Função Pública Em 24 De Outubro — DNOTICIAS.PT
----------------------------------------------------------------------------

 ![Frente Comum anuncia greve da função pública em 24 de Outubro — DNOTICIAS.PT](https://static-storage.dnoticias.pt/www-assets.dnoticias.pt/images/configuration/R/greve_dn_IEi1NHH.JPEG) <small>www.dnoticias.pt</small>Frente Comum anuncia greve da função pública em 24 de Outubro — DNOTICIAS.PT

SPN - Greve Da Administração Pública Com Impacto Nas Escolas!
-------------------------------------------------------------

 ![SPN - Greve da Administração Pública com impacto nas escolas!](https://spn.pt/Media/Default/Info/68000/100/50/7/greve24out (13).jpg) <small>spn.pt</small>SPN - Greve da Administração Pública com impacto nas escolas!

A Uma Semana Da Greve Geral, Sindicatos Anunciam Adesões Em Massa
-----------------------------------------------------------------

 ![A uma semana da greve geral, sindicatos anunciam adesões em massa](https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA247A0g.img?w=1200&h=798&m=4&q=70) <small>www.msn.com</small>A uma semana da greve geral, sindicatos anunciam adesões em massa

27 Outubro – GREVE NACIONAL – Conheça Aqui Os Seus Direitos – SPM – Sindicato Dos Professores Da
------------------------------------------------------------------------------------------------

 ![27 outubro – GREVE NACIONAL – conheça aqui os seus direitos – SPM – Sindicato dos Professores da](https://www.spm-ram.org/wp-content/uploads/2017/10/cartaz-GREVE_Geral-27.out_.2017-1.png) <small>www.spm-ram.org</small>27 outubro – GREVE NACIONAL – conheça aqui os seus direitos – SPM – Sindicato dos Professores da ...

Greve 24 De Outubro – SPM – Sindicato Dos Professores Da Madeira
----------------------------------------------------------------

 ![Greve 24 de outubro – SPM – Sindicato dos Professores da Madeira](https://www.spm-ram.org/wp-content/uploads/2025/10/Imagem-WhatsApp-2025-10-23-as-15.49.23_c3fac451.jpg) <small>www.spm-ram.org</small>Greve 24 de outubro – SPM – Sindicato dos Professores da Madeira

Metro Do Porto "fortemente Condicionado" No Dia Da Greve Geral - JPN
--------------------------------------------------------------------

 ![Metro do Porto "fortemente condicionado" no dia da greve geral - JPN](https://www.jpn.up.pt/wp-content/uploads/2025/12/greve_geral1-1152x759.jpg) <small>www.jpn.up.pt</small>Metro do Porto "fortemente condicionado" no dia da greve geral - JPN

Greve Da Função Pública Marcada Para O Dia 24 De Outubro
--------------------------------------------------------

 ![Greve da função pública marcada para o dia 24 de outubro](https://www.diarioviseu.pt/wp-content/uploads/sites/8/2024/12/Greve-escola.webp) <small>www.diarioviseu.pt</small>Greve da função pública marcada para o dia 24 de outubro

Greve Geral Paralisa Portugal Contra Precarização De Direitos
-------------------------------------------------------------

 ![Greve geral paralisa Portugal contra precarização de direitos](https://pcdob.org.br/wp-content/uploads/2025/12/Ruas-de-Lisboa-foram-tomadas-por-trabalhadores-durante-a-greve-geral-Rafael-Medeiros-Esquerda.jpg) <small>pcdob.org.br</small>Greve geral paralisa Portugal contra precarização de direitos

Greve Geral Juntou Centenas Nos Aliados. Governo Fala Em Adesão "inexpressiva" - JPN
------------------------------------------------------------------------------------

 ![Greve Geral juntou centenas nos Aliados. Governo fala em adesão "inexpressiva" - JPN](https://www.jpn.up.pt/wp-content/uploads/2025/12/greve_geral8.jpg) <small>www.jpn.up.pt</small>Greve Geral juntou centenas nos Aliados. Governo fala em adesão "inexpressiva" - JPN

GREVE DOS TRABALHADORES DA ADMINISTRAÇÃO PÚBLICA – STTS
-------------------------------------------------------

 ![GREVE DOS TRABALHADORES DA ADMINISTRAÇÃO PÚBLICA – STTS](https://www.stts.pt/wp-content/uploads/2024/10/hoje-1024x524.jpg) <small>www.stts.pt</small>GREVE DOS TRABALHADORES DA ADMINISTRAÇÃO PÚBLICA – STTS

Greve (24h): Dia 25 Outubro - Metropolitano De Lisboa, E.P.E.
-------------------------------------------------------------

 ![Greve (24h): dia 25 outubro - Metropolitano de Lisboa, E.P.E.](https://www.metrolisboa.pt/wp-content/uploads/2022/10/greve-25-outubro-1080x450-1.png) <small>www.metrolisboa.pt</small>Greve (24h): dia 25 outubro - Metropolitano de Lisboa, E.P.E.

Motivos Da Adesão à Greve Geral De 11 De Dezembro De 2025
---------------------------------------------------------

 ![Motivos da adesão à Greve Geral de 11 de dezembro de 2025](https://spzn.pt/uploads/noticias/big_1763717239_6728_SPZN_2025_site_novo_(17).png) <small>spzn.pt</small>Motivos da adesão à Greve Geral de 11 de dezembro de 2025

Dados Recolhidos Até às 19h20 Demonstram Que A Greve Geral Parou O País - CGTP-IN
---------------------------------------------------------------------------------

 ![Dados recolhidos até às 19h20 demonstram que a Greve Geral parou o país - CGTP-IN](https://www.cgtp.pt/images/images/2025/11/gg_banner2025.jpg) <small>www.cgtp.pt</small>Dados recolhidos até às 19h20 demonstram que a Greve Geral parou o país - CGTP-IN

Administração Pública Em Greve No Próximo Dia 24 De Outubro. - CGTP-IN
----------------------------------------------------------------------

 ![Administração Pública em greve no próximo dia 24 de Outubro. - CGTP-IN](https://cgtp.pt/images/accao-e-luta/2025/frente-comum-1.jpg) <small>www.cgtp.pt</small>Administração Pública em greve no próximo dia 24 de Outubro. - CGTP-IN

Greve Nacional | 24 De Outubro - SPRA
-------------------------------------

 ![Greve Nacional | 24 de outubro - SPRA](https://www.spra.pt/wp-content/uploads/2025/10/cartaz-24-out-scaled.jpg) <small>www.spra.pt</small>Greve Nacional | 24 de outubro - SPRA

Frente Comum Anuncia Greve Da Função Pública Em 24 De Outubro - Jornal Mundo Lusíada
------------------------------------------------------------------------------------

 ![Frente Comum anuncia greve da função pública em 24 de outubro - Jornal Mundo Lusíada](https://www.mundolusiada.com.br/wp-content/uploads/2020/01/GreveFuncaoPublica_protesto-e1758896568993.jpg) <small>www.mundolusiada.com.br</small>Frente Comum anuncia greve da função pública em 24 de outubro - Jornal Mundo Lusíada

Metro do porto "fortemente condicionado" no dia da greve geral. Greve 2024: pauta de reivindicações – sinasefe rn. Frente comum diz que proposta de oe2026 "dá mais força" à greve geral de 24 de outubro
