---
title: "Atum-16/4-0-stk - Atum-16/4-0-stk te connectivity raychem cable protection"
description: "Atum-16/4-0-stk : raychem atum 4:1 heat shrink tubing"
date: "2026-06-05"
categories:
- "Uncategorized"
images:
- "https://www.te.com/content/dam/te-com/catalog/part/EM5/611/600/EM56116001-t3.jpg/jcr:content/renditions/product-small.png?w=85"
featuredImage: "https://mm.digikey.com/Volume0/opasdata/d220001/derivates/1/300/335/237/ATUM-16^4-0-STK_sml.jpg"
featured_image: "https://sku-product-images.s3.us-east-2.amazonaws.com/RYC/RYCATUM-16-4-0-STK.jpg"
image: "http://www.enwer.com/upfile/files/ATUM-16-4.jpg"
---

If you are looking for ATUM-16/4-0-STK TE Connectivity | Raychem Products | Heilind you've visit to the right place. We have 35 Pictures about ATUM-16/4-0-STK TE Connectivity | Raychem Products | Heilind like ATUM-16/4-0-STK TE Connectivity | Raychem Products | Heilind, ATUM-16/4-0-STK TE Connectivity Raychem Cable Protection | 电缆，电线 - 管理 | DigiKey and also ATUM-16/4-0-STK : RAYCHEM ATUM 4:1 Heat Shrink Tubing | TE Connectivity. Here you go:

ATUM-16/4-0-STK TE Connectivity | Raychem Products | Heilind
------------------------------------------------------------

 ![ATUM-16/4-0-STK TE Connectivity | Raychem Products | Heilind](https://sku-product-images.s3.us-east-2.amazonaws.com/RYC/RYCATUM-16-4-0-STK.jpg) <small>www.heilind.com</small>ATUM-16/4-0-STK TE Connectivity | Raychem Products | Heilind

ATUM-16/4-0-STK | TE Connectivity Heat Shrink Tubing, Black 16 Mm Sleeve Dia. X 1.2m Length
-------------------------------------------------------------------------------------------

 ![ATUM-16/4-0-STK | TE Connectivity Heat Shrink Tubing, Black 16 mm Sleeve Dia. x 1.2m Length](https://media.rs-online.com/image/upload/bo_1.5px_solid_white,b_auto,c_pad,dpr_2,f_auto,h_399,q_auto,w_710/c_pad,h_399,w_710/Y0487244-01?pgw=1) <small>uk.rs-online.com</small>ATUM-16/4-0-STK | TE Connectivity Heat Shrink Tubing, Black 16 mm Sleeve Dia. x 1.2m Length ...

ATUM
----

 ![ATUM](https://scp-sa.es/413-home_default/atum-16-4-0-sp.jpg) <small>scp-sa.es</small>ATUM

TE Connectivity - ATUM-16/4-0 - Black Adhesive Lined Heat Shrink Tubing, 16mm, 4:1, 1.2m Length - RS
----------------------------------------------------------------------------------------------------

 ![TE Connectivity - ATUM-16/4-0 - Black Adhesive Lined Heat Shrink Tubing, 16mm, 4:1, 1.2m Length - RS](https://assets.rs-online.com/f_auto,q_auto,c_scale,w_400/70226662.jpg) <small>us.rs-online.com</small>TE Connectivity - ATUM-16/4-0 - Black Adhesive Lined Heat Shrink Tubing, 16mm, 4:1, 1.2m Length - RS

ATUM-16/4-0 TE Connectivity | TE Connectivity Heat Shrink Tubing, Black 16 Mm Sleeve Dia. X 1.2m
------------------------------------------------------------------------------------------------

 ![ATUM-16/4-0 TE Connectivity | TE Connectivity Heat Shrink Tubing, Black 16 mm Sleeve Dia. x 1.2m](https://res.cloudinary.com/rsc/image/upload/b_rgb:FFFFFF,c_pad,dpr_1.0,f_auto,q_auto,w_700/c_pad,w_700/F3161653-02) <small>in.rsdelivers.com</small>ATUM-16/4-0 TE Connectivity | TE Connectivity Heat Shrink Tubing, Black 16 mm Sleeve Dia. x 1.2m ...

ATUM-16/4-0-STK TE - RF/IF Ve RFID - E-komponent.com
----------------------------------------------------

 ![ATUM-16/4-0-STK TE - RF/IF ve RFID - e-komponent.com](https://www.e-komponent.com/isiyla-daralan-makaron-atum-16-4-0-stk-isiyla-daralan-makaron-te-connectivity-raychem-cable-protection-44965-34-B.jpg) <small>www.e-komponent.com</small>ATUM-16/4-0-STK TE - RF/IF ve RFID - e-komponent.com

ATUM-16/4-0-STK TE Connectivity Raychem Cable Protection | 电缆，电线 - 管理 | DigiKey
-------------------------------------------------------------------------------

 ![ATUM-16/4-0-STK TE Connectivity Raychem Cable Protection | 电缆，电线 - 管理 | DigiKey](https://mm.digikey.com/Volume0/opasdata/d220001/derivates/1/300/335/237/ATUM-16^4-0-STK_sml.jpg) <small>www.digikey.cn</small>ATUM-16/4-0-STK TE Connectivity Raychem Cable Protection | 电缆，电线 - 管理 | DigiKey

ATUM-16/4-0-STK | Raychem Gaines Thermorétractables Polyoléfine, 4 16mm, Noir, 1.2m, Unité
------------------------------------------------------------------------------------------

 ![ATUM-16/4-0-STK | Raychem Gaines thermorétractables Polyoléfine, 4 16mm, Noir, 1.2m, Unité](https://media.distrelec.com/Web/WebShopImages/landscape_large/_t/if/schrumpfschlauche-halogenfrei-w-1-h.jpg) <small>www.distrelec.ch</small>ATUM-16/4-0-STK | Raychem Gaines thermorétractables Polyoléfine, 4 ... 16mm, Noir, 1.2m, Unité ...

ATUM-16/4-0-STK TE Connectivity Raychem Cable Protection | 电缆，电线 - 管理 | DigiKey
-------------------------------------------------------------------------------

 ![ATUM-16/4-0-STK TE Connectivity Raychem Cable Protection | 电缆，电线 - 管理 | DigiKey](https://mm.digikey.com/Volume0/opasdata/d220001/derivates/3/010/197/334/ATUM-8^2-0-STK_tmb.jpg) <small>www.digikey.cn</small>ATUM-16/4-0-STK TE Connectivity Raychem Cable Protection | 电缆，电线 - 管理 | DigiKey

ATUM-16/4-0-STK : RAYCHEM ATUM 4:1 Heat Shrink Tubing | TE Connectivity
-----------------------------------------------------------------------

 ![ATUM-16/4-0-STK : RAYCHEM ATUM 4:1 Heat Shrink Tubing | TE Connectivity](https://www.te.com/content/dam/te-com/catalog/part/EM5/611/600/EM56116001-t2.jpg/jcr:content/renditions/product-small.png?w=85) <small>www.te.com</small>ATUM-16/4-0-STK : RAYCHEM ATUM 4:1 Heat Shrink Tubing | TE Connectivity

ATUM-16/4-0-STK : RAYCHEM ATUM 4:1 Heat Shrink Tubing | TE Connectivity
-----------------------------------------------------------------------

 ![ATUM-16/4-0-STK : RAYCHEM ATUM 4:1 Heat Shrink Tubing | TE Connectivity](https://www.te.com/content/dam/te-com/catalog/part/EM5/611/600/EM56116001-t5.jpg/jcr:content/renditions/product-small.png?w=220) <small>www.te.com</small>ATUM-16/4-0-STK : RAYCHEM ATUM 4:1 Heat Shrink Tubing | TE Connectivity

ATUM-16/4-0-STK TE Connectivity Raychem Cable Protection | 电缆，电线 - 管理 | DigiKey
-------------------------------------------------------------------------------

 ![ATUM-16/4-0-STK TE Connectivity Raychem Cable Protection | 电缆，电线 - 管理 | DigiKey](https://mm.digikey.com/Volume0/opasdata/d220001/derivates/3/300/335/237/ATUM-16^4-0-STK_tmb.jpg) <small>www.digikey.cn</small>ATUM-16/4-0-STK TE Connectivity Raychem Cable Protection | 电缆，电线 - 管理 | DigiKey

ATUM-16/4-0-STK TE Connectivity Raychem Cable Protection | 电缆，电线 - 管理 | DigiKey
-------------------------------------------------------------------------------

 ![ATUM-16/4-0-STK TE Connectivity Raychem Cable Protection | 电缆，电线 - 管理 | DigiKey](https://media.digikey.com/pdf/Catalog Drawings/Heat Shrink/ATUM-164-0-STK.jpg) <small>www.digikey.cn</small>ATUM-16/4-0-STK TE Connectivity Raychem Cable Protection | 电缆，电线 - 管理 | DigiKey

ATUM-16/4-0-STK : RAYCHEM ATUM 4:1 Heat Shrink Tubing | TE Connectivity
-----------------------------------------------------------------------

 ![ATUM-16/4-0-STK : RAYCHEM ATUM 4:1 Heat Shrink Tubing | TE Connectivity](https://www.te.com/content/dam/te-com/catalog/part/EM5/611/600/EM56116001-t3.jpg/jcr:content/renditions/product-small.png?w=85) <small>www.te.com</small>ATUM-16/4-0-STK : RAYCHEM ATUM 4:1 Heat Shrink Tubing | TE Connectivity

ATUM-16/4-0-STK【价格 采购 图片】-立创MRO工业品
----------------------------------

 ![ATUM-16/4-0-STK【价格 采购 图片】-立创MRO工业品](https://alimg.szlcsc.com/upload/public/product/source/20240628/B217DBB8C9AC9475940C8FB77AB7658D.jpg) <small>item.szlcsc.com</small>ATUM-16/4-0-STK【价格 采购 图片】-立创MRO工业品

ATUM-16/4-0 | TE Connectivity Adhesive Lined Heat Shrink Tubing, Black 16mm Sleeve Dia. X 1.2m
----------------------------------------------------------------------------------------------

 ![ATUM-16/4-0 | TE Connectivity Adhesive Lined Heat Shrink Tubing, Black 16mm Sleeve Dia. x 1.2m](https://media.rs-online.com/F3161647-01.jpg) <small>uk.rs-online.com</small>ATUM-16/4-0 | TE Connectivity Adhesive Lined Heat Shrink Tubing, Black 16mm Sleeve Dia. x 1.2m ...

ATUM-16/4-0-SP TE Connectivity / Raychem - Datasheet PDF &amp; Technical Specs
------------------------------------------------------------------------------

 ![ATUM-16/4-0-SP TE Connectivity / Raychem - Datasheet PDF & Technical Specs](https://sigma.octopart.com/21432606/image/TE-Connectivity---Raychem-ATUM-16-4-0-SP.jpg) <small>partsearch.io</small>ATUM-16/4-0-SP TE Connectivity / Raychem - Datasheet PDF &amp; Technical Specs

5/8" Raychem ATUM Heat Shrink Adhesive Lined Tubing, 1ft Length (6" X – KSV Looms
---------------------------------------------------------------------------------

 ![5/8" Raychem ATUM Heat Shrink Adhesive Lined Tubing, 1ft length (6" x – KSV Looms](https://www.ksvlooms.com/cdn/shop/files/5-8-raychem-atum-heat-shrink-adhesive-lined-tubing-908.webp?v=1756159523&width=4096) <small>www.ksvlooms.com</small>5/8" Raychem ATUM Heat Shrink Adhesive Lined Tubing, 1ft length (6" x – KSV Looms

ATUM-16/4-0-STK TE Connectivity / Raychem - Heat Shrink Tubing - Distributors, Price Comparison
-----------------------------------------------------------------------------------------------

 ![ATUM-16/4-0-STK TE Connectivity / Raychem - Heat Shrink Tubing - Distributors, Price Comparison](https://sigma.octopart.com/10048589/image/TE-Connectivity---Raychem-ATUM-16-4-0-STK..jpg) <small>octopart.com</small>ATUM-16/4-0-STK TE Connectivity / Raychem - Heat Shrink Tubing - Distributors, Price Comparison ...

ATUM-16/4-0-STK TE Connectivity Raychem Cable Protection | Cables, Wires - Management | DigiKey
-----------------------------------------------------------------------------------------------

 ![ATUM-16/4-0-STK TE Connectivity Raychem Cable Protection | Cables, Wires - Management | DigiKey](https://mm.digikey.com/Volume0/opasdata/d220001/medias/images/630/ATUM-164-0-STK.jpg) <small>www.digikey.com</small>ATUM-16/4-0-STK TE Connectivity Raychem Cable Protection | Cables, Wires - Management | DigiKey ...

Raychem美国瑞侃ATUM热缩管ATUM-12/4-0-STK热收缩绝缘套管进口-淘宝Taobao | 天猫Tmall
-------------------------------------------------------------

 ![Raychem美国瑞侃ATUM热缩管ATUM-12/4-0-STK热收缩绝缘套管进口-淘宝Taobao | 天猫Tmall](https://img.alicdn.com/imgextra/i4/1049709076/O1CN01qy2maV2GurpFerjvY_!!1049709076.jpg_q50s50.jpg_.webp) <small>www.taobao.com</small>Raychem美国瑞侃ATUM热缩管ATUM-12/4-0-STK热收缩绝缘套管进口-淘宝Taobao | 天猫Tmall

ATUM-16/4-0-STK : RAYCHEM ATUM 4:1 Heat Shrink Tubing | TE Connectivity
-----------------------------------------------------------------------

 ![ATUM-16/4-0-STK : RAYCHEM ATUM 4:1 Heat Shrink Tubing | TE Connectivity](https://www.te.com/content/dam/te-com/catalog/part/EM5/611/600/EM56116001-t3.jpg/jcr:content/renditions/product-small.png) <small>www.te.com</small>ATUM-16/4-0-STK : RAYCHEM ATUM 4:1 Heat Shrink Tubing | TE Connectivity

ATUM-16/4-0-STK Datasheet, Features, Pinout, And Applications | Xecor
---------------------------------------------------------------------

 ![ATUM-16/4-0-STK Datasheet, Features, Pinout, and Applications | Xecor](https://www.xecor.com/img/package/fbga.jpg) <small>www.xecor.com</small>ATUM-16/4-0-STK Datasheet, Features, Pinout, and Applications | Xecor

ATUM
----

 ![ATUM](https://scp-sa.es/414-thickbox_default/atum-19-6-0-sp.jpg) <small>scp-sa.es</small>ATUM

ATUM-16-4-0-STK
---------------

 ![ATUM-16-4-0-STK](http://www.enwer.com/upfile/files/ATUM-16-4.jpg) <small>www.enwer.com</small>ATUM-16-4-0-STK

ATUM-16/4-0-STK TE Connectivity / Raychem | Mouser
--------------------------------------------------

 ![ATUM-16/4-0-STK TE Connectivity / Raychem | Mouser](https://www.mouser.com/images/tycoelectronics/images/ATUM-164-0-STK_SPL.jpg) <small>www.mouser.com</small>ATUM-16/4-0-STK TE Connectivity / Raychem | Mouser

ATUM-16/4-0-STK : RAYCHEM ATUM 4:1 Heat Shrink Tubing | TE Connectivity
-----------------------------------------------------------------------

 ![ATUM-16/4-0-STK : RAYCHEM ATUM 4:1 Heat Shrink Tubing | TE Connectivity](https://www.te.com/content/dam/te-com/catalog/part/EM5/611/600/EM56116001-t4.jpg/jcr:content/renditions/product-small.png) <small>www.te.com</small>ATUM-16/4-0-STK : RAYCHEM ATUM 4:1 Heat Shrink Tubing | TE Connectivity

Raychem美国瑞侃ATUM热缩管ATUM-12/4-0-STK热收缩绝缘套管进口-淘宝Taobao | 天猫Tmall
-------------------------------------------------------------

 ![Raychem美国瑞侃ATUM热缩管ATUM-12/4-0-STK热收缩绝缘套管进口-淘宝Taobao | 天猫Tmall](https://img.alicdn.com/imgextra/i2/1049709076/O1CN01XHQWKe2GurpGXI6r9_!!1049709076.jpg_q50s50.jpg_.webp) <small>www.taobao.com</small>Raychem美国瑞侃ATUM热缩管ATUM-12/4-0-STK热收缩绝缘套管进口-淘宝Taobao | 天猫Tmall

ATUM-16/4-0-STK : RAYCHEM ATUM 4:1 Heat Shrink Tubing | TE Connectivity
-----------------------------------------------------------------------

 ![ATUM-16/4-0-STK : RAYCHEM ATUM 4:1 Heat Shrink Tubing | TE Connectivity](https://www.te.com/content/dam/te-com/catalog/part/EM5/611/600/EM56116001-t4.jpg/jcr:content/renditions/product-small.png?w=85) <small>www.te.com</small>ATUM-16/4-0-STK : RAYCHEM ATUM 4:1 Heat Shrink Tubing | TE Connectivity

ATUM-16/4-0-STK : RAYCHEM ATUM 4:1 Heat Shrink Tubing | TE Connectivity
-----------------------------------------------------------------------

 ![ATUM-16/4-0-STK : RAYCHEM ATUM 4:1 Heat Shrink Tubing | TE Connectivity](https://www.te.com/content/dam/te-com/catalog/part/EM5/611/600/EM56116001-t2.jpg/jcr:content/renditions/product-small.png) <small>www.te.com</small>ATUM-16/4-0-STK : RAYCHEM ATUM 4:1 Heat Shrink Tubing | TE Connectivity

レイケム ATUM-16/4-0-STK（カット品1.2m） 黒色 接着層付き 防水熱収縮チューブ 16.0→4.0mm : FA-Ubon Yahoo!店 - 通販 - Yahoo!ショッピング
--------------------------------------------------------------------------------------------------

 ![レイケム ATUM-16/4-0-STK（カット品1.2m） 黒色 接着層付き 防水熱収縮チューブ 16.0→4.0mm : FA-Ubon Yahoo!店 - 通販 - Yahoo!ショッピング](https://item-shopping.c.yimg.jp/i/n/faubon_0878878) <small>store.shopping.yahoo.co.jp</small>レイケム ATUM-16/4-0-STK（カット品1.2m） 黒色 接着層付き 防水熱収縮チューブ 16.0→4.0mm : FA-Ubon Yahoo!店 - 通販 - Yahoo!ショッピング

ATUM-16/4-0-STK : RAYCHEM ATUM 4:1 Heat Shrink Tubing | TE Connectivity
-----------------------------------------------------------------------

 ![ATUM-16/4-0-STK : RAYCHEM ATUM 4:1 Heat Shrink Tubing | TE Connectivity](https://www.te.com/content/dam/te-com/catalog/part/EM5/611/600/EM56116001-t1.jpg/jcr:content/renditions/product-small.png?w=85) <small>www.te.com</small>ATUM-16/4-0-STK : RAYCHEM ATUM 4:1 Heat Shrink Tubing | TE Connectivity

ATUM-16/4-0-STK TE Connectivity Raychem Cable Protection | 电缆，电线 - 管理 | DigiKey
-------------------------------------------------------------------------------

 ![ATUM-16/4-0-STK TE Connectivity Raychem Cable Protection | 电缆，电线 - 管理 | DigiKey](https://media.digikey.com/Photos/TE Connectivity/ATUM-16^4-0-STK.JPG) <small>www.digikey.cn</small>ATUM-16/4-0-STK TE Connectivity Raychem Cable Protection | 电缆，电线 - 管理 | DigiKey

ATUM-16/4-0-SP TE Connectivity / Raychem - Datasheet PDF &amp; Technical Specs
------------------------------------------------------------------------------

 ![ATUM-16/4-0-SP TE Connectivity / Raychem - Datasheet PDF & Technical Specs](https://sigma.octopart.com/136507203/image/TE-Connectivity---Raychem-ATUM-16-4-0-SP.jpg) <small>partsearch.io</small>ATUM-16/4-0-SP TE Connectivity / Raychem - Datasheet PDF &amp; Technical Specs

ATUM-16/4-0-STK TE Connectivity - Tubo Termoretráctil | Con Pegamento; 4: 1; 16mm; L: 1,2m
------------------------------------------------------------------------------------------

 ![ATUM-16/4-0-STK TE Connectivity - Tubo termoretráctil | con pegamento; 4: 1; 16mm; L: 1,2m](https://ce8dc832c.cloudimg.io/v7/_cdn_/4B/39/A0/00/0/693172_1.jpg?width=640&height=480&wat=1&wat_url=_tme-wrk_%2Ftme_new.png&wat_scale=100p&ci_sign=f7ae6e0a5ca432aafa704d39edcd1d23b1fb5511) <small>www.tme.com</small>ATUM-16/4-0-STK TE Connectivity - Tubo termoretráctil | con pegamento; 4: 1; 16mm; L: 1,2m ...

Atum-16/4-0-stk. Atum-16/4-0-stk te connectivity / raychem. Atum-16/4-0-stk【价格 采购 图片】-立创mro工业品
