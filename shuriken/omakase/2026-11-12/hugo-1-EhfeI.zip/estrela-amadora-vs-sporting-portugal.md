---
title: "Estrela Amadora Vs Sporting Portugal - sporting x estrela amadora: informações do jogo pelo português"
description: "estrela amadora vs sporting cp"
date: "2026-04-04"
categories:
- "Uncategorized"
images:
- "https://i.ytimg.com/vi/yON6hA-J36g/maxresdefault.jpg"
featuredImage: "https://bordalo.observador.pt/v2/q:60/rs:fill:980/c:2059:1158:nowe:0:0/plain/https://s3.observador.pt/wp-content/uploads/2025/11/28195941/prognostico-sporting-estrela-amadora.jpg"
featured_image: "https://thumbor.prod.vidiocdn.com/3WBnY-qbKiSqaGUQSXzflSKGckE=/1280x720/filters:quality(70)/vidio-web-prod-video/uploads/video/image/9103445/sporting-vs-estrela-amadora-liga-portugal-fee729.jpg"
image: "https://images.mon-match.com/images/generated/fixture-sporting-braga-vs-estrela-amadora-1.jpg?format=auto&amp;w=2400&amp;h=1350"
---

If you are looking for Sporting CP vs Estrela da Amadora - live score, predicted lineups and H2H stats you've came to the right web. We have 35 Images about Sporting CP vs Estrela da Amadora - live score, predicted lineups and H2H stats like Sporting vs Estrela Amadora - Highlight | Liga Portugal 2025/26, Estrela Amadora vs Sporting - Highlights | Liga Portugal 2023/24 and also Estrela Amadora vs. Sporting Lisbon: Live Stream, TV Channel, Start Time | 3/29/2025. Here you go:

Sporting CP Vs Estrela Da Amadora - Live Score, Predicted Lineups And H2H Stats
-------------------------------------------------------------------------------

 ![Sporting CP vs Estrela da Amadora - live score, predicted lineups and H2H stats](https://www.fotmob.com/match/preview?matchId=4233364&finished) <small>www.fotmob.com</small>Sporting CP vs Estrela da Amadora - live score, predicted lineups and H2H stats

Sporting CP 4-0 Estrela Da Amadora Highlights, Goals &amp; Key Moments (30 Nov 2025) | Liga Portugal
----------------------------------------------------------------------------------------------------

 ![Sporting CP 4-0 Estrela da Amadora Highlights, Goals & Key Moments (30 Nov 2025) | Liga Portugal](https://i.ytimg.com/vi/hY5-kmezgog/maxresdefault.jpg) <small>footyroom.co</small>Sporting CP 4-0 Estrela da Amadora Highlights, Goals &amp; Key Moments (30 Nov 2025) | Liga Portugal ...

🔴 AO VIVO : Estrela Amadora X Sporting | Liga Portugal 2024 | Transmissão Completa Da Partida
---------------------------------------------------------------------------------------------

 ![🔴 AO VIVO : Estrela Amadora x Sporting | Liga Portugal 2024 | Transmissão completa da partida](https://i.ytimg.com/vi/6_-Jjh8Eahs/maxresdefault.jpg) <small>www.youtube.com</small>🔴 AO VIVO : Estrela Amadora x Sporting | Liga Portugal 2024 | Transmissão completa da partida ...

Daniel Braganca Of Sporting CP Celebrates After Scoring A Goal During... News Photo - Getty Images
--------------------------------------------------------------------------------------------------

 ![Daniel Braganca of Sporting CP celebrates after scoring a goal during... News Photo - Getty Images](https://media.gettyimages.com/id/1765339593/photo/sporting-cp-v-cf-estrela-da-amadora-liga-portugal-betclic.jpg?s=1024x1024&w=gi&k=20&c=FLOgkyepnd4N32NrCbk4CXc2NXQ8ArTbYpkG8ZftKLI=) <small>www.gettyimages.co.uk</small>Daniel Braganca of Sporting CP celebrates after scoring a goal during... News Photo - Getty Images

Estrela Amadora Vs Sporting CP | Liga Portugal | Apr 11, 2026
-------------------------------------------------------------

 ![Estrela Amadora vs Sporting CP | Liga Portugal | Apr 11, 2026](https://accurastat.com/og-image?slug=estrela-amadora-vs-sporting-cp&date=2026-04-11&pageType=overview&locale=en) <small>accurastat.com</small>Estrela Amadora vs Sporting CP | Liga Portugal | Apr 11, 2026

Kikas Of CF Estrela Da Amadora Scores CF Estrela Da Amadora Second... News Photo - Getty Images
-----------------------------------------------------------------------------------------------

 ![Kikas of CF Estrela da Amadora scores CF Estrela da Amadora second... News Photo - Getty Images](https://media.gettyimages.com/id/1765373022/photo/sporting-cp-v-estrela-amadora-liga-portugal-bwin.jpg?s=1024x1024&w=gi&k=20&c=q6Nsr0rtmmrqFQxtAi-z6QzexABchjRzKUKr0HajZAM=) <small>www.gettyimages.co.uk</small>Kikas of CF Estrela da Amadora scores CF Estrela da Amadora second... News Photo - Getty Images

Sporting Vs Estrela Amadora - Full Match | Liga Portugal 2025/26
----------------------------------------------------------------

 ![Sporting vs Estrela Amadora - Full Match | Liga Portugal 2025/26](https://thumbor.prod.vidiocdn.com/3WBnY-qbKiSqaGUQSXzflSKGckE=/1280x720/filters:quality(70)/vidio-web-prod-video/uploads/video/image/9103445/sporting-vs-estrela-amadora-liga-portugal-fee729.jpg) <small>www.vidio.com</small>Sporting vs Estrela Amadora - Full Match | Liga Portugal 2025/26

Estrela Amadora Vs Sporting CP EM DIRETO | Liga Portugal 25/26 | EM DIRETO NA GAMEPLAY PES 2021
-----------------------------------------------------------------------------------------------

 ![Estrela Amadora vs Sporting CP EM DIRETO | Liga Portugal 25/26 | EM DIRETO NA GAMEPLAY PES 2021](https://i.ytimg.com/vi/fjLsUL887oM/maxresdefault.jpg) <small>www.youtube.com</small>Estrela Amadora vs Sporting CP EM DIRETO | Liga Portugal 25/26 | EM DIRETO NA GAMEPLAY PES 2021 ...

Estrela Amadora Vs. Sporting Lisbon: Live Stream, TV Channel, Start Time | 3/29/2025
------------------------------------------------------------------------------------

 ![Estrela Amadora vs. Sporting Lisbon: Live Stream, TV Channel, Start Time | 3/29/2025](https://ftw.usatoday.com/gcdn/authoring/images/DataSkriveFTWWire/2025/03/27/SFTW/82689754007-38oxQad.jpeg?crop=998,561,x0,y0&width=998&height=561&format=pjpg&auto=webp) <small>ftw.usatoday.com</small>Estrela Amadora vs. Sporting Lisbon: Live Stream, TV Channel, Start Time | 3/29/2025

Amadora,Portugal,March 29th, 2025: Gyokeres (9 Sporting CP) In Action During The Liga Portugal
----------------------------------------------------------------------------------------------

 ![Amadora,Portugal,March 29th, 2025: Gyokeres (9 Sporting CP) in action during the Liga Portugal](https://c8.alamy.com/comp/3A928JW/amadoraportugalmarch-29th-2025-gyokeres-9-sporting-cp-in-action-during-the-liga-portugal-betclic-game-between-cf-estrela-da-amadora-vs-sporting-cp-estadio-jose-gomes-amadora-on-29th-march-2025-joo-bravo-spp-3A928JW.jpg) <small>www.alamy.com</small>Amadora,Portugal,March 29th, 2025: Gyokeres (9 Sporting CP) in action during the Liga Portugal ...

Resumo | Liga Portugal: CF Estrela Da Amadora 0-1 Sporting CP - YouTube
-----------------------------------------------------------------------

 ![Resumo | Liga Portugal: CF Estrela da Amadora 0-1 Sporting CP - YouTube](https://i.ytimg.com/vi/twHCWfQ0SCw/maxresdefault.jpg) <small>www.youtube.com</small>Resumo | Liga Portugal: CF Estrela da Amadora 0-1 Sporting CP - YouTube

Resumo | Liga Portugal: Sporting CP 4-0 CF Estrela Da Amadora - YouTube
-----------------------------------------------------------------------

 ![Resumo | Liga Portugal: Sporting CP 4-0 CF Estrela da Amadora - YouTube](https://i.ytimg.com/vi/WyDD-HjwGog/maxresdefault.jpg) <small>www.youtube.com</small>Resumo | Liga Portugal: Sporting CP 4-0 CF Estrela da Amadora - YouTube

Sporting X Estrela Amadora: Informações Do Jogo Pelo Português
--------------------------------------------------------------

 ![Sporting x Estrela Amadora: informações do jogo pelo Português](https://static.gazetaesportiva.com/uploads/imagem/2023/11/03/000_33ZK9FL.jpg.webp) <small>www.gazetaesportiva.com</small>Sporting x Estrela Amadora: informações do jogo pelo Português

Sporting Vs Estrela Amadora - Highlight | Liga Portugal 2025/26
---------------------------------------------------------------

 ![Sporting vs Estrela Amadora - Highlight | Liga Portugal 2025/26](https://thumbor.prod.vidiocdn.com/Pstmg0W2GLyPvL3cp6m0sHmO3hk=/1280x720/filters:quality(70)/vidio-web-prod-video/uploads/video/image/9103890/sporting-vs-estrela-amadora-highlight-liga-portugal-2025-26-e03487.jpg) <small>www.vidio.com</small>Sporting vs Estrela Amadora - Highlight | Liga Portugal 2025/26

Alineaciones Estrela Amadora Vs Sp. Portugal, Primeira Liga 2025/2026
---------------------------------------------------------------------

 ![Alineaciones Estrela Amadora vs Sp. Portugal, Primeira Liga 2025/2026](https://static.prisa.com/aside/resizer/resize/img/sports/football/lives/454_39.png?width=1200&height=675) <small>mexico.as.com</small>Alineaciones Estrela Amadora vs Sp. Portugal, Primeira Liga 2025/2026

Viktor Gyokeres Of Sporting CP In Action During The Liga Portugal... News Photo - Getty Images
----------------------------------------------------------------------------------------------

 ![Viktor Gyokeres of Sporting CP in action during the Liga Portugal... News Photo - Getty Images](https://media.gettyimages.com/id/2181645712/photo/sporting-cp-v-cf-estrela-da-amadora-liga-portugal-betclic.jpg?s=1024x1024&w=gi&k=20&c=pQSHkBU1QxQDR9JnFatynVanZJ6QzkPKyr7WUe2HLVw=) <small>www.gettyimages.com</small>Viktor Gyokeres of Sporting CP in action during the Liga Portugal... News Photo - Getty Images

🔴EM DIRETO: ESTRELA DA AMADORA X SPORTING - LIGA PORTUGAL BETCLIC - Streaming Com RELATO - YouTube
--------------------------------------------------------------------------------------------------

 ![🔴EM DIRETO: ESTRELA DA AMADORA X SPORTING - LIGA PORTUGAL BETCLIC - Streaming com RELATO - YouTube](https://i.ytimg.com/vi/EhYAaL22X_Q/maxresdefault.jpg) <small>www.youtube.com</small>🔴EM DIRETO: ESTRELA DA AMADORA X SPORTING - LIGA PORTUGAL BETCLIC - Streaming com RELATO - YouTube

Estrela Amadora Vs Sporting - Full Match | Liga Portugal 2023/24
----------------------------------------------------------------

 ![Estrela Amadora vs Sporting - Full Match | Liga Portugal 2023/24](https://thumbor.prod.vidiocdn.com/yA5bqgT85_d5r0eooextT7a4-K0=/1280x720/filters:quality(70)/vidio-web-prod-video/uploads/video/image/8124278/estrela-amadora-vs-sporting-full-match-liga-portugal-2023-24-326f86.jpg) <small>www.vidio.com</small>Estrela Amadora vs Sporting - Full Match | Liga Portugal 2023/24

Estrela Amadora Vs Sporting CP 0-1 | Liga Portugal 2026 | Simulação - YouTube
-----------------------------------------------------------------------------

 ![Estrela Amadora vs Sporting CP 0-1 | Liga Portugal 2026 | Simulação - YouTube](https://i.ytimg.com/vi/uiW7_L8REmc/maxresdefault.jpg) <small>www.youtube.com</small>Estrela Amadora vs Sporting CP 0-1 | Liga Portugal 2026 | Simulação - YouTube

Sporting Vs Estrela Amadora - YouTube
-------------------------------------

 ![Sporting vs Estrela Amadora - YouTube](https://i.ytimg.com/vi/yON6hA-J36g/maxresdefault.jpg) <small>www.youtube.com</small>Sporting vs Estrela Amadora - YouTube

Prognóstico Estrela Da Amadora Vs Sporting - Liga Portugal
----------------------------------------------------------

 ![Prognóstico Estrela da Amadora vs Sporting - Liga Portugal](https://bordalo.observador.pt/v2/q:60/rs:fill:980/c:1200:674:nowe:0:0/plain/https://s3.observador.pt/wp-content/uploads/2026/04/09133254/prognostico-estrela-sporting.jpg) <small>observador.pt</small>Prognóstico Estrela da Amadora vs Sporting - Liga Portugal

Prognóstico Sporting Vs Estrela Da Amadora - Liga Portugal
----------------------------------------------------------

 ![Prognóstico Sporting vs Estrela da Amadora - Liga Portugal](https://bordalo.observador.pt/v2/q:60/rs:fill:980/c:2059:1158:nowe:0:0/plain/https://s3.observador.pt/wp-content/uploads/2025/11/28195941/prognostico-sporting-estrela-amadora.jpg) <small>observador.pt</small>Prognóstico Sporting vs Estrela da Amadora - Liga Portugal

Goncalo Inacio Of Sporting CP Tries To Escape Aloisio Souza Of CF... News Photo - Getty Images
----------------------------------------------------------------------------------------------

 ![Goncalo Inacio of Sporting CP tries to escape Aloisio Souza of CF... News Photo - Getty Images](https://media.gettyimages.com/id/1765588653/photo/sporting-cp-v-estrela-amadora-liga-portugal-bwin.jpg?s=1024x1024&w=gi&k=20&c=xE11EbOGrcQ_vMFed0sbeGDv6_hwmgygZKuP-mhxK-A=) <small>www.gettyimages.com</small>Goncalo Inacio of Sporting CP tries to escape Aloisio Souza of CF... News Photo - Getty Images

Estrela Amadora Vs Sporting - Highlights | Liga Portugal 2023/24
----------------------------------------------------------------

 ![Estrela Amadora vs Sporting - Highlights | Liga Portugal 2023/24](https://thumbor.prod.vidiocdn.com/P1-4--FTeBivcxC0OlT2YsuVpAE=/1280x720/filters:quality(70)/vidio-web-prod-video/uploads/video/image/8124233/hl-portuguese-league-estrela-amadora-vs-sporting-a54198.jpg) <small>www.vidio.com</small>Estrela Amadora vs Sporting - Highlights | Liga Portugal 2023/24

Estrela Amadora Vs Sporting - Highlights | Liga Portugal 2024/25 | Vidio
------------------------------------------------------------------------

 ![Estrela Amadora vs Sporting - Highlights | Liga Portugal 2024/25 | Vidio](https://thumbor.prod.vidiocdn.com/9sy6PEp39V5bmMFOVFv7peQmvM0=/1280x720/filters:quality(70)/vidio-web-prod-video/uploads/video/image/8643051/hl-portuguese-league-estrela-amadora-vs-sporting-c5c297.jpg) <small>www.vidio.com</small>Estrela Amadora vs Sporting - Highlights | Liga Portugal 2024/25 | Vidio

SPORTING X ESTRELA DA AMADORA | EM DIRETO LIGA PORTUGAL BETCLIC - YouTube
-------------------------------------------------------------------------

 ![SPORTING x ESTRELA DA AMADORA | EM DIRETO LIGA PORTUGAL BETCLIC - YouTube](https://i.ytimg.com/vi/b14JWVXqA0s/maxresdefault.jpg) <small>www.youtube.com</small>SPORTING x ESTRELA DA AMADORA | EM DIRETO LIGA PORTUGAL BETCLIC - YouTube

Onde E Como Ver O Sporting - Estrela Da Amadora Para A Liga Portugal Betclic | TechBit
--------------------------------------------------------------------------------------

 ![Onde e como ver o Sporting - Estrela da Amadora para a Liga Portugal Betclic | TechBit](https://techbit.pt/wp-content/uploads/2025/11/sporting-estrela-da-amadora.webp) <small>techbit.pt</small>Onde e como ver o Sporting - Estrela da Amadora para a Liga Portugal Betclic | TechBit

Sporting Lisboa Logró Dar Vuelta El Marcador Y Vencer 2-1 A Estrela Amadora
---------------------------------------------------------------------------

 ![Sporting Lisboa logró dar vuelta el marcador y vencer 2-1 a Estrela Amadora](https://media.ambito.com/p/95e89297a9016cd13d92e18ab3d98218/adjuntos/239/imagenes/041/405/0041405185/1200x675/smart/portugal-primera-division-estrela-amadora-vs-sporting-lisboa-fecha-27.png) <small>www.ambito.com</small>Sporting Lisboa logró dar vuelta el marcador y vencer 2-1 a Estrela Amadora

Lisbon, Portugal. 01st Nov, 2024. Team Of Estrela Amadora Seen In Action During Liga Portugal
---------------------------------------------------------------------------------------------

 ![Lisbon, Portugal. 01st Nov, 2024. Team of Estrela Amadora seen in action during Liga Portugal](https://c8.alamy.com/comp/2YF8RM0/lisbon-portugal-01st-nov-2024-team-of-estrela-amadora-seen-in-action-during-liga-portugal-game-between-teams-of-sporting-cp-and-cf-estrela-amadora-at-estadio-jose-alvalade-final-score-sporting-cp-5-1-cf-estrela-amadora-photo-by-maciej-rogowskisopa-imagessipa-usa-credit-sipa-usaalamy-live-news-2YF8RM0.jpg) <small>www.alamy.com</small>Lisbon, Portugal. 01st Nov, 2024. Team of Estrela Amadora seen in action during Liga Portugal ...

SPORTING CP Vs ESTRELA AMADORA - Liga Portugal 2024/25 - EA SPORTS FC 25 - YouTube
----------------------------------------------------------------------------------

 ![SPORTING CP vs ESTRELA AMADORA - Liga Portugal 2024/25 - EA SPORTS FC 25 - YouTube](https://i.ytimg.com/vi/lGOgxE8SZg8/maxresdefault.jpg) <small>www.youtube.com</small>SPORTING CP vs ESTRELA AMADORA - Liga Portugal 2024/25 - EA SPORTS FC 25 - YouTube

Estrela Amadora Vs Sporting - Full Match | Liga Portugal 2024/25
----------------------------------------------------------------

 ![Estrela Amadora vs Sporting - Full Match | Liga Portugal 2024/25](https://thumbor.prod.vidiocdn.com/KAq8-CzzTONXEY3IzUldZlfHUm8=/1280x720/filters:quality(70)/vidio-web-prod-video/uploads/video/image/8643049/fm-portuguese-league-estrela-amadora-vs-sporting-615e42.jpg) <small>www.vidio.com</small>Estrela Amadora vs Sporting - Full Match | Liga Portugal 2024/25

Sporting Braga – Estrela Amadora : Match Liga Portugal (16 Mai 2026)
--------------------------------------------------------------------

 ![Sporting Braga – Estrela Amadora : Match Liga Portugal (16 mai 2026)](https://images.mon-match.com/images/generated/fixture-sporting-braga-vs-estrela-amadora-1.jpg?format=auto&w=2400&h=1350) <small>www.mon-match.com</small>Sporting Braga – Estrela Amadora : Match Liga Portugal (16 mai 2026)

Resumo | Liga Portugal Betclic: Sporting CP 5-1 CF Estrela Da Amadora - YouTube
-------------------------------------------------------------------------------

 ![Resumo | Liga Portugal Betclic: Sporting CP 5-1 CF Estrela da Amadora - YouTube](https://i.ytimg.com/vi/vLbYqqJXM7o/maxresdefault.jpg) <small>www.youtube.com</small>Resumo | Liga Portugal Betclic: Sporting CP 5-1 CF Estrela da Amadora - YouTube

Vlog: Sporting CP 3 Vs 2 CF Estrela Da Amadora (Liga Portugal Betclic 23/24) - YouTube
--------------------------------------------------------------------------------------

 ![Vlog: Sporting CP 3 vs 2 CF Estrela da Amadora (Liga Portugal Betclic 23/24) - YouTube](https://i.ytimg.com/vi/geN2H_8Jnfw/maxresdefault.jpg) <small>www.youtube.com</small>Vlog: Sporting CP 3 vs 2 CF Estrela da Amadora (Liga Portugal Betclic 23/24) - YouTube

Sporting CP Vs Estrela Da Amadora (5 Nov 2023) 🔥 Video Highlights - FootyRoom
-----------------------------------------------------------------------------

 ![Sporting CP vs Estrela da Amadora (5 Nov 2023) 🔥 Video Highlights - FootyRoom](https://i.ytimg.com/vi/cF4Ld9DLvuA/maxresdefault.jpg) <small>footyroom.co</small>Sporting CP vs Estrela da Amadora (5 Nov 2023) 🔥 Video Highlights - FootyRoom

estrela amadora vs sporting cp em direto. Lisbon, portugal. 01st nov, 2024. team of estrela amadora seen in action during liga portugal. Alineaciones estrela amadora vs sp. portugal, primeira liga 2025/2026
