---
title: "Greve Geral 11 Dezembro Cgtp - Trabalhadores protestam contra alterações ao pacote laboral. ugt e cgtp convocam greve geral ..."
description: "Cgtp anuncia greve geral para 11 de dezembro"
date: "2026-04-27"
categories:
- "Uncategorized"
images:
- "https://www.cgtp.pt/images/images/2025/11/gg_banner2025.jpg"
featuredImage: "https://www.diarioviseu.pt/wp-content/uploads/sites/8/2025/05/Cgtp-scaled-e1762628585385.webp"
featured_image: "https://staticx.noticiasilimitadas.pt/jn/image.webp?brand=jn&amp;type=generate&amp;guid=fb434b13-2b30-4ab1-a6bc-4ddd86b96b14&amp;w=3840"
image: "https://lookaside.fbsbx.com/lookaside/crawler/media/?media_id=1634621500842359"
---

If you are looking for Trabalhadores protestam contra alterações ao pacote laboral. UGT e CGTP convocam greve geral you've visit to the right place. We have 35 Pics about Trabalhadores protestam contra alterações ao pacote laboral. UGT e CGTP convocam greve geral like CGTP fala de adesão massiva à greve geral - TSF, CGTP anuncia greve geral para 11 de dezembro and also CGTP anuncia greve geral para 11 de dezembro. Here you go:

Trabalhadores Protestam Contra Alterações Ao Pacote Laboral. UGT E CGTP Convocam Greve Geral
--------------------------------------------------------------------------------------------

 ![Trabalhadores protestam contra alterações ao pacote laboral. UGT e CGTP convocam greve geral](https://images.euronews.com/articles/stories/09/54/15/62/1536x864_cmsv2_374bd949-77e2-5f19-ae5c-6c4cdfc973f3-9541562.jpg) <small>pt.euronews.com</small>Trabalhadores protestam contra alterações ao pacote laboral. UGT e CGTP convocam greve geral ...

CGTP Anuncia Greve Geral Para 11 De Dezembro - SIC Notícias
-----------------------------------------------------------

 ![CGTP anuncia greve geral para 11 de dezembro - SIC Notícias](https://images.impresa.pt/sicnot/2025-09-24-manif-protesto-cgtp-51d0ff36/original) <small>sicnoticias.pt</small>CGTP anuncia greve geral para 11 de dezembro - SIC Notícias

GREVE GERAL E PROTESTO DA CGTP PROVOCAM PERTURBAÇÕES ESTA SEXTA-FEIRA | RÁDIO REGIONAL
--------------------------------------------------------------------------------------

 ![GREVE GERAL E PROTESTO DA CGTP PROVOCAM PERTURBAÇÕES ESTA SEXTA-FEIRA | RÁDIO REGIONAL](https://radioregional.pt/wp-content/uploads/2026/04/greve-geral-e-protesto-da-cgtp-provocam-perturbacoes-esta-sexta-feira-2.webp) <small>radioregional.pt</small>GREVE GERAL E PROTESTO DA CGTP PROVOCAM PERTURBAÇÕES ESTA SEXTA-FEIRA | RÁDIO REGIONAL

Transportes, Hospitais, Escolas E Até Bancos. Que Setores Vão Ser Afetados Pela Greve Geral? – ECO
--------------------------------------------------------------------------------------------------

 ![Transportes, hospitais, escolas e até bancos. Que setores vão ser afetados pela greve geral? – ECO](https://ecoonline.s3.amazonaws.com/uploads/2025/12/46141990.jpg) <small>eco.sapo.pt</small>Transportes, hospitais, escolas e até bancos. Que setores vão ser afetados pela greve geral? – ECO

Greve Geral Pode Custar 792 Milhões De Euros à Economia - JN
------------------------------------------------------------

 ![Greve geral pode custar 792 milhões de euros à economia - JN](https://staticx.noticiasilimitadas.pt/jn/image.webp?brand=jn&type=generate&guid=fb434b13-2b30-4ab1-a6bc-4ddd86b96b14&w=3840) <small>www.jn.pt</small>Greve geral pode custar 792 milhões de euros à economia - JN

CGTP Não Se Compromete Com Extensão Da Greve Para Dois Dias – Observador
------------------------------------------------------------------------

 ![CGTP não se compromete com extensão da greve para dois dias – Observador](https://bordalo.observador.pt/v2/q:60/rs:fill:980/c:2000:1124:nowe:0:104/plain/https://s3.observador.pt/wp-content/uploads/2025/11/17135154/46046150.jpg) <small>observador.pt</small>CGTP não se compromete com extensão da greve para dois dias – Observador

CGTP E UGT Agendam Greve Geral Para 11 De Dezembro - ORegiões
-------------------------------------------------------------

 ![CGTP e UGT agendam greve geral para 11 de Dezembro - oRegiões](https://oregioes.pt/wp-content/uploads/2025/11/greve-2.jpg) <small>oregioes.pt</small>CGTP e UGT agendam greve geral para 11 de Dezembro - oRegiões

Greve Geral Anunciada Pela CGTP Para 11 De Dezembro - Portal Tela
-----------------------------------------------------------------

 ![Greve geral anunciada pela CGTP para 11 de dezembro - Portal Tela](https://www.portaltela.com/s.01k8r8f7wx8pm/2025/11/CGTP.jpg) <small>www.portaltela.com</small>Greve geral anunciada pela CGTP para 11 de dezembro - Portal Tela

CGTP E UGT Avançam Para Greve Geral A 11 De Dezembro
----------------------------------------------------

 ![CGTP e UGT avançam para greve geral a 11 de dezembro](https://cdn-images.rtp.pt/icm/noticias/images/9c/9cc08b7ef9071a995ca0507e7081a472?w=860&q=90&rect=0,106,1249,685) <small>www.rtp.pt</small>CGTP e UGT avançam para greve geral a 11 de dezembro

Sindicatos Independentes Aderem à Greve Geral Pela Primeira Vez E Juntam-se à UGT E CGTP - Expresso
---------------------------------------------------------------------------------------------------

 ![Sindicatos independentes aderem à greve geral pela primeira vez e juntam-se à UGT e CGTP - Expresso](https://images.impresa.pt/expresso/2025-11-27-greve-geral-anuncio-para-a-realizacao-de-greve-a-11-de-dezembro-marques-pombal--9b289114/original) <small>expresso.pt</small>Sindicatos independentes aderem à greve geral pela primeira vez e juntam-se à UGT e CGTP - Expresso

Secretário-geral Da CGTP Confirma Greve Geral Para Dia 11 De Dezembro - Política - Correio Da Manhã
---------------------------------------------------------------------------------------------------

 ![Secretário-geral da CGTP confirma greve geral para dia 11 de dezembro - Política - Correio da Manhã](https://cdn.cmjornal.pt/images/2025-11/img_1500x1000uu2025-11-08-16-56-10-2246797.jpg) <small>www.cmjornal.pt</small>Secretário-geral da CGTP confirma greve geral para dia 11 de dezembro - Política - Correio da Manhã

CGTP Convoca Greve Geral Para 11 De Dezembro - Atualidade - 24 Notícias
-----------------------------------------------------------------------

 ![CGTP convoca greve geral para 11 de dezembro - Atualidade - 24 Notícias](https://thumbs.web.sapo.io/?W=1200&H=630&delay_optim=1&tv=1&crop=center&bottom_overlay=https%3A%2F%2Fsapo24.web.sapo.io%2Fassets%2Fimg%2F24-sapo%2Foverlay.png&epic=NDNlcyjrIm5Zmqq5ttDkEnanq6v0VA6RLjO/oZfo8hUOg3uJjXN4+5R+s8uakhSx6+wkXHmXqlPa6sMZM6eSMEJZY7z6+AvUSRjNmUQyV3hc5CQ=) <small>24noticias.sapo.pt</small>CGTP convoca greve geral para 11 de dezembro - Atualidade - 24 Notícias

GREVE GERAL DE 11 DE DEZEMBRO DE 2025 – A CGTP NAS MANIFESTAÇÕES – LISBOA – EPHEMERA
------------------------------------------------------------------------------------

 ![GREVE GERAL DE 11 DE DEZEMBRO DE 2025 – A CGTP NAS MANIFESTAÇÕES – LISBOA – EPHEMERA](https://ephemerajpp.com/wp-content/uploads/2025/12/IMG_2228.jpg) <small>ephemerajpp.com</small>GREVE GERAL DE 11 DE DEZEMBRO DE 2025 – A CGTP NAS MANIFESTAÇÕES – LISBOA – EPHEMERA ...

CGTP-IN Convoca Manifestação Contra O Pacote Laboral Para 13 De Janeiro
-----------------------------------------------------------------------

 ![CGTP-IN convoca manifestação contra o pacote laboral para 13 de janeiro](https://staticx.noticiasilimitadas.pt/jn/image.webp?brand=jn&type=generate&guid=01217e02-e214-41bd-8f67-8b96b175f842&w=3840) <small>www.jn.pt</small>CGTP-IN convoca manifestação contra o pacote laboral para 13 de janeiro

JORNAL - GREVE GERAL AVANÇA NO DIA 11. SEXTA-FEIRA CONTA COM NOVA GREVE A Greve Geral Que Se
--------------------------------------------------------------------------------------------

 ![JORNAL - GREVE GERAL AVANÇA NO DIA 11. SEXTA-FEIRA CONTA COM NOVA GREVE A greve geral que se](https://lookaside.fbsbx.com/lookaside/crawler/media/?media_id=1634621500842359) <small>www.facebook.com</small>JORNAL - GREVE GERAL AVANÇA NO DIA 11. SEXTA-FEIRA CONTA COM NOVA GREVE A greve geral que se ...

CGTP E UGT Convocam Greve Geral Para 11 De Dezembro - JN
--------------------------------------------------------

 ![CGTP e UGT convocam greve geral para 11 de dezembro - JN](https://staticx.noticiasilimitadas.pt/jn/image.webp?brand=jn&type=generate&guid=44b944fb-8886-457b-a19f-bdc9053848ef&w=3840) <small>www.jn.pt</small>CGTP e UGT convocam greve geral para 11 de dezembro - JN

FEVICCOM Adere à GREVE GERAL De 11 De Dezembro - CGTP-IN
--------------------------------------------------------

 ![FEVICCOM adere à GREVE GERAL de 11 de Dezembro - CGTP-IN](https://www.cgtp.pt/images/accao-e-luta/2025/Feviccom1.jpg) <small>www.cgtp.pt</small>FEVICCOM adere à GREVE GERAL de 11 de Dezembro - CGTP-IN

Balanço Da Greve Geral - CGTP-IN
--------------------------------

 ![Balanço da Greve Geral - CGTP-IN](https://www.cgtp.pt/images/images/2025/11/gg_banner2025.jpg) <small>www.cgtp.pt</small>Balanço da Greve Geral - CGTP-IN

CGTP Anuncia Greve Geral Para 11 De Dezembro
--------------------------------------------

 ![CGTP anuncia greve geral para 11 de dezembro](https://media.assettype.com/dn%2F2025-11-08%2F5zembatj%2FImagem-WhatsApp-2025-11-08-%C3%A0s-17.25.49bf9deb86.jpg?w=1200&ar=40%3A21&auto=format%2Ccompress&ogImage=true&mode=crop&enlarge=true&overlay=false&overlay_position=bottom&overlay_width=100) <small>www.dn.pt</small>CGTP anuncia greve geral para 11 de dezembro

CIL Apoia A Greve Geral Do Próximo Dia 11 De Dezembro - CGTP-IN
---------------------------------------------------------------

 ![CIL apoia a Greve Geral do próximo dia 11 de Dezembro - CGTP-IN](https://www.cgtp.pt/images/accao-e-luta/2025/54909309207_62b0afa28f_o1.jpg) <small>www.cgtp.pt</small>CIL apoia a Greve Geral do próximo dia 11 de Dezembro - CGTP-IN

CGTP Entrega Pré-aviso Da Greve Geral Para 11 De Dezembro | CGTP | PÚBLICO
--------------------------------------------------------------------------

 ![CGTP entrega pré-aviso da greve geral para 11 de Dezembro | CGTP | PÚBLICO](https://imagens.publico.pt/imagens.aspx/2045742?tp=UH&db=IMAGENS&type=JPG&share=1&o=BarraFacebook_Publico.png) <small>www.publico.pt</small>CGTP entrega pré-aviso da greve geral para 11 de Dezembro | CGTP | PÚBLICO

Governo Promete “minimizar E Mitigar” Os Efeitos Da Greve Geral: Até Onde Pode Ir? - Expresso
---------------------------------------------------------------------------------------------

 ![Governo promete “minimizar e mitigar” os efeitos da greve geral: até onde pode ir? - Expresso](https://images.impresa.pt/expresso/2025-11-08-manifestacao-da-cgtp-contra-o-pacote-laboral-com-anuncio-de-greve-geral-4e98c28a/original) <small>expresso.pt</small>Governo promete “minimizar e mitigar” os efeitos da greve geral: até onde pode ir? - Expresso

A Greve Geral De 11 De Dezembro Em 38 Imagens – Observador
----------------------------------------------------------

 ![A greve geral de 11 de dezembro em 38 imagens – Observador](https://bordalo.observador.pt/v2/q:60/rs:fill:1440/c:4096:2734:nowe:0:0/plain/https://s3.observador.pt/wp-content/uploads/2025/12/11191541/dv1-7571-scaled.jpeg) <small>observador.pt</small>A greve geral de 11 de dezembro em 38 imagens – Observador

CGTP Anuncia Greve Geral Para 11 De Dezembro
--------------------------------------------

 ![CGTP anuncia greve geral para 11 de dezembro](https://www.lusa.pt/TEMP/IMAGES/780x1200/CACHE_780X1200_ANALOG_WATERMARKED_45998234_7085120_08112025053627.JPG) <small>www.lusa.pt</small>CGTP anuncia greve geral para 11 de dezembro

Secretário-geral Da CGTP Confirma Greve Geral Para Dia 11 De Dezembro - Política - Correio Da Manhã
---------------------------------------------------------------------------------------------------

 ![Secretário-geral da CGTP confirma greve geral para dia 11 de dezembro - Política - Correio da Manhã](https://cdn.cmjornal.pt/images/2025-11/img_1500x1000uu2025-11-08-16-56-11-2246795.jpg) <small>www.cmjornal.pt</small>Secretário-geral da CGTP confirma greve geral para dia 11 de dezembro - Política - Correio da Manhã

FNSTFPS Adere à Greve Geral De 11 De Dezembro - CGTP-IN
-------------------------------------------------------

 ![FNSTFPS adere à Greve Geral de 11 de Dezembro - CGTP-IN](https://www.cgtp.pt/images/accao-e-luta/2025/54910179541_10702918c8_c.jpg) <small>www.cgtp.pt</small>FNSTFPS adere à Greve Geral de 11 de Dezembro - CGTP-IN

Polícia De Intervenção Dispersa Manifestantes. Acabou A Manif Da Greve Geral
----------------------------------------------------------------------------

 ![Polícia de intervenção dispersa manifestantes. Acabou a manif da greve geral](https://media.assettype.com/dn/2025-12-11/ji5vlnpx/greve-geral.jpg?w=1200&auto=format%2Ccompress) <small>www.dn.pt</small>Polícia de intervenção dispersa manifestantes. Acabou a manif da greve geral

CGTP Tem Ações Agendadas Em 15 Distritos E Regiões Autónomas No Dia Da Greve Geral - Sociedade
----------------------------------------------------------------------------------------------

 ![CGTP tem ações agendadas em 15 distritos e Regiões Autónomas no dia da greve geral - Sociedade](https://cdn.cmjornal.pt/images/2025-11/img_1500x1000uu2025-11-08-16-56-10-2246799.jpg) <small>www.cmjornal.pt</small>CGTP tem ações agendadas em 15 distritos e Regiões Autónomas no dia da greve geral - Sociedade ...

CGTP Anuncia Greve Geral Para 11 De Dezembro
--------------------------------------------

 ![CGTP anuncia greve geral para 11 de dezembro](https://www.diarioviseu.pt/wp-content/uploads/sites/8/2025/05/Cgtp-scaled-e1762628585385.webp) <small>www.diarioviseu.pt</small>CGTP anuncia greve geral para 11 de dezembro

CGTP Fala De Adesão Massiva à Greve Geral - TSF
-----------------------------------------------

 ![CGTP fala de adesão massiva à greve geral - TSF](https://staticx.noticiasilimitadas.pt/tsf/image.webp?brand=tsf&type=generate&guid=f2fd45e3-0eb3-424b-9e51-c41a22a41e1a&w=3840) <small>www.tsf.pt</small>CGTP fala de adesão massiva à greve geral - TSF

FECTRANS | Cresce A Mobilização Para A Greve Geral - CGTP-IN
------------------------------------------------------------

 ![FECTRANS | Cresce a mobilização para a Greve Geral - CGTP-IN](https://www.cgtp.pt/images/accao-e-luta/2025/Logotipo_GG.png) <small>www.cgtp.pt</small>FECTRANS | Cresce a mobilização para a Greve Geral - CGTP-IN

VISEU - Esclarecimento E Mobilização Para A Greve Geral Marcada Para 11 De Dezembro - CGTP-IN
---------------------------------------------------------------------------------------------

 ![VISEU - Esclarecimento e mobilização para a Greve Geral marcada para 11 de Dezembro - CGTP-IN](https://www.cgtp.pt/images/accao-e-luta/2025/gg.jpg) <small>www.cgtp.pt</small>VISEU - Esclarecimento e mobilização para a Greve Geral marcada para 11 de Dezembro - CGTP-IN

CGTP E UGT Convocam Greve Geral Para 11 De Dezembro
---------------------------------------------------

 ![CGTP e UGT convocam greve geral para 11 de dezembro](https://cdn-images.rtp.pt/icm/noticias/images/9d/9d70424fbde54f53aa0f6db19a9f7213?w=860&q=90&rect=0,0,1500,822w=860&q=90) <small>www.rtp.pt</small>CGTP e UGT convocam greve geral para 11 de dezembro

CGTP Entregou Pré-aviso De Greve Geral Contra "ataque Ao Mundo Do Trabalho E Aos Trabalhadores"
-----------------------------------------------------------------------------------------------

 ![CGTP entregou pré-aviso de greve geral contra "ataque ao mundo do trabalho e aos trabalhadores"](https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA1QB7gg.img?w=768&h=422&m=6&x=390&y=51&s=241&d=156) <small>www.msn.com</small>CGTP entregou pré-aviso de greve geral contra "ataque ao mundo do trabalho e aos trabalhadores"

UGT Aprova Greve Geral Com A CGTP A 11 De Dezembro - Renascença
---------------------------------------------------------------

 ![UGT aprova greve geral com a CGTP a 11 de dezembro - Renascença](https://images.rr.pt/459977534574ce6982fcdefaultlarge_1024.JPG) <small>rr.pt</small>UGT aprova greve geral com a CGTP a 11 de dezembro - Renascença

Fnstfps adere à greve geral de 11 de dezembro. cgtp e ugt avançam para greve geral a 11 de dezembro. cgtp tem ações agendadas em 15 distritos e regiões autónomas no dia da greve geral
