---
title: "Kimberly Powell Md - Dive into the future of digital surgery, health, and biology with nvidia&#039;s vp of healthcare and"
description: "powell, kimberly r., aprn"
date: "2026-05-13"
categories:
- "Uncategorized"
images:
- "https://i.ytimg.com/vi/15s952bcezM/maxresdefault.jpg"
featuredImage: "https://www.augustahealth.com/wp-content/uploads/2023/04/Kim-Powell-2-scaled.jpg"
featured_image: "https://public.med.fsu.edu/images/Faculty/Kimberly.Powell.jpg"
image: "https://digitaleconomymag.com/wp-content/uploads/2024/11/Nvidia-Kimberly-Powel.png"
---

If you are searching about Chip giant Nvidia wants to bring robots to the hospital | Business Insider Africa you've came to the right page. We have 34 Pictures about Chip giant Nvidia wants to bring robots to the hospital | Business Insider Africa like Kimberly Powell honored for pioneering work in health informatics and gerontology, NVIDIA: A nova fronteira da Medicina está na IA - CM and also What Can Health Care Learn from Self-Driving Cars? | Johns Hopkins Medicine. Here you go:

Chip Giant Nvidia Wants To Bring Robots To The Hospital | Business Insider Africa
---------------------------------------------------------------------------------

 ![Chip giant Nvidia wants to bring robots to the hospital | Business Insider Africa](https://ocdn.eu/pulscms-transforms/1/i3dktkuTURBXy9kMWIzYzQ0Mi03YzY1LTQ0NTQtYWNjOC0wYjNlNjRmMTVjZmMuanBlZ5GTBc0DFs0Brg) <small>africa.businessinsider.com</small>Chip giant Nvidia wants to bring robots to the hospital | Business Insider Africa

An Interview With Kimberley Powell (NVIDIA) At The AI Summit, San Francisco (2016). - YouTube
---------------------------------------------------------------------------------------------

 ![An Interview with Kimberley Powell (NVIDIA) at The AI Summit, San Francisco (2016). - YouTube](https://i.ytimg.com/vi/15s952bcezM/maxresdefault.jpg) <small>www.youtube.com</small>An Interview with Kimberley Powell (NVIDIA) at The AI Summit, San Francisco (2016). - YouTube

Kimberly Powell - Speech Language Pathologist | LinkedIn
--------------------------------------------------------

 ![Kimberly Powell - Speech Language Pathologist | LinkedIn](https://media.licdn.com/dms/image/v2/C4E03AQGad6PJpLEGrA/profile-displayphoto-shrink_200_200/profile-displayphoto-shrink_200_200/0/1517616680748?e=2147483647&v=beta&t=0kIdF8R4KSg9kR0lU-baZL1JAARdnS570j_qCD7FsDA) <small>www.linkedin.com</small>Kimberly Powell - Speech Language Pathologist | LinkedIn

The Age Of AI In Radiology Is Here – Entelechy Asia
---------------------------------------------------

 ![The age of AI in radiology is here – Entelechy Asia](https://entelechyasia.com/wp-content/uploads/2019/01/kimberly-powell-at-emtech-asia.jpg) <small>entelechyasia.com</small>The age of AI in radiology is here – Entelechy Asia

NVIDIA Powers Up In Drug Discovery
----------------------------------

 ![NVIDIA Powers Up in Drug Discovery](https://genengnews.com/wp-content/uploads/2020/10/Kimberly-Powell_avatar_1511719112-200x200-1.jpg) <small>www.genengnews.com</small>NVIDIA Powers Up in Drug Discovery

Dive Into The Future Of Digital Surgery, Health, And Biology With NVIDIA's VP Of Healthcare And
-----------------------------------------------------------------------------------------------

 ![Dive into the future of digital surgery, health, and biology with NVIDIA's VP of Healthcare and](https://media.licdn.com/dms/image/v2/D5610AQEf18m9u13NPw/image-shrink_800/image-shrink_800/0/1718404075786?e=2147483647&v=beta&t=F-wL667A6hY7CE4c0fp8ufvPB6vLFAUNhCatqrC7jY4) <small>www.linkedin.com</small>Dive into the future of digital surgery, health, and biology with NVIDIA's VP of Healthcare and ...

Dr. Kimberly N Powell, MD - Springfield, IL - Pediatric Critical Care Medicine
------------------------------------------------------------------------------

 ![Dr. Kimberly N Powell, MD - Springfield, IL - Pediatric Critical Care Medicine](https://cdn-images.kyruus.com/providermatch/2201ebuq/photos/orig/powell-kimberly-1033375605.jpg) <small>providers.hshs.org</small>Dr. Kimberly N Powell, MD - Springfield, IL - Pediatric Critical Care Medicine

Faculty Staff | College Of Medicine
-----------------------------------

 ![Faculty Staff | College of Medicine](https://public.med.fsu.edu/images/Faculty/Kimberly.Powell.jpg) <small>public.med.fsu.edu</small>Faculty Staff | College of Medicine

Powell, Kimberly R., APRN | Medical Associates Of Northwest Arkansas
--------------------------------------------------------------------

 ![Powell, Kimberly R., APRN | Medical Associates of Northwest Arkansas](https://mana.md/wp-content/uploads/2022/06/Powell_Kim_headshot.png) <small>mana.md</small>Powell, Kimberly R., APRN | Medical Associates of Northwest Arkansas

AI And Digital Biology: Unlocking The Future Of Drug Discovery With Kimberly Powell | WIRED
-------------------------------------------------------------------------------------------

 ![AI and digital biology: Unlocking the future of drug discovery with Kimberly Powell | WIRED](https://i.ytimg.com/vi/yeCmKq8aOY0/maxresdefault.jpg) <small>www.youtube.com</small>AI and digital biology: Unlocking the future of drug discovery with Kimberly Powell | WIRED ...

Nvidia Looks To Genentech For Its Next Leap In AI Drug Discovery
----------------------------------------------------------------

 ![Nvidia Looks to Genentech for Its Next Leap in AI Drug Discovery](https://www.genengnews.com/wp-content/uploads/2023/11/Kimberly-Powell-NVIDIA-CROPPED11111.jpg) <small>www.genengnews.com</small>Nvidia Looks to Genentech for Its Next Leap in AI Drug Discovery

Kimberly Powell Inducted As Fellow Of The American Medical Informatics Association, Announced As
------------------------------------------------------------------------------------------------

 ![Kimberly Powell inducted as Fellow of the American Medical Informatics Association, announced as](https://showme.missouri.edu/wp-content/uploads/2024/06/internet-usage-4x5-2-scaled.jpg) <small>showme.missouri.edu</small>Kimberly Powell inducted as Fellow of the American Medical Informatics Association, announced as ...

Kimberly POWELL | Pennsylvania State University, PA | Penn State | Department Of Curriculum And
-----------------------------------------------------------------------------------------------

 ![Kimberly POWELL | Pennsylvania State University, PA | Penn State | Department of Curriculum and](https://i1.rgstatic.net/ii/profile.image/807870794842112-1569622815790_Q512/Kimberly-Powell-11.jpg) <small>www.researchgate.net</small>Kimberly POWELL | Pennsylvania State University, PA | Penn State | Department of Curriculum and ...

NVIDIA On LinkedIn: Missed #EmTechDigital? Watch Kimberly Powell, Our Sr. Director Of…
--------------------------------------------------------------------------------------

 ![NVIDIA on LinkedIn: Missed #EmTechDigital? Watch Kimberly Powell, our Sr. Director of…](https://media.licdn.com/dms/image/C4E22AQF_Yb-stkVkEg/feedshare-shrink_800/0/1592157286148?e=2147483647&v=beta&t=7QHOCwj_Y8H2hWCipes3UAij4_lekRTa99CikP6HdkA) <small>www.linkedin.com</small>NVIDIA on LinkedIn: Missed #EmTechDigital? Watch Kimberly Powell, our Sr. Director of…

Nvidia’s AI Healthcare Vision Spans New Drugs, Robots, And Beyond - Fast Company
--------------------------------------------------------------------------------

 ![Nvidia’s AI healthcare vision spans new drugs, robots, and beyond - Fast Company](https://images.fastcompany.com/image/upload/f_webp,q_auto,c_fit/wp-cms-2/2025/12/p-1-91452480-kimberly-powell-qa.jpg) <small>www.fastcompany.com</small>Nvidia’s AI healthcare vision spans new drugs, robots, and beyond - Fast Company

Kimberly Powell Honored For Pioneering Work In Health Informatics And Gerontology
---------------------------------------------------------------------------------

 ![Kimberly Powell honored for pioneering work in health informatics and gerontology](https://nursing.missouri.edu/wp-content/uploads/2024/06/Kimberly-Powell-FAMIA-induction.png) <small>nursing.missouri.edu</small>Kimberly Powell honored for pioneering work in health informatics and gerontology

Kimberly POWELL | Assistant Professor | PhD, RN | University Of Missouri, Missouri | Mizzou
-------------------------------------------------------------------------------------------

 ![Kimberly POWELL | Assistant Professor | PhD, RN | University of Missouri, Missouri | Mizzou](https://i1.rgstatic.net/ii/profile.image/548708995813376-1507833827958_Q512/Kimberly-Powell-5.jpg) <small>www.researchgate.net</small>Kimberly POWELL | Assistant Professor | PhD, RN | University of Missouri, Missouri | Mizzou ...

Kimberly Powell Honored For Pioneering Work In Health Informatics And Gerontology
---------------------------------------------------------------------------------

 ![Kimberly Powell honored for pioneering work in health informatics and gerontology](https://nursing.missouri.edu/wp-content/uploads/2024/05/Congratulations.png) <small>nursing.missouri.edu</small>Kimberly Powell honored for pioneering work in health informatics and gerontology

The History And Future Of Healthcare At Nvidia, According To Its Healthcare VP Kimberly Powell
----------------------------------------------------------------------------------------------

 ![The history and future of healthcare at Nvidia, according to its healthcare VP Kimberly Powell](https://cdn.sanity.io/images/bl383u0v/production/231c26908ecfb4c46ca27dc03994c37ea6982bf3-1500x1000.jpg?rect=0,106,1500,788&w=1200&h=630&q=70&fit=crop&auto=format) <small>www.healthcare-brew.com</small>The history and future of healthcare at Nvidia, according to its healthcare VP Kimberly Powell

Rapid Expansion Of Telehealth In Nursing Homes Studied By Mizzou
----------------------------------------------------------------

 ![Rapid expansion of telehealth in nursing homes studied by Mizzou](https://www.columbiatribune.com/gcdn/presto/2021/11/08/NCDT/f2030b22-85a6-4b25-b46e-34ecc616c90e-Kimberley-Powell.jpg?crop=1120,630,x0,y192&width=1120&height=630&format=pjpg&auto=webp) <small>www.columbiatribune.com</small>Rapid expansion of telehealth in nursing homes studied by Mizzou

Kimberly Powell - Vice President / General Manager, Healthcare @ NVIDIA - Crunchbase Person Profile
---------------------------------------------------------------------------------------------------

 ![Kimberly Powell - Vice President / General Manager, Healthcare @ NVIDIA - Crunchbase Person Profile](https://images.crunchbase.com/image/upload/c_thumb,h_256,w_256,f_auto,g_face,z_0.7,q_auto:eco,dpr_1/v1486125205/a5yj10qzswrekrnfpwag.png) <small>www.crunchbase.com</small>Kimberly Powell - Vice President / General Manager, Healthcare @ NVIDIA - Crunchbase Person Profile

Kimberly Powell - Nurse Practitioner | LinkedIn
-----------------------------------------------

 ![Kimberly Powell - Nurse Practitioner | LinkedIn](https://media.licdn.com/dms/image/v2/C5603AQF0MDdb46gYPA/profile-displayphoto-shrink_200_200/profile-displayphoto-shrink_200_200/0/1517816306842?e=2147483647&v=beta&t=jV3KuSUolnoDYE7NcPw8Ai65M953Zx3u7Dib_Rw9PRk) <small>www.linkedin.com</small>Kimberly Powell - Nurse Practitioner | LinkedIn

Nvidia Expands AI Ambitions In Healthcare; Aims To Transform Hospitals With Robotics – Digital
----------------------------------------------------------------------------------------------

 ![Nvidia expands AI ambitions in healthcare; aims to transform hospitals with robotics – Digital](https://digitaleconomymag.com/wp-content/uploads/2024/11/Nvidia-Kimberly-Powel.png) <small>digitaleconomymag.com</small>Nvidia expands AI ambitions in healthcare; aims to transform hospitals with robotics – Digital ...

FDC Welcomes Kimberly Powell, APRN! | Medical Associates Of Northwest Arkansas
------------------------------------------------------------------------------

 ![FDC Welcomes Kimberly Powell, APRN! | Medical Associates of Northwest Arkansas](https://mana.md/wp-content/uploads/2022/06/Powell_KImberly_blog.jpg) <small>mana.md</small>FDC Welcomes Kimberly Powell, APRN! | Medical Associates of Northwest Arkansas

NVIDIA: A Nova Fronteira Da Medicina Está Na IA - CM
----------------------------------------------------

 ![NVIDIA: A nova fronteira da Medicina está na IA - CM](https://consumidormoderno.com.br/wp-content/uploads/2025/03/Nvidia_Kimberly-Powell-1024x530.webp) <small>consumidormoderno.com.br</small>NVIDIA: A nova fronteira da Medicina está na IA - CM

AIで医療分野にイノベーションを起こすNVIDIA - PC Watch
------------------------------------

 ![AIで医療分野にイノベーションを起こすNVIDIA - PC Watch](https://asset.watch.impress.co.jp/img/pcw/docs/1120/878/DSCF5066_l.jpg) <small>pc.watch.impress.co.jp</small>AIで医療分野にイノベーションを起こすNVIDIA - PC Watch

Generative AI Is Revolutionizing Healthcare, From Drug Discovery To Diagnostics And Post-op Care
------------------------------------------------------------------------------------------------

 ![Generative AI is revolutionizing healthcare, from drug discovery to diagnostics and post-op care](https://media.licdn.com/dms/image/v2/D4D22AQHI7fbK1GV1QQ/feedshare-shrink_2048_1536/feedshare-shrink_2048_1536/0/1717762363344?e=2147483647&v=beta&t=HcXrmL3078ePC82LlnhipxGpfpS2lI088q7m0yCHQ0I) <small>pe.linkedin.com</small>Generative AI is revolutionizing healthcare, from drug discovery to diagnostics and post-op care ...

Kimberly Powell Special Address - Healthcare At GTC | Channah Blocq
-------------------------------------------------------------------

 ![Kimberly Powell Special Address - Healthcare at GTC | Channah Blocq](https://media.licdn.com/dms/image/v2/D4E10AQEoQkQL3_Sr8w/image-shrink_1280/image-shrink_1280/0/1707382180957?e=2147483647&v=beta&t=0dqql3MYC7lUbb88BTFqqiIbvIz3Tb1NcqvpEZkm5PY) <small>www.linkedin.com</small>Kimberly Powell Special Address - Healthcare at GTC | Channah Blocq

Augusta Health Neighborhood Clinic – Augusta Health
---------------------------------------------------

 ![Augusta Health Neighborhood Clinic – Augusta Health](https://www.augustahealth.com/wp-content/uploads/2023/04/Kim-Powell-2-scaled.jpg) <small>www.augustahealth.com</small>Augusta Health Neighborhood Clinic – Augusta Health

60 Seconds With Kim Powell, PhD, RN - Print News
------------------------------------------------

 ![60 Seconds with Kim Powell, PhD, RN - Print News](https://www.mcknights.com/wp-content/uploads/sites/5/2023/01/006_60Seconds_Powell-Kim_1440X810.jpg) <small>www.mcknights.com</small>60 Seconds with ... Kim Powell, PhD, RN - Print News

What Can Health Care Learn From Self-Driving Cars? | Johns Hopkins Medicine
---------------------------------------------------------------------------

 ![What Can Health Care Learn from Self-Driving Cars? | Johns Hopkins Medicine](https://www.hopkinsmedicine.org/-/media/images/articles/2018/03/kimberly_powell.jpeg?h=640&iar=0&w=640&hash=1741F5E78A512573722D6BEAB32D9288) <small>www.hopkinsmedicine.org</small>What Can Health Care Learn from Self-Driving Cars? | Johns Hopkins Medicine

From The Office To The Lab, Amgen Uses AI Tools To Unlock Innovation | Amgen
----------------------------------------------------------------------------

 ![From the Office to the Lab, Amgen Uses AI Tools to Unlock Innovation | Amgen](https://www.amgen.com/stories/2024/05/-/media/Themes/CorporateAffairs/amgen-com/amgen-com/Images/stories/2024/05-21-From-the-Office-to-the-Lab-Amgen-Uses-AI-Tools-to-Unlock-Innovation/powell.png) <small>www.amgen.com</small>From the Office to the Lab, Amgen Uses AI Tools to Unlock Innovation | Amgen

Powell, Kimberly R., APRN - Medical Associates Of Northwest Arkansas
--------------------------------------------------------------------

 ![Powell, Kimberly R., APRN - Medical Associates of Northwest Arkansas](https://mana.md/wp-content/uploads/2022/06/Powell_Kim_headshotweb.jpg) <small>mana.md</small>Powell, Kimberly R., APRN - Medical Associates of Northwest Arkansas

Kimberly Powell Email &amp; Phone Number | NVIDIA Vice President And General Manager, Healthcare At
---------------------------------------------------------------------------------------------------

 ![Kimberly Powell Email & Phone Number | NVIDIA Vice President and General Manager, Healthcare at](https://d2gjqh9j26unp0.cloudfront.net/profilepic/52df68b74126080cddd436a5f381c3c3) <small>rocketreach.co</small>Kimberly Powell Email &amp; Phone Number | NVIDIA Vice President and General Manager, Healthcare at ...

Powell, kimberly r., aprn. Nvidia’s ai healthcare vision spans new drugs, robots, and beyond. Kimberly powell
