---
title: "Porto 5 Benfica 0 - Fc porto 0-0 benfica, liga portugal betclic (ex liga nos) : résumé du match (05/10/2025)"
description: "Campeões f.c.porto: f.c.porto 5-0 s.l.benfica . que têm a dizer sobre isto de 5 golos?"
date: "2026-05-06"
categories:
- "Uncategorized"
images:
- "https://portugoal.net/images/FCPorto/Porto50Benfica.jpg"
featuredImage: "https://organizer-assets.vsports.pt/media/game_cover/DOC.20240303.42450250.2MAR9513_copy.webp"
featured_image: "https://i.ytimg.com/vi/_88Mqg8rHCs/maxresdefault.jpg"
image: "https://www.noticiasmaia.com/wp-content/uploads/2024/03/fc_porto_5_0-1024x630.jpg"
---

If you are looking for Porto Benfica 5-0 - Benfica Vs Porto 6 Classic Clashes Between Portugal S Powerhouse Rivals you've came to the right web. We have 35 Images about Porto Benfica 5-0 - Benfica Vs Porto 6 Classic Clashes Between Portugal S Powerhouse Rivals like Porto-Benfica 5-0 Extended HIGHLIGHTS 2024 - YouTube, Resumo: FC Porto 5-0 Benfica - Liga Portugal Betclic | sport tv - YouTube and also Vídeo - Liga Portugal Betclic (24ª Jornada): Resumo FC Porto 5-0 Benfica. Read more:

Porto Benfica 5-0 - Benfica Vs Porto 6 Classic Clashes Between Portugal S Powerhouse Rivals
-------------------------------------------------------------------------------------------

 ![Porto Benfica 5-0 - Benfica Vs Porto 6 Classic Clashes Between Portugal S Powerhouse Rivals](https://i.pinimg.com/originals/14/d1/fb/14d1fb9ea1b4f2157f8639b3188d5b8e.jpg) <small>kathrynsbeetlebu.blogspot.com</small>Porto Benfica 5-0 - Benfica Vs Porto 6 Classic Clashes Between Portugal S Powerhouse Rivals ...

Porto-Benfica 5-0 Extended HIGHLIGHTS 2024 - YouTube
----------------------------------------------------

 ![Porto-Benfica 5-0 Extended HIGHLIGHTS 2024 - YouTube](https://i.ytimg.com/vi/Rju4y00Hup0/maxresdefault.jpg) <small>www.youtube.com</small>Porto-Benfica 5-0 Extended HIGHLIGHTS 2024 - YouTube

Pepe Of Porto And João Mario Of Benfica Challenge For The Ball During... News Photo - Getty Images
--------------------------------------------------------------------------------------------------

 ![Pepe of Porto and João Mario of Benfica challenge for the ball during... News Photo - Getty Images](https://media.gettyimages.com/id/1480741775/photo/sl-benfica-v-fc-porto-liga-portugal-bwin.jpg?s=1024x1024&w=gi&k=20&c=A9D4A_gi0qbAenMsM660CB-7X1u9TZ3X3h5Uk6dknQc=) <small>www.gettyimages.com</small>Pepe of Porto and João Mario of Benfica challenge for the ball during... News Photo - Getty Images

Em Direto: FC Porto 5-0 Benfica (terminado) - Tribuna
-----------------------------------------------------

 ![Em direto: FC Porto 5-0 Benfica (terminado) - Tribuna](https://images.impresa.pt/olimpia/2024-03-02-Benfica-FC-Porto.jpg-ff0f549d/original) <small>tribuna.expresso.pt</small>Em direto: FC Porto 5-0 Benfica (terminado) - Tribuna

FC PORTO 5-0 SL BENFICA (Resumo) » 7 Novembro 2010 - YouTube
------------------------------------------------------------

 ![FC PORTO 5-0 SL BENFICA (Resumo) » 7 Novembro 2010 - YouTube](https://i.ytimg.com/vi/juwLN9HkwnM/maxresdefault.jpg) <small>www.youtube.com</small>FC PORTO 5-0 SL BENFICA (Resumo) » 7 Novembro 2010 - YouTube

Vídeo - Liga Portugal Betclic (24ª Jornada): Resumo FC Porto 5-0 Benfica
------------------------------------------------------------------------

 ![Vídeo - Liga Portugal Betclic (24ª Jornada): Resumo FC Porto 5-0 Benfica](https://stc.vsports.pt/bigpic/liga/2324/a85gGrMmOCCR3PeZBeDof.jpg) <small>vsports.pt</small>Vídeo - Liga Portugal Betclic (24ª Jornada): Resumo FC Porto 5-0 Benfica

Résultat Porto - Benfica (5-0) La 24e Journée De Liga Portugal Betclic 2023/2024 03/03
--------------------------------------------------------------------------------------

 ![Résultat Porto - Benfica (5-0) la 24e journée de Liga Portugal Betclic 2023/2024 03/03](https://assets-fr.imgfoot.com/match-cover-fr-3901304647934524848-348438376328710519.jpg) <small>www.footmercato.net</small>Résultat Porto - Benfica (5-0) la 24e journée de Liga Portugal Betclic 2023/2024 03/03

GOLEADA HISTÓRICA EN PORTUGAL: PORTO APLASTÓ A BENFICA POR 5-0 EN UN DERBI IMPRESIONANTE 🔴 - YouTube
----------------------------------------------------------------------------------------------------

 ![GOLEADA HISTÓRICA EN PORTUGAL: PORTO APLASTÓ A BENFICA POR 5-0 EN UN DERBI IMPRESIONANTE 🔴 - YouTube](https://i.ytimg.com/vi/4IvPcVc0BEM/maxresdefault.jpg) <small>www.youtube.com</small>GOLEADA HISTÓRICA EN PORTUGAL: PORTO APLASTÓ A BENFICA POR 5-0 EN UN DERBI IMPRESIONANTE 🔴 - YouTube

FC Porto Arrasa Benfica Com Goleada De 5-0 No Dragão
----------------------------------------------------

 ![FC Porto arrasa Benfica com goleada de 5-0 no Dragão](https://www.noticiasmaia.com/wp-content/uploads/2024/03/fc_porto_5_0-1024x630.jpg) <small>www.noticiasmaia.com</small>FC Porto arrasa Benfica com goleada de 5-0 no Dragão

Resumo: FC Porto 5-0 Benfica - Liga Portugal Betclic | Sport Tv - YouTube
-------------------------------------------------------------------------

 ![Resumo: FC Porto 5-0 Benfica - Liga Portugal Betclic | sport tv - YouTube](https://i.ytimg.com/vi/a-Io-0xIbq8/maxresdefault.jpg) <small>www.youtube.com</small>Resumo: FC Porto 5-0 Benfica - Liga Portugal Betclic | sport tv - YouTube

Portuguese Primeira Liga | FC Porto 5 - 0 Benfica | 2023-2024 | Football Web Pages
----------------------------------------------------------------------------------

 ![Portuguese Primeira Liga | FC Porto 5 - 0 Benfica | 2023-2024 | Football Web Pages](https://www.footballwebpages.co.uk/social.jpg?season=20232024&match=475980) <small>www.footballwebpages.co.uk</small>Portuguese Primeira Liga | FC Porto 5 - 0 Benfica | 2023-2024 | Football Web Pages

FC Porto 0-0 Benfica Highlights, Goals &amp; Key Moments (5 Oct 2025) | Liga Portugal - FootyRoom
-------------------------------------------------------------------------------------------------

 ![FC Porto 0-0 Benfica Highlights, Goals & Key Moments (5 Oct 2025) | Liga Portugal - FootyRoom](https://i.ytimg.com/vi/vpyRmn5Nt9s/maxresdefault.jpg) <small>footyroom.co</small>FC Porto 0-0 Benfica Highlights, Goals &amp; Key Moments (5 Oct 2025) | Liga Portugal - FootyRoom

Porto Punish Benfica 5-0 At Estádio Do Dragão - Portugoal.net
-------------------------------------------------------------

 ![Porto punish Benfica 5-0 at Estádio do Dragão - portugoal.net](https://portugoal.net/images/FCPorto/Porto50Benfica.jpg) <small>portugoal.net</small>Porto punish Benfica 5-0 at Estádio do Dragão - portugoal.net

Resultado Final: FC Porto 5-0 Benfica (Veja Todos Os Golos) - CNN Portugal
--------------------------------------------------------------------------

 ![Resultado final: FC Porto 5-0 Benfica (Veja todos os golos) - CNN Portugal](https://img.iol.pt/preset/65e5082bd34e87e0c08a5022/og/cnn) <small>cnnportugal.iol.pt</small>Resultado final: FC Porto 5-0 Benfica (Veja todos os golos) - CNN Portugal

Campeões F.C.Porto: F.C.Porto 5-0 S.L.Benfica . Que Têm A Dizer Sobre Isto De 5 Golos?
--------------------------------------------------------------------------------------

 ![Campeões F.C.Porto: F.C.Porto 5-0 S.L.Benfica . Que têm a dizer sobre isto de 5 golos?](https://4.bp.blogspot.com/_NDATgO5aHIc/TNfVpgB50VI/AAAAAAAAFOo/wOVZ5FNZ1IA/s1600/fcp5x0slb.bmp) <small>campeoesfcporto.blogspot.com</small>Campeões F.C.Porto: F.C.Porto 5-0 S.L.Benfica . Que têm a dizer sobre isto de 5 golos?

Futebol De Verdade Flash: FC Porto 5, Benfica 0 - YouTube
---------------------------------------------------------

 ![Futebol de Verdade Flash: FC Porto 5, Benfica 0 - YouTube](https://i.ytimg.com/vi/TptZztet5uc/maxresdefault.jpg) <small>www.youtube.com</small>Futebol de Verdade Flash: FC Porto 5, Benfica 0 - YouTube

FC Porto-Benfica, 5-0 (resultado Final) | MAISFUTEBOL
-----------------------------------------------------

 ![FC Porto-Benfica, 5-0 (resultado final) | MAISFUTEBOL](https://img.iol.pt/image/id/65e4f592d34e8d13c9b867fa/1024) <small>maisfutebol.iol.pt</small>FC Porto-Benfica, 5-0 (resultado final) | MAISFUTEBOL

PORTO 5 BENFICA 0 - YouTube
---------------------------

 ![PORTO 5 BENFICA 0 - YouTube](https://i.ytimg.com/vi/H9jSEa3iHmw/maxresdefault.jpg) <small>www.youtube.com</small>PORTO 5 BENFICA 0 - YouTube

FC Porto 0-0 Benfica, Liga Portugal Betclic (ex Liga Nos) : Résumé Du Match (05/10/2025)
----------------------------------------------------------------------------------------

 ![FC Porto 0-0 Benfica, Liga Portugal Betclic (ex Liga Nos) : résumé du match (05/10/2025)](https://www.lequipe.fr/_medias/img-photo-jpg/soccer-football-primeira-liga-fc-porto-v-benfica-estadio-do-dragao-porto-portugal-october-5-2025-ben/1500000002286511/0:90,2500:1565-828-490-75/a0132.jpg) <small>www.lequipe.fr</small>FC Porto 0-0 Benfica, Liga Portugal Betclic (ex Liga Nos) : résumé du match (05/10/2025)

Final Do Jogo | FC Porto 5-0 Benfica | 24a Jornada Liga Portugal 23/24 - YouTube
--------------------------------------------------------------------------------

 ![Final do jogo | FC Porto 5-0 Benfica | 24a jornada Liga Portugal 23/24 - YouTube](https://i.ytimg.com/vi/Hyr3dgut3EE/maxresdefault.jpg?sqp=-oaymwEmCIAKENAF8quKqQMa8AEB-AH-CYAC0AWKAgwIABABGGUgZShlMA8=&rs=AOn4CLCXctVYXMF2DTG42kZhX5IkAq1riA) <small>www.youtube.com</small>Final do jogo | FC Porto 5-0 Benfica | 24a jornada Liga Portugal 23/24 - YouTube

FC Porto 5-0 Benfica
--------------------

 ![FC Porto 5-0 Benfica](https://organizer-assets.vsports.pt/media/game_cover/DOC.20240303.42450250.2MAR9513_copy.webp) <small>vsports.pt</small>FC Porto 5-0 Benfica

FC PORTO 5 - 0 Benfica Download 1080i - YouTube
-----------------------------------------------

 ![FC PORTO 5 - 0 benfica download 1080i - YouTube](https://i.ytimg.com/vi/H13FSKOwmAg/hqdefault.jpg) <small>www.youtube.com</small>FC PORTO 5 - 0 benfica download 1080i - YouTube

Pepe Of FC Porto Of FC Porto With Chiquinho Of SL Benfica In Action... News Photo - Getty Images
------------------------------------------------------------------------------------------------

 ![Pepe of FC Porto of FC Porto with Chiquinho of SL Benfica in action... News Photo - Getty Images](https://media.gettyimages.com/id/1250865456/photo/sl-benfica-v-fc-porto-liga-portugal-bwin.jpg?s=1024x1024&w=gi&k=20&c=xkVrfEYBByOoraZ5UfHsRjmmoLeO7b9PR_jQ4mCnqFA=) <small>www.gettyimages.com</small>Pepe of FC Porto of FC Porto with Chiquinho of SL Benfica in action... News Photo - Getty Images

Porto Massacra O Benfica Em Clássico Com Show Brasileiro: 5 A 0 | Ge
--------------------------------------------------------------------

 ![Porto massacra o Benfica em clássico com show brasileiro: 5 a 0 | Ge](https://s2-ge.glbimg.com/34jgTZoD1XJ8RjAsJGY65VVH5x0=/2300x0/filters:format(jpeg)/https://i.s3.glbimg.com/v1/AUTH_bc8228b6673f488aa253bbcb03c80ec5/internal_photos/bs/2024/l/d/Xz8BHTRjS3y7TfhKm2Ag/2024-03-03t215320z-368138143-up1ek331osvrq-rtrmadp-3-soccer-portugal-por-slb-report.jpg) <small>ge.globo.com</small>Porto massacra o Benfica em clássico com show brasileiro: 5 a 0 | Ge

Eis Os Principais Destaques Do FC Porto X SL Benfica (5-0)
----------------------------------------------------------

 ![Eis os principais destaques do FC Porto x SL Benfica (5-0)](https://bolanarede.pt/wp-content/uploads/2024/03/FC-Porto-Jogadores.jpg) <small>bolanarede.pt</small>Eis os principais destaques do FC Porto x SL Benfica (5-0)

🔵 PORTO 5-0 BENFICA 🔴 (ANÁLISE) Benfica é Goleado No Dragão, águias Vivem Novo Pesadelo! - YouTube
--------------------------------------------------------------------------------------------------

 ![🔵 PORTO 5-0 BENFICA 🔴 (ANÁLISE) Benfica é goleado no Dragão, águias vivem novo pesadelo! - YouTube](https://i.ytimg.com/vi/8k1Qpv8delI/maxresdefault.jpg) <small>www.youtube.com</small>🔵 PORTO 5-0 BENFICA 🔴 (ANÁLISE) Benfica é goleado no Dragão, águias vivem novo pesadelo! - YouTube

Eis Os 5 Destaques Do Benfica X FC Porto Em Jogo Da Primeira Liga
-----------------------------------------------------------------

 ![Eis os 5 destaques do Benfica x FC Porto em jogo da Primeira Liga](https://binny-bolanarede.b-cdn.net/wp-content/uploads/2026/03/Nicolas-Otamendi-Benfica-Oskar-Pietuszweski-FC-Porto.jpg) <small>bolanarede.pt</small>Eis os 5 destaques do Benfica x FC Porto em jogo da Primeira Liga

7 Jogos Decisivos Entre FC Porto E Benfica Na 2.ª Volta
-------------------------------------------------------

 ![7 jogos decisivos entre FC Porto e Benfica na 2.ª volta](https://binny-bolanarede.b-cdn.net/wp-content/uploads/2024/03/Porto-x-Benfica-2-1024x683.jpg) <small>bolanarede.pt</small>7 jogos decisivos entre FC Porto e Benfica na 2.ª volta

PORTO 5-0 BENFICA!! ERROS INADMISSÍVEIS DO TREINADOR ARRASAM O GLORIOSO E DEIXA MORAL DE RASTOS
-----------------------------------------------------------------------------------------------

 ![PORTO 5-0 BENFICA!! ERROS INADMISSÍVEIS DO TREINADOR ARRASAM O GLORIOSO E DEIXA MORAL DE RASTOS](https://i.ytimg.com/vi/_88Mqg8rHCs/maxresdefault.jpg) <small>www.youtube.com</small>PORTO 5-0 BENFICA!! ERROS INADMISSÍVEIS DO TREINADOR ARRASAM O GLORIOSO E DEIXA MORAL DE RASTOS ...

Porto Massacra O Benfica Em Clássico Com Show Brasileiro: 5 A 0 | Ge
--------------------------------------------------------------------

 ![Porto massacra o Benfica em clássico com show brasileiro: 5 a 0 | Ge](https://s03.video.glbimg.com/x240/12405602.jpg) <small>ge.globo.com</small>Porto massacra o Benfica em clássico com show brasileiro: 5 a 0 | Ge

FC Porto-Benfica, 5-0: O Duelo Em 5 Factos - Espião Record By Betclic - Jornal Record
-------------------------------------------------------------------------------------

 ![FC Porto-Benfica, 5-0: o duelo em 5 factos - Espião Record by Betclic - Jornal Record](https://cdn.record.pt/images/2024-03/img_1200x721uu2024-03-04-01-49-54-2227769.jpg) <small>www.record.pt</small>FC Porto-Benfica, 5-0: o duelo em 5 factos - Espião Record by Betclic - Jornal Record

FC Porto 5 - 0 SL Benfica (Relato) | Jornada 24 Da I Liga - Golo FM | A Primeira Rádio Desporto
-----------------------------------------------------------------------------------------------

 ![FC Porto 5 - 0 SL Benfica (Relato) | Jornada 24 da I Liga - Golo FM | A Primeira Rádio Desporto](https://golo.fm/wp-content/uploads/2024/03/Porto-vs-Benfica-03032024-20H30-CAPA.png) <small>golo.fm</small>FC Porto 5 - 0 SL Benfica (Relato) | Jornada 24 da I Liga - Golo FM | A Primeira Rádio Desporto

FC Porto-Benfica, 5-0 (destaques Das águias) | MAISFUTEBOL
----------------------------------------------------------

 ![FC Porto-Benfica, 5-0 (destaques das águias) | MAISFUTEBOL](https://www.iol.pt/multimedia/oratvi/multimedia/imagem/id/65e4fbf1d34e8d13c9b86836/1024) <small>maisfutebol.iol.pt</small>FC Porto-Benfica, 5-0 (destaques das águias) | MAISFUTEBOL

Resumo: FC Porto 5-0 Moreirense (Liga 23/24 #18) - YouTube
----------------------------------------------------------

 ![Resumo: FC Porto 5-0 Moreirense (Liga 23/24 #18) - YouTube](https://i.ytimg.com/vi/8ng_xRwIAH4/maxresdefault.jpg) <small>www.youtube.com</small>Resumo: FC Porto 5-0 Moreirense (Liga 23/24 #18) - YouTube

FC Porto 5 - 0 SL Benfica (2010/2011) - YouTube
-----------------------------------------------

 ![FC Porto 5 - 0 SL Benfica (2010/2011) - YouTube](https://i.ytimg.com/vi/zqvMPuf7boI/maxresdefault.jpg) <small>www.youtube.com</small>FC Porto 5 - 0 SL Benfica (2010/2011) - YouTube

Fc porto 0-0 benfica, liga portugal betclic (ex liga nos) : résumé du match (05/10/2025). Fc porto 5-0 benfica. Futebol de verdade flash: fc porto 5, benfica 0
