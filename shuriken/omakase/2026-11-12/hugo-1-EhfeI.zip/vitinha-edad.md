---
title: "Vitinha Edad - Psg : vitinha au real madrid, la majorité a parlé"
description: "vitinha est t-il devenu un joueur de classe mondiale après sa saison avec le psg et ses ..."
date: "2026-09-11"
categories:
- "Uncategorized"
images:
- "https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA25ThH4.img?w=1800&amp;h=975&amp;m=4&amp;q=81"
featuredImage: "https://upload.wikimedia.org/wikipedia/commons/5/57/Vitinha%2C_Euro2024_%28Agência_Lusa%29.png"
featured_image: "https://media.gettyimages.com/id/2170994294/photo/paris-saint-germain-portraits-uefa-champions-league-2024-25.jpg?s=1024x1024&amp;w=gi&amp;k=20&amp;c=_Xtt0fUKmEUhiRBD8sZscaX_azx9voxwZr0_2SY-rs8="
image: "https://media.gettyimages.com/id/2170994294/photo/paris-saint-germain-portraits-uefa-champions-league-2024-25.jpg?s=1024x1024&amp;w=gi&amp;k=20&amp;c=_Xtt0fUKmEUhiRBD8sZscaX_azx9voxwZr0_2SY-rs8="
---

If you are looking for Espanhóis consideram astro do PSG como possível substituto de Vini Jr, no Real Madrid you've visit to the right place. We have 35 Images about Espanhóis consideram astro do PSG como possível substituto de Vini Jr, no Real Madrid like Vitinha age, position, salary and Net Worth in 2025, facts, girlfriend, football Career, Vitinha of Paris Saint-Germain poses for a portrait during the UEFA... News Photo - Getty Images and also Vitinha relevo generacional de Modric que convence al Real Madrid. Here you go:

Espanhóis Consideram Astro Do PSG Como Possível Substituto De Vini Jr, No Real Madrid
-------------------------------------------------------------------------------------

 ![Espanhóis consideram astro do PSG como possível substituto de Vini Jr, no Real Madrid](https://lncimg.lance.com.br/cdn-cgi/image/width=1280,height=720,quality=75,format=webp/wp-content-galerias/uploads/2024/10/vitinha-psg.jpeg) <small>www.otempo.com.br</small>Espanhóis consideram astro do PSG como possível substituto de Vini Jr, no Real Madrid

Vitinha Age, Position, Salary And Net Worth In 2025, Facts, Girlfriend, Football Career
---------------------------------------------------------------------------------------

 ![Vitinha age, position, salary and Net Worth in 2025, facts, girlfriend, football Career](https://footballarroyo.co.uk/wp-content/uploads/2022/06/Vitinha-age-position-salary-and-Net-Worth-in-2022-girlfriend-facts-football-Career.jpg) <small>footballarroyo.co.uk</small>Vitinha age, position, salary and Net Worth in 2025, facts, girlfriend, football Career

PSG: Vitinha é O MVP Da Taça Da Intercontinental
------------------------------------------------

 ![PSG: Vitinha é o MVP da Taça da Intercontinental](https://binny-bolanarede.b-cdn.net/wp-content/uploads/2025/12/Vitinha-PSG.jpg) <small>bolanarede.pt</small>PSG: Vitinha é o MVP da Taça da Intercontinental

Vitinha Est Pleinement Apte à Débuter La Rencontre Face Au Bayern, Le PSG Alignant Son Effectif
-----------------------------------------------------------------------------------------------

 ![Vitinha est pleinement apte à débuter la rencontre face au Bayern, le PSG alignant son effectif](https://pictures.tribuna.com/image/9574e2a3-f131-41ae-b4f2-2b1ee6c4a35d?width=1920&quality=70) <small>tribuna.com</small>Vitinha est pleinement apte à débuter la rencontre face au Bayern, le PSG alignant son effectif ...

Is Vitinha PSG’s Best Player? - The Athletic
--------------------------------------------

 ![Is Vitinha PSG’s best player? - The Athletic](https://static01.nyt.com/athletic/uploads/wp/2025/04/09083552/Vitinha-1024x683.jpg?width=1920&quality=70&auto=webp) <small>www.nytimes.com</small>Is Vitinha PSG’s best player? - The Athletic

Real Madrid's 'dream' Midfield Target Names Club Legend As His Idol - Madrid Universal
--------------------------------------------------------------------------------------

 ![Real Madrid's 'dream' midfield target names club legend as his idol - Madrid Universal](https://madriduniversal.com/wp-content/uploads/2025/08/paris-saint-germain-fc-v-botafogo-fr-group-b-fifa-club-world-cup-2025-scaled.jpg) <small>madriduniversal.com</small>Real Madrid's 'dream' midfield target names club legend as his idol - Madrid Universal

Vitinha Of Paris Saint-Germain Poses For A Portrait During The UEFA... News Photo - Getty Images
------------------------------------------------------------------------------------------------

 ![Vitinha of Paris Saint-Germain poses for a portrait during the UEFA... News Photo - Getty Images](https://media.gettyimages.com/id/2170978612/photo/paris-saint-germain-portraits-uefa-champions-league-2024-25.jpg?s=1024x1024&w=gi&k=20&c=jQFqOjx8g2wpWfK1a79WnmXr988vgFN3LNwu6Pn6O2k=) <small>www.gettyimages.com</small>Vitinha of Paris Saint-Germain poses for a portrait during the UEFA... News Photo - Getty Images

PSG, Le Real Madrid Insiste Pour Vitinha | Goal.com Français
------------------------------------------------------------

 ![PSG, le Real Madrid insiste pour Vitinha | Goal.com Français](https://assets.goal.com/images/v3/blt534e85c8d64cbc3b/GOAL - Blank WEB - Facebook(3048).jpeg?auto=webp&format=pjpg&width=3840&quality=60) <small>www.goal.com</small>PSG, le Real Madrid insiste pour Vitinha | Goal.com Français

Who Replaces Vitinha? PSG Face Midfield Dilemma Ahead Of Bayern Munich Clash — Tribuna.com
------------------------------------------------------------------------------------------

 ![Who replaces Vitinha? PSG face midfield dilemma ahead of Bayern Munich clash — Tribuna.com](https://pictures.tribuna.com/image/cb95b2b6-2c23-4aec-8e92-d886336ebf7c?width=1920&quality=70) <small>tribuna.com</small>Who replaces Vitinha? PSG face midfield dilemma ahead of Bayern Munich clash — Tribuna.com

Grupo K Del Mundial 2026: ¿quiénes Son Los Jugadores Más Destacados De Portugal, Congo
--------------------------------------------------------------------------------------

 ![Grupo K del Mundial 2026: ¿quiénes son los jugadores más destacados de Portugal, Congo](https://assets.ejecentral.com.mx/dims4/default/67b4317/2147483647/strip/true/crop/1394x790+0+0/resize/2541x1440!/quality/90/?url=https:%2F%2Fk3-prod-ejecentral.s3.us-west-2.amazonaws.com%2Fbrightspot%2Fcd%2Fff%2Fc09e5d6346a88c060a8c863f4752%2Fvitinha-int.png) <small>www.ejecentral.com.mx</small>Grupo K del Mundial 2026: ¿quiénes son los jugadores más destacados de Portugal, Congo ...

Vitinha Of Paris Saint-Germain Poses For A Portrait During The... News Photo - Getty Images
-------------------------------------------------------------------------------------------

 ![Vitinha of Paris Saint-Germain poses for a portrait during the... News Photo - Getty Images](https://media.gettyimages.com/id/2231858088/photo/paris-saint-germain-portraits-uefa-champions-league-2025-26.jpg?s=1024x1024&w=gi&k=20&c=ubf2izaN5OMfeN5wHINTF38ayOdydJKu2qHkYLH7M3M=) <small>www.gettyimages.com</small>Vitinha of Paris Saint-Germain poses for a portrait during the... News Photo - Getty Images

Vitinha Of Paris Saint-Germain Poses For A Portrait During The UEFA... News Photo - Getty Images
------------------------------------------------------------------------------------------------

 ![Vitinha of Paris Saint-Germain poses for a portrait during the UEFA... News Photo - Getty Images](https://media.gettyimages.com/id/2170994294/photo/paris-saint-germain-portraits-uefa-champions-league-2024-25.jpg?s=1024x1024&w=gi&k=20&c=_Xtt0fUKmEUhiRBD8sZscaX_azx9voxwZr0_2SY-rs8=) <small>www.gettyimages.com</small>Vitinha of Paris Saint-Germain poses for a portrait during the UEFA... News Photo - Getty Images

PSG : Vitinha Au Real Madrid, La Majorité A Parlé
-------------------------------------------------

 ![PSG : Vitinha au Real Madrid, la majorité a parlé](https://r.testifier.nl/Acbs8526SDKI/resizing_type:fit/width:3840/height:2560/plain/https://s3-newsifier.ams3.digitaloceanspaces.com/foot01.com/images/2025-12/vitinha-psg-693b2ba510ad8.jpg@webp) <small>www.foot01.com</small>PSG : Vitinha au Real Madrid, la majorité a parlé

PSG : Un Club Prêt à Une Folie Pour Vitinha
-------------------------------------------

 ![PSG : un club prêt à une folie pour Vitinha](https://www.topmercato.com/wp-content/uploads/2024/08/Vitinha-Portugal-scaled.jpg) <small>www.topmercato.com</small>PSG : un club prêt à une folie pour Vitinha

Vitinha Est T-il Devenu Un Joueur De Classe Mondiale Après Sa Saison Avec Le PSG Et Ses
---------------------------------------------------------------------------------------

 ![Vitinha est t-il devenu un joueur de classe mondiale après sa saison avec le PSG et ses](https://pictures.tribuna.com/image/65e3d933-4131-4c8c-9010-85aabeb685d5?width=1920&quality=70) <small>tribuna.com</small>Vitinha est t-il devenu un joueur de classe mondiale après sa saison avec le PSG et ses ...

Vitinha Of Paris Saint-Germain Poses For A Portrait During The UEFA... News Photo - Getty Images
------------------------------------------------------------------------------------------------

 ![Vitinha of Paris Saint-Germain poses for a portrait during the UEFA... News Photo - Getty Images](https://media.gettyimages.com/id/2170994293/photo/paris-saint-germain-portraits-uefa-champions-league-2024-25.jpg?s=1024x1024&w=gi&k=20&c=D1bEJSJIbj06z2waYTKRVrx42ss0tnJPP4Yo5F7FxWQ=) <small>www.gettyimages.com</small>Vitinha of Paris Saint-Germain poses for a portrait during the UEFA... News Photo - Getty Images

Vitinha Relevo Generacional De Modric Que Convence Al Real Madrid
-----------------------------------------------------------------

 ![Vitinha relevo generacional de Modric que convence al Real Madrid](https://www.elgoldigital.com/wp-content/uploads/2024/07/Vitinha-2023.webp) <small>www.elgoldigital.com</small>Vitinha relevo generacional de Modric que convence al Real Madrid

Vitinha, O Maestro Do PSG Que Brilhou Na Temporada 2024/25
----------------------------------------------------------

 ![Vitinha, o maestro do PSG que brilhou na temporada 2024/25](https://cdn.resfu.com/media/img_news/vitinha--concentrado-en-el-psg-angers-de-ligue-1-2024-25--efe-yoan-valat.jpg) <small>pt.besoccer.com</small>Vitinha, o maestro do PSG que brilhou na temporada 2024/25

Vitinha Of Paris Saint-Germain Poses For A Portrait During The UEFA... News Photo - Getty Images
------------------------------------------------------------------------------------------------

 ![Vitinha of Paris Saint-Germain poses for a portrait during the UEFA... News Photo - Getty Images](https://media.gettyimages.com/id/2170978567/photo/paris-saint-germain-portraits-uefa-champions-league-2024-25.jpg?s=1024x1024&w=gi&k=20&c=AJFZcg22lXaZVGmvJZgbQtV-VuBoPGfBtAKa2WPBH9k=) <small>www.gettyimages.com</small>Vitinha of Paris Saint-Germain poses for a portrait during the UEFA... News Photo - Getty Images

Vitinha :: 2025/2026 - PSG - Ficha E Estatísticas Do Jogador
------------------------------------------------------------

 ![Vitinha :: 2025/2026 - PSG - Ficha e Estatísticas do Jogador](https://www.zerozero.pt/img/jogadores/new/12/84/421284_vitinha_20260617030911.png) <small>www.zerozero.pt</small>Vitinha :: 2025/2026 - PSG - Ficha e Estatísticas do Jogador

Real Madrid: Vitinha é Uma Das Principais Opções Em Cima Da Mesa
----------------------------------------------------------------

 ![Real Madrid: Vitinha é uma das principais opções em cima da mesa](https://binny-bolanarede.b-cdn.net/wp-content/uploads/2025/04/Vitinha-PSG.jpg) <small>bolanarede.pt</small>Real Madrid: Vitinha é uma das principais opções em cima da mesa

Vitinha Of Paris Saint-Germain Poses For A Portrait During The... News Photo - Getty Images
-------------------------------------------------------------------------------------------

 ![Vitinha of Paris Saint-Germain poses for a portrait during the... News Photo - Getty Images](https://media.gettyimages.com/id/2219979174/photo/paris-saint-germain-portraits-fifa-club-world-cup-2025.jpg?s=1024x1024&w=gi&k=20&c=ay3E0xEA9vTSwENBnuVU9SzQCA0XRo6euWcMhqTlP90=) <small>www.gettyimages.com</small>Vitinha of Paris Saint-Germain poses for a portrait during the... News Photo - Getty Images

Vitinha Of Paris Saint-Germain Poses For A Portrait During The... News Photo - Getty Images
-------------------------------------------------------------------------------------------

 ![Vitinha of Paris Saint-Germain poses for a portrait during the... News Photo - Getty Images](https://media.gettyimages.com/id/2219979168/photo/paris-saint-germain-portraits-fifa-club-world-cup-2025.jpg?s=1024x1024&w=gi&k=20&c=ypKX6KGF7R9tpeT-1mus_XgsHrndX0Ohe-Ht6tr15WQ=) <small>www.gettyimages.com</small>Vitinha of Paris Saint-Germain poses for a portrait during the... News Photo - Getty Images

Vitinha : Biographie, âge, Salaire Et Parcours Au PSG | AllezParis
------------------------------------------------------------------

 ![Vitinha : biographie, âge, salaire et parcours au PSG | AllezParis](https://allezparis.fr/wp-content/uploads/2024/11/b4a5908.jpg) <small>allezparis.fr</small>Vitinha : biographie, âge, salaire et parcours au PSG | AllezParis

PSG - Vitinha Raconte Sa Soirée De Rêve Face à Tottenham : "Je Vais M'en Souvenir Toute Ma Vie"
-----------------------------------------------------------------------------------------------

 ![PSG - Vitinha raconte sa soirée de rêve face à Tottenham : "Je vais m'en souvenir toute ma vie"](https://madeinfoot.ouest-france.fr/photos/ligue-des-champions/2025/zoom/ldc-20251127082832-7302.jpg) <small>madeinfoot.ouest-france.fr</small>PSG - Vitinha raconte sa soirée de rêve face à Tottenham : "Je vais m'en souvenir toute ma vie"

Vitinha – Wikipedia
-------------------

 ![Vitinha – Wikipedia](https://upload.wikimedia.org/wikipedia/commons/5/57/Vitinha%2C_Euro2024_%28Agência_Lusa%29.png) <small>sv.wikipedia.org</small>Vitinha – Wikipedia

Real Madrid Have PSG Ace High On List Of Targets To Replace Luka Modrić
-----------------------------------------------------------------------

 ![Real Madrid Have PSG Ace High on List of Targets to Replace Luka Modrić](https://icdn.psgtalk.com/wp-content/uploads/2025/05/vitinha-psg-v-arsenal-champions-league-2025.jpg) <small>psgtalk.com</small>Real Madrid Have PSG Ace High on List of Targets to Replace Luka Modrić

Mercato : L’offre Pharaonique Du Real Madrid Au PSG Pour Vitinha | Goal.com Français
------------------------------------------------------------------------------------

 ![Mercato : L’offre pharaonique du Real Madrid au PSG pour Vitinha | Goal.com Français](https://assets.goal.com/images/v3/blt3e4ad1160fa9acaf/vitinha.jpg?auto=webp&format=pjpg&width=3840&quality=60) <small>www.goal.com</small>Mercato : L’offre pharaonique du Real Madrid au PSG pour Vitinha | Goal.com Français

Vitinha Of Paris Saint-Germain Poses For A Portrait During The... News Photo - Getty Images
-------------------------------------------------------------------------------------------

 ![Vitinha of Paris Saint-Germain poses for a portrait during the... News Photo - Getty Images](https://media.gettyimages.com/id/2219979157/photo/paris-saint-germain-portraits-fifa-club-world-cup-2025.jpg?s=1024x1024&w=gi&k=20&c=z2mu63b78qHEBLCOX0_gpx9wIKfYTtXBG9317EN86iY=) <small>www.gettyimages.com</small>Vitinha of Paris Saint-Germain poses for a portrait during the... News Photo - Getty Images

Real Madrid Interest In PSG Star Confirmed As Transfer Looks Impossible
-----------------------------------------------------------------------

 ![Real Madrid Interest in PSG Star Confirmed as Transfer Looks Impossible](https://icdn.psgtalk.com/wp-content/uploads/2025/04/vitinha-psg-v-arsenal-ucl-2025.jpg) <small>psgtalk.com</small>Real Madrid Interest in PSG Star Confirmed as Transfer Looks Impossible

Liga De Campeones 2024/2025 : Resultados, Clasificaciones Y Todas Estadísticas
------------------------------------------------------------------------------

 ![Liga de Campeones 2024/2025 : Resultados, clasificaciones y todas estadísticas](https://www.footballdatabase.eu/images/photos/players/2024-2025/a_335/335640.jpg) <small>www.footballdatabase.eu</small>Liga de Campeones 2024/2025 : Resultados, clasificaciones y todas estadísticas

Vitinha Of Paris Saint-Germain Poses For A Portrait During The UEFA... News Photo - Getty Images
------------------------------------------------------------------------------------------------

 ![Vitinha of Paris Saint-Germain poses for a portrait during the UEFA... News Photo - Getty Images](https://media.gettyimages.com/id/2170978582/photo/paris-saint-germain-portraits-uefa-champions-league-2024-25.jpg?s=1024x1024&w=gi&k=20&c=diq_2LrxyIBGWEWNqzgbsNBjs-gyFV5evFQPKRKhSbc=) <small>www.gettyimages.com</small>Vitinha of Paris Saint-Germain poses for a portrait during the UEFA... News Photo - Getty Images

PSG Superstar Names Barcelona Legend As His Role Model: 'The One Who Inspired Me The Most
-----------------------------------------------------------------------------------------

 ![PSG superstar names Barcelona legend as his role model: 'The one who inspired me the most](https://barcauniversal.com/wp-content/uploads/2025/12/bayer-04-leverkusen-v-paris-saint-germain-uefa-champions-league-2025-26-league-phase-md3-scaled.jpg) <small>barcauniversal.com</small>PSG superstar names Barcelona legend as his role model: 'The one who inspired me the most ...

Vitinha Of Paris Saint-Germain Poses For A Portrait During The UEFA... News Photo - Getty Images
------------------------------------------------------------------------------------------------

 ![Vitinha of Paris Saint-Germain poses for a portrait during the UEFA... News Photo - Getty Images](https://media.gettyimages.com/id/2170978324/photo/paris-saint-germain-portraits-uefa-champions-league-2024-25.jpg?s=1024x1024&w=gi&k=20&c=GKPxI8N5MENR8OSavIpp0ONk1DIJ7Lzndgl8RPNTi8A=) <small>www.gettyimages.com</small>Vitinha of Paris Saint-Germain poses for a portrait during the UEFA... News Photo - Getty Images

Así Es Vitinha: La Edad Que Tiene, En Qué Equipos Ha Jugado, Cuánto Cuesta
--------------------------------------------------------------------------

 ![Así es Vitinha: la edad que tiene, en qué equipos ha jugado, cuánto cuesta](https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA25ThH4.img?w=1800&h=975&m=4&q=81) <small>www.msn.com</small>Así es Vitinha: la edad que tiene, en qué equipos ha jugado, cuánto cuesta

Vitinha est t-il devenu un joueur de classe mondiale après sa saison avec le psg et ses. Vitinha, o maestro do psg que brilhou na temporada 2024/25. Vitinha of paris saint-germain poses for a portrait during the... news photo
