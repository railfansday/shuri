---
title: "Ciberataque Indra - Indra supera un ciberataque a una filial sin afectar a clientes ni operaciones"
description: "Nato contractor indra group hit by ransomware: hackers threaten data leak in 9 days"
date: "2026-10-12"
categories:
- "Uncategorized"
images:
- "https://www.economiadigital.es/wp-content/uploads/2026/06/indra-group-20260625085813-1536x1023.jpg"
featuredImage: "https://imagenes.elpais.com/resizer/v2/Y4D3FMEAONPRPEOHRUMK26J4MA.jpg?auth=aeb8091f4d980d48e5d63123f69a8659d38db1938e4bc34551bb4689a2b98016&amp;width=828&amp;height=466&amp;smart=true"
featured_image: "https://estaticos-cdn.prensaiberica.es/clip/3968ed73-3eb2-47b2-afc7-801c503874a9_alta-libre-aspect-ratio_default_0.jpg"
image: "https://i.blogs.es/b5792c/indra3_ciberataque/450_1000.jpg"
---

If you are looking for Indra Group lleva a Bruselas capacidades de defensa aérea, antidron y ciberdefensa críticas para you've came to the right page. We have 35 Pictures about Indra Group lleva a Bruselas capacidades de defensa aérea, antidron y ciberdefensa críticas para like Ciberataque de ransomware a Indra | Opinión | HayCanal, Indra investiga un ciberataque a una de sus filiales and also El primer campo de maniobras para la ciberguerra total se prepara en España. Here you go:

Indra Group Lleva A Bruselas Capacidades De Defensa Aérea, Antidron Y Ciberdefensa Críticas Para
------------------------------------------------------------------------------------------------

 ![Indra Group lleva a Bruselas capacidades de defensa aérea, antidron y ciberdefensa críticas para](https://cdn.vozpopuli.com/articulos/articulos-2800376.jpg) <small>www.vozpopuli.com</small>Indra Group lleva a Bruselas capacidades de defensa aérea, antidron y ciberdefensa críticas para ...

Indra Expone Ante La OTAN Su Tecnología De Ciberdefensa
-------------------------------------------------------

 ![Indra expone ante la OTAN su tecnología de ciberdefensa](https://img.europapress.es/fotoweb/fotonoticia_20241216182806_690.jpg) <small>www.europapress.es</small>Indra expone ante la OTAN su tecnología de ciberdefensa

Brecha De Seguridad En Renault: Lo Que Debes Saber Sobre El Ciberataque Revelado En 2025
----------------------------------------------------------------------------------------

 ![Brecha de seguridad en Renault: lo que debes saber sobre el ciberataque revelado en 2025](https://blog.darknetsearch.com/wp-content/uploads/2025/10/Indra-joint-venture.jpg) <small>darknetsearch.com</small>Brecha de seguridad en Renault: lo que debes saber sobre el ciberataque revelado en 2025 ...

Telefónica E Indra Preparan Un Gigante Nacional De Ciberseguridad E IA Con Respaldo Del Gobierno
------------------------------------------------------------------------------------------------

 ![Telefónica e Indra preparan un gigante nacional de ciberseguridad e IA con respaldo del Gobierno](https://elvertice.es/wp-content/uploads/2026/04/Telefonica-e-Indra-preparan-un-gigante-nacional-de-ciberseguridad.png) <small>elvertice.es</small>Telefónica e Indra preparan un gigante nacional de ciberseguridad e IA con respaldo del Gobierno ...

Telefónica, Iberdrola, Gas Natural, Indra Y Ferrovial, Afectadas Por El Ciberataque
-----------------------------------------------------------------------------------

 ![Telefónica, Iberdrola, Gas Natural, Indra y Ferrovial, afectadas por el ciberataque](https://cdn.vozpopuli.com/cdn/posts/189832/articulos-475176-1200x700.jpg) <small>www.vozpopuli.com</small>Telefónica, Iberdrola, Gas Natural, Indra y Ferrovial, afectadas por el ciberataque

Indra Dotará A La UE De Tecnología Para Responder Rápido A Ciberataques | Empresas | Cinco Días
-----------------------------------------------------------------------------------------------

 ![Indra dotará a la UE de tecnología para responder rápido a ciberataques | Empresas | Cinco Días](https://imagenes.elpais.com/resizer/v2/2NLYICJIAVOGLLWM7YCF4E6X7Y.jpg?auth=f70e0378b994e4e98cfc4077ff94642ebec8665cd82264f72031073677400c1f&width=1000) <small>cincodias.elpais.com</small>Indra dotará a la UE de tecnología para responder rápido a ciberataques | Empresas | Cinco Días

Indra Leads The Largest Cyber Situational Awareness Project For European Defence
--------------------------------------------------------------------------------

 ![Indra leads the largest cyber situational awareness project for European defence](https://www.atalayar.com/asset/thumbnail,1280,720,center,center/media/atalayar/images/2021/10/30/20211030111951054947.jpg) <small>www.atalayar.com</small>Indra leads the largest cyber situational awareness project for European defence

Ciberataques: La Otra Guerra Inclemente Que Libran Ucrania Y Rusia
------------------------------------------------------------------

 ![Ciberataques: la otra guerra inclemente que libran Ucrania y Rusia](https://asosec.co/wp-content/uploads/2023/04/20042023-1.jpeg) <small>asosec.co</small>Ciberataques: la otra guerra inclemente que libran Ucrania y Rusia

Indra Investiga Un Ciberataque A Una De Sus Filiales
----------------------------------------------------

 ![Indra investiga un ciberataque a una de sus filiales](https://images.ecestaticos.com/axgX8trbaFY9iPLZcmwOdpzUseI=/0x0:2272x1515/600x315/filters:fill(white):format(jpg):quality(99):watermark(f.elconfidencial.com/file/65c/43d/0ca/65c43d0ca5dbd5ff8f19b44167343db9.png,0,275,1)/f.elconfidencial.com/original/3cb/3cc/69d/3cb3cc69dbfbe3db28461fa4de4cf8ae.jpg) <small>www.elconfidencial.com</small>Indra investiga un ciberataque a una de sus filiales

Indra Supera Un Ciberataque A Una Filial Sin Afectar A Clientes Ni Operaciones
------------------------------------------------------------------------------

 ![Indra supera un ciberataque a una filial sin afectar a clientes ni operaciones](https://www.economiadigital.es/wp-content/uploads/2026/02/EuropaPress_7125115_fachada_sede_indra_25_noviembre_2025_alcobendas_madrid_espana-1000x665.jpg) <small>www.economiadigital.es</small>Indra supera un ciberataque a una filial sin afectar a clientes ni operaciones

Indra Desarrolla La Capacidad Central Para Gestionar Agentes Autónomos De IA En Apoyo A Las
-------------------------------------------------------------------------------------------

 ![Indra desarrolla la capacidad central para gestionar agentes autónomos de IA en apoyo a las](https://www.atalayar.com/asset/thumbnail,1280,720,center,center/media/atalayar/images/2025/05/20/2025052014110629382.jpg) <small>www.atalayar.com</small>Indra desarrolla la capacidad central para gestionar agentes autónomos de IA en apoyo a las ...

La Española Indra Presenta En Estocolmo Un Simulador Avanzado De Entrenamiento En Ciberseguridad
------------------------------------------------------------------------------------------------

 ![La española Indra presenta en Estocolmo un simulador avanzado de entrenamiento en ciberseguridad](https://www.defensa.com/adjuntos/stories/noticias/2014/10/indra icsoc.jpg) <small>www.defensa.com</small>La española Indra presenta en Estocolmo un simulador avanzado de entrenamiento en ciberseguridad ...

Indra Se Lanza A Por 500 Millones Del Negocio De La Ciberdefensa | Empresas
---------------------------------------------------------------------------

 ![Indra se lanza a por 500 millones del negocio de la ciberdefensa | Empresas](https://e00-expansion.uecdn.es/assets/multimedia/imagenes/2025/04/27/17457768373909.jpg) <small>www.expansion.com</small>Indra se lanza a por 500 millones del negocio de la ciberdefensa | Empresas

Nace IndraMind: Nueva División Para Ciberdefensa Y Soberanía Tecnológica
------------------------------------------------------------------------

 ![Nace IndraMind: nueva división para ciberdefensa y soberanía tecnológica](https://okdiario.com/img/2025/11/05/imagen_recortada-14-635x358.jpg) <small>okdiario.com</small>Nace IndraMind: nueva división para ciberdefensa y soberanía tecnológica

Cyberdefence
------------

 ![Cyberdefence](https://defence.indragroup.com/cms-content/2025/09/SEGMENTOS_Ciberdefence_1920x1080-2.jpg) <small>defence.indragroup.com</small>Cyberdefence

Indra — Hackers Behind Recent Attacks On Iran - Check Point Research
--------------------------------------------------------------------

 ![Indra — Hackers Behind Recent Attacks on Iran - Check Point Research](https://research.checkpoint.com/wp-content/uploads/2021/07/Katerji-Cyber-Attack.jpg) <small>research.checkpoint.com</small>Indra — Hackers Behind Recent Attacks on Iran - Check Point Research

INDRA Crea El Líder De Servicios De Ciberseguridad En España Y Portugal
-----------------------------------------------------------------------

 ![INDRA crea el líder de servicios de ciberseguridad en España y Portugal](https://fotografias.larazon.es/clipping/cmsimages01/2020/01/08/54631B7F-70B4-4466-9890-E34110A182C7/69.jpg?crop=498,280,x151,y0&width=1280&height=720&optimize=low&format=jpg) <small>www.larazon.es</small>INDRA crea el líder de servicios de ciberseguridad en España y Portugal

Indra Liderará El Mayor Proyecto De Ciberdefensa De Europa
----------------------------------------------------------

 ![Indra liderará el mayor proyecto de ciberdefensa de Europa](https://static.que.es/wp-content/uploads/2021/10/Indra-liderara-el-mayor-proyecto-de-ciberdefensa-de-Europa.jpg) <small>www.que.es</small>Indra liderará el mayor proyecto de ciberdefensa de Europa

Indra Muestra Los Avances De Ciberconsciencia Situacional Para La Defensa De Europa - Diario
--------------------------------------------------------------------------------------------

 ![Indra muestra los avances de ciberconsciencia situacional para la defensa de Europa - Diario](https://diariobusinessnews.com/wp-content/uploads/2023/06/Indra-muestra-los-avances-del-mayor-proyecto-de-ciberconsciencia-situacional-para-la-defensa-de-Europa-2.jpg) <small>diariobusinessnews.com</small>Indra muestra los avances de ciberconsciencia situacional para la defensa de Europa - Diario ...

Ataques Informáticos En Cinco Días
----------------------------------

 ![Ataques informáticos en Cinco Días](https://imagenes.elpais.com/resizer/v2/Y4D3FMEAONPRPEOHRUMK26J4MA.jpg?auth=aeb8091f4d980d48e5d63123f69a8659d38db1938e4bc34551bb4689a2b98016&width=828&height=466&smart=true) <small>cincodias.elpais.com</small>Ataques informáticos en Cinco Días

Indra Investiga Un Ciberataque De Un Grupo De Hackers Conocido Como The Gentlemen
---------------------------------------------------------------------------------

 ![Indra investiga un ciberataque de un grupo de hackers conocido como The Gentlemen](https://s10.s3c.es/imag/_v0/1920x1080/6/7/5/_documentacion61_Fot125487362.jpg) <small>www.eleconomista.es</small>Indra investiga un ciberataque de un grupo de hackers conocido como The Gentlemen

Indra Group Presenta Su Nueva Unidad De Negocio Indramind En América Latina Para Apoyar La
------------------------------------------------------------------------------------------

 ![Indra Group presenta su nueva unidad de negocio Indramind en América Latina para apoyar la](https://norteenlinea.com/wp-content/uploads/2026/03/indramind.jpg) <small>norteenlinea.com</small>Indra Group presenta su nueva unidad de negocio Indramind en América Latina para apoyar la ...

Audacia Y Sofisticación, ¿estamos Preparados Para El Próximo Ciberataque?
-------------------------------------------------------------------------

 ![Audacia y sofisticación, ¿estamos preparados para el próximo ciberataque?](https://i.blogs.es/b5792c/indra3_ciberataque/450_1000.jpg) <small>www.xataka.com</small>Audacia y sofisticación, ¿estamos preparados para el próximo ciberataque?

Indra Lanza Su Plataforma De Ciberdefensa IndraMind Con Un Volumen De Negocio De 300 Millones
---------------------------------------------------------------------------------------------

 ![Indra lanza su plataforma de ciberdefensa IndraMind con un volumen de negocio de 300 millones](https://estaticos-cdn.prensaiberica.es/clip/3968ed73-3eb2-47b2-afc7-801c503874a9_alta-libre-aspect-ratio_default_0.jpg) <small>www.elperiodico.com</small>Indra lanza su plataforma de ciberdefensa IndraMind con un volumen de negocio de 300 millones

Así Se Protegen Las Empresas Del Ibex 35 Ante Los Ciberataques | Empresas | Cinco Días
--------------------------------------------------------------------------------------

 ![Así se protegen las empresas del Ibex 35 ante los ciberataques | Empresas | Cinco Días](https://imagenes.elpais.com/resizer/v2/S4HF476GEFNCZIXS7BJY3JOKOQ.jpg?auth=f380e0dbe85fe80c312053e9a4897bbc64b1ac27499f7f4b44d3cb0012547e85&width=640) <small>cincodias.elpais.com</small>Así se protegen las empresas del Ibex 35 ante los ciberataques | Empresas | Cinco Días

NATO Contractor Indra Group Hit By Ransomware: Hackers Threaten Data Leak In 9 Days
-----------------------------------------------------------------------------------

 ![NATO Contractor Indra Group Hit by Ransomware: Hackers Threaten Data Leak in 9 Days](http://www.news4hackers.com/wp-content/uploads/2026/07/www.news4hackers.com-nato-contractor-indra-group-hit-by-ransomware-hackers-threaten-data-leak-in-9-days-nato-contractor-indra-group-hit-by-ransomware-hackers-threaten-data-leak-in-9-days.jpg) <small>www.news4hackers.com</small>NATO Contractor Indra Group Hit by Ransomware: Hackers Threaten Data Leak in 9 Days

Indra Resiste El Ciberataque Del Grupo The Gentlemen | Seguridad | IT User
--------------------------------------------------------------------------

 ![Indra resiste el ciberataque del grupo The Gentlemen | Seguridad | IT User](https://www.ituser.es/files/202505/ciberataque.jpg) <small>www.ituser.es</small>Indra resiste el ciberataque del grupo The Gentlemen | Seguridad | IT User

Ciberataque A Indra: El Grupo Ransomware "The Gentlemen" Reclama Haber Vulnerado La
-----------------------------------------------------------------------------------

 ![Ciberataque a Indra: El grupo ransomware "The Gentlemen" reclama haber vulnerado la](https://eldiestro.info/wp-content/uploads/2026/07/Captura-de-pantalla-2026-07-01-082641.png) <small>eldiestro.info</small>Ciberataque a Indra: El grupo ransomware "The Gentlemen" reclama haber vulnerado la ...

Indra Mantiene Sus Servicios Tras Un Ciberataque Mínimo | Demócrata
-------------------------------------------------------------------

 ![Indra mantiene sus servicios tras un ciberataque mínimo | Demócrata](https://www.democrata.es/uploads/s1/28/02/71/6/fotonoticia-20260626190438-1920_30_427x320.jpeg) <small>www.democrata.es</small>Indra mantiene sus servicios tras un ciberataque mínimo | Demócrata

IndraMind Cybersecurity Lanza Su Centro De Innovación Y Talento En Cataluña Para Fortalecer La
----------------------------------------------------------------------------------------------

 ![IndraMind Cybersecurity lanza su centro de innovación y talento en Cataluña para fortalecer la](https://www.indragroup.com/cms-content/2026/04/JPG-1920x1080-83.jpg) <small>www.indragroup.com</small>IndraMind Cybersecurity lanza su centro de innovación y talento en Cataluña para fortalecer la ...

El Primer Campo De Maniobras Para La Ciberguerra Total Se Prepara En España
---------------------------------------------------------------------------

 ![El primer campo de maniobras para la ciberguerra total se prepara en España](https://estaticos-cdn.prensaiberica.es/clip/8a17272f-4870-43fe-8f3b-61aceecf06cb_alta-libre-aspect-ratio_default_0.jpg) <small>www.elperiodico.com</small>El primer campo de maniobras para la ciberguerra total se prepara en España

Indra Se Lanza A Por 500 Millones Del Negocio De La Ciberdefensa | Empresas
---------------------------------------------------------------------------

 ![Indra se lanza a por 500 millones del negocio de la ciberdefensa | Empresas](https://phantom-expansion.uecdn.es/ae098e38d53b7f092bc350b828083e8e/crop/16x0/1559x868/resize/1200/f/webp/assets/multimedia/imagenes/2025/04/27/17457768372808.jpg) <small>www.expansion.com</small>Indra se lanza a por 500 millones del negocio de la ciberdefensa | Empresas

Indra Supera Un Ciberataque A Una Filial Sin Afectar A Clientes Ni Operaciones
------------------------------------------------------------------------------

 ![Indra supera un ciberataque a una filial sin afectar a clientes ni operaciones](https://www.economiadigital.es/wp-content/uploads/2026/06/indra-group-20260625085813-1536x1023.jpg) <small>www.economiadigital.es</small>Indra supera un ciberataque a una filial sin afectar a clientes ni operaciones

Ciberataque De Ransomware A Indra | Opinión | HayCanal
------------------------------------------------------

 ![Ciberataque de ransomware a Indra | Opinión | HayCanal](https://haycanal.com/uploads/noticias/23304/Ciberataque_Indra.jpg) <small>haycanal.com</small>Ciberataque de ransomware a Indra | Opinión | HayCanal

Indra Presenta Un Simulador De Entrenamiento En Ciberseguridad | Silicon
------------------------------------------------------------------------

 ![Indra presenta un simulador de entrenamiento en ciberseguridad | Silicon](https://www.silicon.es/wp-content/uploads/2011/11/ciberataque-estados-unidos-pentagono.jpg) <small>www.silicon.es</small>Indra presenta un simulador de entrenamiento en ciberseguridad | Silicon

Telefónica e indra preparan un gigante nacional de ciberseguridad e ia con respaldo del gobierno .... Ciberataque de ransomware a indra. Así se protegen las empresas del ibex 35 ante los ciberataques
