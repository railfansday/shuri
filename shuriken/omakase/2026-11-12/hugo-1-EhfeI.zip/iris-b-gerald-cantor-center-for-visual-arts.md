---
title: "Iris &amp; B Gerald Cantor Center For Visual Arts - N t r junior hi-res stock photography and images"
description: "N t r junior hi-res stock photography and images"
date: "2026-09-05"
categories:
- "Uncategorized"
images:
- "https://live.staticflickr.com/65535/52488117002_622146bc03_b.jpg"
featuredImage: "https://fastly.4sqi.net/img/general/600x600/M54vfuUdLPUCgwCujO1MFHPBS5acyNuvWeCZfH3EhTU.jpg"
featured_image: "https://c8.alamy.com/comp/KW4KAT/signage-at-entrance-to-cantor-arts-center-formerly-the-leland-stanford-KW4KAT.jpg"
image: "https://c8.alamy.com/comp/2CB92CW/a-french-tourist-visiting-the-auguste-rodin-sculpture-garden-at-the-iris-and-b-gerald-cantor-center-for-visual-arts-stanford-university-ca-2CB92CW.jpg"
---

If you are looking for Iris &amp; B Gerald Cantor Center for Visual Arts | Iris &amp; B Ger… | Flickr you've came to the right place. We have 35 Pics about Iris &amp; B Gerald Cantor Center for Visual Arts | Iris &amp; B Ger… | Flickr like A Chinese tourist poses in front of the Iris &amp; B. Gerald Cantor Center for Visual Arts at, Iris &amp; B. Gerald Cantor Center for Visual Arts – This Above All; and also Cantor museum hi-res stock photography and images - Alamy. Here you go:

Iris &amp; B Gerald Cantor Center For Visual Arts | Iris &amp; B Ger… | Flickr
------------------------------------------------------------------------------

 ![Iris & B Gerald Cantor Center for Visual Arts | Iris & B Ger… | Flickr](https://live.staticflickr.com/65535/52488605186_dd471d2c4c_b.jpg) <small>www.flickr.com</small>Iris &amp; B Gerald Cantor Center for Visual Arts | Iris &amp; B Ger… | Flickr

N T R Junior Hi-res Stock Photography And Images - Alamy
--------------------------------------------------------

 ![N t r junior hi-res stock photography and images - Alamy](https://c8.alamy.com/comp/KW4KAT/signage-at-entrance-to-cantor-arts-center-formerly-the-leland-stanford-KW4KAT.jpg) <small>www.alamy.com</small>N t r junior hi-res stock photography and images - Alamy

El Anatsui | Cantor Arts Center
-------------------------------

 ![El Anatsui | Cantor Arts Center](https://elanatsui.art/cms/2019/04/Iris-B.-Gerald-Cantor-Center-for-Visual-Arts-Stanford-University-California-Photo-courtesy-Sothebys-Museum-Network-720x720.jpg) <small>elanatsui.art</small>El Anatsui | Cantor Arts Center

The Auguste Rodin Sculpture Garden At The Iris And B. Gerald Cantor Center For Visual Arts
------------------------------------------------------------------------------------------

 ![The Auguste Rodin sculpture garden at the Iris and B. Gerald Cantor Center for Visual Arts](https://www.alamy.com/aggregator-api/download?url=https://c8.alamy.com/comp/G3HYC8/the-auguste-rodin-sculpture-garden-at-the-iris-and-b-gerald-cantor-G3HYC8.jpg) <small>www.alamy.com</small>The Auguste Rodin sculpture garden at the Iris and B. Gerald Cantor Center for Visual Arts ...

Iris &amp; B. Gerald Cantor Center For Visual Arts At Stanford University
-------------------------------------------------------------------------

 ![Iris & B. Gerald Cantor Center for Visual Arts at Stanford University](https://museum.stanford.edu/sites/default/files/styles/11_5_md/public/images/2020-07/mfh-notext-650h.png?itok=7puJGIRY) <small>museum.stanford.edu</small>Iris &amp; B. Gerald Cantor Center for Visual Arts at Stanford University

Museums Explained: Mission, Organization And Accreditation
----------------------------------------------------------

 ![Museums Explained: Mission, Organization and Accreditation](https://tfaoi.org/cm/10cm/10cm13.jpg) <small>tfaoi.org</small>Museums Explained: Mission, Organization and Accreditation

Stanford Museum, Iris And B. Gerald Cantor Center For The Visual Arts
---------------------------------------------------------------------

 ![Stanford Museum, Iris and B. Gerald Cantor Center for the Visual Arts](https://i.pinimg.com/736x/30/a7/c3/30a7c3b03ac8260cd84ca346e9d3e2d1.jpg) <small>www.pinterest.com</small>Stanford Museum, Iris and B. Gerald Cantor Center for the Visual Arts

Iris &amp; B. Gerald Cantor Center For Visual Arts | Sartle - Rogue Art History
-------------------------------------------------------------------------------

 ![Iris & B. Gerald Cantor Center for Visual Arts | Sartle - Rogue Art History](https://www.sartle.com/media/place/iris-b.-gerald-cantor-center-for-visual-arts.jpg) <small>www.sartle.com</small>Iris &amp; B. Gerald Cantor Center for Visual Arts | Sartle - Rogue Art History

The Iris And B. Gerald Cantor Center For The Visual Arts - SWA Group
--------------------------------------------------------------------

 ![The Iris and B. Gerald Cantor Center for the Visual Arts - SWA Group](https://swacdn.s3.amazonaws.com/wp-content/uploads/2019/02/19230655/Cantor-Arts-Center-at-Stanford-University-Jonnu-Singleton-4999-copy.jpg) <small>www.swagroup.com</small>The Iris and B. Gerald Cantor Center for the Visual Arts - SWA Group

Iris &amp; B. Gerald Cantor Center For Visual Arts – This Above All;
--------------------------------------------------------------------

 ![Iris & B. Gerald Cantor Center for Visual Arts – This Above All;](https://cheyennelaux.home.blog/wp-content/uploads/2019/02/fullsizeoutput_92d.jpeg) <small>cheyennelaux.home.blog</small>Iris &amp; B. Gerald Cantor Center for Visual Arts – This Above All;

Stanford Museum, Aka, Iris And B. Gerald Cantor Center For The Visual Arts | Layout Design
------------------------------------------------------------------------------------------

 ![Stanford Museum, aka, Iris and B. Gerald Cantor Center for the Visual Arts | Layout design](https://i.pinimg.com/originals/91/d2/01/91d2010b6d51f58e0e92d2c36fc44b55.jpg) <small>www.pinterest.com</small>Stanford Museum, aka, Iris and B. Gerald Cantor Center for the Visual Arts | Layout design ...

Iris &amp; B Gerald Cantor Center For Visual Arts | Iris &amp; B Ger… | Flickr
------------------------------------------------------------------------------

 ![Iris & B Gerald Cantor Center for Visual Arts | Iris & B Ger… | Flickr](https://live.staticflickr.com/65535/52488117002_622146bc03_b.jpg) <small>www.flickr.com</small>Iris &amp; B Gerald Cantor Center for Visual Arts | Iris &amp; B Ger… | Flickr

The Auguste Rodin Sculpture Garden At The Iris And B. Gerald Cantor Center For Visual Arts
------------------------------------------------------------------------------------------

 ![The Auguste Rodin sculpture garden at the Iris and B. Gerald Cantor Center for Visual Arts](https://c8.alamy.com/comp/G3HDMJ/the-auguste-rodin-sculpture-garden-at-the-iris-and-b-gerald-cantor-G3HDMJ.jpg) <small>www.alamy.com</small>The Auguste Rodin sculpture garden at the Iris and B. Gerald Cantor Center for Visual Arts ...

A Chinese Tourist Poses In Front Of The Iris &amp; B. Gerald Cantor Center For Visual Arts At
---------------------------------------------------------------------------------------------

 ![A Chinese tourist poses in front of the Iris & B. Gerald Cantor Center for Visual Arts at](https://c8.alamy.com/comp/W7M7R7/a-chinese-tourist-poses-in-front-of-the-iris-b-gerald-cantor-center-for-visual-arts-at-stanford-university-in-stanford-california-united-states-o-W7M7R7.jpg) <small>www.alamy.com</small>A Chinese tourist poses in front of the Iris &amp; B. Gerald Cantor Center for Visual Arts at ...

Iris &amp; B. Gerald Cantor Center For Visual Arts (Map, Images And Tips) | Seeker
----------------------------------------------------------------------------------

 ![Iris & B. Gerald Cantor Center for Visual Arts (Map, Images and Tips) | Seeker](https://static.seeker.io/media/img/1/c66ae06c-b01e-4c3a-a7f9-b431732d2d7e-1400.jpg) <small>seeker.io</small>Iris &amp; B. Gerald Cantor Center for Visual Arts (Map, Images and Tips) | Seeker

Iris &amp; B. Gerald Cantor Center For Visual Arts - Stanford University Museum - Museum Information
----------------------------------------------------------------------------------------------------

 ![Iris & B. Gerald Cantor Center For Visual Arts - Stanford University Museum - Museum Information](https://2.bp.blogspot.com/-5K08Yh4CUkI/Vj3CVUdh20I/AAAAAAAAA_0/ratiDIycyr4/w1280-h720-p-k-no-nu/List%2BOf%2BTop%2B10%2BUniversities%2BIn%2BThe%2BWorld%2B%257C%2BLifeStyle%2BPeople-721100.jpg) <small>museuminforme.blogspot.com</small>Iris &amp; B. Gerald Cantor Center For Visual Arts - Stanford University Museum - Museum Information ...

Global Nepali Museum - Iris &amp; B. Gerald Cantor Center For Visual Arts At Stanford University
------------------------------------------------------------------------------------------------

 ![Global Nepali Museum - Iris & B. Gerald Cantor Center for Visual Arts at Stanford University](https://globalnepalimuseum.com/wp-content/uploads/2021/05/logo-3.jpg) <small>globalnepalimuseum.com</small>Global Nepali Museum - Iris &amp; B. Gerald Cantor Center for Visual Arts at Stanford University ...

The Iris And B. Gerald Cantor Center For The Visual Arts - SWA Group
--------------------------------------------------------------------

 ![The Iris and B. Gerald Cantor Center for the Visual Arts - SWA Group](https://s3.amazonaws.com/swacdn/wp-content/uploads/2019/02/19230646/Cantor-Arts-Center-at-Stanford-University-Jonnu-Singleton-4686.jpg) <small>www.swagroup.com</small>The Iris and B. Gerald Cantor Center for the Visual Arts - SWA Group

Iris &amp; B. Gerald Cantor Center For Visual Arts In Palo Alto, CA - Virtual Globetrotting
-------------------------------------------------------------------------------------------

 ![Iris & B. Gerald Cantor Center for Visual Arts in Palo Alto, CA - Virtual Globetrotting](https://c2.vgtstatic.com/thumbll/5/7/57544-v1/iris-b-gerald-cantor-center-for-visual-arts.jpg) <small>virtualglobetrotting.com</small>Iris &amp; B. Gerald Cantor Center for Visual Arts in Palo Alto, CA - Virtual Globetrotting

Journal Of The Iris And B. Gerald Cantor Center For Visual Arts At Stanford Univeristy \[Volume 1
-------------------------------------------------------------------------------------------------

 ![Journal of the Iris and B. Gerald Cantor Center for Visual Arts at Stanford Univeristy [Volume 1](https://www.diatropebooks.com/assets/images/product/33229_1.jpg) <small>www.diatropebooks.com</small>Journal of the Iris and B. Gerald Cantor Center for Visual Arts at Stanford Univeristy \[Volume 1 ...

Iris &amp; B. Gerald Cantor Center For Visual Arts CA, Palo Alto, United States Of America - Top
------------------------------------------------------------------------------------------------

 ![Iris & B. Gerald Cantor Center for Visual Arts CA, palo alto, United States Of America - Top](https://www.hlimg.com/images/things2do/738X538/ttd_1522144671m1.jpg) <small>www.hellotravel.com</small>Iris &amp; B. Gerald Cantor Center for Visual Arts CA, palo alto, United States Of America - Top ...

The Iris And B. Gerald Cantor Center For Visual Arts, Stanford University CA Stock Photo - Alamy
------------------------------------------------------------------------------------------------

 ![The Iris and B. Gerald Cantor Center for Visual Arts, Stanford University CA Stock Photo - Alamy](https://c8.alamy.com/comp/G3HDMN/the-iris-and-b-gerald-cantor-center-for-visual-arts-stanford-university-G3HDMN.jpg) <small>www.alamy.com</small>The Iris and B. Gerald Cantor Center for Visual Arts, Stanford University CA Stock Photo - Alamy

Iris &amp; B Gerald Cantor Center For Visual Arts | Iris &amp; B Ger… | Flickr
------------------------------------------------------------------------------

 ![Iris & B Gerald Cantor Center for Visual Arts | Iris & B Ger… | Flickr](https://live.staticflickr.com/65535/52488126247_f5856fe1f8_b.jpg) <small>www.flickr.com</small>Iris &amp; B Gerald Cantor Center for Visual Arts | Iris &amp; B Ger… | Flickr

The Iris And B. Gerald Cantor Center For Visual Arts, Stanford University CA Stock Photo - Alamy
------------------------------------------------------------------------------------------------

 ![The Iris and B. Gerald Cantor Center for Visual Arts, Stanford University CA Stock Photo - Alamy](https://l450v.alamy.com/450v/g3hdmn/the-iris-and-b-gerald-cantor-center-for-visual-arts-stanford-university-g3hdmn.jpg) <small>www.alamy.com</small>The Iris and B. Gerald Cantor Center for Visual Arts, Stanford University CA Stock Photo - Alamy

Iris &amp; B. Gerald Cantor Center For Visual Arts At Stanford… | Flickr
------------------------------------------------------------------------

 ![Iris & B. Gerald Cantor Center for Visual Arts at Stanford… | Flickr](https://live.staticflickr.com/6054/6403306147_251e8e13fc_b.jpg) <small>www.flickr.com</small>Iris &amp; B. Gerald Cantor Center for Visual Arts at Stanford… | Flickr

A French Tourist Visiting The Auguste Rodin Sculpture Garden At The Iris And B. Gerald Cantor
---------------------------------------------------------------------------------------------

 ![A french tourist visiting the Auguste Rodin sculpture garden at the Iris and B. Gerald Cantor](https://c8.alamy.com/comp/2CB92CW/a-french-tourist-visiting-the-auguste-rodin-sculpture-garden-at-the-iris-and-b-gerald-cantor-center-for-visual-arts-stanford-university-ca-2CB92CW.jpg) <small>www.alamy.com</small>A french tourist visiting the Auguste Rodin sculpture garden at the Iris and B. Gerald Cantor ...

Iris &amp; B. Gerald Cantor Center For Visual Arts, September 2019 | Egecita
----------------------------------------------------------------------------

 ![Iris & B. Gerald Cantor Center for Visual Arts, September 2019 | egecita](https://egecita.com/wp-content/uploads/2021/05/IMG_4058.jpg) <small>egecita.com</small>Iris &amp; B. Gerald Cantor Center for Visual Arts, September 2019 | egecita

The Iris And B. Gerald Cantor Center For The Visual Arts - SWA Group
--------------------------------------------------------------------

 ![The Iris and B. Gerald Cantor Center for the Visual Arts - SWA Group](https://swacdn.s3.amazonaws.com/wp-content/uploads/2019/02/19230628/Cantor-Arts-Center-at-Stanford-University-Jonnu-Singleton-3843.jpg) <small>www.swagroup.com</small>The Iris and B. Gerald Cantor Center for the Visual Arts - SWA Group

Center For Visual Arts High Resolution Stock Photography And Images - Alamy
---------------------------------------------------------------------------

 ![Center for visual arts High Resolution Stock Photography and Images - Alamy](https://c8.alamy.com/comp/G3HB94/the-iris-and-b-gerald-cantor-center-for-visual-arts-stanford-university-ca-G3HB94.jpg) <small>www.alamy.com</small>Center for visual arts High Resolution Stock Photography and Images - Alamy

The Iris And B. Gerald Cantor Center For The Visual Arts - SWA Group
--------------------------------------------------------------------

 ![The Iris and B. Gerald Cantor Center for the Visual Arts - SWA Group](https://swacdn.s3.amazonaws.com/wp-content/uploads/2019/02/19230558/Cantor-Arts-Center-at-Stanford-University-Jonnu-Singleton-2-26.jpg) <small>www.swagroup.com</small>The Iris and B. Gerald Cantor Center for the Visual Arts - SWA Group

Cantor Museum Hi-res Stock Photography And Images - Alamy
---------------------------------------------------------

 ![Cantor museum hi-res stock photography and images - Alamy](https://c8.alamy.com/comp/F1YF79/iris-b-gerald-cantor-center-for-visual-arts-stanford-university-F1YF79.jpg) <small>www.alamy.com</small>Cantor museum hi-res stock photography and images - Alamy

Iris &amp; B. Gerald Cantor Center For Visual Arts, September 2019 | Egecita
----------------------------------------------------------------------------

 ![Iris & B. Gerald Cantor Center for Visual Arts, September 2019 | egecita](https://i0.wp.com/egecita.com/wp-content/uploads/2021/05/IMG_4063.jpg?fit=1200%2C900&ssl=1) <small>egecita.com</small>Iris &amp; B. Gerald Cantor Center for Visual Arts, September 2019 | egecita

Iris &amp; B. Gerald Cantor Center For Visual Arts - 328 Lomita Dr
------------------------------------------------------------------

 ![Iris & B. Gerald Cantor Center for Visual Arts - 328 Lomita Dr](https://fastly.4sqi.net/img/general/600x600/M54vfuUdLPUCgwCujO1MFHPBS5acyNuvWeCZfH3EhTU.jpg) <small>foursquare.com</small>Iris &amp; B. Gerald Cantor Center for Visual Arts - 328 Lomita Dr

Photo : Musée Iris &amp; B. Gerald Cantor Center For Visual Arts, Université De Stanford, Palo Alto
---------------------------------------------------------------------------------------------------

 ![Photo : Musée Iris & B. Gerald Cantor Center for Visual Arts, Université de Stanford, Palo Alto](https://www.photo-alsace.com/2_photo/usa_2/img_1/220323-043.jpg) <small>www.photo-alsace.com</small>Photo : Musée Iris &amp; B. Gerald Cantor Center for Visual Arts, Université de Stanford, Palo Alto ...

איריס וג'רלד קנטור - המרכז לאמנות חזותית (Iris &amp; B. Gerald Cantor Center For Visual Arts) בפאלו
---------------------------------------------------------------------------------------------------

 ![איריס וג'רלד קנטור - המרכז לאמנות חזותית (Iris & B. Gerald Cantor Center for Visual Arts) בפאלו](https://www.lametayel.co.il/limages/6b4b9d16dee88ee79428bf5b2194b79c.JPG?type=r&size=0x540) <small>www.lametayel.co.il</small>איריס וג'רלד קנטור - המרכז לאמנות חזותית (Iris &amp; B. Gerald Cantor Center for Visual Arts) בפאלו ...

The auguste rodin sculpture garden at the iris and b. gerald cantor center for visual arts. The iris and b. gerald cantor center for the visual arts. center for visual arts high resolution stock photography and images
