---
title: "Greve Geral 2 Outubro - Greve geral paralisa portugal contra precarização de direitos"
description: "Dias 2 e 3 de outubro é greve geral da educação"
date: "2026-11-12"
categories:
- "Uncategorized"
images:
- "https://www.spra.pt/wp-content/uploads/2023/10/cartaz-greve-fc-27-outubro-net-1-704x1024.jpg"
featuredImage: "https://cdn.sortiraparis.com/images/1002/1467/1197264-greve-du-2-octobre-transports-ratp-et-sncf.jpg"
featured_image: "https://fernandapsol.com.br/wp-content/uploads/2019/10/WhatsApp-Image-2019-10-01-at-15.57.30.jpeg"
image: "https://www.cgtp.pt/images/images/2026/06/tiago-greve-geral.jpg"
---

If you are searching about Pré-avisos de Greves de 2 e 3 de março 2023 you've visit to the right place. We have 35 Pics about Pré-avisos de Greves de 2 e 3 de março 2023 like Greve geral da Pós: veja a programação. - ANPG, Grève du 2 octobre : transports, écoles, hôpitaux… A quelles perturbations s’attendre and also Greve Geral de 48 horas da Educação – 2 e 3 de outubro – Assufba. Read more:

Pré-avisos De Greves De 2 E 3 De Março 2023
-------------------------------------------

 ![Pré-avisos de Greves de 2 e 3 de março 2023](https://fne.pt/uploads/rte/cartaz_greve_manif_2e3marco2023.jpeg) <small>fne.pt</small>Pré-avisos de Greves de 2 e 3 de março 2023

Greve Geral Contra Cortes Propostos Nas Despesas Públicas Continua A Provocar Perturbações Nas
----------------------------------------------------------------------------------------------

 ![Greve geral contra cortes propostos nas despesas públicas continua a provocar perturbações nas](https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA1OrEdY.img?w=768&h=512&m=6) <small>www.msn.com</small>Greve geral contra cortes propostos nas despesas públicas continua a provocar perturbações nas ...

CUT Mantém A Construção Da Greve Geral - SINDPD-PE
--------------------------------------------------

 ![CUT mantém a construção da Greve Geral - SINDPD-PE](https://sindpdpe.org.br/wp-content/uploads/2016/10/sindpd-20161025_cut-mantem-a-construcao.jpeg) <small>sindpdpe.org.br</small>CUT mantém a construção da Greve Geral - SINDPD-PE

Em Dia De Greve Geral, Ato Em São Sebastião Reúne Mais De 200 Pessoas No Tebar | SindiPetro-LP
----------------------------------------------------------------------------------------------

 ![Em dia de greve geral, ato em São Sebastião reúne mais de 200 pessoas no Tebar | SindiPetro-LP](https://sindipetrolp.org.br/admin/arquivo/noticias/d2f68e48d187ae9262b2.jpg) <small>www.sindipetrolp.org.br</small>Em dia de greve geral, ato em São Sebastião reúne mais de 200 pessoas no Tebar | SindiPetro-LP

O Que Se Pode Esperar Da Greve Dos Aeroportos A 2 De Outubro? - Sortiraparis.com
--------------------------------------------------------------------------------

 ![O que se pode esperar da greve dos aeroportos a 2 de outubro? - Sortiraparis.com](https://cdn.sortiraparis.com/images/80/1467/1199522-greve-dans-les-aeroports-ce-2-octobre-a-quoi-s-attendre.jpg) <small>www.sortiraparis.com</small>O que se pode esperar da greve dos aeroportos a 2 de outubro? - Sortiraparis.com

Setor Das Ifes Indica Greve Da Educação Federal Nos Dias 2 E 3 De Outubro – ADUFPB
----------------------------------------------------------------------------------

 ![Setor das Ifes indica greve da Educação Federal nos dias 2 e 3 de outubro – ADUFPB](https://www.adufpb.org.br/site/wp-content/uploads/2019/09/greve-nacionao-2-e-3-out-01.jpg) <small>www.adufpb.org.br</small>Setor das Ifes indica greve da Educação Federal nos dias 2 e 3 de outubro – ADUFPB

Pré-avisos Para Greve Na Função Pública (e Não Só) Esta 6ª
----------------------------------------------------------

 ![Pré-avisos para greve na Função Pública (e não só) esta 6ª](https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA1ZfPnB.img?w=768&h=512&m=6) <small>www.msn.com</small>Pré-avisos para greve na Função Pública (e não só) esta 6ª

Metro Do Porto "fortemente Condicionado" No Dia Da Greve Geral - JPN
--------------------------------------------------------------------

 ![Metro do Porto "fortemente condicionado" no dia da greve geral - JPN](https://www.jpn.up.pt/wp-content/uploads/2025/12/greve_geral1-1152x759.jpg) <small>www.jpn.up.pt</small>Metro do Porto "fortemente condicionado" no dia da greve geral - JPN

SINDEP - Greve Geral 11 De Dezembro
-----------------------------------

 ![SINDEP - Greve Geral 11 de dezembro](https://sindep.pt/images/cartaz_GREVE_GERAL_UGT.jpg) <small>sindep.pt</small>SINDEP - Greve Geral 11 de dezembro

Dados Recolhidos Até às 19h20 Demonstram Que A Greve Geral Parou O País - CGTP-IN
---------------------------------------------------------------------------------

 ![Dados recolhidos até às 19h20 demonstram que a Greve Geral parou o país - CGTP-IN](https://www.cgtp.pt/images/images/2025/11/gg_banner2025.jpg) <small>www.cgtp.pt</small>Dados recolhidos até às 19h20 demonstram que a Greve Geral parou o país - CGTP-IN

Greve Geral Da Pós: Veja A Programação. - ANPG
----------------------------------------------

 ![Greve geral da Pós: veja a programação. - ANPG](https://www.anpg.org.br/wp-content/uploads/2019/09/greve-geral-2site2.png) <small>www.anpg.org.br</small>Greve geral da Pós: veja a programação. - ANPG

Dias 2 E 3 De Outubro é Greve Geral Da Educação | Fernanda Melchionna
---------------------------------------------------------------------

 ![Dias 2 e 3 de outubro é greve geral da educação | Fernanda Melchionna](https://fernandapsol.com.br/wp-content/uploads/2019/10/WhatsApp-Image-2019-10-01-at-15.57.30.jpeg) <small>fernandapsol.com.br</small>Dias 2 e 3 de outubro é greve geral da educação | Fernanda Melchionna

Greve De 2 De Outubro: O Que Esperar Do Novo Dia De Protesto Em França?
-----------------------------------------------------------------------

 ![Greve de 2 de outubro: o que esperar do novo dia de protesto em França?](https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA1NGuTP.img?w=800&h=450&m=4&q=79) <small>www.msn.com</small>Greve de 2 de outubro: o que esperar do novo dia de protesto em França?

Motivos Da Adesão à Greve Geral De 11 De Dezembro De 2025
---------------------------------------------------------

 ![Motivos da adesão à Greve Geral de 11 de dezembro de 2025](https://spzn.pt/uploads/noticias/big_1763717239_6728_SPZN_2025_site_novo_(17).png) <small>spzn.pt</small>Motivos da adesão à Greve Geral de 11 de dezembro de 2025

Greve De 2 De Outubro De 2025: Perturbações Na RATP E Na SNCF Em Paris E Na Região De Île-de
--------------------------------------------------------------------------------------------

 ![Greve de 2 de outubro de 2025: perturbações na RATP e na SNCF em Paris e na região de Île-de](https://cdn.sortiraparis.com/images/1002/1467/1197264-greve-du-2-octobre-transports-ratp-et-sncf.jpg) <small>www.sortiraparis.com</small>Greve de 2 de outubro de 2025: perturbações na RATP e na SNCF em Paris e na região de Île-de ...

Greve Geral Paralisa A Grécia Contra Projeto Que Amplia Jornada Diária De Trabalho Para 13 Horas
------------------------------------------------------------------------------------------------

 ![Greve geral paralisa a Grécia contra projeto que amplia jornada diária de trabalho para 13 horas](https://p2.trrsf.com/image/fget/cf/774/0/images.terra.com/2025/10/01/255139162-ap25274355543412.jpg) <small>www.terra.com.br</small>Greve geral paralisa a Grécia contra projeto que amplia jornada diária de trabalho para 13 horas

Imprensa Internacional Destaca Brasil; BBC Vê 1ª Greve Geral Em Mais De 2 Décadas - Pequenas
--------------------------------------------------------------------------------------------

 ![Imprensa internacional destaca Brasil; BBC vê 1ª greve geral em mais de 2 décadas - Pequenas](https://s2.glbimg.com/ZUv7xxUmP55dYzk4H9ue63xjTm0=/940x523/e.glbimg.com/og/ed/f/original/2017/04/28/33337301181_5a55568819_k.jpg) <small>revistapegn.globo.com</small>Imprensa internacional destaca Brasil; BBC vê 1ª greve geral em mais de 2 décadas - Pequenas ...

Nouvelle Grève Du 2 Octobre : Voici Ce Qui Vous Attend
------------------------------------------------------

 ![Nouvelle grève du 2 octobre : voici ce qui vous attend](https://www.maison-travaux.fr/wp-content/uploads/sites/8/2025/09/greve-2-octobre.jpg) <small>www.maison-travaux.fr</small>Nouvelle grève du 2 octobre : voici ce qui vous attend

Greve Geral Juntou Centenas Nos Aliados. Governo Fala Em Adesão "inexpressiva" - JPN
------------------------------------------------------------------------------------

 ![Greve Geral juntou centenas nos Aliados. Governo fala em adesão "inexpressiva" - JPN](https://www.jpn.up.pt/wp-content/uploads/2025/12/greve_geral9.jpg) <small>www.jpn.up.pt</small>Greve Geral juntou centenas nos Aliados. Governo fala em adesão "inexpressiva" - JPN

Greve Geral Paralisa Portugal Contra Precarização De Direitos
-------------------------------------------------------------

 ![Greve geral paralisa Portugal contra precarização de direitos](https://pcdob.org.br/wp-content/uploads/2025/12/Ruas-de-Lisboa-foram-tomadas-por-trabalhadores-durante-a-greve-geral-Rafael-Medeiros-Esquerda.jpg) <small>pcdob.org.br</small>Greve geral paralisa Portugal contra precarização de direitos

GREVE GERAL - 3 JUNHO 2026 | Resolução - CGTP-IN
------------------------------------------------

 ![GREVE GERAL - 3 JUNHO 2026 | Resolução - CGTP-IN](https://www.cgtp.pt/images/images/2026/06/tiago-greve-geral.jpg) <small>www.cgtp.pt</small>GREVE GERAL - 3 JUNHO 2026 | Resolução - CGTP-IN

GREVE - 2 De Novembro De 2022 - Por Um ORÇAMENTO DE ESTADO Que Valorize Educadores E Professores
------------------------------------------------------------------------------------------------

 ![GREVE - 2 de novembro de 2022 - Por um ORÇAMENTO DE ESTADO que valorize Educadores e Professores](https://www.sdpa.pt/uploads/greve_2_novembro.jpg) <small>www.sdpa.pt</small>GREVE - 2 de novembro de 2022 - Por um ORÇAMENTO DE ESTADO que valorize Educadores e Professores ...

Greve Geral Deve Parar A França Nesta Terça; Trabalhadores Querem Reajuste Por Inflação | Mundo | G1
----------------------------------------------------------------------------------------------------

 ![Greve geral deve parar a França nesta terça; trabalhadores querem reajuste por inflação | Mundo | G1](https://s2.glbimg.com/dHKLMDY5Euu5sDqMO5OmPBjTBQ4=/1200x/smart/filters:cover():strip_icc()/i.s3.glbimg.com/v1/AUTH_59edd422c0c84a879bd37670ae4f538a/internal_photos/bs/2022/G/h/Z2ahq8R3ixaACR4a87eQ/protesto-paris.jpg) <small>g1.globo.com</small>Greve geral deve parar a França nesta terça; trabalhadores querem reajuste por inflação | Mundo | G1

Greve Nacional De 2 De Dezembro: Transportes, Escolas, Aeroportos... As Informações
-----------------------------------------------------------------------------------

 ![Greve nacional de 2 de dezembro: transportes, escolas, aeroportos... as informações](https://cdn.sortiraparis.com/images/80/1467/1199124-greve-du-2-octobre-les-manifestations-prevues-a-paris-et-en-ile-de-france.jpg) <small>www.sortiraparis.com</small>Greve nacional de 2 de dezembro: transportes, escolas, aeroportos... as informações ...

Manifestantes Convocam Greve-geral Para 2ª E Pedem Adesão De Empresários
------------------------------------------------------------------------

 ![Manifestantes convocam greve-geral para 2ª e pedem adesão de empresários](https://www.otempo.com.br/content/dam/otempo/editorias/eleicoes/2022/11/eleicoes-greve-geral-bolsonarro-belo-horizonte-1708430585.jpeg) <small>www.otempo.com.br</small>Manifestantes convocam greve-geral para 2ª e pedem adesão de empresários

Greve Geral Juntou Centenas Nos Aliados. Governo Fala Em Adesão "inexpressiva" - JPN
------------------------------------------------------------------------------------

 ![Greve Geral juntou centenas nos Aliados. Governo fala em adesão "inexpressiva" - JPN](https://www.jpn.up.pt/wp-content/uploads/2025/12/greve_geral8.jpg) <small>www.jpn.up.pt</small>Greve Geral juntou centenas nos Aliados. Governo fala em adesão "inexpressiva" - JPN

SPGL - Greve Geral Da Administração Pública | 24 De Outubro 2025
----------------------------------------------------------------

 ![SPGL - Greve Geral da Administração Pública | 24 de outubro 2025](https://www.spgl.pt/Media/Default/_Profiles/3675b73a/58a5481d/Cartaz 24 Out_FENPROF_page-0001.jpg?v=638956052779715690) <small>www.spgl.pt</small>SPGL - Greve Geral da Administração Pública | 24 de outubro 2025

Manifestação Em Frente Ao Parlamento Resultou Em Seis Detidos: Tudo Sobre A Greve Geral
---------------------------------------------------------------------------------------

 ![Manifestação em frente ao Parlamento resultou em seis detidos: tudo sobre a greve geral](https://cdn.sabado.pt/images/2025-12/img_1320x743uu2025-12-11-10-18-26-752781.jpg) <small>www.sabado.pt</small>Manifestação em frente ao Parlamento resultou em seis detidos: tudo sobre a greve geral ...

Greve Geral De 48 Horas Da Educação – 2 E 3 De Outubro – Assufba
----------------------------------------------------------------

 ![Greve Geral de 48 horas da Educação – 2 e 3 de outubro – Assufba](https://www.assufba.org.br/novo/wp-content/uploads/2019/10/IMG_7959.jpg) <small>www.assufba.org.br</small>Greve Geral de 48 horas da Educação – 2 e 3 de outubro – Assufba

SPN - 27 De Outubro De 2017 - Greve Por Um Descongelamento Justo E Sem Discriminação
------------------------------------------------------------------------------------

 ![SPN - 27 de outubro de 2017 - Greve por um descongelamento justo e sem discriminação](https://www.spn.pt/Media/Default/Info/18000/600/20/2/cartaz-GREVE_Norte.jpg) <small>www.spn.pt</small>SPN - 27 de outubro de 2017 - Greve por um descongelamento justo e sem discriminação

FENPROF Emite Pré-aviso De Greve Para 27 De Outubro De 2023 E Junta-se Ao Protesto Dos
--------------------------------------------------------------------------------------

 ![FENPROF emite pré-aviso de greve para 27 de outubro de 2023 e junta-se ao protesto dos](https://www.spra.pt/wp-content/uploads/2023/10/cartaz-greve-fc-27-outubro-net-1-704x1024.jpg) <small>www.spra.pt</small>FENPROF emite pré-aviso de greve para 27 de outubro de 2023 e junta-se ao protesto dos ...

Pré-Aviso De Greve – 17 De Abril De 2026 – AE António Correia De Oliveira
-------------------------------------------------------------------------

 ![Pré-Aviso de Greve – 17 de abril de 2026 – AE António Correia de Oliveira](https://www.acoliveira.pt/wp-content/uploads/2026/04/7e9f6ec4-4873-4685-897b-30c62aab02d6.png) <small>www.acoliveira.pt</small>Pré-Aviso de Greve – 17 de abril de 2026 – AE António Correia de Oliveira

Grève Du 2 Octobre : Transports, écoles, Hôpitaux… A Quelles Perturbations S’attendre
-------------------------------------------------------------------------------------

 ![Grève du 2 octobre : transports, écoles, hôpitaux… A quelles perturbations s’attendre](https://www.publicsenat.fr/app/uploads/2025/09/Greve-2-octobre-scaled.jpg) <small>www.publicsenat.fr</small>Grève du 2 octobre : transports, écoles, hôpitaux… A quelles perturbations s’attendre

27 De Outubro - Greve Nacional Da Administração Pública - CGTP-IN
-----------------------------------------------------------------

 ![27 de Outubro - Greve Nacional da Administração Pública - CGTP-IN](https://www.cgtp.pt/images/images/2017/10/171003_GreveFCcartazB.jpg) <small>www.cgtp.pt</small>27 de Outubro - Greve Nacional da Administração Pública - CGTP-IN

Diário Da Greve Geral - CGTP-IN
-------------------------------

 ![Diário da Greve Geral - CGTP-IN](https://www.cgtp.pt/images/images/2025/12/diario_gg/diario-banner.jpg) <small>www.cgtp.pt</small>Diário da Greve Geral - CGTP-IN

Manifestantes convocam greve-geral para 2ª e pedem adesão de empresários. Pré-avisos para greve na função pública (e não só) esta 6ª. greve geral da pós: veja a programação.
