---
title: "Kimberly Powell Tampa - About us"
description: "About us"
date: "2026-10-05"
categories:
- "Uncategorized"
images:
- "https://www.amgen.com/stories/2024/05/-/media/Themes/CorporateAffairs/amgen-com/amgen-com/Images/stories/2024/05-21-From-the-Office-to-the-Lab-Amgen-Uses-AI-Tools-to-Unlock-Innovation/powell.png"
featuredImage: "https://media.licdn.com/dms/image/v2/D5622AQG_Iha5ZShNxQ/feedshare-shrink_2048_1536/feedshare-shrink_2048_1536/0/1689354648155?e=2147483647&amp;v=beta&amp;t=tO0eWpxk-SFUhmapMMCOBpe5SUV4oVhyiIhxUpW5z_k"
featured_image: "https://media.licdn.com/dms/image/C4D03AQEM8l-ceokP0g/profile-displayphoto-shrink_800_800/0/1625234024608?e=2147483647&amp;v=beta&amp;t=yuTwtwzeWsuqXRr60NCGM4C3AmKB_OuM8b1Bwo7Epkk"
image: "https://media.licdn.com/dms/image/D5622AQHpO63Gdvh9pA/feedshare-shrink_2048_1536/0/1686869396106?e=2147483647&amp;v=beta&amp;t=br0qoF38jSsM6UDaZFY07EPc3IwdUveCofo65zD08K8"
---

If you are looking for Welcome to the team Kimberly Powell ! | Kelvin Kam you've came to the right page. We have 35 Images about Welcome to the team Kimberly Powell ! | Kelvin Kam like Kimberly Powell - Office Manager at Florida Medical Clinic/ Rheumatology | LinkedIn, Kimberly Powell on LinkedIn: Had a fantastic time hosting the PowerUp Strategic Educators and also Kimberly Powell's Instagram, Twitter &amp; Facebook on IDCrawl. Here you go:

Welcome To The Team Kimberly Powell ! | Kelvin Kam
--------------------------------------------------

 ![Welcome to the team Kimberly Powell ! | Kelvin Kam](https://media.licdn.com/dms/image/v2/D5622AQFyslA_bU6SmQ/feedshare-shrink_2048_1536/feedshare-shrink_2048_1536/0/1701478818727?e=2147483647&v=beta&t=DJkohkKyaZ_7xCO8qbg4sbuEXtvwp1Ue88oRp9zZehw) <small>www.linkedin.com</small>Welcome to the team Kimberly Powell ! | Kelvin Kam

Kimberly Powell - Office Manager At Florida Medical Clinic/ Rheumatology | LinkedIn
-----------------------------------------------------------------------------------

 ![Kimberly Powell - Office Manager at Florida Medical Clinic/ Rheumatology | LinkedIn](https://media.licdn.com/dms/image/v2/C4E03AQFmRkmHfLZSDg/profile-displayphoto-shrink_200_200/profile-displayphoto-shrink_200_200/0/1579796088265?e=2147483647&v=beta&t=-yw1wY_J7G-nTQcrUsQKbUO2lInaKSPCDo4mIBA0U_U) <small>www.linkedin.com</small>Kimberly Powell - Office Manager at Florida Medical Clinic/ Rheumatology | LinkedIn

Exclusive Interview With Kimberly Powell, VP And General Manager Of NVIDIA Healthcare - MarkTechPost
----------------------------------------------------------------------------------------------------

 ![Exclusive Interview with Kimberly Powell, VP and General Manager of NVIDIA Healthcare - MarkTechPost](https://www.marktechpost.com/wp-content/uploads/2022/04/Interview-2.png) <small>www.marktechpost.com</small>Exclusive Interview with Kimberly Powell, VP and General Manager of NVIDIA Healthcare - MarkTechPost

Dive Into The Future Of Digital Surgery, Health, And Biology With NVIDIA's VP Of Healthcare And
-----------------------------------------------------------------------------------------------

 ![Dive into the future of digital surgery, health, and biology with NVIDIA's VP of Healthcare and](https://media.licdn.com/dms/image/v2/D5610AQEf18m9u13NPw/image-shrink_800/image-shrink_800/0/1718404075786?e=2147483647&v=beta&t=F-wL667A6hY7CE4c0fp8ufvPB6vLFAUNhCatqrC7jY4) <small>www.linkedin.com</small>Dive into the future of digital surgery, health, and biology with NVIDIA's VP of Healthcare and ...

Kimberly Powell - Senior Customer Service Representative | LinkedIn
-------------------------------------------------------------------

 ![Kimberly Powell - Senior Customer Service Representative | LinkedIn](https://media.licdn.com/dms/image/v2/D4E03AQGhWK_YSc-Ftw/profile-displayphoto-shrink_200_200/profile-displayphoto-shrink_200_200/0/1689623070435?e=2147483647&v=beta&t=MNiZ7U0T1dKhitIvPNTkk2U8ymA9xqwSwsFPo2BPmio) <small>www.linkedin.com</small>Kimberly Powell - Senior Customer Service Representative | LinkedIn

Kimberly Powell - At | LinkedIn
-------------------------------

 ![Kimberly Powell - at | LinkedIn](https://media.licdn.com/dms/image/v2/C4E03AQEGJk--BTydNw/profile-displayphoto-shrink_200_200/profile-displayphoto-shrink_200_200/0/1516849136673?e=2147483647&v=beta&t=eSvvy8LcE7y1pXitI4462Hh6HI-1SU2m37-7VI6r4Ek) <small>www.linkedin.com</small>Kimberly Powell - at | LinkedIn

Kimberly Powell On LinkedIn: #womenwholead #mentorship #success #thepurpledoorwellnesshouse…
--------------------------------------------------------------------------------------------

 ![Kimberly Powell on LinkedIn: #womenwholead #mentorship #success #thepurpledoorwellnesshouse…](https://media.licdn.com/dms/image/D4E22AQFEXBAgYvTBYg/feedshare-shrink_2048_1536/0/1716164335026?e=2147483647&v=beta&t=wOCsAhyrEMQHVUnhTT1IhqfJ_a6E7rx2TyyA5C6T2nQ) <small>www.linkedin.com</small>Kimberly Powell on LinkedIn: #womenwholead #mentorship #success #thepurpledoorwellnesshouse…

Kimberly Powell - SR Partner Technical Advisor | LinkedIn
---------------------------------------------------------

 ![Kimberly Powell - SR Partner Technical Advisor | LinkedIn](https://media.licdn.com/dms/image/v2/D5603AQGY1P7BMa4UrA/profile-displayphoto-shrink_200_200/profile-displayphoto-shrink_200_200/0/1709256150173?e=2147483647&v=beta&t=Sr6TwAk9jjQSdKtZX537kaHgDevPQ700DsIYeMP3l0Q) <small>www.linkedin.com</small>Kimberly Powell - SR Partner Technical Advisor | LinkedIn

About Us
--------

 ![About Us](https://img1.wsimg.com/isteam/ip/44d8c6eb-5847-48e2-aff5-373d62931250/blob.png/:/cr=t:0%25,l:0%25,w:100%25,h:67.46%25/rs=w:365,h:365,cg:true) <small>757wecare.org</small>About Us

Kimberly Powell On LinkedIn: #speakupsisawards2024 #susawards2024 #susawardsfinalist2024 #voteforme
---------------------------------------------------------------------------------------------------

 ![Kimberly Powell on LinkedIn: #speakupsisawards2024 #susawards2024 #susawardsfinalist2024 #voteforme](https://media.licdn.com/dms/image/D4D22AQHnpcTAQwDtzg/feedshare-shrink_2048_1536/0/1710527087105?e=2147483647&v=beta&t=ABcsxN8h4u0sB8mJDrZKm9poz4E6UKa_kzE8Y0XAmbE) <small>www.linkedin.com</small>Kimberly Powell on LinkedIn: #speakupsisawards2024 #susawards2024 #susawardsfinalist2024 #voteforme

Kimberly Powell - Federal Cybersecurity Analyst | | Security Architecture Enterprise
------------------------------------------------------------------------------------

 ![Kimberly Powell - Federal Cybersecurity Analyst | | Security Architecture Enterprise](https://media.licdn.com/dms/image/v2/D4E03AQHf6Yx1tOaXCQ/profile-displayphoto-scale_200_200/B4EZvjsxCZJAAY-/0/1769051722281?e=2147483647&v=beta&t=UOjMcwZafuKlXgdI61I0hti_3ZXbs2LOpiufYIR0ZWk) <small>www.linkedin.com</small>Kimberly Powell - Federal Cybersecurity Analyst | | Security Architecture Enterprise ...

Kimberly Powell - Account Manager IV At Dell Technologies | LinkedIn
--------------------------------------------------------------------

 ![Kimberly Powell - Account Manager IV at Dell Technologies | LinkedIn](https://media.licdn.com/dms/image/v2/D5603AQFaZX-TikH51A/profile-displayphoto-shrink_200_200/profile-displayphoto-shrink_200_200/0/1695195797796?e=2147483647&v=beta&t=WKXeR24Fo4zMw6-s5CeH0hkX17k2v_-_AOl4fXFvBE8) <small>www.linkedin.com</small>Kimberly Powell - Account Manager IV at Dell Technologies | LinkedIn

Generative AI Is Revolutionizing Healthcare, From Drug Discovery To Diagnostics And Post-op Care
------------------------------------------------------------------------------------------------

 ![Generative AI is revolutionizing healthcare, from drug discovery to diagnostics and post-op care](https://media.licdn.com/dms/image/v2/D4D22AQHI7fbK1GV1QQ/feedshare-shrink_2048_1536/feedshare-shrink_2048_1536/0/1717762363344?e=2147483647&v=beta&t=HcXrmL3078ePC82LlnhipxGpfpS2lI088q7m0yCHQ0I) <small>pe.linkedin.com</small>Generative AI is revolutionizing healthcare, from drug discovery to diagnostics and post-op care ...

Kimberly Powell On LinkedIn: I Am Honored To Have Been Nominated And Awarded The BAM WW - Gerald
------------------------------------------------------------------------------------------------

 ![Kimberly Powell on LinkedIn: I am honored to have been nominated and awarded the BAM WW - Gerald](https://media.licdn.com/dms/image/D5622AQHpO63Gdvh9pA/feedshare-shrink_2048_1536/0/1686869396106?e=2147483647&v=beta&t=br0qoF38jSsM6UDaZFY07EPc3IwdUveCofo65zD08K8) <small>www.linkedin.com</small>Kimberly Powell on LinkedIn: I am honored to have been nominated and awarded the BAM WW - Gerald ...

Kimberly Powell - -- | LinkedIn
-------------------------------

 ![Kimberly Powell - -- | LinkedIn](https://media.licdn.com/dms/image/v2/C4E03AQEiPzc9g-MIsg/profile-displayphoto-shrink_200_200/profile-displayphoto-shrink_200_200/0/1564583183146?e=2147483647&v=beta&t=HMe3m5s-OgxM7MMBUHz3o2LLzmNf2CvKx3IAW8Y3qKg) <small>www.linkedin.com</small>Kimberly Powell - -- | LinkedIn

Kimberly Powell - Ameriprise Financial Services, LLC | LinkedIn
---------------------------------------------------------------

 ![Kimberly Powell - Ameriprise Financial Services, LLC | LinkedIn](https://media.licdn.com/dms/image/v2/D5603AQGczgPZHL-qRw/profile-displayphoto-shrink_200_200/profile-displayphoto-shrink_200_200/0/1694200867578?e=2147483647&v=beta&t=kg582iE3LiLZhrClX5KIfmnqUUFyag9x8hYXM9xPD7U) <small>www.linkedin.com</small>Kimberly Powell - Ameriprise Financial Services, LLC | LinkedIn

\#locinternships #libraryofcongress | Kimberly Powell, MBA, PMP
---------------------------------------------------------------

 ![#locinternships #libraryofcongress | Kimberly Powell, MBA, PMP](https://media.licdn.com/dms/image/v2/D5622AQH-9yhDoWzSRg/feedshare-shrink_800/feedshare-shrink_800/0/1691613719431?e=2147483647&v=beta&t=V6h7FJjIMWbICbGHmyK-sIZnB8eFpxVdqNLLvCQujok) <small>www.linkedin.com</small>\#locinternships #libraryofcongress | Kimberly Powell, MBA, PMP

What Can Health Care Learn From Self-Driving Cars? | Johns Hopkins Medicine
---------------------------------------------------------------------------

 ![What Can Health Care Learn from Self-Driving Cars? | Johns Hopkins Medicine](https://www.hopkinsmedicine.org/-/media/images/articles/2018/03/kimberly_powell.jpeg?h=640&iar=0&w=640&hash=1741F5E78A512573722D6BEAB32D9288) <small>www.hopkinsmedicine.org</small>What Can Health Care Learn from Self-Driving Cars? | Johns Hopkins Medicine

From The Office To The Lab, Amgen Uses AI Tools To Unlock Innovation | Amgen
----------------------------------------------------------------------------

 ![From the Office to the Lab, Amgen Uses AI Tools to Unlock Innovation | Amgen](https://www.amgen.com/stories/2024/05/-/media/Themes/CorporateAffairs/amgen-com/amgen-com/Images/stories/2024/05-21-From-the-Office-to-the-Lab-Amgen-Uses-AI-Tools-to-Unlock-Innovation/powell.png) <small>www.amgen.com</small>From the Office to the Lab, Amgen Uses AI Tools to Unlock Innovation | Amgen

Kimberly Powell Honored For Pioneering Work In Health Informatics And Gerontology
---------------------------------------------------------------------------------

 ![Kimberly Powell honored for pioneering work in health informatics and gerontology](https://nursing.missouri.edu/wp-content/uploads/2024/06/Kimberly-Powell-FAMIA-induction-1024x1024.png) <small>nursing.missouri.edu</small>Kimberly Powell honored for pioneering work in health informatics and gerontology

Kimberly Powell - PhD, RN, FAMIA, FAAN | LinkedIn
-------------------------------------------------

 ![Kimberly Powell - PhD, RN, FAMIA, FAAN | LinkedIn](https://media.licdn.com/dms/image/v2/D4E03AQELNZTNqlomtw/profile-displayphoto-scale_200_200/B4EZiemXJLHoAY-/0/1755007513927?e=2147483647&v=beta&t=9aVHNfS1ADg7fyk_hbUBaCziZDNeQpkjMX0xwrnhkTQ) <small>www.linkedin.com</small>Kimberly Powell - PhD, RN, FAMIA, FAAN | LinkedIn

20 People To Know In Banking: Kimberly Powell, Huntington National Bank - Pittsburgh Business Times
---------------------------------------------------------------------------------------------------

 ![20 People to Know in Banking: Kimberly Powell, Huntington National Bank - Pittsburgh Business Times](https://media.bizj.us/view/img/12644095/powellkimhuntington*1200xx4046-2282-0-1248.jpg) <small>www.bizjournals.com</small>20 People to Know in Banking: Kimberly Powell, Huntington National Bank - Pittsburgh Business Times

Nvidia's Kimberly Powell Is Leading The Chip Giant's Charge Into AI For Health Care - San
-----------------------------------------------------------------------------------------

 ![Nvidia's Kimberly Powell is leading the chip giant's charge into AI for health care - San](https://media.bizj.us/view/img/12968502/kimberlypowell-1*1200xx9428-5303-0-491.jpg) <small>www.bizjournals.com</small>Nvidia's Kimberly Powell is leading the chip giant's charge into AI for health care - San ...

We're Here! The Indiana Black Expo! Hall H, Booth 1447! Come Visit Us! | Kimberly Powell
----------------------------------------------------------------------------------------

 ![We're here! The Indiana Black Expo! Hall H, booth 1447! Come visit us! | Kimberly Powell](https://media.licdn.com/dms/image/v2/D5622AQG_Iha5ZShNxQ/feedshare-shrink_2048_1536/feedshare-shrink_2048_1536/0/1689354648155?e=2147483647&v=beta&t=tO0eWpxk-SFUhmapMMCOBpe5SUV4oVhyiIhxUpW5z_k) <small>www.linkedin.com</small>We're here! The Indiana Black Expo! Hall H, booth 1447! Come visit us! | Kimberly Powell

Kimberly Powell's Instagram, Twitter &amp; Facebook On IDCrawl
--------------------------------------------------------------

 ![Kimberly Powell's Instagram, Twitter & Facebook on IDCrawl](https://girlgeek.io/wp-content/uploads/2018/10/kimberly-powell.jpg) <small>www.idcrawl.com</small>Kimberly Powell's Instagram, Twitter &amp; Facebook on IDCrawl

Kimberly Powell On LinkedIn: Had A Fantastic Time Hosting The PowerUp Strategic Educators
-----------------------------------------------------------------------------------------

 ![Kimberly Powell on LinkedIn: Had a fantastic time hosting the PowerUp Strategic Educators](https://media.licdn.com/dms/image/D5622AQEBItJYa-ypGw/feedshare-shrink_800/0/1708957758233?e=2147483647&v=beta&t=xMzVZhCGZYMoNSETCR7it3dpNlrrkZKiht8hIB45sdI) <small>www.linkedin.com</small>Kimberly Powell on LinkedIn: Had a fantastic time hosting the PowerUp Strategic Educators ...

NVIDIA Powers Up In Drug Discovery
----------------------------------

 ![NVIDIA Powers Up in Drug Discovery](https://genengnews.com/wp-content/uploads/2020/10/Kimberly-Powell_avatar_1511719112-200x200-1.jpg) <small>www.genengnews.com</small>NVIDIA Powers Up in Drug Discovery

NVIDIA: A Nova Fronteira Da Medicina Está Na IA - CM
----------------------------------------------------

 ![NVIDIA: A nova fronteira da Medicina está na IA - CM](https://consumidormoderno.com.br/wp-content/uploads/2025/03/Nvidia_Kimberly-Powell-1024x530.webp) <small>consumidormoderno.com.br</small>NVIDIA: A nova fronteira da Medicina está na IA - CM

Kimberly Powell - Clinic Manager - MultiCare Health System | LinkedIn
---------------------------------------------------------------------

 ![Kimberly Powell - Clinic Manager - MultiCare Health System | LinkedIn](https://media.licdn.com/dms/image/C5603AQG7MpUq0T4ubw/profile-displayphoto-shrink_200_200/0/1553727787738?e=2147483647&v=beta&t=EgYVmO5tcnfLXaq3BFoGTL0xbbv0Dp9diHjYBEhFewI) <small>www.linkedin.com</small>Kimberly Powell - Clinic Manager - MultiCare Health System | LinkedIn

Kimberly Powell - Welcome To My LinkedIn Profile! I Am A Dedicated Financial Distributor
----------------------------------------------------------------------------------------

 ![Kimberly Powell - Welcome to my LinkedIn profile! I am a dedicated financial distributor](https://media.licdn.com/dms/image/v2/D4E03AQHU4FnOW251Pg/profile-displayphoto-shrink_200_200/profile-displayphoto-shrink_200_200/0/1712280988878?e=2147483647&v=beta&t=y3OtrSMdsUieqeoePomS9lnQrgx52wYFvGEyIeoeDHQ) <small>www.linkedin.com</small>Kimberly Powell - Welcome to my LinkedIn profile! I am a dedicated financial distributor ...

Kimberly Powell - 757 We Care | LinkedIn
----------------------------------------

 ![Kimberly Powell - 757 We Care | LinkedIn](https://media.licdn.com/dms/image/v2/D4E03AQHTD2vp9bw-Fg/profile-displayphoto-shrink_200_200/profile-displayphoto-shrink_200_200/0/1711833604134?e=2147483647&v=beta&t=ze1oQ9t_2gdIDmAoHlyh4f0aYq9JcDpbwZ0yBzIkRo8) <small>www.linkedin.com</small>Kimberly Powell - 757 We Care | LinkedIn

Kimberly Powell On LinkedIn: And Just Like That...25 Years Have Passed!!! In Seattle To See My
----------------------------------------------------------------------------------------------

 ![Kimberly Powell on LinkedIn: And just like that...25 years have passed!!! In Seattle to see my](https://media.licdn.com/dms/image/D5622AQFM01euwGXjow/feedshare-shrink_800/0/1684412420217?e=2147483647&v=beta&t=xcLy4MbpqBRuJ1bhMEqK-ZnS7coH8bt-lxAAEb3hIrk) <small>www.linkedin.com</small>Kimberly Powell on LinkedIn: And just like that...25 years have passed!!! In Seattle to see my ...

Faculty Staff | College Of Medicine
-----------------------------------

 ![Faculty Staff | College of Medicine](https://public.med.fsu.edu/images/Faculty/Kimberly.Powell.jpg) <small>public.med.fsu.edu</small>Faculty Staff | College of Medicine

Kimberly Powell - Vendor Manager - Cricket Wireless | LinkedIn
--------------------------------------------------------------

 ![Kimberly Powell - Vendor Manager - Cricket Wireless | LinkedIn](https://media.licdn.com/dms/image/C4D03AQEM8l-ceokP0g/profile-displayphoto-shrink_800_800/0/1625234024608?e=2147483647&v=beta&t=yuTwtwzeWsuqXRr60NCGM4C3AmKB_OuM8b1Bwo7Epkk) <small>www.linkedin.com</small>Kimberly Powell - Vendor Manager - Cricket Wireless | LinkedIn

Store 1 — Monmouth County Genealogy Society
-------------------------------------------

 ![Store 1 — Monmouth County Genealogy Society](https://images.squarespace-cdn.com/content/v1/5e13cf64d27b8e7f7fed649c/92bb66e6-ef18-46a9-b852-0ab884324205/Kimberly+Powell+-+headshot+2023+cropped+sm.png?format=1000w) <small>www.njmcgs.org</small>Store 1 — Monmouth County Genealogy Society

Kimberly powell. Nvidia powers up in drug discovery. Dive into the future of digital surgery, health, and biology with nvidia's vp of healthcare and
