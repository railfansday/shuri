---
title: "Kimberly Perry Husband Net Worth - kimberly perry and j. p. arencibia&#039;s beautiful married life; see her career and net worth"
description: "kimberly perry: age, husband, divorce, siblings, height, the band perry, worth"
date: "2026-10-13"
categories:
- "Uncategorized"
images:
- "https://i.headtopics.com/images/2023/9/8/billboard/kimberly-perry-welcomes-baby-boy-with-husband-john-kimberly-perry-welcomes-baby-boy-with-husband-john-D18F34E51FE5E6AFD89E735F63DDD35D.webp"
featuredImage: "https://luxlux.net/lux/wp-content/uploads/Kimberly-Perry-1-1160x680.jpeg"
featured_image: "http://img2.timeinc.net/people/i/2014/news/140630/kimberly-perry-768.jpg"
image: "https://musicmayhemmagazine.com/wp-content/uploads/2023/04/Johnny-Costello-Kimberly-Perry-Photo-Courtesy-of-CeCe-Dawson_Kimberly-Perry_Instagram-800x533.jpg"
---

If you are searching about Kimberly Perry biography, net worth, married, husband, son bio, height, divorce • biography you've came to the right place. We have 35 Pics about Kimberly Perry biography, net worth, married, husband, son bio, height, divorce • biography like Kimberly Perry and Husband Johnny Costello Are Still in a Honeymoon Phase: Like ‘Bonnie and Clyde’, Kimberly Perry Net Worth - Wiki, Age, Weight and Height, Relationships, Family, and More - Luxlux and also Kimberly Perry: age, husband, divorce, siblings, height, The Band Perry, worth - Briefly.co.za. Here you go:

Kimberly Perry Biography, Net Worth, Married, Husband, Son Bio, Height, Divorce • Biography
-------------------------------------------------------------------------------------------

 ![Kimberly Perry biography, net worth, married, husband, son bio, height, divorce • biography](https://bijog.com/uploads/images/2016/5/x300x188_kimberly-perry_4833.jpg.pagespeed.ic.TsblI2aCvH.jpg) <small>bijog.com</small>Kimberly Perry biography, net worth, married, husband, son bio, height, divorce • biography

Johnny Costello Marriage Life With Kimberly Perry &amp; Pregnancy - LatestCelebArticles
---------------------------------------------------------------------------------------

 ![Johnny Costello Marriage Life with Kimberly Perry & Pregnancy - LatestCelebArticles](https://latestcelebarticles.com/wp-content/uploads/2023/07/johnny-costello-and-kimberly-perry-on-red-carpet-1024x1024.jpeg) <small>latestcelebarticles.com</small>Johnny Costello Marriage Life with Kimberly Perry &amp; Pregnancy - LatestCelebArticles

Can You Guess Which Country Artist This Kid Grew Up To Be?
----------------------------------------------------------

 ![Can You Guess Which Country Artist This Kid Grew Up to Be?](https://townsquare.media/site/204/files/2023/09/attachment-KimberlyPerry5.jpg) <small>tasteofcountry.com</small>Can You Guess Which Country Artist This Kid Grew Up to Be?

Kimberly Perry Official Wedding Photo With J.P. Arencibia : People.com
----------------------------------------------------------------------

 ![Kimberly Perry Official Wedding Photo with J.P. Arencibia : People.com](http://img2.timeinc.net/people/i/2014/news/140630/kimberly-perry-768.jpg) <small>people.com</small>Kimberly Perry Official Wedding Photo with J.P. Arencibia : People.com

Kimberly Perry And Husband Introduce New 'Kiddos'
-------------------------------------------------

 ![Kimberly Perry and Husband Introduce New 'Kiddos'](https://townsquare.media/site/204/files/2015/12/JP-and-KP1.jpg?w=1200&h=0&zc=1&s=0&a=t&q=89&format=natural) <small>tasteofcountry.com</small>Kimberly Perry and Husband Introduce New 'Kiddos'

BREAKING: Kimberly Perry Is Pregnant, Expecting First Child With Husband Johnny Costello - Music
------------------------------------------------------------------------------------------------

 ![BREAKING: Kimberly Perry Is Pregnant, Expecting First Child With Husband Johnny Costello - Music](https://musicmayhemmagazine.com/wp-content/uploads/2023/04/Johnny-Costello-Kimberly-Perry-Photo-Courtesy-of-CeCe-Dawson_Kimberly-Perry_Instagram-800x533.jpg) <small>musicmayhemmagazine.com</small>BREAKING: Kimberly Perry Is Pregnant, Expecting First Child With Husband Johnny Costello - Music ...

Kimberly Perry Dishes On Her Return To 'The Band Perry' And Adding Her Husband, Johnny Costello
-----------------------------------------------------------------------------------------------

 ![Kimberly Perry dishes on her return to 'The Band Perry' and adding her husband, Johnny Costello](https://lookaside.fbsbx.com/lookaside/crawler/media/?media_id=1291790459661946&get_thumbnail=1) <small>www.facebook.com</small>Kimberly Perry dishes on her return to 'The Band Perry' and adding her husband, Johnny Costello ...

Kimberly Perry And J. P. Arencibia's Beautiful Married Life; See Her Career And Net Worth
-----------------------------------------------------------------------------------------

 ![Kimberly Perry and J. P. Arencibia's beautiful Married Life; see her Career and Net worth](https://marriedwiki.com/uploads/2017/08/perra.gif) <small>marriedwiki.com</small>Kimberly Perry and J. P. Arencibia's beautiful Married Life; see her Career and Net worth

Kimberly Perry, Johnny Costello's Marriage Is ‘Like Bonnie And Clyde’ | Us Weekly
---------------------------------------------------------------------------------

 ![Kimberly Perry, Johnny Costello's Marriage Is ‘Like Bonnie and Clyde’ | Us Weekly](https://www.usmagazine.com/wp-content/uploads/2024/06/Kimberly-Perry-Johnny-Costellos-Marriage-Is-Like-Bonnie-and-Clyde-01-2024.jpg?crop=0px%2C105px%2C1549px%2C813px&resize=1200%2C630&quality=86&strip=all) <small>www.usmagazine.com</small>Kimberly Perry, Johnny Costello's Marriage Is ‘Like Bonnie and Clyde’ | Us Weekly

19 November 2025 - Nashville, Tennessee - Kimberly Perry, Johnny Costello, The Band Perry. 59th
-----------------------------------------------------------------------------------------------

 ![19 November 2025 - Nashville, Tennessee - Kimberly Perry, Johnny Costello, The Band Perry. 59th](https://c8.alamy.com/comp/3D6EWBF/19-november-2025-nashville-tennessee-kimberly-perry-johnny-costello-the-band-perry-59th-cma-awards-held-at-music-city-center-photo-credit-mickey-bernaladmedia-mediapunch-3D6EWBF.jpg) <small>www.alamy.com</small>19 November 2025 - Nashville, Tennessee - Kimberly Perry, Johnny Costello, The Band Perry. 59th ...

Kimberly Perry Is Pregnant! The Band Perry Star Expecting First Baby With Husband Johnny
----------------------------------------------------------------------------------------

 ![Kimberly Perry is pregnant! The Band Perry star expecting first baby with husband Johnny](https://i.dailymail.co.uk/1s/2023/04/13/16/69795795-11969765-image-a-2_1681401549750.jpg) <small>www.dailymail.com</small>Kimberly Perry is pregnant! The Band Perry star expecting first baby with husband Johnny ...

Kimberly Perry + Husband Johnny Costello Welcome A Baby Boy | KJ97 | Randy Carroll
----------------------------------------------------------------------------------

 ![Kimberly Perry + Husband Johnny Costello Welcome A Baby Boy | KJ97 | Randy Carroll](https://i.iheart.com/v3/re/assets.getty/64fa209b1ba1be8706d7e285?ops=gravity("north"),fit(1200,675),quality(65)) <small>kj97.iheart.com</small>Kimberly Perry + Husband Johnny Costello Welcome A Baby Boy | KJ97 | Randy Carroll

Kimberly Perry's Wedding: All The Details
-----------------------------------------

 ![Kimberly Perry's wedding: all the details](https://www.tennessean.com/gcdn/-mm-/711e6690e6ab097b150fe1621fd7b8d2d8a8c3ca/c=0-476-2400-1831/local/-/media/Nashville/2014/06/14/kpjp.jpg?width=2400&height=1355&fit=crop&format=pjpg&auto=webp) <small>www.tennessean.com</small>Kimberly Perry's wedding: all the details

The Band Perry Star Kimberly Perry Marries Baseball Beau J.P. Arencibia | Daily Mail Online
-------------------------------------------------------------------------------------------

 ![The Band Perry star Kimberly Perry marries baseball beau J.P. Arencibia | Daily Mail Online](https://i.dailymail.co.uk/i/pix/2014/06/13/article-2656903-1EB8E2D800000578-191_634x904.jpg) <small>www.dailymail.com</small>The Band Perry star Kimberly Perry marries baseball beau J.P. Arencibia | Daily Mail Online

Kimberly Perry And J. P. Arencibia's Beautiful Married Life; See Her Career And Net Worth
-----------------------------------------------------------------------------------------

 ![Kimberly Perry and J. P. Arencibia's beautiful Married Life; see her Career and Net worth](https://marriedwiki.com/uploads/article/2017/08/25/thumb/kimberly-perry-and-her-husband-j-p-arencibia-married-life-also-know-about-her-career-and-net-worth-here-260-160.gif) <small>marriedwiki.com</small>Kimberly Perry and J. P. Arencibia's beautiful Married Life; see her Career and Net worth

Kimberly Perry And Husband Johnny Costello Are Still In A Honeymoon Phase: Like ‘Bonnie And Clyde’
--------------------------------------------------------------------------------------------------

 ![Kimberly Perry and Husband Johnny Costello Are Still in a Honeymoon Phase: Like ‘Bonnie and Clyde’](https://s.yimg.com/lo/mysterio/api/f8dcfb37113fee0175110673cc3af52b6ea21feaf988157aeb98cda2e6f2f356/lightyear_networkapi/resizefill_w960;quality_80;format_webp/https://www.usmagazine.com/wp-content/uploads/2024/06/Kimberly-Perry-Johnny-Costellos-Marriage-Is-Like-Bonnie-and-Clyde-01-2024.jpg) <small>www.yahoo.com</small>Kimberly Perry and Husband Johnny Costello Are Still in a Honeymoon Phase: Like ‘Bonnie and Clyde’

The Band Perry Singer Kimberly Perry Marries J.P. Arencibia
-----------------------------------------------------------

 ![The Band Perry Singer Kimberly Perry Marries J.P. Arencibia](https://townsquare.media/site/623/files/2014/06/Kimberly-Perry-JP-Arencibia.jpg?w=980&q=75) <small>theboot.com</small>The Band Perry Singer Kimberly Perry Marries J.P. Arencibia

Kimberly Perry Net Worth - Wiki, Age, Weight And Height, Relationships, Family, And More - Luxlux
-------------------------------------------------------------------------------------------------

 ![Kimberly Perry Net Worth - Wiki, Age, Weight and Height, Relationships, Family, and More - Luxlux](https://luxlux.net/lux/wp-content/uploads/Kimberly-Perry-1-675x1024.jpeg) <small>luxlux.net</small>Kimberly Perry Net Worth - Wiki, Age, Weight and Height, Relationships, Family, and More - Luxlux

Kimberly Perry Net Worth 2025: How Much Is The Singers Wealth?
--------------------------------------------------------------

 ![Kimberly Perry Net Worth 2025: How Much is the Singers Wealth?](https://www.caknowledge.in/wp-content/uploads/2024/02/Kimberly-Perry-Net-Worth.jpg) <small>www.caknowledge.in</small>Kimberly Perry Net Worth 2025: How Much is the Singers Wealth?

Kimberly Perry Welcomes Baby Boy With Husband Johnny Costello | United States
-----------------------------------------------------------------------------

 ![Kimberly Perry Welcomes Baby Boy With Husband Johnny Costello | United States](https://i.headtopics.com/images/2023/9/8/billboard/kimberly-perry-welcomes-baby-boy-with-husband-john-kimberly-perry-welcomes-baby-boy-with-husband-john-D18F34E51FE5E6AFD89E735F63DDD35D.webp) <small>us.headtopics.com</small>Kimberly Perry Welcomes Baby Boy With Husband Johnny Costello | United States

Kimberly Perry: Age, Husband, Divorce, Siblings, Height, The Band Perry, Worth - Briefly.co.za
----------------------------------------------------------------------------------------------

 ![Kimberly Perry: age, husband, divorce, siblings, height, The Band Perry, worth - Briefly.co.za](https://cdn.briefly.co.za/images/1120/6c11f0aa764239f9.jpeg?v=1) <small>briefly.co.za</small>Kimberly Perry: age, husband, divorce, siblings, height, The Band Perry, worth - Briefly.co.za

The Band Perry News ? Page 2
----------------------------

 ![The Band Perry News ? Page 2](https://townsquare.media/site/204/files/2017/08/kimberly-perry-jp-arencibia.jpg) <small>tasteofcountry.com</small>The Band Perry News ? Page 2

The Band Perry Releases New Song After 'Lots Of Changes' As Kimberly Perry And Husband Lead Band
------------------------------------------------------------------------------------------------

 ![The Band Perry Releases New Song After 'Lots of Changes' as Kimberly Perry and Husband Lead Band](https://s.yimg.com/ny/api/res/1.2/JADmJjCOZKTycREENKS99g--/YXBwaWQ9aGlnaGxhbmRlcjt3PTk2MDtoPTY0MDtjZj13ZWJw/https://media.zenfs.com/en/people_218/d9b39f16a398ef62ab8897d7b00960d9) <small>malaysia.news.yahoo.com</small>The Band Perry Releases New Song After 'Lots of Changes' as Kimberly Perry and Husband Lead Band ...

Kimberly Perry Sings Of Infidelity After Split In Band Perry Single 'The Good Life'
-----------------------------------------------------------------------------------

 ![Kimberly Perry Sings of Infidelity After Split in Band Perry Single 'The Good Life'](https://people.com/thmb/mRId-1VAhtuC1ockGpYzuzdssWg=/4000x0/filters:no_upscale():max_bytes(150000):strip_icc():focal(667x0:669x2)/kimberley-perry-2000-7fb4f212fda84873a45c94e856b99d7e.jpg) <small>people.com</small>Kimberly Perry Sings of Infidelity After Split in Band Perry Single 'The Good Life'

Kimberly Perry Net Worth 2025: How Much Is The Singers Wealth?
--------------------------------------------------------------

 ![Kimberly Perry Net Worth 2025: How Much is the Singers Wealth?](https://www.caknowledge.in/wp-content/uploads/2024/02/Kimberly-Perry-Income.jpg) <small>www.caknowledge.in</small>Kimberly Perry Net Worth 2025: How Much is the Singers Wealth?

Kimberly Perry Shares First Pic Of Baby No. 1 With Husband Johnny Costello | IHeart
-----------------------------------------------------------------------------------

 ![Kimberly Perry Shares First Pic Of Baby No. 1 With Husband Johnny Costello | iHeart](https://i.iheart.com/v3/re/new_assets/64e91f53890c44fb9fe8974c?ops=contain(1480,0)) <small>www.iheart.com</small>Kimberly Perry Shares First Pic Of Baby No. 1 With Husband Johnny Costello | iHeart

Kimberly Perry And J. P. Arencibia's Beautiful Married Life; See Her Career And Net Worth
-----------------------------------------------------------------------------------------

 ![Kimberly Perry and J. P. Arencibia's beautiful Married Life; see her Career and Net worth](https://marriedwiki.com/uploads/2017/08/pada.gif) <small>marriedwiki.com</small>Kimberly Perry and J. P. Arencibia's beautiful Married Life; see her Career and Net worth

Kimberly Perry Of The Band Perry Welcomes Baby Boy
--------------------------------------------------

 ![Kimberly Perry Of The Band Perry Welcomes Baby Boy](https://countryrebel.com/wp-content/uploads/2023/09/kimberly-perry-baby.png) <small>countryrebel.com</small>Kimberly Perry Of The Band Perry Welcomes Baby Boy

Who Is Kimberly Perry's Future Husband?
---------------------------------------

 ![Who Is Kimberly Perry's Future Husband?](https://townsquare.media/site/204/files/2013/10/Kimberly-and-JP.jpg?w=1200&h=0&zc=1&s=0&a=t&q=89&format=natural) <small>tasteofcountry.com</small>Who Is Kimberly Perry's Future Husband?

Kimberly Perry Waited 'Maybe A Week' To Tell Husband She Loved Him
------------------------------------------------------------------

 ![Kimberly Perry Waited 'Maybe a Week' to Tell Husband She Loved Him](https://people.com/thmb/t40vZBL97Lihkdkb2jWRz1biz9A=/4000x0/filters:no_upscale():max_bytes(150000):strip_icc():focal(499x0:501x2)/Kimberly-Perry-03-061323-89f6a6b2e8e7461ebc607f12514aa1b6.jpg) <small>people.com</small>Kimberly Perry Waited 'Maybe a Week' to Tell Husband She Loved Him

18 November 2025 - Nashville, Tennessee - Kimberly Perry, Neil Perry, The Band Perry. 2025 BMI
----------------------------------------------------------------------------------------------

 ![18 November 2025 - Nashville, Tennessee - Kimberly Perry, Neil Perry, The Band Perry. 2025 BMI](https://c8.alamy.com/comp/3D66EX8/18-november-2025-nashville-tennessee-kimberly-perry-neil-perry-the-band-perry-2025-bmi-country-awards-held-at-bmi-music-row-credit-image-dara-michelle-farradmedia-via-zuma-press-wire-editorial-usage-only!-not-for-commercial-usage!-3D66EX8.jpg) <small>www.alamy.com</small>18 November 2025 - Nashville, Tennessee - Kimberly Perry, Neil Perry, The Band Perry. 2025 BMI ...

Kimberly Perry Net Worth In 2023 - Wiki, Age, Weight And Height, Relationships, Family, And More
------------------------------------------------------------------------------------------------

 ![Kimberly Perry Net Worth in 2023 - Wiki, Age, Weight and Height, Relationships, Family, and More](https://luxlux.net/lux/wp-content/uploads/Kimberly-Perry-1-1160x680.jpeg) <small>luxlux.net</small>Kimberly Perry Net Worth in 2023 - Wiki, Age, Weight and Height, Relationships, Family, and More ...

Kimberly Perry Is Pregnant, Expecting First Child With Husband Johnny Costello: ‘I’m Overflowing
------------------------------------------------------------------------------------------------

 ![Kimberly Perry Is Pregnant, Expecting First Child With Husband Johnny Costello: ‘I’m Overflowing](https://i.headtopics.com/images/2023/4/13/usweekly/the-band-perry-s-kimberly-and-husband-johnny-coste-the-band-perry-s-kimberly-and-husband-johnny-coste-1646545403532173314.webp?w=640) <small>us.headtopics.com</small>Kimberly Perry Is Pregnant, Expecting First Child With Husband Johnny Costello: ‘I’m Overflowing ...

Kimberly Perry Of The Band Perry Is Engaged!
--------------------------------------------

 ![Kimberly Perry of The Band Perry is engaged!](https://www.sheknows.com/wp-content/uploads/2018/12/kimberly-perry-engaged_bbxjzq.jpeg) <small>www.sheknows.com</small>Kimberly Perry of The Band Perry is engaged!

The Band Perry's Kimberly Perry And Husband Renew Vows In Las Vegas One Year After Secret
-----------------------------------------------------------------------------------------

 ![The Band Perry's Kimberly Perry and Husband Renew Vows In Las Vegas One Year After Secret](https://countrynow.com/wp-content/uploads/2022/08/Kimbery-Perry-Vow-Renewal-2-570x964.jpg) <small>countrynow.com</small>The Band Perry's Kimberly Perry and Husband Renew Vows In Las Vegas One Year After Secret ...

Kimberly perry, johnny costello's marriage is ‘like bonnie and clyde’. Kimberly perry + husband johnny costello welcome a baby boy. kimberly perry net worth
