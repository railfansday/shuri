---
title: "Atum-52/13-0-stk - 1 stück, schrumpfschlauch atum-52/13-0-stk /e2de"
description: "Raychem atum 52/13-0"
date: "2026-03-27"
categories:
- "Uncategorized"
images:
- "https://www.cablecraft.co.uk/media/wysiwyg/4-1_Shrink_Ratio_Icon.svg"
featuredImage: "https://scp-sa.es/415-thickbox_default/atum-9-3-0-sp.jpg"
featured_image: "https://fr.farnell.com/productimages/standard/en_GB/3236577-40.jpg"
image: "https://www.taloon.com/media/catalog/product/5/2/5230766.jpg?w=638&amp;h=638"
---

If you are looking for ATUM-52/13-0-SP TE Connectivity / Raychem | Mouser you've visit to the right place. We have 34 Pics about ATUM-52/13-0-SP TE Connectivity / Raychem | Mouser like ATUM-52/13-0-STK | Chemelex Heat Shrink Tubing, Black 52 mm Sleeve Dia. x 1.2m Length 4:1 Ratio, ATUM-52/13-0-STK | TE Connectivity 熱収縮チューブ, 黒, 52 mmから 13 mm, ポリオレフィン, 1.2m | RS and also ATUM-52/13-0-SP TE Connectivity / Raychem - Heat Shrink Tubing - Distributors, Price Comparison. Here it is:

ATUM-52/13-0-SP TE Connectivity / Raychem | Mouser
--------------------------------------------------

 ![ATUM-52/13-0-SP TE Connectivity / Raychem | Mouser](https://www.mouser.cn/images/tycoelectronics/images/pratum.jpg) <small>www.mouser.cn</small>ATUM-52/13-0-SP TE Connectivity / Raychem | Mouser

Raychem ATUM, 52-13mm Dual Wall Adhesive Lined Heat Shrink Tubing - 1.2M Length
-------------------------------------------------------------------------------

 ![Raychem ATUM, 52-13mm Dual Wall Adhesive Lined Heat Shrink Tubing - 1.2M Length](https://www.cablecraft.co.uk/media/wysiwyg/4-1_Shrink_Ratio_Icon.svg) <small>www.cablecraft.co.uk</small>Raychem ATUM, 52-13mm Dual Wall Adhesive Lined Heat Shrink Tubing - 1.2M Length

NVent RAYCHEM Adhesive Lined Heat Shrink Tube, Black 40mm Sleeve Dia. X 1.2m Length 3:1 Ratio
---------------------------------------------------------------------------------------------

 ![NVent RAYCHEM Adhesive Lined Heat Shrink Tube, Black 40mm Sleeve Dia. X 1.2m Length 3:1 Ratio](https://media.halltronics.com/images/atum-40-13-0-stk19-01.jpg) <small>halltronics.com</small>NVent RAYCHEM Adhesive Lined Heat Shrink Tube, Black 40mm Sleeve Dia. X 1.2m Length 3:1 Ratio ...

ATUM-52/13-0-STK : RAYCHEM ATUM 4:1 Heat Shrink Tubing | TE Connectivity
------------------------------------------------------------------------

 ![ATUM-52/13-0-STK : RAYCHEM ATUM 4:1 Heat Shrink Tubing | TE Connectivity](https://www.te.com/content/dam/te-com/catalog/part/EM5/611/600/EM56116001-t5.jpg/jcr:content/renditions/product-small.png?w=220) <small>www.te.com</small>ATUM-52/13-0-STK : RAYCHEM ATUM 4:1 Heat Shrink Tubing | TE Connectivity

ATUM-32/8-0-STK TE Connectivity / Raychem | Mouser
--------------------------------------------------

 ![ATUM-32/8-0-STK TE Connectivity / Raychem | Mouser](https://www.mouser.com/images/tycoelectronics/images/NB09012001_SPL.jpg) <small>www.mouser.com</small>ATUM-32/8-0-STK TE Connectivity / Raychem | Mouser

ATUM Heatshrink Size 52/13 (52.0mm Down To 13.0mm)
--------------------------------------------------

 ![ATUM heatshrink size 52/13 (52.0mm down to 13.0mm)](https://hilltop-products.co.uk/media/catalog/product/cache/f9f2413c71b073e5359531a425f36bfa/r/n/rnf100_black_ps_1_10.png) <small>hilltop-products.co.uk</small>ATUM heatshrink size 52/13 (52.0mm down to 13.0mm)

ATUM-19/6-0-STK TE Connectivity | Raychem Products | ICC
--------------------------------------------------------

 ![ATUM-19/6-0-STK TE Connectivity | Raychem Products | ICC](https://sku-product-images.s3.us-east-2.amazonaws.com/AMP/AMP206705-2.jpg) <small>www.connecticc.com</small>ATUM-19/6-0-STK TE Connectivity | Raychem Products | ICC

2" Raychem ATUM Heat Shrink Adhesive Lined Tubing, 1ft Length (6" X 2) – KSV Looms
----------------------------------------------------------------------------------

 ![2" Raychem ATUM Heat Shrink Adhesive Lined Tubing, 1ft length (6" x 2) – KSV Looms](https://www.ksvlooms.com/cdn/shop/files/2-raychem-atum-heat-shrink-adhesive-lined-tubing-649.webp?v=1756159522&width=4096) <small>www.ksvlooms.com</small>2" Raychem ATUM Heat Shrink Adhesive Lined Tubing, 1ft length (6" x 2) – KSV Looms

ATUM-52/13-0-STK | Chemelex Heat Shrink Tubing, Black 52 Mm Sleeve Dia. X 1.2m Length 4:1 Ratio
-----------------------------------------------------------------------------------------------

 ![ATUM-52/13-0-STK | Chemelex Heat Shrink Tubing, Black 52 mm Sleeve Dia. x 1.2m Length 4:1 Ratio](https://media.rs-online.com/image/upload/bo_1.5px_solid_white,b_auto,c_pad,dpr_2,f_auto,h_399,q_auto,w_710/c_pad,h_399,w_710/Y0433221-01?pgw=1) <small>za.rs-online.com</small>ATUM-52/13-0-STK | Chemelex Heat Shrink Tubing, Black 52 mm Sleeve Dia. x 1.2m Length 4:1 Ratio ...

ATUM-52/13-0-SP TE Connectivity / Raychem - Heat Shrink Tubing - Distributors, Price Comparison
-----------------------------------------------------------------------------------------------

 ![ATUM-52/13-0-SP TE Connectivity / Raychem - Heat Shrink Tubing - Distributors, Price Comparison](https://sigma.octopart.com/187551175/image/TE-Connectivity-ATUM-52-13-0-SP.jpg) <small>octopart.com</small>ATUM-52/13-0-SP TE Connectivity / Raychem - Heat Shrink Tubing - Distributors, Price Comparison ...

ATUM-52/13-0-STK | TE Connectivity 熱収縮チューブ, 黒, 52 Mmから 13 Mm, ポリオレフィン, 1.2m | RS
--------------------------------------------------------------------------------

 ![ATUM-52/13-0-STK | TE Connectivity 熱収縮チューブ, 黒, 52 mmから 13 mm, ポリオレフィン, 1.2m | RS](https://media.rs-online.com/image/upload/bo_1.5px_solid_white,b_auto,c_pad,dpr_2,f_auto,h_399,q_auto,w_710/c_pad,h_399,w_710/Y0487271-01?pgw=1) <small>jp.rs-online.com</small>ATUM-52/13-0-STK | TE Connectivity 熱収縮チューブ, 黒, 52 mmから 13 mm, ポリオレフィン, 1.2m | RS

ATUM-52/13-0-STK TE Connectivity Raychem Cable Protection | Cables, Wires - Management | DigiKey
------------------------------------------------------------------------------------------------

 ![ATUM-52/13-0-STK TE Connectivity Raychem Cable Protection | Cables, Wires - Management | DigiKey](https://media.digikey.com/Photos/Tyco Photos/17_ATUM-5213-0-STK.jpg) <small>www.digikey.com</small>ATUM-52/13-0-STK TE Connectivity Raychem Cable Protection | Cables, Wires - Management | DigiKey

ATUM-32/8-0 ATUM-52/13-0 DR-25-1/2-0 TE 热缩套管
--------------------------------------------

 ![ATUM-32/8-0 ATUM-52/13-0 DR-25-1/2-0 TE 热缩套管](https://b2b-material.cdn.bcebos.com/Q6Rq-hyj3ZDrpiwcCDsJmRAHfsA.png?x-bce-process=image%2Fresize%2Cw_750%2Fformat%2Cf_auto%2Fquality%2Cq_90) <small>b2b.baidu.com</small>ATUM-32/8-0 ATUM-52/13-0 DR-25-1/2-0 TE 热缩套管

1 Stück, Schrumpfschlauch ATUM-52/13-0-STK /E2DE | EBay.de
----------------------------------------------------------

 ![1 Stück, Schrumpfschlauch ATUM-52/13-0-STK /E2DE | eBay.de](https://i.ebayimg.com/thumbs/images/g/hB4AAOSwIgVmWKnz/s-l500.jpg) <small>www.ebay.de</small>1 Stück, Schrumpfschlauch ATUM-52/13-0-STK /E2DE | eBay.de

Raychem ATUM 52/13-0 - трубка термоусаживаемая гибкая с двойной стенкой цена, купить 120610
-------------------------------------------------------------------------------------------

 ![Raychem ATUM 52/13-0 - трубка термоусаживаемая гибкая с двойной стенкой цена, купить 120610](https://skomplekt.com/files/uploads/product_1655915/main_img_p1655915_popup.jpg) <small>skomplekt.com</small>Raychem ATUM 52/13-0 - трубка термоусаживаемая гибкая с двойной стенкой цена, купить 120610 ...

NEW RAYCHEM ATUM-52/13-6" 6" LENGTH 4:1 HEAT SHRINK TUBING | EBay
-----------------------------------------------------------------

 ![NEW RAYCHEM ATUM-52/13-6" 6" LENGTH 4:1 HEAT SHRINK TUBING | eBay](https://i.ebayimg.com/images/g/~dYAAOSwoNBdrGEw/s-l500.jpg) <small>www.ebay.com</small>NEW RAYCHEM ATUM-52/13-6" 6" LENGTH 4:1 HEAT SHRINK TUBING | eBay

レイケム ATUM-52/13-0-STK（カット品1.2m） 黒色 接着層付き 防水熱収縮チューブ 52.0→13.0mm : FA-Ubon Yahoo!店 - 通販 - Yahoo!ショッピング
----------------------------------------------------------------------------------------------------

 ![レイケム ATUM-52/13-0-STK（カット品1.2m） 黒色 接着層付き 防水熱収縮チューブ 52.0→13.0mm : FA-Ubon Yahoo!店 - 通販 - Yahoo!ショッピング](https://item-shopping.c.yimg.jp/i/n/faubon_0878885) <small>store.shopping.yahoo.co.jp</small>レイケム ATUM-52/13-0-STK（カット品1.2m） 黒色 接着層付き 防水熱収縮チューブ 52.0→13.0mm : FA-Ubon Yahoo!店 - 通販 - Yahoo!ショッピング

NB11382001 | TE Connectivity Adhesive Lined Heat-Shrink Tube, Black 52 Mm Sleeve Dia. X 1.2m
--------------------------------------------------------------------------------------------

 ![NB11382001 | TE Connectivity Adhesive Lined Heat-Shrink Tube, Black 52 mm Sleeve Dia. x 1.2m](https://media.distrelec.com/Web/WebShopImages/landscape_large/1-/01/Y0487271-01.jpg) <small>www.distrelec.ch</small>NB11382001 | TE Connectivity Adhesive Lined Heat-Shrink Tube, Black 52 mm Sleeve Dia. x 1.2m ...

ATUM-52/13-0-STK : RAYCHEM ATUM 4:1 Heat Shrink Tubing | TE Connectivity
------------------------------------------------------------------------

 ![ATUM-52/13-0-STK : RAYCHEM ATUM 4:1 Heat Shrink Tubing | TE Connectivity](https://www.te.com/content/dam/te-com/catalog/part/EM5/611/600/EM56116001-t3.jpg/jcr:content/renditions/product-small.png?w=85) <small>www.te.com</small>ATUM-52/13-0-STK : RAYCHEM ATUM 4:1 Heat Shrink Tubing | TE Connectivity

ATUM-52/13-0-STK : RAYCHEM ATUM 4:1 Heat Shrink Tubing | TE Connectivity
------------------------------------------------------------------------

 ![ATUM-52/13-0-STK : RAYCHEM ATUM 4:1 Heat Shrink Tubing | TE Connectivity](https://www.te.com/content/dam/te-com/catalog/part/EM5/611/600/EM56116001-t1.jpg/jcr:content/renditions/product-small.png?w=85) <small>www.te.com</small>ATUM-52/13-0-STK : RAYCHEM ATUM 4:1 Heat Shrink Tubing | TE Connectivity

ATUM-40/13-0-STK TE Connectivity | Raychem Products | Heilind
-------------------------------------------------------------

 ![ATUM-40/13-0-STK TE Connectivity | Raychem Products | Heilind](https://sku-product-images.s3.us-east-2.amazonaws.com/AMP/35244.jpg) <small>www.heilind.com</small>ATUM-40/13-0-STK TE Connectivity | Raychem Products | Heilind

ATUM Heatshrink Size 52/13 (52.0mm Down To 13.0mm)
--------------------------------------------------

 ![ATUM heatshrink size 52/13 (52.0mm down to 13.0mm)](https://hilltop-products.co.uk/media/catalog/product/cache/6d2ffb848796335b7eb82cc8e3ea4df5/r/n/rnf100_black_ps_1_10.png) <small>hilltop-products.co.uk</small>ATUM heatshrink size 52/13 (52.0mm down to 13.0mm)

ATUM-52/13-0-STK : RAYCHEM ATUM 4:1 Heat Shrink Tubing | TE Connectivity
------------------------------------------------------------------------

 ![ATUM-52/13-0-STK : RAYCHEM ATUM 4:1 Heat Shrink Tubing | TE Connectivity](https://www.te.com/content/dam/te-com/catalog/part/EM5/611/600/EM56116001-t4.jpg/jcr:content/renditions/product-small.png?w=85) <small>www.te.com</small>ATUM-52/13-0-STK : RAYCHEM ATUM 4:1 Heat Shrink Tubing | TE Connectivity

ATUM-52/13-0-STK : RAYCHEM ATUM 4:1 Heat Shrink Tubing | TE Connectivity
------------------------------------------------------------------------

 ![ATUM-52/13-0-STK : RAYCHEM ATUM 4:1 Heat Shrink Tubing | TE Connectivity](https://www.te.com/content/dam/te-com/catalog/part/EM5/611/600/EM56116001-t3.jpg/jcr:content/renditions/product-small.png?w=220) <small>www.te.com</small>ATUM-52/13-0-STK : RAYCHEM ATUM 4:1 Heat Shrink Tubing | TE Connectivity

Raychem Heat Shrink Tubing Tat-125/1 1/2-0 &amp; Atum 52/13-0 | EBay
--------------------------------------------------------------------

 ![Raychem Heat Shrink Tubing Tat-125/1 1/2-0 & Atum 52/13-0 | eBay](https://i.ebayimg.com/images/g/52wAAOSw~hZc3Es2/s-l400.jpg) <small>www.ebay.com</small>Raychem Heat Shrink Tubing Tat-125/1 1/2-0 &amp; Atum 52/13-0 | eBay

Kutisteletku ATUM 52/13-1200 MUSTA
----------------------------------

 ![Kutisteletku ATUM 52/13-1200 MUSTA](https://www.taloon.com/media/catalog/product/5/2/5230766.jpg?w=638&h=638) <small>www.taloon.com</small>Kutisteletku ATUM 52/13-1200 MUSTA

TE Connectivity - ATUM-52/13-0-STK - Raychem, Tubing, Heat Shrinkable, Semiflexable,Thin Wall
---------------------------------------------------------------------------------------------

 ![TE Connectivity - ATUM-52/13-0-STK - Raychem, Tubing, Heat Shrinkable, Semiflexable,Thin Wall](https://assets.rs-online.com/f_auto,q_auto/70100815.jpg) <small>us.rs-online.com</small>TE Connectivity - ATUM-52/13-0-STK - Raychem, Tubing, Heat Shrinkable, Semiflexable,Thin Wall ...

ATUM-52/13-0-STK TE CONNECTIVITY - RAYCHEM, Gaine Thermorétractable Avec Adhésif, 4:1, 2.05
-------------------------------------------------------------------------------------------

 ![ATUM-52/13-0-STK TE CONNECTIVITY - RAYCHEM, Gaine thermorétractable avec adhésif, 4:1, 2.05](https://fr.farnell.com/productimages/standard/en_GB/3236577-40.jpg) <small>fr.farnell.com</small>ATUM-52/13-0-STK TE CONNECTIVITY - RAYCHEM, Gaine thermorétractable avec adhésif, 4:1, 2.05 ...

ATUM-32/8-0-STK TE Connectivity | Raychem Products | Heilind
------------------------------------------------------------

 ![ATUM-32/8-0-STK TE Connectivity | Raychem Products | Heilind](https://sku-product-images.s3.us-east-2.amazonaws.com/AMP/1658527-6.jpg) <small>www.heilind.com</small>ATUM-32/8-0-STK TE Connectivity | Raychem Products | Heilind

ATUM-52/13-0-STK : RAYCHEM ATUM 4:1 Heat Shrink Tubing | TE Connectivity
------------------------------------------------------------------------

 ![ATUM-52/13-0-STK : RAYCHEM ATUM 4:1 Heat Shrink Tubing | TE Connectivity](https://www.te.com/content/dam/te-com/catalog/part/EM5/611/600/EM56116001-t2.jpg/jcr:content/renditions/product-high-res.png) <small>www.te.com</small>ATUM-52/13-0-STK : RAYCHEM ATUM 4:1 Heat Shrink Tubing | TE Connectivity

ATUM-52/13-0 | TE Connectivity Heat Shrink Tubing, Black 52 Mm Sleeve Dia. X 1.2m Length 4:1
--------------------------------------------------------------------------------------------

 ![ATUM-52/13-0 | TE Connectivity Heat Shrink Tubing, Black 52 mm Sleeve Dia. x 1.2m Length 4:1](https://media.rs-online.com/f_auto,q_auto,bo_1.5px_solid_white,b_auto,c_pad,dpr_2,h_399,w_710/c_pad,h_399,w_710/R3161552-01?pgw=1) <small>za.rs-online.com</small>ATUM-52/13-0 | TE Connectivity Heat Shrink Tubing, Black 52 mm Sleeve Dia. x 1.2m Length 4:1 ...

ATUM-52/13-0-STK : RAYCHEM ATUM 4:1 Heat Shrink Tubing | TE Connectivity
------------------------------------------------------------------------

 ![ATUM-52/13-0-STK : RAYCHEM ATUM 4:1 Heat Shrink Tubing | TE Connectivity](https://www.te.com/content/dam/te-com/catalog/part/EM5/611/600/EM56116001-t2.jpg/jcr:content/renditions/product-small.png?w=220) <small>www.te.com</small>ATUM-52/13-0-STK : RAYCHEM ATUM 4:1 Heat Shrink Tubing | TE Connectivity

ATUM
----

 ![ATUM](https://scp-sa.es/415-thickbox_default/atum-9-3-0-sp.jpg) <small>scp-sa.es</small>ATUM

ATUM-52/13-0-STK TE Connectivity Raychem Cable Protection | Heat Shrink Tubing | DigiKey Marketplace
----------------------------------------------------------------------------------------------------

 ![ATUM-52/13-0-STK TE Connectivity Raychem Cable Protection | Heat Shrink Tubing | DigiKey Marketplace](https://mm.digikey.com/Volume0/opasdata/d220001/derivates/1/003/226/041/MFG_ATUM-XX-X-0-SP_sml(200x200).jpg) <small>www.digikey.com</small>ATUM-52/13-0-STK TE Connectivity Raychem Cable Protection | Heat Shrink Tubing | DigiKey Marketplace

Atum-52/13-0. 2" raychem atum heat shrink adhesive lined tubing, 1ft length (6" x 2) – ksv looms. atum-52/13-0-stk : raychem atum 4:1 heat shrink tubing
