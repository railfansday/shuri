---
title: "Kimberly Powell Clifton Powell Wife - The 36th naacp image awards arrivals photos and premium high res pictures"
description: "92 clifton powell stock pictures, editorial images and stock photos"
date: "2026-08-09"
categories:
- "Uncategorized"
images:
- "https://static8.imagecollect.com/preview/137/6ab644243b7f373"
featuredImage: "https://static8.imagecollect.com/preview/137/6ab644243b7f373"
featured_image: "https://editorial01.shutterstock.com/preview-440/4372122a/37cc8d57/Shutterstock_4372122a.jpg"
image: "https://liverampup.com/uploads/clifton-powell-with-girlfriend-kita.JPG"
---

If you are looking for Clifton Powell Jr. Bio, Age, Height, Girlfriend, Net Worth, Wiki you've came to the right web. We have 34 Pics about Clifton Powell Jr. Bio, Age, Height, Girlfriend, Net Worth, Wiki like 379 Clifton Powell Stock Photos, High-Res Pictures, and Images - Getty Images, Clifton Powell Wife Kim Editorial Stock Photo - Stock Image | Shutterstock and also Actor Clifton Powell and his wife Kimberly Powell attend the "Genius:... News Photo - Getty Images. Here you go:

Clifton Powell Jr. Bio, Age, Height, Girlfriend, Net Worth, Wiki
----------------------------------------------------------------

 ![Clifton Powell Jr. Bio, Age, Height, Girlfriend, Net Worth, Wiki](https://wealthyspy.com/wp-content/uploads/2022/04/Clifton-Powell-Jr.-1.jpg) <small>wealthyspy.com</small>Clifton Powell Jr. Bio, Age, Height, Girlfriend, Net Worth, Wiki

Clifton Powell &amp; Wife Kimberly... - Throwbackculturera | Facebook
---------------------------------------------------------------------

 ![Clifton Powell & wife Kimberly... - Throwbackculturera | Facebook](https://lookaside.fbsbx.com/lookaside/crawler/media/?media_id=122273831978023023) <small>www.facebook.com</small>Clifton Powell &amp; wife Kimberly... - Throwbackculturera | Facebook

Actor Clifton Powell And Daughter Maya Powell Attend "Chocolate City"... News Photo - Getty Images
--------------------------------------------------------------------------------------------------

 ![Actor Clifton Powell and daughter Maya Powell attend "Chocolate City"... News Photo - Getty Images](https://media.gettyimages.com/id/474358674/photo/chocolate-city-los-angeles-premiere.jpg?s=1024x1024&w=gi&k=20&c=yrUiAMazNB4u5970G6OFCgc-2_dIDaXcvIvy8_Bmjaw=) <small>www.gettyimages.com</small>Actor Clifton Powell and daughter Maya Powell attend "Chocolate City"... News Photo - Getty Images

💞 Clifton Powell And Wife Kimberly Powell A Love That’s Outlasted Hollywood! - YouTube
--------------------------------------------------------------------------------------

 ![💞 Clifton Powell and Wife Kimberly Powell A Love That’s Outlasted Hollywood! - YouTube](https://i.ytimg.com/vi/M0uG29JxCA0/maxresdefault.jpg?sqp=-oaymwEoCIAKENAF8quKqQMcGADwAQH4AbYIgAKAD4oCDAgAEAEYRyBYKGUwDw==&rs=AOn4CLC1vyBqrLBuo3dO4Mr8DOZPzwOJyQ) <small>www.youtube.com</small>💞 Clifton Powell and Wife Kimberly Powell A Love That’s Outlasted Hollywood! - YouTube

92 Clifton Powell Stock Pictures, Editorial Images And Stock Photos | Shutterstock Editorial
--------------------------------------------------------------------------------------------

 ![92 Clifton Powell Stock Pictures, Editorial Images and Stock Photos | Shutterstock Editorial](https://www.shutterstock.com/editorial/image-editorial/N9TcIe19N5T4k552MTQ1/clifton-powell-wife-kim-440nw-498932az.jpg) <small>www.shutterstock.com</small>92 Clifton Powell Stock Pictures, Editorial Images and Stock Photos | Shutterstock Editorial

379 Clifton Powell Stock Photos, High-Res Pictures, And Images - Getty Images
-----------------------------------------------------------------------------

 ![379 Clifton Powell Stock Photos, High-Res Pictures, and Images - Getty Images](https://media.gettyimages.com/id/115378454/photo/kim-powell-wife-of-clifton-powell-during-2005-h-e-r-b-i-e-awards-presented-by-the-rhythm-blues.jpg?s=612x612&w=gi&k=20&c=YTLTn0b4L7HeFtCJL_kVpVJF_lE1f8BsQ-CZ_JVKdio=) <small>www.gettyimages.co.uk</small>379 Clifton Powell Stock Photos, High-Res Pictures, and Images - Getty Images

Clifton Powell's Love Life- Married Or Divorced?
------------------------------------------------

 ![Clifton Powell's Love Life- Married or Divorced?](https://liverampup.com/uploads/clifton-powell-with-girlfriend-kita.JPG) <small>liverampup.com</small>Clifton Powell's Love Life- Married or Divorced?

379 Clifton Powell Stock Photos, High-Res Pictures, And Images - Getty Images
-----------------------------------------------------------------------------

 ![379 Clifton Powell Stock Photos, High-Res Pictures, and Images - Getty Images](https://media.gettyimages.com/id/79508949/photo/clifton-powell-and-wife-kimberly.jpg?s=612x612&w=gi&k=20&c=D7ixwqgBqO7xspOZ3Cu8sxkLYigO88usB0BTG8cKCaU=) <small>www.gettyimages.co.uk</small>379 Clifton Powell Stock Photos, High-Res Pictures, and Images - Getty Images

Clifton Powell And Wife Kimberly During 11th Annual Screen Actors... | WireImage | 130312531
--------------------------------------------------------------------------------------------

 ![Clifton Powell and wife Kimberly during 11th Annual Screen Actors... | WireImage | 130312531](https://i.pinimg.com/originals/97/72/55/977255b7c874047824f1ac2bd2fa6787.jpg) <small>www.pinterest.com</small>Clifton Powell and wife Kimberly during 11th Annual Screen Actors... | WireImage | 130312531 ...

Clifton Powell Wife Kim Editorial Stock Photo - Stock Image | Shutterstock
--------------------------------------------------------------------------

 ![Clifton Powell Wife Kim Editorial Stock Photo - Stock Image | Shutterstock](https://editorial01.shutterstock.com/preview-440/4372122m/e919ffac/Shutterstock_4372122m.jpg) <small>www.shutterstock.com</small>Clifton Powell Wife Kim Editorial Stock Photo - Stock Image | Shutterstock

Actor Clifton Powell (C) Attends The 18th Annual BET Awards At Microsoft Theater In Los Angeles
-----------------------------------------------------------------------------------------------

 ![Actor Clifton Powell (C) attends the 18th annual BET Awards at Microsoft Theater in Los Angeles](https://c8.alamy.com/comp/TY836B/actor-clifton-powell-c-attends-the-18th-annual-bet-awards-at-microsoft-theater-in-los-angeles-on-june-24-2018-the-ceremony-celebrates-achievements-in-entertainment-and-honors-music-sports-television-and-movies-released-between-april-1-2017-and-march-31-2018-photo-by-gregg-deguireupi-TY836B.jpg) <small>www.alamy.com</small>Actor Clifton Powell (C) attends the 18th annual BET Awards at Microsoft Theater in Los Angeles ...

The 36th Naacp Image Awards Arrivals Photos And Premium High Res Pictures - Getty Images
----------------------------------------------------------------------------------------

 ![The 36th Naacp Image Awards Arrivals Photos and Premium High Res Pictures - Getty Images](https://media.gettyimages.com/id/52457971/photo/actor-clifton-powell-and-his-family-arrive-at-the-36th-naacp-image-awards-at-the-dorothy.jpg?s=612x612&w=gi&k=20&c=OPKvh5kUADrVVPyPHTwfHOlUg8Nm9Nd-Uq7gzYdt1Xw=) <small>www.gettyimages.dk</small>The 36th Naacp Image Awards Arrivals Photos and Premium High Res Pictures - Getty Images

Clifton Powell Net Worth, Siblings, Family, Children, Biography - Net Worth Post
--------------------------------------------------------------------------------

 ![Clifton Powell Net Worth, Siblings, Family, Children, Biography - Net Worth Post](https://networthpost.com/wp-content/uploads/2024/03/gettyimages-105567375-1024x1024-1.jpg) <small>networthpost.com</small>Clifton Powell Net Worth, Siblings, Family, Children, Biography - Net Worth Post

New York, USA. 04th Sep, 2024. Clifton Powell Attends Peacock's "Fight Night: The Million Dollar
------------------------------------------------------------------------------------------------

 ![New York, USA. 04th Sep, 2024. Clifton Powell attends Peacock's "Fight Night: The Million Dollar](https://c8.alamy.com/comp/2Y1A3X9/new-york-usa-04th-sep-2024-clifton-powell-attends-peacocks-fight-night-the-million-dollar-heist-world-premiere-at-jazz-at-lincoln-center-on-september-04-2024-in-new-york-city-photo-jeremy-smithimagespacesipa-usa-credit-sipa-usaalamy-live-news-2Y1A3X9.jpg) <small>www.alamy.com</small>New York, USA. 04th Sep, 2024. Clifton Powell attends Peacock's "Fight Night: The Million Dollar ...

Photos And Pictures - Clifton Powell, Wife Kim And Nephew At The Premiere Of New Line Cinema's
----------------------------------------------------------------------------------------------

 ![Photos and Pictures - Clifton Powell, wife Kim and Nephew at the premiere of New Line Cinema's](https://static8.imagecollect.com/preview/137/6ab644243b7f373) <small>imagecollect.com</small>Photos and Pictures - Clifton Powell, wife Kim and Nephew at the premiere of New Line Cinema's ...

Who Is Clifton Powell Jr? Sasha Obama Dating Scriptwriter Son
-------------------------------------------------------------

 ![Who Is Clifton Powell Jr? Sasha Obama Dating Scriptwriter Son](https://data.ibtimes.sg/en/full/5600/a-timeline-of-obamas-nostalgic-journey-as-a-president.jpg?w=736) <small>www.ibtimes.sg</small>Who Is Clifton Powell Jr? Sasha Obama Dating Scriptwriter Son ...

Who Is Clifton Powell From “Menace To Society”? Bio: Net Worth, Wife
--------------------------------------------------------------------

 ![Who is Clifton Powell from “Menace to Society”? Bio: Net Worth, Wife](https://biographytribune.com/wp-content/uploads/2018/11/Clifton-Powell-4.jpg) <small>biographytribune.com</small>Who is Clifton Powell from “Menace to Society”? Bio: Net Worth, Wife

Nov. 13, 2002 - Westwood, CALIFORNIA, USA - K27137TR FRIDAY AFTER NEXT MOVIE PREMIERE.MANN
------------------------------------------------------------------------------------------

 ![Nov. 13, 2002 - Westwood, CALIFORNIA, USA - K27137TR FRIDAY AFTER NEXT MOVIE PREMIERE.MANN](https://c8.alamy.com/comp/DN77B8/nov-13-2002-westwood-california-usa-k27137tr-friday-after-next-movie-DN77B8.jpg) <small>www.alamy.com</small>Nov. 13, 2002 - Westwood, CALIFORNIA, USA - K27137TR FRIDAY AFTER NEXT MOVIE PREMIERE.MANN ...

351 Clifton Powell Stock Photos, High-Res Pictures, And Images - Getty Images
-----------------------------------------------------------------------------

 ![351 Clifton Powell Stock Photos, High-Res Pictures, and Images - Getty Images](https://media.gettyimages.com/id/115378384/photo/clifton-powell-and-his-wife-kim-powell-during-2005-h-e-r-b-i-e-awards-presented-by-the-rhythm.jpg?s=612x612&w=gi&k=20&c=vdjJPdyf3hxFqj5mfpTCdnLh1yET1k6yKVlyxF1p8bY=) <small>www.gettyimages.co.uk</small>351 Clifton Powell Stock Photos, High-Res Pictures, and Images - Getty Images

92 Clifton Powell Stock Pictures, Editorial Images And Stock Photos | Shutterstock Editorial
--------------------------------------------------------------------------------------------

 ![92 Clifton Powell Stock Pictures, Editorial Images and Stock Photos | Shutterstock Editorial](https://www.shutterstock.com/editorial/image-editorial/NeDcMa55O3Ddg9x4ODI2Nw==/clifton-powell-wife-kim-440nw-4372122b.jpg) <small>www.shutterstock.com</small>92 Clifton Powell Stock Pictures, Editorial Images and Stock Photos | Shutterstock Editorial

Clifton Powell Wife Kim Editorial Stock Photo - Stock Image | Shutterstock
--------------------------------------------------------------------------

 ![Clifton Powell Wife Kim Editorial Stock Photo - Stock Image | Shutterstock](https://editorial01.shutterstock.com/preview-440/4372122c/bd80acb5/Shutterstock_4372122c.jpg) <small>www.shutterstock.com</small>Clifton Powell Wife Kim Editorial Stock Photo - Stock Image | Shutterstock

Clifton Powell Photos And Premium High Res Pictures - Getty Images
------------------------------------------------------------------

 ![Clifton Powell Photos and Premium High Res Pictures - Getty Images](https://media.gettyimages.com/id/988071808/photo/clifton-powell-arrives-to-the-2018-bet-awards-held-at-microsoft-theater-on-june-24-2018-in-los.jpg?s=612x612&w=gi&k=20&c=2FINkFygb7z2_KC0w6yw2FzRZmonzccju0zmrCtjOb4=) <small>www.gettyimages.dk</small>Clifton Powell Photos and Premium High Res Pictures - Getty Images

Meet Sasha Obama's BOYFRIEND: Inside Daughter Of Former President Barack Obama's Budding New
--------------------------------------------------------------------------------------------

 ![Meet Sasha Obama's BOYFRIEND: Inside daughter of former President Barack Obama's budding new](https://i.dailymail.co.uk/1s/2022/04/21/19/56887265-10739881-The_second_child_of_actor_Clifton_Powell_66_and_his_wife_Kimberl-a-7_1650564483151.jpg) <small>www.dailymail.com</small>Meet Sasha Obama's BOYFRIEND: Inside daughter of former President Barack Obama's budding new ...

Clifton Powell And Family – Stock Editorial Photo © S\_bukley #15960511
-----------------------------------------------------------------------

 ![Clifton Powell and family – Stock Editorial Photo © s_bukley #15960511](https://st.depositphotos.com/1814084/1596/i/950/depositphotos_15960511-stock-photo-clifton-powell-and-family.jpg) <small>depositphotos.com</small>Clifton Powell and family – Stock Editorial Photo © s\_bukley #15960511

Clifton Powell Wife Kim Editorial Stock Photo - Stock Image | Shutterstock
--------------------------------------------------------------------------

 ![Clifton Powell Wife Kim Editorial Stock Photo - Stock Image | Shutterstock](https://editorial01.shutterstock.com/preview-440/4372122a/37cc8d57/Shutterstock_4372122a.jpg) <small>www.shutterstock.com</small>Clifton Powell Wife Kim Editorial Stock Photo - Stock Image | Shutterstock

Actor Clifton Powell And His Wife Kimberly Powell Attend The "Genius:... News Photo - Getty Images
--------------------------------------------------------------------------------------------------

 ![Actor Clifton Powell and his wife Kimberly Powell attend the "Genius:... News Photo - Getty Images](https://media.gettyimages.com/id/51456961/photo/cbs-ray-charles-tribute-with-jamie-foxx-and-other-celebs-arrivals.jpg?s=1024x1024&w=gi&k=20&c=OUZo6DaUiLNLB3C59_Jv9SSLRGS4n_z9vnstMJGqMwg=) <small>www.gettyimages.com</small>Actor Clifton Powell and his wife Kimberly Powell attend the "Genius:... News Photo - Getty Images

Clifton Powell Wife Kim Editorial Stock Photo - Stock Image | Shutterstock
--------------------------------------------------------------------------

 ![Clifton Powell Wife Kim Editorial Stock Photo - Stock Image | Shutterstock](https://editorial01.shutterstock.com/preview-440/5137138m/ad89a64a/Shutterstock_5137138m.jpg) <small>www.shutterstock.com</small>Clifton Powell Wife Kim Editorial Stock Photo - Stock Image | Shutterstock

️Celebrity Marriages.. Ray Actor Clifton Powell Marriage Transformation - YouTube
---------------------------------------------------------------------------------

 ![️Celebrity Marriages.. Ray Actor Clifton Powell Marriage Transformation - YouTube](https://i.ytimg.com/vi/WirXLqO4R40/oardefault.jpg?sqp=-oaymwEkCJUDENAFSFqQAgHyq4qpAxMIARUAAAAAJQAAyEI9AICiQ3gB&rs=AOn4CLA6Wm0QZIqOhQgAicHhdnxEG_bewg) <small>www.youtube.com</small>️Celebrity Marriages.. Ray Actor Clifton Powell Marriage Transformation - YouTube

Actor Clifton Powell And Wife Arrives At The Tribute Concert For The... News Photo - Getty Images
-------------------------------------------------------------------------------------------------

 ![Actor Clifton Powell and wife arrives at the tribute concert for the... News Photo - Getty Images](https://media.gettyimages.com/id/525052134/photo/a-night-for-ray-charles-in-los-angeles.jpg?s=594x594&w=gi&k=20&c=LKgCg_35hxZz2OHZDxuvT7nPKGQu3FvuLDYnccNeCbg=) <small>www.gettyimages.ca</small>Actor Clifton Powell and wife arrives at the tribute concert for the... News Photo - Getty Images

Photos And Pictures - Clifton Powell, Wife Kim And Nephew At The Premiere Of New Line Cinema's
----------------------------------------------------------------------------------------------

 ![Photos and Pictures - Clifton Powell, wife Kim and Nephew at the premiere of New Line Cinema's](http://imagecollect.com/picture/clifton-powell-photo-3648428/friday-after-next-premiere.jpg) <small>imagecollect.com</small>Photos and Pictures - Clifton Powell, wife Kim and Nephew at the premiere of New Line Cinema's ...

Singer Clifton Powell And His Wife Attend The Finale Of The Verizon... News Photo - Getty Images
------------------------------------------------------------------------------------------------

 ![Singer Clifton Powell and his wife attend the finale of the Verizon... News Photo - Getty Images](https://media.gettyimages.com/id/83624896/photo/verizon-wireless-how-sweet-the-sound-national-gospel-competition.jpg?s=594x594&w=gi&k=20&c=YhNUTLXtCDivceOEYtUsT59S2srfK11WH0VCo-JE0WQ=) <small>www.gettyimages.com</small>Singer Clifton Powell and his wife attend the finale of the Verizon... News Photo - Getty Images

Clifton Powell's Love Life- Married Or Divorced?
------------------------------------------------

 ![Clifton Powell's Love Life- Married or Divorced?](https://liverampup.com/uploads/clifton-powell-with-ex-wife.JPG) <small>liverampup.com</small>Clifton Powell's Love Life- Married or Divorced?

Everything We Know About Sasha Obama's New Boyfriend And His Famous Father
--------------------------------------------------------------------------

 ![Everything We Know About Sasha Obama's New Boyfriend And His Famous Father](https://www.thelist.com/img/gallery/everything-we-know-about-sasha-obamas-new-boyfriend-and-his-famous-father/clifton-powell-sr-raised-his-family-in-a-wealthy-community-1650649036.jpg) <small>www.thelist.com</small>Everything We Know About Sasha Obama's New Boyfriend And His Famous Father

351 Clifton Powell Stock Photos, High-Res Pictures, And Images - Getty Images
-----------------------------------------------------------------------------

 ![351 Clifton Powell Stock Photos, High-Res Pictures, and Images - Getty Images](https://media.gettyimages.com/id/115378383/photo/clifton-powell-and-his-wife-kim-powell-during-2005-h-e-r-b-i-e-awards-presented-by-the-rhythm.jpg?s=612x612&w=gi&k=20&c=7AgZ_sTybfZzVYy50eaenZeuXHRfwTjVm91nD5TQROk=) <small>www.gettyimages.co.uk</small>351 Clifton Powell Stock Photos, High-Res Pictures, and Images - Getty Images

351 clifton powell stock photos, high-res pictures, and images. Who is clifton powell jr? sasha obama dating scriptwriter son .... 💞 clifton powell and wife kimberly powell a love that’s outlasted hollywood!
