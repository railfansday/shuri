---
title: "Kimberly Powell Wikipedia - Kimberly powell honored for pioneering work in health informatics and gerontology"
description: "Breaking: nvidia ceo jensen huang exposed for having a second affair with nvidia executive"
date: "2026-03-20"
categories:
- "Uncategorized"
images:
- "https://cdn.milenio.com/uploads/media/2026/11/12/kimberly-powell-ejecutiva-nvidia-relacionada.jpg"
featuredImage: "https://c.ndtvimg.com/2026-11/tc1q8iag_kimberly-powell_625x300_12_November_26.jpeg"
featured_image: "https://bitcoinfoundation.org/wp-content/uploads/2026/11/kimberly-powell-cancels-health-summit-appearance-after-nvidia-ceo-relationship-r.webp"
image: "https://celebsfortune.com/wp-content/uploads/2026/11/kimberly-powell-picture.jpg"
---

If you are looking for BREAKING: Nvidia CEO Jensen Huang exposed for having a second affair with Nvidia executive you've came to the right place. We have 35 Pictures about BREAKING: Nvidia CEO Jensen Huang exposed for having a second affair with Nvidia executive like Kimberly Powell-Jensen Huang Alleged Affair: What Nvidia's Cod..., Watch: Jensen Huang’s reported extramarital partner Kimberly Powell walks the show floor in and also Nvidia's Kimberly Powell is leading the chip giant's charge into AI for health care - Bizwomen. Here it is:

BREAKING: Nvidia CEO Jensen Huang Exposed For Having A Second Affair With Nvidia Executive
------------------------------------------------------------------------------------------

 ![BREAKING: Nvidia CEO Jensen Huang exposed for having a second affair with Nvidia executive](https://www.lipstickalley.com/data/assets/logo/LipstickAlleyNeonSignrectangle.png) <small>www.lipstickalley.com</small>BREAKING: Nvidia CEO Jensen Huang exposed for having a second affair with Nvidia executive ...

Nvidia's Kimberly Powell Is Leading The Chip Giant's Charge Into AI For Health Care - Bizwomen
----------------------------------------------------------------------------------------------

 ![Nvidia's Kimberly Powell is leading the chip giant's charge into AI for health care - Bizwomen](https://media.bizj.us/view/img/12968502/kimberlypowell-1*800xx9428-5303-0-491.jpg) <small>www.bizjournals.com</small>Nvidia's Kimberly Powell is leading the chip giant's charge into AI for health care - Bizwomen

Kimberly Powell Chez Nvidia : Son Rôle Dans L’IA Médicale Au 12 Novembre 2026
-----------------------------------------------------------------------------

 ![Kimberly Powell chez Nvidia : son rôle dans l’IA médicale au 12 novembre 2026](https://www.webtech360.com/resources_cts/images2/kimberly-powell-quem-e-a-lider-de-ia-em-saude-da_319532148.webp) <small>fr.webtech360.com</small>Kimberly Powell chez Nvidia : son rôle dans l’IA médicale au 12 novembre 2026

Who Is Kimberly Powell? Nvidia Executive Who Had Affair With CEO Jensen Huang
-----------------------------------------------------------------------------

 ![Who Is Kimberly Powell? Nvidia Executive Who Had Affair With CEO Jensen Huang](https://c.ndtvimg.com/2026-11/atbds6hc_kimberly-powell_625x300_12_November_26.jpeg?im=FaceCrop,algorithm=dnn,width=1600,height=900) <small>www.ndtv.com</small>Who Is Kimberly Powell? Nvidia Executive Who Had Affair With CEO Jensen Huang

Kimberly Powell-Jensen Huang Alleged Affair: What Nvidia's Cod...
-----------------------------------------------------------------

 ![Kimberly Powell-Jensen Huang Alleged Affair: What Nvidia's Cod...](https://data.ibtimes.sg/en/full/99518/kimberly-powell.jpg?w=736) <small>www.ibtimes.sg</small>Kimberly Powell-Jensen Huang Alleged Affair: What Nvidia's Cod...

Kimberly Powell's 18-Year Journey At Nvidia Draws Attention After Personal Links With CEO Jensen
------------------------------------------------------------------------------------------------

 ![Kimberly Powell's 18-Year Journey At Nvidia Draws Attention After Personal Links With CEO Jensen](https://images.thedailyjagran.com/images/2026/11/12/template/image/Kimberlypowell-1794456712201.webp) <small>www.thedailyjagran.com</small>Kimberly Powell's 18-Year Journey At Nvidia Draws Attention After Personal Links With CEO Jensen ...

Kim Powell Bio, Wiki, Age, Height, Parents, Husband, Salary, Net Worth, And 3TV
-------------------------------------------------------------------------------

 ![Kim Powell Bio, Wiki, Age, Height, Parents, Husband, Salary, Net Worth, and 3TV](https://credible-wiki.com/wp-content/uploads/2024/01/Kim-Powell-Photo-300x300.jpg) <small>credible-wiki.com</small>Kim Powell Bio, Wiki, Age, Height, Parents, Husband, Salary, Net Worth, and 3TV

NVIDIA VP Kimberly Powell Announced Resignation Or Remova... 2026 | Polymarket
------------------------------------------------------------------------------

 ![NVIDIA VP Kimberly Powell announced resignation or remova... 2026 | Polymarket](https://polymarket.com/api/og?eslug=nvidia-vp-kimberly-powell-announced-resignation-or-removal-byptptpt&tid=1794481024899) <small>polymarket.com</small>NVIDIA VP Kimberly Powell announced resignation or remova... 2026 | Polymarket

Kimberly Powell Biography: Age, Nvidia Healthcare Career And The Jensen Huang Report – The
------------------------------------------------------------------------------------------

 ![Kimberly Powell Biography: Age, Nvidia Healthcare Career and the Jensen Huang Report – The](https://jaisalmernews.com/wp-content/uploads/2026/11/kimberly-powell-biography-cover.webp) <small>jaisalmernews.com</small>Kimberly Powell Biography: Age, Nvidia Healthcare Career and the Jensen Huang Report – The ...

Kim Powell Bio, Age, Family, 3TV, Husband, Height, Salary, Net Worth – Celebrity
--------------------------------------------------------------------------------

 ![Kim Powell Bio, Age, Family, 3TV, Husband, Height, Salary, Net Worth – Celebrity](https://cdn.file.com.es/clb/2022/10/16012746/Kim-Powell-2-400x381.jpg) <small>celebrity.com.es</small>Kim Powell Bio, Age, Family, 3TV, Husband, Height, Salary, Net Worth – Celebrity

Who Is Graham Gerade? What To Know About Kimberly Powell's Husband Amid Jensen Huang Controversy
------------------------------------------------------------------------------------------------

 ![Who is Graham Gerade? What to know about Kimberly Powell's husband amid Jensen Huang controversy](https://img.etimg.com/thumb/msid-135757356,width-950,height-600,imgsize-55824,resizemode-75/image-of-kimberly-powell.jpg) <small>economictimes.indiatimes.com</small>Who is Graham Gerade? What to know about Kimberly Powell's husband amid Jensen Huang controversy ...

Kimberly Powell, The Engineer Who Became Nvidia's Healthcare VP And Is Now Caught In The Jensen
-----------------------------------------------------------------------------------------------

 ![Kimberly Powell, the engineer who became Nvidia's healthcare VP and is now caught in the Jensen](https://www.asiaone.com/sites/default/files/styles/article_top_image/public/original_images/Nov2026/kimberly-powell-nvidia-facebook (1).jpg?itok=hIIek7fk) <small>www.asiaone.com</small>Kimberly Powell, the engineer who became Nvidia's healthcare VP and is now caught in the Jensen ...

Kimberly Powell Biography: Net Worth, Lifestyle &amp; Success Story | Gen-z Bio - YouTube
-----------------------------------------------------------------------------------------

 ![Kimberly Powell Biography: Net Worth, Lifestyle & Success Story | Gen-z Bio - YouTube](https://i.ytimg.com/vi/KWlhh49Nh18/maxres2.jpg?sqp=-oaymwEoCIAKENAF8quKqQMcGADwAQH4AbYIgAKAD4oCDAgAEAEYciBLKEIwDw==&rs=AOn4CLD4hVZeJqrNtcNMJybmuwutd5NWtg) <small>www.youtube.com</small>Kimberly Powell Biography: Net Worth, Lifestyle &amp; Success Story | Gen-z Bio - YouTube

¿Quién Es Kimberly Powell, Ligada A Jensen Huang, Ex Ceo De Nvidia?- Grupo Milenio
----------------------------------------------------------------------------------

 ![¿Quién es Kimberly Powell, ligada a Jensen Huang, ex Ceo de Nvidia?- Grupo Milenio](https://cdn.milenio.com/uploads/media/2026/11/12/kimberly-powell-ejecutiva-nvidia-relacionada.jpg) <small>www.milenio.com</small>¿Quién es Kimberly Powell, ligada a Jensen Huang, ex Ceo de Nvidia?- Grupo Milenio

Who Is Kimberly Powell, Nvidia Exec Alleged To Have A Relationship With CEO Jensen Huang
----------------------------------------------------------------------------------------

 ![Who is Kimberly Powell, Nvidia exec alleged to have a relationship with CEO Jensen Huang](https://images.news9live.com/wp-content/uploads/2026/11/kimberly.png) <small>www.news9live.com</small>Who is Kimberly Powell, Nvidia exec alleged to have a relationship with CEO Jensen Huang ...

Who Is Kimberly Powell, Nvidia Executive Who Had Affair With CEO Jensen Huang?
------------------------------------------------------------------------------

 ![Who Is Kimberly Powell, Nvidia Executive Who Had Affair With CEO Jensen Huang?](https://c.ndtvimg.com/2026-11/9ks3vb1s_kimberly-powell_625x300_12_November_26.jpeg?downsize=723:486) <small>www.ndtv.com</small>Who Is Kimberly Powell, Nvidia Executive Who Had Affair With CEO Jensen Huang?

Kimberly Powell (Nvidia) Wiki, Age, Husband &amp; Salary
--------------------------------------------------------

 ![Kimberly Powell (Nvidia) Wiki, Age, Husband & Salary](https://wikiofcelebrities.com/wp-content/uploads/2026/11/Kimberly-Powell.webp) <small>wikiofcelebrities.com</small>Kimberly Powell (Nvidia) Wiki, Age, Husband &amp; Salary

Kimberly Powell: Il Ruolo Nell’IA Medica Di NVIDIA E I Progetti Aggiornati Al 12 Novembre 2026
----------------------------------------------------------------------------------------------

 ![Kimberly Powell: il ruolo nell’IA medica di NVIDIA e i progetti aggiornati al 12 novembre 2026](https://www.webtech360.com/resources_cts/images2/kimberly-powell-chez-nvidia-son-role-dans-lia_885489594.webp) <small>it.webtech360.com</small>Kimberly Powell: il ruolo nell’IA medica di NVIDIA e i progetti aggiornati al 12 novembre 2026

Jensen Huang Did Not Have Sẹxual Relations With That Woman, Kimberly Powell - Wikipedia
---------------------------------------------------------------------------------------

 ![Jensen Huang did not have sẹxual relations with that woman, Kimberly Powell - Wikipedia](https://upload.wikimedia.org/wikipedia/commons/c/c4/Jensen_Huang_(cropped).jpg?utm_source=en.wikipedia.org&utm_campaign=index&utm_content=thumbnail_unscaled) <small>en.wikipedia.org</small>Jensen Huang did not have sẹxual relations with that woman, Kimberly Powell - Wikipedia

Kimberly Powell Nvidia: Summit Exit After Huang Report
------------------------------------------------------

 ![Kimberly Powell Nvidia: Summit Exit After Huang Report](https://bitcoinfoundation.org/wp-content/uploads/2026/11/kimberly-powell-cancels-health-summit-appearance-after-nvidia-ceo-relationship-r.webp) <small>bitcoinfoundation.org</small>Kimberly Powell Nvidia: Summit Exit After Huang Report

Kimberly Powell's Family: Meet Her Husband Graham &amp; 2 Kids
--------------------------------------------------------------

 ![Kimberly Powell's Family: Meet Her Husband Graham & 2 Kids](https://celebsindepth.com/wp-content/uploads/2026/11/kimberly-powell-husband-and-children.jpg) <small>celebsindepth.com</small>Kimberly Powell's Family: Meet Her Husband Graham &amp; 2 Kids

Watch: Jensen Huang’s Reported Extramarital Partner Kimberly Powell Walks The Show Floor In
-------------------------------------------------------------------------------------------

 ![Watch: Jensen Huang’s reported extramarital partner Kimberly Powell walks the show floor in](https://img.etimg.com/thumb/msid-135754452,width-950,height-600,imgsize-130156,resizemode-75/jensen-huangs-former-partner-kimberly-powell-walks-the-show-floor-in-nvidia-videobr.jpg) <small>economictimes.indiatimes.com</small>Watch: Jensen Huang’s reported extramarital partner Kimberly Powell walks the show floor in ...

Kimberly Powell Honored For Pioneering Work In Health Informatics And Gerontology
---------------------------------------------------------------------------------

 ![Kimberly Powell honored for pioneering work in health informatics and gerontology](https://nursing.missouri.edu/wp-content/uploads/2024/06/Kimberly-Powell-FAMIA-induction.png) <small>nursing.missouri.edu</small>Kimberly Powell honored for pioneering work in health informatics and gerontology

Who Is Kimberly Powell, Nvidia Executive Who Had Affair With CEO Jensen Huang?
------------------------------------------------------------------------------

 ![Who Is Kimberly Powell, Nvidia Executive Who Had Affair With CEO Jensen Huang?](https://c.ndtvimg.com/2026-11/tc1q8iag_kimberly-powell_625x300_12_November_26.jpeg) <small>www.ndtv.com</small>Who Is Kimberly Powell, Nvidia Executive Who Had Affair With CEO Jensen Huang?

Kimberly Powell Had Affair With Jensen Huang, NYT Reports
---------------------------------------------------------

 ![Kimberly Powell had affair with Jensen Huang, NYT reports](https://www.nacionale.com/_next/image?url=https:%2F%2Fmedia.nacionale.kabineti.net%2Fuploads%2Fkimberly_powell_nvidia_illustration_5a1969db6f.jpg&w=828&q=85) <small>www.nacionale.com</small>Kimberly Powell had affair with Jensen Huang, NYT reports

Who Is Kimberly Powell, The Nvidia Executive Linked To CEO Jensen Huang? | Republic World
-----------------------------------------------------------------------------------------

 ![Who Is Kimberly Powell, the Nvidia Executive Linked to CEO Jensen Huang? | Republic World](https://img.republicworld.com/all_images/2026/11/who-is-kimberly-powell-the-nvidia-executive-linked-to-ceo-jensen-huang-1794455712889-1280x720.webp?w=1280&h=720&q=75&format=webp) <small>www.republicworld.com</small>Who Is Kimberly Powell, the Nvidia Executive Linked to CEO Jensen Huang? | Republic World

Before Nvidia, Kimberly Powell Was An Engineering…
--------------------------------------------------

 ![Before Nvidia, Kimberly Powell was an engineering…](https://images.inkl.com/s3/article/lead_image/24056025/135773875.jpg) <small>www.inkl.com</small>Before Nvidia, Kimberly Powell was an engineering…

After Chinese Spy Scandal: Nvidia CEO Caught In Another Scandalous Affair | Dagens.com
--------------------------------------------------------------------------------------

 ![After Chinese spy scandal: Nvidia CEO caught in another scandalous affair | Dagens.com](https://media.mgdk.dk/wp-content/uploads/sites/2/2026/11/Donald-Trump-and-Jensen-Huang.webp) <small>www.dagens.com</small>After Chinese spy scandal: Nvidia CEO caught in another scandalous affair | Dagens.com

Kim Powell Leaves KTVK 3/KPHO 5 Phoenix – PNW Broadcasting History &amp; Current Affairs
----------------------------------------------------------------------------------------

 ![Kim Powell Leaves KTVK 3/KPHO 5 Phoenix – PNW Broadcasting History & Current Affairs](https://qzvx.com/wp-content/uploads/2022/08/Kim-Powell-AZFAMILY3and5.png) <small>www.qzvx.com</small>Kim Powell Leaves KTVK 3/KPHO 5 Phoenix – PNW Broadcasting History &amp; Current Affairs

After Alice Huang, Who Is Kimberly Powell, The Nvidia Executive Linked To CEO Jensen Huang
------------------------------------------------------------------------------------------

 ![After Alice Huang, who is Kimberly Powell, the Nvidia executive linked to CEO Jensen Huang](https://www.indiablooms.com/phoenix/public/storage/assets/n/2026/1794460587854967219.jpg) <small>www.indiablooms.com</small>After Alice Huang, who is Kimberly Powell, the Nvidia executive linked to CEO Jensen Huang ...

Kimberly Powell, Bajo Escrutinio Tras Un Nuevo Reporte Sobre NVIDIA | 12 De Noviembre
-------------------------------------------------------------------------------------

 ![Kimberly Powell, bajo escrutinio tras un nuevo reporte sobre NVIDIA | 12 de noviembre](https://www.webtech360.com/resources_cts/images2/nvidia-et-kimberly-powell-enquete-incertitudes-et_640811521.webp) <small>es.webtech360.com</small>Kimberly Powell, bajo escrutinio tras un nuevo reporte sobre NVIDIA | 12 de noviembre

Kimberly Powell: How Married Nvidia Healthcare VP Rose Through...
-----------------------------------------------------------------

 ![Kimberly Powell: How Married Nvidia Healthcare VP Rose Through...](https://data.ibtimes.sg/en/full/99508/kimberly-powell.jpg?w=736) <small>www.ibtimes.sg</small>Kimberly Powell: How Married Nvidia Healthcare VP Rose Through...

Kimberly Powell Editorial Stock Photo - Stock Image | Shutterstock Editorial
----------------------------------------------------------------------------

 ![Kimberly Powell Editorial Stock Photo - Stock Image | Shutterstock Editorial](https://www.shutterstock.com/editorial/image-editorial/MfT4Qcy7N9j7c5x6NzM3MTc=/kimberly-powell-1500w-14136080dr.jpg) <small>www.shutterstock.com</small>Kimberly Powell Editorial Stock Photo - Stock Image | Shutterstock Editorial

Urgent: Kimberly Powell NVIDIA Update Not In Latest Release
-----------------------------------------------------------

 ![Urgent: Kimberly Powell NVIDIA Update Not in Latest Release](https://thegadgetscentral.com/wp-content/uploads/2026/11/kimberly-powell-nvidia_1794436202.jpg) <small>thegadgetscentral.com</small>Urgent: Kimberly Powell NVIDIA Update Not in Latest Release

Kimberly Powell's Net Worth (2026) &amp; NVIDIA Salary Revealed
---------------------------------------------------------------

 ![Kimberly Powell's Net Worth (2026) & NVIDIA Salary Revealed](https://celebsfortune.com/wp-content/uploads/2026/11/kimberly-powell-picture.jpg) <small>celebsfortune.com</small>Kimberly Powell's Net Worth (2026) &amp; NVIDIA Salary Revealed

kimberly powell: il ruolo nell’ia medica di nvidia e i progetti aggiornati al 12 novembre 2026. kimberly powell's net worth (2026) &amp; nvidia salary revealed. kimberly powell, bajo escrutinio tras un nuevo reporte sobre nvidia
