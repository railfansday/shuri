---
title: "Vitinha Portugal Number - Vitinha 23 (dorsal oficial)"
description: "Portugal&#039;s vitinha during the 2026 fifa world cup european qualifying, group f match at the"
date: "2026-06-09"
categories:
- "Uncategorized"
images:
- "https://c8.alamy.com/comp/3CYE9X1/portugals-vitinha-attempts-a-shot-at-goal-during-a-world-cup-2026-group-f-qualifying-soccer-match-between-portugal-and-hungary-in-lisbon-tuesday-oct-14-2025-ap-photoarmando-franca-3CYE9X1.jpg"
featuredImage: "https://trivela.fr/wp-content/uploads/2024/03/portugal-v-nigeria-friendly-game-4-scaled-1.jpeg"
featured_image: "https://static1.cdn-subsidesports.com/2/media/catalog/product/cache/38d4094f49a5c2931b615f53f1250097/5/0/502e7c1b30cbe8d9397b686ee11d2cb0fc46bb875edc7b27c038873fb2a62d58.jpeg"
image: "https://c8.alamy.com/comp/2XG23MC/vitinha-of-portugal-during-the-uefa-euro-2024-quarter-final-football-match-between-portugal-and-france-on-july-5-2024-at-volksparkstadion-in-hamburg-germany-credit-independent-photo-agencyalamy-live-news-2XG23MC.jpg"
---

If you are searching about Portugal Shirt Thuis 2025-2026 + Vitinha 23 you've came to the right web. We have 35 Pics about Portugal Shirt Thuis 2025-2026 + Vitinha 23 like Vitinha 23 (Dorsal Oficial) - 26-27 Portugal Local, Puma Portugal Home Vitinha 23 Shirt 2026-2027 (Official Printing) and also Football Idol Numbers 2025 Portugal Home BERNARDO Football Jersey Number VITINHA Team numbers. Here it is:

Portugal Shirt Thuis 2025-2026 + Vitinha 23
-------------------------------------------

 ![Portugal Shirt Thuis 2025-2026 + Vitinha 23](https://static1.cdn-subsidesports.com/2/media/catalog/product/cache/38d4094f49a5c2931b615f53f1250097/9/e/9e48d0c79f9684e705821f1bbea916a97fd7c0850dd5a54b5635e84b5c4f15cb.jpeg) <small>www.subsidesports.nl</small>Portugal Shirt Thuis 2025-2026 + Vitinha 23

FRANKFURT - Vitinha Of Portugal During The UEFA EURO 2024 Round Of 16 Match Between Portugal And
------------------------------------------------------------------------------------------------

 ![FRANKFURT - Vitinha of Portugal during the UEFA EURO 2024 round of 16 match between Portugal and](https://c8.alamy.com/comp/2XGE28T/frankfurt-vitinha-of-portugal-during-the-uefa-euro-2024-round-of-16-match-between-portugal-and-slovenia-at-frankfurt-arena-on-july-1-2024-in-frankfurt-germany-anp-hollandse-hoogte-gerrit-van-keulen-2XGE28T.jpg) <small>www.alamy.com</small>FRANKFURT - Vitinha of Portugal during the UEFA EURO 2024 round of 16 match between Portugal and ...

Puma Portugal Home Vitinha 23 Shirt 2026-2027 (Official Printing)
-----------------------------------------------------------------

 ![Puma Portugal Home Vitinha 23 Shirt 2026-2027 (Official Printing)](https://static1.cdn-subsidesports.com/2/media/catalog/product/cache/38d4094f49a5c2931b615f53f1250097/8/d/8d73290ecc10262ba766db0d1bb32167b247b38c7ce69e445c336a0616970f87.jpeg) <small>www.subside.com.au</small>Puma Portugal Home Vitinha 23 Shirt 2026-2027 (Official Printing)

Quarter Final Uefa Euro 2024 Hi-res Stock Photography And Images - Alamy
------------------------------------------------------------------------

 ![Quarter final uefa euro 2024 hi-res stock photography and images - Alamy](https://c8.alamy.com/comp/2XG23MC/vitinha-of-portugal-during-the-uefa-euro-2024-quarter-final-football-match-between-portugal-and-france-on-july-5-2024-at-volksparkstadion-in-hamburg-germany-credit-independent-photo-agencyalamy-live-news-2XG23MC.jpg) <small>www.alamy.com</small>Quarter final uefa euro 2024 hi-res stock photography and images - Alamy

Vitinha 23 (Official Printing) - 25-26 Portugal Home
----------------------------------------------------

 ![Vitinha 23 (Official Printing) - 25-26 Portugal Home](https://static1.cdn-subsidesports.com/2/media/catalog/product/cache/38d4094f49a5c2931b615f53f1250097/a/0/a05935197420b74e0c04c894f63c35018cc3a71cd48f5d96dd8cf9cef9015da3.jpeg) <small>www.subsidesports.com</small>Vitinha 23 (Official Printing) - 25-26 Portugal Home

Portugal's Vitinha Attempts A Shot At Goal During A World Cup 2026 Group F Qualifying Soccer
--------------------------------------------------------------------------------------------

 ![Portugal's Vitinha attempts a shot at goal during a World Cup 2026 group F qualifying soccer](https://c8.alamy.com/comp/3CYE9X1/portugals-vitinha-attempts-a-shot-at-goal-during-a-world-cup-2026-group-f-qualifying-soccer-match-between-portugal-and-hungary-in-lisbon-tuesday-oct-14-2025-ap-photoarmando-franca-3CYE9X1.jpg) <small>www.alamy.com</small>Portugal's Vitinha attempts a shot at goal during a World Cup 2026 group F qualifying soccer ...

Vitinha Of Portugal During The Portugal Portraits - UEFA Nations... News Photo - Getty Images
---------------------------------------------------------------------------------------------

 ![Vitinha of Portugal during the Portugal Portraits - UEFA Nations... News Photo - Getty Images](https://media.gettyimages.com/id/2218377412/photo/portugal-portraits-uefa-nations-league-2025-finals.jpg?s=612x612&w=gi&k=20&c=A6idYjwIdjQDTCurRu6XBojy_3tGOaJwsFpbsSSPVTM=) <small>www.gettyimages.in</small>Vitinha of Portugal during the Portugal Portraits - UEFA Nations... News Photo - Getty Images

La Drôle De Promesse De Vitinha En Cas De Victoire Du Portugal à L'Euro 2024
----------------------------------------------------------------------------

 ![La drôle de promesse de Vitinha en cas de victoire du Portugal à l'Euro 2024](https://trivela.fr/wp-content/uploads/2024/03/portugal-v-nigeria-friendly-game-4-scaled-1.jpeg) <small>trivela.fr</small>La drôle de promesse de Vitinha en cas de victoire du Portugal à l'Euro 2024

Vitinha Of Portugal In Action During The UEFA Nations League... News Photo - Getty Images
-----------------------------------------------------------------------------------------

 ![Vitinha of Portugal in action during the UEFA Nations League... News Photo - Getty Images](https://media.gettyimages.com/id/2206638957/photo/portugal-v-denmark-uefa-nations-league-quarterfinal-leg-two.jpg?s=1024x1024&w=gi&k=20&c=egyDYrpmHTvf7EyYiVRGRVgfNymbIzICtgx5QOooUNQ=) <small>www.gettyimages.com</small>Vitinha of Portugal in action during the UEFA Nations League... News Photo - Getty Images

Portugals Vitinha Feiert Den Sieg Nach Der UEFA Euro 2024, Dem Achtelfinale In Der Frankfurt
--------------------------------------------------------------------------------------------

 ![Portugals Vitinha feiert den Sieg nach der UEFA Euro 2024, dem Achtelfinale in der Frankfurt](https://c8.alamy.com/compde/2xf7b8f/portugals-vitinha-feiert-den-sieg-nach-der-uefa-euro-2024-dem-achtelfinale-in-der-frankfurt-arena-in-frankfurt-bilddatum-montag-1-juli-2024-2xf7b8f.jpg) <small>www.alamy.de</small>Portugals Vitinha feiert den Sieg nach der UEFA Euro 2024, dem Achtelfinale in der Frankfurt ...

Vitinha Of Portugal During The FIFA World Cup Qatar 2022 Match, Group H, Between South Korea V
----------------------------------------------------------------------------------------------

 ![Vitinha of Portugal during the FIFA World Cup Qatar 2022 match, Group H, between South Korea v](https://c8.alamy.com/comp/2KYWHX8/vitinha-of-portugal-during-the-fifa-world-cup-qatar-2022-match-group-h-between-south-korea-v-portugal-played-at-education-city-stadium-on-dec-2-2022-in-doha-qatar-photo-by-bagu-blanco-pressin-2KYWHX8.jpg) <small>www.alamy.com</small>Vitinha of Portugal during the FIFA World Cup Qatar 2022 match, Group H, between South Korea v ...

MUNCHEN - Vitinha Of Portugal During The UEFA Nations League Final Portugal V. Spain At The
-------------------------------------------------------------------------------------------

 ![MUNCHEN - Vitinha of Portugal during the UEFA Nations League final Portugal v. Spain at the](https://c8.alamy.com/comp/3BH9GP0/munchen-vitinha-of-portugal-during-the-uefa-nations-league-final-portugal-v-spain-at-the-munich-football-arena-on-june-8-2025-in-munich-germany-anp-hollandse-hoogte-maurice-van-steen-3BH9GP0.jpg) <small>www.alamy.com</small>MUNCHEN - Vitinha of Portugal during the UEFA Nations League final Portugal v. Spain at the ...

Vitinha évoque Le Défi Allemand, L’alchimie Du Groupe Portugais Et Le Rêve D’un Trophée | UEFA
----------------------------------------------------------------------------------------------

 ![Vitinha évoque le défi allemand, l’alchimie du groupe portugais et le rêve d’un trophée | UEFA](https://editorial.uefa.com/resources/029a-1de93d03920e-c3e68b6132f6-1000/portugal_v_denmark_-_uefa_nations_league_quarterfinal_leg_two.jpeg) <small>fr.uefa.com</small>Vitinha évoque le défi allemand, l’alchimie du groupe portugais et le rêve d’un trophée | UEFA ...

Vitinha Et Le Portugal Renversent L’Allemagne Et Filent En Finale – Le Meilleur Du PSG
--------------------------------------------------------------------------------------

 ![Vitinha et le Portugal renversent l’Allemagne et filent en finale – Le Meilleur Du PSG](https://www.lemeilleurdupsg.com/wp-content/uploads/2025/06/Vitinha-et-le-Portugal-eliminent-lAllemagne-en-Ligue-des-Nations.jpeg) <small>www.lemeilleurdupsg.com</small>Vitinha et le Portugal renversent l’Allemagne et filent en finale – Le Meilleur Du PSG

LEIPZIG, GERMANY - JUNE 18: Vitinha Of Portugal Runs With The Ball During The Group F - UEFA
--------------------------------------------------------------------------------------------

 ![LEIPZIG, GERMANY - JUNE 18: Vitinha of Portugal runs with the ball during the Group F - UEFA](https://c8.alamy.com/comp/2XCTAFP/leipzig-germany-june-18-vitinha-of-portugal-runs-with-the-ball-during-the-group-f-uefa-euro-2024-match-between-portugal-and-czechia-at-red-bull-arena-on-june-18-2024-in-leipzig-germany-photo-by-peter-lousbsr-agency-2XCTAFP.jpg) <small>www.alamy.com</small>LEIPZIG, GERMANY - JUNE 18: Vitinha of Portugal runs with the ball during the Group F - UEFA ...

Levensgrote Kartonnen Standaard Van Vitinha – 🇵🇹 Portugal’s Midfield Maestro Editie
-----------------------------------------------------------------------------------

 ![Levensgrote kartonnen standaard van Vitinha – 🇵🇹 Portugal’s Midfield Maestro Editie](https://cdn.myikas.com/images/b363bd06-fb46-4ffd-a7d0-b7231a175a7e/01a25c4c-9374-4722-ace8-e25b629b776c/3840/vitinha-life-size-cardboard-cutout-model-portugal-national-football-team-number-23-celebrity-cutouts.webp) <small>lifesizemodelshop.com</small>Levensgrote kartonnen standaard van Vitinha – 🇵🇹 Portugal’s Midfield Maestro Editie

Vitinha 23 (Dorsal Oficial) - 26-27 Portugal Local
--------------------------------------------------

 ![Vitinha 23 (Dorsal Oficial) - 26-27 Portugal Local](https://www.subsidesports.com/media/catalog/product/cache/a5716ed2a1003630b9abacca1719c93b/0/8/0841cb15d088c272ef9b948367c45ff71c0c59215e5abf4c7e59519e92303a8c.jpeg) <small>www.subsidesports.es</small>Vitinha 23 (Dorsal Oficial) - 26-27 Portugal Local

Vitinha | Portugal | UEFA EURO 2024 | UEFA.com
----------------------------------------------

 ![Vitinha | Portugal | UEFA EURO 2024 | UEFA.com](https://img.uefa.com/imgml/TP/players/3/2024/cutoff/250101444.png) <small>www.uefa.com</small>Vitinha | Portugal | UEFA EURO 2024 | UEFA.com

Euro 2024 | Vitinha, Maestro Du PSG Cherche Sa Place à L'Euro Avec Le Portugal - Eurosport
------------------------------------------------------------------------------------------

 ![Euro 2024 | Vitinha, maestro du PSG cherche sa place à l'Euro avec le Portugal - Eurosport](https://imgresizer.eurosport.com/unsafe/2560x1440/filters:format(jpeg)/origin-imgresizer.eurosport.com/2024/06/05/3983020-80836108-2560-1440.jpg) <small>www.eurosport.fr</small>Euro 2024 | Vitinha, maestro du PSG cherche sa place à l'Euro avec le Portugal - Eurosport

FRANKFURT - Vitinha Of Portugal During The UEFA EURO 2024 Round Of 16 Match Between Portugal And
------------------------------------------------------------------------------------------------

 ![FRANKFURT - Vitinha of Portugal during the UEFA EURO 2024 round of 16 match between Portugal and](https://c8.alamy.com/comp/2XGE223/frankfurt-vitinha-of-portugal-during-the-uefa-euro-2024-round-of-16-match-between-portugal-and-slovenia-at-frankfurt-arena-on-july-1-2024-in-frankfurt-germany-anp-hollandse-hoogte-gerrit-van-keulen-2XGE223.jpg) <small>www.alamy.com</small>FRANKFURT - Vitinha of Portugal during the UEFA EURO 2024 round of 16 match between Portugal and ...

Portugal Shirt Uit 2025-2026 + Vitinha 23
-----------------------------------------

 ![Portugal Shirt Uit 2025-2026 + Vitinha 23](https://static1.cdn-subsidesports.com/2/media/catalog/product/cache/38d4094f49a5c2931b615f53f1250097/5/0/502e7c1b30cbe8d9397b686ee11d2cb0fc46bb875edc7b27c038873fb2a62d58.jpeg) <small>www.subsidesports.nl</small>Portugal Shirt Uit 2025-2026 + Vitinha 23

Vitinha Of Portugal During The Portugal Portraits - UEFA Nations... News Photo - Getty Images
---------------------------------------------------------------------------------------------

 ![Vitinha of Portugal during the Portugal Portraits - UEFA Nations... News Photo - Getty Images](https://media.gettyimages.com/id/2218377536/photo/portugal-portraits-uefa-nations-league-2025-finals.jpg?s=1024x1024&w=gi&k=20&c=5L1EGOqCUCXZdPLcJhkolqJiJuh2Ei3UFJ2JEhVS2Rw=) <small>www.gettyimages.in</small>Vitinha of Portugal during the Portugal Portraits - UEFA Nations... News Photo - Getty Images

Portugal 2026- Home VITINHA #23 Official Name Set – ProSoccer
-------------------------------------------------------------

 ![Portugal 2026- Home VITINHA #23 Official Name Set – ProSoccer](https://www.prosoccer.com/cdn/shop/files/portugal-2026-home-vitinha-23-official-name-set-7781831.webp?v=1781910191&width=1946) <small>www.prosoccer.com</small>Portugal 2026- Home VITINHA #23 Official Name Set – ProSoccer

FRANKFURT - Vitinha Of Portugal During The UEFA EURO 2024 Round Of 16 Match Between Portugal And
------------------------------------------------------------------------------------------------

 ![FRANKFURT - Vitinha of Portugal during the UEFA EURO 2024 round of 16 match between Portugal and](https://c8.alamy.com/comp/2XGE32D/frankfurt-vitinha-of-portugal-during-the-uefa-euro-2024-round-of-16-match-between-portugal-and-slovenia-at-frankfurt-arena-on-july-1-2024-in-frankfurt-germany-anp-hollandse-hoogte-gerrit-van-keulen-2XGE32D.jpg) <small>www.alamy.com</small>FRANKFURT - Vitinha of Portugal during the UEFA EURO 2024 round of 16 match between Portugal and ...

Vitinha Of Portugal Poses For A Photo With The Vivo Player Of The... News Photo - Getty Images
----------------------------------------------------------------------------------------------

 ![Vitinha of Portugal poses for a photo with the Vivo Player of the... News Photo - Getty Images](https://media.gettyimages.com/id/2158161619/photo/group-f-uefa-euro-2024.jpg?s=1024x1024&w=gi&k=20&c=OFb9p49Wo4ZCBgEOpEvqn4NZqC0VW1v-dHT27U9Xoho=) <small>www.gettyimages.com</small>Vitinha of Portugal poses for a photo with the Vivo Player of the... News Photo - Getty Images

Vitinha Of Portugal Poses For A Portrait During The Portugal Portrait... News Photo - Getty Images
--------------------------------------------------------------------------------------------------

 ![Vitinha of Portugal poses for a portrait during the Portugal Portrait... News Photo - Getty Images](https://media.gettyimages.com/id/2156815343/photo/portugal-portraits-uefa-euro-2024.jpg?s=1024x1024&w=gi&k=20&c=OgVYE8wvaeLYHemYypa0_Qx0JVkAm5i93MMsfftyi5A=) <small>www.gettyimages.com</small>Vitinha of Portugal poses for a portrait during the Portugal Portrait... News Photo - Getty Images

Portugal's Vitinha During The 2026 FIFA World Cup European Qualifying, Group F Match At The
-------------------------------------------------------------------------------------------

 ![Portugal's Vitinha during the 2026 FIFA World Cup European Qualifying, Group F match at the](https://c8.alamy.com/comp/3D55CYB/portugals-vitinha-during-the-2026-fifa-world-cup-european-qualifying-group-f-match-at-the-aviva-stadium-in-dublin-ireland-picture-date-thursday-november-13-2025-3D55CYB.jpg) <small>www.alamy.com</small>Portugal's Vitinha during the 2026 FIFA World Cup European Qualifying, Group F match at the ...

Portugal's Vitinha During The 2026 FIFA World Cup European Qualifying, Group F Match At The
-------------------------------------------------------------------------------------------

 ![Portugal's Vitinha during the 2026 FIFA World Cup European Qualifying, Group F match at the](https://c8.alamy.com/comp/3D55CYY/portugals-vitinha-during-the-2026-fifa-world-cup-european-qualifying-group-f-match-at-the-aviva-stadium-in-dublin-ireland-picture-date-thursday-november-13-2025-3D55CYY.jpg) <small>www.alamy.com</small>Portugal's Vitinha during the 2026 FIFA World Cup European Qualifying, Group F match at the ...

« Vitinha Mérite Le Ballon D’Or » : La Déclaration D’amour Du Sélectionneur Du Portugal Au
------------------------------------------------------------------------------------------

 ![« Vitinha mérite le Ballon d’Or » : la déclaration d’amour du sélectionneur du Portugal au](https://www.leparisien.fr/resizer/V6iBKBOQ2sa2QJ8ls7JB1HyQHzU=/932x582/cloudfront-eu-central-1.images.arcpublishing.com/leparisien/GGZABC65ZVA7TGD3WZYOAW2KIU.jpg) <small>www.leparisien.fr</small>« Vitinha mérite le Ballon d’Or » : la déclaration d’amour du sélectionneur du Portugal au ...

Portugal's Vitinha During The UEFA Euro 2024 Group F Match At Leipzig Stadium In Leipzig
----------------------------------------------------------------------------------------

 ![Portugal's Vitinha during the UEFA Euro 2024 Group F match at Leipzig Stadium in Leipzig](https://c8.alamy.com/comp/2XCTH3R/portugals-vitinha-during-the-uefa-euro-2024-group-f-match-at-leipzig-stadium-in-leipzig-germany-picture-date-tuesday-june-18-2024-2XCTH3R.jpg) <small>www.alamy.com</small>Portugal's Vitinha during the UEFA Euro 2024 Group F match at Leipzig Stadium in Leipzig ...

Portugal At The 2026 FIFA World Cup: What You Need To Know
----------------------------------------------------------

 ![Portugal at the 2026 FIFA World Cup: What You Need to Know](https://www.futbolupdate.com/wp-content/uploads/2026/02/Vitinha-portugal-national-team-1024x768.jpg) <small>www.futbolupdate.com</small>Portugal at the 2026 FIFA World Cup: What You Need to Know

Portugals Vitinha Im Spiel Der Gruppe F Zur UEFA Euro 2024 Im BVB Stadion Dortmund In Dortmund
----------------------------------------------------------------------------------------------

 ![Portugals Vitinha im Spiel der Gruppe F zur UEFA Euro 2024 im BVB Stadion Dortmund in Dortmund](https://l450v.alamy.com/450vde/2xatbap/juni-2024-lissabon-portugal-portugal-und-paris-saint-germain-mittelfeldspieler-vitinha-23-im-spiel-wahrend-des-internationalen-freundschaftsspiels-portugal-gegen-kroatien-credit-alexandre-de-sousaalamy-live-news-2xatbap.jpg) <small>www.alamy.de</small>Portugals Vitinha im Spiel der Gruppe F zur UEFA Euro 2024 im BVB Stadion Dortmund in Dortmund ...

Football Idol Numbers 2025 Portugal Home BERNARDO Football Jersey Number VITINHA Team Numbers
---------------------------------------------------------------------------------------------

 ![Football Idol Numbers 2025 Portugal Home BERNARDO Football Jersey Number VITINHA Team numbers](https://www.kitpatch.com/wp-content/uploads/2026/01/football-idol-numbers-2025-portugal-home-bernardo-football-jersey-number-vitinha-team-numbers-and-names.jpg) <small>www.kitpatch.com</small>Football Idol Numbers 2025 Portugal Home BERNARDO Football Jersey Number VITINHA Team numbers ...

Vitinha, Por 23 In The UEFA Nations League 2025 Semi Final Match GERMANY - PORTUGAL 1-2 In
------------------------------------------------------------------------------------------

 ![Vitinha, Por 23 in the UEFA Nations League 2025 semi final match GERMANY - PORTUGAL 1-2 in](https://c8.alamy.com/comp/3BGJH6R/vitinha-por-23-in-the-uefa-nations-league-2025-semi-final-match-germany-portugal-1-2-in-season-20242025-at-june-4-2025-in-munich-germany-photographer-peter-schatz-3BGJH6R.jpg) <small>www.alamy.com</small>Vitinha, Por 23 in the UEFA Nations League 2025 semi final match GERMANY - PORTUGAL 1-2 in ...

Vitinha – Wikipédia, A Enciclopédia Livre
-----------------------------------------

 ![Vitinha – Wikipédia, a enciclopédia livre](https://upload.wikimedia.org/wikipedia/commons/thumb/8/89/Portugal_national_football_team_0866_%28Vitinha%29.jpg/250px-Portugal_national_football_team_0866_%28Vitinha%29.jpg) <small>pt.wikipedia.org</small>Vitinha – Wikipédia, a enciclopédia livre

Vitinha of portugal in action during the uefa nations league... news photo. Levensgrote kartonnen standaard van vitinha – 🇵🇹 portugal’s midfield maestro editie. Vitinha 23 (dorsal oficial)
