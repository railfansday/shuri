---
title: "Estrela Amadora Vs Sporting Cp - Sporting cp vs. estrela da amadora 2023-2024"
description: "Sporting cp – estrela amadora : match liga portugal (1 nov. 2024)"
date: "2026-04-12"
categories:
- "Uncategorized"
images:
- "https://media.gettyimages.com/id/1765581445/photo/sporting-cp-v-cf-estrela-da-amadora-liga-portugal-betclic.jpg?s=1024x1024&amp;w=gi&amp;k=20&amp;c=IZOrycW1WcSbNOjdqw0aSqY8WrfcsARlT5EUL7l0uv4="
featuredImage: "https://thumbor.prod.vidiocdn.com/9sy6PEp39V5bmMFOVFv7peQmvM0=/1280x720/filters:quality(70)/vidio-web-prod-video/uploads/video/image/8643051/hl-portuguese-league-estrela-amadora-vs-sporting-c5c297.jpg"
featured_image: "https://i.ytimg.com/vi/WyDD-HjwGog/maxresdefault.jpg"
image: "https://c8.alamy.com/comp/3D8FDGB/maximiliano-araujo-20-of-sporting-cp-and-luan-patrick-of-30-estrela-da-amadora-fighting-for-possession-during-the-liga-portugal-match-between-sporting-cp-vs-estrela-da-amadora-at-estadio-jose-alvalade-on-november-30th2025-photo-by-joao-bravosports-press-photo-3D8FDGB.jpg"
---

If you are looking for Sporting CP 3 - 2 Estrela da Amadora (Relato) | Jornada 10 da I Liga - Golo FM | A Primeira you've visit to the right page. We have 35 Pics about Sporting CP 3 - 2 Estrela da Amadora (Relato) | Jornada 10 da I Liga - Golo FM | A Primeira like Luis Suarez 97 of Sporting CP celebrates after scoring during the Liga Portugal match between, Maximiliano Araujo 20 of Sporting CP and Luan Patrick of 30 Estrela da Amadora fighting for and also Sporting CP Vs Estrela Amadora Live Match Today | SCP Vs ESA Live Football Match 2023 Live - YouTube. Here you go:

Sporting CP 3 - 2 Estrela Da Amadora (Relato) | Jornada 10 Da I Liga - Golo FM | A Primeira
-------------------------------------------------------------------------------------------

 ![Sporting CP 3 - 2 Estrela da Amadora (Relato) | Jornada 10 da I Liga - Golo FM | A Primeira](https://golo.fm/wp-content/uploads/2023/11/Sporting-vs-Estrela-Amadora-05112023-20H30-CAPA.png) <small>golo.fm</small>Sporting CP 3 - 2 Estrela da Amadora (Relato) | Jornada 10 da I Liga - Golo FM | A Primeira ...

Resumo | Liga Portugal: Sporting CP 4-0 CF Estrela Da Amadora - YouTube
-----------------------------------------------------------------------

 ![Resumo | Liga Portugal: Sporting CP 4-0 CF Estrela da Amadora - YouTube](https://i.ytimg.com/vi/WyDD-HjwGog/maxresdefault.jpg) <small>www.youtube.com</small>Resumo | Liga Portugal: Sporting CP 4-0 CF Estrela da Amadora - YouTube

Lisbon, Portugal. 30 November 2025. Players Of Sporting CP Celebrate The Goal During The
----------------------------------------------------------------------------------------

 ![Lisbon, Portugal. 30 November 2025. Players of Sporting CP celebrate the goal during the](https://c8.alamy.com/comp/3D8FWWH/lisbon-portugal-30-november-2025-players-of-sporting-cp-celebrate-the-goal-during-the-sporting-cp-against-estrela-da-amadora-for-the-portuguese-liga-at-estadio-jose-alvalade-in-lisbon-credit-ricardo-rocha-alamy-live-news-3D8FWWH.jpg) <small>www.alamy.com</small>Lisbon, Portugal. 30 November 2025. Players of Sporting CP celebrate the goal during the ...

Amadora,Portugal,March 29th, 2025: Gyokeres (9 Sporting CP) In Action During The Liga Portugal
----------------------------------------------------------------------------------------------

 ![Amadora,Portugal,March 29th, 2025: Gyokeres (9 Sporting CP) in action during the Liga Portugal](https://c8.alamy.com/comp/3A928JW/amadoraportugalmarch-29th-2025-gyokeres-9-sporting-cp-in-action-during-the-liga-portugal-betclic-game-between-cf-estrela-da-amadora-vs-sporting-cp-estadio-jose-gomes-amadora-on-29th-march-2025-joo-bravo-spp-3A928JW.jpg) <small>www.alamy.com</small>Amadora,Portugal,March 29th, 2025: Gyokeres (9 Sporting CP) in action during the Liga Portugal ...

CF Estrela Amadora Vs Sporting CP B Live Score, H2H And Lineups | Sofascore
---------------------------------------------------------------------------

 ![CF Estrela Amadora vs Sporting CP B live score, H2H and lineups | Sofascore](https://img.sofascore.com/api/v1/event/12532658/share-image/16x9) <small>www.sofascore.com</small>CF Estrela Amadora vs Sporting CP B live score, H2H and lineups | Sofascore

Sporting CP 4-0 Estrela Da Amadora Highlights, Goals &amp; Key Moments (30 Nov 2025) | Liga Portugal
----------------------------------------------------------------------------------------------------

 ![Sporting CP 4-0 Estrela da Amadora Highlights, Goals & Key Moments (30 Nov 2025) | Liga Portugal](https://i.ytimg.com/vi/hY5-kmezgog/maxresdefault.jpg) <small>footyroom.co</small>Sporting CP 4-0 Estrela da Amadora Highlights, Goals &amp; Key Moments (30 Nov 2025) | Liga Portugal ...

Resumo | Liga Portugal: CF Estrela Da Amadora 0-1 Sporting CP - YouTube
-----------------------------------------------------------------------

 ![Resumo | Liga Portugal: CF Estrela da Amadora 0-1 Sporting CP - YouTube](https://i.ytimg.com/vi/twHCWfQ0SCw/maxresdefault.jpg) <small>www.youtube.com</small>Resumo | Liga Portugal: CF Estrela da Amadora 0-1 Sporting CP - YouTube

Sporting CP Vs CF Estrela Da Amadora 2024 - 2025 Primeira Liga
--------------------------------------------------------------

 ![Sporting CP vs CF Estrela da Amadora 2024 - 2025 Primeira Liga](https://imgs.ticombo.com/tc-images-main/thumbnail/events/sports/sporting-cp-vs-cf-estrela-da-amadora-2024-2025-primeira-liga/thumbnail-48dabb16-badc-4055-96c9-f850705ad812.png) <small>www.ticombo.com</small>Sporting CP vs CF Estrela da Amadora 2024 - 2025 Primeira Liga

Lisbon, Portugal. 30 November 2025. Players Of Sporting CP Celebrate The Goal During The
----------------------------------------------------------------------------------------

 ![Lisbon, Portugal. 30 November 2025. Players of Sporting CP celebrate the goal during the](https://c8.alamy.com/comp/3D8FDC2/lisbon-portugal-30-november-2025-players-of-sporting-cp-celebrate-the-goal-during-the-sporting-cp-against-estrela-da-amadora-for-the-portuguese-liga-at-estadio-jose-alvalade-in-lisbon-credit-ricardo-rocha-alamy-live-news-3D8FDC2.jpg) <small>www.alamy.com</small>Lisbon, Portugal. 30 November 2025. Players of Sporting CP celebrate the goal during the ...

Estrela Amadora Vs Sporting CP 2025-03-29 Result - TheSportsDB.com
------------------------------------------------------------------

 ![Estrela Amadora vs Sporting CP 2025-03-29 result - TheSportsDB.com](https://r2.thesportsdb.com/images/media/event/thumb/owweyu1720533741.jpg) <small>www.thesportsdb.com</small>Estrela Amadora vs Sporting CP 2025-03-29 result - TheSportsDB.com

Sporting Vs Estrela Amadora - Highlight | Liga Portugal 2025/26
---------------------------------------------------------------

 ![Sporting vs Estrela Amadora - Highlight | Liga Portugal 2025/26](https://thumbor.prod.vidiocdn.com/Pstmg0W2GLyPvL3cp6m0sHmO3hk=/1280x720/filters:quality(70)/vidio-web-prod-video/uploads/video/image/9103890/sporting-vs-estrela-amadora-highlight-liga-portugal-2025-26-e03487.jpg) <small>www.vidio.com</small>Sporting vs Estrela Amadora - Highlight | Liga Portugal 2025/26

Estrela Amadora Vs Sporting CP EM DIRETO | Liga Portugal 25/26 | EM DIRETO NA GAMEPLAY PES 2021
-----------------------------------------------------------------------------------------------

 ![Estrela Amadora vs Sporting CP EM DIRETO | Liga Portugal 25/26 | EM DIRETO NA GAMEPLAY PES 2021](https://i.ytimg.com/vi/fjLsUL887oM/maxresdefault.jpg) <small>www.youtube.com</small>Estrela Amadora vs Sporting CP EM DIRETO | Liga Portugal 25/26 | EM DIRETO NA GAMEPLAY PES 2021 ...

Estrela Amadora Vs Sporting CP 0-1 | Liga Portugal 2026 | Simulação - YouTube
-----------------------------------------------------------------------------

 ![Estrela Amadora vs Sporting CP 0-1 | Liga Portugal 2026 | Simulação - YouTube](https://i.ytimg.com/vi/uiW7_L8REmc/maxresdefault.jpg) <small>www.youtube.com</small>Estrela Amadora vs Sporting CP 0-1 | Liga Portugal 2026 | Simulação - YouTube

Lisbon, Portugal. 01st Nov, 2024. Team Of Estrela Amadora Seen In Action During Liga Portugal
---------------------------------------------------------------------------------------------

 ![Lisbon, Portugal. 01st Nov, 2024. Team of Estrela Amadora seen in action during Liga Portugal](https://c8.alamy.com/comp/2YF8RM0/lisbon-portugal-01st-nov-2024-team-of-estrela-amadora-seen-in-action-during-liga-portugal-game-between-teams-of-sporting-cp-and-cf-estrela-amadora-at-estadio-jose-alvalade-final-score-sporting-cp-5-1-cf-estrela-amadora-photo-by-maciej-rogowskisopa-imagessipa-usa-credit-sipa-usaalamy-live-news-2YF8RM0.jpg) <small>www.alamy.com</small>Lisbon, Portugal. 01st Nov, 2024. Team of Estrela Amadora seen in action during Liga Portugal ...

Estrela Amadora Vs Sporting - Highlights | Liga Portugal 2024/25 | Vidio
------------------------------------------------------------------------

 ![Estrela Amadora vs Sporting - Highlights | Liga Portugal 2024/25 | Vidio](https://thumbor.prod.vidiocdn.com/9sy6PEp39V5bmMFOVFv7peQmvM0=/1280x720/filters:quality(70)/vidio-web-prod-video/uploads/video/image/8643051/hl-portuguese-league-estrela-amadora-vs-sporting-c5c297.jpg) <small>www.vidio.com</small>Estrela Amadora vs Sporting - Highlights | Liga Portugal 2024/25 | Vidio

Sporting CP Vs Estrela Da Amadora (5 Nov 2023) 🔥 Video Highlights - FootyRoom
-----------------------------------------------------------------------------

 ![Sporting CP vs Estrela da Amadora (5 Nov 2023) 🔥 Video Highlights - FootyRoom](https://i.ytimg.com/vi/cF4Ld9DLvuA/maxresdefault.jpg) <small>footyroom.co</small>Sporting CP vs Estrela da Amadora (5 Nov 2023) 🔥 Video Highlights - FootyRoom

Estrela Amadora Vs Sporting CP Predicciones De Fútbol Y Estadística - 11/04/2026
--------------------------------------------------------------------------------

 ![Estrela Amadora vs Sporting CP Predicciones de Fútbol y Estadística - 11/04/2026](https://www.forebet.com/images/match-covers/cover-2411181.jpg) <small>www.forebet.com</small>Estrela Amadora vs Sporting CP Predicciones de Fútbol y Estadística - 11/04/2026

Sporting CP Vs Estrela Da Amadora (1 Nov 2024) 🔥 Video Highlights - FootyRoom
-----------------------------------------------------------------------------

 ![Sporting CP vs Estrela da Amadora (1 Nov 2024) 🔥 Video Highlights - FootyRoom](https://i.ytimg.com/vi/vLbYqqJXM7o/maxresdefault.jpg) <small>footyroom.co</small>Sporting CP vs Estrela da Amadora (1 Nov 2024) 🔥 Video Highlights - FootyRoom

Sporting Cp Vs Estrela Amadora Live | Club Friendlies - YouTube
---------------------------------------------------------------

 ![sporting cp vs estrela amadora live | Club Friendlies - YouTube](https://i.ytimg.com/vi/vq_YtsSldTw/maxresdefault.jpg) <small>www.youtube.com</small>sporting cp vs estrela amadora live | Club Friendlies - YouTube

Vlog: Sporting CP 3 Vs 2 CF Estrela Da Amadora (Liga Portugal Betclic 23/24) - YouTube
--------------------------------------------------------------------------------------

 ![Vlog: Sporting CP 3 vs 2 CF Estrela da Amadora (Liga Portugal Betclic 23/24) - YouTube](https://i.ytimg.com/vi/geN2H_8Jnfw/maxresdefault.jpg) <small>www.youtube.com</small>Vlog: Sporting CP 3 vs 2 CF Estrela da Amadora (Liga Portugal Betclic 23/24) - YouTube

Goncalo Inacio Of Sporting CP Tries To Escape Aloisio Souza Of CF... News Photo - Getty Images
----------------------------------------------------------------------------------------------

 ![Goncalo Inacio of Sporting CP tries to escape Aloisio Souza of CF... News Photo - Getty Images](https://media.gettyimages.com/id/1765588653/photo/sporting-cp-v-estrela-amadora-liga-portugal-bwin.jpg?s=1024x1024&w=gi&k=20&c=xE11EbOGrcQ_vMFed0sbeGDv6_hwmgygZKuP-mhxK-A=) <small>www.gettyimages.com</small>Goncalo Inacio of Sporting CP tries to escape Aloisio Souza of CF... News Photo - Getty Images

Sporting CP – Estrela Amadora : Match Liga Portugal (1 Nov. 2024)
-----------------------------------------------------------------

 ![Sporting CP – Estrela Amadora : Match Liga Portugal (1 nov. 2024)](https://d2y7bwvzo8ehns.cloudfront.net/images/generated/fixture-sporting-cp-vs-estrela-amadora.jpg?twic=v1/output=auto) <small>www.mon-match.com</small>Sporting CP – Estrela Amadora : Match Liga Portugal (1 nov. 2024)

Hidemasa Morita Of Sporting CP With Nani Of CF Estrela Da Amadora In... News Photo - Getty Images
-------------------------------------------------------------------------------------------------

 ![Hidemasa Morita of Sporting CP with Nani of CF Estrela da Amadora in... News Photo - Getty Images](https://media.gettyimages.com/id/2181647834/photo/sporting-cp-v-cf-estrela-da-amadora-liga-portugal-betclic.jpg?s=1024x1024&w=gi&k=20&c=QGSy10ieLWcGgBoc-orBR2MOjqSb2M_V65jmnmV2bec=) <small>www.gettyimages.com</small>Hidemasa Morita of Sporting CP with Nani of CF Estrela da Amadora in... News Photo - Getty Images

Sporting CP Vs. Estrela Da Amadora 2023-2024 | Footballia
---------------------------------------------------------

 ![Sporting CP vs. Estrela da Amadora 2023-2024 | Footballia](https://footballia.eu/cache/matches/f2ed4bf1265279e42d2c83744d763b81.png) <small>footballia.eu</small>Sporting CP vs. Estrela da Amadora 2023-2024 | Footballia

Sebastian Coates Of Sporting CP With Leo Jaba Of CF Estrela Da... News Photo - Getty Images
-------------------------------------------------------------------------------------------

 ![Sebastian Coates of Sporting CP with Leo Jaba of CF Estrela da... News Photo - Getty Images](https://media.gettyimages.com/id/1765581445/photo/sporting-cp-v-cf-estrela-da-amadora-liga-portugal-betclic.jpg?s=1024x1024&w=gi&k=20&c=IZOrycW1WcSbNOjdqw0aSqY8WrfcsARlT5EUL7l0uv4=) <small>www.gettyimages.co.uk</small>Sebastian Coates of Sporting CP with Leo Jaba of CF Estrela da... News Photo - Getty Images

Primeira Liga » Estrela Amadora Gegen Sporting CP » Aufstellung
---------------------------------------------------------------

 ![Primeira Liga » Estrela Amadora gegen Sporting CP » Aufstellung](https://teaser-image-service.global-sports.net/v1/sport.de/default/11306078.webp) <small>www.weltfussball.at</small>Primeira Liga » Estrela Amadora gegen Sporting CP » Aufstellung

Sporting CP Vs Estrela Amadora Live Match Today | SCP Vs ESA Live Football Match 2023 Live - YouTube
----------------------------------------------------------------------------------------------------

 ![Sporting CP Vs Estrela Amadora Live Match Today | SCP Vs ESA Live Football Match 2023 Live - YouTube](https://i.ytimg.com/vi/iB0Num4LMzc/maxresdefault.jpg) <small>www.youtube.com</small>Sporting CP Vs Estrela Amadora Live Match Today | SCP Vs ESA Live Football Match 2023 Live - YouTube

SPORTING CP 3-2 ESTRELA DA AMADORA - EM DIRETO - YouTube
--------------------------------------------------------

 ![SPORTING CP 3-2 ESTRELA DA AMADORA - EM DIRETO - YouTube](https://i.ytimg.com/vi/fz1W6CVV534/maxresdefault.jpg) <small>www.youtube.com</small>SPORTING CP 3-2 ESTRELA DA AMADORA - EM DIRETO - YouTube

Maxi Araujo Of Sporting CP, Max Scholze Of Estrela Da Amadora During The Liga Portugal Betclic
----------------------------------------------------------------------------------------------

 ![Maxi Araujo of Sporting CP, Max Scholze of Estrela da Amadora during the Liga Portugal Betclic](https://c8.alamy.com/comp/3E829G1/maxi-araujo-of-sporting-cp-max-scholze-of-estrela-da-amadora-during-the-liga-portugal-betclic-match-between-estrela-da-amadora-and-sporting-at-estadio-jose-gomes-on-april-11-2026-in-amadora-portugal-photo-by-joao-ricoicon-sport-3E829G1.jpg) <small>www.alamy.com</small>Maxi Araujo of Sporting CP, Max Scholze of Estrela da Amadora during the Liga Portugal Betclic ...

Estrela Da Amadora Contre Sporting CP - Score En Direct, Compositions Probables Et Statistiques H2H
---------------------------------------------------------------------------------------------------

 ![Estrela da Amadora contre Sporting CP - score en direct, compositions probables et statistiques H2H](https://www.fotmob.com/match/preview?matchId=4844417) <small>www.fotmob.com</small>Estrela da Amadora contre Sporting CP - score en direct, compositions probables et statistiques H2H

Estrela Amadora Vs Sporting CP 2025-03-29 Result - TheSportsDB.com
------------------------------------------------------------------

 ![Estrela Amadora vs Sporting CP 2025-03-29 result - TheSportsDB.com](https://img.youtube.com/vi/IzPokAAKjts/hqdefault.jpg) <small>www.thesportsdb.com</small>Estrela Amadora vs Sporting CP 2025-03-29 result - TheSportsDB.com

Sporting CP Vs Estrela Amadora: Marcador En Vivo, Retransmisión Y Enfrentamientos Directos 9/20
-----------------------------------------------------------------------------------------------

 ![Sporting CP vs Estrela Amadora: Marcador en vivo, Retransmisión y enfrentamientos directos 9/20](https://tribuna.com/imaginarium/images/tribuna-match/en/championsleague/match/100586922.jpeg) <small>tribuna.com</small>Sporting CP vs Estrela Amadora: Marcador en vivo, Retransmisión y enfrentamientos directos 9/20 ...

SPORTING CP Vs ESTRELA AMADORA - Liga Portugal 2024/25 - EA SPORTS FC 25 - YouTube
----------------------------------------------------------------------------------

 ![SPORTING CP vs ESTRELA AMADORA - Liga Portugal 2024/25 - EA SPORTS FC 25 - YouTube](https://i.ytimg.com/vi/lGOgxE8SZg8/maxresdefault.jpg) <small>www.youtube.com</small>SPORTING CP vs ESTRELA AMADORA - Liga Portugal 2024/25 - EA SPORTS FC 25 - YouTube

Maximiliano Araujo 20 Of Sporting CP And Luan Patrick Of 30 Estrela Da Amadora Fighting For
-------------------------------------------------------------------------------------------

 ![Maximiliano Araujo 20 of Sporting CP and Luan Patrick of 30 Estrela da Amadora fighting for](https://c8.alamy.com/comp/3D8FDGB/maximiliano-araujo-20-of-sporting-cp-and-luan-patrick-of-30-estrela-da-amadora-fighting-for-possession-during-the-liga-portugal-match-between-sporting-cp-vs-estrela-da-amadora-at-estadio-jose-alvalade-on-november-30th2025-photo-by-joao-bravosports-press-photo-3D8FDGB.jpg) <small>www.alamy.com</small>Maximiliano Araujo 20 of Sporting CP and Luan Patrick of 30 Estrela da Amadora fighting for ...

Luis Suarez 97 Of Sporting CP Celebrates After Scoring During The Liga Portugal Match Between
---------------------------------------------------------------------------------------------

 ![Luis Suarez 97 of Sporting CP celebrates after scoring during the Liga Portugal match between](https://c8.alamy.com/comp/3D8FGMF/luis-suarez-97-of-sporting-cp-celebrates-after-scoring-during-the-liga-portugal-match-between-sporting-cp-vs-estrela-da-amadora-at-estadio-jose-alvalade-on-november-30th2025-photo-by-joao-bravosports-press-photo-3D8FGMF.jpg) <small>www.alamy.com</small>Luis Suarez 97 of Sporting CP celebrates after scoring during the Liga Portugal match between ...

Sporting cp 3. Lisbon, portugal. 30 november 2025. players of sporting cp celebrate the goal during the .... Maximiliano araujo 20 of sporting cp and luan patrick of 30 estrela da amadora fighting for ...
