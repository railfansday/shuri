---
title: "Quem Pode Fazer Greve Geral - Canalhices contra a greve geral"
description: "Greve histórica em portugal: três milhões cruzam os braços em protesto contra medidas de"
date: "2026-01-25"
categories:
- "Uncategorized"
images:
- "https://spzn.pt/uploads/noticias/big_1763717239_6728_SPZN_2025_site_novo_(17).png"
featuredImage: "https://bordalo.observador.pt/v2/q:60/rs:fill:1440/c:4096:2730:nowe:0:0/plain/https://s3.observador.pt/wp-content/uploads/2025/12/11173246/dventura-greve-geral-11dez-43-scaled.jpg"
featured_image: "https://static.wixstatic.com/media/d0f32c_9ff1199ee2c34418af0094a43c516733~mv2.png/v1/fill/w_940,h_788,al_c,q_90,enc_avif,quality_auto/d0f32c_9ff1199ee2c34418af0094a43c516733~mv2.png"
image: "https://sabiasque.pt/images/stories/2026/trabalho/20260602-greve-geral-3-junho-1024x683.jpg"
---

If you are looking for UGT aprova por unanimidade greve geral a 11 de dezembro - Diário do Minho you've visit to the right place. We have 35 Pics about UGT aprova por unanimidade greve geral a 11 de dezembro - Diário do Minho like Greve geral: o que você precisa saber sobre a tentativa de parar o país pela 1ª vez em 20 anos, Greve geral: quem pode aderir, o que muda no salário e o que vai estar a funcionar - JN and also PCP - Partido... - PCP - Partido Comunista Português. Read more:

UGT Aprova Por Unanimidade Greve Geral A 11 De Dezembro - Diário Do Minho
-------------------------------------------------------------------------

 ![UGT aprova por unanimidade greve geral a 11 de dezembro - Diário do Minho](https://www.diariodominho.pt/storage/posts/greve-direito-a-greve_655b8a6d702c0_xl.jpg) <small>www.diariodominho.pt</small>UGT aprova por unanimidade greve geral a 11 de dezembro - Diário do Minho

A Greve, Quem A Pode Convocar E Quem Está Abrangido: Perguntas E Respostas
--------------------------------------------------------------------------

 ![A greve, quem a pode convocar e quem está abrangido: perguntas e respostas](https://jornaleconomico.sapo.pt/wp-content/themes/yootheme/cache/f5/greve-1-e1764932962267-f502b260.jpeg) <small>jornaleconomico.sapo.pt</small>A greve, quem a pode convocar e quem está abrangido: perguntas e respostas

Greve Geral: Quem Pode Aderir, O Que Muda No Salário E O Que Vai Estar A Funcionar - JN
---------------------------------------------------------------------------------------

 ![Greve geral: quem pode aderir, o que muda no salário e o que vai estar a funcionar - JN](https://staticx.noticiasilimitadas.pt/jn/image.webp?brand=jn&type=generate&guid=4a9e034d-f191-4476-908a-d05d2af1a846&w=3840) <small>www.jn.pt</small>Greve geral: quem pode aderir, o que muda no salário e o que vai estar a funcionar - JN

Canalhices Contra A Greve Geral
-------------------------------

 ![Canalhices contra a greve geral](https://resistir.info/portugal/imagens/greve_geral_11dez25.jpg) <small>resistir.info</small>Canalhices contra a greve geral

PCP - Partido... - PCP - Partido Comunista Português
----------------------------------------------------

 ![PCP - Partido... - PCP - Partido Comunista Português](https://lookaside.fbsbx.com/lookaside/crawler/media/?media_id=1392612092234526) <small>www.facebook.com</small>PCP - Partido... - PCP - Partido Comunista Português

Cartilha Ensina Como Servidor Público Deve Fazer Greve - Destaque Noticias
--------------------------------------------------------------------------

 ![Cartilha ensina como servidor público deve fazer greve - Destaque Noticias](https://www.destaquenoticias.com.br/wp-content/uploads/2024/02/greve-foto-agencia-brasil.jpeg) <small>www.destaquenoticias.com.br</small>Cartilha ensina como servidor público deve fazer greve - Destaque Noticias

Greve Geral Paralisa Transportes, Saúde E Educação No Porto - Expresso
----------------------------------------------------------------------

 ![Greve geral paralisa transportes, saúde e educação no Porto - Expresso](https://images.impresa.pt/expresso/2025-12-11-rds_15_greve-geral-2025-manifestacao-porto_rds_4314.jpg-f75ffda9/original) <small>expresso.pt</small>Greve geral paralisa transportes, saúde e educação no Porto - Expresso

Greve Geral: Entenda Os Seus Direitos E Deveres | VEJA
------------------------------------------------------

 ![Greve geral: Entenda os seus direitos e deveres | VEJA](https://veja.abril.com.br/wp-content/uploads/2017/03/greve-metroviarios-02.jpg?quality=90&strip=info) <small>veja.abril.com.br</small>Greve geral: Entenda os seus direitos e deveres | VEJA

FAQ: Os Direitos Dos Docentes Em Dia De Greve Geral - 11/12/2025
----------------------------------------------------------------

 ![FAQ: Os direitos dos docentes em dia de Greve Geral - 11/12/2025](https://static.wixstatic.com/media/d0f32c_9ff1199ee2c34418af0094a43c516733~mv2.png/v1/fill/w_940,h_788,al_c,q_90,enc_avif,quality_auto/d0f32c_9ff1199ee2c34418af0094a43c516733~mv2.png) <small>www.sprc.pt</small>FAQ: Os direitos dos docentes em dia de Greve Geral - 11/12/2025

A Greve Foi "um Estrondo" Político Mas "perderam Todos" - CNN Portugal
----------------------------------------------------------------------

 ![A greve foi "um estrondo" político mas "perderam todos" - CNN Portugal](https://img.iol.pt/image/id/693b2a1ad34e3caad84c47e9/1024.jpg) <small>cnnportugal.iol.pt</small>A greve foi "um estrondo" político mas "perderam todos" - CNN Portugal

A Greve Geral - Eu Adoro Pudim De Aveia - A GREVE GERAL Nome: Endryo Fernandes Dos Reis Turma
---------------------------------------------------------------------------------------------

 ![A Greve Geral - Eu adoro pudim de aveia - A GREVE GERAL Nome: Endryo Fernandes dos Reis Turma](https://d20ohkaloyme4g.cloudfront.net/img/document_thumbnails/c37c00a813b7a1213460e2178f52ec4e/thumb_1200_1698.png) <small>www.studocu.com</small>A Greve Geral - Eu adoro pudim de aveia - A GREVE GERAL Nome: Endryo Fernandes dos Reis Turma ...

O Que Você Precisa Saber Para Fazer O Enem; SEMEC Greve Professores | Atualidade Jurídica
-----------------------------------------------------------------------------------------

 ![O que você precisa saber para fazer o Enem; SEMEC Greve Professores | Atualidade Jurídica](https://www.portalaz.com.br/media/image_bank/2023/10/thumbs/greve.webp.1200x0_q95_crop.jpg) <small>www.portalaz.com.br</small>O que você precisa saber para fazer o Enem; SEMEC Greve Professores | Atualidade Jurídica ...

Pinterest | Greve Geral, Greve Brasil, Iniciais
-----------------------------------------------

 ![Pinterest | Greve geral, Greve brasil, Iniciais](https://i.pinimg.com/736x/e1/38/65/e13865fdc7e8e96c18ae8b6679ac8a06.jpg) <small>br.pinterest.com</small>Pinterest | Greve geral, Greve brasil, Iniciais

Perguntas E Respostas: A Greve, Quem A Pode Convocar E Quem Está Abrangido | Greve Geral | PÚBLICO
--------------------------------------------------------------------------------------------------

 ![Perguntas e respostas: a greve, quem a pode convocar e quem está abrangido | Greve geral | PÚBLICO](https://imagens.publico.pt/imagens.aspx/2050814?tp=UH&db=IMAGENS&type=JPG&share=1&o=BarraFacebook_Publico.png) <small>www.publico.pt</small>Perguntas e respostas: a greve, quem a pode convocar e quem está abrangido | Greve geral | PÚBLICO

Greve Geral De 3 De Junho: O Que Está Em Causa, Quem Pode Aderir E Que Impacto Se Prevê
---------------------------------------------------------------------------------------

 ![Greve Geral de 3 de junho: o que está em causa, quem pode aderir e que impacto se prevê](https://sabiasque.pt/images/stories/2026/trabalho/20260602-greve-geral-3-junho-1024x683.jpg) <small>sabiasque.pt</small>Greve Geral de 3 de junho: o que está em causa, quem pode aderir e que impacto se prevê

Greve Geral Em Lisboa A 3 De Junho: O Que Pára Na Cidade
--------------------------------------------------------

 ![Greve geral em Lisboa a 3 de Junho: o que pára na cidade](https://media.timeout.com/images/106411166/image.jpg) <small>www.timeout.pt</small>Greve geral em Lisboa a 3 de Junho: o que pára na cidade

Entre O Dever De Informar E A Adesão è Greve, Sindicato Dos Jornalistas Faz Balanço
-----------------------------------------------------------------------------------

 ![Entre o dever de informar e a adesão è greve, Sindicato dos Jornalistas faz balanço](https://eco.imgix.net/uploads/2025/12/cropped-greve-geral03.jpg) <small>eco.sapo.pt</small>Entre o dever de informar e a adesão è greve, Sindicato dos Jornalistas faz balanço ...

A Greve Geral De 11 De Dezembro Em 38 Imagens – Observador
----------------------------------------------------------

 ![A greve geral de 11 de dezembro em 38 imagens – Observador](https://bordalo.observador.pt/v2/q:60/rs:fill:1440/c:4096:2730:nowe:0:0/plain/https://s3.observador.pt/wp-content/uploads/2025/12/11173246/dventura-greve-geral-11dez-43-scaled.jpg) <small>observador.pt</small>A greve geral de 11 de dezembro em 38 imagens – Observador

Greve Geral: Saiba Quais São Os Serviços Mínimos Já Decretados - SIC Notícias
-----------------------------------------------------------------------------

 ![Greve geral: saiba quais são os serviços mínimos já decretados - SIC Notícias](https://images.impresa.pt/sicnot/2025-11-17-cgtp-pre-aviso-greve-82e19fc3-1/16x9/mw-1200) <small>sicnoticias.pt</small>Greve geral: saiba quais são os serviços mínimos já decretados - SIC Notícias

Greve Geral Juntou Centenas Nos Aliados. Governo Fala Em Adesão "inexpressiva" - JPN
------------------------------------------------------------------------------------

 ![Greve Geral juntou centenas nos Aliados. Governo fala em adesão "inexpressiva" - JPN](https://www.jpn.up.pt/wp-content/uploads/2025/12/greve_geral8.jpg) <small>www.jpn.up.pt</small>Greve Geral juntou centenas nos Aliados. Governo fala em adesão "inexpressiva" - JPN

Greve Geral Pode Custar 792 Milhões De Euros à Economia - JN
------------------------------------------------------------

 ![Greve geral pode custar 792 milhões de euros à economia - JN](https://staticx.noticiasilimitadas.pt/jn/image.webp?brand=jn&type=generate&guid=fb434b13-2b30-4ab1-a6bc-4ddd86b96b14&w=3840) <small>www.jn.pt</small>Greve geral pode custar 792 milhões de euros à economia - JN

Greve Geral Paralisa Portugal Contra Precarização De Direitos
-------------------------------------------------------------

 ![Greve geral paralisa Portugal contra precarização de direitos](https://horadopovo.com.br/wp-content/uploads/2025/12/Ruas-de-Lisboa-foram-tomadas-por-trabalhadores-durante-a-greve-geral-Rafael-Medeiros-Esquerda.jpg) <small>horadopovo.com.br</small>Greve geral paralisa Portugal contra precarização de direitos

Greve Geral – Derrotar O Pacote Laboral – 3 De Junho 2026 – SINTTAV Sindicato Nacional Dos
------------------------------------------------------------------------------------------

 ![Greve Geral – Derrotar o Pacote Laboral – 3 de Junho 2026 – SINTTAV Sindicato Nacional dos](https://sinttav.pt/wp-content/uploads/2026/05/Cartaz_Greve-Geral-Derrotar-o-Pacote-Laboral-3-de-Junho-2026.jpg) <small>sinttav.pt</small>Greve Geral – Derrotar o Pacote Laboral – 3 de Junho 2026 – SINTTAV Sindicato Nacional dos ...

Greve Histórica Em Portugal: Três Milhões Cruzam Os Braços Em Protesto Contra Medidas De
----------------------------------------------------------------------------------------

 ![Greve histórica em Portugal: três milhões cruzam os braços em protesto contra medidas de](https://ogimg.infoglobo.com.br/in/2920985-315-96f/FT1086A/Manifestante-no-Centro-de-Lisboa-na-primeira-greve-geral-em-mais-de-duas-decadasFrancisco-LeongAFP.jpg) <small>oglobo.globo.com</small>Greve histórica em Portugal: três milhões cruzam os braços em protesto contra medidas de ...

Greve Geral: O Que Você Precisa Saber Sobre A Tentativa De Parar O País Pela 1ª Vez Em 20 Anos
----------------------------------------------------------------------------------------------

 ![Greve geral: o que você precisa saber sobre a tentativa de parar o país pela 1ª vez em 20 anos](https://p2.trrsf.com/image/fget/cf/648/0/images.terra.com/2017/04/27/95818331e3c5a7de-1d73-435a-a64c-6edfb0c1fd11.jpg) <small>www.terra.com.br</small>Greve geral: o que você precisa saber sobre a tentativa de parar o país pela 1ª vez em 20 anos

11 DEZ | GREVE GERAL - Expressão Pública Com Concentração às 14h30 No Rossio - STML
-----------------------------------------------------------------------------------

 ![11 DEZ | GREVE GERAL - Expressão Pública com concentração às 14h30 no Rossio - STML](https://www.stml.pt/wp-content/uploads/2025/12/GREVE-GERAL-2-752x1024.jpg) <small>www.stml.pt</small>11 DEZ | GREVE GERAL - Expressão Pública com concentração às 14h30 no Rossio - STML

Às Vésperas Da Greve Geral, Relembre 7 Paralisações Que Marcaram A História Do Brasil
-------------------------------------------------------------------------------------

 ![Às vésperas da greve geral, relembre 7 paralisações que marcaram a história do Brasil](https://smetal.org.br/wp-content/uploads/2019/06/E112948-F00001-G426-850x380.jpeg) <small>smetal.org.br</small>Às vésperas da greve geral, relembre 7 paralisações que marcaram a história do Brasil

Greve Geral: Escolas Fechadas, Transportes Parados E Impacto Nacional
---------------------------------------------------------------------

 ![Greve Geral: Escolas Fechadas, Transportes Parados e Impacto Nacional](https://media.assettype.com/dn%2F2025-12-11%2F9hy4apil%2Fgreve-geral.jpg?w=768&auto=format%2Ccompress) <small>www.dn.pt</small>Greve Geral: Escolas Fechadas, Transportes Parados e Impacto Nacional

Motivos Da Adesão à Greve Geral De 11 De Dezembro De 2025
---------------------------------------------------------

 ![Motivos da adesão à Greve Geral de 11 de dezembro de 2025](https://spzn.pt/uploads/noticias/big_1763717239_6728_SPZN_2025_site_novo_(17).png) <small>spzn.pt</small>Motivos da adesão à Greve Geral de 11 de dezembro de 2025

Pré-Avisos De Greve – Sindicato S.TO.P.
---------------------------------------

 ![Pré-Avisos de Greve – Sindicato S.TO.P.](https://stop-sindicato.pt/wp-content/uploads/2025/11/S.TO_.P.-Cartaz-Greve-Geral-Educacao-11Dez2025_x1000-768x1086.png) <small>stop-sindicato.pt</small>Pré-Avisos de Greve – Sindicato S.TO.P.

Greve Geral é Para Todos Os Trabalhadores! – Escola Portuguesa
--------------------------------------------------------------

 ![Greve Geral é para todos os trabalhadores! – Escola Portuguesa](https://escolapt.wordpress.com/wp-content/uploads/2026/05/706357188_18081656384561625_6623516586727525352_n.jpg) <small>escolapt.wordpress.com</small>Greve Geral é para todos os trabalhadores! – Escola Portuguesa

Greve Geral Contra Pacote Laboral A 11 De Dezembro (vídeo) – RTP Madeira
------------------------------------------------------------------------

 ![Greve geral contra pacote laboral a 11 de dezembro (vídeo) – RTP Madeira](https://madeira.rtp.pt/wp-content/uploads/2025/11/DOC.20251108.45998234.ACOT9063-scaled.jpg) <small>madeira.rtp.pt</small>Greve geral contra pacote laboral a 11 de dezembro (vídeo) – RTP Madeira

Greve Geral Do Próximo Dia 14 Pode Ser A Maior Da História - Sinasefe
---------------------------------------------------------------------

 ![Greve Geral do próximo dia 14 pode ser a maior da história - Sinasefe](https://sinasefe-sc.org.br/wp-content/uploads/2019/06/greve-geral-do-proximo-dia-14-pode-ser-a-maior-da-historia1560361626997.png) <small>sinasefe-sc.org.br</small>Greve Geral do próximo dia 14 pode ser a maior da história - Sinasefe

SINDEP - Greve Geral 11 De Dezembro
-----------------------------------

 ![SINDEP - Greve Geral 11 de dezembro](https://sindep.pt/images/cartaz_GREVE_GERAL_UGT.jpg) <small>sindep.pt</small>SINDEP - Greve Geral 11 de dezembro

📢 GREVE GERAL — 11 DE DEZEMBRO POSSO FAZER GREVE? Sim. E é Importante Que Saibas Porquê. Todos
----------------------------------------------------------------------------------------------

 ![📢 GREVE GERAL — 11 DE DEZEMBRO POSSO FAZER GREVE? Sim. E é importante que saibas porquê. Todos](https://lookaside.fbsbx.com/lookaside/crawler/media/?media_id=1185258557072905) <small>www.facebook.com</small>📢 GREVE GERAL — 11 DE DEZEMBRO POSSO FAZER GREVE? Sim. E é importante que saibas porquê. Todos ...

greve geral juntou centenas nos aliados. governo fala em adesão "inexpressiva". Pré-avisos de greve – sindicato s.to.p.. A greve geral
