---
title: "Cf Estrela Amadora Avs Futebol Sad - Gustavo assuncao seen during liga portugal game between teams of cf estrela amadora and avs"
description: "Lucas piazon seen during liga portugal game between teams of cf estrela amadora and avs futebol"
date: "2026-08-30"
categories:
- "Uncategorized"
images:
- "https://helpinghandmission.org/wp-content/uploads/truc-tiep/thumbnails/OTgwNDY5MjA2MTE3NDY5NTI2MzI=.webp"
featuredImage: "https://c8.alamy.com/comp/3BAFN4T/lucas-piazon-seen-during-liga-portugal-game-between-teams-of-cf-estrela-amadora-and-avs-futebol-sad-at-estadio-jose-gomes-maciej-rogowski-3BAFN4T.jpg"
featured_image: "https://c8.alamy.com/comp/3BAFJHP/guilermo-ochoa-seen-during-liga-portugal-game-between-teams-of-cf-estrela-amadora-and-avs-futebol-sad-at-estadio-jose-gomes-maciej-rogowski-3BAFJHP.jpg"
image: "https://c8.alamy.com/comp/3BAFKR2/babatunde-akinsola-seen-during-liga-portugal-game-between-teams-of-cf-estrela-amadora-and-avs-futebol-sad-at-estadio-jose-gomes-maciej-rogowski-3BAFKR2.jpg"
---

If you are searching about Fernando Fonseca seen during Liga Portugal game between teams of CF Estrela Amadora and AVS you've visit to the right page. We have 35 Images about Fernando Fonseca seen during Liga Portugal game between teams of CF Estrela Amadora and AVS like Fans of Estrela seen during Liga Portugal game between teams of CF Estrela Amadora and AVS, Issiar Drame and Babatunde Akinsola seen during Liga Portugal game between teams of CF Estrela and also Babatunde Akinsola seen during Liga Portugal game between teams of CF Estrela Amadora and AVS. Here you go:

Fernando Fonseca Seen During Liga Portugal Game Between Teams Of CF Estrela Amadora And AVS
-------------------------------------------------------------------------------------------

 ![Fernando Fonseca seen during Liga Portugal game between teams of CF Estrela Amadora and AVS](https://c8.alamy.com/comp/3BAFT56/fernando-fonseca-seen-during-liga-portugal-game-between-teams-of-cf-estrela-amadora-and-avs-futebol-sad-at-estadio-jose-gomes-maciej-rogowski-3BAFT56.jpg) <small>www.alamy.com</small>Fernando Fonseca seen during Liga Portugal game between teams of CF Estrela Amadora and AVS ...

Gustavo Assuncao Seen During Liga Portugal Game Between Teams Of CF Estrela Amadora And AVS
-------------------------------------------------------------------------------------------

 ![Gustavo Assuncao seen during Liga Portugal game between teams of CF Estrela Amadora and AVS](https://c8.alamy.com/comp/3BAFKDB/gustavo-assuncao-seen-during-liga-portugal-game-between-teams-of-cf-estrela-amadora-and-avs-futebol-sad-at-estadio-jose-gomes-maciej-rogowski-3BAFKDB.jpg) <small>www.alamy.com</small>Gustavo Assuncao seen during Liga Portugal game between teams of CF Estrela Amadora and AVS ...

Babatunde Akinsola Seen During Liga Portugal Game Between Teams Of CF Estrela Amadora And AVS
---------------------------------------------------------------------------------------------

 ![Babatunde Akinsola seen during Liga Portugal game between teams of CF Estrela Amadora and AVS](https://c8.alamy.com/comp/3BAFMR1/babatunde-akinsola-seen-during-liga-portugal-game-between-teams-of-cf-estrela-amadora-and-avs-futebol-sad-at-estadio-jose-gomes-maciej-rogowski-3BAFMR1.jpg) <small>www.alamy.com</small>Babatunde Akinsola seen during Liga Portugal game between teams of CF Estrela Amadora and AVS ...

Link Xem Trực Tiếp CF Estrela Amadora SAD Vs AVS Futebol SAD Lúc 21:30, Ngày 11/05/2025
---------------------------------------------------------------------------------------

 ![Link xem trực tiếp CF Estrela Amadora SAD vs AVS Futebol SAD lúc 21:30, ngày 11/05/2025](https://helpinghandmission.org/wp-content/uploads/truc-tiep/thumbnails/OTgwNDY5MjA2MTE3NDY5NTI2MzI=.webp) <small>helpinghandmission.org</small>Link xem trực tiếp CF Estrela Amadora SAD vs AVS Futebol SAD lúc 21:30, ngày 11/05/2025 ...

Gustavo Assuncao Seen During Liga Portugal Game Between Teams Of CF Estrela Amadora And AVS
-------------------------------------------------------------------------------------------

 ![Gustavo Assuncao seen during Liga Portugal game between teams of CF Estrela Amadora and AVS](https://c8.alamy.com/comp/3BAFRPD/gustavo-assuncao-seen-during-liga-portugal-game-between-teams-of-cf-estrela-amadora-and-avs-futebol-sad-at-estadio-jose-gomes-maciej-rogowski-3BAFRPD.jpg) <small>www.alamy.com</small>Gustavo Assuncao seen during Liga Portugal game between teams of CF Estrela Amadora and AVS ...

Babatunde Akinsola Seen During Liga Portugal Game Between Teams Of CF Estrela Amadora And AVS
---------------------------------------------------------------------------------------------

 ![Babatunde Akinsola seen during Liga Portugal game between teams of CF Estrela Amadora and AVS](https://c8.alamy.com/comp/3BAFKR2/babatunde-akinsola-seen-during-liga-portugal-game-between-teams-of-cf-estrela-amadora-and-avs-futebol-sad-at-estadio-jose-gomes-maciej-rogowski-3BAFKR2.jpg) <small>www.alamy.com</small>Babatunde Akinsola seen during Liga Portugal game between teams of CF Estrela Amadora and AVS ...

Gustavo Assuncao Seen During Liga Portugal Game Between Teams Of CF Estrela Amadora And AVS
-------------------------------------------------------------------------------------------

 ![Gustavo Assuncao seen during Liga Portugal game between teams of CF Estrela Amadora and AVS](https://c8.alamy.com/comp/3BAFMDT/gustavo-assuncao-seen-during-liga-portugal-game-between-teams-of-cf-estrela-amadora-and-avs-futebol-sad-at-estadio-jose-gomes-maciej-rogowski-3BAFMDT.jpg) <small>www.alamy.com</small>Gustavo Assuncao seen during Liga Portugal game between teams of CF Estrela Amadora and AVS ...

Vasco Lopes Seen During Liga Portugal Game Between Teams Of CF Estrela Amadora And AVS Futebol
----------------------------------------------------------------------------------------------

 ![Vasco Lopes seen during Liga Portugal game between teams of CF Estrela Amadora and AVS Futebol](https://l450v.alamy.com/450v/3bafk33/vasco-lopes-seen-during-liga-portugal-game-between-teams-of-cf-estrela-amadora-and-avs-futebol-sad-at-estadio-jose-gomes-maciej-rogowski-3bafk33.jpg) <small>www.alamy.com</small>Vasco Lopes seen during Liga Portugal game between teams of CF Estrela Amadora and AVS Futebol ...

Fans Of Estrela Seen During Liga Portugal Game Between Teams Of CF Estrela Amadora And AVS
------------------------------------------------------------------------------------------

 ![Fans of Estrela seen during Liga Portugal game between teams of CF Estrela Amadora and AVS](https://c8.alamy.com/comp/3BAFP5B/fans-of-estrela-seen-during-liga-portugal-game-between-teams-of-cf-estrela-amadora-and-avs-futebol-sad-at-estadio-jose-gomes-maciej-rogowski-3BAFP5B.jpg) <small>www.alamy.com</small>Fans of Estrela seen during Liga Portugal game between teams of CF Estrela Amadora and AVS ...

Gustavo Assuncao Seen During Liga Portugal Game Between Teams Of CF Estrela Amadora And AVS
-------------------------------------------------------------------------------------------

 ![Gustavo Assuncao seen during Liga Portugal game between teams of CF Estrela Amadora and AVS](https://c8.alamy.com/comp/3BAFRPE/gustavo-assuncao-seen-during-liga-portugal-game-between-teams-of-cf-estrela-amadora-and-avs-futebol-sad-at-estadio-jose-gomes-maciej-rogowski-3BAFRPE.jpg) <small>www.alamy.com</small>Gustavo Assuncao seen during Liga Portugal game between teams of CF Estrela Amadora and AVS ...

Lucas Piazon Seen During Liga Portugal Game Between Teams Of CF Estrela Amadora And AVS Futebol
-----------------------------------------------------------------------------------------------

 ![Lucas Piazon seen during Liga Portugal game between teams of CF Estrela Amadora and AVS Futebol](https://c8.alamy.com/comp/3BAFJAA/lucas-piazon-seen-during-liga-portugal-game-between-teams-of-cf-estrela-amadora-and-avs-futebol-sad-at-estadio-jose-gomes-maciej-rogowski-3BAFJAA.jpg) <small>www.alamy.com</small>Lucas Piazon seen during Liga Portugal game between teams of CF Estrela Amadora and AVS Futebol ...

Gustavo Assuncao Seen During Liga Portugal Game Between Teams Of CF Estrela Amadora And AVS
-------------------------------------------------------------------------------------------

 ![Gustavo Assuncao seen during Liga Portugal game between teams of CF Estrela Amadora and AVS](https://c8.alamy.com/comp/3BAFJE7/gustavo-assuncao-seen-during-liga-portugal-game-between-teams-of-cf-estrela-amadora-and-avs-futebol-sad-at-estadio-jose-gomes-maciej-rogowski-3BAFJE7.jpg) <small>www.alamy.com</small>Gustavo Assuncao seen during Liga Portugal game between teams of CF Estrela Amadora and AVS ...

Lucas Piazon Seen During Liga Portugal Game Between Teams Of CF Estrela Amadora And AVS Futebol
-----------------------------------------------------------------------------------------------

 ![Lucas Piazon seen during Liga Portugal game between teams of CF Estrela Amadora and AVS Futebol](https://c8.alamy.com/comp/3BAFN4T/lucas-piazon-seen-during-liga-portugal-game-between-teams-of-cf-estrela-amadora-and-avs-futebol-sad-at-estadio-jose-gomes-maciej-rogowski-3BAFN4T.jpg) <small>www.alamy.com</small>Lucas Piazon seen during Liga Portugal game between teams of CF Estrela Amadora and AVS Futebol ...

Jaume Grau Seen During Liga Portugal Game Between Teams Of CF Estrela Amadora And AVS Futebol
---------------------------------------------------------------------------------------------

 ![Jaume Grau seen during Liga Portugal game between teams of CF Estrela Amadora and AVS Futebol](https://c8.alamy.com/comp/3BAFKD5/jaume-grau-seen-during-liga-portugal-game-between-teams-of-cf-estrela-amadora-and-avs-futebol-sad-at-estadio-jose-gomes-maciej-rogowski-3BAFKD5.jpg) <small>www.alamy.com</small>Jaume Grau seen during Liga Portugal game between teams of CF Estrela Amadora and AVS Futebol ...

Francisco Meixedo Seen During Liga Portugal Game Between Teams Of CF Estrela Amadora And AVS
--------------------------------------------------------------------------------------------

 ![Francisco Meixedo seen during Liga Portugal game between teams of CF Estrela Amadora and AVS](https://c8.alamy.com/comp/3BAFRM7/francisco-meixedo-seen-during-liga-portugal-game-between-teams-of-cf-estrela-amadora-and-avs-futebol-sad-at-estadio-jose-gomes-maciej-rogowski-3BAFRM7.jpg) <small>www.alamy.com</small>Francisco Meixedo seen during Liga Portugal game between teams of CF Estrela Amadora and AVS ...

Issiar Drame And Babatunde Akinsola Seen During Liga Portugal Game Between Teams Of CF Estrela
----------------------------------------------------------------------------------------------

 ![Issiar Drame and Babatunde Akinsola seen during Liga Portugal game between teams of CF Estrela](https://c8.alamy.com/comp/3BAFPF7/issiar-drame-and-babatunde-akinsola-seen-during-liga-portugal-game-between-teams-of-cf-estrela-amadora-and-avs-futebol-sad-at-estadio-jose-gomes-mac-3BAFPF7.jpg) <small>www.alamy.com</small>Issiar Drame and Babatunde Akinsola seen during Liga Portugal game between teams of CF Estrela ...

Fernando Fonseca Seen During Liga Portugal Game Between Teams Of CF Estrela Amadora And AVS
-------------------------------------------------------------------------------------------

 ![Fernando Fonseca seen during Liga Portugal game between teams of CF Estrela Amadora and AVS](https://c8.alamy.com/comp/3BAFP7T/fernando-fonseca-seen-during-liga-portugal-game-between-teams-of-cf-estrela-amadora-and-avs-futebol-sad-at-estadio-jose-gomes-maciej-rogowski-3BAFP7T.jpg) <small>www.alamy.com</small>Fernando Fonseca seen during Liga Portugal game between teams of CF Estrela Amadora and AVS ...

Jose Mota And Jose Faria Seen During Liga Portugal Game Between Teams Of CF Estrela Amadora And
-----------------------------------------------------------------------------------------------

 ![Jose Mota and Jose Faria seen during Liga Portugal game between teams of CF Estrela Amadora and](https://c8.alamy.com/comp/3BAFRD7/jose-mota-and-jose-faria-seen-during-liga-portugal-game-between-teams-of-cf-estrela-amadora-and-avs-futebol-sad-at-estadio-jose-gomes-maciej-rogowsk-3BAFRD7.jpg) <small>www.alamy.com</small>Jose Mota and Jose Faria seen during Liga Portugal game between teams of CF Estrela Amadora and ...

Gustavo Assuncao Seen During Liga Portugal Game Between Teams Of CF Estrela Amadora And AVS
-------------------------------------------------------------------------------------------

 ![Gustavo Assuncao seen during Liga Portugal game between teams of CF Estrela Amadora and AVS](https://c8.alamy.com/comp/3BAFM9C/gustavo-assuncao-seen-during-liga-portugal-game-between-teams-of-cf-estrela-amadora-and-avs-futebol-sad-at-estadio-jose-gomes-maciej-rogowski-3BAFM9C.jpg) <small>www.alamy.com</small>Gustavo Assuncao seen during Liga Portugal game between teams of CF Estrela Amadora and AVS ...

Leonel Bucca Seen During Liga Portugal Game Between Teams Of CF Estrela Amadora And AVS Futebol
-----------------------------------------------------------------------------------------------

 ![Leonel Bucca seen during Liga Portugal game between teams of CF Estrela Amadora and AVS Futebol](https://c8.alamy.com/comp/3BAFP56/leonel-bucca-seen-during-liga-portugal-game-between-teams-of-cf-estrela-amadora-and-avs-futebol-sad-at-estadio-jose-gomes-maciej-rogowski-3BAFP56.jpg) <small>www.alamy.com</small>Leonel Bucca seen during Liga Portugal game between teams of CF Estrela Amadora and AVS Futebol ...

Lucas Piazon Seen During Liga Portugal Game Between Teams Of CF Estrela Amadora And AVS Futebol
-----------------------------------------------------------------------------------------------

 ![Lucas Piazon seen during Liga Portugal game between teams of CF Estrela Amadora and AVS Futebol](https://c8.alamy.com/comp/3BAFMRF/lucas-piazon-seen-during-liga-portugal-game-between-teams-of-cf-estrela-amadora-and-avs-futebol-sad-at-estadio-jose-gomes-maciej-rogowski-3BAFMRF.jpg) <small>www.alamy.com</small>Lucas Piazon seen during Liga Portugal game between teams of CF Estrela Amadora and AVS Futebol ...

Guilermo Ochoa Seen During Liga Portugal Game Between Teams Of CF Estrela Amadora And AVS
-----------------------------------------------------------------------------------------

 ![Guilermo Ochoa seen during Liga Portugal game between teams of CF Estrela Amadora and AVS](https://c8.alamy.com/comp/3BAFJHP/guilermo-ochoa-seen-during-liga-portugal-game-between-teams-of-cf-estrela-amadora-and-avs-futebol-sad-at-estadio-jose-gomes-maciej-rogowski-3BAFJHP.jpg) <small>www.alamy.com</small>Guilermo Ochoa seen during Liga Portugal game between teams of CF Estrela Amadora and AVS ...

Lucas Piazon Seen During Liga Portugal Game Between Teams Of CF Estrela Amadora And AVS Futebol
-----------------------------------------------------------------------------------------------

 ![Lucas Piazon seen during Liga Portugal game between teams of CF Estrela Amadora and AVS Futebol](https://c8.alamy.com/comp/3BAFKP8/lucas-piazon-seen-during-liga-portugal-game-between-teams-of-cf-estrela-amadora-and-avs-futebol-sad-at-estadio-jose-gomes-maciej-rogowski-3BAFKP8.jpg) <small>www.alamy.com</small>Lucas Piazon seen during Liga Portugal game between teams of CF Estrela Amadora and AVS Futebol ...

Tiago Martins Seen During Liga Portugal Game Between Teams Of CF Estrela Amadora And AVS Futebol
------------------------------------------------------------------------------------------------

 ![Tiago Martins seen during Liga Portugal game between teams of CF Estrela Amadora and AVS Futebol](https://c8.alamy.com/comp/3BAFM4T/tiago-martins-seen-during-liga-portugal-game-between-teams-of-cf-estrela-amadora-and-avs-futebol-sad-at-estadio-jose-gomes-maciej-rogowski-3BAFM4T.jpg) <small>www.alamy.com</small>Tiago Martins seen during Liga Portugal game between teams of CF Estrela Amadora and AVS Futebol ...

Jose Mota And Jose Faria Seen During Liga Portugal Game Between Teams Of CF Estrela Amadora And
-----------------------------------------------------------------------------------------------

 ![Jose Mota and Jose Faria seen during Liga Portugal game between teams of CF Estrela Amadora and](https://c8.alamy.com/comp/3BAFRD3/jose-mota-and-jose-faria-seen-during-liga-portugal-game-between-teams-of-cf-estrela-amadora-and-avs-futebol-sad-at-estadio-jose-gomes-maciej-rogowsk-3BAFRD3.jpg) <small>www.alamy.com</small>Jose Mota and Jose Faria seen during Liga Portugal game between teams of CF Estrela Amadora and ...

Lucas Piazon Seen During Liga Portugal Game Between Teams Of CF Estrela Amadora And AVS Futebol
-----------------------------------------------------------------------------------------------

 ![Lucas Piazon seen during Liga Portugal game between teams of CF Estrela Amadora and AVS Futebol](https://c8.alamy.com/comp/3BAFK30/lucas-piazon-seen-during-liga-portugal-game-between-teams-of-cf-estrela-amadora-and-avs-futebol-sad-at-estadio-jose-gomes-maciej-rogowski-3BAFK30.jpg) <small>www.alamy.com</small>Lucas Piazon seen during Liga Portugal game between teams of CF Estrela Amadora and AVS Futebol ...

Jaume Grau Seen During Liga Portugal Game Between Teams Of CF Estrela Amadora And AVS Futebol
---------------------------------------------------------------------------------------------

 ![Jaume Grau seen during Liga Portugal game between teams of CF Estrela Amadora and AVS Futebol](https://c8.alamy.com/comp/3BAFR8E/jaume-grau-seen-during-liga-portugal-game-between-teams-of-cf-estrela-amadora-and-avs-futebol-sad-at-estadio-jose-gomes-maciej-rogowski-3BAFR8E.jpg) <small>www.alamy.com</small>Jaume Grau seen during Liga Portugal game between teams of CF Estrela Amadora and AVS Futebol ...

Jose Mota Seen During Liga Portugal Game Between Teams Of CF Estrela Amadora And AVS Futebol SAD
------------------------------------------------------------------------------------------------

 ![Jose Mota seen during Liga Portugal game between teams of CF Estrela Amadora and AVS Futebol SAD](https://c8.alamy.com/comp/3BAFR3W/jose-mota-seen-during-liga-portugal-game-between-teams-of-cf-estrela-amadora-and-avs-futebol-sad-at-estadio-jose-gomes-maciej-rogowski-3BAFR3W.jpg) <small>www.alamy.com</small>Jose Mota seen during Liga Portugal game between teams of CF Estrela Amadora and AVS Futebol SAD ...

Babatunde Akinsola Seen During Liga Portugal Game Between Teams Of CF Estrela Amadora And AVS
---------------------------------------------------------------------------------------------

 ![Babatunde Akinsola seen during Liga Portugal game between teams of CF Estrela Amadora and AVS](https://c8.alamy.com/comp/3BAFME9/babatunde-akinsola-seen-during-liga-portugal-game-between-teams-of-cf-estrela-amadora-and-avs-futebol-sad-at-estadio-jose-gomes-maciej-rogowski-3BAFME9.jpg) <small>www.alamy.com</small>Babatunde Akinsola seen during Liga Portugal game between teams of CF Estrela Amadora and AVS ...

Jose Mota Seen During Liga Portugal Game Between Teams Of CF Estrela Amadora And AVS Futebol SAD
------------------------------------------------------------------------------------------------

 ![Jose Mota seen during Liga Portugal game between teams of CF Estrela Amadora and AVS Futebol SAD](https://c8.alamy.com/comp/3BAFPHP/jose-mota-seen-during-liga-portugal-game-between-teams-of-cf-estrela-amadora-and-avs-futebol-sad-at-estadio-jose-gomes-maciej-rogowski-3BAFPHP.jpg) <small>www.alamy.com</small>Jose Mota seen during Liga Portugal game between teams of CF Estrela Amadora and AVS Futebol SAD ...

Fans Of Estrela Seen During Liga Portugal Game Between Teams Of CF Estrela Amadora And AVS
------------------------------------------------------------------------------------------

 ![Fans of Estrela seen during Liga Portugal game between teams of CF Estrela Amadora and AVS](https://c8.alamy.com/comp/3BAFMRB/fans-of-estrela-seen-during-liga-portugal-game-between-teams-of-cf-estrela-amadora-and-avs-futebol-sad-at-estadio-jose-gomes-maciej-rogowski-3BAFMRB.jpg) <small>www.alamy.com</small>Fans of Estrela seen during Liga Portugal game between teams of CF Estrela Amadora and AVS ...

Babatunde Akinsola Seen During Liga Portugal Game Between Teams Of CF Estrela Amadora And AVS
---------------------------------------------------------------------------------------------

 ![Babatunde Akinsola seen during Liga Portugal game between teams of CF Estrela Amadora and AVS](https://c8.alamy.com/comp/3BAFM3T/babatunde-akinsola-seen-during-liga-portugal-game-between-teams-of-cf-estrela-amadora-and-avs-futebol-sad-at-estadio-jose-gomes-maciej-rogowski-3BAFM3T.jpg) <small>www.alamy.com</small>Babatunde Akinsola seen during Liga Portugal game between teams of CF Estrela Amadora and AVS ...

Prognóstico AVS Futebol SAD Estrela Amadora - Liga Portugal - 28/02/26
----------------------------------------------------------------------

 ![Prognóstico AVS Futebol SAD Estrela Amadora - Liga Portugal - 28/02/26](https://static.sportytrader.com/betting-tip-thumbnail/prod/330634.webp) <small>www.sportytrader.pt</small>Prognóstico AVS Futebol SAD Estrela Amadora - Liga Portugal - 28/02/26

Guilermo Ochoa Seen During Liga Portugal Game Between Teams Of CF Estrela Amadora And AVS
-----------------------------------------------------------------------------------------

 ![Guilermo Ochoa seen during Liga Portugal game between teams of CF Estrela Amadora and AVS](https://c8.alamy.com/comp/3BAFJGC/guilermo-ochoa-seen-during-liga-portugal-game-between-teams-of-cf-estrela-amadora-and-avs-futebol-sad-at-estadio-jose-gomes-maciej-rogowski-3BAFJGC.jpg) <small>www.alamy.com</small>Guilermo Ochoa seen during Liga Portugal game between teams of CF Estrela Amadora and AVS ...

Lucas Piazon Seen During Liga Portugal Game Between Teams Of CF Estrela Amadora And AVS Futebol
-----------------------------------------------------------------------------------------------

 ![Lucas Piazon seen during Liga Portugal game between teams of CF Estrela Amadora and AVS Futebol](https://c8.alamy.com/comp/3BAFM4B/lucas-piazon-seen-during-liga-portugal-game-between-teams-of-cf-estrela-amadora-and-avs-futebol-sad-at-estadio-jose-gomes-maciej-rogowski-3BAFM4B.jpg) <small>www.alamy.com</small>Lucas Piazon seen during Liga Portugal game between teams of CF Estrela Amadora and AVS Futebol ...

Issiar drame and babatunde akinsola seen during liga portugal game between teams of cf estrela. Gustavo assuncao seen during liga portugal game between teams of cf estrela amadora and avs .... Jose mota seen during liga portugal game between teams of cf estrela amadora and avs futebol sad ...
