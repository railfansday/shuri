---
title: "Sporting Cp Vs Cf Estrela Amadora - sporting cp vs cf estrela da amadora 2024"
description: "Team of estrela amadora seen during liga portugal game between teams of sporting cp and cf ..."
date: "2026-03-29"
categories:
- "Uncategorized"
images:
- "https://i.ytimg.com/vi/uiW7_L8REmc/maxresdefault.jpg"
featuredImage: "https://www.solardonorte.org/wp-content/uploads/2026/04/produto-estrela-1536x847.png"
featured_image: "https://c8.alamy.com/comp/3D8FDC2/lisbon-portugal-30-november-2025-players-of-sporting-cp-celebrate-the-goal-during-the-sporting-cp-against-estrela-da-amadora-for-the-portuguese-liga-at-estadio-jose-alvalade-in-lisbon-credit-ricardo-rocha-alamy-live-news-3D8FDC2.jpg"
image: "https://c8.alamy.com/comp/2YEXHGD/portugal-01st-nov-2024-ruben-amorim-head-coach-of-sporting-cp-during-the-liga-portugal-betclic-match-between-sporting-cp-and-cf-estrela-amadora-at-estadio-jose-de-alvalade-on-november-01th-2024-in-lisbon-portugal-liga-portugal-betclic-sporting-cp-vs-cf-estrela-amadora-valter-gouveiaspp-credit-spp-sport-press-photo-alamy-live-news-2YEXHGD.jpg"
---

If you are looking for Sebastian Coates of Sporting CP with Leo Jaba of CF Estrela da... News Photo - Getty Images you've came to the right web. We have 35 Pics about Sebastian Coates of Sporting CP with Leo Jaba of CF Estrela da... News Photo - Getty Images like Portugal. 01st Nov, 2024. Pedro Gonçalves midfielder of Sporting CP during the Liga Portugal, Sporting CP vs CF Estrela da Amadora 2024 - 2025 Primeira Liga and also Hidemasa Morita of Sporting CP with Nani of CF Estrela da Amadora in... News Photo - Getty Images. Here you go:

Sebastian Coates Of Sporting CP With Leo Jaba Of CF Estrela Da... News Photo - Getty Images
-------------------------------------------------------------------------------------------

 ![Sebastian Coates of Sporting CP with Leo Jaba of CF Estrela da... News Photo - Getty Images](https://media.gettyimages.com/id/1765581445/photo/sporting-cp-v-cf-estrela-da-amadora-liga-portugal-betclic.jpg?s=1024x1024&w=gi&k=20&c=IZOrycW1WcSbNOjdqw0aSqY8WrfcsARlT5EUL7l0uv4=) <small>www.gettyimages.co.uk</small>Sebastian Coates of Sporting CP with Leo Jaba of CF Estrela da... News Photo - Getty Images

Hidemasa Morita Of Sporting CP With Nani Of CF Estrela Da Amadora In... News Photo - Getty Images
-------------------------------------------------------------------------------------------------

 ![Hidemasa Morita of Sporting CP with Nani of CF Estrela da Amadora in... News Photo - Getty Images](https://media.gettyimages.com/id/2181647834/photo/sporting-cp-v-cf-estrela-da-amadora-liga-portugal-betclic.jpg?s=1024x1024&w=gi&k=20&c=QGSy10ieLWcGgBoc-orBR2MOjqSb2M_V65jmnmV2bec=) <small>www.gettyimages.com</small>Hidemasa Morita of Sporting CP with Nani of CF Estrela da Amadora in... News Photo - Getty Images

Sporting CP Vs Estrela Da Amadora (1 Nov 2024) 🔥 Video Highlights - FootyRoom
-----------------------------------------------------------------------------

 ![Sporting CP vs Estrela da Amadora (1 Nov 2024) 🔥 Video Highlights - FootyRoom](https://i.ytimg.com/vi/vLbYqqJXM7o/maxresdefault.jpg) <small>footyroom.co</small>Sporting CP vs Estrela da Amadora (1 Nov 2024) 🔥 Video Highlights - FootyRoom

Vlog: Sporting CP 3 Vs 2 CF Estrela Da Amadora (Liga Portugal Betclic 23/24) - YouTube
--------------------------------------------------------------------------------------

 ![Vlog: Sporting CP 3 vs 2 CF Estrela da Amadora (Liga Portugal Betclic 23/24) - YouTube](https://i.ytimg.com/vi/geN2H_8Jnfw/maxresdefault.jpg) <small>www.youtube.com</small>Vlog: Sporting CP 3 vs 2 CF Estrela da Amadora (Liga Portugal Betclic 23/24) - YouTube

Sporting CP Vs. Estrela Da Amadora 2023-2024 | Footballia
---------------------------------------------------------

 ![Sporting CP vs. Estrela da Amadora 2023-2024 | Footballia](https://footballia.eu/cache/matches/f2ed4bf1265279e42d2c83744d763b81.png) <small>footballia.eu</small>Sporting CP vs. Estrela da Amadora 2023-2024 | Footballia

Portugal. 01st Nov, 2024. Viktor Gyokeres Forward Of Sporting CP And Rúben Lima Defender Of
-------------------------------------------------------------------------------------------

 ![Portugal. 01st Nov, 2024. Viktor Gyokeres forward of Sporting CP and Rúben Lima defender of](https://c8.alamy.com/comp/2YEXK3J/portugal-01st-nov-2024-viktor-gyokeres-forward-of-sporting-cp-and-rben-lima-defender-of-estrela-amadora-during-the-liga-portugal-betclic-match-between-sporting-cp-and-cf-estrela-amadora-at-estadio-jose-de-alvalade-on-november-01th-2024-in-lisbon-portugal-liga-portugal-betclic-sporting-cp-vs-cf-estrela-amadora-valter-gouveiaspp-credit-spp-sport-press-photo-alamy-live-news-2YEXK3J.jpg) <small>www.alamy.com</small>Portugal. 01st Nov, 2024. Viktor Gyokeres forward of Sporting CP and Rúben Lima defender of ...

Lisbon, Portugal. 30 November 2025. Players Of Sporting CP Celebrate The Goal During The
----------------------------------------------------------------------------------------

 ![Lisbon, Portugal. 30 November 2025. Players of Sporting CP celebrate the goal during the](https://c8.alamy.com/comp/3D8FDC2/lisbon-portugal-30-november-2025-players-of-sporting-cp-celebrate-the-goal-during-the-sporting-cp-against-estrela-da-amadora-for-the-portuguese-liga-at-estadio-jose-alvalade-in-lisbon-credit-ricardo-rocha-alamy-live-news-3D8FDC2.jpg) <small>www.alamy.com</small>Lisbon, Portugal. 30 November 2025. Players of Sporting CP celebrate the goal during the ...

Goncalo Inacio Of Sporting CP In Action During The Match Between Sporting CP And CF Estrela Da
----------------------------------------------------------------------------------------------

 ![Goncalo Inacio of Sporting CP in action during the match between Sporting CP and CF Estrela da](https://c8.alamy.com/comp/2YF7WY4/goncalo-inacio-of-sporting-cp-in-action-during-the-match-between-sporting-cp-and-cf-estrela-da-amadora-for-the-liga-portugal-betclic-at-estadio-jose-alvalade-final-score-sporting-cp-5-1-cf-estrela-da-amadora-2YF7WY4.jpg) <small>www.alamy.com</small>Goncalo Inacio of Sporting CP in action during the match between Sporting CP and CF Estrela da ...

Portugal. 01st Nov, 2024. Viktor Gyokeres Forward Of Sporting CP Penalty During The Liga
----------------------------------------------------------------------------------------

 ![Portugal. 01st Nov, 2024. Viktor Gyokeres forward of Sporting CP penalty during the Liga](https://c8.alamy.com/comp/2YEXE0J/portugal-01st-nov-2024-viktor-gyokeres-forward-of-sporting-cp-penalty-during-the-liga-portugal-betclic-match-between-sporting-cp-and-cf-estrela-amadora-at-estadio-jose-de-alvalade-on-november-01th-2024-in-lisbon-portugal-liga-portugal-betclic-sporting-cp-vs-cf-estrela-amadora-valter-gouveiaspp-credit-spp-sport-press-photo-alamy-live-news-2YEXE0J.jpg) <small>www.alamy.com</small>Portugal. 01st Nov, 2024. Viktor Gyokeres forward of Sporting CP penalty during the Liga ...

CF Estrela Amadora Vs Sporting CP B Live Score, H2H And Lineups | Sofascore
---------------------------------------------------------------------------

 ![CF Estrela Amadora vs Sporting CP B live score, H2H and lineups | Sofascore](https://img.sofascore.com/api/v1/event/12532658/share-image/16x9) <small>www.sofascore.com</small>CF Estrela Amadora vs Sporting CP B live score, H2H and lineups | Sofascore

(L-R) Viktor Gyokeres Of Sporting CP With Francisco Reis Ferreira Of CF Estrela Da Amadora In
---------------------------------------------------------------------------------------------

 ![(L-R) Viktor Gyokeres of Sporting CP with Francisco Reis Ferreira of CF Estrela da Amadora in](https://c8.alamy.com/comp/2YF7X62/l-r-viktor-gyokeres-of-sporting-cp-with-francisco-reis-ferreira-of-cf-estrela-da-amadora-in-action-during-the-match-between-sporting-cp-and-cf-estrela-da-amadora-for-the-liga-portugal-betclic-at-estadio-jose-alvalade-final-score-sporting-cp-5-1-cf-estrela-da-amadora-2YF7X62.jpg) <small>www.alamy.com</small>(L-R) Viktor Gyokeres of Sporting CP with Francisco Reis Ferreira of CF Estrela da Amadora in ...

Highlight Sporting CP Vs CF Estrela Amadora SAD
-----------------------------------------------

 ![Highlight Sporting CP vs CF Estrela Amadora SAD](https://img.thesports.com/match/gif/cover/1056234148-177594088835472095.png) <small>www.fifadata.com</small>Highlight Sporting CP vs CF Estrela Amadora SAD

Portugal. 01st Nov, 2024. Nani Forward Of Estrela Amadora Reacts During The Liga Portugal
-----------------------------------------------------------------------------------------

 ![Portugal. 01st Nov, 2024. Nani forward of Estrela Amadora reacts during the Liga Portugal](https://c8.alamy.com/comp/2YEXET5/portugal-01st-nov-2024-nani-forward-of-estrela-amadora-reacts-during-the-liga-portugal-betclic-match-between-sporting-cp-and-cf-estrela-amadora-at-estadio-jose-de-alvalade-on-november-01th-2024-in-lisbon-portugal-liga-portugal-betclic-sporting-cp-vs-cf-estrela-amadora-valter-gouveiaspp-credit-spp-sport-press-photo-alamy-live-news-2YEXET5.jpg) <small>www.alamy.com</small>Portugal. 01st Nov, 2024. Nani forward of Estrela Amadora reacts during the Liga Portugal ...

Portugal. 01st Nov, 2024. Viktor Gyokeres Forward Of Sporting CP Celebrates After Scoring A Goal
------------------------------------------------------------------------------------------------

 ![Portugal. 01st Nov, 2024. Viktor Gyokeres forward of Sporting CP celebrates after scoring a goal](https://c8.alamy.com/comp/2YEXK1F/portugal-01st-nov-2024-viktor-gyokeres-forward-of-sporting-cp-celebrates-after-scoring-a-goal-during-the-liga-portugal-betclic-match-between-sporting-cp-and-cf-estrela-amadora-at-estadio-jose-de-alvalade-on-november-01th-2024-in-lisbon-portugal-liga-portugal-betclic-sporting-cp-vs-cf-estrela-amadora-valter-gouveiaspp-credit-spp-sport-press-photo-alamy-live-news-2YEXK1F.jpg) <small>www.alamy.com</small>Portugal. 01st Nov, 2024. Viktor Gyokeres forward of Sporting CP celebrates after scoring a goal ...

Estrela Amadora Vs Sporting CP 0-1 | Liga Portugal 2026 | Simulação - YouTube
-----------------------------------------------------------------------------

 ![Estrela Amadora vs Sporting CP 0-1 | Liga Portugal 2026 | Simulação - YouTube](https://i.ytimg.com/vi/uiW7_L8REmc/maxresdefault.jpg) <small>www.youtube.com</small>Estrela Amadora vs Sporting CP 0-1 | Liga Portugal 2026 | Simulação - YouTube

Highlight Sporting CP Vs CF Estrela Amadora SAD
-----------------------------------------------

 ![Highlight Sporting CP vs CF Estrela Amadora SAD](https://img.thesports.com/match/gif/cover/1056234148-17759425622548757.png) <small>www.fifadata.com</small>Highlight Sporting CP vs CF Estrela Amadora SAD

Lisbon, Portugal. 30 November 2025. Players Of Sporting CP Celebrate The Goal During The
----------------------------------------------------------------------------------------

 ![Lisbon, Portugal. 30 November 2025. Players of Sporting CP celebrate the goal during the](https://c8.alamy.com/comp/3D8FWWH/lisbon-portugal-30-november-2025-players-of-sporting-cp-celebrate-the-goal-during-the-sporting-cp-against-estrela-da-amadora-for-the-portuguese-liga-at-estadio-jose-alvalade-in-lisbon-credit-ricardo-rocha-alamy-live-news-3D8FWWH.jpg) <small>www.alamy.com</small>Lisbon, Portugal. 30 November 2025. Players of Sporting CP celebrate the goal during the ...

Sporting CP Vs CF Estrela Da Amadora In Lisboa - 01 Nov 2024 Daniel Braganca Of Sporting CP With
------------------------------------------------------------------------------------------------

 ![Sporting CP Vs CF Estrela da Amadora in Lisboa - 01 Nov 2024 Daniel Braganca of Sporting CP with](https://cdn.imago-images.com/bild/sp/1053373202/s.jpg) <small>www.imago-images.com</small>Sporting CP Vs CF Estrela da Amadora in Lisboa - 01 Nov 2024 Daniel Braganca of Sporting CP with

Portugal. 01st Nov, 2024. Ruben Amorim Head Coach Of Sporting CP During The Liga Portugal
-----------------------------------------------------------------------------------------

 ![Portugal. 01st Nov, 2024. Ruben Amorim head coach of Sporting CP during the Liga Portugal](https://c8.alamy.com/comp/2YEXHGD/portugal-01st-nov-2024-ruben-amorim-head-coach-of-sporting-cp-during-the-liga-portugal-betclic-match-between-sporting-cp-and-cf-estrela-amadora-at-estadio-jose-de-alvalade-on-november-01th-2024-in-lisbon-portugal-liga-portugal-betclic-sporting-cp-vs-cf-estrela-amadora-valter-gouveiaspp-credit-spp-sport-press-photo-alamy-live-news-2YEXHGD.jpg) <small>www.alamy.com</small>Portugal. 01st Nov, 2024. Ruben Amorim head coach of Sporting CP during the Liga Portugal ...

Daniel Braganca Of Sporting CP Celebrates After Scoring A Goal During... News Photo - Getty Images
--------------------------------------------------------------------------------------------------

 ![Daniel Braganca of Sporting CP celebrates after scoring a goal during... News Photo - Getty Images](https://media.gettyimages.com/id/1765339593/photo/sporting-cp-v-cf-estrela-da-amadora-liga-portugal-betclic.jpg?s=1024x1024&w=gi&k=20&c=FLOgkyepnd4N32NrCbk4CXc2NXQ8ArTbYpkG8ZftKLI=) <small>www.gettyimages.co.uk</small>Daniel Braganca of Sporting CP celebrates after scoring a goal during... News Photo - Getty Images

Resumo | Liga Portugal: Sporting CP 4-0 CF Estrela Da Amadora - YouTube
-----------------------------------------------------------------------

 ![Resumo | Liga Portugal: Sporting CP 4-0 CF Estrela da Amadora - YouTube](https://i.ytimg.com/vi/WyDD-HjwGog/maxresdefault.jpg) <small>www.youtube.com</small>Resumo | Liga Portugal: Sporting CP 4-0 CF Estrela da Amadora - YouTube

Lisboa, Portugal. 01st Nov, 2024. Sporting CP Fans Seen During The Match Between Sporting CP And
------------------------------------------------------------------------------------------------

 ![Lisboa, Portugal. 01st Nov, 2024. Sporting CP fans seen during the match between Sporting CP and](https://c8.alamy.com/comp/2YF84KH/lisboa-portugal-01st-nov-2024-sporting-cp-fans-seen-during-the-match-between-sporting-cp-and-cf-estrela-da-amadora-for-the-liga-portugal-betclic-at-estadio-jose-alvalade-final-score-sporting-cp-5-1-cf-estrela-da-amadora-photo-by-david-martinssopa-imagessipa-usa-credit-sipa-usaalamy-live-news-2YF84KH.jpg) <small>www.alamy.com</small>Lisboa, Portugal. 01st Nov, 2024. Sporting CP fans seen during the match between Sporting CP and ...

Bilhetes CF Estrela Da Amadora Vs Sporting CP – Liga Portugal 25/26 Betclic 29ª Jornada – Núcleo
------------------------------------------------------------------------------------------------

 ![Bilhetes CF Estrela da Amadora vs Sporting CP – Liga Portugal 25/26 Betclic 29ª jornada – Núcleo](https://www.solardonorte.org/wp-content/uploads/2026/04/produto-estrela-1536x847.png) <small>www.solardonorte.org</small>Bilhetes CF Estrela da Amadora vs Sporting CP – Liga Portugal 25/26 Betclic 29ª jornada – Núcleo ...

Sporting CP Vs CF Estrela Da Amadora 2024 - 2025 Primeira Liga
--------------------------------------------------------------

 ![Sporting CP vs CF Estrela da Amadora 2024 - 2025 Primeira Liga](https://imgs.ticombo.com/tc-images-main/thumbnail/events/sports/sporting-cp-vs-cf-estrela-da-amadora-2024-2025-primeira-liga/thumbnail-48dabb16-badc-4055-96c9-f850705ad812.png) <small>www.ticombo.com</small>Sporting CP vs CF Estrela da Amadora 2024 - 2025 Primeira Liga

Amadora,Portugal,March 29th, 2025: Gyokeres (9 Sporting CP) In Action During The Liga Portugal
----------------------------------------------------------------------------------------------

 ![Amadora,Portugal,March 29th, 2025: Gyokeres (9 Sporting CP) in action during the Liga Portugal](https://c8.alamy.com/comp/3A928JW/amadoraportugalmarch-29th-2025-gyokeres-9-sporting-cp-in-action-during-the-liga-portugal-betclic-game-between-cf-estrela-da-amadora-vs-sporting-cp-estadio-jose-gomes-amadora-on-29th-march-2025-joo-bravo-spp-3A928JW.jpg) <small>www.alamy.com</small>Amadora,Portugal,March 29th, 2025: Gyokeres (9 Sporting CP) in action during the Liga Portugal ...

Portugal. 01st Nov, 2024. Pedro Gonçalves Midfielder Of Sporting CP During The Liga Portugal
--------------------------------------------------------------------------------------------

 ![Portugal. 01st Nov, 2024. Pedro Gonçalves midfielder of Sporting CP during the Liga Portugal](https://c8.alamy.com/comp/2YEXK2J/portugal-01st-nov-2024-pedro-gonalves-midfielder-of-sporting-cp-during-the-liga-portugal-betclic-match-between-sporting-cp-and-cf-estrela-amadora-at-estadio-jose-de-alvalade-on-november-01th-2024-in-lisbon-portugal-liga-portugal-betclic-sporting-cp-vs-cf-estrela-amadora-valter-gouveiaspp-credit-spp-sport-press-photo-alamy-live-news-2YEXK2J.jpg) <small>www.alamy.com</small>Portugal. 01st Nov, 2024. Pedro Gonçalves midfielder of Sporting CP during the Liga Portugal ...

Portugal. 01st Nov, 2024. Viktor Gyokeres Forward Of Sporting CP And Ferro Defender Of Estrela
----------------------------------------------------------------------------------------------

 ![Portugal. 01st Nov, 2024. Viktor Gyokeres forward of Sporting CP and Ferro defender of Estrela](https://c8.alamy.com/comp/2YEXK6N/portugal-01st-nov-2024-viktor-gyokeres-forward-of-sporting-cp-and-ferro-defender-of-estrela-amadora-during-the-liga-portugal-betclic-match-between-sporting-cp-and-cf-estrela-amadora-at-estadio-jose-de-alvalade-on-november-01th-2024-in-lisbon-portugal-liga-portugal-betclic-sporting-cp-vs-cf-estrela-amadora-valter-gouveiaspp-credit-spp-sport-press-photo-alamy-live-news-2YEXK6N.jpg) <small>www.alamy.com</small>Portugal. 01st Nov, 2024. Viktor Gyokeres forward of Sporting CP and Ferro defender of Estrela ...

Luis Suarez 97 Of Sporting CP Celebrates After Scoring During The Liga Portugal Match Between
---------------------------------------------------------------------------------------------

 ![Luis Suarez 97 of Sporting CP celebrates after scoring during the Liga Portugal match between](https://c8.alamy.com/comp/3D8FGMF/luis-suarez-97-of-sporting-cp-celebrates-after-scoring-during-the-liga-portugal-match-between-sporting-cp-vs-estrela-da-amadora-at-estadio-jose-alvalade-on-november-30th2025-photo-by-joao-bravosports-press-photo-3D8FGMF.jpg) <small>www.alamy.com</small>Luis Suarez 97 of Sporting CP celebrates after scoring during the Liga Portugal match between ...

Estrela Amadora Vs Sporting CP EM DIRETO | Liga Portugal 25/26 | EM DIRETO NA GAMEPLAY PES 2021
-----------------------------------------------------------------------------------------------

 ![Estrela Amadora vs Sporting CP EM DIRETO | Liga Portugal 25/26 | EM DIRETO NA GAMEPLAY PES 2021](https://i.ytimg.com/vi/fjLsUL887oM/maxresdefault.jpg) <small>www.youtube.com</small>Estrela Amadora vs Sporting CP EM DIRETO | Liga Portugal 25/26 | EM DIRETO NA GAMEPLAY PES 2021 ...

Pronóstico Estrela Amadora Sporting CP - Liga Portugal 11/04/26
---------------------------------------------------------------

 ![Pronóstico Estrela Amadora Sporting CP - Liga Portugal 11/04/26](https://static.sportytrader.com/betting-tip-thumbnail/prod/340686.webp) <small>www.sportytrader.com</small>Pronóstico Estrela Amadora Sporting CP - Liga Portugal 11/04/26

Viktor Gyokeres Of Sporting CP In Action During The Liga Portugal... News Photo - Getty Images
----------------------------------------------------------------------------------------------

 ![Viktor Gyokeres of Sporting CP in action during the Liga Portugal... News Photo - Getty Images](https://media.gettyimages.com/id/2181645712/photo/sporting-cp-v-cf-estrela-da-amadora-liga-portugal-betclic.jpg?s=1024x1024&w=gi&k=20&c=pQSHkBU1QxQDR9JnFatynVanZJ6QzkPKyr7WUe2HLVw=) <small>www.gettyimages.com</small>Viktor Gyokeres of Sporting CP in action during the Liga Portugal... News Photo - Getty Images

Team Of Estrela Amadora Seen During Liga Portugal Game Between Teams Of Sporting CP And CF
------------------------------------------------------------------------------------------

 ![Team of Estrela Amadora seen during Liga Portugal game between teams of Sporting CP and CF](https://c8.alamy.com/comp/2YFKXRW/team-of-estrela-amadora-seen-during-liga-portugal-game-between-teams-of-sporting-cp-and-cf-estrela-amadora-at-estadio-jose-alvalade-maciej-rogowski-2YFKXRW.jpg) <small>www.alamy.com</small>Team of Estrela Amadora seen during Liga Portugal game between teams of Sporting CP and CF ...

Francisco Trincao De Sporting CP Avec Danilo Veiga De CF Estrela Da Amadora En Action Lors Du
---------------------------------------------------------------------------------------------

 ![Francisco Trincao de Sporting CP avec Danilo Veiga de CF Estrela da Amadora en action lors du](https://c8.alamy.com/compfr/2yf7wpx/francisco-trincao-de-sporting-cp-avec-danilo-veiga-de-cf-estrela-da-amadora-en-action-lors-du-match-entre-sporting-cp-et-cf-estrela-da-amadora-pour-la-liga-portugal-betclic-a-l-estadio-jose-alvalade-score-final-sporting-cp-5-1-cf-estrela-da-amadora-2yf7wpx.jpg) <small>www.alamyimages.fr</small>Francisco Trincao de Sporting CP avec Danilo Veiga de CF Estrela da Amadora en action lors du ...

Team Of Estrela Amadora Seen During Liga Portugal Game Between Teams Of Sporting CP And CF
------------------------------------------------------------------------------------------

 ![Team of Estrela Amadora seen during Liga Portugal game between teams of Sporting CP and CF](https://c8.alamy.com/comp/2YFKXHG/team-of-estrela-amadora-seen-during-liga-portugal-game-between-teams-of-sporting-cp-and-cf-estrela-amadora-at-estadio-jose-alvalade-maciej-rogowski-2YFKXHG.jpg) <small>www.alamy.com</small>Team of Estrela Amadora seen during Liga Portugal game between teams of Sporting CP and CF ...

Portugal. 01st Nov, 2024. Ruben Amorim Head Coach Of Sporting CP During The Liga Portugal
-----------------------------------------------------------------------------------------

 ![Portugal. 01st Nov, 2024. Ruben Amorim head coach of Sporting CP during the Liga Portugal](https://c8.alamy.com/comp/2YEXA6T/portugal-01st-nov-2024-ruben-amorim-head-coach-of-sporting-cp-during-the-liga-portugal-betclic-match-between-sporting-cp-and-cf-estrela-amadora-at-estadio-jose-de-alvalade-on-november-01th-2024-in-lisbon-portugal-liga-portugal-betclic-sporting-cp-vs-cf-estrela-amadora-valter-gouveiaspp-credit-spp-sport-press-photo-alamy-live-news-2YEXA6T.jpg) <small>www.alamy.com</small>Portugal. 01st Nov, 2024. Ruben Amorim head coach of Sporting CP during the Liga Portugal ...

Bilhetes cf estrela da amadora vs sporting cp – liga portugal 25/26 betclic 29ª jornada – núcleo. Daniel braganca of sporting cp celebrates after scoring a goal during... news photo. Team of estrela amadora seen during liga portugal game between teams of sporting cp and cf ...
