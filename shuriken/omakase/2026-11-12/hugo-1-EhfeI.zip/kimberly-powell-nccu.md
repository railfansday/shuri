---
title: "Kimberly Powell Nccu - Kimberly powell"
description: "kimberly powell&#039;s family: meet her husband graham &amp; 2 kids"
date: "2025-12-19"
categories:
- "Uncategorized"
images:
- "https://cache.legacy.net/legacy/images/cobrands/legacyadn/photos/07002946-700d-40b4-9dd9-b0254ea7d6c4.jpgx?w=600&amp;h=500"
featuredImage: "https://celebsfortune.com/wp-content/uploads/2026/11/kimberly-powell-picture.jpg"
featured_image: "https://i0.wp.com/www.theworkingmothersmentor.com/wp-content/uploads/2018/03/Kim-Powell-18_r-1-e1531767896668.jpg?w=2275&amp;ssl=1"
image: "https://img.etimg.com/photo/imgsize-152718,msid-135773875/135773875.jpg"
---

If you are looking for Kimberly Powell's Net Worth (2026) &amp; NVIDIA Salary Revealed you've came to the right web. We have 35 Images about Kimberly Powell's Net Worth (2026) &amp; NVIDIA Salary Revealed like Who is Kimberly Powell, Nvidia exec alleged to have a relationship with CEO Jensen Huang, Who Is Kimberly Powell, Nvidia Executive Who Had Affair With CEO Jensen Huang? and also Nvidia's Kimberly Powell is leading the chip giant's charge into AI for health care - Bizwomen. Here it is:

Kimberly Powell's Net Worth (2026) &amp; NVIDIA Salary Revealed
---------------------------------------------------------------

 ![Kimberly Powell's Net Worth (2026) & NVIDIA Salary Revealed](https://celebsfortune.com/wp-content/uploads/2026/11/kimberly-powell-picture.jpg) <small>celebsfortune.com</small>Kimberly Powell's Net Worth (2026) &amp; NVIDIA Salary Revealed

Kimberly Powell Honored For Pioneering Work In Health Informatics And Gerontology
---------------------------------------------------------------------------------

 ![Kimberly Powell honored for pioneering work in health informatics and gerontology](https://nursing.missouri.edu/wp-content/uploads/2024/05/Congratulations.png) <small>nursing.missouri.edu</small>Kimberly Powell honored for pioneering work in health informatics and gerontology

From The Office To The Lab, Amgen Uses AI Tools To Unlock Innovation | Amgen
----------------------------------------------------------------------------

 ![From the Office to the Lab, Amgen Uses AI Tools to Unlock Innovation | Amgen](https://www.amgen.com/stories/2024/05/-/media/Themes/CorporateAffairs/amgen-com/amgen-com/Images/stories/2024/05-21-From-the-Office-to-the-Lab-Amgen-Uses-AI-Tools-to-Unlock-Innovation/powell.png) <small>www.amgen.com</small>From the Office to the Lab, Amgen Uses AI Tools to Unlock Innovation | Amgen

Who Is Kimberly Powell, Nvidia Executive Who Had Affair With CEO Jensen Huang?
------------------------------------------------------------------------------

 ![Who Is Kimberly Powell, Nvidia Executive Who Had Affair With CEO Jensen Huang?](https://c.ndtvimg.com/2026-11/9ks3vb1s_kimberly-powell_625x300_12_November_26.jpeg?downsize=723:486) <small>www.ndtv.com</small>Who Is Kimberly Powell, Nvidia Executive Who Had Affair With CEO Jensen Huang?

Kim Powell To Be Sentenced For Murder February 3; Niece Wants Investigation Into BRPD’s DNA
-------------------------------------------------------------------------------------------

 ![Kim Powell to be sentenced for murder February 3; niece wants investigation into BRPD’s DNA](https://i0.wp.com/www.soundoffla.com/wp-content/uploads/2023/01/Kim_Powell.jpg?ssl=1) <small>www.soundoffla.com</small>Kim Powell to be sentenced for murder February 3; niece wants investigation into BRPD’s DNA ...

Kimberly Powell: How Married Nvidia Healthcare VP Rose Through...
-----------------------------------------------------------------

 ![Kimberly Powell: How Married Nvidia Healthcare VP Rose Through...](https://data.ibtimes.sg/en/full/99508/kimberly-powell.jpg?w=736) <small>www.ibtimes.sg</small>Kimberly Powell: How Married Nvidia Healthcare VP Rose Through...

Kimberly Powell, The Engineer Who Became Nvidia's Healthcare VP And Is Now Caught In The Jensen
-----------------------------------------------------------------------------------------------

 ![Kimberly Powell, the engineer who became Nvidia's healthcare VP and is now caught in the Jensen](https://www.asiaone.com/sites/default/files/styles/article_top_image/public/original_images/Nov2026/kimberly-powell-nvidia-facebook (1).jpg?itok=hIIek7fk) <small>www.asiaone.com</small>Kimberly Powell, the engineer who became Nvidia's healthcare VP and is now caught in the Jensen ...

Watch: Jensen Huang’s Reported Extramarital Partner Kimberly Powell Walks The Show Floor In
-------------------------------------------------------------------------------------------

 ![Watch: Jensen Huang’s reported extramarital partner Kimberly Powell walks the show floor in](https://img.etimg.com/thumb/msid-135754452,width-950,height-600,imgsize-130156,resizemode-75/jensen-huangs-former-partner-kimberly-powell-walks-the-show-floor-in-nvidia-videobr.jpg) <small>economictimes.indiatimes.com</small>Watch: Jensen Huang’s reported extramarital partner Kimberly Powell walks the show floor in ...

Kimberly Burney Powell Obituary (2024) - Dublin, GA - Townsend Brothers Funeral Home - Dublin
---------------------------------------------------------------------------------------------

 ![Kimberly Burney Powell Obituary (2024) - Dublin, GA - Townsend Brothers Funeral Home - Dublin](https://cache.legacy.net/legacy/images/cobrands/legacyadn/photos/07002946-700d-40b4-9dd9-b0254ea7d6c4.jpgx?w=600&h=500) <small>www.legacy.com</small>Kimberly Burney Powell Obituary (2024) - Dublin, GA - Townsend Brothers Funeral Home - Dublin

Nvidia's Kimberly Powell Is Applying AI To Expedite Drug Discovery - Fast Company
---------------------------------------------------------------------------------

 ![Nvidia's Kimberly Powell is applying AI to expedite drug discovery - Fast Company](https://images.fastcompany.com/image/upload/f_webp,q_auto,c_fit/wp-cms-2/2025/11/p-2-91449906-ai-20-kimberly-powell-nvidia.jpg) <small>www.fastcompany.com</small>Nvidia's Kimberly Powell is applying AI to expedite drug discovery - Fast Company

Kimberly Powell-Jensen Huang Alleged Affair: What Nvidia's Cod...
-----------------------------------------------------------------

 ![Kimberly Powell-Jensen Huang Alleged Affair: What Nvidia's Cod...](https://data.ibtimes.sg/en/full/99518/kimberly-powell.jpg?w=736) <small>www.ibtimes.sg</small>Kimberly Powell-Jensen Huang Alleged Affair: What Nvidia's Cod...

Kimberly Powell Biography: Net Worth, Lifestyle &amp; Success Story | Gen-z Bio - YouTube
-----------------------------------------------------------------------------------------

 ![Kimberly Powell Biography: Net Worth, Lifestyle & Success Story | Gen-z Bio - YouTube](https://i.ytimg.com/vi/KWlhh49Nh18/maxres2.jpg?sqp=-oaymwEoCIAKENAF8quKqQMcGADwAQH4AbYIgAKAD4oCDAgAEAEYciBLKEIwDw==&rs=AOn4CLD4hVZeJqrNtcNMJybmuwutd5NWtg) <small>www.youtube.com</small>Kimberly Powell Biography: Net Worth, Lifestyle &amp; Success Story | Gen-z Bio - YouTube

Kimberly Powell's Family: Meet Her Husband Graham &amp; 2 Kids
--------------------------------------------------------------

 ![Kimberly Powell's Family: Meet Her Husband Graham & 2 Kids](https://celebsindepth.com/wp-content/uploads/2026/11/kimberly-powell-husband-and-children.jpg) <small>celebsindepth.com</small>Kimberly Powell's Family: Meet Her Husband Graham &amp; 2 Kids

Nvidia's Kimberly Powell Is Leading The Chip Giant's Charge Into AI For Health Care - Bizwomen
----------------------------------------------------------------------------------------------

 ![Nvidia's Kimberly Powell is leading the chip giant's charge into AI for health care - Bizwomen](https://media.bizj.us/view/img/12968502/kimberlypowell-1*800xx9428-5303-0-491.jpg) <small>www.bizjournals.com</small>Nvidia's Kimberly Powell is leading the chip giant's charge into AI for health care - Bizwomen

Kimberly Powell's 18-Year Journey At Nvidia Draws Attention After Personal Links With CEO Jensen
------------------------------------------------------------------------------------------------

 ![Kimberly Powell's 18-Year Journey At Nvidia Draws Attention After Personal Links With CEO Jensen](https://images.thedailyjagran.com/images/2026/11/12/template/image/Kimberlypowell-1794456712201.webp) <small>www.thedailyjagran.com</small>Kimberly Powell's 18-Year Journey At Nvidia Draws Attention After Personal Links With CEO Jensen ...

Who Is Kimberly Powell, Nvidia Executive Who Had Affair With CEO Jensen Huang?
------------------------------------------------------------------------------

 ![Who Is Kimberly Powell, Nvidia Executive Who Had Affair With CEO Jensen Huang?](https://c.ndtvimg.com/2026-11/tc1q8iag_kimberly-powell_625x300_12_November_26.jpeg) <small>www.ndtv.com</small>Who Is Kimberly Powell, Nvidia Executive Who Had Affair With CEO Jensen Huang?

Who Is Graham Gerade? What To Know About Kimberly Powell's Husband Amid Jensen Huang Controversy
------------------------------------------------------------------------------------------------

 ![Who is Graham Gerade? What to know about Kimberly Powell's husband amid Jensen Huang controversy](https://img.etimg.com/thumb/msid-135757356,width-950,height-600,imgsize-55824,resizemode-75/image-of-kimberly-powell.jpg) <small>economictimes.indiatimes.com</small>Who is Graham Gerade? What to know about Kimberly Powell's husband amid Jensen Huang controversy ...

Kim Powell Leaves KTVK 3/KPHO 5 Phoenix – PNW Broadcasting History &amp; Current Affairs
----------------------------------------------------------------------------------------

 ![Kim Powell Leaves KTVK 3/KPHO 5 Phoenix – PNW Broadcasting History & Current Affairs](https://qzvx.com/wp-content/uploads/2022/08/Kim-Powell-AZFAMILY3and5.png) <small>www.qzvx.com</small>Kim Powell Leaves KTVK 3/KPHO 5 Phoenix – PNW Broadcasting History &amp; Current Affairs

Who Is Kimberly Powell? Nvidia Executive Who Had Affair With CEO Jensen Huang
-----------------------------------------------------------------------------

 ![Who Is Kimberly Powell? Nvidia Executive Who Had Affair With CEO Jensen Huang](https://c.ndtvimg.com/2026-11/atbds6hc_kimberly-powell_625x300_12_November_26.jpeg?im=FaceCrop,algorithm=dnn,width=1600,height=900) <small>www.ndtv.com</small>Who Is Kimberly Powell? Nvidia Executive Who Had Affair With CEO Jensen Huang

Kimberly Powell Had Affair With Jensen Huang, NYT Reports
---------------------------------------------------------

 ![Kimberly Powell had affair with Jensen Huang, NYT reports](https://www.nacionale.com/_next/image?url=https:%2F%2Fmedia.nacionale.kabineti.net%2Fuploads%2Fkimberly_powell_nvidia_illustration_5a1969db6f.jpg&w=1080&q=85) <small>nacionale.com</small>Kimberly Powell had affair with Jensen Huang, NYT reports

Kimberly Powell Honored For Pioneering Work In Health Informatics And Gerontology
---------------------------------------------------------------------------------

 ![Kimberly Powell honored for pioneering work in health informatics and gerontology](https://nursing.missouri.edu/wp-content/uploads/2024/06/Kimberly-Powell-FAMIA-induction.png) <small>nursing.missouri.edu</small>Kimberly Powell honored for pioneering work in health informatics and gerontology

Who Is Kimberly Powell, The Nvidia Executive Linked To CEO Jensen Huang? | Republic World
-----------------------------------------------------------------------------------------

 ![Who Is Kimberly Powell, the Nvidia Executive Linked to CEO Jensen Huang? | Republic World](https://img.republicworld.com/all_images/2026/11/who-is-kimberly-powell-the-nvidia-executive-linked-to-ceo-jensen-huang-1794455712889-1280x720.webp?w=1280&h=720&q=75&format=webp) <small>www.republicworld.com</small>Who Is Kimberly Powell, the Nvidia Executive Linked to CEO Jensen Huang? | Republic World

Kim Powell Bio, Age, Family, 3TV, Husband, Height, Salary, Net Worth – Celebrity
--------------------------------------------------------------------------------

 ![Kim Powell Bio, Age, Family, 3TV, Husband, Height, Salary, Net Worth – Celebrity](https://cdn.file.com.es/clb/2022/10/16012746/Kim-Powell-2-400x381.jpg) <small>celebrity.com.es</small>Kim Powell Bio, Age, Family, 3TV, Husband, Height, Salary, Net Worth – Celebrity

Kimberly Powell (Nvidia) Wiki, Age, Husband &amp; Salary
--------------------------------------------------------

 ![Kimberly Powell (Nvidia) Wiki, Age, Husband & Salary](https://wikiofcelebrities.com/wp-content/uploads/2026/11/Kimberly-Powell.webp) <small>wikiofcelebrities.com</small>Kimberly Powell (Nvidia) Wiki, Age, Husband &amp; Salary

Nvidia Wants To Bring Robots To The Hospital - Business Insider
---------------------------------------------------------------

 ![Nvidia Wants to Bring Robots to the Hospital - Business Insider](https://i.insider.com/6722a9e501ea6d83dee542bb?width=700) <small>www.businessinsider.com</small>Nvidia Wants to Bring Robots to the Hospital - Business Insider

Who Is Kimberly Powell, The Nvidia Exec Alleged To Have A Relationship With CEO Jensen Huang
--------------------------------------------------------------------------------------------

 ![Who is Kimberly Powell, the Nvidia exec alleged to have a relationship with CEO Jensen Huang](https://dnyuz.com/wp-content/uploads/2026/11/6af503aeb2c29afb4e56a013.webp) <small>dnyuz.com</small>Who is Kimberly Powell, the Nvidia exec alleged to have a relationship with CEO Jensen Huang ...

Who Is Kimberly Powell, Nvidia Exec Alleged To Have A Relationship With CEO Jensen Huang
----------------------------------------------------------------------------------------

 ![Who is Kimberly Powell, Nvidia exec alleged to have a relationship with CEO Jensen Huang](https://images.news9live.com/wp-content/uploads/2026/11/kimberly.png) <small>www.news9live.com</small>Who is Kimberly Powell, Nvidia exec alleged to have a relationship with CEO Jensen Huang ...

Kimberly Powell, Vice-présidente De NVIDIA, A Annoncé Sa 2026 | Polymarket
--------------------------------------------------------------------------

 ![Kimberly Powell, vice-présidente de NVIDIA, a annoncé sa 2026 | Polymarket](https://polymarket.com/api/og?eslug=nvidia-vp-kimberly-powell-announced-resignation-or-removal-byptptpt&locale=fr&tid=1794492203296) <small>polymarket.com</small>Kimberly Powell, vice-présidente de NVIDIA, a annoncé sa ... 2026 | Polymarket

Before Nvidia, Kimberly Powell Was An Engineering…
--------------------------------------------------

 ![Before Nvidia, Kimberly Powell was an engineering…](https://img.etimg.com/photo/imgsize-152718,msid-135773875/135773875.jpg) <small>www.inkl.com</small>Before Nvidia, Kimberly Powell was an engineering…

Kimberly Powell Biography: Age, Nvidia Healthcare Career And The Jensen Huang Report – The
------------------------------------------------------------------------------------------

 ![Kimberly Powell Biography: Age, Nvidia Healthcare Career and the Jensen Huang Report – The](https://jaisalmernews.com/wp-content/uploads/2026/11/kimberly-powell-biography-cover.webp) <small>jaisalmernews.com</small>Kimberly Powell Biography: Age, Nvidia Healthcare Career and the Jensen Huang Report – The ...

Kimberly Powell Nvidia: Summit Exit After Huang Report
------------------------------------------------------

 ![Kimberly Powell Nvidia: Summit Exit After Huang Report](https://bitcoinfoundation.org/wp-content/uploads/2026/11/kimberly-powell-cancels-health-summit-appearance-after-nvidia-ceo-relationship-r.webp) <small>bitcoinfoundation.org</small>Kimberly Powell Nvidia: Summit Exit After Huang Report

What Does It Take To Become A CEO? Kim Powell, Author Of The CEO Next Door Teaches Us Surprising
------------------------------------------------------------------------------------------------

 ![What does it take to become a CEO? Kim Powell, author of the CEO Next Door teaches us surprising](https://i0.wp.com/www.theworkingmothersmentor.com/wp-content/uploads/2018/03/Kim-Powell-18_r-1-e1531767896668.jpg?w=2275&ssl=1) <small>www.theworkingmothersmentor.com</small>What does it take to become a CEO? Kim Powell, author of the CEO Next Door teaches us surprising ...

Nvidia Expands AI Ambitions In Healthcare; Aims To Transform Hospitals With Robotics – Digital
----------------------------------------------------------------------------------------------

 ![Nvidia expands AI ambitions in healthcare; aims to transform hospitals with robotics – Digital](https://digitaleconomymag.com/wp-content/uploads/2024/11/Nvidia-Kimberly-Powel.png) <small>digitaleconomymag.com</small>Nvidia expands AI ambitions in healthcare; aims to transform hospitals with robotics – Digital ...

Kimberly Hill-Davis Joins NCCU As Visiting Scholar To Advance Community Engagement | North
------------------------------------------------------------------------------------------

 ![Kimberly Hill-Davis Joins NCCU as Visiting Scholar to Advance Community Engagement | North](https://www.nccu.edu/sites/default/files/styles/16_9_1600x900/public/2025-05/Kimberly Hill Davis.jpg?h=a92f03cd&itok=_URIZieF) <small>www.nccu.edu</small>Kimberly Hill-Davis Joins NCCU as Visiting Scholar to Advance Community Engagement | North ...

Kimberly Powell - Student Services Specialist For The Mechanical, Aeronautical &amp; Astronautical
--------------------------------------------------------------------------------------------------

 ![Kimberly Powell - Student Services Specialist for the Mechanical, Aeronautical & Astronautical](https://media.licdn.com/dms/image/v2/D5603AQHG7P7fwrwt1g/profile-displayphoto-shrink_200_200/profile-displayphoto-shrink_200_200/0/1729514339987?e=2147483647&v=beta&t=618YQWbHvXVuH9AxmfnxTKy8myI4emyzsY9P7_amtBs) <small>www.linkedin.com</small>Kimberly Powell - Student Services Specialist for the Mechanical, Aeronautical &amp; Astronautical ...

Kimberly powell nvidia: summit exit after huang report. Who is kimberly powell, nvidia executive who had affair with ceo jensen huang?. kimberly powell's family: meet her husband graham &amp; 2 kids
