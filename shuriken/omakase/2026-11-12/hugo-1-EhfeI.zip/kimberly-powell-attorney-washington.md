---
title: "Kimberly Powell Attorney Washington - kimberly powell"
description: "Seattle city attorney asks for more staff to respond to trump&#039;s executive orders"
date: "2026-09-10"
categories:
- "Uncategorized"
images:
- "https://www.news-journalonline.com/gcdn/presto/2021/10/28/NDNJ/fb9c6e73-5ed6-469b-b4b2-04ee75e54e98-harrpic1.jpg?width=660&amp;height=361&amp;fit=crop&amp;format=pjpg&amp;auto=webp"
featuredImage: "https://media.licdn.com/dms/image/D5622AQHpO63Gdvh9pA/feedshare-shrink_2048_1536/0/1686869396106?e=2147483647&amp;v=beta&amp;t=br0qoF38jSsM6UDaZFY07EPc3IwdUveCofo65zD08K8"
featured_image: "https://lookaside.fbsbx.com/lookaside/crawler/media/?media_id=122095709648899761"
image: "https://www.brownfamilylaw.com/wp-content/webp-express/webp-images/uploads/KinserStudios-Headshots-BrownLaw-97-e1750270461402.jpg.webp"
---

If you are looking for Who We Are you've came to the right web. We have 35 Pics about Who We Are like Lawyer and Law Team Profiles | Desmond Law Group, P.S., Senior Managing Attorney, Kimberly P. Washington | Bryan Fagan and also Kimberly Powell - SR Partner Technical Advisor | LinkedIn. Read more:

Who We Are
----------

 ![Who We Are](https://tbi-dv-il.org/wp-content/uploads/2025/12/Kimberly_Washington-edited.jpg) <small>tbi-dv-il.org</small>Who We Are

Kimberly Powell - SR Partner Technical Advisor | LinkedIn
---------------------------------------------------------

 ![Kimberly Powell - SR Partner Technical Advisor | LinkedIn](https://media.licdn.com/dms/image/v2/D5603AQGY1P7BMa4UrA/profile-displayphoto-shrink_200_200/profile-displayphoto-shrink_200_200/0/1709256150173?e=2147483647&v=beta&t=Sr6TwAk9jjQSdKtZX537kaHgDevPQ700DsIYeMP3l0Q) <small>www.linkedin.com</small>Kimberly Powell - SR Partner Technical Advisor | LinkedIn

Kimberly Williams Profile - Tacoma, WA Family Lawyer
----------------------------------------------------

 ![Kimberly Williams Profile - Tacoma, WA Family Lawyer](https://images.avvo.com/avvo/ugc/images/head_shot/standard/lawyer_kimberly_williams_4087590_1715705009.jpg) <small>www.avvo.com</small>Kimberly Williams Profile - Tacoma, WA Family Lawyer

Seattle City Attorney Asks For More Staff To Respond To Trump's Executive Orders | King5.com
--------------------------------------------------------------------------------------------

 ![Seattle City Attorney asks for more staff to respond to Trump's executive orders | king5.com](https://media.king5.com/assets/KING/images/b81b9977-69cf-4ff7-84b8-dc6b69278409/20250312T021358/b81b9977-69cf-4ff7-84b8-dc6b69278409_1140x641.jpg) <small>www.king5.com</small>Seattle City Attorney asks for more staff to respond to Trump's executive orders | king5.com

About Us | Davis Business Law
-----------------------------

 ![About Us | Davis Business Law](https://davisbusinesslaw.com/wp-content/uploads/2024/07/Kim-Atwell03127-Edited-980x980.jpg) <small>davisbusinesslaw.com</small>About Us | Davis Business Law

Business &amp; Corporate | Wards Lawyers
----------------------------------------

 ![Business & Corporate | Wards Lawyers](https://static.wixstatic.com/media/a2ebc9_2f49761ee3b84a21b90e1aec0ee6aae9~mv2.jpg/v1/crop/x_0,y_374,w_3853,h_5044/fill/w_980,h_1283,al_c,q_85,usm_0.66_1.00_0.01,enc_avif,quality_auto/Kimberly.jpg) <small>www.wardlegal.ca</small>Business &amp; Corporate | Wards Lawyers

Kimberly Powell On LinkedIn: And Just Like That...25 Years Have Passed!!! In Seattle To See My
----------------------------------------------------------------------------------------------

 ![Kimberly Powell on LinkedIn: And just like that...25 years have passed!!! In Seattle to see my](https://media.licdn.com/dms/image/D5622AQFM01euwGXjow/feedshare-shrink_800/0/1684412420217?e=2147483647&v=beta&t=xcLy4MbpqBRuJ1bhMEqK-ZnS7coH8bt-lxAAEb3hIrk) <small>www.linkedin.com</small>Kimberly Powell on LinkedIn: And just like that...25 years have passed!!! In Seattle to see my ...

Kimberly Powell Inducted As Fellow Of The American Medical Informatics Association, Announced As
------------------------------------------------------------------------------------------------

 ![Kimberly Powell inducted as Fellow of the American Medical Informatics Association, announced as](https://showme.missouri.edu/wp-content/uploads/2024/06/071124_PowellFeature-940x529.jpg) <small>showme.missouri.edu</small>Kimberly Powell inducted as Fellow of the American Medical Informatics Association, announced as ...

Kimberly Powell
---------------

 ![Kimberly Powell](https://lookaside.fbsbx.com/lookaside/crawler/media/?media_id=122095709648899761) <small>www.facebook.com</small>Kimberly Powell

NVIDIA Powers Up In Drug Discovery
----------------------------------

 ![NVIDIA Powers Up in Drug Discovery](https://genengnews.com/wp-content/uploads/2020/10/Kimberly-Powell_avatar_1511719112-200x200-1.jpg) <small>www.genengnews.com</small>NVIDIA Powers Up in Drug Discovery

CMS To SNFs: Stop Overusing Dashes In The MDS - I Advance Senior Care
---------------------------------------------------------------------

 ![CMS to SNFs: Stop overusing dashes in the MDS - I Advance Senior Care](https://www.iadvanceseniorcare.com/wp-content/uploads/2025/02/Kimberly-Powell.png) <small>www.iadvanceseniorcare.com</small>CMS to SNFs: Stop overusing dashes in the MDS - I Advance Senior Care

US Washington Attorney To Prosecute MMIP Cases In Northwest | Krem.com
----------------------------------------------------------------------

 ![US Washington Attorney to prosecute MMIP cases in northwest | krem.com](https://media.krem.com/assets/KREM/images/d06dd667-8e50-4d84-a4fa-da2090ad676a/d06dd667-8e50-4d84-a4fa-da2090ad676a_1140x641.jpg) <small>www.krem.com</small>US Washington Attorney to prosecute MMIP cases in northwest | krem.com

Jane Joseph - Lawyer In Houston, TX - Avvo
------------------------------------------

 ![Jane Joseph - Lawyer in Houston, TX - Avvo](https://images.avvo.com/avvo/ugc/images/head_shot/standard/lawyer_kimberly_washington_1804681_1530034254.jpg) <small>www.avvo.com</small>Jane Joseph - Lawyer in Houston, TX - Avvo

Kimberly Powell - At | LinkedIn
-------------------------------

 ![Kimberly Powell - at | LinkedIn](https://media.licdn.com/dms/image/v2/C4E03AQEGJk--BTydNw/profile-displayphoto-shrink_200_200/profile-displayphoto-shrink_200_200/0/1516849136673?e=2147483647&v=beta&t=eSvvy8LcE7y1pXitI4462Hh6HI-1SU2m37-7VI6r4Ek) <small>www.linkedin.com</small>Kimberly Powell - at | LinkedIn

Kimberly Powell - PhD, RN, FAMIA, FAAN | LinkedIn
-------------------------------------------------

 ![Kimberly Powell - PhD, RN, FAMIA, FAAN | LinkedIn](https://media.licdn.com/dms/image/v2/D4E03AQELNZTNqlomtw/profile-displayphoto-scale_200_200/B4EZiemXJLHoAY-/0/1755007513927?e=2147483647&v=beta&t=9aVHNfS1ADg7fyk_hbUBaCziZDNeQpkjMX0xwrnhkTQ) <small>www.linkedin.com</small>Kimberly Powell - PhD, RN, FAMIA, FAAN | LinkedIn

About Kimberly J MacLeod, PC - Bankruptcy Lawyer Lynnwood &amp; Edmonds WA
--------------------------------------------------------------------------

 ![About Kimberly J MacLeod, PC - Bankruptcy Lawyer Lynnwood & Edmonds WA](https://lirp.cdn-website.com/c9844353/dms3rep/multi/opt/Head-shot-1920w.jpg) <small>www.kjmdebtlaw.com</small>About Kimberly J MacLeod, PC - Bankruptcy Lawyer Lynnwood &amp; Edmonds WA

Our Attorneys | Civil Litigation &amp; Criminal Law In Pinehurst
----------------------------------------------------------------

 ![Our Attorneys | Civil Litigation & Criminal Law in Pinehurst](https://www.vancamplaw.com/wp-content/uploads/2022/03/kimberly_post_4.jpg) <small>www.vancamplaw.com</small>Our Attorneys | Civil Litigation &amp; Criminal Law in Pinehurst

Press Release: Kimberly Brown Joins McKinley Irvin As Of Counsel
----------------------------------------------------------------

 ![Press Release: Kimberly Brown Joins McKinley Irvin as Of Counsel](https://www.mckinleyirvin.com/images/blog/New-Attorney-Kimberly-Brown-Post-Image.2505221239474.png) <small>www.mckinleyirvin.com</small>Press Release: Kimberly Brown Joins McKinley Irvin as Of Counsel

About Us | Brown Family Law | Firm Overview
-------------------------------------------

 ![About Us | Brown Family Law | Firm Overview](https://www.brownfamilylaw.com/wp-content/webp-express/webp-images/uploads/KinserStudios-Headshots-BrownLaw-97-e1750270461402.jpg.webp) <small>www.brownfamilylaw.com</small>About Us | Brown Family Law | Firm Overview

Kimberly
--------

 ![Kimberly](https://deweylegal.com/kim.jpg) <small>deweylegal.com</small>Kimberly

Polk County Attorney Kimberly Graham To Seek Reelection In 2026 | Weareiowa.com
-------------------------------------------------------------------------------

 ![Polk County attorney Kimberly Graham to seek reelection in 2026 | weareiowa.com](https://media.tegna-media.com/assets/WOI/images/bd179585-df07-48be-8377-f3b2dcd5ca9b/bd179585-df07-48be-8377-f3b2dcd5ca9b_1920x1080.jpg) <small>www.weareiowa.com</small>Polk County attorney Kimberly Graham to seek reelection in 2026 | weareiowa.com

Board Of Directors — Basic Needs Inc.
-------------------------------------

 ![Board of Directors — Basic Needs Inc.](https://images.squarespace-cdn.com/content/v1/63d48a2e85aa7959f69d2f27/58712eb8-621f-4cbe-b73b-a7e4fbbc934a/Powell_Kim+2005.jpg) <small>www.basicneedsmn.org</small>Board of Directors — Basic Needs Inc.

Frankford CDC | About
---------------------

 ![Frankford CDC | About](https://frankfordcdc.org/wp-content/uploads/2020/09/kimberly-1024x683-1.jpg) <small>frankfordcdc.org</small>Frankford CDC | About

Team | Wards Lawyers
--------------------

 ![Team | Wards Lawyers](https://static.wixstatic.com/media/a2ebc9_9777b0b0ea5d40cd96d5492c6bfab19f~mv2.jpg/v1/crop/x_155,y_1006,w_3560,h_4421/fill/w_980,h_1217,al_c,q_85,usm_0.66_1.00_0.01,enc_avif,quality_auto/Kimberly.jpg) <small>www.wardlegal.ca</small>Team | Wards Lawyers

Kimberly Powell On LinkedIn: I Am Honored To Have Been Nominated And Awarded The BAM WW - Gerald
------------------------------------------------------------------------------------------------

 ![Kimberly Powell on LinkedIn: I am honored to have been nominated and awarded the BAM WW - Gerald](https://media.licdn.com/dms/image/D5622AQHpO63Gdvh9pA/feedshare-shrink_2048_1536/0/1686869396106?e=2147483647&v=beta&t=br0qoF38jSsM6UDaZFY07EPc3IwdUveCofo65zD08K8) <small>www.linkedin.com</small>Kimberly Powell on LinkedIn: I am honored to have been nominated and awarded the BAM WW - Gerald ...

Kimberly Powell's Instagram, Twitter &amp; Facebook On IDCrawl
--------------------------------------------------------------

 ![Kimberly Powell's Instagram, Twitter & Facebook on IDCrawl](https://www.hopkinsmedicine.org/-/media/images/articles/2018/03/kimberly_powell.jpeg?h=640&iar=0&w=640&hash=1741F5E78A512573722D6BEAB32D9288) <small>www.idcrawl.com</small>Kimberly Powell's Instagram, Twitter &amp; Facebook on IDCrawl

Lawyer And Law Team Profiles | Desmond Law Group, P.S.
------------------------------------------------------

 ![Lawyer and Law Team Profiles | Desmond Law Group, P.S.](https://www.desmondlaw.org/static/sitefiles/staff/kimberly.jpg) <small>www.desmondlaw.org</small>Lawyer and Law Team Profiles | Desmond Law Group, P.S.

Kimberly A. Parker - Criminal Defense: White-Collar Lawyer - Washington, DC
---------------------------------------------------------------------------

 ![Kimberly A. Parker - Criminal Defense: White-Collar Lawyer - Washington, DC](https://www.bestlawyers.com/lawyer-share/kimberly-a-parker-153100.png) <small>www.bestlawyers.com</small>Kimberly A. Parker - Criminal Defense: White-Collar Lawyer - Washington, DC

Criminal Defense Attorney Lynnwood WA | McAvoy Law PLLC | Former Prosecutor
---------------------------------------------------------------------------

 ![Criminal Defense Attorney Lynnwood WA | McAvoy Law PLLC | Former Prosecutor](https://www.mcavoylaw.net/lovable-uploads/0e3a36cd-aa32-44d5-a29c-eb7203a834e4.png) <small>www.mcavoylaw.net</small>Criminal Defense Attorney Lynnwood WA | McAvoy Law PLLC | Former Prosecutor

Meet The LOBF Legal Team Attorney Kimberly Washington - YouTube
---------------------------------------------------------------

 ![Meet The LOBF Legal Team Attorney Kimberly Washington - YouTube](https://i.ytimg.com/vi/XxUpPVeu7o4/maxresdefault.jpg) <small>www.youtube.com</small>Meet The LOBF Legal Team Attorney Kimberly Washington - YouTube

Volusia Schools Sued By Mother Over Treatment Of Autistic Son
-------------------------------------------------------------

 ![Volusia schools sued by mother over treatment of autistic son](https://www.news-journalonline.com/gcdn/presto/2021/10/28/NDNJ/fb9c6e73-5ed6-469b-b4b2-04ee75e54e98-harrpic1.jpg?width=660&height=361&fit=crop&format=pjpg&auto=webp) <small>www.news-journalonline.com</small>Volusia schools sued by mother over treatment of autistic son

Our Team - Class 101 Suwanee-Duluth
-----------------------------------

 ![Our Team - Class 101 Suwanee-Duluth](https://www.class101.com/suwaneeduluth/wp-content/uploads/sites/82/2024/05/IMG_4490-e1715204918449.jpg) <small>www.class101.com</small>Our Team - Class 101 Suwanee-Duluth

Kimberly Powell
---------------

 ![Kimberly Powell](https://robbreport.com/wp-content/uploads/2025/03/56530266-E7BC-4572-A806-5A5BBF318742.jpeg) <small>robbreport.com</small>Kimberly Powell

Senior Managing Attorney, Kimberly P. Washington | Bryan Fagan
--------------------------------------------------------------

 ![Senior Managing Attorney, Kimberly P. Washington | Bryan Fagan](http://texascpslawyer.net/wp-content/uploads/2018/06/Kim-profile-2020.jpg) <small>texascpslawyer.net</small>Senior Managing Attorney, Kimberly P. Washington | Bryan Fagan

Seattle Divorce Attorneys And Family Law Attorney Profiles - 206-728-8000
-------------------------------------------------------------------------

 ![Seattle Divorce Attorneys and Family Law Attorney Profiles - 206-728-8000](https://www.tlclawco.com/wp-content/uploads/2019/06/Kimberly_A_Kasin.jpg) <small>www.tlclawco.com</small>Seattle Divorce Attorneys and Family Law Attorney Profiles - 206-728-8000

Kimberly powell. Meet the lobf legal team attorney kimberly washington. Business &amp; corporate
