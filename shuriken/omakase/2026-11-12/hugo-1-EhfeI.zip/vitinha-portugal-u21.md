---
title: "Vitinha Portugal U21 - portugal&#039;s vitinha during the uefa euro 2024 group f match at leipzig stadium in leipzig ..."
description: "Leipzig, germany"
date: "2026-08-05"
categories:
- "Uncategorized"
images:
- "https://func-wolves-playmaker-imageresizer-prod-uksouth.azurewebsites.net/api/media/17005/vitinha-portugal.jpg"
featuredImage: "https://func-wolves-playmaker-imageresizer-prod-uksouth.azurewebsites.net/api/media/17005/vitinha-portugal.jpg"
featured_image: "https://c8.alamy.com/compde/2xdf865/portugals-vitinha-im-spiel-der-gruppe-f-zur-uefa-euro-2024-im-bvb-stadion-dortmund-in-dortmund-bilddatum-samstag-22-juni-2024-2xdf865.jpg"
image: "https://c8.alamy.com/comp/2G08BE7/ljubljana-slovenia-31st-may-2021-vitinha-of-portugal-during-the-uefa-u21-championships-2021-match-at-stadion-stoczicw-ljubljana-picture-credit-should-read-jonathan-moscrop-sportimage-2G08BE7.jpg"
---

If you are searching about Vitinha machado hi-res stock photography and images - Alamy you've visit to the right place. We have 35 Pictures about Vitinha machado hi-res stock photography and images - Alamy like Ljubljana, Slovenia, 31st May 2021. Vitinha of Portugal during the UEFA U21 Championships 2021, Dortmund, Germany. 22nd June 2024. Dortmund - Vitinha of Portugal during the UEFA EURO 2024 and also Vitinha machado hi-res stock photography and images - Alamy. Here it is:

Vitinha Machado Hi-res Stock Photography And Images - Alamy
-----------------------------------------------------------

 ![Vitinha machado hi-res stock photography and images - Alamy](https://c8.alamy.com/comp/2F5XP8D/portugals-vitinha-machado-ferreira-reacts-during-the-2021-uefa-european-under-21-championship-group-d-match-at-the-stozice-stadium-in-ljubljana-slovenia-picture-date-sunday-march-28-2021-2F5XP8D.jpg) <small>www.alamy.com</small>Vitinha machado hi-res stock photography and images - Alamy

LEIPZIG, GERMANY - JUNE 18: Vitinha Of Portugal Runs With The Ball During The Group F - UEFA
--------------------------------------------------------------------------------------------

 ![LEIPZIG, GERMANY - JUNE 18: Vitinha of Portugal runs with the ball during the Group F - UEFA](https://c8.alamy.com/comp/2XCTAFP/leipzig-germany-june-18-vitinha-of-portugal-runs-with-the-ball-during-the-group-f-uefa-euro-2024-match-between-portugal-and-czechia-at-red-bull-arena-on-june-18-2024-in-leipzig-germany-photo-by-peter-lousbsr-agency-2XCTAFP.jpg) <small>www.alamy.com</small>LEIPZIG, GERMANY - JUNE 18: Vitinha of Portugal runs with the ball during the Group F - UEFA ...

Quarter Final Uefa Euro 2024 Hi-res Stock Photography And Images - Alamy
------------------------------------------------------------------------

 ![Quarter final uefa euro 2024 hi-res stock photography and images - Alamy](https://c8.alamy.com/comp/2XG23MC/vitinha-of-portugal-during-the-uefa-euro-2024-quarter-final-football-match-between-portugal-and-france-on-july-5-2024-at-volksparkstadion-in-hamburg-germany-credit-independent-photo-agencyalamy-live-news-2XG23MC.jpg) <small>www.alamy.com</small>Quarter final uefa euro 2024 hi-res stock photography and images - Alamy

Vitinha Sets Up Crucial Goal As Portugal U21 Make Euros Final
-------------------------------------------------------------

 ![Vitinha sets up crucial goal as Portugal U21 make Euros final](https://cdn1.molineux.news/uploads/2/2021/06/GettyImages-1233251314.jpg) <small>www.molineux.news</small>Vitinha sets up crucial goal as Portugal U21 make Euros final

Lui, C’est Vitinha : Vous Connaissez ? - Euro 2024 - Quarts - Portugal-France - 05 Juil. 2024
---------------------------------------------------------------------------------------------

 ![Lui, c’est Vitinha : vous connaissez ? - Euro 2024 - Quarts - Portugal-France - 05 Juil. 2024](https://www.sofoot.com/convert/LzIwMjQvMDcvMDQxODM1MjcvODMxNzkyOS0xNDAweDkzMy5qcGc/image/euro-2024-vitinha-portugal-se-represente-a-la-france.jpg) <small>www.sofoot.com</small>Lui, c’est Vitinha : vous connaissez ? - Euro 2024 - Quarts - Portugal-France - 05 Juil. 2024 ...

Portugal's Vitinha During The UEFA Euro 2024 Group F Match At Leipzig Stadium In Leipzig
----------------------------------------------------------------------------------------

 ![Portugal's Vitinha during the UEFA Euro 2024 Group F match at Leipzig Stadium in Leipzig](https://c8.alamy.com/comp/2XCTH3W/portugals-vitinha-during-the-uefa-euro-2024-group-f-match-at-leipzig-stadium-in-leipzig-germany-picture-date-tuesday-june-18-2024-2XCTH3W.jpg) <small>www.alamy.com</small>Portugal's Vitinha during the UEFA Euro 2024 Group F match at Leipzig Stadium in Leipzig ...

Portugals Vitinha Im Spiel Der Gruppe F Zur UEFA Euro 2024 Im BVB Stadion Dortmund In Dortmund
----------------------------------------------------------------------------------------------

 ![Portugals Vitinha im Spiel der Gruppe F zur UEFA Euro 2024 im BVB Stadion Dortmund in Dortmund](https://c8.alamy.com/compde/2xdf865/portugals-vitinha-im-spiel-der-gruppe-f-zur-uefa-euro-2024-im-bvb-stadion-dortmund-in-dortmund-bilddatum-samstag-22-juni-2024-2xdf865.jpg) <small>www.alamy.de</small>Portugals Vitinha im Spiel der Gruppe F zur UEFA Euro 2024 im BVB Stadion Dortmund in Dortmund ...

Vitinha Von Portugal Während Der UEFA Euro 2024, Gruppe F, Fußballspiel Zwischen Portugal Und
---------------------------------------------------------------------------------------------

 ![Vitinha von Portugal während der UEFA Euro 2024, Gruppe F, Fußballspiel zwischen Portugal und](https://c8.alamy.com/compde/2xcwy4w/vitinha-von-portugal-wahrend-der-uefa-euro-2024-gruppe-f-fussballspiel-zwischen-portugal-und-tschechien-am-18-juni-2024-im-leipziger-stadion-2xcwy4w.jpg) <small>www.alamy.de</small>Vitinha von Portugal während der UEFA Euro 2024, Gruppe F, Fußballspiel zwischen Portugal und ...

Vitinha Shines During Fabio Silva's Portugal U21 Debut
------------------------------------------------------

 ![Vitinha shines during Fabio Silva's Portugal U21 debut](https://cdn1.molineux.news/uploads/2/2021/09/GettyImages-1235091011.jpg) <small>www.molineux.news</small>Vitinha shines during Fabio Silva's Portugal U21 debut

Vitinha Portugal Celebrating After Uefa Euro Editorial Stock Photo - Stock Image | Shutterstock
-----------------------------------------------------------------------------------------------

 ![Vitinha Portugal Celebrating After Uefa Euro Editorial Stock Photo - Stock Image | Shutterstock](https://www.shutterstock.com/editorial/image-editorial/MdT6Q23fM8D0c4ybNDUwODI=/vitinha-portugal-celebrating-after-uefa-euro-2024-1500w-14567562fh.jpg) <small>www.shutterstock.com</small>Vitinha Portugal Celebrating After Uefa Euro Editorial Stock Photo - Stock Image | Shutterstock ...

Dortmund, Germany. 22nd June 2024. Dortmund - Vitinha Of Portugal During The UEFA EURO 2024
-------------------------------------------------------------------------------------------

 ![Dortmund, Germany. 22nd June 2024. Dortmund - Vitinha of Portugal during the UEFA EURO 2024](https://c8.alamy.com/comp/2XDF7Y7/dortmund-germany-22nd-june-2024-dortmund-vitinha-of-portugal-during-the-uefa-euro-2024-group-f-match-between-turkey-and-portugal-at-bvb-stadium-dortmund-on-june-22-2024-in-dortmund-germany-anp-hollandse-hoogte-gerrit-van-keulen-2XDF7Y7.jpg) <small>www.alamy.com</small>Dortmund, Germany. 22nd June 2024. Dortmund - Vitinha of Portugal during the UEFA EURO 2024 ...

FRANKFURT - Vitinha Of Portugal During The UEFA EURO 2024 Round Of 16 Match Between Portugal And
------------------------------------------------------------------------------------------------

 ![FRANKFURT - Vitinha of Portugal during the UEFA EURO 2024 round of 16 match between Portugal and](https://c8.alamy.com/comp/2XGE2YA/frankfurt-vitinha-of-portugal-during-the-uefa-euro-2024-round-of-16-match-between-portugal-and-slovenia-at-frankfurt-arena-on-july-1-2024-in-frankfurt-germany-anp-hollandse-hoogte-gerrit-van-keulen-2XGE2YA.jpg) <small>www.alamy.com</small>FRANKFURT - Vitinha of Portugal during the UEFA EURO 2024 round of 16 match between Portugal and ...

Vitinha High Resolution Stock Photography And Images - Alamy
------------------------------------------------------------

 ![Vitinha High Resolution Stock Photography and Images - Alamy](https://c8.alamy.com/comp/2G08BE7/ljubljana-slovenia-31st-may-2021-vitinha-of-portugal-during-the-uefa-u21-championships-2021-match-at-stadion-stoczicw-ljubljana-picture-credit-should-read-jonathan-moscrop-sportimage-2G08BE7.jpg) <small>www.alamy.com</small>Vitinha High Resolution Stock Photography and Images - Alamy

Munich, Germany. 8th June, 2025. Vitinha Seen Celebrating With A Trophy During UEFA Nations
-------------------------------------------------------------------------------------------

 ![Munich, Germany. 8th June, 2025. Vitinha seen celebrating with a trophy during UEFA Nations](https://c8.alamy.com/comp/3BHA4KD/munich-germany-8th-june-2025-vitinha-seen-celebrating-with-a-trophy-during-uefa-nations-league-2025-final-game-between-national-teams-of-portugal-and-spain-maciej-rogowski-credit-maciej-rogowskialamy-live-news-3BHA4KD.jpg) <small>www.alamy.com</small>Munich, Germany. 8th June, 2025. Vitinha seen celebrating with a trophy during UEFA Nations ...

Dortmund - Vitinha Of Portugal During The UEFA EURO 2024 Group F Match Between Turkey And
-----------------------------------------------------------------------------------------

 ![Dortmund - Vitinha of Portugal during the UEFA EURO 2024 group F match between Turkey and](https://c8.alamy.com/comp/2XEW6MB/dortmund-vitinha-of-portugal-during-the-uefa-euro-2024-group-f-match-between-turkey-and-portugal-at-bvb-stadium-dortmund-on-june-22-2024-in-dortmund-germany-anp-hollandse-hoogte-gerrit-van-keulen-2XEW6MB.jpg) <small>www.alamy.com</small>Dortmund - Vitinha of Portugal during the UEFA EURO 2024 group F match between Turkey and ...

Portugal's Vitinha Celebrates Victory After The UEFA Euro 2024, Round Of 16 Match At The
----------------------------------------------------------------------------------------

 ![Portugal's Vitinha celebrates victory after the UEFA Euro 2024, round of 16 match at the](https://c8.alamy.com/comp/2XF7B8F/portugals-vitinha-celebrates-victory-after-the-uefa-euro-2024-round-of-16-match-at-the-frankfurt-arena-in-frankfurt-germany-picture-date-monday-july-1-2024-2XF7B8F.jpg) <small>www.alamy.com</small>Portugal's Vitinha celebrates victory after the UEFA Euro 2024, round of 16 match at the ...

Stadion 2021 Hi-res Stock Photography And Images - Alamy
--------------------------------------------------------

 ![Stadion 2021 hi-res stock photography and images - Alamy](https://c8.alamy.com/comp/2G08BE8/ljubljana-slovenia-31st-may-2021-vitinha-of-portugal-during-the-uefa-u21-championships-2021-match-at-stadion-stoczicw-ljubljana-picture-credit-should-read-jonathan-moscrop-sportimage-2G08BE8.jpg) <small>www.alamy.com</small>Stadion 2021 hi-res stock photography and images - Alamy

FRANKFURT - Vitinha Of Portugal During The UEFA EURO 2024 Round Of 16 Match Between Portugal And
------------------------------------------------------------------------------------------------

 ![FRANKFURT - Vitinha of Portugal during the UEFA EURO 2024 round of 16 match between Portugal and](https://c8.alamy.com/comp/2XGE30G/frankfurt-vitinha-of-portugal-during-the-uefa-euro-2024-round-of-16-match-between-portugal-and-slovenia-at-frankfurt-arena-on-july-1-2024-in-frankfurt-germany-anp-hollandse-hoogte-gerrit-van-keulen-2XGE30G.jpg) <small>www.alamy.com</small>FRANKFURT - Vitinha of Portugal during the UEFA EURO 2024 round of 16 match between Portugal and ...

Portugal's Vitinha During The UEFA Euro 2024, Round Of 16 Match At The Frankfurt Arena In
-----------------------------------------------------------------------------------------

 ![Portugal's Vitinha during the UEFA Euro 2024, round of 16 match at the Frankfurt Arena in](https://c8.alamy.com/comp/2XFAK18/portugals-vitinha-during-the-uefa-euro-2024-round-of-16-match-at-the-frankfurt-arena-in-frankfurt-germany-picture-date-monday-july-1-2024-2XFAK18.jpg) <small>www.alamy.com</small>Portugal's Vitinha during the UEFA Euro 2024, round of 16 match at the Frankfurt Arena in ...

Ljubljana, Slovenia, 31st May 2021. Vitinha Of Portugal During The UEFA U21 Championships 2021
----------------------------------------------------------------------------------------------

 ![Ljubljana, Slovenia, 31st May 2021. Vitinha of Portugal during the UEFA U21 Championships 2021](https://c8.alamy.com/comp/2GHJ6G9/ljubljana-slovenia-31st-may-2021-vitinha-of-portugal-during-the-uefa-u21-championships-2021-match-at-stadion-stoczicw-ljubljana-picture-credit-should-read-jonathan-moscrop-sportimage-via-pa-images-2GHJ6G9.jpg) <small>www.alamy.com</small>Ljubljana, Slovenia, 31st May 2021. Vitinha of Portugal during the UEFA U21 Championships 2021 ...

Vitinha Portugal Celebrating After Uefa Euro Editorial Stock Photo - Stock Image | Shutterstock
-----------------------------------------------------------------------------------------------

 ![Vitinha Portugal Celebrating After Uefa Euro Editorial Stock Photo - Stock Image | Shutterstock](https://www.shutterstock.com/editorial/image-editorial/M9T4Q736MfDac0yaNDUxMDY=/vitinha-portugal-celebrating-after-uefa-euro-2024-550nw-14567562fo.jpg) <small>www.shutterstock.com</small>Vitinha Portugal Celebrating After Uefa Euro Editorial Stock Photo - Stock Image | Shutterstock ...

Vitinha | Portugal | UEFA EURO 2024 | UEFA.com
----------------------------------------------

 ![Vitinha | Portugal | UEFA EURO 2024 | UEFA.com](https://img.uefa.com/imgml/TP/players/3/2024/cutoff/250101444.png) <small>www.uefa.com</small>Vitinha | Portugal | UEFA EURO 2024 | UEFA.com

FRANKFURT - Vitinha Of Portugal During The UEFA EURO 2024 Round Of 16 Match Between Portugal And
------------------------------------------------------------------------------------------------

 ![FRANKFURT - Vitinha of Portugal during the UEFA EURO 2024 round of 16 match between Portugal and](https://c8.alamy.com/comp/2XGE223/frankfurt-vitinha-of-portugal-during-the-uefa-euro-2024-round-of-16-match-between-portugal-and-slovenia-at-frankfurt-arena-on-july-1-2024-in-frankfurt-germany-anp-hollandse-hoogte-gerrit-van-keulen-2XGE223.jpg) <small>www.alamy.com</small>FRANKFURT - Vitinha of Portugal during the UEFA EURO 2024 round of 16 match between Portugal and ...

Vitinha Of Portugal Poses For A Photo With The Vivo Player Of The... News Photo - Getty Images
----------------------------------------------------------------------------------------------

 ![Vitinha of Portugal poses for a photo with the Vivo Player of the... News Photo - Getty Images](https://media.gettyimages.com/id/2158161619/photo/group-f-uefa-euro-2024.jpg?s=1024x1024&w=gi&k=20&c=OFb9p49Wo4ZCBgEOpEvqn4NZqC0VW1v-dHT27U9Xoho=) <small>www.gettyimages.com</small>Vitinha of Portugal poses for a photo with the Vivo Player of the... News Photo - Getty Images

Transferts : Le PSG Et Luis Campos Apprécient Vitinha, Le Milieu Du FC Porto
----------------------------------------------------------------------------

 ![Transferts : le PSG et Luis Campos apprécient Vitinha, le milieu du FC Porto](https://www.lequipe.fr/_medias/img-photo-jpg/vitinha-avec-le-maillot-d-international-u21-portugais-en-2021-maurizio-borsari-aflo-presse-sports-pr/1500000001656433/41:732,1925:1988-828-552-75/5771d.jpg) <small>www.lequipe.fr</small>Transferts : le PSG et Luis Campos apprécient Vitinha, le milieu du FC Porto

Vitinha Of Portugal During The Portugal Portraits - UEFA Nations... News Photo - Getty Images
---------------------------------------------------------------------------------------------

 ![Vitinha of Portugal during the Portugal Portraits - UEFA Nations... News Photo - Getty Images](https://media.gettyimages.com/id/2218377412/photo/portugal-portraits-uefa-nations-league-2025-finals.jpg?s=612x612&w=gi&k=20&c=A6idYjwIdjQDTCurRu6XBojy_3tGOaJwsFpbsSSPVTM=) <small>www.gettyimages.in</small>Vitinha of Portugal during the Portugal Portraits - UEFA Nations... News Photo - Getty Images

Portugal's Vitinha During The UEFA Euro 2024 Group F Match At Leipzig Stadium In Leipzig
----------------------------------------------------------------------------------------

 ![Portugal's Vitinha during the UEFA Euro 2024 Group F match at Leipzig Stadium in Leipzig](https://c8.alamy.com/comp/2XCTFEP/portugals-vitinha-during-the-uefa-euro-2024-group-f-match-at-leipzig-stadium-in-leipzig-germany-picture-date-tuesday-june-18-2024-2XCTFEP.jpg) <small>www.alamy.com</small>Portugal's Vitinha during the UEFA Euro 2024 Group F match at Leipzig Stadium in Leipzig ...

Vitinha Portugal Playing During Uefa Euro Editorial Stock Photo - Stock Image | Shutterstock
--------------------------------------------------------------------------------------------

 ![Vitinha Portugal Playing During Uefa Euro Editorial Stock Photo - Stock Image | Shutterstock](https://www.shutterstock.com/editorial/image-editorial/M9TfQa3eM3Dacby5NDQ3MDU=/vitinha-portugal-playing-during-uefa-euro-2024-440nw-14567562av.jpg) <small>www.shutterstock.com</small>Vitinha Portugal Playing During Uefa Euro Editorial Stock Photo - Stock Image | Shutterstock ...

Portugal's Vitinha During The UEFA Euro 2024, Round Of 16 Match At The Frankfurt Arena In
-----------------------------------------------------------------------------------------

 ![Portugal's Vitinha during the UEFA Euro 2024, round of 16 match at the Frankfurt Arena in](https://c8.alamy.com/comp/2XF6XEJ/portugals-vitinha-during-the-uefa-euro-2024-round-of-16-match-at-the-frankfurt-arena-in-frankfurt-germany-picture-date-monday-july-1-2024-2XF6XEJ.jpg) <small>www.alamy.com</small>Portugal's Vitinha during the UEFA Euro 2024, round of 16 match at the Frankfurt Arena in ...

Internationals | Vitinha Makes U21 Euros’ Team Of The Week | Men's First-Team | News
------------------------------------------------------------------------------------

 ![Internationals | Vitinha makes U21 Euros’ team of the week | Men's First-Team | News](https://func-wolves-playmaker-imageresizer-prod-uksouth.azurewebsites.net/api/media/17005/vitinha-portugal.jpg) <small>www.wolves.co.uk</small>Internationals | Vitinha makes U21 Euros’ team of the week | Men's First-Team | News ...

Vitinha Of Portugal Poses For A Portrait During The Portugal Portrait... News Photo - Getty Images
--------------------------------------------------------------------------------------------------

 ![Vitinha of Portugal poses for a portrait during the Portugal Portrait... News Photo - Getty Images](https://media.gettyimages.com/id/2156815343/photo/portugal-portraits-uefa-euro-2024.jpg?s=1024x1024&w=gi&k=20&c=OgVYE8wvaeLYHemYypa0_Qx0JVkAm5i93MMsfftyi5A=) <small>www.gettyimages.com</small>Vitinha of Portugal poses for a portrait during the Portugal Portrait... News Photo - Getty Images

Vitinha Of Portugal Poses For A Portrait During The Portugal Portrait... News Photo - Getty Images
--------------------------------------------------------------------------------------------------

 ![Vitinha of Portugal poses for a portrait during the Portugal Portrait... News Photo - Getty Images](https://media.gettyimages.com/id/2156923086/photo/portugal-portraits-uefa-euro-2024.jpg?s=1024x1024&w=gi&k=20&c=IhNQt3531uvsjD8xcCgywtJ8STmji6ZQFgJ2Z5VpCjo=) <small>www.gettyimages.com</small>Vitinha of Portugal poses for a portrait during the Portugal Portrait... News Photo - Getty Images

Frankfurt, Germany. 01st July, 2024. Frankfurt, Germany, July 1st 2024 FRANKFURT, GERMANY - JULY
------------------------------------------------------------------------------------------------

 ![Frankfurt, Germany. 01st July, 2024. Frankfurt, Germany, July 1st 2024 FRANKFURT, GERMANY - JULY](https://c8.alamy.com/comp/2XF9YM5/frankfurt-germany-01st-july-2024-frankfurt-germany-july-1st-2024-frankfurt-germany-july-01-vitinha-of-portugal-seen-before-the-uefa-euro-2024-championship-round-of-16-match-between-portugal-and-slovenia-at-frankfurt-arena-on-july-01-2024-in-frankfurt-germany-photo-by-dan-o-connoratpimages-dan-o-connor-dan-o-connoratp-imagesspp-credit-spp-sport-press-photo-alamy-live-news-2XF9YM5.jpg) <small>www.alamy.com</small>Frankfurt, Germany. 01st July, 2024. Frankfurt, Germany, July 1st 2024 FRANKFURT, GERMANY - JULY ...

Euro 2024 : Pour Vitinha, Le Portugal Est «une Grande équipe» Qui Doit Faire Ses Preuves
----------------------------------------------------------------------------------------

 ![Euro 2024 : Pour Vitinha, le Portugal est «une grande équipe» qui doit faire ses preuves](https://i.f1g.fr/media/cms/1200x630_crop/2024/06/14/41d8af2dcd8363569e3fe40e2880b75aac689e48f7a9d269d92d01aa27fe95ef.jpg) <small>www.lefigaro.fr</small>Euro 2024 : Pour Vitinha, le Portugal est «une grande équipe» qui doit faire ses preuves

Wolves: Vitinha Shines At Euro U21 Tournament
---------------------------------------------

 ![Wolves: Vitinha shines at Euro U21 tournament](https://static0.footballfancastimages.com/wordpress/wp-content/uploads/2021/04/Vitinha-Wolves-Portugal-Portugal-U21-Molineux-Joao-Moutinho-Nuno-Santo-Premier-League-Fosun-Jeff-Shi.jpg) <small>www.footballfancast.com</small>Wolves: Vitinha shines at Euro U21 tournament

Munich, germany. 8th june, 2025. vitinha seen celebrating with a trophy during uefa nations. Vitinha high resolution stock photography and images. vitinha shines during fabio silva's portugal u21 debut
