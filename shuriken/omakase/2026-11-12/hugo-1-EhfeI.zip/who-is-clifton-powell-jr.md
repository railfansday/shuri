---
title: "Who Is Clifton Powell Jr - Clifton powell jr. wiki: biography, age, height, parents, ethnicity, girlfriend, net worth &amp; more"
description: "Clifton powell jr net worth, wiki, biography, age, girlfriend, religion, nationality, photos"
date: "2026-03-14"
categories:
- "Uncategorized"
images:
- "https://www.newsunzip.com/wp-content/uploads/2022/04/Clifton-Powell-Jr.-with-Sasha-Obama.jpg"
featuredImage: "https://pagesix.com/wp-content/uploads/sites/3/2022/04/who-is-clifton-powell-jr_19.jpg?quality=75&amp;strip=all&amp;w=683"
featured_image: "https://healthyceleb.com/wp-content/uploads/2022/04/Clifton-Powell-Jr..jpg"
image: "https://healthyceleb.com/wp-content/uploads/2022/04/Clifton-Powell-Jr.-as-seen-while-posing-for-a-picture.jpg"
---

If you are looking for Who is Clifton Powell Jr? Wiki, Net Worth, Biography, Age, Height, Girlfriend you've came to the right web. We have 35 Images about Who is Clifton Powell Jr? Wiki, Net Worth, Biography, Age, Height, Girlfriend like Who is Clifton Powell Jr.? What to know about Sasha Obama’s BF, ¿Quién es Clifton Powell Jr.? ¿Está saliendo con Sasha Obama? - En El Ajo En El Ajo and also Who is Clifton Powell Jr? Wiki, Net Worth, Biography, Age, Height, Girlfriend. Here it is:

Who Is Clifton Powell Jr? Wiki, Net Worth, Biography, Age, Height, Girlfriend
-----------------------------------------------------------------------------

 ![Who is Clifton Powell Jr? Wiki, Net Worth, Biography, Age, Height, Girlfriend](https://www.walikali.com/wp-content/uploads/2022/04/Clifton-Powell-Jr-4.jpg) <small>www.walikali.com</small>Who is Clifton Powell Jr? Wiki, Net Worth, Biography, Age, Height, Girlfriend

Clifton Powell Jr. Height, Weight, Age, Family, Girlfriends, Facts
------------------------------------------------------------------

 ![Clifton Powell Jr. Height, Weight, Age, Family, Girlfriends, Facts](https://healthyceleb.com/wp-content/uploads/2022/04/Clifton-Powell-Jr..jpg) <small>healthyceleb.com</small>Clifton Powell Jr. Height, Weight, Age, Family, Girlfriends, Facts

Sasha Obama Now Living In LA And Dating Actor Clifton Powell's Namesake Son | EURweb | Black
--------------------------------------------------------------------------------------------

 ![Sasha Obama Now Living in LA and Dating Actor Clifton Powell's Namesake Son | EURweb | Black](https://eurweb.com/wp-content/uploads/2022/04/Sasha-Obama-and-Clifton-Powell-Jr-Getty.jpg) <small>eurweb.com</small>Sasha Obama Now Living in LA and Dating Actor Clifton Powell's Namesake Son | EURweb | Black ...

Clifton Powell Jr. Wiki: Biography, Age, Height, Parents, Ethnicity, Girlfriend, Net Worth &amp; More
-----------------------------------------------------------------------------------------------------

 ![Clifton Powell Jr. Wiki: Biography, Age, Height, Parents, Ethnicity, Girlfriend, Net Worth & More](https://www.newsunzip.com/wp-content/uploads/2022/04/Clifton-Powell-Jr.-childhood-picture-with-his-father-Clifton-Powell-and-sister-May-Powell.jpg) <small>www.newsunzip.com</small>Clifton Powell Jr. Wiki: Biography, Age, Height, Parents, Ethnicity, Girlfriend, Net Worth &amp; More

Clifton Theater Hi-res Stock Photography And Images - Alamy
-----------------------------------------------------------

 ![Clifton theater hi-res stock photography and images - Alamy](https://c8.alamy.com/comp/TY8368/actor-clifton-powell-c-attends-the-18th-annual-bet-awards-at-microsoft-theater-in-los-angeles-on-june-24-2018-the-ceremony-celebrates-achievements-in-entertainment-and-honors-music-sports-television-and-movies-released-between-april-1-2017-and-march-31-2018-photo-by-gregg-deguireupi-TY8368.jpg) <small>www.alamy.com</small>Clifton theater hi-res stock photography and images - Alamy

Clifton Powell | Live Action Wiki | Fandom
------------------------------------------

 ![Clifton Powell | Live Action Wiki | Fandom](https://static.wikia.nocookie.net/live-action/images/b/b6/Clifton_Powell.PNG/revision/latest/scale-to-width-down/220?cb=20201006180043) <small>live-action.fandom.com</small>Clifton Powell | Live Action Wiki | Fandom

379 Clifton Powell Stock Photos, High-Res Pictures, And Images - Getty Images
-----------------------------------------------------------------------------

 ![379 Clifton Powell Stock Photos, High-Res Pictures, and Images - Getty Images](https://media.gettyimages.com/id/111517334/photo/clifton-powell-jr-clifton-powell-and-mya-powell-at-the-world-premiere-of-screen-gems-first.jpg?s=612x612&w=gi&k=20&c=Z1wlsz1qyhVzoIJJkfK8Hz2ZdwQmboKDGz-rAaIoYpI=) <small>www.gettyimages.co.uk</small>379 Clifton Powell Stock Photos, High-Res Pictures, and Images - Getty Images

Clifton Powell Jr. Archives - TheJasmineBRAND
---------------------------------------------

 ![Clifton Powell Jr. Archives - theJasmineBRAND](https://thejasminebrand.com/wp-content/uploads/2022/04/Untitled-design-2022-04-21T133135.970-620x600.png) <small>thejasminebrand.com</small>Clifton Powell Jr. Archives - theJasmineBRAND

¿Quién Es Clifton Powell Jr.? ¿Está Saliendo Con Sasha Obama? - En El Ajo En El Ajo
-----------------------------------------------------------------------------------

 ![¿Quién es Clifton Powell Jr.? ¿Está saliendo con Sasha Obama? - En El Ajo En El Ajo](https://otakukart.com/wp-content/uploads/2022/04/Clifton-Powell-Jr.-.jpg) <small>enelajo.com</small>¿Quién es Clifton Powell Jr.? ¿Está saliendo con Sasha Obama? - En El Ajo En El Ajo

Who Is Sasha Obama’s New Boyfriend, Clifton Powell Jr? Barack And Michelle’s Youngest Daughter
----------------------------------------------------------------------------------------------

 ![Who is Sasha Obama’s new boyfriend, Clifton Powell Jr? Barack and Michelle’s youngest daughter](https://img.i-scmp.com/cdn-cgi/image/fit=contain,width=1024,format=auto/sites/default/files/d8/images/canvas/2022/05/10/a21c5716-5bec-4419-b3b7-2e3a4f1fc551_932f8b0b.jpg) <small>www.scmp.com</small>Who is Sasha Obama’s new boyfriend, Clifton Powell Jr? Barack and Michelle’s youngest daughter ...

Sasha Obama's New Boyfriend Is Son Of Hollywood Actor | Daily Mail Online
-------------------------------------------------------------------------

 ![Sasha Obama's new boyfriend is son of Hollywood actor | Daily Mail Online](https://i.dailymail.co.uk/1s/2022/04/20/23/56846675-10736199-Proud_father_Clifton_Sr_wrote_Check_out_Clifton_Powell_Jr_god_is-a-23_1650493434358.jpg) <small>www.dailymail.com</small>Sasha Obama's new boyfriend is son of Hollywood actor | Daily Mail Online

Clifton Powell Jr. Height, Weight, Age, Family, Girlfriends, Facts
------------------------------------------------------------------

 ![Clifton Powell Jr. Height, Weight, Age, Family, Girlfriends, Facts](https://healthyceleb.com/wp-content/uploads/2022/04/Clifton-Powell-Jr.-as-seen-while-posing-for-a-picture.jpg) <small>healthyceleb.com</small>Clifton Powell Jr. Height, Weight, Age, Family, Girlfriends, Facts

Clifton Powell's Instagram, Twitter &amp; Facebook On IDCrawl
-------------------------------------------------------------

 ![Clifton Powell's Instagram, Twitter & Facebook on IDCrawl](https://pyxis.nymag.com/v1/imgs/3d7/126/cc4ee26bccddb30de43489205b5dbe60f0-sasha-obama-clifton-powell-jr.2x.rsocial.w600.jpg) <small>www.idcrawl.com</small>Clifton Powell's Instagram, Twitter &amp; Facebook on IDCrawl

Hat Sohn Eines Hollywood-Stars Sasha Obamas Herz Erobert?
---------------------------------------------------------

 ![Hat Sohn eines Hollywood-Stars Sasha Obamas Herz erobert?](https://content3.promiflash.de/article-images/video_480/clifton-powell-und-clifton-powell-jr-laecheln.jpg) <small>www.promiflash.de</small>Hat Sohn eines Hollywood-Stars Sasha Obamas Herz erobert?

Clifton Powell Jr. Wiki: Biography, Age, Height, Parents, Ethnicity, Girlfriend, Net Worth &amp; More
-----------------------------------------------------------------------------------------------------

 ![Clifton Powell Jr. Wiki: Biography, Age, Height, Parents, Ethnicity, Girlfriend, Net Worth & More](https://www.newsunzip.com/wp-content/uploads/2022/04/Clifton-Powell-Jr.-with-Sasha-Obama.jpg) <small>www.newsunzip.com</small>Clifton Powell Jr. Wiki: Biography, Age, Height, Parents, Ethnicity, Girlfriend, Net Worth &amp; More

Clifton Powell Jr And Sasha Obama - Wanttono
--------------------------------------------

 ![Clifton Powell Jr and Sasha Obama - Wanttono](https://www.wanttono.com/wp-content/uploads/Clifton-Powell-Jr-and-Sasha.jpg) <small>wanttono.com</small>Clifton Powell Jr and Sasha Obama - Wanttono

Actor Clifton Powell Speaks On His Son Dating Sasha Obama And The Advice He Gives Him To Treat
----------------------------------------------------------------------------------------------

 ![Actor Clifton Powell Speaks On His Son Dating Sasha Obama And The Advice He Gives Him To Treat](https://sacculturalhub.com/wp-content/uploads/2022/07/Actor-Clifton-Powell-Speaks-On-His-Son-Dating-Sasha-Obama-And-The-Advice-He-Gives-Him-To-Treat-Her-Right-1024x670.png) <small>sacculturalhub.com</small>Actor Clifton Powell Speaks On His Son Dating Sasha Obama And The Advice He Gives Him To Treat ...

Clifton Powell Jr. Net Worth: All About Sasha Obama's Boyfriend
---------------------------------------------------------------

 ![Clifton Powell Jr. Net Worth: All About Sasha Obama's Boyfriend](https://media.marketrealist.com/brand-img/pRgCWwmOI/1600x838/clifton-powell-jr-dad-1650645137911.jpg) <small>marketrealist.com</small>Clifton Powell Jr. Net Worth: All About Sasha Obama's Boyfriend

Who Is Clifton Powell Jr? Wiki, Net Worth, Biography, Age, Height, Girlfriend
-----------------------------------------------------------------------------

 ![Who is Clifton Powell Jr? Wiki, Net Worth, Biography, Age, Height, Girlfriend](https://www.walikali.com/wp-content/uploads/2022/04/Clifton-Powell-Jr.jpg) <small>www.walikali.com</small>Who is Clifton Powell Jr? Wiki, Net Worth, Biography, Age, Height, Girlfriend

What To Know About Sasha Obama’s Reported BF Clifton Powell Jr. | Us Weekly
---------------------------------------------------------------------------

 ![What to Know About Sasha Obama’s Reported BF Clifton Powell Jr. | Us Weekly](https://www.usmagazine.com/wp-content/uploads/2022/04/Who-Is-Clifton-Powell-Jr-5-Things-to-Know-About-Sasha-Obama-Reported-Boyfriend-2.jpg?w=1200&quality=86&strip=all) <small>www.usmagazine.com</small>What to Know About Sasha Obama’s Reported BF Clifton Powell Jr. | Us Weekly

What Life Is Like For The Obama Sisters Today
---------------------------------------------

 ![What Life Is Like For The Obama Sisters Today](https://www.thelist.com/img/gallery/what-life-is-like-for-the-obama-sisters-today/sasha-is-dating-former-basketball-star-clifton-powell-jr-1673289690.jpg) <small>www.thelist.com</small>What Life Is Like For The Obama Sisters Today

Who Is Clifton Powell Jr? Wiki, Net Worth, Biography, Age, Height, Girlfriend
-----------------------------------------------------------------------------

 ![Who is Clifton Powell Jr? Wiki, Net Worth, Biography, Age, Height, Girlfriend](https://www.walikali.com/wp-content/uploads/2022/04/Clifton-Powell-Jr-3.jpg) <small>www.walikali.com</small>Who is Clifton Powell Jr? Wiki, Net Worth, Biography, Age, Height, Girlfriend

Clifton Powell Jr. Photos, News And Videos, Trivia And Quotes - FamousFix
-------------------------------------------------------------------------

 ![Clifton Powell Jr. Photos, News and Videos, Trivia and Quotes - FamousFix](https://www.usmagazine.com/wp-content/uploads/2022/04/Feature-Who-Is-Clifton-Powell-Jr-5-Things-to-Know-About-Sasha-Obama-Reported-Boyfriend.jpg?quality=86&strip=all) <small>www.famousfix.com</small>Clifton Powell Jr. Photos, News and Videos, Trivia and Quotes - FamousFix

Who Is Clifton Powell Jr.? What To Know About Sasha Obama’s BF
--------------------------------------------------------------

 ![Who is Clifton Powell Jr.? What to know about Sasha Obama’s BF](https://pagesix.com/wp-content/uploads/sites/3/2022/04/who-is-clifton-powell-jr_23.jpg) <small>pagesix.com</small>Who is Clifton Powell Jr.? What to know about Sasha Obama’s BF

Who Is Clifton Powell Jr.? What To Know About Sasha Obama’s BF
--------------------------------------------------------------

 ![Who is Clifton Powell Jr.? What to know about Sasha Obama’s BF](https://pagesix.com/wp-content/uploads/sites/3/2022/04/who-is-clifton-powell-jr_19.jpg?quality=75&strip=all&w=683) <small>pagesix.com</small>Who is Clifton Powell Jr.? What to know about Sasha Obama’s BF

Clifton Powell Jr Net Worth, Wiki, Biography, Age, Girlfriend, Religion, Nationality, Photos
--------------------------------------------------------------------------------------------

 ![Clifton Powell Jr Net Worth, Wiki, Biography, Age, Girlfriend, Religion, Nationality, Photos](https://explorenetworth.com/wp-content/uploads/2022/04/Clifton-Powell-Jr-1-1024x576.jpg) <small>explorenetworth.com</small>Clifton Powell Jr Net Worth, Wiki, Biography, Age, Girlfriend, Religion, Nationality, Photos

Who Is Clifton Powell Jr.? What To Know About Sasha Obama’s BF
--------------------------------------------------------------

 ![Who is Clifton Powell Jr.? What to know about Sasha Obama’s BF](https://pagesix.com/wp-content/uploads/sites/3/2022/04/who-is-clifton-powell-jr_24.jpg?quality=75&strip=all&w=2000) <small>pagesix.com</small>Who is Clifton Powell Jr.? What to know about Sasha Obama’s BF

Clifton Powell Jr. Bio, Age, Height, Girlfriend, Net Worth, Wiki
----------------------------------------------------------------

 ![Clifton Powell Jr. Bio, Age, Height, Girlfriend, Net Worth, Wiki](https://wealthyspy.com/wp-content/uploads/2022/04/Clifton-Powell-Jr..jpg) <small>wealthyspy.com</small>Clifton Powell Jr. Bio, Age, Height, Girlfriend, Net Worth, Wiki

Who Is Clifton Powell Jr? Wiki, Net Worth, Biography, Age, Height, Girlfriend
-----------------------------------------------------------------------------

 ![Who is Clifton Powell Jr? Wiki, Net Worth, Biography, Age, Height, Girlfriend](https://www.walikali.com/wp-content/uploads/2022/04/Clifton-Powell-Jr-2.jpg) <small>www.walikali.com</small>Who is Clifton Powell Jr? Wiki, Net Worth, Biography, Age, Height, Girlfriend

Sasha Obama Is Dating The Son Of Actor Clifton Powell - Just Jared - Celebrity News And Gossip
----------------------------------------------------------------------------------------------

 ![Sasha Obama Is Dating the Son of Actor Clifton Powell - Just Jared - Celebrity News and Gossip](https://cdn.justjared.com/wp-content/uploads/headlines/2022/04/sasha-clif2.jpg) <small>www.justjared.com</small>Sasha Obama Is Dating the Son of Actor Clifton Powell - Just Jared - Celebrity News and Gossip ...

Powell Jr Photos And Premium High Res Pictures - Getty Images
-------------------------------------------------------------

 ![Powell Jr Photos and Premium High Res Pictures - Getty Images](https://media.gettyimages.com/id/937951292/photo/clifton-powell-attends-insolved-history-life-of-a-king-atlanta-screening-at-martin-luther-king.jpg?s=612x612&w=gi&k=20&c=8q-HnbrpJZTxzUCDWWOHEPKEpZVo_4JJ9YGMk_5WwEY=) <small>www.gettyimages.com</small>Powell Jr Photos and Premium High Res Pictures - Getty Images

Actor Clifton Powell (C) Attends The 18th Annual BET Awards At Microsoft Theater In Los Angeles
-----------------------------------------------------------------------------------------------

 ![Actor Clifton Powell (C) attends the 18th annual BET Awards at Microsoft Theater in Los Angeles](https://c8.alamy.com/comp/TY836B/actor-clifton-powell-c-attends-the-18th-annual-bet-awards-at-microsoft-theater-in-los-angeles-on-june-24-2018-the-ceremony-celebrates-achievements-in-entertainment-and-honors-music-sports-television-and-movies-released-between-april-1-2017-and-march-31-2018-photo-by-gregg-deguireupi-TY836B.jpg) <small>www.alamy.com</small>Actor Clifton Powell (C) attends the 18th annual BET Awards at Microsoft Theater in Los Angeles ...

Powell Jr Photos And Premium High Res Pictures - Getty Images
-------------------------------------------------------------

 ![Powell Jr Photos and Premium High Res Pictures - Getty Images](https://media.gettyimages.com/id/937951288/photo/clifton-powell-attends-insolved-history-life-of-a-king-atlanta-screening-at-martin-luther-king.jpg?s=612x612&w=gi&k=20&c=dDt3KdYV6x_ploOyQYAu-fCb3frm3Y3S82n1objvI-Y=) <small>www.gettyimages.com</small>Powell Jr Photos and Premium High Res Pictures - Getty Images

Clifton Powell Jr. Bio, Age, Height, Girlfriend, Net Worth, Wiki
----------------------------------------------------------------

 ![Clifton Powell Jr. Bio, Age, Height, Girlfriend, Net Worth, Wiki](https://wealthyspy.com/wp-content/uploads/2022/04/Clifton-Powell-Jr.-1.jpg) <small>wealthyspy.com</small>Clifton Powell Jr. Bio, Age, Height, Girlfriend, Net Worth, Wiki

Knowledgecjanice - 🎬Celebrity Children.. Clifton Powell Son Clifton Powell Jr. (born On May 5
---------------------------------------------------------------------------------------------

 ![knowledgecjanice - 🎬Celebrity Children.. Clifton Powell Son Clifton Powell Jr. (born on May 5](https://lookaside.fbsbx.com/lookaside/crawler/media/?media_id=693996600037381) <small>www.facebook.com</small>knowledgecjanice - 🎬Celebrity Children.. Clifton Powell Son Clifton Powell Jr. (born on May 5 ...

Who is clifton powell jr? wiki, net worth, biography, age, height, girlfriend. Clifton powell jr. photos, news and videos, trivia and quotes. clifton powell's instagram, twitter &amp; facebook on idcrawl
