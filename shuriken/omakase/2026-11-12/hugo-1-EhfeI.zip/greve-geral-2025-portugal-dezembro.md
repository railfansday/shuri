---
title: "Greve Geral 2025 Portugal Dezembro - O que vai parar com a greve geral de 3 de junho?"
description: "Manifestação em frente ao parlamento resultou em seis detidos: tudo sobre a greve geral"
date: "2026-03-09"
categories:
- "Uncategorized"
images:
- "https://www.spn.pt/Media/Default/Info/68000/500/60/7/grevegeral11dez_cartaz.jpg"
featuredImage: "https://upload.wikimedia.org/wikipedia/commons/thumb/d/d1/Convocatórias_nas_ruas_sobre_a_Greve_Geral_de_7_de_dezembro_2025%2C_em_Portugal_07.jpg/960px-Convocatórias_nas_ruas_sobre_a_Greve_Geral_de_7_de_dezembro_2025%2C_em_Portugal_07.jpg"
featured_image: "https://cdn.sabado.pt/images/2025-12/img_980x653uu2025-12-22-09-03-14-753915.jpg"
image: "https://www.stts.pt/wp-content/uploads/2025/05/CAPA.jpg"
---

If you are looking for SPN - Fenprof — Adesão histórica à greve geral you've visit to the right web. We have 35 Images about SPN - Fenprof — Adesão histórica à greve geral like SPN - Fenprof — Adesão histórica à greve geral, A greve foi "um estrondo" político mas "perderam todos" - CNN Portugal and also Amanhã há greve da função pública (escolas podem fechar). Here it is:

SPN - Fenprof — Adesão Histórica à Greve Geral
----------------------------------------------

 ![SPN - Fenprof — Adesão histórica à greve geral](https://www.spn.pt/Media/Default/Info/68000/500/60/7/grevegeral11dez_cartaz.jpg) <small>www.spn.pt</small>SPN - Fenprof — Adesão histórica à greve geral

GREVE GERAL DE 11 DE DEZEMBRO DE 2025 – MANIFESTAÇÕES – LISBOA (VÍDEO) – EPHEMERA – Biblioteca E
------------------------------------------------------------------------------------------------

 ![GREVE GERAL DE 11 DE DEZEMBRO DE 2025 – MANIFESTAÇÕES – LISBOA (VÍDEO) – EPHEMERA – Biblioteca e](https://ephemerajpp.com/wp-content/uploads/2025/12/IMG_2182.jpg) <small>ephemerajpp.com</small>GREVE GERAL DE 11 DE DEZEMBRO DE 2025 – MANIFESTAÇÕES – LISBOA (VÍDEO) – EPHEMERA – Biblioteca e ...

Greve Geral Em Portugal – 11 De Dezembro - FLEMACON
---------------------------------------------------

 ![Greve geral em Portugal – 11 de dezembro - FLEMACON](https://www.flemacon.org/wp-content/uploads/2025/12/WhatsApp-Image-2025-12-12-at-19.45.27.jpeg) <small>www.flemacon.org</small>Greve geral em Portugal – 11 de dezembro - FLEMACON

Greve Geral Portuguesa De 2025 – Wikipédia, A Enciclopédia Livre
----------------------------------------------------------------

 ![Greve geral portuguesa de 2025 – Wikipédia, a enciclopédia livre](https://upload.wikimedia.org/wikipedia/commons/thumb/9/9c/Manifestação_Greve_Geral%2C_Lisboa%2C_Dez._2025_(54977121422).jpg/1280px-Manifestação_Greve_Geral%2C_Lisboa%2C_Dez._2025_(54977121422).jpg) <small>pt.wikipedia.org</small>Greve geral portuguesa de 2025 – Wikipédia, a enciclopédia livre

GREVE GERAL DE 11 DE DEZEMBRO DE 2025 – MANIFESTAÇÕES – LISBOA (2ª SÉRIE) – FOTOGRAFIAS DE PEDRO
------------------------------------------------------------------------------------------------

 ![GREVE GERAL DE 11 DE DEZEMBRO DE 2025 – MANIFESTAÇÕES – LISBOA (2ª SÉRIE) – FOTOGRAFIAS DE PEDRO](https://ephemerajpp.com/wp-content/uploads/2025/12/GreveGeral-0033.jpg) <small>ephemerajpp.com</small>GREVE GERAL DE 11 DE DEZEMBRO DE 2025 – MANIFESTAÇÕES – LISBOA (2ª SÉRIE) – FOTOGRAFIAS DE PEDRO ...

Maioria Dos Portugueses Diz Que Greve Geral Foi Justificada - Portugal - SÁBADO
-------------------------------------------------------------------------------

 ![Maioria dos portugueses diz que greve geral foi justificada - Portugal - SÁBADO](https://cdn.sabado.pt/images/2025-12/img_980x653uu2025-12-22-09-03-14-753915.jpg) <small>www.sabado.pt</small>Maioria dos portugueses diz que greve geral foi justificada - Portugal - SÁBADO

Mais De 50 Sindicatos Aderem à Greve Geral Marcada Para 11 De Dezembro
----------------------------------------------------------------------

 ![Mais de 50 sindicatos aderem à greve geral marcada para 11 de dezembro](https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA1QBjfX.img?w=1200&h=800&m=4&q=70) <small>www.msn.com</small>Mais de 50 sindicatos aderem à greve geral marcada para 11 de dezembro

Greve Geral Em Portugal – 11 De Dezembro - FLEMACON
---------------------------------------------------

 ![Greve geral em Portugal – 11 de dezembro - FLEMACON](https://www.flemacon.org/wp-content/uploads/2025/12/WhatsApp-Image-2025-12-12-at-19.45.27-1-696x870.jpeg) <small>www.flemacon.org</small>Greve geral em Portugal – 11 de dezembro - FLEMACON

A Greve Foi "um Estrondo" Político Mas "perderam Todos" - CNN Portugal
----------------------------------------------------------------------

 ![A greve foi "um estrondo" político mas "perderam todos" - CNN Portugal](https://img.iol.pt/image/id/693b2a1ad34e3caad84c47e9/1024.jpg) <small>cnnportugal.iol.pt</small>A greve foi "um estrondo" político mas "perderam todos" - CNN Portugal

Au Portugal, Appel à La Grève Générale Contre « L’une Des Plus Grandes Attaques Jamais Menées
---------------------------------------------------------------------------------------------

 ![Au Portugal, appel à la grève générale contre « l’une des plus grandes attaques jamais menées](https://rapportsdeforce.fr/wp-content/uploads/2025/12/Grevegeneraleportugallast.jpeg) <small>rapportsdeforce.fr</small>Au Portugal, appel à la grève générale contre « l’une des plus grandes attaques jamais menées ...

Após A Greve Geral De 11 De Dezembro Em Portugal - Mpr-nacional
---------------------------------------------------------------

 ![Após a Greve Geral de 11 de dezembro em Portugal - mpr-nacional](https://mpr-nacional.org/wp-content/uploads/2025/12/greve-geral-portugal-11-dezembro-1024x538.webp) <small>mpr-nacional.org</small>Após a Greve Geral de 11 de dezembro em Portugal - mpr-nacional

SPN - Fenprof — Adesão Histórica à Greve Geral
----------------------------------------------

 ![SPN - Fenprof — Adesão histórica à greve geral](https://www.spn.pt/Media/Default/_Profiles/ee10172b/82507d9/grevefenprof (6).jpeg?v=639010548582441113) <small>www.spn.pt</small>SPN - Fenprof — Adesão histórica à greve geral

Greve Geral Histórica Em Portugal Paralisa Transportes, Fecha Escolas E Pressiona Hospitais
-------------------------------------------------------------------------------------------

 ![Greve geral histórica em Portugal paralisa transportes, fecha escolas e pressiona hospitais](https://s.rfi.fr/media/display/074d4efc-d66a-11f0-a540-005056bfb2b6/w:1024/p:9x16/AP25345021595048.jpg) <small>www.rfi.fr</small>Greve geral histórica em Portugal paralisa transportes, fecha escolas e pressiona hospitais ...

Portugal: Greve Geral - CIG: Confederación Intersindical Galega
---------------------------------------------------------------

 ![Portugal: Greve geral - CIG: Confederación Intersindical Galega](https://www.cig.gal/assets/images/0/20251212_greve.PT-c79520e0.jpg) <small>www.cig.gal</small>Portugal: Greve geral - CIG: Confederación Intersindical Galega

SPGL - Greve Geral | 11 De Dezembro De 2025 (Piquetes, Concentrações E Manifestações)
-------------------------------------------------------------------------------------

 ![SPGL - Greve Geral | 11 de dezembro de 2025 (Piquetes, Concentrações e Manifestações)](https://www.spgl.pt/Media/Default/_Profiles/722d2b7d/68bcf4e1/IMG_2694.JPG?v=639010778412646835) <small>www.spgl.pt</small>SPGL - Greve Geral | 11 de dezembro de 2025 (Piquetes, Concentrações e Manifestações)

Motivos Da Adesão à Greve Geral De 11 De Dezembro De 2025
---------------------------------------------------------

 ![Motivos da adesão à Greve Geral de 11 de dezembro de 2025](https://spzn.pt/uploads/noticias/big_1763717239_6728_SPZN_2025_site_novo_(17).png) <small>spzn.pt</small>Motivos da adesão à Greve Geral de 11 de dezembro de 2025

Category:General Strike 11 December 2025 (Portugal) - Wikimedia Commons
-----------------------------------------------------------------------

 ![Category:General strike 11 December 2025 (Portugal) - Wikimedia Commons](https://upload.wikimedia.org/wikipedia/commons/thumb/d/d1/Convocatórias_nas_ruas_sobre_a_Greve_Geral_de_7_de_dezembro_2025%2C_em_Portugal_07.jpg/960px-Convocatórias_nas_ruas_sobre_a_Greve_Geral_de_7_de_dezembro_2025%2C_em_Portugal_07.jpg) <small>commons.wikimedia.org</small>Category:General strike 11 December 2025 (Portugal) - Wikimedia Commons

O Que Vai Parar Com A Greve Geral De 3 De Junho? - Portugal - SÁBADO
--------------------------------------------------------------------

 ![O que vai parar com a greve geral de 3 de junho? - Portugal - SÁBADO](https://cdn.sabado.pt/images/2026-05/img_980x653uu2026-05-21-18-26-04-766232.jpg) <small>www.sabado.pt</small>O que vai parar com a greve geral de 3 de junho? - Portugal - SÁBADO

Manifestação Em Frente Ao Parlamento Resultou Em Seis Detidos: Tudo Sobre A Greve Geral
---------------------------------------------------------------------------------------

 ![Manifestação em frente ao Parlamento resultou em seis detidos: tudo sobre a greve geral](https://cdn.sabado.pt/images/2025-12/img_1320x742uu2025-12-11-15-03-48-752830.jpg) <small>www.sabado.pt</small>Manifestação em frente ao Parlamento resultou em seis detidos: tudo sobre a greve geral ...

Greve Histórica Em Portugal: Três Milhões Cruzam Os Braços Em Protesto Contra Medidas De
----------------------------------------------------------------------------------------

 ![Greve histórica em Portugal: três milhões cruzam os braços em protesto contra medidas de](https://ogimg.infoglobo.com.br/in/2920985-315-96f/FT1086A/760/Manifestante-no-Centro-de-Lisboa-na-primeira-greve-geral-em-mais-de-duas-decadasFrancisco-LeongAFP.jpg) <small>oglobo.globo.com</small>Greve histórica em Portugal: três milhões cruzam os braços em protesto contra medidas de ...

Greve Geral Em Portugal Em Grande Destaque Na Imprensa Internacional - Sociedade - Correio Da Manhã
---------------------------------------------------------------------------------------------------

 ![Greve geral em Portugal em grande destaque na imprensa internacional - Sociedade - Correio da Manhã](https://cdn.cmjornal.pt/images/2025-12/img_1500x1000uu2025-12-10-22-06-51-2253721.jpg) <small>www.cmjornal.pt</small>Greve geral em Portugal em grande destaque na imprensa internacional - Sociedade - Correio da Manhã

GREVE GERAL DE 11 DE DEZEMBRO DE 2025 – MANIFESTAÇÕES – LISBOA (3ª SÉRIE) – EPHEMERA
------------------------------------------------------------------------------------

 ![GREVE GERAL DE 11 DE DEZEMBRO DE 2025 – MANIFESTAÇÕES – LISBOA (3ª SÉRIE) – EPHEMERA](https://ephemerajpp.com/wp-content/uploads/2025/12/IMG_2271.jpg) <small>ephemerajpp.com</small>GREVE GERAL DE 11 DE DEZEMBRO DE 2025 – MANIFESTAÇÕES – LISBOA (3ª SÉRIE) – EPHEMERA ...

Amanhã Há Greve Da Função Pública (escolas Podem Fechar)
--------------------------------------------------------

 ![Amanhã há greve da função pública (escolas podem fechar)](https://jornaldemafra.pt/wp-content/uploads/2025/12/greve-geral.webp) <small>jornaldemafra.pt</small>Amanhã há greve da função pública (escolas podem fechar)

Greve Geral Paralisa Transportes, Saúde E Educação No Porto - Expresso
----------------------------------------------------------------------

 ![Greve geral paralisa transportes, saúde e educação no Porto - Expresso](https://images.impresa.pt/expresso/2025-12-11-rds_15_greve-geral-2025-manifestacao-porto_rds_4314.jpg-f75ffda9/original) <small>expresso.pt</small>Greve geral paralisa transportes, saúde e educação no Porto - Expresso

Greve Geral Paralisa Portugal Contra Precarização De Direitos
-------------------------------------------------------------

 ![Greve geral paralisa Portugal contra precarização de direitos](https://pcdob.org.br/wp-content/uploads/2025/12/Ruas-de-Lisboa-foram-tomadas-por-trabalhadores-durante-a-greve-geral-Rafael-Medeiros-Esquerda.jpg) <small>pcdob.org.br</small>Greve geral paralisa Portugal contra precarização de direitos

GREVE GERAL – 11. DEZEMBRO.2025 | FEVICCOM - Federação Portuguesa Dos Sindicatos Da Construção
----------------------------------------------------------------------------------------------

 ![GREVE GERAL – 11. DEZEMBRO.2025 | FEVICCOM - Federação Portuguesa dos Sindicatos da Construção](https://sindicatos.cgtp.pt/feviccom/wp-content/blogs.dir/53/files/sites/53/2025/12/596523244_1281772690424980_8769585701815676928_n-800x450.jpg) <small>sindicatos.cgtp.pt</small>GREVE GERAL – 11. DEZEMBRO.2025 | FEVICCOM - Federação Portuguesa dos Sindicatos da Construção ...

Greve Geral Histórica Em Portugal Paralisa Transportes, Fecha Escolas E Pressiona Hospitais
-------------------------------------------------------------------------------------------

 ![Greve geral histórica em Portugal paralisa transportes, fecha escolas e pressiona hospitais](https://s.rfi.fr/media/display/074d4efc-d66a-11f0-a540-005056bfb2b6/w:1024/p:16x9/AP25345021595048.jpg) <small>www.rfi.fr</small>Greve geral histórica em Portugal paralisa transportes, fecha escolas e pressiona hospitais ...

Fertagus &gt; Fertagus (pt) &gt; Viajar &gt; Comunicados E Campanhas &gt; Greve Geral 11 De Dezembro De 2025
------------------------------------------------------------------------------------------------------------

 ![Fertagus > Fertagus (pt) > Viajar > Comunicados e Campanhas > Greve Geral 11 de dezembro de 2025](https://www.fertagus.pt/portals/0/FTG-Greve-Geral-web-1253x886.jpg) <small>www.fertagus.pt</small>Fertagus &gt; Fertagus (pt) &gt; Viajar &gt; Comunicados e Campanhas &gt; Greve Geral 11 de dezembro de 2025

UGT - UGT Convoca Greve Geral Para 11 De Dezembro De 2025
---------------------------------------------------------

 ![UGT - UGT convoca Greve Geral para 11 de dezembro de 2025](https://www.ugt.pt/publicfiles/5lwiefowts6org4iylxdz17lza2ejvtttpd6zq44.png) <small>www.ugt.pt</small>UGT - UGT convoca Greve Geral para 11 de dezembro de 2025

UGT - UGT Convoca Greve Geral Para 11 De Dezembro De 2025
---------------------------------------------------------

 ![UGT - UGT convoca Greve Geral para 11 de dezembro de 2025](https://www.ugt.pt/publicfiles/dvc3keu4ex9l4e2fizbuignqdef3jdmrhdwzogyd.png) <small>www.ugt.pt</small>UGT - UGT convoca Greve Geral para 11 de dezembro de 2025

AVISO PRÉVIO DE GREVE TRABALHADORES ADMINISTRAÇÃO PÚBLICA 16 DE MAIO 2025 – STTS
--------------------------------------------------------------------------------

 ![AVISO PRÉVIO DE GREVE TRABALHADORES ADMINISTRAÇÃO PÚBLICA 16 DE MAIO 2025 – STTS](https://www.stts.pt/wp-content/uploads/2025/05/CAPA.jpg) <small>www.stts.pt</small>AVISO PRÉVIO DE GREVE TRABALHADORES ADMINISTRAÇÃO PÚBLICA 16 DE MAIO 2025 – STTS

Fesete Vai Aderir à Greve Geral De 11 De Dezembro - Portugal - SÁBADO
---------------------------------------------------------------------

 ![Fesete vai aderir à greve geral de 11 de dezembro - Portugal - SÁBADO](https://cdn.sabado.pt/images/2013-05/img_980x653uu2013-05-30-19-15-03-73602.jpg) <small>www.sabado.pt</small>Fesete vai aderir à greve geral de 11 de dezembro - Portugal - SÁBADO

Greve Geral - CGTP-IN
---------------------

 ![Greve Geral - CGTP-IN](https://www.cgtp.pt/images/accao-e-luta/2025/54909311757_96950637a1_o1.jpg) <small>www.cgtp.pt</small>Greve Geral - CGTP-IN

11 De Dezembro. Portugal Terá A Sua Primeira Greve Geral Em 12 Anos Contra O Pacote Laboral
-------------------------------------------------------------------------------------------

 ![11 de Dezembro. Portugal terá a sua primeira Greve Geral em 12 anos contra o pacote laboral](https://www.esquerdadiario.com.br/IMG/logo/imagem_do_whatsapp_de_2025-11-18_a_s_20.02_31_2e7bdf41.jpg?1763508227) <small>www.esquerdadiario.com.br</small>11 de Dezembro. Portugal terá a sua primeira Greve Geral em 12 anos contra o pacote laboral ...

Imagens Do Dia De Greve Geral Em Portugal - Jornal O Globo
----------------------------------------------------------

 ![Imagens do dia de greve geral em Portugal - Jornal O Globo](https://ogimg.infoglobo.com.br/in/4387791-fd9-94b/FT1086A/760/foto2.jpg?posicaoFoto2) <small>oglobo.globo.com</small>Imagens do dia de greve geral em Portugal - Jornal O Globo

Mais de 50 sindicatos aderem à greve geral marcada para 11 de dezembro. Greve geral em portugal – 11 de dezembro. greve geral histórica em portugal paralisa transportes, fecha escolas e pressiona hospitais ...
