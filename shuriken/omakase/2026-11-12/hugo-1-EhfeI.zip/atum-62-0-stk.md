---
title: "Atum-6/2-0-stk - atum-6/2-0-stk : raychem atum 3:1 heat shrink tubing"
description: "レイケム atum-6/2-0-stk（カット品1.2m） 黒色 接着層付き 防水熱収縮チューブ 6.0→2.0mm : fa-ubon yahoo!店"
date: "2026-05-11"
categories:
- "Uncategorized"
images:
- "https://media.digikey.com/photos/Tyco Raychem Photos/ATU062K.jpg"
featuredImage: "https://uk.farnell.com/productimages/large/en_GB/42246141.jpg"
featured_image: "https://s-motorsport.com/image/cache/catalog/Raychem/ATUM 3-1/TE-Raychem-ATUM 3-1-900x900.jpg"
image: "https://media.rs-online.com/F3161568-01.jpg"
---

If you are searching about ATUM-6/2-0-STK TE Connectivity Raychem Cable Protection | Kabel, Drähte - Management | DigiKey you've came to the right page. We have 35 Pictures about ATUM-6/2-0-STK TE Connectivity Raychem Cable Protection | Kabel, Drähte - Management | DigiKey like ATUM-6/2-0-STK TE Connectivity | Raychem Products | Heilind, ATUM-6/2-0-STK Клеевая термоусадка самозатухающая Raychem, NB11652001 and also ATUM-6/2-0-STK : RAYCHEM ATUM 3:1 Heat Shrink Tubing | TE Connectivity. Here it is:

ATUM-6/2-0-STK TE Connectivity Raychem Cable Protection | Kabel, Drähte - Management | DigiKey
----------------------------------------------------------------------------------------------

 ![ATUM-6/2-0-STK TE Connectivity Raychem Cable Protection | Kabel, Drähte - Management | DigiKey](https://media.digikey.com/pdf/Catalog Drawings/Heat Shrink/ATUM-62-0-STK.jpg) <small>www.digikey.de</small>ATUM-6/2-0-STK TE Connectivity Raychem Cable Protection | Kabel, Drähte - Management | DigiKey

ATUM-6/2-0-STK | Gaine Thermorétractable TE Connectivity, Noir Rétreint 3:1, 1.219m | RS
----------------------------------------------------------------------------------------

 ![ATUM-6/2-0-STK | Gaine thermorétractable TE Connectivity, Noir rétreint 3:1, 1.219m | RS](https://media.rs-online.com/image/upload/bo_1.5px_solid_white,b_auto,c_pad,dpr_2,f_auto,h_399,q_auto,w_710/c_pad,h_399,w_710/R7822071-01?pgw=1) <small>fr.rs-online.com</small>ATUM-6/2-0-STK | Gaine thermorétractable TE Connectivity, Noir rétreint 3:1, 1.219m | RS

ATUM-6/2-0-STK TE Connectivity | Raychem Products | Heilind
-----------------------------------------------------------

 ![ATUM-6/2-0-STK TE Connectivity | Raychem Products | Heilind](https://sku-product-images.s3.us-east-2.amazonaws.com/AMP/1-1971875-7.jpg) <small>www.heilind.com</small>ATUM-6/2-0-STK TE Connectivity | Raychem Products | Heilind

ATUM-6/2-0-STK TE Connectivity Raychem Cable Protection | Heat Shrink Tubing | DigiKey
--------------------------------------------------------------------------------------

 ![ATUM-6/2-0-STK TE Connectivity Raychem Cable Protection | Heat Shrink Tubing | DigiKey](https://mm.digikey.com/Volume0/opasdata/d220001/derivates/3/003/226/041/MFG_ATUM-XX-X-0-SP_tmb(64x64).jpg) <small>www.digikey.com</small>ATUM-6/2-0-STK TE Connectivity Raychem Cable Protection | Heat Shrink Tubing | DigiKey

ATUM-6/2-0-STK TE Connectivity | Raychem Products | Heilind
-----------------------------------------------------------

 ![ATUM-6/2-0-STK TE Connectivity | Raychem Products | Heilind](https://sku-product-images.s3.us-east-2.amazonaws.com/RYC/RYCATUM-6-2-0-STK.jpg) <small>www.heilind.com</small>ATUM-6/2-0-STK TE Connectivity | Raychem Products | Heilind

ATUM-6/2-0-STK TE Connectivity Raychem Cable Protection | Cables, Wires - Management | DigiKey
----------------------------------------------------------------------------------------------

 ![ATUM-6/2-0-STK TE Connectivity Raychem Cable Protection | Cables, Wires - Management | DigiKey](https://media.digikey.com/photos/nophoto/pna_en_tmb.jpg) <small>www.digikey.com</small>ATUM-6/2-0-STK TE Connectivity Raychem Cable Protection | Cables, Wires - Management | DigiKey

Termocontraible Atum 6/2-0 ( 6mm/2mm )con Pasta 0.20mtrs | MercadoLibre
-----------------------------------------------------------------------

 ![Termocontraible Atum 6/2-0 ( 6mm/2mm )con Pasta 0.20mtrs | MercadoLibre](https://http2.mlstatic.com/D_NQ_NP_669773-MLA91139399415_082025-O.webp) <small>www.mercadolibre.com.ar</small>Termocontraible Atum 6/2-0 ( 6mm/2mm )con Pasta 0.20mtrs | MercadoLibre

ATUM-6/2-0-STK : RAYCHEM ATUM 3:1 Heat Shrink Tubing | TE Connectivity
----------------------------------------------------------------------

 ![ATUM-6/2-0-STK : RAYCHEM ATUM 3:1 Heat Shrink Tubing | TE Connectivity](https://www.te.com/content/dam/te-com/catalog/part/EM5/611/600/EM56116001-t2.jpg/jcr:content/renditions/product-small.png) <small>www.te.com</small>ATUM-6/2-0-STK : RAYCHEM ATUM 3:1 Heat Shrink Tubing | TE Connectivity

ATUM-6/2-0-STK Клеевая термоусадка самозатухающая Raychem, NB11652001
---------------------------------------------------------------------

 ![ATUM-6/2-0-STK Клеевая термоусадка самозатухающая Raychem, NB11652001](https://s-motorsport.com/image/cache/catalog/Raychem/ATUM 3-1/Raychem ATUM-6 2-0-STK NB11652001-2000x2000.jpg) <small>s-motorsport.com</small>ATUM-6/2-0-STK Клеевая термоусадка самозатухающая Raychem, NB11652001

ATUM-6/2-0-STK Chemelex | Chemelex Heat Shrink Tubing, Black 6 Mm Sleeve Dia. X 1.2m Length 3:1
-----------------------------------------------------------------------------------------------

 ![ATUM-6/2-0-STK Chemelex | Chemelex Heat Shrink Tubing, Black 6 mm Sleeve Dia. x 1.2m Length 3:1](https://res.cloudinary.com/rsc/image/upload/b_rgb:FFFFFF,c_pad,dpr_1.0,f_auto,q_auto,w_700/c_pad,w_700/Y0433222-01) <small>in.rsdelivers.com</small>ATUM-6/2-0-STK Chemelex | Chemelex Heat Shrink Tubing, Black 6 mm Sleeve Dia. x 1.2m Length 3:1 ...

TE Connectivity ATUM-6/2-0-STK Heat Shrink Tubing - 4 Ft. Stick At SkyGeek.com
------------------------------------------------------------------------------

 ![TE Connectivity ATUM-6/2-0-STK Heat Shrink Tubing - 4 ft. Stick at SkyGeek.com](https://cdn11.bigcommerce.com/s-jifykode7m/images/stencil/1280x1280/products/15869/120854/SGP97922_1_main__13081.1617287781.jpg?c=1) <small>skygeek.com</small>TE Connectivity ATUM-6/2-0-STK Heat Shrink Tubing - 4 ft. Stick at SkyGeek.com

ATUM-6/2-0-STK TE Connectivity - Heat Shrink Sleeve | Glued; 3: 1; 6mm; L: 1.2m; Black
--------------------------------------------------------------------------------------

 ![ATUM-6/2-0-STK TE Connectivity - Heat shrink sleeve | glued; 3: 1; 6mm; L: 1.2m; black](https://ce8dc832c.cloudimg.io/v7/_cdn_/0A/7F/90/00/0/653216_1.jpg?width=640&height=480&wat=1&wat_url=_tme-wrk_%2Ftme_new.png&wat_scale=100p&ci_sign=0dadd26c6980f757122b7c7b52dc68a66dc3f3ca) <small>www.tme.eu</small>ATUM-6/2-0-STK TE Connectivity - Heat shrink sleeve | glued; 3: 1; 6mm; L: 1.2m; black ...

ATUM-6/2-0-STK TE Connectivity 熱収縮チューブ， 収縮前 6mm， 収縮後 2mm， スリーブ長さ 1.2m ポリオレフィン， 黒 1本 TE
--------------------------------------------------------------------------------------

 ![ATUM-6/2-0-STK TE Connectivity 熱収縮チューブ， 収縮前 6mm， 収縮後 2mm， スリーブ長さ 1.2m ポリオレフィン， 黒 1本 TE](https://jp.images-monotaro.com/Monotaro3/pi/full/mono40953335-190508-02.jpg) <small>www.monotaro.com</small>ATUM-6/2-0-STK TE Connectivity 熱収縮チューブ， 収縮前 6mm， 収縮後 2mm， スリーブ長さ 1.2m ポリオレフィン， 黒 1本 TE ...

ATUM-6/2-0-STK : RAYCHEM ATUM 3:1 Heat Shrink Tubing | TE Connectivity
----------------------------------------------------------------------

 ![ATUM-6/2-0-STK : RAYCHEM ATUM 3:1 Heat Shrink Tubing | TE Connectivity](https://www.te.com/content/dam/te-com/catalog/part/EM5/611/600/EM56116001-t1.jpg/jcr:content/renditions/product-small.png?w=85) <small>www.te.com</small>ATUM-6/2-0-STK : RAYCHEM ATUM 3:1 Heat Shrink Tubing | TE Connectivity

ATUM-6/2-0-STK Heat Shrink Tubing By RAYCHEM CONNECTIVITY
---------------------------------------------------------

 ![ATUM-6/2-0-STK Heat Shrink Tubing by RAYCHEM CONNECTIVITY](https://cdn.radwell.com/productgoogleimages/cf054bf9e1344ba19a131778bed859f4.jpg) <small>www.radwell.com</small>ATUM-6/2-0-STK Heat Shrink Tubing by RAYCHEM CONNECTIVITY

ATUM-6/2-0-STK Raychem - Te Connectivity, Adhesive Lined Heat Shrink Tubing, Dual Medium Wall, 3
------------------------------------------------------------------------------------------------

 ![ATUM-6/2-0-STK Raychem - Te Connectivity, Adhesive Lined Heat Shrink Tubing, Dual Medium Wall, 3](https://uk.farnell.com/productimages/large/en_GB/42246141.jpg) <small>uk.farnell.com</small>ATUM-6/2-0-STK Raychem - Te Connectivity, Adhesive Lined Heat Shrink Tubing, Dual Medium Wall, 3 ...

ATUM-6/2-0-STK TE Connectivity | Raychem Products | Heilind
-----------------------------------------------------------

 ![ATUM-6/2-0-STK TE Connectivity | Raychem Products | Heilind](https://sku-product-images.s3.us-east-2.amazonaws.com/AMP/AMP206061-2.jpg) <small>www.heilind.com</small>ATUM-6/2-0-STK TE Connectivity | Raychem Products | Heilind

ATUM-6/2-0-STK | TE Connectivity Heat Shrink Tubing, Black 6 Mm Sleeve Dia. X 1.2m Length, ATUM
-----------------------------------------------------------------------------------------------

 ![ATUM-6/2-0-STK | TE Connectivity Heat Shrink Tubing, Black 6 mm Sleeve Dia. x 1.2m Length, ATUM](https://media.rs-online.com/image/upload/bo_1.5px_solid_white,b_auto,c_pad,dpr_2,f_auto,h_399,q_auto,w_710/c_pad,h_399,w_710/Y0487247-01?pgw=1) <small>my.rs-online.com</small>ATUM-6/2-0-STK | TE Connectivity Heat Shrink Tubing, Black 6 mm Sleeve Dia. x 1.2m Length, ATUM ...

TE Connectivity ATUM-6/2-0-STK Tubing, Heat Shrink,Adhesive Lined, Flame Retardant, Thin Wall
---------------------------------------------------------------------------------------------

 ![TE Connectivity ATUM-6/2-0-STK Tubing, Heat Shrink,Adhesive Lined, Flame Retardant, Thin Wall](https://assets.rs-online.com/image/upload/v1525227553/70101276.jpg) <small>us.rs-online.com</small>TE Connectivity ATUM-6/2-0-STK Tubing, Heat Shrink,Adhesive Lined, Flame Retardant, Thin Wall ...

ATUM-6/2-0-STK TE Connectivity Raychem Cable Protection | Heat Shrink Tubing | DigiKey
--------------------------------------------------------------------------------------

 ![ATUM-6/2-0-STK TE Connectivity Raychem Cable Protection | Heat Shrink Tubing | DigiKey](https://mm.digikey.com/Volume0/opasdata/d220001/derivates/1/003/209/407/ATU062K_sml.jpg) <small>www.digikey.com</small>ATUM-6/2-0-STK TE Connectivity Raychem Cable Protection | Heat Shrink Tubing | DigiKey

ATUM-6/2-0-STK TE CONNECTIVITY - RAYCHEM, Adhesive Lined Heat Shrink Tubing, Dual Medium Wall, 3
------------------------------------------------------------------------------------------------

 ![ATUM-6/2-0-STK TE CONNECTIVITY - RAYCHEM, Adhesive Lined Heat Shrink Tubing, Dual Medium Wall, 3](https://uk.farnell.com/productimages/standard/en_GB/42246141.jpg) <small>uk.farnell.com</small>ATUM-6/2-0-STK TE CONNECTIVITY - RAYCHEM, Adhesive Lined Heat Shrink Tubing, Dual Medium Wall, 3 ...

ATUM Thin Wall Heatshrink
-------------------------

 ![ATUM Thin Wall Heatshrink](https://www.transnet.co.nz/images/Products/ATUM-6-2-0-STK_1.jpg) <small>www.transnet.co.nz</small>ATUM Thin Wall Heatshrink

ATUM-6/2-0-STK : RAYCHEM ATUM 3:1 Heat Shrink Tubing | TE Connectivity
----------------------------------------------------------------------

 ![ATUM-6/2-0-STK : RAYCHEM ATUM 3:1 Heat Shrink Tubing | TE Connectivity](https://www.te.com/content/dam/te-com/catalog/part/EM5/611/600/EM56116001-t3.jpg/jcr:content/renditions/product-small.png) <small>www.te.com</small>ATUM-6/2-0-STK : RAYCHEM ATUM 3:1 Heat Shrink Tubing | TE Connectivity

レイケム ATUM-6/2-0-STK（カット品1.2m） 黒色 接着層付き 防水熱収縮チューブ 6.0→2.0mm : FA-Ubon Yahoo!店 - 通販 - Yahoo!ショッピング
------------------------------------------------------------------------------------------------

 ![レイケム ATUM-6/2-0-STK（カット品1.2m） 黒色 接着層付き 防水熱収縮チューブ 6.0→2.0mm : FA-Ubon Yahoo!店 - 通販 - Yahoo!ショッピング](https://item-shopping.c.yimg.jp/i/n/faubon_0878886) <small>store.shopping.yahoo.co.jp</small>レイケム ATUM-6/2-0-STK（カット品1.2m） 黒色 接着層付き 防水熱収縮チューブ 6.0→2.0mm : FA-Ubon Yahoo!店 - 通販 - Yahoo!ショッピング

ATUM-6/2-0-MS-STK - Raychem - Te Connectivity - Adhesive Lined Heat Shrink Tubing, Medium Wall, 3:1
---------------------------------------------------------------------------------------------------

 ![ATUM-6/2-0-MS-STK - Raychem - Te Connectivity - Adhesive Lined Heat Shrink Tubing, Medium Wall, 3:1](https://www.newark.com/productimages/large/en_US/09J3922-20.jpg) <small>www.newark.com</small>ATUM-6/2-0-MS-STK - Raychem - Te Connectivity - Adhesive Lined Heat Shrink Tubing, Medium Wall, 3:1

ATUM-6/2-0-STK TE Connectivity Raychem Cable Protection | Cables, Wires - Management | DigiKey
----------------------------------------------------------------------------------------------

 ![ATUM-6/2-0-STK TE Connectivity Raychem Cable Protection | Cables, Wires - Management | DigiKey](https://mm.digikey.com/Volume0/opasdata/d220001/medias/images/630/ATUM-62-0-STK.jpg) <small>www.digikey.com</small>ATUM-6/2-0-STK TE Connectivity Raychem Cable Protection | Cables, Wires - Management | DigiKey

ATUM-24/6-0-STK TE Connectivity | Raychem Products | Heilind
------------------------------------------------------------

 ![ATUM-24/6-0-STK TE Connectivity | Raychem Products | Heilind](https://sku-product-images.s3.us-east-2.amazonaws.com/RYC/RYCNB14032001.jpg) <small>www.heilind.com</small>ATUM-24/6-0-STK TE Connectivity | Raychem Products | Heilind

ATUM-6/2-0-STK By TE Connectivity | Digiode | ATUM-6/2-0-STK Connector Accessories
----------------------------------------------------------------------------------

 ![ATUM-6/2-0-STK by TE Connectivity | Digiode | ATUM-6/2-0-STK Connector Accessories](https://partstack.com/mpn/images/200/4058380737.webp) <small>digiode.com</small>ATUM-6/2-0-STK by TE Connectivity | Digiode | ATUM-6/2-0-STK Connector Accessories

ATUM-6/2-0-STK TE Connectivity Raychem Cable Protection | Cables, Wires - Management | DigiKey
----------------------------------------------------------------------------------------------

 ![ATUM-6/2-0-STK TE Connectivity Raychem Cable Protection | Cables, Wires - Management | DigiKey](https://mm.digikey.com/Volume0/opasdata/d220001/medias/images/707/ATU062K.jpg) <small>www.digikey.com</small>ATUM-6/2-0-STK TE Connectivity Raychem Cable Protection | Cables, Wires - Management | DigiKey

ATUM-6/2-0 | TE Connectivity Adhesive Lined Heat Shrink Tubing, Black 6mm Sleeve Dia. X 1.2m
--------------------------------------------------------------------------------------------

 ![ATUM-6/2-0 | TE Connectivity Adhesive Lined Heat Shrink Tubing, Black 6mm Sleeve Dia. x 1.2m](https://media.rs-online.com/F3161568-01.jpg) <small>uk.rs-online.com</small>ATUM-6/2-0 | TE Connectivity Adhesive Lined Heat Shrink Tubing, Black 6mm Sleeve Dia. x 1.2m ...

ATUM-6/2-0-STK Клеевая термоусадка самозатухающая Raychem, NB11652001
---------------------------------------------------------------------

 ![ATUM-6/2-0-STK Клеевая термоусадка самозатухающая Raychem, NB11652001](https://s-motorsport.com/image/cache/catalog/Raychem/ATUM 3-1/TE-Raychem-ATUM 3-1-900x900.jpg) <small>s-motorsport.com</small>ATUM-6/2-0-STK Клеевая термоусадка самозатухающая Raychem, NB11652001

ATUM-6/2-0-STK TE Connectivity Raychem Cable Protection | Cables, Wires - Management | DigiKey
----------------------------------------------------------------------------------------------

 ![ATUM-6/2-0-STK TE Connectivity Raychem Cable Protection | Cables, Wires - Management | DigiKey](https://media.digikey.com/photos/Tyco Raychem Photos/ATU062K.jpg) <small>www.digikey.com</small>ATUM-6/2-0-STK TE Connectivity Raychem Cable Protection | Cables, Wires - Management | DigiKey

ATUM-6/2-0-SP TE Connectivity Raychem Cable Protection $3.40136/ 1 SPQ, 2827 Original Parts In
----------------------------------------------------------------------------------------------

 ![ATUM-6/2-0-SP TE Connectivity Raychem Cable Protection $3.40136/ 1 SPQ, 2827 Original Parts in](https://res01.jakelectronics.com/80fimg/teconnectivityraychemcableprotection-atum620sp-8903.jpg) <small>www.jakelectronics.com</small>ATUM-6/2-0-SP TE Connectivity Raychem Cable Protection $3.40136/ 1 SPQ, 2827 Original Parts in ...

ATUM-6/2-0-STK Клеевая термоусадка самозатухающая Raychem, NB11652001
---------------------------------------------------------------------

 ![ATUM-6/2-0-STK Клеевая термоусадка самозатухающая Raychem, NB11652001](https://s-motorsport.com/image/cache/catalog/Raychem/ATUM 3-1/Raychem-ATUM 3-1-900x900.jpg) <small>s-motorsport.com</small>ATUM-6/2-0-STK Клеевая термоусадка самозатухающая Raychem, NB11652001

Kutistesukat -Instele Oy
------------------------

 ![Kutistesukat -Instele Oy](http://www.instele.fi/product_pictures/original/919-941-liimasukkaa.jpg) <small>www.instele.fi</small>Kutistesukat -Instele Oy

Te connectivity atum-6/2-0-stk heat shrink tubing. atum-6/2-0-sp te connectivity raychem cable protection $3.40136/ 1 spq, 2827 original parts in .... Atum-6/2-0-stk te connectivity
