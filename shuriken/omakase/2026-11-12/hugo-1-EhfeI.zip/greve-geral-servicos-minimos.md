---
title: "Greve Geral Serviços Mínimos - Greve geral: cgtp garante serviços mínimos e espera maior impacto na saúde, educação e ..."
description: "Ministério da educação pede serviços mínimos para greves de 2 e 3 de março"
date: "2026-06-12"
categories:
- "Uncategorized"
images:
- "https://eco.imgix.net/uploads/2025/11/cropped-doc2025110845998234acot9063.jpg"
featuredImage: "https://bordalo.observador.pt/v2/q:60/rs:fill:1440/c:2000:1125:nowe:0:104/plain/https://s3.observador.pt/wp-content/uploads/2024/06/21181009/43086145.jpg"
featured_image: "https://jornaleconomico.sapo.pt/wp-content/themes/yootheme/cache/f5/greve-1-e1764932962267-f502b260.jpeg"
image: "https://jornaleconomico.sapo.pt/wp-content/themes/yootheme/cache/f5/greve-1-e1764932962267-f502b260.jpeg"
---

If you are looking for SERVIÇOS MÍNIMOS «ILEGAIS» NÃO PARAM OS PROFESSORES. As greves de 2 e 3 de Março são para manter you've visit to the right place. We have 35 Pics about SERVIÇOS MÍNIMOS «ILEGAIS» NÃO PARAM OS PROFESSORES. As greves de 2 e 3 de Março são para manter like 📹 Esta quinta-feira há greve geral. Sabe porquê? – ECO, Que serviços mínimos estão já definidos para a greve geral? – Observador and also Greve geral: CGTP garante serviços mínimos e espera maior impacto na saúde, educação e. Here you go:

SERVIÇOS MÍNIMOS «ILEGAIS» NÃO PARAM OS PROFESSORES. As Greves De 2 E 3 De Março São Para Manter
------------------------------------------------------------------------------------------------

 ![SERVIÇOS MÍNIMOS «ILEGAIS» NÃO PARAM OS PROFESSORES. As greves de 2 e 3 de Março são para manter](https://external-preview.redd.it/serviços-mínimos-ilegais-não-param-os-professores-as-greves-v0-H26sUUh4Bkcny23dPnjaQCMMoQatIxQZZIlfV9bhVrw.jpg?auto=webp&s=256b74119aa4072c21e92be065645d62f59f6335) <small>www.reddit.com</small>SERVIÇOS MÍNIMOS «ILEGAIS» NÃO PARAM OS PROFESSORES. As greves de 2 e 3 de Março são para manter ...

Metro Do Porto "fortemente Condicionado" No Dia Da Greve Geral - JPN
--------------------------------------------------------------------

 ![Metro do Porto "fortemente condicionado" no dia da greve geral - JPN](https://www.jpn.up.pt/wp-content/uploads/2025/12/greve_geral1-1152x759.jpg) <small>www.jpn.up.pt</small>Metro do Porto "fortemente condicionado" no dia da greve geral - JPN

Greve Geral: Como São Determinados Os Serviços Mínimos
------------------------------------------------------

 ![Greve geral: como são determinados os serviços mínimos](https://assets.e-konomista.pt/uploads/2025/12/greve.jpg) <small>www.e-konomista.pt</small>Greve geral: como são determinados os serviços mínimos

Comboios: Conheça Os Serviços Mínimos Garantidos Nesta Greve Geral » Fama Rádio E Televisão
-------------------------------------------------------------------------------------------

 ![Comboios: Conheça os serviços mínimos garantidos nesta greve geral » Fama Rádio e Televisão](https://famaradio.tv/wp-content/uploads/2025/12/4.png) <small>famaradio.tv</small>Comboios: Conheça os serviços mínimos garantidos nesta greve geral » Fama Rádio e Televisão

ESCLARECIMENTOS SOBRE COMO AGIR, FACE AOS SERVIÇOS MÍNIMOS IMPOSTOS À GREVE ÀS AVALIAÇÕES FINAIS
------------------------------------------------------------------------------------------------

 ![ESCLARECIMENTOS SOBRE COMO AGIR, FACE AOS SERVIÇOS MÍNIMOS IMPOSTOS À GREVE ÀS AVALIAÇÕES FINAIS](http://www.spzs.pt/wp-content/uploads/2023/06/autocolante_sm.png) <small>www.spzs.pt</small>ESCLARECIMENTOS SOBRE COMO AGIR, FACE AOS SERVIÇOS MÍNIMOS IMPOSTOS À GREVE ÀS AVALIAÇÕES FINAIS ...

Dos Transportes à Saúde, Lares E Prisões, Que Serviços Mínimos Estão Garantidos Para A Greve
--------------------------------------------------------------------------------------------

 ![Dos transportes à saúde, lares e prisões, que serviços mínimos estão garantidos para a greve](https://images.impresa.pt/expresso/2025-12-09-greve-geral.jpg-0c01f0f6/original) <small>expresso.pt</small>Dos transportes à saúde, lares e prisões, que serviços mínimos estão garantidos para a greve ...

📹 Esta Quinta-feira Há Greve Geral. Sabe Porquê? – ECO
------------------------------------------------------

 ![📹 Esta quinta-feira há greve geral. Sabe porquê? – ECO](https://eco.imgix.net/uploads/2025/11/cropped-doc2025110845998234acot9063.jpg) <small>eco.sapo.pt</small>📹 Esta quinta-feira há greve geral. Sabe porquê? – ECO

Saiba Quais São Os Serviços Mínimos Garantidos Durante A Greve Geral - Infográficos - Correio Da
------------------------------------------------------------------------------------------------

 ![Saiba quais são os serviços mínimos garantidos durante a greve geral - Infográficos - Correio da](https://cdn.cmjornal.pt/images/2025-12/img_1280x721uu2025-12-08-00-14-01-2253212.jpg) <small>www.cmjornal.pt</small>Saiba quais são os serviços mínimos garantidos durante a greve geral - Infográficos - Correio da ...

SPGL - Os Serviços Mínimos Não Impedem O Direito à Greve, Nem A Continuação Da Luta. Não Deixes
-----------------------------------------------------------------------------------------------

 ![SPGL - Os serviços mínimos não impedem o direito à greve, nem a continuação da luta. Não deixes](https://www.spgl.pt/Media/Default/_Profiles/6a4bdd66/cbfc5fe7/IMAGEM SERV MINIMOS E GREVE.jpg?v=638132660260059746) <small>www.spgl.pt</small>SPGL - Os serviços mínimos não impedem o direito à greve, nem a continuação da luta. Não deixes ...

Que Serviços Mínimos Estão Assegurados Para A Greve Geral Nos Transportes, Saúde, Lares E Prisõ
-----------------------------------------------------------------------------------------------

 ![Que serviços mínimos estão assegurados para a greve geral nos transportes, saúde, lares e prisõ](https://i.ytimg.com/vi/sT6H2H9a8U4/maxresdefault.jpg?sqp=-oaymwEmCIAKENAF8quKqQMa8AEB-AH-CYAC0AWKAgwIABABGGUgWyhUMA8=&rs=AOn4CLBOmKc4t7MFIC2CJnyUJK2trzRUQQ) <small>www.youtube.com</small>Que serviços mínimos estão assegurados para a greve geral nos transportes, saúde, lares e prisõ ...

Autarquias Da CDU Não Exigiram Serviços Mínimos A Não Docentes Durante Greve Geral - Diário Do
----------------------------------------------------------------------------------------------

 ![Autarquias da CDU não exigiram serviços mínimos a não docentes durante greve geral - Diário do](https://diariodistrito.sapo.pt/wp-content/uploads/2021/10/greves_1.jpeg) <small>diariodistrito.sapo.pt</small>Autarquias da CDU não exigiram serviços mínimos a não docentes durante greve geral - Diário do ...

Comboios: Conheça Os Serviços Mínimos Garantidos Nesta Greve Geral » Fama Rádio E Televisão
-------------------------------------------------------------------------------------------

 ![Comboios: Conheça os serviços mínimos garantidos nesta greve geral » Fama Rádio e Televisão](https://famaradio.tv/wp-content/uploads/2025/12/2-1.png) <small>famaradio.tv</small>Comboios: Conheça os serviços mínimos garantidos nesta greve geral » Fama Rádio e Televisão

Em Dia De Greve Geral, Serviços Públicos Vão Estar Em Mínimos - Sociedade - Correio Da Manhã
--------------------------------------------------------------------------------------------

 ![Em dia de greve geral, serviços públicos vão estar em mínimos - Sociedade - Correio da Manhã](https://cdn.cmjornal.pt/images/2026-06/img_1500x1000uu2026-06-01-10-26-53-2288546.jpg) <small>www.cmjornal.pt</small>Em dia de greve geral, serviços públicos vão estar em mínimos - Sociedade - Correio da Manhã

Greve Geral: Comboios, Carris E Barcos Com Serviços Mínimos, Metro De Lisboa De Fora
------------------------------------------------------------------------------------

 ![Greve geral: Comboios, Carris e barcos com serviços mínimos, Metro de Lisboa de fora](https://media.assettype.com/dn/2025-11-17/ih84d6bj/DOC.20251117.46046223.JSG12.JPG?w=480&auto=format%2Ccompress) <small>www.dn.pt</small>Greve geral: Comboios, Carris e barcos com serviços mínimos, Metro de Lisboa de fora

GREVE GERAL – 11 DE DEZEMBRO DE 2025 – Pela Defesa Dos Direitos Laborais. Professores
-------------------------------------------------------------------------------------

 ![GREVE GERAL – 11 DE DEZEMBRO DE 2025 – Pela defesa dos direitos laborais. Professores](https://www.spzs.pt/wp-content/uploads/2025/11/pacotelaboral-1.jpg) <small>www.spzs.pt</small>GREVE GERAL – 11 DE DEZEMBRO DE 2025 – Pela defesa dos direitos laborais. Professores ...

Ministério Da Educação Pede Serviços Mínimos Para Greves De 2 E 3 De Março - SIC Notícias
-----------------------------------------------------------------------------------------

 ![Ministério da Educação pede serviços mínimos para greves de 2 e 3 de março - SIC Notícias](https://images.impresa.pt/sicnot/2023-02-15-Mario-Nogueira-Fenprof.jpg-a0f935e0/original) <small>sicnoticias.pt</small>Ministério da Educação pede serviços mínimos para greves de 2 e 3 de março - SIC Notícias

Dos Serviços Mínimos Aos Confrontos Entre Manifestantes E Polícias: País Voltou A Estar A Meio
----------------------------------------------------------------------------------------------

 ![Dos serviços mínimos aos confrontos entre manifestantes e polícias: País voltou a estar a meio](https://cdn.cmjornal.pt/images/2026-06/img_1500x1000uu2026-06-03-16-17-02-2289022.jpg) <small>www.cmjornal.pt</small>Dos serviços mínimos aos confrontos entre manifestantes e polícias: País voltou a estar a meio ...

Profissionais De Saúde Moçambicanos Em Greve Anunciam Serviços Mínimos – Moz24h
-------------------------------------------------------------------------------

 ![Profissionais de saúde moçambicanos em greve anunciam serviços mínimos – Moz24h](https://moz24h.co.mz/wp-content/uploads/2023/08/41300705.jpg) <small>moz24h.co.mz</small>Profissionais de saúde moçambicanos em greve anunciam serviços mínimos – Moz24h

São Estes Os Serviços Mínimos Já Fixados Para A Greve Geral
-----------------------------------------------------------

 ![São estes os serviços mínimos já fixados para a greve geral](https://www.mais.pt/atividadesindical/PublishingImages/greve 9.jpg?Width=300) <small>www.mais.pt</small>São estes os serviços mínimos já fixados para a greve geral

VILA REAL: GREVE ENCERRA ESCOLAS, FÁBRICAS E DEIXA HOSPITAL EM "MÍNIMOS" | JORNALONLINE
---------------------------------------------------------------------------------------

 ![VILA REAL: GREVE ENCERRA ESCOLAS, FÁBRICAS E DEIXA HOSPITAL EM "MÍNIMOS" | JORNALONLINE](https://jornalonline.pt/wp-content/uploads/2025/12/vila-real-greve-geral-fecha-escolas-para-fabricas-e-deixa-hospital-de-chaves-em-servicos-minimos.jpg) <small>jornalonline.pt</small>VILA REAL: GREVE ENCERRA ESCOLAS, FÁBRICAS E DEIXA HOSPITAL EM "MÍNIMOS" | JORNALONLINE

Railways.pt | GREVE: Serviços Mínimos Para A Greve De 31 De Maio De 2023
------------------------------------------------------------------------

 ![Railways.pt | GREVE: serviços mínimos para a greve de 31 de Maio de 2023](https://railways.pt/strikes/31Mai2023/urbanos-porto-1.png) <small>railways.pt</small>Railways.pt | GREVE: serviços mínimos para a greve de 31 de Maio de 2023

Dos Serviços Mínimos Aos Confrontos Entre Manifestantes E Polícias: País Voltou A Estar A Meio
----------------------------------------------------------------------------------------------

 ![Dos serviços mínimos aos confrontos entre manifestantes e polícias: País voltou a estar a meio](https://cdn.cmjornal.pt/images/2026-06/img_1500x1000uu2026-06-03-16-17-00-2289019.jpg) <small>www.cmjornal.pt</small>Dos serviços mínimos aos confrontos entre manifestantes e polícias: País voltou a estar a meio ...

A Greve, Quem A Pode Convocar E Quem Está Abrangido: Perguntas E Respostas
--------------------------------------------------------------------------

 ![A greve, quem a pode convocar e quem está abrangido: perguntas e respostas](https://jornaleconomico.sapo.pt/wp-content/themes/yootheme/cache/f5/greve-1-e1764932962267-f502b260.jpeg) <small>jornaleconomico.sapo.pt</small>A greve, quem a pode convocar e quem está abrangido: perguntas e respostas

Greve Geral: Saiba Quais São Os Serviços Mínimos Já Decretados - SIC Notícias
-----------------------------------------------------------------------------

 ![Greve geral: saiba quais são os serviços mínimos já decretados - SIC Notícias](https://images.impresa.pt/sicnot/2025-11-17-cgtp-pre-aviso-greve-82e19fc3-1/16x9/mw-1200) <small>sicnoticias.pt</small>Greve geral: saiba quais são os serviços mínimos já decretados - SIC Notícias

Que Serviços Mínimos Estão Já Definidos Para A Greve Geral? – Observador
------------------------------------------------------------------------

 ![Que serviços mínimos estão já definidos para a greve geral? – Observador](https://bordalo.observador.pt/v2/q:60/rs:fill:1440/c:2000:1125:nowe:0:104/plain/https://s3.observador.pt/wp-content/uploads/2024/06/21181009/43086145.jpg) <small>observador.pt</small>Que serviços mínimos estão já definidos para a greve geral? – Observador

Greve Geral: CGTP Garante Serviços Mínimos E Espera Maior Impacto Na Saúde, Educação E
--------------------------------------------------------------------------------------

 ![Greve geral: CGTP garante serviços mínimos e espera maior impacto na saúde, educação e](https://images.impresa.pt/expresso/2025-11-08-manifestacao-da-cgtp-contra-o-pacote-laboral-com-anuncio-de-greve-geral-ea5472c4/original) <small>expresso.pt</small>Greve geral: CGTP garante serviços mínimos e espera maior impacto na saúde, educação e ...

JORNAL - GREVE GERAL AVANÇA NO DIA 11. SEXTA-FEIRA CONTA COM NOVA GREVE A Greve Geral Que Se
--------------------------------------------------------------------------------------------

 ![JORNAL - GREVE GERAL AVANÇA NO DIA 11. SEXTA-FEIRA CONTA COM NOVA GREVE A greve geral que se](https://lookaside.fbsbx.com/lookaside/crawler/media/?media_id=1634621500842359) <small>www.facebook.com</small>JORNAL - GREVE GERAL AVANÇA NO DIA 11. SEXTA-FEIRA CONTA COM NOVA GREVE A greve geral que se ...

Tribunal Prolonga Serviços Mínimos Nas Escolas Até Ao Final Do Mês – Observador
-------------------------------------------------------------------------------

 ![Tribunal prolonga serviços mínimos nas escolas até ao final do mês – Observador](https://bordalo.observador.pt/v2/q:84/rs:fill:2000:1125/c:2000:1125:nowe:0:115/plain/https://s3.observador.pt/wp-content/uploads/2023/03/09135554/40398190.jpg) <small>observador.pt</small>Tribunal prolonga serviços mínimos nas escolas até ao final do mês – Observador

Greve 3 De Fevereiro – Serviços Mínimos - Agrupamento De Escolas Da Lousã
-------------------------------------------------------------------------

 ![Greve 3 de fevereiro – Serviços mínimos - Agrupamento de Escolas da Lousã](https://escolas.aglousa.com/wp-content/uploads/2019/06/greve.png) <small>escolas.aglousa.com</small>Greve 3 de fevereiro – Serviços mínimos - Agrupamento de Escolas da Lousã

3 JUNHO | GREVE GERAL CONTRA O PACOTE LABORAL - Sindicato Dos Trabalhadores Do Comércio
---------------------------------------------------------------------------------------

 ![3 JUNHO | GREVE GERAL CONTRA O PACOTE LABORAL - Sindicato dos Trabalhadores do Comércio](https://image.jimcdn.com/app/cms/image/transf/dimension=4000x3000:format=jpg/path/s3820655f8d987127/image/i4ba186dc42d4f07e/version/1778075119/3-junho-greve-geral-contra-o-pacote-laboral.jpg) <small>www.cesp.pt</small>3 JUNHO | GREVE GERAL CONTRA O PACOTE LABORAL - Sindicato dos Trabalhadores do Comércio ...

3 JUNHO | GREVE GERAL CONTRA O PACOTE LABORAL - Sindicato Dos Trabalhadores Do Comércio
---------------------------------------------------------------------------------------

 ![3 JUNHO | GREVE GERAL CONTRA O PACOTE LABORAL - Sindicato dos Trabalhadores do Comércio](https://image.jimcdn.com/app/cms/image/transf/dimension=origxorig:format=jpg/path/s3820655f8d987127/image/i5e5b75974b65d8a9/version/1779378127/image.jpg) <small>www.cesp.pt</small>3 JUNHO | GREVE GERAL CONTRA O PACOTE LABORAL - Sindicato dos Trabalhadores do Comércio ...

Comboios: Conheça Os Serviços Mínimos Garantidos Nesta Greve Geral » Fama Rádio E Televisão
-------------------------------------------------------------------------------------------

 ![Comboios: Conheça os serviços mínimos garantidos nesta greve geral » Fama Rádio e Televisão](https://famaradio.tv/wp-content/uploads/2025/12/5.png) <small>famaradio.tv</small>Comboios: Conheça os serviços mínimos garantidos nesta greve geral » Fama Rádio e Televisão

Greve Geral: TAP Garante 79 Voos E CP Terá Comboios Em Serviços Mínimos
-----------------------------------------------------------------------

 ![Greve geral: TAP garante 79 voos e CP terá comboios em serviços mínimos](https://infocul.pt/wp-content/uploads/2026/06/43d5e47b-5742-4308-8616-44856afa7e5a-1068x601.jpg) <small>infocul.pt</small>Greve geral: TAP garante 79 voos e CP terá comboios em serviços mínimos

Greve Geral De 11 De Dezembro: Impacto Económico Estimado E Análise | Economia
------------------------------------------------------------------------------

 ![Greve Geral de 11 de Dezembro: Impacto Económico Estimado e Análise | Economia](https://i.headtopics.com/images/2025/12/6/publico/greve-geral-o-que-e-quem-abrange-e-como-funciona-greve-geral-o-que-e-quem-abrange-e-como-funciona-43970BF408A401F542300934033BEA05.webp?w=640) <small>ph.headtopics.com</small>Greve Geral de 11 de Dezembro: Impacto Económico Estimado e Análise | Economia

Funcionários Públicos Angolanos Iniciam Hoje Greve Geral Com Manutenção De Serviços Mínimos
-------------------------------------------------------------------------------------------

 ![Funcionários públicos angolanos iniciam hoje greve geral com manutenção de serviços mínimos](https://angola24horas.com/media/k2/items/cache/42a873a737eaa0da6de41a41ecaa0f08_XL.jpg) <small>angola24horas.com</small>Funcionários públicos angolanos iniciam hoje greve geral com manutenção de serviços mínimos ...

Vila real: greve encerra escolas, fábricas e deixa hospital em "mínimos". Saiba quais são os serviços mínimos garantidos durante a greve geral. Profissionais de saúde moçambicanos em greve anunciam serviços mínimos – moz24h
