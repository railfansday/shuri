---
title: "Atum-24/6-0-stk - Термоусадочная трубка, raychem atum-24/6-0-stk, nb10132001 не распространяющая горение"
description: "atum-24/6-0-stk te connectivity"
date: "2026-04-22"
categories:
- "Uncategorized"
images:
- "https://ce8dc832c.cloudimg.io/v7/_cdn_/C8/C7/D0/00/0/883852_1.jpg?width=640&amp;height=480&amp;wat=1&amp;wat_url=_tme-wrk_%2Ftme_new.png&amp;wat_scale=100p&amp;ci_sign=110a38f48455cbc0e141d56f651fa796f65f9b30"
featuredImage: "https://s-motorsport.com/image/cache/catalog/Raychem/ATUM 4-1/TE-Raychem-ATUM 3-1-900x900.jpg"
featured_image: "https://www.ksvlooms.com/cdn/shop/files/1-raychem-atum-heat-shrink-adhesive-lined-tubing-148.webp?v=1756159523&amp;width=4096"
image: "https://www.mouser.hk/images/tycoelectronics/images/pratum.jpg"
---

If you are searching about ATUM-24/6-0-STK TE Connectivity | Raychem Products | ICC you've came to the right page. We have 35 Pics about ATUM-24/6-0-STK TE Connectivity | Raychem Products | ICC like ATUM-24/6-0-STK TE Connectivity Raychem Cable Protection | Cables, alambres - administración, ATUM-24/6-0-STK TE Connectivity | Raychem Products | Heilind and also ATUM-24/6-0-STK TE Connectivity - チップワンストップ. Here you go:

ATUM-24/6-0-STK TE Connectivity | Raychem Products | ICC
--------------------------------------------------------

 ![ATUM-24/6-0-STK TE Connectivity | Raychem Products | ICC](https://sku-product-images.s3.us-east-2.amazonaws.com/AMP/1-640526-0.jpg) <small>www.connecticc.com</small>ATUM-24/6-0-STK TE Connectivity | Raychem Products | ICC

1" Raychem ATUM Heat Shrink Adhesive Lined Tubing, 1ft Length (6" X 2) – KSV Looms
----------------------------------------------------------------------------------

 ![1" Raychem ATUM Heat Shrink Adhesive Lined Tubing, 1ft length (6" x 2) – KSV Looms](https://www.ksvlooms.com/cdn/shop/files/1-raychem-atum-heat-shrink-adhesive-lined-tubing-148.webp?v=1756159523&width=4096) <small>www.ksvlooms.com</small>1" Raychem ATUM Heat Shrink Adhesive Lined Tubing, 1ft length (6" x 2) – KSV Looms

Rurka Termokurczliwa Z Klejem 4:1, 24mm L1,2m • Cena, Opinie - Allegro
----------------------------------------------------------------------

 ![Rurka termokurczliwa z klejem 4:1, 24mm L1,2m • Cena, Opinie - Allegro](https://a.allegroimg.com/original/116dd2/480a5f5a439a84691b28d4c8c775/Rurka-termokurczliwa-z-klejem-4-1-24mm-L1-2m-ATUM-24-6-0-STK) <small>allegro.pl</small>Rurka termokurczliwa z klejem 4:1, 24mm L1,2m • Cena, Opinie - Allegro

ATUM-24/8-0-STK | Gaine Thermorétractable, Noir Polyoléfine Chemelex, , Rétreint 3:1 Diam. 24 Mm
------------------------------------------------------------------------------------------------

 ![ATUM-24/8-0-STK | Gaine thermorétractable, Noir Polyoléfine Chemelex, , Rétreint 3:1 Diam. 24 mm](https://media.rs-online.com/image/upload/bo_1.5px_solid_white,b_auto,c_pad,dpr_2,f_auto,h_399,q_auto,w_710/c_pad,h_399,w_710/Y0433212-01?pgw=1) <small>fr.rs-online.com</small>ATUM-24/8-0-STK | Gaine thermorétractable, Noir Polyoléfine Chemelex, , Rétreint 3:1 Diam. 24 mm ...

Термоусадочная трубка, Raychem ATUM-24/6-0-STK, NB10132001 не распространяющая горение
--------------------------------------------------------------------------------------

 ![Термоусадочная трубка, Raychem ATUM-24/6-0-STK, NB10132001 не распространяющая горение](https://s-motorsport.com/image/cache/catalog/Raychem/ATUM 4-1/Raychem-ATUM 4-1-900x900.jpg) <small>s-motorsport.com</small>Термоусадочная трубка, Raychem ATUM-24/6-0-STK, NB10132001 не распространяющая горение

ATUM-24/6-0-SP TE Connectivity / Raychem | Mouser 香港
----------------------------------------------------

 ![ATUM-24/6-0-SP TE Connectivity / Raychem | Mouser 香港](https://www.mouser.hk/images/tycoelectronics/images/pratum.jpg) <small>www.mouser.hk</small>ATUM-24/6-0-SP TE Connectivity / Raychem | Mouser 香港

ATUM-24/6-0-STK TE Connectivity - チップワンストップ
-------------------------------------------

 ![ATUM-24/6-0-STK TE Connectivity - チップワンストップ](https://static6.arrow.com/aropdfconversion/arrowimages/bd3676cd5e2d67ee42e25da9e8159cbe97f230d8/pratum.jpg) <small>www.chip1stop.com</small>ATUM-24/6-0-STK TE Connectivity - チップワンストップ

ATUM-24/6-0-STK TE Connectivity | Raychem Products | Heilind
------------------------------------------------------------

 ![ATUM-24/6-0-STK TE Connectivity | Raychem Products | Heilind](https://sku-product-images.s3.us-east-2.amazonaws.com/RYC/RYCNB14032001.jpg) <small>www.heilind.com</small>ATUM-24/6-0-STK TE Connectivity | Raychem Products | Heilind

Термоусадочная трубка, Raychem ATUM-24/6-0-STK, NB10132001 не распространяющая горение
--------------------------------------------------------------------------------------

 ![Термоусадочная трубка, Raychem ATUM-24/6-0-STK, NB10132001 не распространяющая горение](https://s-motorsport.com/image/cache/catalog/Raychem/ATUM 4-1/TE-Raychem-ATUM 3-1-900x900.jpg) <small>s-motorsport.com</small>Термоусадочная трубка, Raychem ATUM-24/6-0-STK, NB10132001 не распространяющая горение

ATUM-16-4-0-STK
---------------

 ![ATUM-16-4-0-STK](http://www.enwer.com/upfile/files/ATUM-16-4.jpg) <small>www.enwer.com</small>ATUM-16-4-0-STK

ATUM-24/6-0-SP TE Connectivity Raychem Cable Protection | Heat Shrink Tubing | DigiKey
--------------------------------------------------------------------------------------

 ![ATUM-24/6-0-SP TE Connectivity Raychem Cable Protection | Heat Shrink Tubing | DigiKey](https://mm.digikey.com/Volume0/opasdata/d220001/derivates/1/300/349/314/ATUM-24^6-0-STK_sml.jpg) <small>www.digikey.com</small>ATUM-24/6-0-SP TE Connectivity Raychem Cable Protection | Heat Shrink Tubing | DigiKey

ATUM-24/6-0-SP : RAYCHEM ATUM 4:1 Heat Shrink Tubing | TE Connectivity
----------------------------------------------------------------------

 ![ATUM-24/6-0-SP : RAYCHEM ATUM 4:1 Heat Shrink Tubing | TE Connectivity](https://www.te.com/content/dam/te-com/catalog/part/EM5/611/600/EM56116001-t1.jpg/jcr:content/renditions/product-small.png) <small>www.te.com</small>ATUM-24/6-0-SP : RAYCHEM ATUM 4:1 Heat Shrink Tubing | TE Connectivity

ATUM-24/6-0-STK TE Connectivity | Raychem Products | Heilind
------------------------------------------------------------

 ![ATUM-24/6-0-STK TE Connectivity | Raychem Products | Heilind](https://sku-product-images.s3.us-east-2.amazonaws.com/RST/RSTNB13462001.jpg) <small>www.heilind.com</small>ATUM-24/6-0-STK TE Connectivity | Raychem Products | Heilind

ATUM-24/6-0-STK TE Connectivity / Raychem | Mouser Polska
---------------------------------------------------------

 ![ATUM-24/6-0-STK TE Connectivity / Raychem | Mouser Polska](https://www.mouser.pl/images/tycoelectronics/images/NB09012001_SPL.jpg) <small>www.mouser.pl</small>ATUM-24/6-0-STK TE Connectivity / Raychem | Mouser Polska

ATUM-24/6-0-STK TE Connectivity | Raychem Products | Heilind
------------------------------------------------------------

 ![ATUM-24/6-0-STK TE Connectivity | Raychem Products | Heilind](https://sku-product-images.s3.us-east-2.amazonaws.com/AMP/AMP2822354-1.jpg) <small>www.heilind.com</small>ATUM-24/6-0-STK TE Connectivity | Raychem Products | Heilind

TE Connectivity ATUM-24/6-0-SP Heat Shrink Tubing 24MM 4:1 Black | Rapid Electronics
------------------------------------------------------------------------------------

 ![TE Connectivity ATUM-24/6-0-SP Heat Shrink Tubing 24MM 4:1 Black | Rapid Electronics](https://static.rapidonline.com/catalogueimages/product/15/74/s15-7443p01wl.jpg) <small>www.rapidonline.com</small>TE Connectivity ATUM-24/6-0-SP Heat Shrink Tubing 24MM 4:1 Black | Rapid Electronics

ATUM-24/6-0-STK TE Connectivity Raychem Cable Protection | Cables, Wires - Management | DigiKey
-----------------------------------------------------------------------------------------------

 ![ATUM-24/6-0-STK TE Connectivity Raychem Cable Protection | Cables, Wires - Management | DigiKey](https://mm.digikey.com/Volume0/opasdata/d220001/medias/images/630/ATUM-246-0-STK.jpg) <small>www.digikey.com</small>ATUM-24/6-0-STK TE Connectivity Raychem Cable Protection | Cables, Wires - Management | DigiKey

ATUM-24/6-0-STK | Chemelex 4:1 熱収縮チューブ, 24 Mmから 6 Mm, ポリオレフィン, 1.2m | RS
------------------------------------------------------------------------

 ![ATUM-24/6-0-STK | Chemelex 4:1 熱収縮チューブ, 24 mmから 6 mm, ポリオレフィン, 1.2m | RS](https://media.rs-online.com/image/upload/bo_1.5px_solid_white,b_auto,c_pad,dpr_2,f_auto,h_399,q_auto,w_710/c_pad,h_399,w_710/Y0433210-01?pgw=1) <small>jp.rs-online.com</small>ATUM-24/6-0-STK | Chemelex 4:1 熱収縮チューブ, 24 mmから 6 mm, ポリオレフィン, 1.2m | RS

ATUM-24/6-0-STK TE Connectivity Raychem Cable Protection | Cables, Alambres - Administración
--------------------------------------------------------------------------------------------

 ![ATUM-24/6-0-STK TE Connectivity Raychem Cable Protection | Cables, alambres - administración](https://media.digikey.com/pdf/Catalog Drawings/Heat Shrink/ATUM-246-0-STK.jpg) <small>www.digikey.com.mx</small>ATUM-24/6-0-STK TE Connectivity Raychem Cable Protection | Cables, alambres - administración ...

ATUM-24/6-0-STK TE Connectivity Raychem Cable Protection | Cables, Alambres - Administración
--------------------------------------------------------------------------------------------

 ![ATUM-24/6-0-STK TE Connectivity Raychem Cable Protection | Cables, alambres - administración](https://mm.digikey.com/Volume0/opasdata/d220001/derivates/2/030/255/123/MFG_P-20-018895(640x640).jpg) <small>www.digikey.com.mx</small>ATUM-24/6-0-STK TE Connectivity Raychem Cable Protection | Cables, alambres - administración ...

ATUM-24/6-0 TE Connectivity | Tubos Termorretráctiles TE Connectivity De Poliolefina Negro
------------------------------------------------------------------------------------------

 ![ATUM-24/6-0 TE Connectivity | Tubos termorretráctiles TE Connectivity de Poliolefina Negro](https://res.cloudinary.com/rsc/image/upload/b_rgb:FFFFFF,c_pad,dpr_1.0,f_auto,q_auto,w_700/c_pad,w_700/F3161669-02) <small>cl.rsdelivers.com</small>ATUM-24/6-0 TE Connectivity | Tubos termorretráctiles TE Connectivity de Poliolefina Negro ...

レイケム ATUM-24/ 6-0-STK（カット品1.2m） 黒色 接着層付き 防水熱収縮チューブ 24.0→6.0mm : FA-Ubon Yahoo!店 - 通販 - Yahoo!ショッピング
---------------------------------------------------------------------------------------------------

 ![レイケム ATUM-24/ 6-0-STK（カット品1.2m） 黒色 接着層付き 防水熱収縮チューブ 24.0→6.0mm : FA-Ubon Yahoo!店 - 通販 - Yahoo!ショッピング](https://item-shopping.c.yimg.jp/i/n/faubon_0880621) <small>store.shopping.yahoo.co.jp</small>レイケム ATUM-24/ 6-0-STK（カット品1.2m） 黒色 接着層付き 防水熱収縮チューブ 24.0→6.0mm : FA-Ubon Yahoo!店 - 通販 - Yahoo!ショッピング

ATUM-24/6-0-SP TE Connectivity Raychem Cable Protection | Heat Shrink Tubing | DigiKey
--------------------------------------------------------------------------------------

 ![ATUM-24/6-0-SP TE Connectivity Raychem Cable Protection | Heat Shrink Tubing | DigiKey](https://mm.digikey.com/Volume0/opasdata/d220001/derivates/3/003/226/041/MFG_ATUM-XX-X-0-SP_tmb(64x64).jpg) <small>www.digikey.com</small>ATUM-24/6-0-SP TE Connectivity Raychem Cable Protection | Heat Shrink Tubing | DigiKey

ATUM-24/6-0-STK TE Connectivity Raychem Cable Protection | Cables, Wires - Management | DigiKey
-----------------------------------------------------------------------------------------------

 ![ATUM-24/6-0-STK TE Connectivity Raychem Cable Protection | Cables, Wires - Management | DigiKey](https://media.digikey.com/Photos/TE Connectivity/ATUM-24^6-0-STK.jpg) <small>www.digikey.my</small>ATUM-24/6-0-STK TE Connectivity Raychem Cable Protection | Cables, Wires - Management | DigiKey

TE Connectivity ATUM-24/6-0-STK Tubing, Adhesive Wall, 4:1 Shrink Ratio; 4ft Lenghts;Black;
-------------------------------------------------------------------------------------------

 ![TE Connectivity ATUM-24/6-0-STK Tubing, adhesive wall, 4:1 shrink ratio; 4ft lenghts;Black;](https://assets.rs-online.com/image/upload/v1525227526/70101199.jpg) <small>us.rs-online.com</small>TE Connectivity ATUM-24/6-0-STK Tubing, adhesive wall, 4:1 shrink ratio; 4ft lenghts;Black;

ATUM-24/6-0-STK TE Connectivity - Heat Shrink Sleeve | Glued; 4: 1; 24mm; L: 1.2m; Black
----------------------------------------------------------------------------------------

 ![ATUM-24/6-0-STK TE Connectivity - Heat shrink sleeve | glued; 4: 1; 24mm; L: 1.2m; black](https://ce8dc832c.cloudimg.io/v7/_cdn_/C8/C7/D0/00/0/883852_1.jpg?width=640&height=480&wat=1&wat_url=_tme-wrk_%2Ftme_new.png&wat_scale=100p&ci_sign=110a38f48455cbc0e141d56f651fa796f65f9b30) <small>www.tme.eu</small>ATUM-24/6-0-STK TE Connectivity - Heat shrink sleeve | glued; 4: 1; 24mm; L: 1.2m; black ...

ATUM-24/8-0-STK | TE Connectivity Adhesive Lined Heat Shrink Tubing, Black 24mm Sleeve Dia. X 1
-----------------------------------------------------------------------------------------------

 ![ATUM-24/8-0-STK | TE Connectivity Adhesive Lined Heat Shrink Tubing, Black 24mm Sleeve Dia. x 1](https://media.rs-online.com/image/upload/bo_1.5px_solid_white,b_auto,c_pad,dpr_2,f_auto,h_399,q_auto,w_710/c_pad,h_399,w_710/R7822078-01?pgw=1) <small>uk.rs-online.com</small>ATUM-24/8-0-STK | TE Connectivity Adhesive Lined Heat Shrink Tubing, Black 24mm Sleeve Dia. x 1 ...

ATUM-24/6-0-STK TE Connectivity | Raychem Products | Heilind
------------------------------------------------------------

 ![ATUM-24/6-0-STK TE Connectivity | Raychem Products | Heilind](https://sku-product-images.s3.us-east-2.amazonaws.com/AMP/AMP1-1123722-6.jpg) <small>www.heilind.com</small>ATUM-24/6-0-STK TE Connectivity | Raychem Products | Heilind

TE Connectivity - ATUM-24/6-2-RSU-STK - Raychem, Red Adhesive Lined Tubing,24-6mm I/d - RS
------------------------------------------------------------------------------------------

 ![TE Connectivity - ATUM-24/6-2-RSU-STK - Raychem, Red adhesive lined tubing,24-6mm i/d - RS](https://assets.rs-online.com/f_auto,q_auto,c_scale,w_400/70294870.jpg) <small>us.rs-online.com</small>TE Connectivity - ATUM-24/6-2-RSU-STK - Raychem, Red adhesive lined tubing,24-6mm i/d - RS

ATUM-24/6-0 | TE Connectivity Adhesive Lined Heat Shrink Tubing, Black 24mm Sleeve Dia. X 1.2m
----------------------------------------------------------------------------------------------

 ![ATUM-24/6-0 | TE Connectivity Adhesive Lined Heat Shrink Tubing, Black 24mm Sleeve Dia. x 1.2m](https://res.cloudinary.com/rsc/image/upload/bo_1.5px_solid_white,b_auto,c_pad,dpr_2,f_auto,h_399,q_auto,w_710/c_pad,h_399,w_710/F3161669-01?pgw=1) <small>uk.rs-online.com</small>ATUM-24/6-0 | TE Connectivity Adhesive Lined Heat Shrink Tubing, Black 24mm Sleeve Dia. x 1.2m ...

AAP | ATUM Adhesive-Lined Polyolefin Tubing | 4:1, 24/6, Black
--------------------------------------------------------------

 ![AAP | ATUM Adhesive-Lined Polyolefin Tubing | 4:1, 24/6, Black](https://www.americanaviationparts.com/image/cache/catalog/products/main/476/NB10132001-900x900.jpg) <small>www.americanaviationparts.com</small>AAP | ATUM Adhesive-Lined Polyolefin Tubing | 4:1, 24/6, Black

ATUM-24/8-0-STK : RAYCHEM ATUM 3:1 Heat Shrink Tubing | TE Connectivity
-----------------------------------------------------------------------

 ![ATUM-24/8-0-STK : RAYCHEM ATUM 3:1 Heat Shrink Tubing | TE Connectivity](https://www.te.com/content/dam/te-com/catalog/part/EM5/611/600/EM56116001-t1.jpg/jcr:content/renditions/product-high-res.png) <small>www.te.com</small>ATUM-24/8-0-STK : RAYCHEM ATUM 3:1 Heat Shrink Tubing | TE Connectivity

ATUM-24/8-0-MS-STK TE CONNECTIVITY - RAYCHEM, Adhesive Lined Heat Shrink Tubing, 3:1, 0.94
------------------------------------------------------------------------------------------

 ![ATUM-24/8-0-MS-STK TE CONNECTIVITY - RAYCHEM, Adhesive Lined Heat Shrink Tubing, 3:1, 0.94](https://www.newark.com/productimages/standard/en_US/4308689.jpg) <small>www.newark.com</small>ATUM-24/8-0-MS-STK TE CONNECTIVITY - RAYCHEM, Adhesive Lined Heat Shrink Tubing, 3:1, 0.94 ...

ATUM-24/6-0-STK TE Connectivity | Raychem Products | Heilind
------------------------------------------------------------

 ![ATUM-24/6-0-STK TE Connectivity | Raychem Products | Heilind](https://sku-product-images.s3.us-east-2.amazonaws.com/AMP/170366-1.png) <small>www.heilind.com</small>ATUM-24/6-0-STK TE Connectivity | Raychem Products | Heilind

Термоусадочная трубка, Raychem ATUM-24/6-0-STK, NB10132001 не распространяющая горение
--------------------------------------------------------------------------------------

 ![Термоусадочная трубка, Raychem ATUM-24/6-0-STK, NB10132001 не распространяющая горение](https://s-motorsport.com/image/cache/catalog/Raychem/ATUM 4-1/ATUM-24 6-0-STK Raychem NB10132001-2000x2000.jpg) <small>s-motorsport.com</small>Термоусадочная трубка, Raychem ATUM-24/6-0-STK, NB10132001 не распространяющая горение

atum-24/6-0-sp te connectivity raychem cable protection. Atum-24/8-0-stk. Te connectivity atum-24/6-0-stk tubing, adhesive wall, 4:1 shrink ratio; 4ft lenghts;black;
