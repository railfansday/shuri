---
title: "Vitinha Height And Weight - The 30 world-class players in 2025"
description: "Mercato psg : le real madrid prépare une première offre xxl pour vitinha"
date: "2026-07-10"
categories:
- "Uncategorized"
images:
- "https://healthyceleb.com/wp-content/uploads/2023/09/Vitinha-as-seen-in-a-picture-that-was-taken-in-September-2023-at-Parc-Des-Princes.jpg"
featuredImage: "http://media.culturepsg.com/image/news/vitinha_dos_210528_psg_barca_uefa_10042024.jpg"
featured_image: "https://pictures.tribuna.com/image/65e3d933-4131-4c8c-9010-85aabeb685d5?width=1920&amp;quality=70"
image: "https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA1SwuD0.img?w=1500&amp;h=1000&amp;m=4&amp;q=100"
---

If you are searching about Vitinha EA SPORTS FC™ 25 Player Ratings you've visit to the right place. We have 35 Pics about Vitinha EA SPORTS FC™ 25 Player Ratings like Vitinha’s Real Height Revealed, Why His Size Doesn’t Match His Skillset - FEAST Online Magazine, PSG : Vitinha au Real Madrid, la majorité a parlé and also Vitinha of Paris Saint-Germain - Paris Saint-Germain training ahead of their UEFA Champions. Here it is:

Vitinha EA SPORTS FC™ 25 Player Ratings
---------------------------------------

 ![Vitinha EA SPORTS FC™ 25 Player Ratings](https://ratings-images-prod.pulse.ea.com/FC25/full/player-shields/en/255253.png?width=265) <small>www.ea.com</small>Vitinha EA SPORTS FC™ 25 Player Ratings

Portugal's Vitinha During A Quarterfinal Match Between Portugal And France At The Euro 2024
-------------------------------------------------------------------------------------------

 ![Portugal's Vitinha during a quarterfinal match between Portugal and France at the Euro 2024](https://c8.alamy.com/comp/2XGCM7M/portugals-vitinha-during-a-quarterfinal-match-between-portugal-and-france-at-the-euro-2024-soccer-tournament-in-hamburg-germany-friday-saturday-july-6-2024-sport-soccer-photo-by-fabio-ferrarilapresse-2XGCM7M.jpg) <small>www.alamy.com</small>Portugal's Vitinha during a quarterfinal match between Portugal and France at the Euro 2024 ...

Vitinha 💫 In 2024 | Soccer Pictures, Soccer Players, Psg
--------------------------------------------------------

 ![Vitinha 💫 in 2024 | Soccer pictures, Soccer players, Psg](https://i.pinimg.com/736x/81/a3/5b/81a35bf9c18f9efa716d3df6b28e89f2.jpg) <small>www.pinterest.com</small>Vitinha 💫 in 2024 | Soccer pictures, Soccer players, Psg

PSG : Vitinha Au Real Madrid, La Majorité A Parlé
-------------------------------------------------

 ![PSG : Vitinha au Real Madrid, la majorité a parlé](https://r.testifier.nl/Acbs8526SDKI/resizing_type:fit/width:3840/height:2560/plain/https://s3-newsifier.ams3.digitaloceanspaces.com/foot01.com/images/2025-12/vitinha-psg-693b2ba510ad8.jpg@webp) <small>www.foot01.com</small>PSG : Vitinha au Real Madrid, la majorité a parlé

Vitinha - Wikipedia
-------------------

 ![Vitinha - Wikipedia](https://upload.wikimedia.org/wikipedia/commons/5/57/Vitinha%2C_Euro2024_%28Agência_Lusa%29.png) <small>en.wikipedia.org</small>Vitinha - Wikipedia

Is Vitinha PSG’s Best Player? - The Athletic
--------------------------------------------

 ![Is Vitinha PSG’s best player? - The Athletic](https://static01.nyt.com/athletic/uploads/wp/2025/04/09083552/Vitinha-1024x683.jpg?width=1920&quality=70&auto=webp) <small>www.nytimes.com</small>Is Vitinha PSG’s best player? - The Athletic

Vitinha Is A Crucial Element In Luis Enrique's Setup Amid Champions League Match Against
----------------------------------------------------------------------------------------

 ![Vitinha is a crucial element in Luis Enrique's setup amid Champions League match against](https://s2.dmcdn.net/v/W3HHU1c2oEIA-id-h/x1080) <small>www.beinsports.com</small>Vitinha is a crucial element in Luis Enrique's setup amid Champions League match against ...

Vitinha Height Revealed—Is PSG’s Midfield Star Really That Short?
-----------------------------------------------------------------

 ![Vitinha Height Revealed—Is PSG’s Midfield Star Really That Short?](https://wealthfuture.co.uk/wp-content/uploads/2025/06/Vitinha-Height.jpg) <small>wealthfuture.co.uk</small>Vitinha Height Revealed—Is PSG’s Midfield Star Really That Short?

Vitinha, Un Deseado Fichaje De 90 M€
------------------------------------

 ![Vitinha, un deseado fichaje de 90 M€](https://assets-es.imgfoot.com/media/cache/1200x675/vitinha-psg-2025.jpg) <small>www.fichajes.com</small>Vitinha, un deseado fichaje de 90 M€

Vitinha - TheSportsDB.com
-------------------------

 ![Vitinha - TheSportsDB.com](https://r2.thesportsdb.com/images/media/player/render/ygre3m1735980014.png) <small>www.thesportsdb.com</small>Vitinha - TheSportsDB.com

Vitinha Of Paris Saint-Germain - Paris Saint-Germain Training Ahead Of Their UEFA Champions
-------------------------------------------------------------------------------------------

 ![Vitinha of Paris Saint-Germain - Paris Saint-Germain training ahead of their UEFA Champions](https://c8.alamy.com/comp/2T2RDR3/vitinha-of-paris-saint-germain-paris-saint-germain-training-ahead-of-their-uefa-champions-league-match-v-newcastle-united-st-james-park-newcastle-upon-tyne-uk-3rd-october-2023-2T2RDR3.jpg) <small>www.alamy.com</small>Vitinha of Paris Saint-Germain - Paris Saint-Germain training ahead of their UEFA Champions ...

PSG Vs Flamengo – Vitinha Weighs The Weight Of A Unique Trophy
--------------------------------------------------------------

 ![PSG vs Flamengo – Vitinha weighs the weight of a unique trophy](https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA1SwuD0.img?w=1500&h=1000&m=4&q=100) <small>www.msn.com</small>PSG vs Flamengo – Vitinha weighs the weight of a unique trophy

FlashFocus: Vitinha - The Little Maestro Who Points The Way To Success | Flashscore.co.za
-----------------------------------------------------------------------------------------

 ![FlashFocus: Vitinha - the little maestro who points the way to success | Flashscore.co.za](https://livesport-ott-images.ssl.cdn.cra.cz/r900xfq60/28afc582-452c-408f-9909-ecbd5e812982.jpg) <small>www.flashscore.co.za</small>FlashFocus: Vitinha - the little maestro who points the way to success | Flashscore.co.za

PSG : Vitinha Souffre D'une Inflammation Du Talon Droit
-------------------------------------------------------

 ![PSG : Vitinha souffre d'une inflammation du talon droit](https://r.testifier.nl/Acbs8526SDKI/resizing_type:fit/width:3840/height:2560/plain/https://s3-newsifier.ams3.digitaloceanspaces.com/foot01.com/images/2026-04/iconsport-363515-0147-69d37d5a44f45.jpg@webp) <small>www.foot01.com</small>PSG : Vitinha souffre d'une inflammation du talon droit

Vitinha Psg Pes 2021 Vitinha Face (psg) - Hikaru Amerigo
--------------------------------------------------------

 ![vitinha psg Pes 2021 vitinha face (psg) - Hikaru Amerigo](https://img.playerswiki.com/uploads/2022/09/18/vitinha-on-psgs-outfit-1663514680.jpg) <small>hikaruamerigo.blogspot.com</small>vitinha psg Pes 2021 vitinha face (psg) - Hikaru Amerigo

Vitinha Height, Weight, Age, Girlfriend, Family
-----------------------------------------------

 ![Vitinha Height, Weight, Age, Girlfriend, Family](https://healthyceleb.com/wp-content/uploads/2023/09/Vitinha-as-seen-in-a-picture-that-was-taken-in-November-2022.jpg) <small>healthyceleb.com</small>Vitinha Height, Weight, Age, Girlfriend, Family

PSG - Vitinha élu Personnalité De L'année 2025 Au Portugal
----------------------------------------------------------

 ![PSG - Vitinha élu personnalité de l'année 2025 au Portugal](https://photos.madeinparisiens.com/ligue-des-champions/2025/zoom/ldc-20251127082832-7302.jpg) <small>madeinparisiens.ouest-france.fr</small>PSG - Vitinha élu personnalité de l'année 2025 au Portugal

The 30 World-Class Players In 2025 - Lentedesportiva
----------------------------------------------------

 ![The 30 World-Class players in 2025 - Lentedesportiva](https://lentedesportiva.com/wp-content/uploads/2025/02/shutterstock_2394529789.jpg) <small>lentedesportiva.com</small>The 30 World-Class players in 2025 - Lentedesportiva

Vitinha Height, Weight, Age, Girlfriend, Family
-----------------------------------------------

 ![Vitinha Height, Weight, Age, Girlfriend, Family](https://healthyceleb.com/wp-content/uploads/2023/09/Vitinha-as-seen-in-a-picture-that-was-taken-in-September-2023-at-Parc-Des-Princes.jpg) <small>healthyceleb.com</small>Vitinha Height, Weight, Age, Girlfriend, Family

Vitinha: PSG| Height| Stats| Messi| How Tall Is| Age| Real Madrid - Sportsjone
------------------------------------------------------------------------------

 ![Vitinha: PSG| Height| Stats| Messi| How tall is| Age| Real madrid - sportsjone](https://sportsjone.com/wp-content/uploads/2026/05/images-2026-05-31T140851.587.jpeg) <small>sportsjone.com</small>Vitinha: PSG| Height| Stats| Messi| How tall is| Age| Real madrid - sportsjone

FlashFocus: Vitinha - The Little Maestro Who Points The Way To Success | Flashscore.com
---------------------------------------------------------------------------------------

 ![FlashFocus: Vitinha - the little maestro who points the way to success | Flashscore.com](https://livesport-ott-images.ssl.cdn.cra.cz/r900xfq60/8ad36d59-436f-4cef-a9bd-356f9fd7f451.jpeg) <small>www.flashscore.com</small>FlashFocus: Vitinha - the little maestro who points the way to success | Flashscore.com

Vitinha Biography, Age, Height, PSG Career, Stats &amp; Net Worth
-----------------------------------------------------------------

 ![Vitinha Biography, Age, Height, PSG Career, Stats & Net Worth](https://playersbiography.com/wp-content/uploads/2026/06/Vitinha.png) <small>playersbiography.com</small>Vitinha Biography, Age, Height, PSG Career, Stats &amp; Net Worth

Vitinha Player Stats - Sportsmen Height
---------------------------------------

 ![Vitinha Player Stats - Sportsmen Height](https://sportsmanheight.com/wp-content/uploads/2022/11/5-12.png) <small>sportsmanheight.com</small>Vitinha Player Stats - Sportsmen Height

Vitinha Height, Weight, Age, Girlfriend, Family
-----------------------------------------------

 ![Vitinha Height, Weight, Age, Girlfriend, Family](https://healthyceleb.com/wp-content/uploads/2023/09/Vitinha.jpg) <small>healthyceleb.com</small>Vitinha Height, Weight, Age, Girlfriend, Family

Vitinha – Wikipedija
--------------------

 ![Vitinha – Wikipedija](https://upload.wikimedia.org/wikipedia/commons/thumb/4/44/Vitinha_USMNT_v_Portugal_Mar_31_2026-50_(cropped).jpg/960px-Vitinha_USMNT_v_Portugal_Mar_31_2026-50_(cropped).jpg) <small>hr.wikipedia.org</small>Vitinha – Wikipedija

Mercato PSG : Le Real Madrid Prépare Une Première Offre XXL Pour Vitinha | Goal.com Français
--------------------------------------------------------------------------------------------

 ![Mercato PSG : le Real Madrid prépare une première offre XXL pour Vitinha | Goal.com Français](https://assets.goal.com/images/v3/blt4840a76194cf2250/Vitinha.jpeg?auto=webp&format=pjpg&width=3840&quality=60) <small>www.goal.com</small>Mercato PSG : le Real Madrid prépare une première offre XXL pour Vitinha | Goal.com Français

DOHA - Vitinha Of Portugal During The FIFA World Cup Qatar 2022 Group H Match Between South
-------------------------------------------------------------------------------------------

 ![DOHA - Vitinha of Portugal during the FIFA World Cup Qatar 2022 group H match between South](https://c8.alamy.com/comp/2NHFKYJ/doha-vitinha-of-portugal-during-the-fifa-world-cup-qatar-2022-group-h-match-between-south-korea-and-portugal-at-education-city-stadium-on-december-2-2022-in-doha-qatar-ap-dutch-height-maurice-of-stone-2NHFKYJ.jpg) <small>www.alamy.com</small>DOHA - Vitinha of Portugal during the FIFA World Cup Qatar 2022 group H match between South ...

Vitinha’s Real Height Revealed, Why His Size Doesn’t Match His Skillset - FEAST Online Magazine
-----------------------------------------------------------------------------------------------

 ![Vitinha’s Real Height Revealed, Why His Size Doesn’t Match His Skillset - FEAST Online Magazine](https://www.feastmagazine.org/wp-content/uploads/2025/06/vitinha-height.jpg) <small>www.feastmagazine.org</small>Vitinha’s Real Height Revealed, Why His Size Doesn’t Match His Skillset - FEAST Online Magazine ...

Vitinha Est T-il Devenu Un Joueur De Classe Mondiale Après Sa Saison Avec Le PSG Et Ses
---------------------------------------------------------------------------------------

 ![Vitinha est t-il devenu un joueur de classe mondiale après sa saison avec le PSG et ses](https://pictures.tribuna.com/image/65e3d933-4131-4c8c-9010-85aabeb685d5?width=1920&quality=70) <small>tribuna.com</small>Vitinha est t-il devenu un joueur de classe mondiale après sa saison avec le PSG et ses ...

PSG : Vitinha, Une Saison Stratosphérique
-----------------------------------------

 ![PSG : Vitinha, une saison stratosphérique](https://www.planetepsg.com/divers/vitinha_une_saison_stratospherique_iconsport_0727111047.webp) <small>www.planetepsg.com</small>PSG : Vitinha, une saison stratosphérique

Sélections : Vitinha Brillant Et Taille Patron Avec Le Portugal | CulturePSG
----------------------------------------------------------------------------

 ![Sélections : Vitinha brillant et taille patron avec le Portugal | CulturePSG](http://media.culturepsg.com/image/news/vitinha_dos_210528_psg_barca_uefa_10042024.jpg) <small>www.culturepsg.com</small>Sélections : Vitinha brillant et taille patron avec le Portugal | CulturePSG

PSG's Vitinha Claims Third Spot In Ballon D'Or Vote
---------------------------------------------------

 ![PSG's Vitinha claims third spot in Ballon d'Or vote](https://cdn.resfu.com/media/img_news/vitinha--concentrado-en-el-psg-angers-de-ligue-1-2024-25--efe-yoan-valat.jpg) <small>www.besoccer.com</small>PSG's Vitinha claims third spot in Ballon d'Or vote

Vitinha Of Paris Saint-Germain Poses For A Portrait During The UEFA... News Photo - Getty Images
------------------------------------------------------------------------------------------------

 ![Vitinha of Paris Saint-Germain poses for a portrait during the UEFA... News Photo - Getty Images](https://media.gettyimages.com/id/2170994293/photo/paris-saint-germain-portraits-uefa-champions-league-2024-25.jpg?s=594x594&w=gi&k=20&c=ELZ-VqM8uWXUqpDLiDrPSaKgSaZmDxJekSppii-Demg=) <small>www.gettyimages.in</small>Vitinha of Paris Saint-Germain poses for a portrait during the UEFA... News Photo - Getty Images

Vitinha | Paris SG
------------------

 ![Vitinha | Paris SG](https://www.footballdatabase.eu/images/photos/players/2021-2022/a_335/335640.jpg) <small>www.footballdatabase.eu</small>Vitinha | Paris SG

Real Madrid Interest In PSG Star Confirmed As Transfer Looks Impossible
-----------------------------------------------------------------------

 ![Real Madrid Interest in PSG Star Confirmed as Transfer Looks Impossible](https://icdn.psgtalk.com/wp-content/uploads/2025/04/vitinha-psg-v-arsenal-ucl-2025.jpg) <small>psgtalk.com</small>Real Madrid Interest in PSG Star Confirmed as Transfer Looks Impossible

Psg's vitinha claims third spot in ballon d'or vote. Mercato psg : le real madrid prépare une première offre xxl pour vitinha. Sélections : vitinha brillant et taille patron avec le portugal
