---
title: "Cantor Colburn - David hudyma: cantor colburn"
description: "Tong kim, ph.d.: cantor colburn"
date: "2026-04-14"
categories:
- "Uncategorized"
images:
- "https://pbs.twimg.com/media/E2zidnVWQAMcA1l.jpg"
featuredImage: "https://www.cantorcolburn.com/assets/images/713.jpeg"
featured_image: "https://www.cantorcolburn.com/assets/images/743.png"
image: "https://ipwatchdog.com/wp-content/uploads/2026/01/CantorColburn-FeaturedImage-PR-01202026.jpg"
---

If you are searching about #teamcantorcolburn | Cantor Colburn LLP you've visit to the right place. We have 35 Pics about #teamcantorcolburn | Cantor Colburn LLP like Cantor Colburn Continues Growth, Adding Experienced Patent Attorneys and Agent in Chemistry, Cantor Colburn Adds 11 New Attorneys and Patent Agents to Strengthen Intellectual Property and also Ko Nakamura Serves as Judge at UNC Charlotte’s 2026 Invention of the Year Awards: Cantor Colburn. Here it is:

\#teamcantorcolburn | Cantor Colburn LLP
----------------------------------------

 ![#teamcantorcolburn | Cantor Colburn LLP](https://media.licdn.com/dms/image/v2/D4E22AQGonvJY_nwUBg/feedshare-shrink_1280/B4EZu80_1gHkAs-/0/1768399568874?e=2147483647&v=beta&t=ck_lJNw50UW24VQaG9ygHfPWup8BRXIKq6F5LQw0lMk) <small>www.linkedin.com</small>\#teamcantorcolburn | Cantor Colburn LLP

Cantor Colburn Announces The Election Of M. Brad Lawrence As Managing Partner - IPWatchdog.com
----------------------------------------------------------------------------------------------

 ![Cantor Colburn Announces the Election of M. Brad Lawrence as Managing Partner - IPWatchdog.com](https://ipwatchdog.com/wp-content/uploads/2026/01/CantorColburn-FeaturedImage-PR-01202026.jpg) <small>ipwatchdog.com</small>Cantor Colburn Announces the Election of M. Brad Lawrence as Managing Partner - IPWatchdog.com ...

Cantor Colburn Continues Growth, Adding Experienced Patent Attorneys And Agent In Chemistry
-------------------------------------------------------------------------------------------

 ![Cantor Colburn Continues Growth, Adding Experienced Patent Attorneys and Agent in Chemistry](https://ipwatchdog.com/wp-content/uploads/2023/04/Cantor-Colburn-LLP-logo.jpeg) <small>ipwatchdog.com</small>Cantor Colburn Continues Growth, Adding Experienced Patent Attorneys and Agent in Chemistry ...

Cantor Colburn Sponsors 2018 UConn Patent: Cantor Colburn
---------------------------------------------------------

 ![Cantor Colburn Sponsors 2018 UConn Patent: Cantor Colburn](https://www.cantorcolburn.com/assets/htmlimages/Cantor_Michael_bio.jpg) <small>www.cantorcolburn.com</small>Cantor Colburn Sponsors 2018 UConn Patent: Cantor Colburn

Cantor Colburn LLP (@CantorColburn) / Posts / X
-----------------------------------------------

 ![Cantor Colburn LLP (@CantorColburn) / Posts / X](https://pbs.twimg.com/media/E2zidnVWQAMcA1l.jpg) <small>x.com</small>Cantor Colburn LLP (@CantorColburn) / Posts / X

Cantor Colburn LLP On LinkedIn: #teamcantorcolburn #intellectualproperty #patentlaw #patents #
----------------------------------------------------------------------------------------------

 ![Cantor Colburn LLP on LinkedIn: #teamcantorcolburn #intellectualproperty #patentlaw #patents #](https://media.licdn.com/dms/image/v2/D4E22AQH1dvL25ni9ZQ/feedshare-shrink_2048_1536/feedshare-shrink_2048_1536/0/1679945637391?e=2147483647&v=beta&t=9csFDINX2gu-zjiAzBHHzLT5rSkqRcIN5p2lxITQboY) <small>www.linkedin.com</small>Cantor Colburn LLP on LinkedIn: #teamcantorcolburn #intellectualproperty #patentlaw #patents # ...

IP Stars 2025: Cantor Colburn
-----------------------------

 ![IP Stars 2025: Cantor Colburn](https://www.cantorcolburn.com/assets/htmlimages/IP Stars 2025 LinkedIn.png) <small>www.cantorcolburn.com</small>IP Stars 2025: Cantor Colburn

Karl Vick At ACPC Summer Meeting June 2023: Cantor Colburn
----------------------------------------------------------

 ![Karl Vick at ACPC Summer Meeting June 2023: Cantor Colburn](https://www.cantorcolburn.com/assets/htmlimages/Vick_Karl_high.jpg) <small>www.cantorcolburn.com</small>Karl Vick at ACPC Summer Meeting June 2023: Cantor Colburn

Cantor Colburn LLP (@CantorColburn) / Posts / X
-----------------------------------------------

 ![Cantor Colburn LLP (@CantorColburn) / Posts / X](https://pbs.twimg.com/media/FGB0WJxXwAEhVwh.jpg) <small>x.com</small>Cantor Colburn LLP (@CantorColburn) / Posts / X

LeRoy Ashley III: Cantor Colburn
--------------------------------

 ![LeRoy Ashley III: Cantor Colburn](https://www.cantorcolburn.com/assets/images/727.jpeg) <small>www.cantorcolburn.com</small>LeRoy Ashley III: Cantor Colburn

Cantor Colburn LLP On LinkedIn: Cantor Colburn Recognized In “Best Law Firms” By U.S. News
------------------------------------------------------------------------------------------

 ![Cantor Colburn LLP on LinkedIn: Cantor Colburn Recognized in “Best Law Firms” by U.S. News](https://media.licdn.com/dms/image/v2/C5634AQELQXPXnhVHzw/ugc-proxy-shrink_800/ugc-proxy-shrink_800/0/1598486102085?e=2147483647&v=beta&t=3ZS2FApNHMCruwXgiKGCIw-H-67BsUCJt1dj8s7IBCs) <small>www.linkedin.com</small>Cantor Colburn LLP on LinkedIn: Cantor Colburn Recognized in “Best Law Firms” by U.S. News ...

Yong Tang, Ph.D.: Cantor Colburn
--------------------------------

 ![Yong Tang, Ph.D.: Cantor Colburn](https://www.cantorcolburn.com/assets/images/676.png) <small>www.cantorcolburn.com</small>Yong Tang, Ph.D.: Cantor Colburn

Cantor Colburn LLP On LinkedIn: #intellectualproperty #michigan #mackinac #icle
-------------------------------------------------------------------------------

 ![Cantor Colburn LLP on LinkedIn: #intellectualproperty #michigan #mackinac #icle](https://media.licdn.com/dms/image/C4D22AQHxVIcFfGwmpg/feedshare-shrink_2048_1536/0/1658243202529?e=2147483647&v=beta&t=AthQoXu9FWN1pzfVEWVQ_l_X0ejWh4l9pkFCo_Wux8w) <small>www.linkedin.com</small>Cantor Colburn LLP on LinkedIn: #intellectualproperty #michigan #mackinac #icle

\#teamcantorcolburn #intellectualproperty #judgesdinner2023 #judgesdinner | Cantor Colburn LLP
----------------------------------------------------------------------------------------------

 ![#teamcantorcolburn #intellectualproperty #judgesdinner2023 #judgesdinner | Cantor Colburn LLP](https://media.licdn.com/dms/image/v2/D4E22AQGae5Agrx9JZw/feedshare-shrink_2048_1536/feedshare-shrink_2048_1536/0/1680554514536?e=2147483647&v=beta&t=JL8G_N2hV3-kKOykHPmIb3vGgySw6YJl_xLMFZf4IyI) <small>www.linkedin.com</small>\#teamcantorcolburn #intellectualproperty #judgesdinner2023 #judgesdinner | Cantor Colburn LLP

Ruslan Arbit: Cantor Colburn
----------------------------

 ![Ruslan Arbit: Cantor Colburn](https://www.cantorcolburn.com/assets/images/713.jpeg) <small>www.cantorcolburn.com</small>Ruslan Arbit: Cantor Colburn

Cantor Colburn LLP On LinkedIn: #tradesecrets #ai #artificialintelligence #intellectualproperty
-----------------------------------------------------------------------------------------------

 ![Cantor Colburn LLP on LinkedIn: #tradesecrets #ai #artificialintelligence #intellectualproperty](https://media.licdn.com/dms/image/v2/D4D22AQG6wziQ_0uYYQ/feedshare-shrink_800/feedshare-shrink_800/0/1733524880005?e=2147483647&v=beta&t=bgOCZ4y5fuaX8QioJ5bMRC4K_baCnD8e6SGL1UwEG8Y) <small>www.linkedin.com</small>Cantor Colburn LLP on LinkedIn: #tradesecrets #ai #artificialintelligence #intellectualproperty

The 2026 Invention Convention Florida: Cantor Colburn
-----------------------------------------------------

 ![The 2026 Invention Convention Florida: Cantor Colburn](https://www.cantorcolburn.com/assets/htmlimages/Kincaid_David_high.jpg) <small>www.cantorcolburn.com</small>The 2026 Invention Convention Florida: Cantor Colburn

Cantor Colburn LLP On LinkedIn: #teamcantorcolburn #intellectualproperty #patents #trademarks
---------------------------------------------------------------------------------------------

 ![Cantor Colburn LLP on LinkedIn: #teamcantorcolburn #intellectualproperty #patents #trademarks](https://media.licdn.com/dms/image/D4E22AQFWVlMNg8Uh7w/feedshare-shrink_2048_1536/0/1704396519970?e=2147483647&v=beta&t=wHetKe76n3uMJR3MQUnU_Wq2XwnhJjlNZyNBjvdnMhY) <small>www.linkedin.com</small>Cantor Colburn LLP on LinkedIn: #teamcantorcolburn #intellectualproperty #patents #trademarks ...

Ko Nakamura Serves As Judge At UNC Charlotte’s 2026 Invention Of The Year Awards: Cantor Colburn
------------------------------------------------------------------------------------------------

 ![Ko Nakamura Serves as Judge at UNC Charlotte’s 2026 Invention of the Year Awards: Cantor Colburn](https://www.cantorcolburn.com/assets/htmlimages/26 4 24 Inventor of the Year 2026 Judges.png) <small>www.cantorcolburn.com</small>Ko Nakamura Serves as Judge at UNC Charlotte’s 2026 Invention of the Year Awards: Cantor Colburn

Creativity And The Law With The Greater Hartford Arts Council: Cantor Colburn
-----------------------------------------------------------------------------

 ![Creativity and the Law with the Greater Hartford Arts Council: Cantor Colburn](https://www.cantorcolburn.com/assets/htmlimages/creativity and the law 2025.png) <small>www.cantorcolburn.com</small>Creativity and the Law with the Greater Hartford Arts Council: Cantor Colburn

Cantor Colburn LLP On LinkedIn: #intellectualproperty #patentlaw #biotechnology #pharmaceutical…
------------------------------------------------------------------------------------------------

 ![Cantor Colburn LLP on LinkedIn: #intellectualproperty #patentlaw #biotechnology #pharmaceutical…](https://media.licdn.com/dms/image/C4E22AQGIZjpXbme91w/feedshare-shrink_800/0/1675456518586?e=2147483647&v=beta&t=ZtzdfzGPAZlkcvEbdxcFd9f87VNKAiTYGuN5cMp8Tv0) <small>www.linkedin.com</small>Cantor Colburn LLP on LinkedIn: #intellectualproperty #patentlaw #biotechnology #pharmaceutical…

Nicholas Geiger: Cantor Colburn
-------------------------------

 ![Nicholas Geiger: Cantor Colburn](https://www.cantorcolburn.com/assets/images/293.jpeg) <small>www.cantorcolburn.com</small>Nicholas Geiger: Cantor Colburn

Cantor Colburn Adds 11 New Attorneys And Patent Agents To Strengthen Intellectual Property
------------------------------------------------------------------------------------------

 ![Cantor Colburn Adds 11 New Attorneys and Patent Agents to Strengthen Intellectual Property](https://ipwatchdog.com/wp-content/uploads/2023/09/Cantor-Colburn-Logo-Square1-copy.jpg) <small>ipwatchdog.com</small>Cantor Colburn Adds 11 New Attorneys and Patent Agents to Strengthen Intellectual Property ...

David Fox: Cantor Colburn
-------------------------

 ![David Fox: Cantor Colburn](https://www.cantorcolburn.com/assets/images/51.jpeg) <small>www.cantorcolburn.com</small>David Fox: Cantor Colburn

Cantor Colburn LLP On LinkedIn: #intellectualproperty #jointventures #agreements #iptransactions
------------------------------------------------------------------------------------------------

 ![Cantor Colburn LLP on LinkedIn: #intellectualproperty #jointventures #agreements #iptransactions](https://media.licdn.com/dms/image/D4E22AQERrr8FxMrmgA/feedshare-shrink_2048_1536/0/1712167711409?e=2147483647&v=beta&t=PuY2szS25GQuSFowadmD0TaIA2kbu7Q-1UJzzIC9G6E) <small>www.linkedin.com</small>Cantor Colburn LLP on LinkedIn: #intellectualproperty #jointventures #agreements #iptransactions

New England Parkinson's Ride 2020: Cantor Colburn
-------------------------------------------------

 ![New England Parkinson's Ride 2020: Cantor Colburn](https://www.cantorcolburn.com/assets/htmlimages/IMG_0654.jpg) <small>www.cantorcolburn.com</small>New England Parkinson's Ride 2020: Cantor Colburn

Albert Einstein College Of Medicine Spirit Of Achievement Luncheon 2025: Cantor Colburn
---------------------------------------------------------------------------------------

 ![Albert Einstein College of Medicine Spirit of Achievement Luncheon 2025: Cantor Colburn](https://www.cantorcolburn.com/assets/htmlimages/Cantor Colburn Congratulations to AECM Spirit of Achievement 2025.png) <small>www.cantorcolburn.com</small>Albert Einstein College of Medicine Spirit of Achievement Luncheon 2025: Cantor Colburn

Cantor Colburn LLP On LinkedIn: Get Ready For Invention Convention U.S. Nationals 2024
--------------------------------------------------------------------------------------

 ![Cantor Colburn LLP on LinkedIn: Get Ready for Invention Convention U.S. Nationals 2024](https://media.licdn.com/dms/image/sync/D4E27AQHx2SxBI_1k6g/articleshare-shrink_800/0/1714486049571?e=2147483647&v=beta&t=tSaC_soQYVsAaXFWflCek0jo74J3SDFPkA4vfD_XsPU) <small>www.linkedin.com</small>Cantor Colburn LLP on LinkedIn: Get Ready for Invention Convention U.S. Nationals 2024

Cantor Colburn LLP On LinkedIn: Working Examples In Patent Applications: How Much Detail To Include?
----------------------------------------------------------------------------------------------------

 ![Cantor Colburn LLP on LinkedIn: Working examples in patent applications: how much detail to include?](https://media.licdn.com/dms/image/D4E10AQEc4a4gCMQIvQ/image-shrink_1280/0/1704715208788?e=2147483647&v=beta&t=6dNRbVst40esq_ys6xqV6HvaD6Fjh9ypmqmzVIjQjTk) <small>www.linkedin.com</small>Cantor Colburn LLP on LinkedIn: Working examples in patent applications: how much detail to include?

\#teamcantorcolburn | Cantor Colburn LLP
----------------------------------------

 ![#teamcantorcolburn | Cantor Colburn LLP](https://media.licdn.com/dms/image/v2/D4E22AQHOt8P7kFVAMw/feedshare-shrink_800/B4EZStud3zHcAg-/0/1738081427847?e=2147483647&v=beta&t=vMcsMYylOfL3hjQK6-iTsXM1KU6KufdjZI36c7GBvYE) <small>www.linkedin.com</small>\#teamcantorcolburn | Cantor Colburn LLP

David Hudyma: Cantor Colburn
----------------------------

 ![David Hudyma: Cantor Colburn](https://www.cantorcolburn.com/assets/images/703.png) <small>www.cantorcolburn.com</small>David Hudyma: Cantor Colburn

Cantor Colburn LLP On LinkedIn: #intellectualproperty #duediligence #ipduediligence #acquisition
------------------------------------------------------------------------------------------------

 ![Cantor Colburn LLP on LinkedIn: #intellectualproperty #duediligence #ipduediligence #acquisition](https://media.licdn.com/dms/image/C4D22AQF-sl5NR4yqMQ/feedshare-shrink_2048_1536/0/1676577917284?e=2147483647&v=beta&t=bnJqFoVNNFk7a7Ne5M6uga_2sXJbWFU7uYBUoWWyr1E) <small>www.linkedin.com</small>Cantor Colburn LLP on LinkedIn: #intellectualproperty #duediligence #ipduediligence #acquisition ...

Auto IP 2026: Cantor Colburn
----------------------------

 ![Auto IP 2026: Cantor Colburn](https://www.cantorcolburn.com/assets/htmlimages/Hudyma_David_high.png) <small>www.cantorcolburn.com</small>Auto IP 2026: Cantor Colburn

Tong Kim, Ph.D.: Cantor Colburn
-------------------------------

 ![Tong Kim, Ph.D.: Cantor Colburn](https://www.cantorcolburn.com/assets/images/743.png) <small>www.cantorcolburn.com</small>Tong Kim, Ph.D.: Cantor Colburn

Michael Brodowski: Cantor Colburn
---------------------------------

 ![Michael Brodowski: Cantor Colburn](https://www.cantorcolburn.com/assets/images/719.png) <small>www.cantorcolburn.com</small>Michael Brodowski: Cantor Colburn

Yong tang, ph.d.: cantor colburn. cantor colburn llp on linkedin: #intellectualproperty #duediligence #ipduediligence #acquisition .... The 2026 invention convention florida: cantor colburn
