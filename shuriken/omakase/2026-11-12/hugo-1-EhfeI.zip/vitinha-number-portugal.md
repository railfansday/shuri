---
title: "Vitinha Number Portugal - March 23, 2025. lisbon, portugal. portugal&#039;s and paris saint-germain midfielder vitinha (23) in ..."
description: "Vitinha of portugal during the portugal portraits"
date: "2026-03-19"
categories:
- "Uncategorized"
images:
- "https://c8.alamy.com/comp/3D55CYY/portugals-vitinha-during-the-2026-fifa-world-cup-european-qualifying-group-f-match-at-the-aviva-stadium-in-dublin-ireland-picture-date-thursday-november-13-2025-3D55CYY.jpg"
featuredImage: "https://editorial.uefa.com/resources/029a-1de93d03920e-c3e68b6132f6-1000/portugal_v_denmark_-_uefa_nations_league_quarterfinal_leg_two.jpeg"
featured_image: "https://upload.wikimedia.org/wikipedia/commons/thumb/8/89/Portugal_national_football_team_0866_%28Vitinha%29.jpg/250px-Portugal_national_football_team_0866_%28Vitinha%29.jpg"
image: "https://cdn.imago-images.com/bild/sp/1062758972/w.jpg"
---

If you are searching about Vitinha évoque le défi allemand, l’alchimie du groupe portugais et le rêve d’un trophée | UEFA you've came to the right place. We have 35 Images about Vitinha évoque le défi allemand, l’alchimie du groupe portugais et le rêve d’un trophée | UEFA like Vitinha, Por 23 in the UEFA Nations League 2025 semi final match GERMANY - PORTUGAL 1-2 in, Puma Portugal Home Vitinha 23 Shirt 2026-2027 (Official Printing) and also March 23, 2025. Lisbon, Portugal. Portugal's and Paris Saint-Germain midfielder Vitinha (23) in. Read more:

Vitinha évoque Le Défi Allemand, L’alchimie Du Groupe Portugais Et Le Rêve D’un Trophée | UEFA
----------------------------------------------------------------------------------------------

 ![Vitinha évoque le défi allemand, l’alchimie du groupe portugais et le rêve d’un trophée | UEFA](https://editorial.uefa.com/resources/029a-1de93d03920e-c3e68b6132f6-1000/portugal_v_denmark_-_uefa_nations_league_quarterfinal_leg_two.jpeg) <small>fr.uefa.com</small>Vitinha évoque le défi allemand, l’alchimie du groupe portugais et le rêve d’un trophée | UEFA ...

Portugal's Vitinha During The 2026 FIFA World Cup European Qualifying, Group F Match At The
-------------------------------------------------------------------------------------------

 ![Portugal's Vitinha during the 2026 FIFA World Cup European Qualifying, Group F match at the](https://c8.alamy.com/comp/3D55CYB/portugals-vitinha-during-the-2026-fifa-world-cup-european-qualifying-group-f-match-at-the-aviva-stadium-in-dublin-ireland-picture-date-thursday-november-13-2025-3D55CYB.jpg) <small>www.alamy.com</small>Portugal's Vitinha during the 2026 FIFA World Cup European Qualifying, Group F match at the ...

Vitinha 23 (Dorsal Oficial) - 26-27 Portugal Local
--------------------------------------------------

 ![Vitinha 23 (Dorsal Oficial) - 26-27 Portugal Local](https://www.subsidesports.com/media/catalog/product/cache/a5716ed2a1003630b9abacca1719c93b/0/8/0841cb15d088c272ef9b948367c45ff71c0c59215e5abf4c7e59519e92303a8c.jpeg) <small>www.subsidesports.es</small>Vitinha 23 (Dorsal Oficial) - 26-27 Portugal Local

Portugal's Vitinha Celebrates Victory After The UEFA Euro 2024, Round Of 16 Match At The
----------------------------------------------------------------------------------------

 ![Portugal's Vitinha celebrates victory after the UEFA Euro 2024, round of 16 match at the](https://c8.alamy.com/comp/2XF7B8F/portugals-vitinha-celebrates-victory-after-the-uefa-euro-2024-round-of-16-match-at-the-frankfurt-arena-in-frankfurt-germany-picture-date-monday-july-1-2024-2XF7B8F.jpg) <small>www.alamy.com</small>Portugal's Vitinha celebrates victory after the UEFA Euro 2024, round of 16 match at the ...

Euro 2024 | Vitinha, Maestro Du PSG Cherche Sa Place à L'Euro Avec Le Portugal - Eurosport
------------------------------------------------------------------------------------------

 ![Euro 2024 | Vitinha, maestro du PSG cherche sa place à l'Euro avec le Portugal - Eurosport](https://imgresizer.eurosport.com/unsafe/2560x1440/filters:format(jpeg)/origin-imgresizer.eurosport.com/2024/06/05/3983020-80836108-2560-1440.jpg) <small>www.eurosport.fr</small>Euro 2024 | Vitinha, maestro du PSG cherche sa place à l'Euro avec le Portugal - Eurosport

FRANKFURT - Vitinha Of Portugal During The UEFA EURO 2024 Round Of 16 Match Between Portugal And
------------------------------------------------------------------------------------------------

 ![FRANKFURT - Vitinha of Portugal during the UEFA EURO 2024 round of 16 match between Portugal and](https://c8.alamy.com/comp/2XGE28T/frankfurt-vitinha-of-portugal-during-the-uefa-euro-2024-round-of-16-match-between-portugal-and-slovenia-at-frankfurt-arena-on-july-1-2024-in-frankfurt-germany-anp-hollandse-hoogte-gerrit-van-keulen-2XGE28T.jpg) <small>www.alamy.com</small>FRANKFURT - Vitinha of Portugal during the UEFA EURO 2024 round of 16 match between Portugal and ...

"Vitinha - Portugal 2022" Sticker For Sale By OnTargetSports | Redbubble
------------------------------------------------------------------------

 !["Vitinha - Portugal 2022" Sticker for Sale by OnTargetSports | Redbubble](https://ih1.redbubble.net/image.4347374033.0199/bg,f8f8f8-flat,750x,075,f-pad,750x1000,f8f8f8.u5.jpg) <small>www.redbubble.com</small>"Vitinha - Portugal 2022" Sticker for Sale by OnTargetSports | Redbubble

Portugal's Vitinha During The UEFA Euro 2024 Group F Match At Leipzig Stadium In Leipzig
----------------------------------------------------------------------------------------

 ![Portugal's Vitinha during the UEFA Euro 2024 Group F match at Leipzig Stadium in Leipzig](https://c8.alamy.com/comp/2XCTH3R/portugals-vitinha-during-the-uefa-euro-2024-group-f-match-at-leipzig-stadium-in-leipzig-germany-picture-date-tuesday-june-18-2024-2XCTH3R.jpg) <small>www.alamy.com</small>Portugal's Vitinha during the UEFA Euro 2024 Group F match at Leipzig Stadium in Leipzig ...

Portugal's Vitinha During The 2026 FIFA World Cup European Qualifying, Group F Match At The
-------------------------------------------------------------------------------------------

 ![Portugal's Vitinha during the 2026 FIFA World Cup European Qualifying, Group F match at the](https://c8.alamy.com/comp/3D55CYY/portugals-vitinha-during-the-2026-fifa-world-cup-european-qualifying-group-f-match-at-the-aviva-stadium-in-dublin-ireland-picture-date-thursday-november-13-2025-3D55CYY.jpg) <small>www.alamy.com</small>Portugal's Vitinha during the 2026 FIFA World Cup European Qualifying, Group F match at the ...

Vitinha Of Portugal During The Portugal Portraits - UEFA Nations... News Photo - Getty Images
---------------------------------------------------------------------------------------------

 ![Vitinha of Portugal during the Portugal Portraits - UEFA Nations... News Photo - Getty Images](https://media.gettyimages.com/id/2218377412/photo/portugal-portraits-uefa-nations-league-2025-finals.jpg?s=612x612&w=gi&k=20&c=A6idYjwIdjQDTCurRu6XBojy_3tGOaJwsFpbsSSPVTM=) <small>www.gettyimages.in</small>Vitinha of Portugal during the Portugal Portraits - UEFA Nations... News Photo - Getty Images

Vitinha Of Portugal Poses For A Portrait During The Portugal Portrait... News Photo - Getty Images
--------------------------------------------------------------------------------------------------

 ![Vitinha of Portugal poses for a portrait during the Portugal Portrait... News Photo - Getty Images](https://media.gettyimages.com/id/2156815343/photo/portugal-portraits-uefa-euro-2024.jpg?s=1024x1024&w=gi&k=20&c=OgVYE8wvaeLYHemYypa0_Qx0JVkAm5i93MMsfftyi5A=) <small>www.gettyimages.com</small>Vitinha of Portugal poses for a portrait during the Portugal Portrait... News Photo - Getty Images

FRANKFURT - Vitinha Of Portugal During The UEFA EURO 2024 Round Of 16 Match Between Portugal And
------------------------------------------------------------------------------------------------

 ![FRANKFURT - Vitinha of Portugal during the UEFA EURO 2024 round of 16 match between Portugal and](https://c8.alamy.com/comp/2XGE32D/frankfurt-vitinha-of-portugal-during-the-uefa-euro-2024-round-of-16-match-between-portugal-and-slovenia-at-frankfurt-arena-on-july-1-2024-in-frankfurt-germany-anp-hollandse-hoogte-gerrit-van-keulen-2XGE32D.jpg) <small>www.alamy.com</small>FRANKFURT - Vitinha of Portugal during the UEFA EURO 2024 round of 16 match between Portugal and ...

Vitinha 23 (Official Printing) - 25-26 Portugal Home
----------------------------------------------------

 ![Vitinha 23 (Official Printing) - 25-26 Portugal Home](https://static1.cdn-subsidesports.com/2/media/catalog/product/cache/38d4094f49a5c2931b615f53f1250097/a/0/a05935197420b74e0c04c894f63c35018cc3a71cd48f5d96dd8cf9cef9015da3.jpeg) <small>www.subsidesports.com</small>Vitinha 23 (Official Printing) - 25-26 Portugal Home

Vitinha Of Portugal Poses For A Photo With The Vivo Player Of The... News Photo - Getty Images
----------------------------------------------------------------------------------------------

 ![Vitinha of Portugal poses for a photo with the Vivo Player of the... News Photo - Getty Images](https://media.gettyimages.com/id/2158161619/photo/group-f-uefa-euro-2024.jpg?s=1024x1024&w=gi&k=20&c=OFb9p49Wo4ZCBgEOpEvqn4NZqC0VW1v-dHT27U9Xoho=) <small>www.gettyimages.com</small>Vitinha of Portugal poses for a photo with the Vivo Player of the... News Photo - Getty Images

MUNCHEN - Vitinha Of Portugal During The UEFA Nations League Final Portugal V. Spain At The
-------------------------------------------------------------------------------------------

 ![MUNCHEN - Vitinha of Portugal during the UEFA Nations League final Portugal v. Spain at the](https://c8.alamy.com/comp/3BH9GP0/munchen-vitinha-of-portugal-during-the-uefa-nations-league-final-portugal-v-spain-at-the-munich-football-arena-on-june-8-2025-in-munich-germany-anp-hollandse-hoogte-maurice-van-steen-3BH9GP0.jpg) <small>www.alamy.com</small>MUNCHEN - Vitinha of Portugal during the UEFA Nations League final Portugal v. Spain at the ...

Vitinha, Por 23 In The UEFA Nations League 2025 Semi Final Match GERMANY - PORTUGAL 1-2 In
------------------------------------------------------------------------------------------

 ![Vitinha, Por 23 in the UEFA Nations League 2025 semi final match GERMANY - PORTUGAL 1-2 in](https://c8.alamy.com/comp/3BGJH6R/vitinha-por-23-in-the-uefa-nations-league-2025-semi-final-match-germany-portugal-1-2-in-season-20242025-at-june-4-2025-in-munich-germany-photographer-peter-schatz-3BGJH6R.jpg) <small>www.alamy.com</small>Vitinha, Por 23 in the UEFA Nations League 2025 semi final match GERMANY - PORTUGAL 1-2 in ...

Vitinha Portugal Celebrating After Uefa Euro Editorial Stock Photo - Stock Image | Shutterstock
-----------------------------------------------------------------------------------------------

 ![Vitinha Portugal Celebrating After Uefa Euro Editorial Stock Photo - Stock Image | Shutterstock](https://www.shutterstock.com/editorial/image-editorial/MdT6Q23fM8D0c4ybNDUwODI=/vitinha-portugal-celebrating-after-uefa-euro-2024-440nw-14567562fh.jpg) <small>www.shutterstock.com</small>Vitinha Portugal Celebrating After Uefa Euro Editorial Stock Photo - Stock Image | Shutterstock ...

Vitinha | Portugal | UEFA EURO 2024 | UEFA.com
----------------------------------------------

 ![Vitinha | Portugal | UEFA EURO 2024 | UEFA.com](https://img.uefa.com/imgml/TP/players/3/2024/cutoff/250101444.png) <small>www.uefa.com</small>Vitinha | Portugal | UEFA EURO 2024 | UEFA.com

Portugal 2026- Home VITINHA #23 Official Name Set – ProSoccer
-------------------------------------------------------------

 ![Portugal 2026- Home VITINHA #23 Official Name Set – ProSoccer](https://www.prosoccer.com/cdn/shop/files/portugal-2026-home-vitinha-23-official-name-set-7781831.webp?v=1781910191&width=1946) <small>www.prosoccer.com</small>Portugal 2026- Home VITINHA #23 Official Name Set – ProSoccer

Portugal's Vitinha Attempts A Shot At Goal During A World Cup 2026 Group F Qualifying Soccer
--------------------------------------------------------------------------------------------

 ![Portugal's Vitinha attempts a shot at goal during a World Cup 2026 group F qualifying soccer](https://c8.alamy.com/comp/3CYE9X1/portugals-vitinha-attempts-a-shot-at-goal-during-a-world-cup-2026-group-f-qualifying-soccer-match-between-portugal-and-hungary-in-lisbon-tuesday-oct-14-2025-ap-photoarmando-franca-3CYE9X1.jpg) <small>www.alamy.com</small>Portugal's Vitinha attempts a shot at goal during a World Cup 2026 group F qualifying soccer ...

Portugueses Na Bola De Ouro 2025: Vitinha, Nuno Mendes E João Neves Podem Brilhar Entre Os
------------------------------------------------------------------------------------------

 ![Portugueses na Bola de Ouro 2025: Vitinha, Nuno Mendes e João Neves podem brilhar entre os](https://offloadmedia.feverup.com/lisboasecreta.co/wp-content/uploads/2025/09/18120223/vitinha-com-a-taca-da-Ligas-das-Nacoes-ganha-por-Portugal-@vitinha.jpg) <small>lisboasecreta.co</small>Portugueses na Bola de Ouro 2025: Vitinha, Nuno Mendes e João Neves podem brilhar entre os ...

FRANKFURT - Vitinha Of Portugal During The UEFA EURO 2024 Round Of 16 Match Between Portugal And
------------------------------------------------------------------------------------------------

 ![FRANKFURT - Vitinha of Portugal during the UEFA EURO 2024 round of 16 match between Portugal and](https://c8.alamy.com/comp/2XGE2YB/frankfurt-vitinha-of-portugal-during-the-uefa-euro-2024-round-of-16-match-between-portugal-and-slovenia-at-frankfurt-arena-on-july-1-2024-in-frankfurt-germany-anp-hollandse-hoogte-gerrit-van-keulen-2XGE2YB.jpg) <small>www.alamy.com</small>FRANKFURT - Vitinha of Portugal during the UEFA EURO 2024 round of 16 match between Portugal and ...

March 23, 2025. Lisbon, Portugal. Portugal's And Paris Saint-Germain Midfielder Vitinha (23) In
-----------------------------------------------------------------------------------------------

 ![March 23, 2025. Lisbon, Portugal. Portugal's and Paris Saint-Germain midfielder Vitinha (23) in](https://c8.alamy.com/comp/3A5MNFT/march-23-2025-lisbon-portugal-portugals-and-paris-saint-germain-midfielder-vitinha-23-in-action-during-the-2nd-leg-of-quarter-finals-of-the-uefa-nations-league-portugal-vs-denmark-credit-alexandre-de-sousaalamy-live-news-3A5MNFT.jpg) <small>www.alamy.com</small>March 23, 2025. Lisbon, Portugal. Portugal's and Paris Saint-Germain midfielder Vitinha (23) in ...

Portugal's Vitinha During The UEFA Euro 2024 Group F Match At Leipzig Stadium In Leipzig
----------------------------------------------------------------------------------------

 ![Portugal's Vitinha during the UEFA Euro 2024 Group F match at Leipzig Stadium in Leipzig](https://c8.alamy.com/comp/2XCTFEP/portugals-vitinha-during-the-uefa-euro-2024-group-f-match-at-leipzig-stadium-in-leipzig-germany-picture-date-tuesday-june-18-2024-2XCTFEP.jpg) <small>www.alamy.com</small>Portugal's Vitinha during the UEFA Euro 2024 Group F match at Leipzig Stadium in Leipzig ...

MUNICH, GERMANY - JUNE 08: Vitinha Of Portugal Reacts During The UEFA Nations League 2025 Final
-----------------------------------------------------------------------------------------------

 ![MUNICH, GERMANY - JUNE 08: Vitinha of Portugal reacts during the UEFA Nations League 2025 final](https://c8.alamy.com/comp/3BHBJGG/munich-germany-june-08-vitinha-of-portugal-reacts-during-the-uefa-nations-league-2025-final-match-between-portugal-and-spain-at-munich-football-arena-on-june-08-2025-in-munich-germany-diebilderwelt-alamy-stock-3BHBJGG.jpg) <small>www.alamy.com</small>MUNICH, GERMANY - JUNE 08: Vitinha of Portugal reacts during the UEFA Nations League 2025 final ...

Vitinha Life Size Cardboard Cutout Model| Portugal’s Midfield Maestro &amp; Seleção Number 23 Fifa
--------------------------------------------------------------------------------------------------

 ![Vitinha Life Size Cardboard Cutout Model| Portugal’s Midfield Maestro & Seleção Number 23 Fifa](https://cdn.myikas.com/images/b363bd06-fb46-4ffd-a7d0-b7231a175a7e/01a25c4c-9374-4722-ace8-e25b629b776c/3840/vitinha-life-size-cardboard-cutout-model-portugal-national-football-team-number-23-celebrity-cutouts.webp) <small>lifesizemodelshop.com</small>Vitinha Life Size Cardboard Cutout Model| Portugal’s Midfield Maestro &amp; Seleção Number 23 Fifa ...

Vitinha Et Le Portugal Renversent L’Allemagne Et Filent En Finale – Le Meilleur Du PSG
--------------------------------------------------------------------------------------

 ![Vitinha et le Portugal renversent l’Allemagne et filent en finale – Le Meilleur Du PSG](https://www.lemeilleurdupsg.com/wp-content/uploads/2025/06/Vitinha-et-le-Portugal-eliminent-lAllemagne-en-Ligue-des-Nations.jpeg) <small>www.lemeilleurdupsg.com</small>Vitinha et le Portugal renversent l’Allemagne et filent en finale – Le Meilleur Du PSG

Vitinha Red No.23 Portugal V. Germany Short-sleeved Shirt, 2025 - Budds | Sports Memorabilia
--------------------------------------------------------------------------------------------

 ![Vitinha red No.23 Portugal v. Germany short-sleeved shirt, 2025 - Budds | Sports Memorabilia](https://media.app.artisio.co/media/b20fa6d1-9e1e-4e31-a8b7-df01c351be13/inventory/99f59fe7-78d6-4c2c-b68c-9c510c3397c7/89201e91-9667-417b-a4fb-85c0d54a31ad/0002_mDaxcT_original.jpeg) <small>www.budds.com</small>Vitinha red No.23 Portugal v. Germany short-sleeved shirt, 2025 - Budds | Sports Memorabilia

Vitinha Of Portugal During The Portugal Portraits - UEFA Nations... News Photo - Getty Images
---------------------------------------------------------------------------------------------

 ![Vitinha of Portugal during the Portugal Portraits - UEFA Nations... News Photo - Getty Images](https://media.gettyimages.com/id/2218377536/photo/portugal-portraits-uefa-nations-league-2025-finals.jpg?s=1024x1024&w=gi&k=20&c=5L1EGOqCUCXZdPLcJhkolqJiJuh2Ei3UFJ2JEhVS2Rw=) <small>www.gettyimages.in</small>Vitinha of Portugal during the Portugal Portraits - UEFA Nations... News Photo - Getty Images

Vitinha Of Portugal During The FIFA World Cup Qatar 2022 Match, Group H, Between South Korea V
----------------------------------------------------------------------------------------------

 ![Vitinha of Portugal during the FIFA World Cup Qatar 2022 match, Group H, between South Korea v](https://c8.alamy.com/comp/2KYWD9T/vitinha-of-portugal-during-the-fifa-world-cup-qatar-2022-match-group-h-between-south-korea-v-portugal-played-at-education-city-stadium-on-dec-2-2022-in-doha-qatar-photo-by-bagu-blanco-pressin-2KYWD9T.jpg) <small>www.alamy.com</small>Vitinha of Portugal during the FIFA World Cup Qatar 2022 match, Group H, between South Korea v ...

Portugal Shirt Uit 2025-2026 + Vitinha 23
-----------------------------------------

 ![Portugal Shirt Uit 2025-2026 + Vitinha 23](https://static1.cdn-subsidesports.com/2/media/catalog/product/cache/38d4094f49a5c2931b615f53f1250097/5/0/502e7c1b30cbe8d9397b686ee11d2cb0fc46bb875edc7b27c038873fb2a62d58.jpeg) <small>www.subsidesports.nl</small>Portugal Shirt Uit 2025-2026 + Vitinha 23

Vitinha Portugal Gestures During The UEFA Nations League 2025 Semifinal Match Between Germany And
-------------------------------------------------------------------------------------------------

 ![Vitinha Portugal gestures during the UEFA Nations League 2025 semifinal match between Germany and](https://cdn.imago-images.com/bild/sp/1062758972/w.jpg) <small>www.imago-images.com</small>Vitinha Portugal gestures during the UEFA Nations League 2025 semifinal match between Germany and

Puma Portugal Home Vitinha 23 Shirt 2026-2027 (Official Printing)
-----------------------------------------------------------------

 ![Puma Portugal Home Vitinha 23 Shirt 2026-2027 (Official Printing)](https://static1.cdn-subsidesports.com/2/media/catalog/product/cache/38d4094f49a5c2931b615f53f1250097/8/d/8d73290ecc10262ba766db0d1bb32167b247b38c7ce69e445c336a0616970f87.jpeg) <small>www.subside.com.au</small>Puma Portugal Home Vitinha 23 Shirt 2026-2027 (Official Printing)

Vitinha – Wikipédia, A Enciclopédia Livre
-----------------------------------------

 ![Vitinha – Wikipédia, a enciclopédia livre](https://upload.wikimedia.org/wikipedia/commons/thumb/8/89/Portugal_national_football_team_0866_%28Vitinha%29.jpg/250px-Portugal_national_football_team_0866_%28Vitinha%29.jpg) <small>pt.wikipedia.org</small>Vitinha – Wikipédia, a enciclopédia livre

Vitinha Leads Portugal At The 2026 World Cup: 216 Of 226 Passes | OneFootball
-----------------------------------------------------------------------------

 ![Vitinha leads Portugal at the 2026 World Cup: 216 of 226 passes | OneFootball](https://image-service.onefootball.com/transform?w=280&h=210&dpr=2&image=https:%2F%2Fwww.fcporto.ws%2Fwp-content%2Fuploads%2F2026%2F06%2FHLk5LZ-XkAA0Sx1.jpg) <small>onefootball.com</small>Vitinha leads Portugal at the 2026 World Cup: 216 of 226 passes | OneFootball

Vitinha leads portugal at the 2026 world cup: 216 of 226 passes. Portugal's vitinha during the uefa euro 2024 group f match at leipzig stadium in leipzig. Vitinha portugal celebrating after uefa euro editorial stock photo
