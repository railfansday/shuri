---
title: "Lotto Results Lotto Plus 1 And 2 History - R67 million on line for lotto and lotto plus 1 and 2 on saturday 14 ..."
description: "Check your tickets: r66 million lotto jackpot has been won!"
date: "2026-06-12"
categories:
- "Uncategorized"
images:
- "https://i.pinimg.com/originals/2c/e1/6f/2ce16ff6352249a4346f438b39af9f09.png"
featuredImage: "https://www.thesouthafrican.com/wp-content/uploads/2023/02/09-feb-daily-lotto.jpeg"
featured_image: "https://www.magiclotto.co.za/Assets/images/news/DIowyYzVYAEVvhD.jpg"
image: "https://www.thesouthafrican.com/wp-content/uploads/2026/04/Lotto-and-Lotto-Plus-1-and-2-on-Wednesday-8-April-2026_1.jpg.optimal.jpg"
---

If you are looking for ITHUBA confirms Lotto Plus 1 and Lotto Plus 2 jackpots WON you've visit to the right web. We have 29 Pictures about ITHUBA confirms Lotto Plus 1 and Lotto Plus 2 jackpots WON like Check your tickets: R66 million Lotto jackpot has been won!, Lotto Results And Payouts &amp; Lotto Plus Best Sale | www.cityofclovis.org and also R98 million UP for grabs: Lotto and Lotto Plus 1 and 2 on Wednesday 29. Here it is:

ITHUBA Confirms Lotto Plus 1 And Lotto Plus 2 Jackpots WON
----------------------------------------------------------

 ![ITHUBA confirms Lotto Plus 1 and Lotto Plus 2 jackpots WON](https://www.thesouthafrican.com/wp-content/uploads/2026/04/Lotto-and-Lotto-Plus-1-and-2-on-Wednesday-8-April-2026_1.jpg.optimal.jpg) <small>www.thesouthafrican.com</small>ITHUBA confirms Lotto Plus 1 and Lotto Plus 2 jackpots WON

Lotto Plus Two 1 July 2026 Wednesday, Results Tonight, South Africa
-------------------------------------------------------------------

 ![Lotto Plus Two 1 July 2026 Wednesday, Results Tonight, South Africa](https://powerball.us.org/images/lottoplustwosa/1.webp) <small>powerball.us.org</small>Lotto Plus Two 1 July 2026 Wednesday, Results Tonight, South Africa

R98 Million UP For Grabs: Lotto And Lotto Plus 1 And 2 On Wednesday 29
----------------------------------------------------------------------

 ![R98 million UP for grabs: Lotto and Lotto Plus 1 and 2 on Wednesday 29](https://www.thesouthafrican.com/wp-content/uploads/2026/04/Lotto-and-Lotto-Plus-1-and-2-on-Wednesday-29-April-2026_1-1200x321.png) <small>www.thesouthafrican.com</small>R98 million UP for grabs: Lotto and Lotto Plus 1 and 2 on Wednesday 29 ...

SA Lotto Plus 2 Summary - 2024-01-20
------------------------------------

 ![SA Lotto Plus 2 Summary - 2024-01-20](https://cdn.africanlottery.net/img/results/lotto-plus-2-results-no-2405.webp) <small>www.africanlottery.net</small>SA Lotto Plus 2 Summary - 2024-01-20

Lotto And Lotto Plus Results For Yesterday Online
-------------------------------------------------

 ![Lotto and lotto plus results for yesterday online](https://i.pinimg.com/736x/b6/4f/3d/b64f3dfa01d82a81dd4fc7e3b3b85094.jpg) <small>www.namibian.com.na</small>Lotto and lotto plus results for yesterday online

Anele Mdoda’s Husband Mgudlwa Breaks Silence Amid PPE Claims
------------------------------------------------------------

 ![Anele Mdoda’s husband Mgudlwa breaks silence amid PPE claims](https://www.thesouthafrican.com/wp-content/uploads/2025/04/Lotto.jpg.optimal.jpg) <small>www.thesouthafrican.com</small>Anele Mdoda’s husband Mgudlwa breaks silence amid PPE claims

R67 Million On LINE For Lotto And Lotto Plus 1 And 2 On Saturday 14
-------------------------------------------------------------------

 ![R67 million on LINE for Lotto and Lotto Plus 1 and 2 on Saturday 14](https://www.thesouthafrican.com/wp-content/uploads/2026/03/Lotto-and-Lotto-Plus-1-and-2-on-Saturday-14-March-2026_1-960x259.jpg.optimal.jpg) <small>www.thesouthafrican.com</small>R67 million on LINE for Lotto and Lotto Plus 1 and 2 on Saturday 14 ...

LOTTO, LOTTO PLUS 1 AND LOTTO PLUS 2 DRAW 1955 (21 SEPTEMBER 2019
-----------------------------------------------------------------

 ![LOTTO, LOTTO PLUS 1 AND LOTTO PLUS 2 DRAW 1955 (21 SEPTEMBER 2019](https://i.pinimg.com/736x/e9/4d/ba/e94dbaba6f623521df9aacf164cf74de.jpg) <small>www.pinterest.com</small>LOTTO, LOTTO PLUS 1 AND LOTTO PLUS 2 DRAW 1955 (21 SEPTEMBER 2019 ...

SA Lotto Plus 1 Summary - 2026-02-25
------------------------------------

 ![SA Lotto Plus 1 Summary - 2026-02-25](https://cdn.africanlottery.net/libchart/generated/lotto-plus-payouts-2623.png) <small>www.africanlottery.net</small>SA Lotto Plus 1 Summary - 2026-02-25

Lotto And Lotto Plus Results: Winning Numbers
---------------------------------------------

 ![Lotto and Lotto Plus Results: Winning Numbers](https://www.thesouthafrican.com/wp-content/uploads/2026/04/Lotto-and-Lotto-Plus-1-and-2-on-Saturday-2-May-2026_4-750x500.jpg.optimal.jpg) <small>www.thesouthafrican.com</small>Lotto and Lotto Plus Results: Winning Numbers

Lotto Plus 1 And Lotto Plus 2 Online
------------------------------------

 ![Lotto plus 1 and lotto plus 2 online](https://media.citizen.co.za/wp-content/uploads/2021/10/LOTTO-PLUS-2-002.jpg) <small>www.namibian.com.na</small>Lotto plus 1 and lotto plus 2 online

Lotto Results Lotto Plus 1 And 2 Today New Arrivals
---------------------------------------------------

 ![Lotto results lotto plus 1 and 2 today new arrivals](https://www.saffarazzi.com/wp-content/uploads/2021/10/lotto-and-lotto-plus-results-saturday-south-africa.webp) <small>pediatrianorte.med.uchile.cl</small>Lotto results lotto plus 1 and 2 today new arrivals

ITHUBA Confirms Lotto Plus 1 And Lotto Plus 2 Jackpots WON
----------------------------------------------------------

 ![ITHUBA confirms Lotto Plus 1 and Lotto Plus 2 jackpots WON](https://www.thesouthafrican.com/wp-content/uploads/2026/04/image-28.png) <small>www.thesouthafrican.com</small>ITHUBA confirms Lotto Plus 1 and Lotto Plus 2 jackpots WON

‘Budget Speech’ Lotto And Lotto Plus 1 And 2 On Wednesday 25 February
---------------------------------------------------------------------

 ![‘Budget Speech’ Lotto and Lotto Plus 1 and 2 on Wednesday 25 February](https://www.thesouthafrican.com/wp-content/uploads/2026/02/Lotto-and-Lotto-Plus-1-and-2-on-Wednesday-25-February-2026-750x500.jpg.optimal.jpg) <small>www.thesouthafrican.com</small>‘Budget Speech’ Lotto and Lotto Plus 1 and 2 on Wednesday 25 February ...

Lotto Plus 1 Plus 2 Results Online
----------------------------------

 ![Lotto plus 1 plus 2 results online](https://pbs.twimg.com/media/EOX9TJlUUAArL9n.png) <small>www.namibian.com.na</small>Lotto plus 1 plus 2 results online

R67 Million On LINE For Lotto And Lotto Plus 1 And 2 On Saturday 14
-------------------------------------------------------------------

 ![R67 million on LINE for Lotto and Lotto Plus 1 and 2 on Saturday 14](https://www.thesouthafrican.com/wp-content/uploads/2026/03/Lotto-and-Lotto-Plus-1-and-2-on-Saturday-14-March-2026_5.jpg.optimal.jpg) <small>www.thesouthafrican.com</small>R67 million on LINE for Lotto and Lotto Plus 1 and 2 on Saturday 14 ...

Check Your Tickets: R66 Million Lotto Jackpot Has Been Won!
-----------------------------------------------------------

 ![Check your tickets: R66 million Lotto jackpot has been won!](https://www.thesouthafrican.com/wp-content/uploads/2023/05/Lotto-20-May-winner.jpg) <small>www.sapeople.com</small>Check your tickets: R66 million Lotto jackpot has been won!

10 Previous Lotto Results Online
--------------------------------

 ![10 previous lotto results online](https://www.saffarazzi.com/wp-content/uploads/2024/01/20240110-wednesday-south-africa-lotto-and-lotto-plus-results.webp) <small>www.namibian.com.na</small>10 previous lotto results online

R98 Million UP For Grabs: Lotto And Lotto Plus 1 And 2 On Wednesday 29
----------------------------------------------------------------------

 ![R98 million UP for grabs: Lotto and Lotto Plus 1 and 2 on Wednesday 29](https://www.thesouthafrican.com/wp-content/uploads/2026/04/Lotto-and-Lotto-Plus-1-and-2-on-Wednesday-29-April-2026_1-960x257.png) <small>www.thesouthafrican.com</small>R98 million UP for grabs: Lotto and Lotto Plus 1 and 2 on Wednesday 29 ...

R54-million Payday For Lotto And Lotto Plus 1 And 2 On Saturday 28
------------------------------------------------------------------

 ![R54-million payday for Lotto and Lotto Plus 1 and 2 on Saturday 28](https://www.thesouthafrican.com/wp-content/uploads/2026/02/Lotto-and-Lotto-Plus-1-and-2-on-Saturday-28-February-2026-.jpg.optimal.jpg) <small>www.thesouthafrican.com</small>R54-million payday for Lotto and Lotto Plus 1 and 2 on Saturday 28 ...

The Lotto And Lotto Plus 1 And 2 Results For Wednesday, 1 April 2026
--------------------------------------------------------------------

 ![The Lotto and Lotto Plus 1 and 2 results for Wednesday, 1 April 2026](https://miro.medium.com/v2/resize:fit:1358/1*8hsJQ8wmznkNEyY8GjNt6w.png) <small>www.afghanistanwatch.com</small>The Lotto and Lotto Plus 1 and 2 results for Wednesday, 1 April 2026 ...

View The Latest South African Lotto, Lotto Plus 1 &amp; Lotto Plus 2
--------------------------------------------------------------------

 ![View the Latest South African Lotto, Lotto Plus 1 & Lotto Plus 2](https://i.pinimg.com/originals/2c/e1/6f/2ce16ff6352249a4346f438b39af9f09.png) <small>www.pinterest.com</small>View the Latest South African Lotto, Lotto Plus 1 &amp; Lotto Plus 2 ...

Lotto Results And Payouts &amp; Lotto Plus Best Sale | Www.cityofclovis.org
---------------------------------------------------------------------------

 ![Lotto Results And Payouts & Lotto Plus Best Sale | www.cityofclovis.org](https://media.citizen.co.za/wp-content/uploads/2018/12/Screenshot-2018-12-06-at-08.45.46.png) <small>www.cityofclovis.org</small>Lotto Results And Payouts &amp; Lotto Plus Best Sale | www.cityofclovis.org

Lotto Plus 1 And 2 Online
-------------------------

 ![Lotto plus 1 and 2 online](https://www.magiclotto.co.za/Assets/images/news/DIowyYzVYAEVvhD.jpg) <small>www.namibian.com.na</small>Lotto plus 1 and 2 online

R94-million HOLY Saturday For Lotto And Lotto Plus 1 And 2 On Saturday
----------------------------------------------------------------------

 ![R94-million HOLY Saturday for Lotto and Lotto Plus 1 and 2 on Saturday](https://www.thesouthafrican.com/wp-content/uploads/2026/04/Lotto-and-Lotto-Plus-1-and-2-on-Saturday-4-April-2026_4-960x640.jpg.optimal.jpg) <small>www.thesouthafrican.com</small>R94-million HOLY Saturday for Lotto and Lotto Plus 1 and 2 on Saturday ...

Daily Lotto Result: ONE Lucky Winner Of Thursday's Jackpot Payouts
------------------------------------------------------------------

 ![Daily Lotto result: ONE lucky winner of Thursday's jackpot payouts](https://www.thesouthafrican.com/wp-content/uploads/2023/02/09-feb-daily-lotto.jpeg) <small>www.sapeople.com</small>Daily Lotto result: ONE lucky winner of Thursday's jackpot payouts

Lotto Plus 2 Results History
----------------------------

 ![Lotto Plus 2 Results History](https://lottoresultsonline.co.za/wp-content/uploads/2023/07/social-lor.png) <small>lottoresultsonline.co.za</small>Lotto Plus 2 Results History

SA Lotto Plus 2 Results For Today, SA Lotto Plus 2 Results For
--------------------------------------------------------------

 ![SA Lotto Plus 2 Results for Today, SA Lotto Plus 2 Results for](https://i.pinimg.com/originals/3b/46/a9/3b46a9c12e248b3faf2facb362846403.png) <small>es.pinterest.com</small>SA Lotto Plus 2 Results for Today, SA Lotto Plus 2 Results for ...

R44.5-million On The Line In Lotto And Lotto Plus 1 And 2 On Saturday
---------------------------------------------------------------------

 ![R44.5-million on the line in Lotto and Lotto Plus 1 and 2 on Saturday](https://www.thesouthafrican.com/wp-content/uploads/2026/02/Lotto-and-Lotto-Plus-1-and-2-on-Saturday-21-February-2026_1.png) <small>www.thesouthafrican.com</small>R44.5-million on the line in Lotto and Lotto Plus 1 and 2 on Saturday ...

Lotto plus two 1 july 2026 wednesday, results tonight, south africa. View the latest south african lotto, lotto plus 1 &amp; lotto plus 2. 10 previous lotto results online
