---
title: "Eva Lys Vs Coco Gauff - Lys vs gauff pronóstico wta pekín"
description: "Pronóstico eva lys cori gauff"
date: "2026-06-15"
categories:
- "Uncategorized"
images:
- "https://i.ytimg.com/vi/-VfavHiExAk/maxresdefault.jpg"
featuredImage: "https://cdn-images-3.listennotes.com/podcasts/qualityshot-tennis/coco-gauff-vs-eva-lys-hreog1FN2A4-LdiqX83HRNz.1400x1400.jpg"
featured_image: "https://www.yardbarker.com/media/5/b/5b1193b85dd562aa97a5d18face50aaa2bec4941/thumb_16x9/GettyImages-2265038109-1024x683.jpg"
image: "https://cdn1.thetennisgazette.com/uploads/78/2025/10/GettyImages-2238735832-scaled.jpg"
---

If you are looking for Coco Gauff ends Eva Lys's dream run, moves one step closer to China you've visit to the right place. We have 35 Pics about Coco Gauff ends Eva Lys's dream run, moves one step closer to China like Eva Lys vs Coco Gauff | China Open highlights | Tennis News | Sky Sports, Coco Gauff vs Eva Lys - China Open Quarterfinal - YouTube and also Generation Freundschaft um Lys: «Macht Karriere schöner». Here it is:

Coco Gauff Ends Eva Lys's Dream Run, Moves One Step Closer To China
-------------------------------------------------------------------

 ![Coco Gauff ends Eva Lys's dream run, moves one step closer to China](https://www.yardbarker.com/media/0/b/0b5fd9b5b965a79ae0b891b7f0e041270a16177e/thumb_16x9/sep-1-2025-flushing-ny-usa-coco-gauff-usa-hits.jpg) <small>www.yardbarker.com</small>Coco Gauff ends Eva Lys's dream run, moves one step closer to China ...

Tennis In Peking: Eva Lys Erstmals Im Viertelfinale – Und Nun Gegen
-------------------------------------------------------------------

 ![Tennis in Peking: Eva Lys erstmals im Viertelfinale – und nun gegen](https://cdn.prod.www.spiegel.de/images/d78d6b1b-e3c9-44a9-8e31-ea780d88e96a_w960_r1.778_fpx43.98_fpy49.99.jpg) <small>www.spiegel.de</small>Tennis in Peking: Eva Lys erstmals im Viertelfinale – und nun gegen ...

Eva Lys’s Fairytale Run Continues, Sets Up Epic Coco Gauff Clash
----------------------------------------------------------------

 ![Eva Lys’s Fairytale Run Continues, Sets Up Epic Coco Gauff Clash](http://res.cloudinary.com/ybmedia/image/upload/c_crop,e_improve,h_1043,w_1854,x_0,y_55/c_fill,f_auto,h_900,q_auto,w_1600/v1/m/d/7/d70b5c07c859c37fe5b3ea672048a79e13fbbbbf/USATSI_26933773_168418642_lowres.jpg) <small>www.yardbarker.com</small>Eva Lys’s Fairytale Run Continues, Sets Up Epic Coco Gauff Clash ...

Coco Gauff Vs Eva Lys | China Open 2025 | Quarter Finals - YouTube
------------------------------------------------------------------

 ![Coco Gauff vs Eva Lys | China Open 2025 | quarter finals - YouTube](https://i.ytimg.com/vi/oYxaiRLvILg/maxresdefault.jpg) <small>www.youtube.com</small>Coco Gauff vs Eva Lys | China Open 2025 | quarter finals - YouTube

2,993 Eva Lys Photos &amp; High Res Pictures - Getty Images
-----------------------------------------------------------

 ![2,993 Eva Lys Photos & High Res Pictures - Getty Images](https://media.gettyimages.com/id/2238713794/photo/beijing-china-eva-lys-of-germany-in-action-against-coco-gauff-of-the-united-states-in-the.jpg?s=612x612&w=gi&k=20&c=OOk-e7KkwIcGbJU4ZvZuEH21isXpDPSbDvdwUEQ9en0=) <small>www.gettyimages.ie</small>2,993 Eva Lys Photos &amp; High Res Pictures - Getty Images

US Open 2025 Women's Draw Preview &amp; Predictions - Swiatek Avoids
--------------------------------------------------------------------

 ![US Open 2025 Women's Draw Preview & Predictions - Swiatek Avoids](https://cdn-images-3.listennotes.com/podcasts/qualityshot-tennis/coco-gauff-vs-eva-lys-hreog1FN2A4-LdiqX83HRNz.1400x1400.jpg) <small>www.listennotes.com</small>US Open 2025 Women's Draw Preview &amp; Predictions - Swiatek Avoids ...

Lys Vs Gauff Pronóstico WTA Pekín | Apuesta HOY
-----------------------------------------------

 ![Lys vs Gauff pronóstico WTA Pekín | Apuesta HOY](https://blog.micasino.com/wp-content/uploads/2025/09/Eva-Lys-vs-Coco-Gauff-Pronostico-WTA-Pekin-MiCasino.com_.webp) <small>blog.micasino.com</small>Lys vs Gauff pronóstico WTA Pekín | Apuesta HOY

What Coco Gauff Said To Eva Lys About Alex Eala After Their Stuttgart
---------------------------------------------------------------------

 ![What Coco Gauff said to Eva Lys about Alex Eala after their Stuttgart](https://www.yardbarker.com/media/5/b/5b1193b85dd562aa97a5d18face50aaa2bec4941/thumb_16x9/GettyImages-2265038109-1024x683.jpg) <small>www.yardbarker.com</small>What Coco Gauff said to Eva Lys about Alex Eala after their Stuttgart ...

Eva Lys Sends Message To Coco Gauff On Instagram After Losing To Her In
-----------------------------------------------------------------------

 ![Eva Lys sends message to Coco Gauff on Instagram after losing to her in](https://cdn1.thetennisgazette.com/uploads/78/2025/10/GettyImages-2238735832-scaled.jpg) <small>www.thetennisgazette.com</small>Eva Lys sends message to Coco Gauff on Instagram after losing to her in ...

Coco Gauff Vs Eva Lys - China Open Quarterfinal - YouTube
---------------------------------------------------------

 ![Coco Gauff vs Eva Lys - China Open Quarterfinal - YouTube](https://i.ytimg.com/vi/b4dmGhLEPUg/maxresdefault.jpg) <small>www.youtube.com</small>Coco Gauff vs Eva Lys - China Open Quarterfinal - YouTube

Tennis Fans USA - Coco Gauff Takes On Eva Lys For A Spot... | Facebook
----------------------------------------------------------------------

 ![Tennis Fans USA - Coco Gauff takes on Eva Lys for a spot... | Facebook](https://lookaside.fbsbx.com/lookaside/crawler/media/?media_id=1205460074948030) <small>www.facebook.com</small>Tennis Fans USA - Coco Gauff takes on Eva Lys for a spot... | Facebook

China Open: Coco Gauff Reaches First Semi-final Since French Open Win
---------------------------------------------------------------------

 ![China Open: Coco Gauff reaches first semi-final since French Open win](https://e0.365dm.com/25/10/768x432/skysports-coco-gauff-china_7038780.jpg?20251002091628) <small>www.skysports.com</small>China Open: Coco Gauff reaches first semi-final since French Open win ...

Coco Gauff Vs Eva Lys - Preview &amp; Prediction - 2025 China Open QF - YouTube
-------------------------------------------------------------------------------

 ![Coco Gauff vs Eva Lys - Preview & Prediction - 2025 China Open QF - YouTube](https://i.ytimg.com/vi/L32b_VQJ8nc/maxresdefault.jpg) <small>www.youtube.com</small>Coco Gauff vs Eva Lys - Preview &amp; Prediction - 2025 China Open QF - YouTube

Eva Lys Vs Coco Gauff | China Open Highlights | Tennis News | Sky Sports
------------------------------------------------------------------------

 ![Eva Lys vs Coco Gauff | China Open highlights | Tennis News | Sky Sports](https://e0.365dm.com/25/10/1600x900/skysports-coco-gauff-china_7038904.jpg?20251002111340) <small>www.skysports.com</small>Eva Lys vs Coco Gauff | China Open highlights | Tennis News | Sky Sports

US Open 2023 Qualifying: Coco Vandeweghe Vs Eva Lys Preview, Head-to
--------------------------------------------------------------------

 ![US Open 2023 Qualifying: Coco Vandeweghe vs Eva Lys preview, head-to](https://staticg.sportskeeda.com/editor/2023/08/de024-16927274084269-1920.jpg) <small>www.sportskeeda.com</small>US Open 2023 Qualifying: Coco Vandeweghe vs Eva Lys preview, head-to ...

Coco Gauff Talks For The First Time After Reaching The Semifinals In
--------------------------------------------------------------------

 ![Coco Gauff talks for the first time after reaching the semifinals in](https://cdn1.thetennisgazette.com/uploads/78/2025/10/GettyImages-2238708595-scaled.jpg) <small>www.thetennisgazette.com</small>Coco Gauff talks for the first time after reaching the semifinals in ...

Coco Gauff And Eva Lys Spotted Together At Aminé’s Melbourne Show Ahead
-----------------------------------------------------------------------

 ![Coco Gauff and Eva Lys Spotted Together at Aminé’s Melbourne Show Ahead](https://collegefootballnetwork.com/wp-content/uploads/2026/01/coco-gauff-eva-lys-spotted-01-16-26.png) <small>collegefootballnetwork.com</small>Coco Gauff and Eva Lys Spotted Together at Aminé’s Melbourne Show Ahead ...

Gauff Wartet: Lys Schaltet Kessler Aus Und Steht Im Viertelfinale - Kicker
--------------------------------------------------------------------------

 ![Gauff wartet: Lys schaltet Kessler aus und steht im Viertelfinale - kicker](https://derivates.kicker.de/image/upload/c_crop%2Cx_0%2Cy_96%2Cw_4000%2Ch_2250/w_1000%2Cq_auto/v1/2025/09/30/40d11274-8eb4-4ac7-a639-e4df9ae09139.jpg) <small>www.kicker.de</small>Gauff wartet: Lys schaltet Kessler aus und steht im Viertelfinale - kicker

WTA Peking Live: Eva Lys Vs. Coco Gauff Im TV. Livestream Und
-------------------------------------------------------------

 ![WTA Peking live: Eva Lys vs. Coco Gauff im TV. Livestream und](https://www.tennisnet.com/fileadmin/_processed_/8/9/csm_peking_ticker_lys_gauff_199dfe8f75.jpg) <small>www.tennisnet.com</small>WTA Peking live: Eva Lys vs. Coco Gauff im TV. Livestream und ...

Besties: Coco Gauff &amp; Eva Lys At The Players Party In Berlin.
-----------------------------------------------------------------

 ![Besties: Coco Gauff & Eva Lys at the Players Party in Berlin.](https://pbs.twimg.com/media/HK4nn1FWgAIL8LA.jpg) <small>x.com</small>Besties: Coco Gauff &amp; Eva Lys at the Players Party in Berlin.

Eva Lys, Of Germany Plays A Backhand Return To Coco Gauff, Of The
-----------------------------------------------------------------

 ![Eva Lys, of Germany plays a backhand return to Coco Gauff, of the](https://c8.alamy.com/comp/3CRMXGF/eva-lys-of-germany-plays-a-backhand-return-to-coco-gauff-of-the-united-states-during-a-womens-singles-quarterfinals-match-of-the-china-open-tennis-tournament-in-beijing-china-thursday-oct-2-2025-ap-photomahesh-kumar-a-3CRMXGF.jpg) <small>www.alamy.com</small>Eva Lys, of Germany plays a backhand return to Coco Gauff, of the ...

🎾 Epic Comebacks Coco Gauff, Eva Lys &amp; Amanda Anisimova Battle Back
-----------------------------------------------------------------------

 ![🎾 Epic Comebacks Coco Gauff, Eva Lys & Amanda Anisimova Battle Back](https://i.ytimg.com/vi/ZVS6eho9N9s/maxresdefault.jpg) <small>www.youtube.com</small>🎾 Epic Comebacks Coco Gauff, Eva Lys &amp; Amanda Anisimova Battle Back ...

Coco Gauff, Of The United States Plays A Backhand Return To Eva Lys, Of
-----------------------------------------------------------------------

 ![Coco Gauff, of the United States plays a backhand return to Eva Lys, of](https://c8.alamy.com/comp/3CRMCGM/coco-gauff-of-the-united-states-plays-a-backhand-return-to-eva-lys-of-germany-during-the-womens-singles-quarterfinals-match-of-the-china-open-tennis-tournament-at-the-national-tennis-center-in-beijing-thursday-oct-2-2025-ap-photoandy-wong-3CRMCGM.jpg) <small>www.alamy.com</small>Coco Gauff, of the United States plays a backhand return to Eva Lys, of ...

WTA: Hamburger Tennis-Star Eva Lys Scheitert In Peking An Coco Gauff
--------------------------------------------------------------------

 ![WTA: Hamburger Tennis-Star Eva Lys scheitert in Peking an Coco Gauff](https://images.t-online.de/2025/10/8nlbgoHRV-7Q/1037x1085:1583x890/fit-in/1583x0/eva-lys-r-neben-coco-gauff-die-junge-hamburgerin-gehoert-zu-den-grossen-aufsteigerinnen-der-tennis-szene.jpg) <small>hamburg.t-online.de</small>WTA: Hamburger Tennis-Star Eva Lys scheitert in Peking an Coco Gauff

Coco Gauff Domine Eva Lys Et Accède Aux Demi-finales Du Prestigieux WTA
-----------------------------------------------------------------------

 ![Coco Gauff domine Eva Lys et accède aux demi-finales du prestigieux WTA](https://sixactualites.fr/wp-content/uploads/2025/10/Coco-Gauff-domine-Eva-Lys-et-accede-aux-demi-finales-du-prestigieux-WTA-1000-de-Pekin.jpg) <small>sixactualites.fr</small>Coco Gauff domine Eva Lys et accède aux demi-finales du prestigieux WTA ...

Generation Freundschaft Um Lys: «Macht Karriere Schöner»
--------------------------------------------------------

 ![Generation Freundschaft um Lys: «Macht Karriere schöner»](https://www.lkz.de/cms_media/module_img/3153/1576960_1_detailbig_Coco_Gauff_r_umarmt_Eva_Lys_nach_einem_Match._Archivbild_.jpeg) <small>www.lkz.de</small>Generation Freundschaft um Lys: «Macht Karriere schöner»

Pronóstico Eva Lys Cori Gauff | China Open WTA - 2/10/25
--------------------------------------------------------

 ![Pronóstico Eva Lys Cori Gauff | China Open WTA - 2/10/25](https://static.sportytrader.com/betting-tip-thumbnail/prod/294490.webp) <small>www.sportytrader.es</small>Pronóstico Eva Lys Cori Gauff | China Open WTA - 2/10/25

Coco Gauff Shares What She Hopes Every Other WTA Player Thinks About
--------------------------------------------------------------------

 ![Coco Gauff shares what she hopes every other WTA player thinks about](https://cdn1.tennishead.net/uploads/106/2025/10/GettyImages-2238288788-1024x683.jpg) <small>tennishead.net</small>Coco Gauff shares what she hopes every other WTA player thinks about ...

Eva Lys Vs. Coco Gauff | 2025 Beijing Quarterfinal | WTA Match
--------------------------------------------------------------

 ![Eva Lys vs. Coco Gauff | 2025 Beijing Quarterfinal | WTA Match](https://i.ytimg.com/vi/LO--oDbfPN0/maxresdefault.jpg) <small>www.youtube.com</small>Eva Lys vs. Coco Gauff | 2025 Beijing Quarterfinal | WTA Match ...

Coco Gauff Dominates Eva Lys To Enter China Open 2025 Semifinals
----------------------------------------------------------------

 ![Coco Gauff Dominates Eva Lys to Enter China Open 2025 Semifinals](https://i.ytimg.com/vi/iiZB-Jf4f-4/maxresdefault.jpg) <small>www.youtube.com</small>Coco Gauff Dominates Eva Lys to Enter China Open 2025 Semifinals ...

Eva Lys Vs Coco Gauff - Highlight | WTA 1000: China Open 2025
-------------------------------------------------------------

 ![Eva Lys vs Coco Gauff - Highlight | WTA 1000: China Open 2025](https://thumbor.prod.vidiocdn.com/lzsSfCopcgzlFgPKgMFCYSnzfpQ=/1280x720/filters:quality(70)/vidio-web-prod-video/uploads/video/image/8981675/beijing-match-highlights-qf-eva-lys-v-coco-gauff_digital-download_m46037-3555fa.jpg) <small>www.vidio.com</small>Eva Lys vs Coco Gauff - Highlight | WTA 1000: China Open 2025

Eva Lys, Of Germany Serves Against Coco Gauff, Of The United States
-------------------------------------------------------------------

 ![Eva Lys, of Germany serves against Coco Gauff, of the United States](https://c8.alamy.com/comp/3CRMJ04/eva-lys-of-germany-serves-against-coco-gauff-of-the-united-states-during-the-womens-singles-quarterfinals-match-of-the-china-open-tennis-tournament-at-the-national-tennis-center-in-beijing-thursday-oct-2-2025-ap-photoandy-wong-3CRMJ04.jpg) <small>www.alamy.com</small>Eva Lys, of Germany serves against Coco Gauff, of the United States ...

🔥 Coco Gauff Vs Eva Lys Key Predictions And Betting Odds For The WTA
--------------------------------------------------------------------

 ![🔥 Coco Gauff vs Eva Lys Key Predictions and Betting Odds for the WTA](https://i.ytimg.com/vi/-VfavHiExAk/maxresdefault.jpg) <small>www.youtube.com</small>🔥 Coco Gauff vs Eva Lys Key Predictions and Betting Odds for the WTA ...

Novak Djokovic Gefällt's: Eva Lys Vor Highlight-Match Gegen Coco Gauff
----------------------------------------------------------------------

 ![Novak Djokovic gefällt's: Eva Lys vor Highlight-Match gegen Coco Gauff](https://livesport-ott-images.ssl.cdn.cra.cz/r900xfq60/260e568f-2ba4-4fc7-82b5-b7398a544f92.jpeg) <small>www.flashscore.de</small>Novak Djokovic gefällt's: Eva Lys vor Highlight-Match gegen Coco Gauff ...

China Open 2025: Coco Gauff Vs Eva Lys Preview, Head-to-head
------------------------------------------------------------

 ![China Open 2025: Coco Gauff vs Eva Lys preview, head-to-head](https://staticg.sportskeeda.com/editor/2025/10/ef371-17593107366085-1920.jpg) <small>www.sportskeeda.com</small>China Open 2025: Coco Gauff vs Eva Lys preview, head-to-head ...

2,993 eva lys photos &amp; high res pictures. 🔥 coco gauff vs eva lys key predictions and betting odds for the wta .... Coco gauff vs eva lys
