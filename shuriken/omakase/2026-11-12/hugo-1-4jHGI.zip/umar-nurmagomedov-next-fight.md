---
title: "Umar Nurmagomedov Next Fight - umar nurmagomedov set to face ex-ufc champion as khabib confirms next ..."
description: "Ufc 324: full fight results, winners, and highlights"
date: "2026-08-18"
categories:
- "Uncategorized"
images:
- "https://mmajunkie.usatoday.com/gcdn/authoring/authoring-images/2025/10/25/SMMA/86904561007-umar-nurmagomedov-def-mario-bautista-ufc-321-9570.jpg?crop=5468,3077,x0,y285&amp;width=3200&amp;height=1801&amp;format=pjpg&amp;auto=webp"
featuredImage: "https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA1T1hXb.img?w=2252&amp;h=1501&amp;m=4&amp;q=93"
featured_image: "https://mmajunkie.usatoday.com/gcdn/authoring/images/smg/2024/10/14/SMGW/75675166007-91-2760687.png?crop=1919,1079,x0,y0&amp;width=1919&amp;height=1079&amp;format=pjpg&amp;auto=webp"
image: "https://mmajunkie.usatoday.com/gcdn/authoring/authoring-images/2025/10/25/SMMA/86904561007-umar-nurmagomedov-def-mario-bautista-ufc-321-9570.jpg?crop=5468,3077,x0,y285&amp;width=3200&amp;height=1801&amp;format=pjpg&amp;auto=webp"
---

If you are searching about UFC News: Umar Nurmagomedov's Mystery Opponent Finally Revealed you've visit to the right page. We have 35 Pics about UFC News: Umar Nurmagomedov's Mystery Opponent Finally Revealed like Silent assassin Umar Nurmagomedov back to make some noise at UFC 321 in, MMA Fighting | Who would you want to see Sean O'Malley fight next and also Umar Nurmagomedov Reveals The One Fight He Wants More Than The UFC. Here it is:

UFC News: Umar Nurmagomedov's Mystery Opponent Finally Revealed
---------------------------------------------------------------

 ![UFC News: Umar Nurmagomedov's Mystery Opponent Finally Revealed](https://www.si.com/.image/t_share/MTk5NDk2NDY4MzE3ODczNTY2/umar-nurmagomedov-1.jpg) <small>www.si.com</small>UFC News: Umar Nurmagomedov's Mystery Opponent Finally Revealed ...

Khabib Sheds Light On Umar Nurmagomedov's Next UFC Moves
--------------------------------------------------------

 ![Khabib sheds light on Umar Nurmagomedov's next UFC moves](https://mmajunkie.usatoday.com/gcdn/authoring/authoring-images/2025/10/16/SMMA/86724281007-usatsi-25224796.jpg?crop=4734,2664,x0,y175&width=3200&height=1801&format=pjpg&auto=webp) <small>mmajunkie.usatoday.com</small>Khabib sheds light on Umar Nurmagomedov's next UFC moves

UFC 321: Umar Nurmagomedov Full Media Day Interview
---------------------------------------------------

 ![UFC 321: Umar Nurmagomedov full media day interview](https://mmajunkie.usatoday.com/gcdn/authoring/authoring-images/2025/10/22/SMMA/86832327007-umar-yt.jpg?crop=1919,1079,x0,y0&width=1919&height=1079&format=pjpg&auto=webp) <small>mmajunkie.usatoday.com</small>UFC 321: Umar Nurmagomedov full media day interview

Khabib's Cousin Umar Nurmagomedov Takes Unbeaten Record To 15 With
------------------------------------------------------------------

 ![Khabib's cousin Umar Nurmagomedov takes unbeaten record to 15 with](https://www.the-sun.com/wp-content/uploads/sites/6/2022/06/3592d9c4-0d5b-4904-a64d-f033284aba18.jpg?resize=717) <small>www.the-sun.com</small>Khabib's cousin Umar Nurmagomedov takes unbeaten record to 15 with ...

Umar Nurmagomedov Aims To Ease Islam Makhachev's Nerves With 'perfect
---------------------------------------------------------------------

 ![Umar Nurmagomedov aims to ease Islam Makhachev's nerves with 'perfect](https://mmajunkie.usatoday.com/gcdn/authoring/images/smg/2025/01/12/SMGW/77661811007-91-2797088.jpeg?crop=999,563,x0,y18&width=999&height=563&format=pjpg&auto=webp) <small>mmajunkie.usatoday.com</small>Umar Nurmagomedov aims to ease Islam Makhachev's nerves with 'perfect ...

Umar Nurmagomedov Reveals The One Fight He Wants More Than The UFC
------------------------------------------------------------------

 ![Umar Nurmagomedov Reveals The One Fight He Wants More Than The UFC](https://www.totalprosports.com/wp-content/uploads/2026/06/Umar-Nurmagomedov-1.jpg) <small>www.totalprosports.com</small>Umar Nurmagomedov Reveals The One Fight He Wants More Than The UFC ...

UFC 324: Umar Nurmagomedov Media Day Interview
----------------------------------------------

 ![UFC 324: Umar Nurmagomedov media day interview](https://mmajunkie.usatoday.com/gcdn/authoring/authoring-images/2026/01/21/USAT/88289897007-umar-nurmagomedov-mxf-13-15-22-12-still-001.jpg?crop=3839,2159,x0,y0&width=3200&height=1800&format=pjpg&auto=webp) <small>mmajunkie.usatoday.com</small>UFC 324: Umar Nurmagomedov media day interview

Sean O’Malley’s Co-Host Wants Umar Nurmagomedov Fight Next
----------------------------------------------------------

 ![Sean O’Malley’s Co-Host Wants Umar Nurmagomedov Fight Next](https://www.totalprosports.com/wp-content/uploads/2025/06/Sean-OMalley-Merab-Dvalishvili-and-Umar-Nurmagomedov-1200x675.jpg) <small>www.totalprosports.com</small>Sean O’Malley’s Co-Host Wants Umar Nurmagomedov Fight Next

18-0 Umar Nurmagomedov Slams ‘scared’ Merab Dvalishvili For Suggesting
----------------------------------------------------------------------

 ![18-0 Umar Nurmagomedov slams ‘scared’ Merab Dvalishvili for suggesting](https://bloodyelbow.com/wp-content/uploads/1/2024/10/Umar-Nurmagomedov-Merab-Dvalishvili-750x409.png) <small>bloodyelbow.com</small>18-0 Umar Nurmagomedov slams ‘scared’ Merab Dvalishvili for suggesting ...

UFC Rankings: Umar Nurmagomedov Surges After Abu Dhabi Win
----------------------------------------------------------

 ![UFC Rankings: Umar Nurmagomedov Surges After Abu Dhabi Win](https://imageio.forbes.com/specials-images/imageserve/66b2107bee3284e776dec405/UFC-Fight-Night--Sandhagen-v-Nurmagomedov/0x0.jpg?width=960) <small>www.forbes.com</small>UFC Rankings: Umar Nurmagomedov Surges After Abu Dhabi Win

UFC: Umar Nurmagomedov Accepted Fight Vs. Merab Dvalishvili, But There
----------------------------------------------------------------------

 ![UFC: Umar Nurmagomedov accepted fight vs. Merab Dvalishvili, but there](https://wp.clutchpoints.com/wp-content/uploads/2023/03/Umar-Nurmagomedov-Accepted-A-Fight-Against-Merab-Dvalishvili-But-There-Is-A-Catch.jpg) <small>clutchpoints.com</small>UFC: Umar Nurmagomedov accepted fight vs. Merab Dvalishvili, but there ...

Silent Assassin Umar Nurmagomedov Back To Make Some Noise At UFC 321 In
-----------------------------------------------------------------------

 ![Silent assassin Umar Nurmagomedov back to make some noise at UFC 321 in](https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA1OVDwJ.img?w=4579&h=2576&m=4&q=80) <small>www.msn.com</small>Silent assassin Umar Nurmagomedov back to make some noise at UFC 321 in ...

Umar Nurmagomedov: 'We're Not Perfect, But We Will Try To Become'
-----------------------------------------------------------------

 ![Umar Nurmagomedov: 'We're not perfect, but we will try to become'](https://mmajunkie.usatoday.com/gcdn/authoring/authoring-images/2025/10/25/SMMA/86904561007-umar-nurmagomedov-def-mario-bautista-ufc-321-9570.jpg?crop=5468,3077,x0,y285&width=3200&height=1801&format=pjpg&auto=webp) <small>mmajunkie.usatoday.com</small>Umar Nurmagomedov: 'We're not perfect, but we will try to become'

Khabib Sees Two Options For Umar Nurmagomedov's Next UFC Fight
--------------------------------------------------------------

 ![Khabib sees two options for Umar Nurmagomedov's next UFC fight](https://mmajunkie.usatoday.com/gcdn/authoring/authoring-images/2026/01/24/SMMA/88342098007-islam-makhachev-umar-nurmagomedov-khabib-nurmagomedov-ufc-324-prefight.png?crop=899,506,x0,y0&width=899&height=506&format=pjpg&auto=webp) <small>mmajunkie.usatoday.com</small>Khabib sees two options for Umar Nurmagomedov's next UFC fight

Umar Nurmagomedov Fight Week Interview | UFC Fight Night: Rozenstruik
---------------------------------------------------------------------

 ![Umar Nurmagomedov Fight Week Interview | UFC Fight Night: Rozenstruik](https://dmxg5wxfqgb4u.cloudfront.net/styles/gallery_collapsed_desktop_1x/s3/2024-02/022824-UMAR-NURMAGOMEDOV-fight-week-interview.jpg?itok=0sPwzIvF) <small>www.ufc.com</small>Umar Nurmagomedov Fight Week Interview | UFC Fight Night: Rozenstruik ...

Umar Nurmagomedov Vs. Jack Shore Booked For March 19 - MMAmania.com
-------------------------------------------------------------------

 ![Umar Nurmagomedov vs. Jack Shore booked for March 19 - MMAmania.com](https://cdn.vox-cdn.com/thumbor/xjlWTOubI35WHuDGaojf1YUk_CE=/0x0:3446x2396/1200x800/filters:focal(1433x545:1983x1095)/cdn.vox-cdn.com/uploads/chorus_image/image/70163101/1297441732.0.jpg) <small>www.mmamania.com</small>Umar Nurmagomedov vs. Jack Shore booked for March 19 - MMAmania.com

Vengeance First! Islam Makhachev Picks Merab Dvalishvili For Umar
-----------------------------------------------------------------

 ![Vengeance first! Islam Makhachev picks Merab Dvalishvili for Umar](https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA1T1hXb.img?w=2252&h=1501&m=4&q=93) <small>www.msn.com</small>Vengeance first! Islam Makhachev picks Merab Dvalishvili for Umar ...

Undefeated Umar Nurmagomedov Gets Next UFC Assignment, Will Face Raoni
----------------------------------------------------------------------

 ![Undefeated Umar Nurmagomedov gets next UFC assignment, will face Raoni](https://mmajunkie.usatoday.com/gcdn/authoring/images/smg/2025/03/02/SMMA/81056456007-91-2556319.jpeg?width=660&height=372&fit=crop&format=pjpg&auto=webp) <small>mmajunkie.usatoday.com</small>Undefeated Umar Nurmagomedov gets next UFC assignment, will face Raoni ...

MMA Fighting | Who Would You Want To See Sean O'Malley Fight Next
-----------------------------------------------------------------

 ![MMA Fighting | Who would you want to see Sean O'Malley fight next](https://lookaside.instagram.com/seo/google_widget/crawler/?media_id=3538264852739886244) <small>www.instagram.com</small>MMA Fighting | Who would you want to see Sean O'Malley fight next ...

Umar Nurmagomedov Next Fight 2026
---------------------------------

 ![Umar Nurmagomedov Next Fight 2026](https://lookaside.instagram.com/seo/google_widget/crawler/?media_id=3817542564938064948) <small>www.instagram.com</small>Umar Nurmagomedov Next Fight 2026

Umar Nurmagomedov: UFC Champ Merab Dvalishvili Delaying Title Fight
-------------------------------------------------------------------

 ![Umar Nurmagomedov: UFC champ Merab Dvalishvili delaying title fight](https://mmajunkie.usatoday.com/gcdn/authoring/images/smg/2024/10/14/SMGW/75675166007-91-2760687.png?crop=1919,1079,x0,y0&width=1919&height=1079&format=pjpg&auto=webp) <small>mmajunkie.usatoday.com</small>Umar Nurmagomedov: UFC champ Merab Dvalishvili delaying title fight ...

UFC 324: Full Fight Results, Winners, And Highlights
----------------------------------------------------

 ![UFC 324: Full Fight Results, Winners, and Highlights](https://www.totalprosports.com/wp-content/uploads/2025/02/Umar-Nurmagomedov-1024x563.jpg) <small>www.totalprosports.com</small>UFC 324: Full Fight Results, Winners, and Highlights

4 Merab Dvalishvili Next Fight Options After UFC 320, Including Alex
--------------------------------------------------------------------

 ![4 Merab Dvalishvili Next Fight Options After UFC 320, Including Alex](https://s.yimg.com/ny/api/res/1.2/z6TB19NNGakembKlLt2cJg--/YXBwaWQ9aGlnaGxhbmRlcjt3PTk2MDtoPTY1NDtjZj13ZWJw/https://media.zenfs.com/en/sportsnaut_articles_397/d1c1b8579ed6b6b7eb687186311a4a43) <small>sports.yahoo.com</small>4 Merab Dvalishvili Next Fight Options After UFC 320, Including Alex ...

After His Win At UFC 324, What’s Next For Umar Nurmagomedov?
------------------------------------------------------------

 ![After his win at UFC 324, what’s next for Umar Nurmagomedov?](https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA1V1qUH.img?w=1250&h=834&m=4&q=81) <small>www.msn.com</small>After his win at UFC 324, what’s next for Umar Nurmagomedov?

UFC 324: Umar Nurmagomedov Post-fight Interview
-----------------------------------------------

 ![UFC 324: Umar Nurmagomedov post-fight interview](https://mmajunkie.usatoday.com/gcdn/authoring/authoring-images/2026/01/25/USAT/88344880007-umar-nurmagomedov-mxf-17-58-37-09-still-001.jpg?crop=3839,2159,x0,y0&width=3200&height=1800&format=pjpg&auto=webp) <small>mmajunkie.usatoday.com</small>UFC 324: Umar Nurmagomedov post-fight interview

UFC 321: Umar Nurmagomedov Full Post-fight Interview
----------------------------------------------------

 ![UFC 321: Umar Nurmagomedov full post-fight interview](https://mmajunkie.usatoday.com/gcdn/authoring/authoring-images/2025/10/25/SMMA/86904866007-umar.jpg?crop=1919,1079,x0,y0&width=1919&height=1079&format=pjpg&auto=webp) <small>mmajunkie.usatoday.com</small>UFC 321: Umar Nurmagomedov full post-fight interview

“I Do Not Feel Good About This Guy Fighting Yan Or Merab” – Fans
----------------------------------------------------------------

 ![“I Do Not Feel Good About This Guy Fighting Yan Or Merab” – Fans](https://media.mmanews.com/uploads/2026/01/Umar-Nurmagomedov.png) <small>www.mmanews.com</small>“I Do Not Feel Good About This Guy Fighting Yan Or Merab” – Fans ...

Umar Nurmagomedov Set To Face Ex-UFC Champion As Khabib Confirms Next
---------------------------------------------------------------------

 ![Umar Nurmagomedov Set to Face Ex-UFC Champion as Khabib Confirms Next](https://www.yardbarker.com/media/0/8/088bc75b2fdf6c4e5f25ae2e5743dcd286250241/thumb_16x9/Umar-Nurmagomedov-2.jpg) <small>www.yardbarker.com</small>Umar Nurmagomedov Set to Face Ex-UFC Champion as Khabib Confirms Next ...

UFC Fight Night 238 Results: Umar Nurmagomedov Survives Knockdown, Wins
-----------------------------------------------------------------------

 ![UFC Fight Night 238 results: Umar Nurmagomedov survives knockdown, wins](https://mmajunkie.usatoday.com/gcdn/authoring/images/smg/2025/02/24/SMMA/80013311007-91-2720702.jpeg?width=660&height=441&fit=crop&format=pjpg&auto=webp) <small>mmajunkie.usatoday.com</small>UFC Fight Night 238 results: Umar Nurmagomedov survives knockdown, wins ...

Umar Nurmagomedov Names Potential Opponents For Next Fight
----------------------------------------------------------

 ![Umar Nurmagomedov Names Potential Opponents for Next Fight](https://www1-cdn.sherdog.com/_images/headers/20251026022646_20251025092615_11_GettyImages2243271087.JPG) <small>www.sherdog.com</small>Umar Nurmagomedov Names Potential Opponents for Next Fight

MMA Theory | Next Matchups: UFC Seattle. Song Yadong Vs Umar
------------------------------------------------------------

 ![MMA Theory | Next Matchups: UFC Seattle. Song Yadong vs Umar](https://lookaside.instagram.com/seo/google_widget/crawler/?media_id=3574101219031961817) <small>www.instagram.com</small>MMA Theory | Next Matchups: UFC Seattle. Song Yadong vs Umar ...

Umar Nurmagomedov’s Camp Confident He’s Next In Line For UFC Title Shot
-----------------------------------------------------------------------

 ![Umar Nurmagomedov’s Camp Confident He’s Next in Line for UFC Title Shot](https://www1-cdn.sherdog.com/_images/headers/20240916011733_20240803062145_GettyImages2165152707.JPG) <small>www.sherdog.com</small>Umar Nurmagomedov’s Camp Confident He’s Next in Line for UFC Title Shot

Umar Nurmagomedov Vs. Jack Shore Targeted For March 2022 - FIGHT SPORTS
-----------------------------------------------------------------------

 ![Umar Nurmagomedov Vs. Jack Shore Targeted For March 2022 - FIGHT SPORTS](https://www.fightsports.tv/wp-content/uploads/Umar-Nurmagomedov-min-711x430.jpg) <small>www.fightsports.tv</small>Umar Nurmagomedov Vs. Jack Shore Targeted For March 2022 - FIGHT SPORTS

Umar Nurmagomedov Fought With Broken Hand, But Didn't Tell Coach, In
--------------------------------------------------------------------

 ![Umar Nurmagomedov Fought With Broken Hand, But Didn't Tell Coach, In](https://d.newsweek.com/en/full/2570659/umar-nurmagomedov.jpg) <small>www.newsweek.com</small>Umar Nurmagomedov Fought With Broken Hand, But Didn't Tell Coach, In ...

Khabib: Umar Nurmagomedov Will Expose 'nervous' Merab Dvalishvili At
--------------------------------------------------------------------

 ![Khabib: Umar Nurmagomedov will expose 'nervous' Merab Dvalishvili at](https://mmajunkie.usatoday.com/gcdn/authoring/images/smg/2024/12/06/SMGW/76831919007-91-2790903.jpeg?width=660&height=396&fit=crop&format=pjpg&auto=webp) <small>mmajunkie.usatoday.com</small>Khabib: Umar Nurmagomedov will expose 'nervous' Merab Dvalishvili at ...

Ufc rankings: umar nurmagomedov surges after abu dhabi win. Undefeated umar nurmagomedov gets next ufc assignment, will face raoni .... Ufc news: umar nurmagomedov's mystery opponent finally revealed ...
