---
title: "Crime Radar Flagstaff Az - Crimeradar: safety alerts"
description: "Satellite radar map for flagstaff az – kmfp"
date: "2026-04-28"
categories:
- "Uncategorized"
images:
- "https://www.doorprofit.com/crime-map-images/flagstaff-AZ-crime-map.webp"
featuredImage: "https://ewscripps.brightspotcdn.com/dims4/default/cd7acc2/2147483647/strip/true/crop/1280x720+0+0/resize/2560x1440!/quality/90/?url=http:%2F%2Fewscripps-brightspot.s3.amazonaws.com%2F66%2Fa1%2F42851ed84e9c91ada42baec9d0ed%2Ffalling-violent-0108-2.jpg"
featured_image: "https://images.crimegrade.org/map/property-rates/property-crime-per-capita-map-sunnyside-flagstaff-flagstaff-az.webp"
image: "https://bloximages.chicago2.vip.townnews.com/azdailysun.com/content/tncms/assets/v3/editorial/d/71/d71f5b11-d2d7-4401-88c6-3e713c79422e/6984b8319dcbf.image.png?resize=753%2C500"
---

If you are searching about Crime in Flagstaff, Arizona (AZ): murders, rapes, robberies, assaults you've visit to the right page. We have 34 Images about Crime in Flagstaff, Arizona (AZ): murders, rapes, robberies, assaults like Flagstaff Crime Rates and Statistics - NeighborhoodScout, The Safest and Most Dangerous Places in Flagstaff, AZ: Crime Maps and and also Interactive Hail Maps - Hail Map for Flagstaff, AZ. Here you go:

Crime In Flagstaff, Arizona (AZ): Murders, Rapes, Robberies, Assaults
---------------------------------------------------------------------

 ![Crime in Flagstaff, Arizona (AZ): murders, rapes, robberies, assaults](https://pics4.city-data.com/sgraphs/crime/crime_crime_index-Flagstaff-AZ.png) <small>www.city-data.com</small>Crime in Flagstaff, Arizona (AZ): murders, rapes, robberies, assaults ...

Flagstaff City Council Approves Expedited Purchase Of New Police
----------------------------------------------------------------

 ![Flagstaff City Council approves expedited purchase of new police](https://bloximages.chicago2.vip.townnews.com/azdailysun.com/content/tncms/assets/v3/editorial/a/51/a51fd40c-8844-4677-95bc-eaa49881887c/5e5d9bac6515c.image.jpg?crop=1878%2C986%2C111%2C0&resize=1200%2C630&order=crop%2Cresize) <small>azdailysun.com</small>Flagstaff City Council approves expedited purchase of new police ...

CrimeRadar: Safety Alerts - Apps On Google Play
-----------------------------------------------

 ![CrimeRadar: Safety Alerts - Apps on Google Play](https://play-lh.googleusercontent.com/KjE_VSewPhBADO9eBGl7V4UCI31LHjTR0ll62GEcuiPuDFO_97oRb6F4Pgkq6pREzBTc6muSDF_P23owc4f8Bg) <small>play.google.com</small>CrimeRadar: Safety Alerts - Apps on Google Play

My Glendale Arizona Weather Station Radar
-----------------------------------------

 ![My Glendale Arizona Weather Station Radar](https://radar.weather.gov/ridge/standard/KFSX_loop.gif) <small>www.myglendalewxs.com</small>My Glendale Arizona Weather Station Radar

Interactive Hail Maps - Hail Map For Flagstaff, AZ
--------------------------------------------------

 ![Interactive Hail Maps - Hail Map for Flagstaff, AZ](https://s3.amazonaws.com/content.interactivehailmaps.com/radar-images/radar-image-1223198.png) <small>www.interactivehailmaps.com</small>Interactive Hail Maps - Hail Map for Flagstaff, AZ

Flagstaff, AZ Violent Crime Rates And Maps | CrimeGrade.org
-----------------------------------------------------------

 ![Flagstaff, AZ Violent Crime Rates and Maps | CrimeGrade.org](https://images.crimegrade.org/map/violence-rates/violent-crime-per-capita-map-flagstaff-az.webp) <small>crimegrade.org</small>Flagstaff, AZ Violent Crime Rates and Maps | CrimeGrade.org

PD: Man Arrested After Argument Leads To Deadly Stabbing In Flagstaff
---------------------------------------------------------------------

 ![PD: Man arrested after argument leads to deadly stabbing in Flagstaff](https://ewscripps.brightspotcdn.com/dims4/default/f684182/2147483647/strip/true/crop/2016x1134+0+189/resize/1280x720!/quality/90/?url=https:%2F%2Fewscripps.brightspotcdn.com%2F88%2F41%2F854184594a5a98b853f95e12f5d3%2F3-28-flagstaff-homicide-stabbing.jpg) <small>www.abc15.com</small>PD: Man arrested after argument leads to deadly stabbing in Flagstaff

Flagstaff Live Weather Radar At Johnny Moe Blog
-----------------------------------------------

 ![Flagstaff Live Weather Radar at Johnny Moe blog](https://pbs.twimg.com/tweet_video_thumb/FNCdhmSVgAMkNAl.jpg) <small>storage.googleapis.com</small>Flagstaff Live Weather Radar at Johnny Moe blog

South Flagstaff, Flagstaff, AZ Violent Crime Rates And Maps
-----------------------------------------------------------

 ![South Flagstaff, Flagstaff, AZ Violent Crime Rates and Maps](https://images.crimegrade.org/map/violence-rates/violent-crime-per-capita-map-south-flagstaff-flagstaff-az.webp) <small>crimegrade.org</small>South Flagstaff, Flagstaff, AZ Violent Crime Rates and Maps ...

Two Dead As AZDPS Ranger Helicopter Crashes During Active Shooter
-----------------------------------------------------------------

 ![Two dead as AZDPS Ranger Helicopter crashes during active shooter](https://bloximages.chicago2.vip.townnews.com/azdailysun.com/content/tncms/assets/v3/editorial/d/71/d71f5b11-d2d7-4401-88c6-3e713c79422e/6984b8319dcbf.image.png?resize=753%2C500) <small>azdailysun.com</small>Two dead as AZDPS Ranger Helicopter crashes during active shooter ...

Guilty Plea Reached In 2024 Downtown Flagstaff Homicide Case | Crime
--------------------------------------------------------------------

 ![Guilty plea reached in 2024 downtown Flagstaff homicide case | Crime](https://bloximages.chicago2.vip.townnews.com/azdailysun.com/content/tncms/assets/v3/editorial/4/fc/4fc0556c-de7c-11ef-b628-0b83753eae40/679bc3f3ba43c.preview.jpg?crop=1662%2C873%2C51%2C102&resize=1200%2C630&order=crop%2Cresize) <small>azdailysun.com</small>Guilty plea reached in 2024 downtown Flagstaff homicide case | Crime ...

Flagstaff, AZ Crime Rate &amp; More | DoorProfit
------------------------------------------------

 ![Flagstaff, AZ Crime Rate & More | DoorProfit](https://www.doorprofit.com/crime-map-images/flagstaff-AZ-crime-map.webp) <small>www.doorprofit.com</small>Flagstaff, AZ Crime Rate &amp; More | DoorProfit

DATA: A Look At Violent Crime Rates By County In Arizona
--------------------------------------------------------

 ![DATA: A look at violent crime rates by county in Arizona](https://ewscripps.brightspotcdn.com/dims4/default/0522bd0/2147483647/strip/true/crop/1280x720+0+0/resize/2560x1440!/quality/90/?url=http:%2F%2Fewscripps-brightspot.s3.amazonaws.com%2F6b%2F0a%2Ffcd0562b4dae9697116d948201a8%2Fwith-firearms2-0108-2.jpg) <small>www.abc15.com</small>DATA: A look at violent crime rates by county in Arizona

Metro Interactive Radar On 12NEWS In Phoenix | 12news.com
---------------------------------------------------------

 ![Metro Interactive Radar on 12NEWS in Phoenix | 12news.com](http://cdn.tegna-media.com/kpnx/weather/12news_flagstaffsatrad_16x9.jpg) <small>www.12news.com</small>Metro Interactive Radar on 12NEWS in Phoenix | 12news.com

Flagstaff, AZ Crime Rates: Stats &amp; Map
------------------------------------------

 ![Flagstaff, AZ Crime Rates: Stats & Map](https://www.areavibes.com/images/banner-cr.png) <small>www.areavibes.com</small>Flagstaff, AZ Crime Rates: Stats &amp; Map

Sunnyside-Flagstaff, Flagstaff, AZ Property Crime Rates And Maps
----------------------------------------------------------------

 ![Sunnyside-Flagstaff, Flagstaff, AZ Property Crime Rates and Maps](https://images.crimegrade.org/map/property-rates/property-crime-per-capita-map-sunnyside-flagstaff-flagstaff-az.webp) <small>crimegrade.org</small>Sunnyside-Flagstaff, Flagstaff, AZ Property Crime Rates and Maps ...

Flagstaff, Az Violent Crime Rates And Maps – MVWEI
--------------------------------------------------

 ![Flagstaff, Az Violent Crime Rates And Maps – MVWEI](https://images.crimegrade.org/map/violence-rates/violent-crime-per-capita-map-85051.webp) <small>high-professionals.de</small>Flagstaff, Az Violent Crime Rates And Maps – MVWEI

FPD: Flagstaff Man Shot By Police Had Drawn Gun On Officers | Crime And
-----------------------------------------------------------------------

 ![FPD: Flagstaff man shot by police had drawn gun on officers | Crime and](https://bloximages.chicago2.vip.townnews.com/azdailysun.com/content/tncms/assets/v3/editorial/4/a2/4a28ae94-3a42-59af-ae9e-0763d9edbb5a/5e5d31de0b072.image.jpg?crop=1662%2C873%2C0%2C186&resize=1200%2C630&order=crop%2Cresize) <small>azdailysun.com</small>FPD: Flagstaff man shot by police had drawn gun on officers | Crime and ...

Crime And Courts | Azdailysun.com
---------------------------------

 ![Crime and Courts | azdailysun.com](https://bloximages.chicago2.vip.townnews.com/azdailysun.com/content/tncms/assets/v3/editorial/2/c1/2c1e215c-9886-11ef-a3e3-7f15fe747934/67253d3b76e2f.preview.jpg?crop=1683%2C950%2C48%2C14&resize=1333%2C752&order=crop%2Cresize) <small>azdailysun.com</small>Crime and Courts | azdailysun.com

Crime In Flagstaff, Arizona (AZ): Murders, Rapes, Robberies, Assaults
---------------------------------------------------------------------

 ![Crime in Flagstaff, Arizona (AZ): murders, rapes, robberies, assaults](https://pics4.city-data.com/sgraphs/crime/crimes-by-type-2025-Flagstaff-AZ.png) <small>www.city-data.com</small>Crime in Flagstaff, Arizona (AZ): murders, rapes, robberies, assaults ...

Satellite Radar Map For Flagstaff Az – KMFP
-------------------------------------------

 ![Satellite Radar Map For Flagstaff Az – KMFP](https://lookaside.fbsbx.com/lookaside/crawler/media/?media_id=6351778531540612&get_thumbnail=1) <small>learn.catherinecranephoto.com</small>Satellite Radar Map For Flagstaff Az – KMFP

Crime In Flagstaff, Arizona (AZ): Murders, Rapes, Robberies, Assaults
---------------------------------------------------------------------

 ![Crime in Flagstaff, Arizona (AZ): murders, rapes, robberies, assaults](https://pics4.city-data.com/sgraphs/crime/crimes-per-weekday-and-hour-Flagstaff-AZ.png) <small>www.city-data.com</small>Crime in Flagstaff, Arizona (AZ): murders, rapes, robberies, assaults ...

Flagstaff Crime Statistics: Arizona (AZ) - CityRating.com
---------------------------------------------------------

 ![Flagstaff Crime Statistics: Arizona (AZ) - CityRating.com](https://www.cityrating.com/charts/arizona/flagstaff-crime-2026.png) <small>www.cityrating.com</small>Flagstaff Crime Statistics: Arizona (AZ) - CityRating.com

Flagstaff Police Receive $90K Grant To Combat Driving Under The
---------------------------------------------------------------

 ![Flagstaff police receive $90K grant to combat driving under the](https://bloximages.chicago2.vip.townnews.com/azdailysun.com/content/tncms/assets/v3/editorial/4/3f/43f53304-27e8-4360-a5d7-e3710befe893/67f3ffbe8001c.preview.jpg?crop=1209%2C635%2C51%2C260&resize=1200%2C630&order=crop%2Cresize) <small>azdailysun.com</small>Flagstaff police receive $90K grant to combat driving under the ...

Crime Maps Track Flagstaff's Hot Spots | Crime And Courts | Azdailysun.com
--------------------------------------------------------------------------

 ![Crime maps track Flagstaff's hot spots | Crime and Courts | azdailysun.com](https://bloximages.chicago2.vip.townnews.com/azdailysun.com/content/tncms/assets/v3/editorial/a/63/a63a5f74-e177-5c85-b0e3-bbec120c1958/5e5d59f8278ff.image.jpg?crop=906%2C476%2C0%2C89&resize=906%2C476&order=crop%2Cresize) <small>azdailysun.com</small>Crime maps track Flagstaff's hot spots | Crime and Courts | azdailysun.com

DATA: A Look At Violent Crime Rates By County In Arizona
--------------------------------------------------------

 ![DATA: A look at violent crime rates by county in Arizona](https://ewscripps.brightspotcdn.com/dims4/default/cd7acc2/2147483647/strip/true/crop/1280x720+0+0/resize/2560x1440!/quality/90/?url=http:%2F%2Fewscripps-brightspot.s3.amazonaws.com%2F66%2Fa1%2F42851ed84e9c91ada42baec9d0ed%2Ffalling-violent-0108-2.jpg) <small>www.abc15.com</small>DATA: A look at violent crime rates by county in Arizona

Flagstaff Live Weather Radar At Johnny Moe Blog
-----------------------------------------------

 ![Flagstaff Live Weather Radar at Johnny Moe blog](https://pbs.twimg.com/ext_tw_video_thumb/1681077856095604736/pu/img/CcqvudQT2vGNz6JG.jpg) <small>storage.googleapis.com</small>Flagstaff Live Weather Radar at Johnny Moe blog

The Safest And Most Dangerous Places In Sunnyside-Flagstaff, Flagstaff
----------------------------------------------------------------------

 ![The Safest and Most Dangerous Places in Sunnyside-Flagstaff, Flagstaff](https://images.crimegrade.org/map/overall-total/total-crime-map-sunnyside-flagstaff-flagstaff-az.webp) <small>crimegrade.org</small>The Safest and Most Dangerous Places in Sunnyside-Flagstaff, Flagstaff ...

CrimeRadar: Dispatch Alerts For Android - Free App
--------------------------------------------------

 ![CrimeRadar: Dispatch Alerts for Android - Free App](https://www.appbrain.com/share-img?pkg=com.newsbreak.crimeradar&width=764&height=400&maxCacheSeconds=3600) <small>www.appbrain.com</small>CrimeRadar: Dispatch Alerts for Android - Free App

The Safest And Most Dangerous Places In Sunnyside-Flagstaff, Flagstaff
----------------------------------------------------------------------

 ![The Safest and Most Dangerous Places in Sunnyside-Flagstaff, Flagstaff](https://images.crimegrade.org/map/crime-rate-maps/safest-places-in-sunnyside-flagstaff-flagstaff-az.webp) <small>crimegrade.org</small>The Safest and Most Dangerous Places in Sunnyside-Flagstaff, Flagstaff ...

Flagstaff Crime Rates And Statistics - NeighborhoodScout
--------------------------------------------------------

 ![Flagstaff Crime Rates and Statistics - NeighborhoodScout](https://s3.amazonaws.com/crime-maps-aws.neighborhoodscout.com/flagstaff-az-crime-map.png) <small>www.neighborhoodscout.com</small>Flagstaff Crime Rates and Statistics - NeighborhoodScout

Reports: Man Dead After Police Shooting Outside Flagstaff Mall | 12news.com
---------------------------------------------------------------------------

 ![Reports: Man dead after police shooting outside Flagstaff Mall | 12news.com](https://media.12news.com/assets/KPNX/images/e16be041-2b11-4e2f-9ebc-392d2e726b40/e16be041-2b11-4e2f-9ebc-392d2e726b40_1140x641.jpg) <small>www.12news.com</small>Reports: Man dead after police shooting outside Flagstaff Mall | 12news.com

Flagstaff, AZ Theft Crime Rates And Maps | CrimeGrade.org
---------------------------------------------------------

 ![Flagstaff, AZ Theft Crime Rates and Maps | CrimeGrade.org](https://images.crimegrade.org/map/theft-rates/theft-per-capita-map-flagstaff-az.webp) <small>crimegrade.org</small>Flagstaff, AZ Theft Crime Rates and Maps | CrimeGrade.org

The Safest And Most Dangerous Places In Flagstaff, AZ: Crime Maps And
---------------------------------------------------------------------

 ![The Safest and Most Dangerous Places in Flagstaff, AZ: Crime Maps and](https://images.crimegrade.org/map/overall-total/total-crime-map-flagstaff-az.webp) <small>crimegrade.org</small>The Safest and Most Dangerous Places in Flagstaff, AZ: Crime Maps and ...

Crime and courts. South flagstaff, flagstaff, az violent crime rates and maps .... Flagstaff, az theft crime rates and maps
