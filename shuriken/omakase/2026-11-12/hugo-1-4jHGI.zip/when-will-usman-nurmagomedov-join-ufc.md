---
title: "When Will Usman Nurmagomedov Join Ufc - Islam makhachev stumps for usman nurmagomedov to join ufc: ‘he’s ready"
description: "How would usman nurmagomedov do in ufc&#039;s lightweight division?"
date: "2026-07-13"
categories:
- "Uncategorized"
images:
- "https://www.totalprosports.com/wp-content/uploads/2025/04/Khabib-Nurmagomedov-1200x675.jpg"
featuredImage: "https://mmajunkie.usatoday.com/gcdn/authoring/authoring-images/2025/12/11/SMMA/87710605007-usman.jpg?crop=1918,1078,x1,y0&amp;width=1918&amp;height=1078&amp;format=pjpg&amp;auto=webp"
featured_image: "https://www.totalprosports.com/wp-content/uploads/2024/09/Khabib-Nurmagomedov-and-Usman-Nurmagomedov-1.jpg"
image: "https://inthecage.pl/wp-content/uploads/2025/11/Zrzut-ekranu-2025-11-20-204721.png"
---

If you are looking for The 11 greatest Russian MMA fighters of all time - Lentedesportiva you've came to the right place. We have 35 Pictures about The 11 greatest Russian MMA fighters of all time - Lentedesportiva like Islam Makhachev on 'perfect time' for Usman Nurmagomedov to join UFC, Team Khabib's Coach Addresses Whether PFL Champ Usman Will Ever Join UFC and also Usman Nurmagomedov: Umar willing to beat all UFC top 10 for title shot. Here it is:

The 11 Greatest Russian MMA Fighters Of All Time - Lentedesportiva
------------------------------------------------------------------

 ![The 11 greatest Russian MMA fighters of all time - Lentedesportiva](https://lentedesportiva.com/wp-content/uploads/2025/08/UsmanNurmagomedov.png) <small>lentedesportiva.com</small>The 11 greatest Russian MMA fighters of all time - Lentedesportiva

Islam Makhachev Stumps For Usman Nurmagomedov To Join UFC: ‘He’s Ready
----------------------------------------------------------------------

 ![Islam Makhachev stumps for Usman Nurmagomedov to join UFC: ‘He’s ready](https://platform.mmafighting.com/wp-content/uploads/sites/109/2026/08/gettyimages-2288531496.jpg?quality=90&strip=all&crop=0%2C15.047638996396%2C100%2C78.534031413613&w=1200) <small>www.mmafighting.com</small>Islam Makhachev stumps for Usman Nurmagomedov to join UFC: ‘He’s ready ...

Daniel Cormier Challenges Usman Nurmagomedov To Join UFC: ‘You Think
--------------------------------------------------------------------

 ![Daniel Cormier Challenges Usman Nurmagomedov To Join UFC: ‘You Think](https://middleeasy.com/wp-content/uploads/2026/08/daniel-cormier-usman-nurmagomedov-ufc-330-1140x641.jpg) <small>middleeasy.com</small>Daniel Cormier Challenges Usman Nurmagomedov To Join UFC: ‘You Think ...

Usman Nurmagomedov To Defend PFL Title Against Britain’s Alfie Davis
--------------------------------------------------------------------

 ![Usman Nurmagomedov to defend PFL title against Britain’s Alfie Davis](https://static.independent.co.uk/2025/11/20/14/59/Usman-Nurmagomedov.jpeg) <small>www.independent.co.uk</small>Usman Nurmagomedov to defend PFL title against Britain’s Alfie Davis ...

Usman Nurmagomedov Challenges The UFC Elite: Dominance Beyond The Cage
----------------------------------------------------------------------

 ![Usman Nurmagomedov Challenges the UFC Elite: Dominance Beyond the Cage](https://mmamag.ma/en/wp-content/uploads/2026/02/Usman-Nurmagomedov-affronte-Ilia-Topuria-Arman-Tsarukyan-1024x576-1-696x392.jpg) <small>mmamag.ma</small>Usman Nurmagomedov Challenges the UFC Elite: Dominance Beyond the Cage ...

Usman Nurmagomedov Suggests He Would Choke UFC Champion Ilia Topuria
--------------------------------------------------------------------

 ![Usman Nurmagomedov suggests he would choke UFC champion Ilia Topuria](https://static.independent.co.uk/2026/02/09/12/00/Usman-Nurmagomedov-PFL-Alfie-Davis.jpeg?trim=0,0,0,0&width=1200&height=800&crop=1200:800) <small>www.independent.co.uk</small>Usman Nurmagomedov suggests he would choke UFC champion Ilia Topuria ...

Islam Makhachev Says 'it's A Good Time' For Bellator Lightweight
----------------------------------------------------------------

 ![Islam Makhachev says 'it's a good time' for Bellator lightweight](https://sportshub.cbsistatic.com/i/r/2025/01/10/5110d1df-725c-4814-b8cf-80f1e70dce3d/thumbnail/1200x675/8bc868015a82d513cbd26950e30865d9/islam-makhachev-press.jpg) <small>www.cbssports.com</small>Islam Makhachev says 'it's a good time' for Bellator lightweight ...

Khabib Nurmagomedov Lauds Cousin Usman Nurmagomedov As "future Of This
----------------------------------------------------------------------

 ![Khabib Nurmagomedov lauds cousin Usman Nurmagomedov as "future of this](https://staticg.sportskeeda.com/editor/2024/09/2bccb-17256976097553-1920.jpg) <small>www.sportskeeda.com</small>Khabib Nurmagomedov lauds cousin Usman Nurmagomedov as "future of this ...

Usman Nurmagomedov Determined To Defend His Title After Brother Umar’s
----------------------------------------------------------------------

 ![Usman Nurmagomedov Determined To Defend His Title After Brother Umar’s](https://www.totalprosports.com/wp-content/uploads/2025/01/Usman-Nurmagomedov-and-Umar-Nurmagomedov.jpg) <small>www.totalprosports.com</small>Usman Nurmagomedov Determined To Defend His Title After Brother Umar’s ...

How Would Usman Nurmagomedov Do In UFC's Lightweight Division?
--------------------------------------------------------------

 ![How would Usman Nurmagomedov do in UFC's Lightweight Division?](https://www.thescrap.co/wp-content/uploads/2025/01/Usman-Nurmagomedov.jpg) <small>www.thescrap.co</small>How would Usman Nurmagomedov do in UFC's Lightweight Division?

Team Khabib's Coach Addresses Whether PFL Champ Usman Will Ever Join UFC
------------------------------------------------------------------------

 ![Team Khabib's Coach Addresses Whether PFL Champ Usman Will Ever Join UFC](https://www.totalprosports.com/wp-content/uploads/2024/09/Khabib-Nurmagomedov-and-Usman-Nurmagomedov.jpg) <small>www.totalprosports.com</small>Team Khabib's Coach Addresses Whether PFL Champ Usman Will Ever Join UFC

Islam Makhachev : Usman Nurmagomedov Have To Accept A Pay Cut To Join
---------------------------------------------------------------------

 ![Islam Makhachev : Usman Nurmagomedov Have to Accept a Pay Cut to join](https://i.ytimg.com/vi/Ewz8Kx_d3ck/oardefault.jpg?sqp=-oaymwEoCJUDENAFSFqQAgHyq4qpAxcIARUAAAAAJQAAyEI9AICiQ3gBuAL3GA==&rs=AOn4CLDoHJ11stGXP4uIzw4JY8rWio3eEQ&usqp=CCk) <small>www.youtube.com</small>Islam Makhachev : Usman Nurmagomedov Have to Accept a Pay Cut to join ...

Usman Nurmagomedov Outlines Future Pathway To The UFC Ahead Of Title
--------------------------------------------------------------------

 ![Usman Nurmagomedov outlines future pathway to the UFC ahead of title](https://bloodyelbow.com/wp-content/uploads/1/2024/10/GettyImages-2170781806.jpg) <small>bloodyelbow.com</small>Usman Nurmagomedov outlines future pathway to the UFC ahead of title ...

Bellator Champions Series: Usman Nurmagomedov Retains Lightweight Title
-----------------------------------------------------------------------

 ![Bellator Champions Series: Usman Nurmagomedov retains lightweight title](https://blogs.rdxsports.com/wp-content/uploads/2024/09/usman-nurmagomedov-1024x576.jpg) <small>blogs.rdxsports.com</small>Bellator Champions Series: Usman Nurmagomedov retains lightweight title ...

Usman Nurmagomedov Wraca Do Klatki. PFL Odsłania Pierwszą Walkę
---------------------------------------------------------------

 ![Usman Nurmagomedov wraca do klatki. PFL odsłania pierwszą walkę](https://inthecage.pl/wp-content/uploads/2025/11/Zrzut-ekranu-2025-11-20-204721.png) <small>inthecage.pl</small>Usman Nurmagomedov wraca do klatki. PFL odsłania pierwszą walkę ...

Team Khabib Nurmagomedov’s Coach Addresses Whether PFL Champ Usman Will
-----------------------------------------------------------------------

 ![Team Khabib Nurmagomedov’s Coach Addresses Whether PFL Champ Usman Will](https://www.totalprosports.com/wp-content/uploads/2024/09/Khabib-Nurmagomedov-and-Usman-Nurmagomedov-1.jpg) <small>newsdailyreportsph.blogspot.com</small>Team Khabib Nurmagomedov’s Coach Addresses Whether PFL Champ Usman Will ...

UFC - Umar Nurmagomedov Recadre Kamaru Usman
--------------------------------------------

 ![UFC - Umar Nurmagomedov recadre Kamaru Usman](https://lasueur.com/wp-content/uploads/2024/09/nurmagomedov-recadre-kamaru-usman-1054x593.jpg) <small>lasueur.com</small>UFC - Umar Nurmagomedov recadre Kamaru Usman

Usman Nurmagomedov: Umar Willing To Beat All UFC Top 10 For Title Shot
----------------------------------------------------------------------

 ![Usman Nurmagomedov: Umar willing to beat all UFC top 10 for title shot](https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA1UUFsc.img?w=4206&h=2805&m=4&q=75) <small>www.msn.com</small>Usman Nurmagomedov: Umar willing to beat all UFC top 10 for title shot

Daniel Cormier Challenges Usman Nurmagomedov To Join UFC
--------------------------------------------------------

 ![Daniel Cormier Challenges Usman Nurmagomedov to Join UFC](https://mmasucka.com/api/media/file/Daniel Cormier (right) and Usman Nurmagomedov (right).webp) <small>mmasucka.com</small>Daniel Cormier Challenges Usman Nurmagomedov to Join UFC

UFC Move For PFL Champ Usman Nurmagomedov Hinges On One Major Condition
-----------------------------------------------------------------------

 ![UFC Move for PFL Champ Usman Nurmagomedov Hinges on One Major Condition](https://mmauk.net/wp-content/uploads/2025/12/UFC-Move-for-PFL-Champ-Usman-Nurmagomedov-Hinges-on-One-Major-Condition.jpg) <small>mmauk.net</small>UFC Move for PFL Champ Usman Nurmagomedov Hinges on One Major Condition ...

Islam Makhachev Says The UFC's 'small Purses' Could Hold Up Usman
-----------------------------------------------------------------

 ![Islam Makhachev says the UFC's 'small purses' could hold up Usman](https://bloodyelbow.com/wp-content/uploads/1/2026/02/Khabib-Usman-1140x622.png) <small>bloodyelbow.com</small>Islam Makhachev says the UFC's 'small purses' could hold up Usman ...

UFC 311 Pre-event Facts: Umar Nurmagomedov Can Join Exclusive Club Of
---------------------------------------------------------------------

 ![UFC 311 pre-event facts: Umar Nurmagomedov can join exclusive club of](https://mmajunkie.usatoday.com/gcdn/authoring/images/smg/2025/01/14/SMGW/77702165007-91-2797681.jpeg?crop=999,563,x0,y18&width=999&height=563&format=pjpg&auto=webp) <small>mmajunkie.usatoday.com</small>UFC 311 pre-event facts: Umar Nurmagomedov can join exclusive club of ...

Fighters React To Usman Nurmagomedov's PFL Title Defense In Final
-----------------------------------------------------------------

 ![Fighters react to Usman Nurmagomedov's PFL title defense in final](https://hermes.media.static.aol.com/media/2026/08/01/20c54ea6-c679-39de-843a-c0fd4704743a/3fa78c04-db5f-4a67-8cf9-f0c939f0818c.jpg) <small>www.aol.com</small>Fighters react to Usman Nurmagomedov's PFL title defense in final ...

Javier Mendez: Usman Nurmagomedov Will Win The UFC Title | MMA News
-------------------------------------------------------------------

 ![Javier Mendez: Usman Nurmagomedov Will Win the UFC Title | MMA News](https://media.mmanews.com/uploads/2025/01/Usman-Nurmagomedov-at-PFL-Champions-Series.jpg) <small>www.mmanews.com</small>Javier Mendez: Usman Nurmagomedov Will Win the UFC Title | MMA News

MMA - Le Bellator De Retour En France En 2024 Avec Usman Nurmagomedov
---------------------------------------------------------------------

 ![MMA - Le Bellator de retour en France en 2024 avec Usman Nurmagomedov](https://lasueur.com/wp-content/uploads/2023/10/Usman-Nurmagomedov.jpg) <small>lasueur.com</small>MMA - Le Bellator de retour en France en 2024 avec Usman Nurmagomedov

Usman Nurmagomedov Extends Perfect Record With 'amazing' Win Over Paul
----------------------------------------------------------------------

 ![Usman Nurmagomedov extends perfect record with 'amazing' win over Paul](https://www.thenationalnews.com/resizer/v2/U2FCUNFAPRF25BZACFHECKACGM.jpg?auth=70773c6b29c05da0008b983da71eb337425d8b2a204af93e663530d5cc8160fa) <small>www.thenationalnews.com</small>Usman Nurmagomedov extends perfect record with 'amazing' win over Paul ...

Bellator Champion Usman Nurmagomedov Eyes UFC Move After Islam
--------------------------------------------------------------

 ![Bellator Champion Usman Nurmagomedov Eyes UFC Move After Islam](https://static.wixstatic.com/media/668b59_2e17438bb1734b7588d1e29c8a4c6340~mv2.jpg/v1/fill/w_987,h_576,al_c/668b59_2e17438bb1734b7588d1e29c8a4c6340~mv2.jpg) <small>www.fight.tv</small>Bellator Champion Usman Nurmagomedov Eyes UFC Move After Islam ...

Islam Makhachev On 'perfect Time' For Usman Nurmagomedov To Join UFC
--------------------------------------------------------------------

 ![Islam Makhachev on 'perfect time' for Usman Nurmagomedov to join UFC](https://mmajunkie.usatoday.com/gcdn/authoring/authoring-images/2026/02/07/SMMA/88570600007-usman-nurmagomedov-def-alfie-davis-pfl-road-to-dubai-44.JPG?crop=2399,1351,x0,y124&width=2399&height=1351&format=pjpg&auto=webp) <small>mmajunkie.usatoday.com</small>Islam Makhachev on 'perfect time' for Usman Nurmagomedov to join UFC

Islam Makhachev On 'perfect Time' For Usman Nurmagomedov To Join UFC
--------------------------------------------------------------------

 ![Islam Makhachev on 'perfect time' for Usman Nurmagomedov to join UFC](https://mmajunkie.usatoday.com/gcdn/authoring/images/smg/2024/08/08/SMGW/74730497007-islam-makhachev-ufc-302-ceremonial-weigh-ins.png?crop=887) <small>mmajunkie.usatoday.com</small>Islam Makhachev on 'perfect time' for Usman Nurmagomedov to join UFC

Legendary UFC Champs Boldly Predict Usman Nurmagomedov’s Fate Against
---------------------------------------------------------------------

 ![Legendary UFC Champs Boldly Predict Usman Nurmagomedov’s Fate Against](https://image-cdn.essentiallysports.com/wp-content/uploads/Khabib-Nurmagomedov-Usman-Nurmagomedov-1.jpg) <small>www.essentiallysports.com</small>Legendary UFC Champs Boldly Predict Usman Nurmagomedov’s Fate Against ...

Usman Nurmagomedov To Defend PFL Lightweight Title Feb. 7 - ESPN
----------------------------------------------------------------

 ![Usman Nurmagomedov to defend PFL lightweight title Feb. 7 - ESPN](https://a4.espncdn.com/combiner/i?img=%2Fphoto%2F2024%2F0228%2Fr1297663_1296x729_16-9.jpg) <small>www.espn.com</small>Usman Nurmagomedov to defend PFL lightweight title Feb. 7 - ESPN

Usman Nurmagomedov Outlines Future Pathway To The UFC Ahead Of Title
--------------------------------------------------------------------

 ![Usman Nurmagomedov outlines future pathway to the UFC ahead of title](https://bloodyelbow.com/wp-content/uploads/1/2025/01/Usman-Nurmagomedov-UFC-1140x622.png) <small>bloodyelbow.com</small>Usman Nurmagomedov outlines future pathway to the UFC ahead of title ...

Usman Nurmagomedov News ⋆ TotalProSports
----------------------------------------

 ![Usman Nurmagomedov News ⋆ TotalProSports](https://www.totalprosports.com/wp-content/uploads/2025/04/Khabib-Nurmagomedov-1200x675.jpg) <small>www.totalprosports.com</small>Usman Nurmagomedov News ⋆ TotalProSports

Usman Nurmagomedov On Behance
-----------------------------

 ![Usman Nurmagomedov on Behance](https://mir-s3-cdn-cf.behance.net/project_modules/1400/759ce6129823655.6172d3b829a76.jpg) <small>www.behance.net</small>Usman Nurmagomedov on Behance

Usman Nurmagomedov Addresses Potential UFC Move As PFL Deal Winds Down
----------------------------------------------------------------------

 ![Usman Nurmagomedov addresses potential UFC move as PFL deal winds down](https://mmajunkie.usatoday.com/gcdn/authoring/authoring-images/2025/12/11/SMMA/87710605007-usman.jpg?crop=1918,1078,x1,y0&width=1918&height=1078&format=pjpg&auto=webp) <small>mmajunkie.usatoday.com</small>Usman Nurmagomedov addresses potential UFC move as PFL deal winds down

Khabib nurmagomedov lauds cousin usman nurmagomedov as "future of this. Daniel cormier challenges usman nurmagomedov to join ufc: ‘you think .... Fighters react to usman nurmagomedov's pfl title defense in final
