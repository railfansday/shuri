---
title: "Elina Svitolina Age And Height - elina svitolina: age, height, country, titles, ranking, career stats ..."
description: "Elina svitolina husband, age, height, weight, net worth, career and"
date: "2026-01-28"
categories:
- "Uncategorized"
images:
- "https://superstarsbio.com/wp-content/uploads/2019/09/Elina-Svitolina-mole.jpg"
featuredImage: "https://superstarsbio.com/wp-content/uploads/2019/09/Elina-Svitolina-classy.jpg"
featured_image: "https://infotopbio.com/wp-content/uploads/2025/03/Elina-Svitolina-Husband-Age-Height-Weight-Net-Worth-Career-And-Full-Bio-4-1024x572.webp"
image: "https://healthyceleb.com/wp-content/uploads/2018/07/Elina-Svitolina-as-seen-in-May-2018-300x420.jpg"
---

If you are searching about Elina Svitolina - Biography, Height &amp; Life Story | Super Stars Bio you've came to the right place. We have 35 Pictures about Elina Svitolina - Biography, Height &amp; Life Story | Super Stars Bio like Elina Svitolina Height, Weight, Age, Boyfriend, Family, Facts, Biography, How Tall Is Elina Svitolina | Height Comparison Tool and also Elina Mykhailivna Svitolina Net Worth, Bio, Weight, Height, Age 2024. Here you go:

Elina Svitolina - Biography, Height &amp; Life Story | Super Stars Bio
----------------------------------------------------------------------

 ![Elina Svitolina - Biography, Height & Life Story | Super Stars Bio](https://superstarsbio.com/wp-content/uploads/2019/09/Elina-Svitolina-classy.jpg) <small>superstarsbio.com</small>Elina Svitolina - Biography, Height &amp; Life Story | Super Stars Bio

Elina Svitolina Bio, Net Worth, Wiki, Age, Height, Husband, Parents
-------------------------------------------------------------------

 ![Elina Svitolina Bio, Net worth, Wiki, Age, Height, Husband, Parents](https://i.pinimg.com/736x/90/40/91/9040913cea98cd4c579651e15c2f1d4b.jpg) <small>tr.pinterest.com</small>Elina Svitolina Bio, Net worth, Wiki, Age, Height, Husband, Parents ...

Elina Svitolina Biography 2026 Age, Height, Weight, Net Worth, Salary
---------------------------------------------------------------------

 ![Elina Svitolina Biography 2026 Age, Height, Weight, Net Worth, Salary](https://browvopetshop.com/wp-content/uploads/2025/07/Elina-Svitolina.jpg) <small>browvopetshop.com</small>Elina Svitolina Biography 2026 Age, Height, Weight, Net Worth, Salary ...

Elina Svitolina (Tennis Player) Wiki, Age, Height, Net Worth, Boyfriend
-----------------------------------------------------------------------

 ![Elina Svitolina (Tennis Player) Wiki, Age, Height, Net Worth, Boyfriend](https://i.ytimg.com/vi/Gg5FabfMWts/maxresdefault.jpg) <small>www.youtube.com</small>Elina Svitolina (Tennis Player) Wiki, Age, Height, Net Worth, Boyfriend ...

Elina Svitolina Net Worth - Wiki, Age, Weight And Height, Relationships
-----------------------------------------------------------------------

 ![Elina Svitolina Net Worth - Wiki, Age, Weight and Height, Relationships](https://luxlux.net/lux/wp-content/uploads/Elina-Svitolina-1-1024x683.jpeg) <small>luxlux.net</small>Elina Svitolina Net Worth - Wiki, Age, Weight and Height, Relationships ...

Elina Svitolina Profile - Career Stats, Titles &amp; Biography
--------------------------------------------------------------

 ![Elina Svitolina Profile - Career Stats, Titles & Biography](https://images.mykhel.com/webp/common_dynamic/images/tennis/players/9/27849.jpg) <small>www.mykhel.com</small>Elina Svitolina Profile - Career Stats, Titles &amp; Biography

Elina Svitolina Bio, Age, Height, Parents, Husband, Net Worth
-------------------------------------------------------------

 ![Elina Svitolina Bio, Age, Height, Parents, Husband, Net Worth](https://wealthyspy.com/wp-content/uploads/2023/07/Elina-Svitolina-2-768x576.jpg) <small>wealthyspy.com</small>Elina Svitolina Bio, Age, Height, Parents, Husband, Net Worth

Who Is Elina Svitolina Married To? Meet Gael Monfils: His Age, Height
---------------------------------------------------------------------

 ![Who is Elina Svitolina married to? Meet Gael Monfils: His Age, Height](https://staticg.sportskeeda.com/editor/2024/10/81df7-17302941292958-1920.jpg?w=1200) <small>www.sportskeeda.com</small>Who is Elina Svitolina married to? Meet Gael Monfils: His Age, Height ...

Elina Svitolina Height, Weight, Age, Boyfriend, Family, Facts, Biography
------------------------------------------------------------------------

 ![Elina Svitolina Height, Weight, Age, Boyfriend, Family, Facts, Biography](https://healthyceleb.com/wp-content/uploads/2018/07/Elina-Svitolina-as-seen-in-May-2018-300x420.jpg) <small>healthyceleb.com</small>Elina Svitolina Height, Weight, Age, Boyfriend, Family, Facts, Biography

Elina Svitolina Biography, Age, Family, Husband, Tennis Ranking, Career
-----------------------------------------------------------------------

 ![Elina Svitolina Biography, Age, Family, Husband, Tennis Ranking, Career](https://thesportsgrail.com/wp-content/uploads/2022/03/Elina-Svitolina-Ukrainian-tennis-star-stockq-1-min.jpg) <small>thesportsgrail.com</small>Elina Svitolina Biography, Age, Family, Husband, Tennis Ranking, Career ...

ELINA SVITOLINA | ASB Classic | Tennis
--------------------------------------

 ![ELINA SVITOLINA | ASB Classic | Tennis](https://wtafiles.blob.core.windows.net/images/players/hero/316738.png) <small>www.asbclassic.co.nz</small>ELINA SVITOLINA | ASB Classic | Tennis

Elina Svitolina Tennis Scores, Ranking, Predictions, Betting Odds
-----------------------------------------------------------------

 ![Elina Svitolina Tennis Scores, Ranking, Predictions, Betting Odds](https://dcjiq3n10rn3u.cloudfront.net/cms/images/d6870bd0-e58a-45da-b375-8fae24417904-22742.png) <small>www.tennisboard.com</small>Elina Svitolina Tennis Scores, Ranking, Predictions, Betting Odds ...

Celebrity Heights | How Tall Are Celebrities? Heights Of Celebrities
--------------------------------------------------------------------

 ![Celebrity Heights | How Tall Are Celebrities? Heights of Celebrities](https://2.bp.blogspot.com/-D323NfZaTdY/WQY5jCWLb2I/AAAAAAAAO_E/bZRdBvxxL_syoaEJK_N2xfAZvPLfayFSACLcB/s1600/Elina-Svitolina01.jpg) <small>www.heightceleb.info</small>Celebrity Heights | How Tall Are Celebrities? Heights of Celebrities ...

Elina Svitolina Husband, Age, Height, Weight, Net Worth, Career And
-------------------------------------------------------------------

 ![Elina Svitolina Husband, Age, Height, Weight, Net Worth, Career And](https://infotopbio.com/wp-content/uploads/2025/03/Elina-Svitolina-Husband-Age-Height-Weight-Net-Worth-Career-And-Full-Bio-1.webp) <small>infotopbio.com</small>Elina Svitolina Husband, Age, Height, Weight, Net Worth, Career And ...

Elina Svitolina Player Stats - Sportsmen Height
-----------------------------------------------

 ![Elina Svitolina Player Stats - Sportsmen Height](https://sportsmanheight.com/wp-content/uploads/2022/08/14.webp) <small>sportsmanheight.com</small>Elina Svitolina Player Stats - Sportsmen Height

Elina Svitolina - Biography, Height &amp; Life Story | Super Stars Bio
----------------------------------------------------------------------

 ![Elina Svitolina - Biography, Height & Life Story | Super Stars Bio](https://superstarsbio.com/wp-content/uploads/2019/09/Elina-Svitolina-seeker.jpg) <small>superstarsbio.com</small>Elina Svitolina - Biography, Height &amp; Life Story | Super Stars Bio

Elina Svitolina Bio, Age, Parents, Siblings, Husband, Children, Height
----------------------------------------------------------------------

 ![Elina Svitolina Bio, Age, Parents, Siblings, Husband, Children, Height](https://www.mynewsgh.com/wp-content/uploads/2023/07/Elina-Svitolina.jpeg) <small>www.mynewsgh.com</small>Elina Svitolina Bio, Age, Parents, Siblings, Husband, Children, Height

Elina Svitolina Husband, Age, Height, Weight, Net Worth, Career And
-------------------------------------------------------------------

 ![Elina Svitolina Husband, Age, Height, Weight, Net Worth, Career And](https://infotopbio.com/wp-content/uploads/2025/03/Elina-Svitolina-Husband-Age-Height-Weight-Net-Worth-Career-And-Full-Bio-3.webp) <small>infotopbio.com</small>Elina Svitolina Husband, Age, Height, Weight, Net Worth, Career And ...

How Tall Is Elina Svitolina | Height Comparison Tool
----------------------------------------------------

 ![How Tall Is Elina Svitolina | Height Comparison Tool](https://images.heightcomparisontool.com/celebrities/elina-svitolina/elina-svitolina-ak40ionq53.jpg) <small>www.heightcomparisontool.com</small>How Tall Is Elina Svitolina | Height Comparison Tool

Elina Svitolina’s Profile: Age, Height, Husband, Nationality, Children
----------------------------------------------------------------------

 ![Elina Svitolina’s Profile: Age, height, husband, nationality, children](https://ds-images.bolavip.com/news/image?src=https:%2F%2Fimages.bolavip.com%2Fjpg%2Fen%2Ffull%2FBUS_20230712_BUS_27990_svitolina.jpg&width=1200&height=740) <small>bolavip.com</small>Elina Svitolina’s Profile: Age, height, husband, nationality, children ...

Elina Svitolina - Biography, Height &amp; Life Story | Super Stars Bio
----------------------------------------------------------------------

 ![Elina Svitolina - Biography, Height & Life Story | Super Stars Bio](https://superstarsbio.com/wp-content/uploads/2019/09/Elina-Svitolina-mole.jpg) <small>superstarsbio.com</small>Elina Svitolina - Biography, Height &amp; Life Story | Super Stars Bio

Elina Svitolina Biography: Net Worth, Age, Height, Children, Parents
--------------------------------------------------------------------

 ![Elina Svitolina Biography: Net Worth, Age, Height, Children, Parents](https://www.thecityceleb.com/wp-content/uploads/2024/05/image-173-1024x683.png) <small>www.thecityceleb.com</small>Elina Svitolina Biography: Net Worth, Age, Height, Children, Parents ...

Elina Svitolina Bio, Body Measurements, Relationship, Net Worth, Career
-----------------------------------------------------------------------

 ![Elina Svitolina Bio, Body Measurements, Relationship, Net Worth, Career](https://metrobiography.com/wp-content/uploads/2018/05/Elina-Svitolina.jpeg) <small>metrobiography.com</small>Elina Svitolina Bio, Body Measurements, Relationship, Net Worth, Career ...

Elina Svitolina Height In Ft (feet), Cm &amp; Meters — MrHeight
---------------------------------------------------------------

 ![Elina Svitolina height in ft (feet), cm & meters — MrHeight](https://mrheight.com/celebrity-images/elina-svitolina.jpg) <small>mrheight.com</small>Elina Svitolina height in ft (feet), cm &amp; meters — MrHeight

Elina Svitolina - Biography, Height &amp; Life Story | Super Stars Bio
----------------------------------------------------------------------

 ![Elina Svitolina - Biography, Height & Life Story | Super Stars Bio](https://superstarsbio.com/wp-content/uploads/2019/09/Elina-Svitolina-teeth-1024x773.jpg) <small>superstarsbio.com</small>Elina Svitolina - Biography, Height &amp; Life Story | Super Stars Bio

Elina Svitolina: Age, Height, Country, Titles, Ranking, Career Stats
--------------------------------------------------------------------

 ![Elina Svitolina: Age, Height, Country, Titles, Ranking, Career Stats](https://www.mykhel.com/img/2023/06/elina-svitolina-french-open-2023-1685907064.jpg) <small>www.mykhel.com</small>Elina Svitolina: Age, Height, Country, Titles, Ranking, Career Stats ...

Elina Svitolina - Biography, Height &amp; Life Story | Super Stars Bio
----------------------------------------------------------------------

 ![Elina Svitolina - Biography, Height & Life Story | Super Stars Bio](https://superstarsbio.com/wp-content/uploads/2019/09/Elina-Svitolina.jpg) <small>superstarsbio.com</small>Elina Svitolina - Biography, Height &amp; Life Story | Super Stars Bio

Elina Mykhailivna Svitolina Net Worth, Bio, Weight, Height, Age 2024
--------------------------------------------------------------------

 ![Elina Mykhailivna Svitolina Net Worth, Bio, Weight, Height, Age 2024](https://thepersonage.com/wp-content/uploads/2021/10/Elina-Mykhailivna-Svitolina-weight.png) <small>thepersonage.com</small>Elina Mykhailivna Svitolina Net Worth, Bio, Weight, Height, Age 2024 ...

EXCLU - Elina Svitolina (Roland-Garros) Prête à Prendre Sa Retraite
-------------------------------------------------------------------

 ![EXCLU - Elina Svitolina (Roland-Garros) prête à prendre sa retraite](https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA24DPDW.img?w=1630&h=917&m=4&q=74) <small>www.msn.com</small>EXCLU - Elina Svitolina (Roland-Garros) prête à prendre sa retraite ...

Elina Svitolina Height, Weight, Age, Boyfriend, Family, Facts, Biography
------------------------------------------------------------------------

 ![Elina Svitolina Height, Weight, Age, Boyfriend, Family, Facts, Biography](https://healthyceleb.com/wp-content/uploads/2018/07/Elina-Svitolina-during-the-Aegon-International-Tennis-tournament-in-June-2015.jpg) <small>healthyceleb.com</small>Elina Svitolina Height, Weight, Age, Boyfriend, Family, Facts, Biography

Elina Svitolina Husband, Age, Height, Weight, Net Worth, Career And
-------------------------------------------------------------------

 ![Elina Svitolina Husband, Age, Height, Weight, Net Worth, Career And](https://infotopbio.com/wp-content/uploads/2025/03/Elina-Svitolina-Husband-Age-Height-Weight-Net-Worth-Career-And-Full-Bio-2.webp) <small>infotopbio.com</small>Elina Svitolina Husband, Age, Height, Weight, Net Worth, Career And ...

Elina Svitolina Husband, Age, Height, Weight, Net Worth, Career And
-------------------------------------------------------------------

 ![Elina Svitolina Husband, Age, Height, Weight, Net Worth, Career And](https://infotopbio.com/wp-content/uploads/2025/03/Elina-Svitolina-Husband-Age-Height-Weight-Net-Worth-Career-And-Full-Bio-4-1024x572.webp) <small>infotopbio.com</small>Elina Svitolina Husband, Age, Height, Weight, Net Worth, Career And ...

Everything About Elina Svitolina
--------------------------------

 ![Everything about Elina Svitolina](https://r.testifier.nl/Acbs8526SDKI/resizing_type:fit/watermark:Picture: Proshots/width:3840/height:2560/plain/https://s3-newsifier.ams3.digitaloceanspaces.com/tennisuptodate.com/images/2023-07/copyright-proshots-21545435-64a8670d923c1.jpg@webp) <small>tennisuptodate.com</small>Everything about Elina Svitolina

Elina Svitolina 2026: Biography, Career, Net Worth, Earnings And Titles
-----------------------------------------------------------------------

 ![Elina Svitolina 2026: biography, Career, Net Worth, earnings and titles](https://www.tennisworlditalia.com/world_cms/images/tennis_players/player109.jpg) <small>www.tennisworlditalia.com</small>Elina Svitolina 2026: biography, Career, Net Worth, earnings and titles

Elina Svitolina File En Huitièmes De Finale De Roland-Garros
------------------------------------------------------------

 ![Elina Svitolina file en huitièmes de finale de Roland-Garros](https://www.lequipe.fr/_medias/img-photo-jpg/pour-la-quatrieme-annee-de-suite-elina-svitolina-est-en-hutiemes-de-finale-a-roland-garros-f-faugere/1500000002478182/159:146,1936:1330-1200-800-75/f1dc8.jpg) <small>www.lequipe.fr</small>Elina Svitolina file en huitièmes de finale de Roland-Garros

Celebrity heights. elina svitolina file en huitièmes de finale de roland-garros. Elina mykhailivna svitolina net worth, bio, weight, height, age 2024
