---
title: "Lottery Results Powerball News - Powerball results: congratulations to the powerball winners for 15/04"
description: "$256 million powerball jackpot won in new york; ninth powerball jackpot"
date: "2026-02-20"
categories:
- "Uncategorized"
images:
- "https://pbs.twimg.com/media/GIChXFXaUAE7gK9.jpg"
featuredImage: "https://news24cobalt.24.co.za/resources/029f-1f33e0619108-466ff5b5ed4e-1000/format/inline/inline.jpg"
featured_image: "https://pbs.twimg.com/media/GIChXFXaUAE7gK9.jpg"
image: "https://blackstarnews.com/wp-content/uploads/2026/02/ChatGPT-Image-Feb-12-2026-03_14_11-PM-1024x683.png"
---

If you are looking for Lotto numbers powerball results online you've came to the right web. We have 35 Images about Lotto numbers powerball results online like PowerBall draws: Numbers, results, payouts, ithuba, lottery winners, News Articles from LotteryUSA.com and also Powerball and Mega Millions both hit big over the weekend. Here it is:

Lotto Numbers Powerball Results Online
--------------------------------------

 ![Lotto numbers powerball results online](https://pbs.twimg.com/media/GIChXFXaUAE7gK9.jpg) <small>www.namibian.com.na</small>Lotto numbers powerball results online

NJ Lottery Results: 3 Million-Dollar Power Ball Tickets Sold – NBC New York
---------------------------------------------------------------------------

 ![NJ Lottery Results: 3 Million-Dollar Power Ball Tickets Sold – NBC New York](https://media.nbcnewyork.com/2022/11/107147592-1667866621944-gettyimages-1244589866-AA_08112022_932298-1.jpeg?quality=85&strip=all&resize=1200%2C675) <small>www.nbcnewyork.com</small>NJ Lottery Results: 3 Million-Dollar Power Ball Tickets Sold – NBC New York

See Winning Numbers For Powerball Lottery As Jackpot Rises To $1.27B
--------------------------------------------------------------------

 ![See winning numbers for Powerball lottery as jackpot rises to $1.27B](https://www.usatoday.com/gcdn/authoring/authoring-images/2026/04/30/USAT/89870102007-usatsi-28668230.jpg?crop=4017) <small>www.usatoday.com</small>See winning numbers for Powerball lottery as jackpot rises to $1.27B

News Articles From LotteryUSA.com
---------------------------------

 ![News Articles from LotteryUSA.com](https://assets.lotteryusa.com/uploads/articles/1756925618133.jpg) <small>www.lotteryusa.com</small>News Articles from LotteryUSA.com

Winning Powerball Numbers, Lottery Jackpot Results Last Night, May 25, 2026
---------------------------------------------------------------------------

 ![Winning Powerball numbers, lottery jackpot results last night, May 25, 2026](https://www.indystar.com/gcdn/-mm-/14f6a20ea46ef7239967ac8489f4a4c91147820c/c=0-243-2394-1596/local/-/media/2017/02/23/INGroup/Indianapolis/636234288375686944-3-Powerball.jpg?width=2394&height=1353&fit=crop&format=pjpg&auto=webp) <small>www.indystar.com</small>Winning Powerball numbers, lottery jackpot results last night, May 25, 2026

Powerball Winning Numbers For Saturday, April 26, 2025
------------------------------------------------------

 ![Powerball winning numbers for Saturday, April 26, 2025](https://www.beaconjournal.com/gcdn/presto/2023/07/15/PBRE/0cbb236e-8352-4e12-a621-ce08c1478ad4-870D536C-1E77-45DD-83DA-CCBAD07F72CC.jpeg?crop=4031,2267,x1,y0&width=3200&height=1800&format=pjpg&auto=webp) <small>www.beaconjournal.com</small>Powerball winning numbers for Saturday, April 26, 2025

Powerball Lotto Results Today Online
------------------------------------

 ![Powerball lotto results today online](https://img.etimg.com/thumb/width-1200,height-1200,imgsize-205830,resizemode-75,msid-104380719/news/international/us/powerball-jackpot-player-in-california-wins-second-largest-prize-in-games-history-worth-over-1-7-billion.jpg) <small>www.namibian.com.na</small>Powerball lotto results today online

USA Lottery Results For December 15, 2025: Powerball $1.15 Billion
------------------------------------------------------------------

 ![USA Lottery Results for December 15, 2025: Powerball $1.15 Billion](https://cdn.sanity.io/images/17cgpou4/production/64f4a163c30a91cd41e8e8c355e67f554f4e880d-1600x1200.png?w=1600) <small>www.lotteryvalley.com</small>USA Lottery Results for December 15, 2025: Powerball $1.15 Billion ...

Powerball Results: Jackpot Climbs To $747M After No One Matched The
-------------------------------------------------------------------

 ![Powerball results: jackpot climbs to $747M after no one matched the](https://cdn.abcotvs.com/dip/images/12773002_020523-wabc-powerball-img.jpg?w=1600) <small>abc7ny.com</small>Powerball results: jackpot climbs to $747M after no one matched the ...

New York Lottery Awards Two Players $1 Million In Powerball Winnings
--------------------------------------------------------------------

 ![New York Lottery awards two players $1 million in Powerball winnings](https://www.usatoday.com/gcdn/authoring/authoring-images/2024/01/02/USAT/72089978007-microsoft-teamsimage-159.png?crop=1249) <small>www.usatoday.com</small>New York Lottery awards two players $1 million in Powerball winnings

Winning Powerball Numbers, Lottery Jackpot Results Last Night, April 27
-----------------------------------------------------------------------

 ![Winning Powerball numbers, lottery jackpot results last night, April 27](https://i.ytimg.com/vi/A1Xt_vtgJnM/maxresdefault.jpg) <small>www.indystar.com</small>Winning Powerball numbers, lottery jackpot results last night, April 27 ...

Powerball June 28, 2025: Winning Numbers, Lottery Drawing Jackpot Results
-------------------------------------------------------------------------

 ![Powerball June 28, 2025: Winning numbers, lottery drawing jackpot results](https://i.ytimg.com/vi/n-7yrpZxk5M/maxresdefault.jpg) <small>www.indystar.com</small>Powerball June 28, 2025: Winning numbers, lottery drawing jackpot results

Here Are The Powerball And Powerball Plus Results | News24
----------------------------------------------------------

 ![Here are the Powerball and Powerball Plus results | News24](https://news24cobalt.24.co.za/resources/029f-1f33e0619108-466ff5b5ed4e-1000/format/inline/inline.jpg) <small>www.news24.com</small>Here are the Powerball and Powerball Plus results | News24

POWERBALL RESULTS: Congratulations To The PowerBall Winners For 15/04
---------------------------------------------------------------------

 ![POWERBALL RESULTS: Congratulations to the PowerBall Winners for 15/04](https://todaylotto.co.za/wp-content/uploads/2025/04/Today-Lotto-Template-16-1024x576.png) <small>todaylotto.co.za</small>POWERBALL RESULTS: Congratulations to the PowerBall Winners for 15/04 ...

Texas Lottery Results: Powerball, Lotto Texas Winning Numbers For June
----------------------------------------------------------------------

 ![Texas Lottery results: Powerball, Lotto Texas winning numbers for June](https://www.elpasotimes.com/gcdn/authoring/authoring-images/2025/03/13/PTX1/82368850007-03132025-lottery-sign-2.jpg?crop=3679,2070,x0,y191&width=3200&height=1801&format=pjpg&auto=webp) <small>www.elpasotimes.com</small>Texas Lottery results: Powerball, Lotto Texas winning numbers for June ...

Powerball Winning Numbers: Lottery Results Today, Powerball Winning
-------------------------------------------------------------------

 ![Powerball winning numbers: Lottery Results today, Powerball winning](https://img.etimg.com/thumb/msid-126464503,width-1200,height-630,imgsize-263824,overlay-economictimes/articleshow.jpg) <small>economictimes.indiatimes.com</small>Powerball winning numbers: Lottery Results today, Powerball winning ...

PowerBall And PowerBall Plus Results | 20 May 2025 - ENCA
---------------------------------------------------------

 ![PowerBall and PowerBall Plus Results | 20 May 2025 - eNCA](https://www.enca.com/sites/default/files/styles/banner_image/public/2023-07/etv_pb_results.jpg.webp?itok=6NASh8rZ) <small>www.enca.com</small>PowerBall and PowerBall Plus Results | 20 May 2025 - eNCA

Oregon Powerball Winners Of $1.3B Lottery Prize Announced
---------------------------------------------------------

 ![Oregon Powerball winners of $1.3B lottery prize announced](https://www.statesmanjournal.com/gcdn/authoring/authoring-images/2024/04/29/PSAL/73505047007-lottery-108.jpg?crop=4934,2774,x0,y346&width=3200&height=1800&format=pjpg&auto=webp) <small>www.statesmanjournal.com</small>Oregon Powerball winners of $1.3B lottery prize announced

Powerball And Mega Millions Both Hit Big Over The Weekend
---------------------------------------------------------

 ![Powerball and Mega Millions both hit big over the weekend](https://assets.lotteryusa.com/uploads/articles/1749573868178.jpg) <small>www.lotteryusa.com</small>Powerball and Mega Millions both hit big over the weekend

PowerBall And PowerBall Plus Results | 26 August 2025 - ENCA
------------------------------------------------------------

 ![PowerBall and PowerBall Plus Results | 26 August 2025 - eNCA](https://www.enca.com/sites/default/files/styles/banner_image/public/2025-02/pb_results-example 2.jpg.webp?itok=tQKYnMcc) <small>www.enca.com</small>PowerBall and PowerBall Plus Results | 26 August 2025 - eNCA

Powerball Winning Numbers, Live Results For Saturday’s $263M Drawing
--------------------------------------------------------------------

 ![Powerball winning numbers, live results for Saturday’s $263M drawing](https://www.nj.com/resizer/v2/RR67HN5MGRETBIXR6CZIK2CDZM.jpg?auth=c5eaecc25f2b0b72e64ac2e5cbca1725f98fa8ac48ad1bcc67525e0ab6e498a7&width=1280&quality=90) <small>www.nj.com</small>Powerball winning numbers, live results for Saturday’s $263M drawing ...

A Lucky Player Won The Second Prize; Powerball Jackpot Rises To $195
--------------------------------------------------------------------

 ![A lucky player won the second prize; Powerball jackpot rises to $195](https://internationallottery.org/wp-content/uploads/2025/10/xo_so_powerball_02_10_2025_055403.png) <small>internationallottery.org</small>A lucky player won the second prize; Powerball jackpot rises to $195 ...

$256 Million Powerball Jackpot Won In New York; Ninth Powerball Jackpot
-----------------------------------------------------------------------

 ![$256 million Powerball jackpot won in New York; ninth Powerball jackpot](https://cdn.powerball.com/v01/images/opengraph/copy-of-jackpot-winner-1200.webp) <small>www.powerball.com</small>$256 million Powerball jackpot won in New York; ninth Powerball jackpot ...

PowerBall Draws: Numbers, Results, Payouts, Ithuba, Lottery Winners
-------------------------------------------------------------------

 ![PowerBall draws: Numbers, results, payouts, ithuba, lottery winners](https://www.thesouthafrican.com/wp-content/uploads/2025/03/image-8.png) <small>www.thesouthafrican.com</small>PowerBall draws: Numbers, results, payouts, ithuba, lottery winners

Powerball Results For January 7 Drawing Revealed: Did Anyone Win $105
---------------------------------------------------------------------

 ![Powerball results for January 7 drawing revealed: Did anyone win $105](https://img.etimg.com/thumb/msid-126405977,width-650,height-488,imgsize-110346,resizemode-75/powerball-lottery.jpg) <small>economictimes.indiatimes.com</small>Powerball results for January 7 drawing revealed: Did anyone win $105 ...

Michigan Couple, Attorney Announced As Winners Of $842.4 Million
----------------------------------------------------------------

 ![Michigan couple, attorney announced as winners of $842.4 million](https://dims.apnews.com/dims4/default/521f8d2/2147483647/strip/true/crop/3833x2554+0+1/resize/980x653!/quality/90/?url=https:%2F%2Fassets.apnews.com%2F84%2F0a%2F447143ed72710907ff790c0f74f7%2Ffd12bc8bc5b74fada21db34fd1e58522) <small>apnews.com</small>Michigan couple, attorney announced as winners of $842.4 million ...

Powerball Lottery Result Announced: California's Edwin Castro Wins The
----------------------------------------------------------------------

 ![Powerball lottery result announced: California's Edwin Castro wins the](http://cdn.wionews.com/sites/default/files/2023/02/15/332622-untitled-design-59.png) <small>www.wionews.com</small>Powerball lottery result announced: California's Edwin Castro wins the ...

PowerBall Results: Latest Winning Numbers, Payouts And Draw Updates For
-----------------------------------------------------------------------

 ![PowerBall results: Latest winning numbers, payouts and draw updates for](https://www.swisherpost.com/wp-content/uploads/2026/01/powerball-results-south-africa-2026.jpg) <small>www.swisherpost.com</small>PowerBall results: Latest winning numbers, payouts and draw updates for ...

Immigrant Battling Cancer Among Trio Who Won $1.326 Billion Powerball
---------------------------------------------------------------------

 ![Immigrant battling cancer among trio who won $1.326 billion Powerball](https://i.abcnewsfe.com/a/4b1ef916-acaf-4fc1-932e-c842d8c6d45b/portland-powerball-1-gty-dp-040924_1712690062474_hpMain.jpg?w=992) <small>www.goodmorningamerica.com</small>Immigrant battling cancer among trio who won $1.326 billion Powerball ...

Winner Stories | Powerball
--------------------------

 ![Winner Stories | Powerball](https://cdn.powerball.com/v01/images/gallery/tn-richie-david-1m-powerball-6-11-22-v2-400.webp) <small>www.powerball.com</small>Winner Stories | Powerball

Oregonian Strikes Gold, $329 Million Powerball Jackpot Winner Revealed
----------------------------------------------------------------------

 ![Oregonian Strikes Gold, $329 Million Powerball Jackpot Winner Revealed](https://a57.foxnews.com/static.foxnews.com/foxnews.com/content/uploads/2024/04/1200/675/Oregon-Lottery-winner.jpg?ve=1&tl=1) <small>techstory.in</small>Oregonian Strikes Gold, $329 Million Powerball Jackpot Winner Revealed ...

Powerball Results For 06/09/25: Jackpot Stands At $65 Million
-------------------------------------------------------------

 ![Powerball results for 06/09/25: Jackpot stands at $65 million](https://internationallottery.org/wp-content/uploads/2025/06/xo_so_powerball_10_06_2025_052703.png) <small>internationallottery.org</small>Powerball results for 06/09/25: Jackpot stands at $65 million ...

Powerball Results: Winning Numbers For Saturday, January 9
----------------------------------------------------------

 ![Powerball results: Winning numbers for Saturday, January 9](https://www.the-sun.com/wp-content/uploads/sites/6/2020/12/ad-powerball-live-comp-1.jpg?w=750) <small>www.the-sun.com</small>Powerball results: Winning numbers for Saturday, January 9 ...

Powerball Winning Numbers 11th February: Results, Jackpot, Prize
----------------------------------------------------------------

 ![Powerball Winning Numbers 11th February: Results, Jackpot, Prize](https://blackstarnews.com/wp-content/uploads/2026/02/ChatGPT-Image-Feb-12-2026-03_14_11-PM-1024x683.png) <small>blackstarnews.com</small>Powerball Winning Numbers 11th February: Results, Jackpot, Prize

TN Lottery Powerball, Lotto America Winning Numbers For July 11, 2026
---------------------------------------------------------------------

 ![TN Lottery Powerball, Lotto America winning numbers for July 11, 2026](https://www.tennessean.com/gcdn/authoring/authoring-images/2024/04/29/PNAS/73499463007-041904-powerball-02.jpg?crop=2359,1325,x0,y45&width=2359&height=1325&format=pjpg&auto=webp) <small>www.tennessean.com</small>TN Lottery Powerball, Lotto America winning numbers for July 11, 2026

$256 million powerball jackpot won in new york; ninth powerball jackpot .... Winning powerball numbers, lottery jackpot results last night, may 25, 2026. Powerball june 28, 2025: winning numbers, lottery drawing jackpot results
