---
title: "Usman Nurmagomedov Vs Alfie Davis - Prediction, pick for usman nurmagomedov vs. alfie davis at pfl road to ..."
description: "Usman nurmagomedov vs alfie davis – mma fight analysis &amp; results"
date: "2026-06-22"
categories:
- "Uncategorized"
images:
- "https://www.bjpenn.com/wp-content/uploads/2026/02/Khabib-Nurmagomedov.jpg"
featuredImage: "https://boxing-schedule.com/images/usman-nurmagomedov.webp"
featured_image: "https://nyfights.com/wp-content/uploads/2026/11/imago1072218191h-860x573.jpg"
image: "https://image-cdn.essentiallysports.com/wp-content/uploads/Copy-of-Copy-of-UFC-FIs_20260206_033812_0000.jpg?width=1200"
---

If you are searching about Usman Nurmagomedov vs Alfie Davis Set to Headline PFL: Road to Dubai you've visit to the right page. We have 35 Images about Usman Nurmagomedov vs Alfie Davis Set to Headline PFL: Road to Dubai like Nurmagomedov vs Davis (Feb 7, 2026): How to Watch, Start Time, Usman Nurmagomedov’s Manager Drops Blunt Truth on ‘False’ Promotion and also Usman Nurmagomedov vs Alfie Davis RECAP: Relive Usman Nurmagomedov's. Here it is:

Usman Nurmagomedov Vs Alfie Davis Set To Headline PFL: Road To Dubai
--------------------------------------------------------------------

 ![Usman Nurmagomedov vs Alfie Davis Set to Headline PFL: Road to Dubai](https://mmauk.net/wp-content/uploads/2025/11/Usman-Nurmagomedov-vs-Alfie-Davis-Set-to-Headline-PFL-Road-to-Dubai-2026.jpg) <small>mmauk.net</small>Usman Nurmagomedov vs Alfie Davis Set to Headline PFL: Road to Dubai ...

Usman Nurmagomedov Vs Alfie Davis - Fight Start Time
----------------------------------------------------

 ![Usman Nurmagomedov vs Alfie Davis - Fight Start Time](https://boxing-schedule.com/images/alfie-davis.webp) <small>boxing-schedule.com</small>Usman Nurmagomedov vs Alfie Davis - Fight Start Time

Umar Nurmagomedov Says Usman Is Ready To Fight UFC Champions
------------------------------------------------------------

 ![Umar Nurmagomedov Says Usman Is Ready to Fight UFC Champions](https://mmasucka.com/_next/image/?url=%2Fapi%2Fmedia%2Ffile%2FFotoJet (66).webp&w=3840&q=75) <small>mmasucka.com</small>Umar Nurmagomedov Says Usman Is Ready to Fight UFC Champions

Usman Nurmagomedov Stats, Record &amp; Fight History | MMA Junkie
-----------------------------------------------------------------

 ![Usman Nurmagomedov Stats, Record & Fight History | MMA Junkie](https://www.gannett-cdn.com/authoring/images/smg/2025/02/21/SMMA/79491279007-91-2768463.jpeg?auto=webp&width=640&quality=75) <small>mmajunkie.usatoday.com</small>Usman Nurmagomedov Stats, Record &amp; Fight History | MMA Junkie

Usman Nurmagomedov Vs. Alfie Davis Title Fight Headlines PFL Dubai On Feb 7
---------------------------------------------------------------------------

 ![Usman Nurmagomedov vs. Alfie Davis Title Fight Headlines PFL Dubai on Feb 7](https://cagesidepress.com/wp-content/uploads/2021/10/03-Bellator-269-Nurmagomedov-vs-Pietila-01-696x465.jpg) <small>cagesidepress.com</small>Usman Nurmagomedov vs. Alfie Davis Title Fight Headlines PFL Dubai on Feb 7

Usman Nurmagomedov Vs Alfie Davis: A Round By Round Breakdown – Data
--------------------------------------------------------------------

 ![Usman Nurmagomedov vs Alfie Davis: A Round By Round Breakdown – Data](https://datacombatsport.com/wp-content/uploads/2026/02/Usman-Nurmagomedov-PFL-Lightweight-Champion-1024x683.png) <small>datacombatsport.com</small>Usman Nurmagomedov vs Alfie Davis: A Round By Round Breakdown – Data ...

Reports: Usman Nurmagomedov Reached Agreement To Join UFC, Official
-------------------------------------------------------------------

 ![Reports: Usman Nurmagomedov Reached Agreement to Join UFC, Official](https://assets.agentmma.com/ig/mmaaddictonly/DfiNTcdGHsO.jpg) <small>agentmma.com</small>Reports: Usman Nurmagomedov Reached Agreement to Join UFC, Official ...

Nurmagomedov Vs Davis (Feb 7, 2026): How To Watch, Start Time
-------------------------------------------------------------

 ![Nurmagomedov vs Davis (Feb 7, 2026): How to Watch, Start Time](https://champinon.info/images/nurmagomedov-vs-davis.webp) <small>champinon.info</small>Nurmagomedov vs Davis (Feb 7, 2026): How to Watch, Start Time

Usman Nurmagomedov’s Manager Drops Blunt Truth On ‘False’ Promotion
-------------------------------------------------------------------

 ![Usman Nurmagomedov’s Manager Drops Blunt Truth on ‘False’ Promotion](https://nyfights.com/wp-content/uploads/2026/11/imago1072218172h-scaled-e1794407997109.jpg) <small>nyfights.com</small>Usman Nurmagomedov’s Manager Drops Blunt Truth on ‘False’ Promotion ...

Merab Dvalishvili And Usman Nurmagomedov Brawl In Abu Dhabi Before RAF
----------------------------------------------------------------------

 ![Merab Dvalishvili and Usman Nurmagomedov brawl in Abu Dhabi before RAF](https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA2hgBjZ.img?w=768&h=432&m=6&x=378&y=76&s=134&d=134) <small>www.msn.com</small>Merab Dvalishvili and Usman Nurmagomedov brawl in Abu Dhabi before RAF ...

Abubakar Nurmagomedov Returns After Three Years Out Against David
-----------------------------------------------------------------

 ![Abubakar Nurmagomedov returns after three years out against David](https://resoldtick.com/assets/news/pfl-first-dubai-show-recap-january-2025-usman-nurmagomedov-beats-paul-hughes-nemkov-akhmed-magomedov.jpg) <small>resoldtick.com</small>Abubakar Nurmagomedov returns after three years out against David ...

Usman Nurmagomedov Vs Alfie Davis - How To Watch, Stream &amp; TV Info
----------------------------------------------------------------------

 ![Usman Nurmagomedov vs Alfie Davis - How to Watch, Stream & TV Info](https://boxing-schedule.com/images/usman-nurmagomedov.webp) <small>boxing-schedule.com</small>Usman Nurmagomedov vs Alfie Davis - How to Watch, Stream &amp; TV Info

Usman Nurmagomedov Vs Alfie Davis – MMA Fight Analysis &amp; Results | MMAtown
------------------------------------------------------------------------------

 ![Usman Nurmagomedov vs Alfie Davis – MMA Fight Analysis & Results | MMAtown](https://cdn.mmatown.com/blog-posts/2025/08/khabib-nurmagomedov-hints-at-usman-nurmagomedov-vs-paul-hughes-rematch-in-dubai-this-october-EmJeW7fY.jpg) <small>mmatown.com</small>Usman Nurmagomedov vs Alfie Davis – MMA Fight Analysis &amp; Results | MMAtown

Usman Nurmagomedov Vs. Alfie Davis Highlights | Wildz Casino
------------------------------------------------------------

 ![Usman Nurmagomedov vs. Alfie Davis Highlights | Wildz Casino](https://s-cms.rootz.com/wildz/2026/02/20/Usman-Nurmagomedov-vs.-Alfie-Davis-Highlights_uid_69986296c8d78.png) <small>www.wildz.com</small>Usman Nurmagomedov vs. Alfie Davis Highlights | Wildz Casino

PFL Full Fight: Usman Nurmagomedov Sleeps Alfie Davis In Title Defense
----------------------------------------------------------------------

 ![PFL full fight: Usman Nurmagomedov sleeps Alfie Davis in title defense](https://mmajunkie.usatoday.com/gcdn/authoring/authoring-images/2026/02/07/SMMA/88570588007-usman-nurmagomedov-def-alfie-davis-pfl-road-to-dubai-32.JPG?crop=2399,1351,x0,y124&width=2399&height=1351&format=pjpg&auto=webp) <small>mmajunkie.usatoday.com</small>PFL full fight: Usman Nurmagomedov sleeps Alfie Davis in title defense

Usman Nurmagomedov’s Manager Drops Blunt Truth On ‘False’ Promotion
-------------------------------------------------------------------

 ![Usman Nurmagomedov’s Manager Drops Blunt Truth on ‘False’ Promotion](https://nyfights.com/wp-content/uploads/2026/11/imago1072218191h-860x573.jpg) <small>nyfights.com</small>Usman Nurmagomedov’s Manager Drops Blunt Truth on ‘False’ Promotion ...

PFL Dubai Results: Usman Nurmagomedov Defends Lightweight Title After
---------------------------------------------------------------------

 ![PFL Dubai Results: Usman Nurmagomedov Defends Lightweight Title After](https://middleeasy.com/wp-content/uploads/2026/02/Usman-Nurmagomedov-870x489.jpg) <small>middleeasy.com</small>PFL Dubai Results: Usman Nurmagomedov Defends Lightweight Title After ...

PFL Dubai: Nurmagomedov Vs. Davis Live Updates, Results
-------------------------------------------------------

 ![PFL Dubai: Nurmagomedov vs. Davis live updates, results](https://mmajunkie.usatoday.com/gcdn/authoring/authoring-images/2026/02/06/SMMA/88552943007-usman-nurmagomedov-vs-alfie-davis-pfl-road-to-dubai-ceremonial-weighins-1.jpg?crop=1919,1081,x0,y99&width=1919&height=1081&format=pjpg&auto=webp) <small>mmajunkie.usatoday.com</small>PFL Dubai: Nurmagomedov vs. Davis live updates, results

Usman Nurmagomedov Vs Alfie Davis | Highlights Before The Fight - YouTube
-------------------------------------------------------------------------

 ![Usman Nurmagomedov vs Alfie Davis | Highlights before the Fight - YouTube](https://i.ytimg.com/vi/HGzZP2WndCU/maxresdefault.jpg) <small>www.youtube.com</small>Usman Nurmagomedov vs Alfie Davis | Highlights before the Fight - YouTube

Usman Nurmagomedov Vs. Alfie Davis Title Bout Headlines PFL: Road To Dubai
--------------------------------------------------------------------------

 ![Usman Nurmagomedov vs. Alfie Davis title bout headlines PFL: Road to Dubai](https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA1QOp88.img?w=768&h=511&m=6) <small>www.msn.com</small>Usman Nurmagomedov vs. Alfie Davis title bout headlines PFL: Road to Dubai

(WATCH) Usman Nurmagomedov Chokes Out Alfie Davis, Retains PFL Title
--------------------------------------------------------------------

 ![(WATCH) Usman Nurmagomedov Chokes Out Alfie Davis, Retains PFL Title](https://www.bjjee.com/wp-content/uploads/2026/02/Usman-Nurmagomedov-vs-Alfie-Davis-RNC-finish.jpg) <small>www.bjjee.com</small>(WATCH) Usman Nurmagomedov Chokes Out Alfie Davis, Retains PFL Title

Prediction, Pick For Usman Nurmagomedov Vs. Alfie Davis At PFL Road To
----------------------------------------------------------------------

 ![Prediction, pick for Usman Nurmagomedov vs. Alfie Davis at PFL Road to](https://dknetwork.draftkings.com/wp-content/uploads/GettyImages-2195374020.jpg) <small>dknetwork.draftkings.com</small>Prediction, pick for Usman Nurmagomedov vs. Alfie Davis at PFL Road to ...

Usman Nurmagomedov Vs Alfie Davis – MMA Fight Analysis &amp; Results | MMAtown
------------------------------------------------------------------------------

 ![Usman Nurmagomedov vs Alfie Davis – MMA Fight Analysis & Results | MMAtown](https://img.youtube.com/vi/ZsmZYgvlC0c/sddefault.jpg) <small>mmatown.com</small>Usman Nurmagomedov vs Alfie Davis – MMA Fight Analysis &amp; Results | MMAtown

PFL Dubai: Usman Nurmagomedov Vs. Alfie Davis Stats And Prediction
------------------------------------------------------------------

 ![PFL Dubai: Usman Nurmagomedov vs. Alfie Davis Stats and Prediction](https://image-cdn.essentiallysports.com/wp-content/uploads/Copy-of-Copy-of-UFC-FIs_20260206_033812_0000.jpg?width=1200) <small>www.essentiallysports.com</small>PFL Dubai: Usman Nurmagomedov vs. Alfie Davis Stats and Prediction ...

Usman Nurmagomedov Chokes Alfie Davis Unconscious To Retain Lightweight
-----------------------------------------------------------------------

 ![Usman Nurmagomedov Chokes Alfie Davis Unconscious To Retain Lightweight](https://cdn.lowkickmma.com/2026/02/MixCollage-07-Feb-2026-02-10-PM-5629.jpg) <small>www.lowkickmma.com</small>Usman Nurmagomedov Chokes Alfie Davis Unconscious To Retain Lightweight ...

Usman Nurmagomedov Dominates And Submits Alfie Davis To Retain Title
--------------------------------------------------------------------

 ![Usman Nurmagomedov Dominates and Submits Alfie Davis to Retain Title](https://ichef.bbci.co.uk/ace/branded_sport/1200/cpsprodpb/3eed/live/2f776950-046c-11f1-96f5-2f82f674a667.jpg) <small>newsclip.com</small>Usman Nurmagomedov Dominates and Submits Alfie Davis to Retain Title ...

Abu Dhabi Police Confirm 10 Arrests After Nurmagomedov-Dvalishvili
------------------------------------------------------------------

 ![Abu Dhabi Police confirm 10 arrests after Nurmagomedov-Dvalishvili](https://static.toiimg.com/photo/imgsize-271740,msid-135770956/img6062d49bc9d73b00186e914f.jpg) <small>timesofindia.indiatimes.com</small>Abu Dhabi Police confirm 10 arrests after Nurmagomedov-Dvalishvili ...

Usman Nurmagomedov Vs Alfie Davis RECAP: Relive Usman Nurmagomedov's
--------------------------------------------------------------------

 ![Usman Nurmagomedov vs Alfie Davis RECAP: Relive Usman Nurmagomedov's](https://ichef.bbci.co.uk/ace/standard/1024/cpsprodpb/be1f/live/52513350-0464-11f1-a12b-658d26b020a4.png) <small>www.bbc.co.uk</small>Usman Nurmagomedov vs Alfie Davis RECAP: Relive Usman Nurmagomedov's ...

Usman Nurmagomedov Vs. Alfie Davis Headlines First PFL Card In 2026
-------------------------------------------------------------------

 ![Usman Nurmagomedov vs. Alfie Davis headlines first PFL card in 2026](https://platform.mmafighting.com/wp-content/uploads/sites/109/2025/08/20250125221838-_JP13385_.jpg?quality=90&strip=all&crop=0%2C6.1497095545259%2C100%2C78.534031413613&w=1200) <small>www.mmafighting.com</small>Usman Nurmagomedov vs. Alfie Davis headlines first PFL card in 2026 ...

Alfie Davis Eyes Khabib Nurmagomedov Callout, Blasts “Entitled Boy
------------------------------------------------------------------

 ![Alfie Davis eyes Khabib Nurmagomedov callout, blasts “Entitled Boy](https://www.bjpenn.com/wp-content/uploads/2026/02/Khabib-Nurmagomedov.jpg) <small>www.bjpenn.com</small>Alfie Davis eyes Khabib Nurmagomedov callout, blasts “Entitled Boy ...

PFL Dubai: Nurmagomedov Vs. Davis - Usman Nurmagomedov Vs. Alfie Davis
----------------------------------------------------------------------

 ![PFL Dubai: Nurmagomedov vs. Davis - Usman Nurmagomedov vs. Alfie Davis](https://bmyxlmhutpeswgoxuplj.supabase.co/storage/v1/object/public/event-posters/pfl-nurmagomedov-vs-davis/poster.webp?v=1775521668010) <small>kakuota.app</small>PFL Dubai: Nurmagomedov vs. Davis - Usman Nurmagomedov vs. Alfie Davis ...

Davis Vs Usman Nurmagomedov Fight Card, Date, Venue, How To Watch
-----------------------------------------------------------------

 ![Davis vs Usman Nurmagomedov Fight Card, Date, Venue, How To Watch](https://ichef.bbci.co.uk/ace/standard/976/cpsprodpb/c343/live/29feb5b0-c541-11f0-88be-3bc2aea1a256.png.webp) <small>www.sportshistori.com</small>Davis vs Usman Nurmagomedov Fight Card, Date, Venue, How To Watch ...

PFL Dubai Results: Usman Nurmagomedov Sleeps Alfie Davis In Rare Fashion
------------------------------------------------------------------------

 ![PFL Dubai results: Usman Nurmagomedov sleeps Alfie Davis in rare fashion](https://mmajunkie.usatoday.com/gcdn/authoring/authoring-images/2026/02/07/SMMA/88570597007-usman-nurmagomedov-def-alfie-davis-pfl-road-to-dubai-41.JPG?crop=2399,1351,x0,y124&width=2399&height=1351&format=pjpg&auto=webp) <small>mmajunkie.usatoday.com</small>PFL Dubai results: Usman Nurmagomedov sleeps Alfie Davis in rare fashion

UFC Star Merab Dvalishvili Left Bloodied After Alleged Attack From
------------------------------------------------------------------

 ![UFC Star Merab Dvalishvili Left Bloodied After Alleged Attack From](https://images2.minutemediacdn.com/image/upload/c_crop,x_0,y_0,w_1320,h_880/c_fill,w_16,ar_16:9,f_auto,q_auto,g_auto/images/voltaxMediaLibrary/mmsport/mma_knockout/01m1byng6qk1q42f6n4d.jpg) <small>www.si.com</small>UFC Star Merab Dvalishvili Left Bloodied After Alleged Attack From ...

Usman Nurmagomedov Free To Negotiate With UFC After PFL Exclusivity
-------------------------------------------------------------------

 ![Usman Nurmagomedov Free To Negotiate With UFC After PFL Exclusivity](https://c.ndtvimg.com/2026-10/3vf9j2hg_usman-nurmagomedov-_625x300_29_October_26.png?im=FaceCrop,algorithm=dnn,width=1600,height=900) <small>sports.ndtv.com</small>Usman Nurmagomedov Free To Negotiate With UFC After PFL Exclusivity ...

Usman nurmagomedov’s manager drops blunt truth on ‘false’ promotion. Davis vs usman nurmagomedov fight card, date, venue, how to watch .... Pfl full fight: usman nurmagomedov sleeps alfie davis in title defense
