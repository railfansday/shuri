---
title: "Usman Vs Alfie Davis - usman nurmagomedov dominates alfie davis to retain pfl lightweight ..."
description: "usman nurmagomedov vs alfie davis highlights"
date: "2026-01-29"
categories:
- "Uncategorized"
images:
- "https://aws-br-images.s3.us-east-2.amazonaws.com/images/0c/a4/0ca4198fb375a2e60aa3f3d3b5046f29.jpg"
featuredImage: "https://www.thenationalnews.com/resizer/v2/QVCCYWR5IVBZLBBIOLWEQFZV7E.jpg?auth=de1185c00aad8615b4ff2f543fa7627b493ad4280578c5d56bb278472e1767b1"
featured_image: "https://www.thenationalnews.com/resizer/v2/BY2EIIFFWRH4HGQSTMXY5K5NYI.JPG?auth=304a652705fd30f295f5955e5c305504958d45c93af0ae904f8f487070609155"
image: "https://www.thenationalnews.com/resizer/v2/ZRJIPCIZE5HURNFDHHVK4ZGWPE.JPG?smart=true&amp;auth=de799f3fb442295b515df138daa22ac832f14370f67ffa402cb033590adaea61&amp;width=400&amp;height=225"
---

If you are searching about PFL: Road to Dubai Returns February 7, 2026 — Usman Nurmagomedov vs you've visit to the right web. We have 35 Pics about PFL: Road to Dubai Returns February 7, 2026 — Usman Nurmagomedov vs like PFL: Road to Dubai Returns February 7, 2026 — Usman Nurmagomedov vs, Usman Nurmagomedov vs. Alfie Davis title bout headlines PFL: Road to Dubai and also Usman Nurmagomedov vs Alfie Davis Set to Headline PFL: Road to Dubai. Read more:

PFL: Road To Dubai Returns February 7, 2026 — Usman Nurmagomedov Vs
-------------------------------------------------------------------

 ![PFL: Road to Dubai Returns February 7, 2026 — Usman Nurmagomedov vs](https://www.fightbookmma.com/wp-content/uploads/2025/11/image-80-2048x1152.png) <small>www.fightbookmma.com</small>PFL: Road to Dubai Returns February 7, 2026 — Usman Nurmagomedov vs ...

"Alfie Davis, Anytime, Anywhere." - Usman Nurmagomedov Gets His Wish A
----------------------------------------------------------------------

 !["Alfie Davis, Anytime, Anywhere." - Usman Nurmagomedov gets his wish a](https://www.tiktok.com/api/img/?itemId=7575538504147422494&location=0&aid=1988) <small>www.tiktok.com</small>"Alfie Davis, Anytime, Anywhere." - Usman Nurmagomedov gets his wish a ...

PFL Dubai: Usman Nurmagomedov Submits Alfie Davis In Third Round To
-------------------------------------------------------------------

 ![PFL Dubai: Usman Nurmagomedov submits Alfie Davis in third round to](https://ichef.bbci.co.uk/ace/standard/2560/cpsprodpb/3eed/live/2f776950-046c-11f1-96f5-2f82f674a667.jpg) <small>www.bbc.co.uk</small>PFL Dubai: Usman Nurmagomedov submits Alfie Davis in third round to ...

Usman Nurmagomedov Dominates Alfie Davis To Retain PFL Lightweight
------------------------------------------------------------------

 ![Usman Nurmagomedov dominates Alfie Davis to retain PFL lightweight](https://www.thenationalnews.com/resizer/v2/VIMJTPO5BRH25H7BZAHQGBLFNQ.JPG?auth=330d8ac5c2f2f25dfa270239455a9b22b5257b0e35de64235aca344ede099012) <small>www.thenationalnews.com</small>Usman Nurmagomedov dominates Alfie Davis to retain PFL lightweight ...

Winner Fights Usman!! | No Comms! | Gadzhi Rabadanov V Alfie Davis
------------------------------------------------------------------

 ![Winner Fights Usman!! | No Comms! | Gadzhi Rabadanov v Alfie Davis](https://i.ytimg.com/vi/fg9IcPVIVLY/maxresdefault.jpg) <small>www.youtube.com</small>Winner Fights Usman!! | No Comms! | Gadzhi Rabadanov v Alfie Davis ...

Usman Nurmagomedov Vs Alfie Davis RECAP: Relive Usman Nurmagomedov's
--------------------------------------------------------------------

 ![Usman Nurmagomedov vs Alfie Davis RECAP: Relive Usman Nurmagomedov's](https://ichef.bbci.co.uk/ace/standard/640/cpsprodpb/vivo/live/images/2026/2/7/4182f023-6644-49d1-9f7a-f3c2fc2d9d03.png.webp) <small>www.bbc.co.uk</small>Usman Nurmagomedov vs Alfie Davis RECAP: Relive Usman Nurmagomedov's ...

TEAM MMA - Usman Nurmagomedov Vs. Alfie Davis AGREGADO A... | Facebook
----------------------------------------------------------------------

 ![TEAM MMA - Usman Nurmagomedov vs. Alfie Davis AGREGADO a... | Facebook](https://lookaside.fbsbx.com/lookaside/crawler/media/?media_id=827835563342846) <small>www.facebook.com</small>TEAM MMA - Usman Nurmagomedov vs. Alfie Davis AGREGADO a... | Facebook

Usman Nurmagomedov Vs Alfie Davis RECAP: Relive Usman Nurmagomedov's
--------------------------------------------------------------------

 ![Usman Nurmagomedov vs Alfie Davis RECAP: Relive Usman Nurmagomedov's](https://ichef.bbci.co.uk/ace/standard/640/cpsprodpb/vivo/live/images/2026/2/7/7105d8ae-31d1-4417-bc67-84306cd42980.png.webp) <small>www.bbc.co.uk</small>Usman Nurmagomedov vs Alfie Davis RECAP: Relive Usman Nurmagomedov's ...

PFL Dubai: Usman Nurmagomedov To Defend Title Against Alfie Davis In
--------------------------------------------------------------------

 ![PFL Dubai: Usman Nurmagomedov to defend title against Alfie Davis in](https://ichef.bbci.co.uk/ace/branded_sport/1200/cpsprodpb/c343/live/29feb5b0-c541-11f0-88be-3bc2aea1a256.png) <small>www.bbc.com</small>PFL Dubai: Usman Nurmagomedov to defend title against Alfie Davis in ...

USMAN NURMAGOMEDOV VS ALFIE DAVIS | HIGHLIGHTS BEFORE THE MATCH - YouTube
-------------------------------------------------------------------------

 ![USMAN NURMAGOMEDOV VS ALFIE DAVIS | HIGHLIGHTS BEFORE THE MATCH - YouTube](https://i.ytimg.com/vi/ZrYbPpwVvUU/hqdefault.jpg) <small>www.youtube.com</small>USMAN NURMAGOMEDOV VS ALFIE DAVIS | HIGHLIGHTS BEFORE THE MATCH - YouTube

PFL Dubai Full Card Revealed With Usman Nurmagomedov Vs. Alfie Davis In
-----------------------------------------------------------------------

 ![PFL Dubai full card revealed with Usman Nurmagomedov vs. Alfie Davis in](https://platform.mmafighting.com/wp-content/uploads/sites/109/2025/08/20250125221838-_JP13385_.jpg?quality=90&strip=all&crop=0%2C6.1497095545259%2C100%2C78.534031413613&w=1200) <small>www.mmafighting.com</small>PFL Dubai full card revealed with Usman Nurmagomedov vs. Alfie Davis in ...

Usman Nurmagomedov Dominates Alfie Davis To Retain PFL Lightweight
------------------------------------------------------------------

 ![Usman Nurmagomedov dominates Alfie Davis to retain PFL lightweight](https://www.thenationalnews.com/resizer/v2/YRXSLCWKGNBJTIHYQ76UNEVAUA.JPG?auth=def560589771fc22ab05dd3435f061a5c3d2866722939a1bb8576d5b495c38f0) <small>www.thenationalnews.com</small>Usman Nurmagomedov dominates Alfie Davis to retain PFL lightweight ...

Usman Nurmagomedov Dominates Alfie Davis To Retain PFL Lightweight
------------------------------------------------------------------

 ![Usman Nurmagomedov dominates Alfie Davis to retain PFL lightweight](https://www.thenationalnews.com/resizer/v2/D52VITTS7FHZZNTAFVE4VZTJ7Y.JPG?auth=67a9adf2a5ab59883e11da506db4764d8d78ef46587d6d73948b77ac45e4c2f0) <small>www.thenationalnews.com</small>Usman Nurmagomedov dominates Alfie Davis to retain PFL lightweight ...

Usman Nurmagomedov Vs Alfie Davis - Full Fight Recap - YouTube
--------------------------------------------------------------

 ![Usman Nurmagomedov vs Alfie Davis - Full Fight Recap - YouTube](https://i.ytimg.com/vi/EoarzlC1krY/maxresdefault.jpg) <small>www.youtube.com</small>Usman Nurmagomedov vs Alfie Davis - Full Fight Recap - YouTube

Usman Nurmagomedov Vs Alfie Davis RECAP: Relive Usman Nurmagomedov's
--------------------------------------------------------------------

 ![Usman Nurmagomedov vs Alfie Davis RECAP: Relive Usman Nurmagomedov's](https://ichef.bbci.co.uk/ace/standard/640/cpsprodpb/vivo/live/images/2026/2/7/ea61cd8a-22c2-4e52-8164-4e29deacde9c.jpg.webp) <small>www.bbc.co.uk</small>Usman Nurmagomedov vs Alfie Davis RECAP: Relive Usman Nurmagomedov's ...

Usman Nurmagomedov Vs Alfie Davis | Highlights Before The Fight - YouTube
-------------------------------------------------------------------------

 ![Usman Nurmagomedov vs Alfie Davis | Highlights before the Fight - YouTube](https://i.ytimg.com/vi/HGzZP2WndCU/maxresdefault.jpg) <small>www.youtube.com</small>Usman Nurmagomedov vs Alfie Davis | Highlights before the Fight - YouTube

Usman Nurmagomedov Dominates Alfie Davis To Retain PFL Lightweight
------------------------------------------------------------------

 ![Usman Nurmagomedov dominates Alfie Davis to retain PFL lightweight](https://www.thenationalnews.com/resizer/v2/XEFVPMHXW5BZNNCWDT2I6KJ4VE.JPG?smart=true&auth=4f4f1c75eecfa65edc8f68a6b13ed1b77a7a53aa1ca828757c88a4a9a43c2f78&width=400&height=225) <small>www.thenationalnews.com</small>Usman Nurmagomedov dominates Alfie Davis to retain PFL lightweight ...

Usman Nurmagomedov Dominates Alfie Davis To Retain PFL Lightweight
------------------------------------------------------------------

 ![Usman Nurmagomedov dominates Alfie Davis to retain PFL lightweight](https://www.thenationalnews.com/resizer/v2/BY2EIIFFWRH4HGQSTMXY5K5NYI.JPG?auth=304a652705fd30f295f5955e5c305504958d45c93af0ae904f8f487070609155) <small>www.thenationalnews.com</small>Usman Nurmagomedov dominates Alfie Davis to retain PFL lightweight ...

Usman Nurmagomedov Vs Alfie Davis Highlights
--------------------------------------------

 ![Usman Nurmagomedov Vs Alfie Davis Highlights](https://lookaside.instagram.com/seo/google_widget/crawler/?media_id=3827508970144347224) <small>www.instagram.com</small>Usman Nurmagomedov Vs Alfie Davis Highlights

Alfie Davis Taunts Usman Nurmagomedov With Verbal Jabs Ahead Of PFL
-------------------------------------------------------------------

 ![Alfie Davis Taunts Usman Nurmagomedov with Verbal Jabs Ahead of PFL](https://aws-br-images.s3.us-east-2.amazonaws.com/images/0c/a4/0ca4198fb375a2e60aa3f3d3b5046f29.jpg) <small>www.telecomasia.net</small>Alfie Davis Taunts Usman Nurmagomedov with Verbal Jabs Ahead of PFL ...

Usman Nurmagomedov Vs Alfie Davis RECAP: Relive Usman Nurmagomedov's
--------------------------------------------------------------------

 ![Usman Nurmagomedov vs Alfie Davis RECAP: Relive Usman Nurmagomedov's](https://ichef.bbci.co.uk/ace/standard/640/cpsprodpb/vivo/live/images/2026/2/7/99182994-708a-4479-a15c-fafe7fd11642.jpg.webp) <small>www.bbc.co.uk</small>Usman Nurmagomedov vs Alfie Davis RECAP: Relive Usman Nurmagomedov's ...

Usman Nurmagomedov Vs Alfie Davis RECAP: Relive Usman Nurmagomedov's
--------------------------------------------------------------------

 ![Usman Nurmagomedov vs Alfie Davis RECAP: Relive Usman Nurmagomedov's](https://ichef.bbci.co.uk/ace/standard/640/cpsprodpb/vivo/live/images/2026/2/7/b2462704-94c1-4bc4-90c5-b3a221214a96.png.webp) <small>www.bbc.co.uk</small>Usman Nurmagomedov vs Alfie Davis RECAP: Relive Usman Nurmagomedov's ...

Usman Nurmagomedov Vs. Alfie Davis Title Bout Headlines PFL: Road To Dubai
--------------------------------------------------------------------------

 ![Usman Nurmagomedov vs. Alfie Davis title bout headlines PFL: Road to Dubai](https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA1QOp88.img?w=1000&h=666&m=4&q=75) <small>www.msn.com</small>Usman Nurmagomedov vs. Alfie Davis title bout headlines PFL: Road to Dubai

Usman Nurmagomedov Vs Alfie Davis RECAP: Relive Usman Nurmagomedov's
--------------------------------------------------------------------

 ![Usman Nurmagomedov vs Alfie Davis RECAP: Relive Usman Nurmagomedov's](https://ichef.bbci.co.uk/ace/standard/640/cpsprodpb/vivo/live/images/2026/2/7/89ee560a-05ad-4d89-8a2c-6d544736c055.jpg.webp) <small>www.bbc.co.uk</small>Usman Nurmagomedov vs Alfie Davis RECAP: Relive Usman Nurmagomedov's ...

Usman Nurmagomedov Vs Alfie Davis Set To Headline PFL: Road To Dubai
--------------------------------------------------------------------

 ![Usman Nurmagomedov vs Alfie Davis Set to Headline PFL: Road to Dubai](https://mmauk.net/wp-content/uploads/2025/11/Usman-Nurmagomedov-vs-Alfie-Davis-Set-to-Headline-PFL-Road-to-Dubai-2026.jpg) <small>mmauk.net</small>Usman Nurmagomedov vs Alfie Davis Set to Headline PFL: Road to Dubai ...

Usman Nurmagomedov Dominates Alfie Davis To Retain PFL Lightweight
------------------------------------------------------------------

 ![Usman Nurmagomedov dominates Alfie Davis to retain PFL lightweight](https://www.thenationalnews.com/resizer/v2/VJWI62VJQFBGVA5SMZSMS74K2E.JPG?auth=100effa075e12ea7d33d6b0251d80f768a8f922034e5c68d94e9efeb3293236c) <small>www.thenationalnews.com</small>Usman Nurmagomedov dominates Alfie Davis to retain PFL lightweight ...

Usman Nurmagomedov Vs Alfie Davis RECAP: Relive Usman Nurmagomedov's
--------------------------------------------------------------------

 ![Usman Nurmagomedov vs Alfie Davis RECAP: Relive Usman Nurmagomedov's](https://ichef.bbci.co.uk/ace/standard/1024/cpsprodpb/be1f/live/52513350-0464-11f1-a12b-658d26b020a4.png) <small>www.bbc.com</small>Usman Nurmagomedov vs Alfie Davis RECAP: Relive Usman Nurmagomedov's ...

PFL Full Fight: Usman Nurmagomedov Sleeps Alfie Davis In Title Defense
----------------------------------------------------------------------

 ![PFL full fight: Usman Nurmagomedov sleeps Alfie Davis in title defense](https://mmajunkie.usatoday.com/gcdn/authoring/authoring-images/2026/02/07/SMMA/88570588007-usman-nurmagomedov-def-alfie-davis-pfl-road-to-dubai-32.JPG?crop=2399,1351,x0,y124&width=2399&height=1351&format=pjpg&auto=webp) <small>mmajunkie.usatoday.com</small>PFL full fight: Usman Nurmagomedov sleeps Alfie Davis in title defense

Usman Nurmagomedov Dominates Alfie Davis To Retain PFL Lightweight
------------------------------------------------------------------

 ![Usman Nurmagomedov dominates Alfie Davis to retain PFL lightweight](https://www.thenationalnews.com/resizer/v2/YCXNSBSTUFCNBOKU5MCS5PY5EI.JPG?auth=976dda88cca9c69880074695c3b14926e26c6fc9d0e3a65f549bd7cab03620de) <small>www.thenationalnews.com</small>Usman Nurmagomedov dominates Alfie Davis to retain PFL lightweight ...

PFL Dubai: Usman Nurmagomedov Submits Alfie Davis In Third Round To
-------------------------------------------------------------------

 ![PFL Dubai: Usman Nurmagomedov submits Alfie Davis in third round to](https://ichef.bbci.co.uk/ace/standard/927/cpsprodpb/5020/live/855a0d50-0467-11f1-a12b-658d26b020a4.png) <small>www.bbc.com</small>PFL Dubai: Usman Nurmagomedov submits Alfie Davis in third round to ...

Usman Nurmagomedov Vs Alfie Davis RECAP: Relive Usman Nurmagomedov's
--------------------------------------------------------------------

 ![Usman Nurmagomedov vs Alfie Davis RECAP: Relive Usman Nurmagomedov's](https://ichef.bbci.co.uk/ace/standard/640/cpsprodpb/vivo/live/images/2026/2/7/43e7fc32-f9e1-40aa-ab80-8c8cb164b129.png.webp) <small>www.bbc.co.uk</small>Usman Nurmagomedov vs Alfie Davis RECAP: Relive Usman Nurmagomedov's ...

Usman Nurmagomedov Vs Alfie... - Dagestani Fighters Page | Facebook
-------------------------------------------------------------------

 ![Usman Nurmagomedov vs Alfie... - Dagestani fighters page | Facebook](https://lookaside.fbsbx.com/lookaside/crawler/media/?media_id=816840084215970) <small>www.facebook.com</small>Usman Nurmagomedov vs Alfie... - Dagestani fighters page | Facebook

Usman Nurmagomedov Dominates Alfie Davis To Retain PFL Lightweight
------------------------------------------------------------------

 ![Usman Nurmagomedov dominates Alfie Davis to retain PFL lightweight](https://www.thenationalnews.com/resizer/v2/YK5TYNHM2RFW3NRJ4YCVOK6CHQ.JPG?auth=f7ba41cfdd5635dcccb361c2d0c3c910445b0b7a0177d22cf0c52a90b51750a6) <small>www.thenationalnews.com</small>Usman Nurmagomedov dominates Alfie Davis to retain PFL lightweight ...

Usman Nurmagomedov Dominates Alfie Davis To Retain PFL Lightweight
------------------------------------------------------------------

 ![Usman Nurmagomedov dominates Alfie Davis to retain PFL lightweight](https://www.thenationalnews.com/resizer/v2/ZRJIPCIZE5HURNFDHHVK4ZGWPE.JPG?smart=true&auth=de799f3fb442295b515df138daa22ac832f14370f67ffa402cb033590adaea61&width=400&height=225) <small>www.thenationalnews.com</small>Usman Nurmagomedov dominates Alfie Davis to retain PFL lightweight ...

Usman Nurmagomedov Returns To Dubai To Defend PFL Title Against
---------------------------------------------------------------

 ![Usman Nurmagomedov returns to Dubai to defend PFL title against](https://www.thenationalnews.com/resizer/v2/QVCCYWR5IVBZLBBIOLWEQFZV7E.jpg?auth=de1185c00aad8615b4ff2f543fa7627b493ad4280578c5d56bb278472e1767b1) <small>www.thenationalnews.com</small>Usman Nurmagomedov returns to Dubai to defend PFL title against ...

usman nurmagomedov dominates alfie davis to retain pfl lightweight .... Usman nurmagomedov dominates alfie davis to retain pfl lightweight. Usman nurmagomedov vs alfie davis recap: relive usman nurmagomedov's
