---
title: "Usman Nurmagomedov Vs Archie Colgan - Anatomy of pfl new york: usman nurmagomedov vs archie colgan"
description: "Pfl new york: usman nurmagomedov bludgeons archie colgan in first round"
date: "2026-07-31"
categories:
- "Uncategorized"
images:
- "https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA2977Pm.img?w=570&amp;h=380&amp;m=4&amp;q=84"
featuredImage: "https://pflmma-prod.s3.amazonaws.com/articles/thumbnails/455d44c1cb80df0dc352642ebcd1feec-1-1.png"
featured_image: "https://platform.mmafighting.com/wp-content/uploads/sites/109/2026/07/unnamed_d81ed4.jpg?quality=90&amp;strip=all&amp;crop=0%2C10.737850094397%2C100%2C78.524299811207&amp;w=1200"
image: "https://mmajunkie.usatoday.com/gcdn/authoring/authoring-images/2026/08/01/SMMA/91131237007-pfl-20260731-c-2-n-01377-1.jpg?width=1320&amp;height=882&amp;fit=crop&amp;format=pjpg&amp;auto=webp"
---

If you are searching about Usman Nurmagomedov, Dakota Ditcheva booked for PFL Long Island in July you've came to the right place. We have 35 Pictures about Usman Nurmagomedov, Dakota Ditcheva booked for PFL Long Island in July like 🚨 BREAKING: Usman Nurmagomedov will defend his lightweight title, PFL New York headlined by Usman Nurmagomedov vs Archie Colgan and also Usman Nurmagomedov def. Archie Colgan at PFL New York: Best photos. Here it is:

Usman Nurmagomedov, Dakota Ditcheva Booked For PFL Long Island In July
----------------------------------------------------------------------

 ![Usman Nurmagomedov, Dakota Ditcheva booked for PFL Long Island in July](https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA246ktP.img?w=768&h=448&m=6&x=178&y=53&s=658&d=141) <small>www.msn.com</small>Usman Nurmagomedov, Dakota Ditcheva booked for PFL Long Island in July

Usman Nurmagomedov Defenderá Su Corona De PFL Ante Archie Colgan
----------------------------------------------------------------

 ![Usman Nurmagomedov defenderá su corona de PFL ante Archie Colgan](https://objetos-xlk.estaticos-marca.com/uploads/2026/05/27/6a1721c0bf3dc.jpeg) <small>www.marca.com</small>Usman Nurmagomedov defenderá su corona de PFL ante Archie Colgan

Fighters React To Usman Nurmagomedov's PFL Title Defense In Final
-----------------------------------------------------------------

 ![Fighters react to Usman Nurmagomedov's PFL title defense in final](https://hermes.media.static.aol.com/media/2026/08/01/20c54ea6-c679-39de-843a-c0fd4704743a/3fa78c04-db5f-4a67-8cf9-f0c939f0818c.jpg) <small>www.aol.com</small>Fighters react to Usman Nurmagomedov's PFL title defense in final ...

Usman Nurmagomedov | Lightweight (155)
--------------------------------------

 ![Usman Nurmagomedov | Lightweight (155)](https://pflmma-prod.s3.amazonaws.com/videos/thumbnails/54887548b6f001957bca70ce5cd6216f-1-1.png) <small>pflmma.com</small>Usman Nurmagomedov | Lightweight (155)

Nurmagomedov Vs Colgan En PFL Long Island: Claves Y Contexto — NoticiasMMA
--------------------------------------------------------------------------

 ![Nurmagomedov vs Colgan en PFL Long Island: claves y contexto — NoticiasMMA](https://pub-d7394a79b4b84aa4b63379f7f642836e.r2.dev/heroes/usman-nurmagomedov-vs-archie-colgan-claves-y-contexto-de-la-hero.webp) <small>noticiasmma.com</small>Nurmagomedov vs Colgan en PFL Long Island: claves y contexto — NoticiasMMA

Usman Nurmagomedov To Defend Title Against Archie Colgan In New York
--------------------------------------------------------------------

 ![Usman Nurmagomedov to Defend Title Against Archie Colgan in New York](https://sportnews.az/storage/thumbs/aspect/101b133c-32d7-433d-8da4-07779c05ca01.webp) <small>sportnews.az</small>Usman Nurmagomedov to Defend Title Against Archie Colgan in New York ...

PFL New York Results: Usman Nurmagomedov Takes Out Archie Colgan To
-------------------------------------------------------------------

 ![PFL New York Results: Usman Nurmagomedov takes out Archie Colgan to](https://www.mmaweekly.com/.image/Mjk6MDAwMDAwMDAwMTE5ODU3/usman-nurmagomedov-pflnewyork-1600.jpg?profile=share16-9) <small>www.mmaweekly.com</small>PFL New York Results: Usman Nurmagomedov takes out Archie Colgan to ...

PFL New York Headlined By Usman Nurmagomedov Vs Archie Colgan
-------------------------------------------------------------

 ![PFL New York headlined by Usman Nurmagomedov vs Archie Colgan](https://mymmanews.com/wp-content/uploads/2026/05/pfl-new-york-main-1536x864.jpg) <small>mymmanews.com</small>PFL New York headlined by Usman Nurmagomedov vs Archie Colgan

PFL New York: Usman Nurmagomedov Bludgeons Archie Colgan In First Round
-----------------------------------------------------------------------

 ![PFL New York: Usman Nurmagomedov bludgeons Archie Colgan in first round](https://mmajunkie.usatoday.com/gcdn/authoring/authoring-images/2026/08/01/SMMA/91130785007-usman-2.jpg?crop=1919) <small>mmajunkie.usatoday.com</small>PFL New York: Usman Nurmagomedov bludgeons Archie Colgan in first round

🚨 BREAKING: Usman Nurmagomedov Will Defend His Lightweight Title
----------------------------------------------------------------

 ![🚨 BREAKING: Usman Nurmagomedov will defend his lightweight title](https://pbs.twimg.com/media/HJQQC4OWYAAK26s.jpg) <small>x.com</small>🚨 BREAKING: Usman Nurmagomedov will defend his lightweight title ...

Usman Nurmagomedov Def. Archie Colgan At PFL New York: Best Photos
------------------------------------------------------------------

 ![Usman Nurmagomedov def. Archie Colgan at PFL New York: Best photos](https://mmajunkie.usatoday.com/gcdn/authoring/authoring-images/2026/08/01/SMMA/91131238007-pfl-20260731-c-2-n-01473-1.jpg?crop=8224,4626,x0,y428&width=3200&height=1800&format=pjpg&auto=webp) <small>mmajunkie.usatoday.com</small>Usman Nurmagomedov def. Archie Colgan at PFL New York: Best photos

PFL New York Live Blog: Usman Nurmagomedov Vs. Archie Colgan | MMA Fighting
---------------------------------------------------------------------------

 ![PFL New York live blog: Usman Nurmagomedov vs. Archie Colgan | MMA Fighting](https://platform.mmafighting.com/wp-content/uploads/sites/109/2026/07/unnamed_d81ed4.jpg?quality=90&strip=all&crop=0%2C10.737850094397%2C100%2C78.524299811207&w=1200) <small>www.mmafighting.com</small>PFL New York live blog: Usman Nurmagomedov vs. Archie Colgan | MMA Fighting

PFL Bringing Usman Nurmagomedov, Dakota Ditcheva To Long Island On Star
-----------------------------------------------------------------------

 ![PFL bringing Usman Nurmagomedov, Dakota Ditcheva to Long Island on star](https://s.yimg.com/ny/api/res/1.2/qJyWp1M0UZ4TJD_W9a1vtg--/YXBwaWQ9aGlnaGxhbmRlcjt3PTk2MDtoPTYzOTtjZj13ZWJw/https://media.zenfs.com/en/ny_post_sports_articles_389/71e1d2e6d78ecb282fec71d62b375d24) <small>sports.yahoo.com</small>PFL bringing Usman Nurmagomedov, Dakota Ditcheva to Long Island on star ...

PFL New York: Usman Nurmagomedov Bludgeons Archie Colgan In First Round
-----------------------------------------------------------------------

 ![PFL New York: Usman Nurmagomedov bludgeons Archie Colgan in first round](https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA29aKgG.img?w=768&h=652&m=6&x=726&y=112&s=73&d=73) <small>www.msn.com</small>PFL New York: Usman Nurmagomedov bludgeons Archie Colgan in first round

ANATOMY OF PFL NEW YORK: USMAN NURMAGOMEDOV Vs ARCHIE COLGAN | Fight
--------------------------------------------------------------------

 ![ANATOMY OF PFL NEW YORK: USMAN NURMAGOMEDOV vs ARCHIE COLGAN | Fight](https://i.ytimg.com/vi/zR4hhZ3Ijao/maxresdefault.jpg) <small>www.youtube.com</small>ANATOMY OF PFL NEW YORK: USMAN NURMAGOMEDOV vs ARCHIE COLGAN | Fight ...

Archie Colgan Shares Encouraging Health Update After Scary KO Loss To
---------------------------------------------------------------------

 ![Archie Colgan shares encouraging health update after scary KO loss to](https://www.bjpenn.com/wp-content/uploads/2026/08/MixCollage-03-Aug-2026-01-56-PM-6727.jpg) <small>www.bjpenn.com</small>Archie Colgan shares encouraging health update after scary KO loss to ...

Archie Colgan Confident He Can End Usman Nurmagomedov's PFL Title Run
---------------------------------------------------------------------

 ![Archie Colgan confident he can end Usman Nurmagomedov's PFL title run](https://mmajunkie.usatoday.com/gcdn/authoring/authoring-images/2025/06/21/SMMA/84296187007-pfl-20250620-c-1-n-02832-1.jpg?crop=6329,3560,x0,y0&width=3200&height=1800&format=pjpg&auto=webp) <small>mmajunkie.usatoday.com</small>Archie Colgan confident he can end Usman Nurmagomedov's PFL title run

🚨BREAKING NEWS🚨 🏆Usman Nurmagomedov (21-0) Defenderá Su Cinturón Del
--------------------------------------------------------------------

 ![🚨BREAKING NEWS🚨 🏆Usman Nurmagomedov (21-0) defenderá su cinturón del](https://pbs.twimg.com/media/HJQMT3jWwAAV9fA.jpg) <small>x.com</small>🚨BREAKING NEWS🚨 🏆Usman Nurmagomedov (21-0) defenderá su cinturón del ...

Usman Nurmagomedov Faces Rising Threat Archie Colgan As Dakota Ditcheva
-----------------------------------------------------------------------

 ![Usman Nurmagomedov faces rising threat Archie Colgan as Dakota Ditcheva](https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA246pv5.img?w=768&h=432&m=6&x=122&y=74&s=708&d=259) <small>www.msn.com</small>Usman Nurmagomedov faces rising threat Archie Colgan as Dakota Ditcheva ...

Usman Nurmagomedov Def. Archie Colgan At PFL New York: Best Photos
------------------------------------------------------------------

 ![Usman Nurmagomedov def. Archie Colgan at PFL New York: Best photos](https://mmajunkie.usatoday.com/gcdn/authoring/authoring-images/2026/08/01/SMMA/91131237007-pfl-20260731-c-2-n-01377-1.jpg?width=1320&height=882&fit=crop&format=pjpg&auto=webp) <small>mmajunkie.usatoday.com</small>Usman Nurmagomedov def. Archie Colgan at PFL New York: Best photos

Nurmagomedov Gegen Colgan (31. Juli 2026): Live-Übertragung, Uhrzeit
--------------------------------------------------------------------

 ![Nurmagomedov gegen Colgan (31. Juli 2026): Live-Übertragung, Uhrzeit](https://champinon.info/images/archie-colgan_b.webp) <small>champinon.info</small>Nurmagomedov gegen Colgan (31. Juli 2026): Live-Übertragung, Uhrzeit

PFL's Usman Nurmagomedov To Defend Title Vs. Archie Colgan - ESPN
-----------------------------------------------------------------

 ![PFL's Usman Nurmagomedov to defend title vs. Archie Colgan - ESPN](https://a1.espncdn.com/combiner/i?img=%2Fphoto%2F2026%2F0204%2Fr1610269_1296x729_16%2D9.jpg) <small>www.espn.com</small>PFL's Usman Nurmagomedov to defend title vs. Archie Colgan - ESPN

Usman Nurmagomedov Vs Archie Colgan FULL FIGHT HIGHLIGHTS | PFL New
-------------------------------------------------------------------

 ![Usman Nurmagomedov vs Archie Colgan FULL FIGHT HIGHLIGHTS | PFL New](https://i.ytimg.com/vi/Ys5rvQKQMTA/maxresdefault.jpg) <small>www.youtube.com</small>Usman Nurmagomedov vs Archie Colgan FULL FIGHT HIGHLIGHTS | PFL New ...

Usman Nurmagomedov Defends The World Title Against Archie Colgan
----------------------------------------------------------------

 ![Usman Nurmagomedov Defends the World Title Against Archie Colgan](https://pflmma-prod.s3.amazonaws.com/articles/thumbnails/455d44c1cb80df0dc352642ebcd1feec-1-1.png) <small>pflmma.com</small>Usman Nurmagomedov Defends the World Title Against Archie Colgan ...

PFL New York Results: Usman Nurmagomedov Obliterates Archie Colgan On
---------------------------------------------------------------------

 ![PFL New York results: Usman Nurmagomedov obliterates Archie Colgan on](https://s.yimg.com/lo/mysterio/api/b58b37fbf3265eb08e0b9e6d82850d7fae27f4fb0542f4ef164841170bc08f79/lightyear_networkapi/resizefill_w1200_h675%3Bquality_80%3Bformat_webp/https://d29szjachogqwa.cloudfront.net/images/2026-07/eb92897a-f1a9-4654-a203-8756552e063d) <small>sports.yahoo.com</small>PFL New York results: Usman Nurmagomedov obliterates Archie Colgan on ...

Usman Nurmagomedov Vs. Archie Colgan, PFL New York | MMA Bout | Tapology
------------------------------------------------------------------------

 ![Usman Nurmagomedov vs. Archie Colgan, PFL New York | MMA Bout | Tapology](https://images.tapology.com/poster_images/144072/profile/SnapInsta.to_707499178_18595727038013832_3534947330590306099_n.jpg?1779810333) <small>www.tapology.com</small>Usman Nurmagomedov vs. Archie Colgan, PFL New York | MMA Bout | Tapology

Usman Nurmagomedov Interpelle L'UFC Après Sa Victoire Par K.-O. Sur
-------------------------------------------------------------------

 ![Usman Nurmagomedov interpelle l'UFC après sa victoire par K.-O. sur](https://www.actumma.com/wp-content/uploads/2026/08/usman-nurmagomedov-ko-archie-colgan-pfl-new-york-interpelle-ufc-1024x576.jpg) <small>www.actumma.com</small>Usman Nurmagomedov interpelle l'UFC après sa victoire par K.-O. sur ...

Khabib Nurmagomedov Admits Archie Colgan Is Usman Nurmagomedov's
----------------------------------------------------------------

 ![Khabib Nurmagomedov admits Archie Colgan is Usman Nurmagomedov's](https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA2977Pm.img?w=570&h=380&m=4&q=84) <small>www.msn.com</small>Khabib Nurmagomedov admits Archie Colgan is Usman Nurmagomedov's ...

𝙔𝙊𝙐𝙍 𝙋𝙁𝙇 𝙇𝙄𝙂𝙃𝙏𝙒𝙀𝙄𝙂𝙃𝙏 𝙒𝙊𝙍𝙇𝘿 𝙏𝙄𝙏𝙇𝙀 𝙈𝘼𝙄𝙉 | Usman Nurmagomedov | TikTok
-------------------------------------------------------------------

 ![𝙔𝙊𝙐𝙍 𝙋𝙁𝙇 𝙇𝙄𝙂𝙃𝙏𝙒𝙀𝙄𝙂𝙃𝙏 𝙒𝙊𝙍𝙇𝘿 𝙏𝙄𝙏𝙇𝙀 𝙈𝘼𝙄𝙉 | Usman Nurmagomedov | TikTok](https://www.tiktok.com/api/img/?itemId=7667791695450262815&location=0&aid=1988) <small>www.tiktok.com</small>𝙔𝙊𝙐𝙍 𝙋𝙁𝙇 𝙇𝙄𝙂𝙃𝙏𝙒𝙀𝙄𝙂𝙃𝙏 𝙒𝙊𝙍𝙇𝘿 𝙏𝙄𝙏𝙇𝙀 𝙈𝘼𝙄𝙉 ... | Usman Nurmagomedov | TikTok

Usman Nurmagomedov Defends The World Title Against Archie Colgan
----------------------------------------------------------------

 ![Usman Nurmagomedov Defends the World Title Against Archie Colgan](https://pflmma-prod.s3.amazonaws.com/articles/featured/2be207891456ee3632896deb8969d435-1-1.jpg) <small>pflmma.com</small>Usman Nurmagomedov Defends the World Title Against Archie Colgan ...

Usman Nurmagomedov Vs Archie Colgan: Who Will Win? - CasinoNewsWatch
--------------------------------------------------------------------

 ![Usman Nurmagomedov vs Archie Colgan: Who Will Win? - CasinoNewsWatch](https://casinonewswatch.com/images/large/blurred/nurmagomedov_colgan_fight_03_18_2026_1e907deb-894c-48b6-9b0c-b760c73ad37f.webp?width=720&height=720) <small>casinonewswatch.com</small>Usman Nurmagomedov vs Archie Colgan: Who Will Win? - CasinoNewsWatch

PFL New York: Usman Nurmagomedov Bludgeons Archie Colgan In First Round
-----------------------------------------------------------------------

 ![PFL New York: Usman Nurmagomedov bludgeons Archie Colgan in first round](https://mmajunkie.usatoday.com/gcdn/authoring/authoring-images/2026/08/01/SMMA/91131217007-pfl-20260731-c-2-n-01088-1.jpg?crop=6306,3548,x0,y328&width=3200&height=1801&format=pjpg&auto=webp) <small>mmajunkie.usatoday.com</small>PFL New York: Usman Nurmagomedov bludgeons Archie Colgan in first round

Usman Nurmagomedov To Defend PFL Lightweight Title Vs. Archie Colgan
--------------------------------------------------------------------

 ![Usman Nurmagomedov to Defend PFL Lightweight Title vs. Archie Colgan](https://gidstats.com/img/news/500/300/90260184007-test.webp) <small>gidstats.com</small>Usman Nurmagomedov to Defend PFL Lightweight Title vs. Archie Colgan

PFL Lightweight Title Clash Heads To Long Island On July 31
-----------------------------------------------------------

 ![PFL Lightweight Title Clash Heads to Long Island on July 31](https://pbs.twimg.com/media/HJQM8ZxXsAAvpP2.jpg) <small>x.com</small>PFL Lightweight Title Clash Heads to Long Island on July 31

Usman Nurmagomedov Vs Archie Colgan | PFL New York | DAZN Highlights
--------------------------------------------------------------------

 ![Usman Nurmagomedov vs Archie Colgan | PFL New York | DAZN Highlights](https://i.ytimg.com/vi/kdZ3vjRoqYg/maxresdefault.jpg) <small>www.youtube.com</small>Usman Nurmagomedov vs Archie Colgan | PFL New York | DAZN Highlights ...

Anatomy of pfl new york: usman nurmagomedov vs archie colgan. Usman nurmagomedov defends the world title against archie colgan. Pfl new york: usman nurmagomedov bludgeons archie colgan in first round
