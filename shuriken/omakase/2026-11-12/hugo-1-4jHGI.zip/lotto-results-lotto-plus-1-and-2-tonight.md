---
title: "Lotto Results Lotto Plus 1 And 2 Tonight - lotto results lotto plus 1 and 2 today new arrivals"
description: "Tonight’s lotto results 02 may 2026💰 lotto, lotto plus 1 &amp; plus 2"
date: "2026-01-23"
categories:
- "Uncategorized"
images:
- "https://powerball.us.org/images/lottoplustwosa/1.webp"
featuredImage: "https://i.ytimg.com/vi/OVUYk5TbOww/maxresdefault.jpg"
featured_image: "https://i.ytimg.com/vi/WqZq3sTiu_o/maxresdefault.jpg"
image: "https://media.citizen.co.za/wp-content/uploads/2026/04/Screenshot-2026-04-04-210248.jpg"
---

If you are looking for Irish Lotto results - Numbers in for Saturday February 1 €2m jackpot you've came to the right page. We have 35 Pics about Irish Lotto results - Numbers in for Saturday February 1 €2m jackpot like Lotto plus 1 plus 2 results online, Lotto draws: Numbers, results, payouts, winner, ithuba lottery and also BAD news for RESET Lotto and Lotto Plus 1 and 2 on Saturday 9 May 2026. Read more:

Irish Lotto Results - Numbers In For Saturday February 1 €2m Jackpot
--------------------------------------------------------------------

 ![Irish Lotto results - Numbers in for Saturday February 1 €2m jackpot](https://www.thesun.ie/wp-content/uploads/sites/3/2020/02/LottoSatFeb1.png?strip=all&w=960) <small>www.thesun.ie</small>Irish Lotto results - Numbers in for Saturday February 1 €2m jackpot ...

R98 Million UP For Grabs: Lotto And Lotto Plus 1 And 2 On Wednesday 29
----------------------------------------------------------------------

 ![R98 million UP for grabs: Lotto and Lotto Plus 1 and 2 on Wednesday 29](https://www.thesouthafrican.com/wp-content/uploads/2026/04/Lotto-and-Lotto-Plus-1-and-2-on-Wednesday-29-April-2026_1-1200x321.png) <small>www.thesouthafrican.com</small>R98 million UP for grabs: Lotto and Lotto Plus 1 and 2 on Wednesday 29 ...

Lotto Draws: Numbers, Results, Payouts, Winner, Ithuba Lottery
--------------------------------------------------------------

 ![Lotto draws: Numbers, results, payouts, winner, ithuba lottery](https://www.thesouthafrican.com/wp-content/uploads/2024/09/image-1.png) <small>www.thesouthafrican.com</small>Lotto draws: Numbers, results, payouts, winner, ithuba lottery

Lotto Plus 1 Plus 2 Results Online
----------------------------------

 ![Lotto plus 1 plus 2 results online](https://pbs.twimg.com/media/EOX9TJlUUAArL9n.png) <small>www.namibian.com.na</small>Lotto plus 1 plus 2 results online

Lotto And Lotto Plus Results: Winning Numbers
---------------------------------------------

 ![Lotto and Lotto Plus Results: Winning Numbers](https://www.thesouthafrican.com/wp-content/uploads/2026/05/Lotto-and-Lotto-Plus-1-and-2-on-Saturday-16-May-2026_1-640x427.jpg.optimal.jpg) <small>www.thesouthafrican.com</small>Lotto and Lotto Plus Results: Winning Numbers

Lotto And Lotto Plus Results: Saturday, 4 April 2026 | The Citizen
------------------------------------------------------------------

 ![Lotto and Lotto Plus results: Saturday, 4 April 2026 | The Citizen](https://media.citizen.co.za/wp-content/uploads/2026/04/Screenshot-2026-04-04-210248.jpg) <small>www.citizen.co.za</small>Lotto and Lotto Plus results: Saturday, 4 April 2026 | The Citizen

Lotto Plus 1 And Lotto Plus 2 Online
------------------------------------

 ![Lotto plus 1 and lotto plus 2 online](https://media.citizen.co.za/wp-content/uploads/2021/10/LOTTO-PLUS-2-002.jpg) <small>www.namibian.com.na</small>Lotto plus 1 and lotto plus 2 online

R67 Million On LINE For Lotto And Lotto Plus 1 And 2 On Saturday 14
-------------------------------------------------------------------

 ![R67 million on LINE for Lotto and Lotto Plus 1 and 2 on Saturday 14](https://www.thesouthafrican.com/wp-content/uploads/2026/03/Lotto-and-Lotto-Plus-1-and-2-on-Saturday-14-March-2026_1.jpg.optimal.jpg) <small>www.thesouthafrican.com</small>R67 million on LINE for Lotto and Lotto Plus 1 and 2 on Saturday 14 ...

BAD News For RESET Lotto And Lotto Plus 1 And 2 On Saturday 9 May 2026
----------------------------------------------------------------------

 ![BAD news for RESET Lotto and Lotto Plus 1 and 2 on Saturday 9 May 2026](https://www.thesouthafrican.com/wp-content/uploads/2026/05/Lotto-and-Lotto-Plus-1-and-2-on-Saturday-9-May-2026_2.png) <small>www.thesouthafrican.com</small>BAD news for RESET Lotto and Lotto Plus 1 and 2 on Saturday 9 May 2026

Tonight’s Lotto Results 08 April 2026 💰 Lotto, Lotto Plus 1 &amp; Plus 2
------------------------------------------------------------------------

 ![Tonight’s Lotto Results 08 April 2026 💰 Lotto, Lotto Plus 1 & Plus 2](https://i.ytimg.com/vi/w3rkJ-zQ-9o/hqdefault.jpg) <small>www.youtube.com</small>Tonight’s Lotto Results 08 April 2026 💰 Lotto, Lotto Plus 1 &amp; Plus 2 ...

Tonight’s Lotto Results 09 May 2026 💰 Lotto, Lotto Plus 1 &amp; Plus 2
----------------------------------------------------------------------

 ![Tonight’s Lotto Results 09 May 2026 💰 Lotto, Lotto Plus 1 & Plus 2](https://i.ytimg.com/vi/aJJ7GcWeC2g/maxresdefault.jpg) <small>www.youtube.com</small>Tonight’s Lotto Results 09 May 2026 💰 Lotto, Lotto Plus 1 &amp; Plus 2 ...

Lotto Plus 2 Results, Prizes For 7 December 2024 (Saturday 07.12.2024)
----------------------------------------------------------------------

 ![Lotto Plus 2 results, Prizes for 7 December 2024 (Saturday 07.12.2024)](https://cdn.africanlottery.net/img/results/lotto-plus-2-results-no-2495.webp) <small>www.africanlottery.net</small>Lotto Plus 2 results, Prizes for 7 December 2024 (Saturday 07.12.2024)

South Africa Lotto, Lotto Plus 1 &amp; Lotto Plus 2 Results: Draw 2619
----------------------------------------------------------------------

 ![South Africa Lotto, Lotto Plus 1 & Lotto Plus 2 Results: Draw 2619](https://swikblog.com/wp-content/uploads/2026/01/lotto-google-news-1200x628-under-100kb-1024x536.webp) <small>swikblog.com</small>South Africa Lotto, Lotto Plus 1 &amp; Lotto Plus 2 Results: Draw 2619 ...

Lotto Plus Two 1 July 2026 Wednesday, Results Tonight, South Africa
-------------------------------------------------------------------

 ![Lotto Plus Two 1 July 2026 Wednesday, Results Tonight, South Africa](https://powerball.us.org/images/lottoplustwosa/1.webp) <small>powerball.us.org</small>Lotto Plus Two 1 July 2026 Wednesday, Results Tonight, South Africa

Tonight’s Lotto Results 27 May 2026 💰 Lotto, Lotto Plus 1 &amp; Plus 2
----------------------------------------------------------------------

 ![Tonight’s Lotto Results 27 May 2026 💰 Lotto, Lotto Plus 1 & Plus 2](https://i.ytimg.com/vi/OVUYk5TbOww/maxresdefault.jpg) <small>www.youtube.com</small>Tonight’s Lotto Results 27 May 2026 💰 Lotto, Lotto Plus 1 &amp; Plus 2 ...

Lotto And Lotto Plus Results: Winning Numbers
---------------------------------------------

 ![Lotto and Lotto Plus Results: Winning Numbers](https://www.thesouthafrican.com/wp-content/uploads/2026/05/Lotto-Plus-1-jackpot-winner-768x531.jpg.optimal.jpg) <small>www.thesouthafrican.com</small>Lotto and Lotto Plus Results: Winning Numbers

Tonight’s Lotto Results And Payouts: Saturday, 1 November 2025
--------------------------------------------------------------

 ![Tonight’s Lotto results and payouts: Saturday, 1 November 2025](https://www.swisherpost.com/wp-content/uploads/2025/11/swisherpost-lotto-results-1-november-2025.jpg) <small>www.swisherpost.com</small>Tonight’s Lotto results and payouts: Saturday, 1 November 2025 ...

Daily Lotto Result: ONE Lucky Winner Of Thursday's Jackpot Payouts
------------------------------------------------------------------

 ![Daily Lotto result: ONE lucky winner of Thursday's jackpot payouts](https://www.thesouthafrican.com/wp-content/uploads/2023/02/09-feb-daily-lotto.jpeg) <small>www.sapeople.com</small>Daily Lotto result: ONE lucky winner of Thursday's jackpot payouts

R67 Million On LINE For Lotto And Lotto Plus 1 And 2 On Saturday 14
-------------------------------------------------------------------

 ![R67 million on LINE for Lotto and Lotto Plus 1 and 2 on Saturday 14](https://www.thesouthafrican.com/wp-content/uploads/2026/03/Lotto-and-Lotto-Plus-1-and-2-on-Saturday-14-March-2026_7.jpg.optimal.jpg) <small>www.thesouthafrican.com</small>R67 million on LINE for Lotto and Lotto Plus 1 and 2 on Saturday 14 ...

ITHUBA Confirms Lotto Plus 1 And Lotto Plus 2 Jackpots WON
----------------------------------------------------------

 ![ITHUBA confirms Lotto Plus 1 and Lotto Plus 2 jackpots WON](https://www.thesouthafrican.com/wp-content/uploads/2026/04/image-28.png) <small>www.thesouthafrican.com</small>ITHUBA confirms Lotto Plus 1 and Lotto Plus 2 jackpots WON

Lotto And Lotto Plus Results: Winning Numbers
---------------------------------------------

 ![Lotto and Lotto Plus Results: Winning Numbers](https://www.thesouthafrican.com/wp-content/uploads/2026/04/Lotto-and-Lotto-Plus-1-and-2-on-Saturday-2-May-2026_4-750x500.jpg.optimal.jpg) <small>www.thesouthafrican.com</small>Lotto and Lotto Plus Results: Winning Numbers

Tonight’s Lotto Results 02 May 2026💰 Lotto, Lotto Plus 1 &amp; Plus 2 - YouTube
-------------------------------------------------------------------------------

 ![Tonight’s Lotto Results 02 May 2026💰 Lotto, Lotto Plus 1 & Plus 2 - YouTube](https://i.ytimg.com/vi/WqZq3sTiu_o/maxresdefault.jpg) <small>www.youtube.com</small>Tonight’s Lotto Results 02 May 2026💰 Lotto, Lotto Plus 1 &amp; Plus 2 - YouTube

ITHUBA Confirms Lotto Plus 1 And Lotto Plus 2 Jackpots WON
----------------------------------------------------------

 ![ITHUBA confirms Lotto Plus 1 and Lotto Plus 2 jackpots WON](https://www.thesouthafrican.com/wp-content/uploads/2026/04/Lotto-and-Lotto-Plus-1-and-2-on-Wednesday-8-April-2026_1.jpg.optimal.jpg) <small>www.thesouthafrican.com</small>ITHUBA confirms Lotto Plus 1 and Lotto Plus 2 jackpots WON

Lotto Results Lotto Plus 1 And 2 Today New Arrivals
---------------------------------------------------

 ![Lotto results lotto plus 1 and 2 today new arrivals](https://www.saffarazzi.com/wp-content/uploads/2021/10/lotto-and-lotto-plus-results-saturday-south-africa.webp) <small>pediatrianorte.med.uchile.cl</small>Lotto results lotto plus 1 and 2 today new arrivals

SA Lotto Results 22 April 2026 | Lotto Plus 1 &amp; 2 Winning Numbers Today
---------------------------------------------------------------------------

 ![SA Lotto Results 22 April 2026 | Lotto Plus 1 & 2 Winning Numbers Today](https://swikblog.com/wp-content/uploads/2026/04/powerballresultstoday-lotto-results-today-1024x683.webp) <small>swikblog.com</small>SA Lotto Results 22 April 2026 | Lotto Plus 1 &amp; 2 Winning Numbers Today

R98 Million UP For Grabs: Lotto And Lotto Plus 1 And 2 On Wednesday 29
----------------------------------------------------------------------

 ![R98 million UP for grabs: Lotto and Lotto Plus 1 and 2 on Wednesday 29](https://www.thesouthafrican.com/wp-content/uploads/2026/04/Lotto-and-Lotto-Plus-1-and-2-on-Wednesday-29-April-2026_1-960x257.png) <small>www.thesouthafrican.com</small>R98 million UP for grabs: Lotto and Lotto Plus 1 and 2 on Wednesday 29 ...

Siya Kolisi Reunites With Zozi Tunzi After THAT Viral Moment
------------------------------------------------------------

 ![Siya Kolisi reunites with Zozi Tunzi after THAT viral moment](https://www.thesouthafrican.com/wp-content/uploads/2026/03/Lotto-and-Lotto-Plus-1-and-2-on-Saturday-7-March-2026_4.jpg.optimal.jpg) <small>www.thesouthafrican.com</small>Siya Kolisi reunites with Zozi Tunzi after THAT viral moment

R54-million Payday For Lotto And Lotto Plus 1 And 2 On Saturday 28
------------------------------------------------------------------

 ![R54-million payday for Lotto and Lotto Plus 1 and 2 on Saturday 28](https://www.thesouthafrican.com/wp-content/uploads/2026/02/Lotto-and-Lotto-Plus-1-and-2-on-Saturday-28-February-2026-.jpg.optimal.jpg) <small>www.thesouthafrican.com</small>R54-million payday for Lotto and Lotto Plus 1 and 2 on Saturday 28 ...

Lotto Results 19 November 2025 – Winning Numbers, Lotto Plus 1 &amp; Plus 2
---------------------------------------------------------------------------

 ![Lotto Results 19 November 2025 – Winning Numbers, Lotto Plus 1 & Plus 2](https://www.techchamp.co.za/wp-content/uploads/2025/12/Lotto-Lotto-Plus-1-Lotto-Plus-2-Results-for-Wednesday-03-December-2025.webp) <small>www.techchamp.co.za</small>Lotto Results 19 November 2025 – Winning Numbers, Lotto Plus 1 &amp; Plus 2 ...

Tonight’s Lotto Results 13 May 2026 💰 Lotto, Lotto Plus 1 &amp; Plus 2
----------------------------------------------------------------------

 ![Tonight’s Lotto Results 13 May 2026 💰 Lotto, Lotto Plus 1 & Plus 2](https://i.ytimg.com/vi/VV9UfMu68YA/maxresdefault.jpg) <small>www.youtube.com</small>Tonight’s Lotto Results 13 May 2026 💰 Lotto, Lotto Plus 1 &amp; Plus 2 ...

R99-million PAYDAY For Lotto And Lotto Plus 1 And 2 On Wednesday 8
------------------------------------------------------------------

 ![R99-million PAYDAY for Lotto and Lotto Plus 1 and 2 on Wednesday 8](https://www.thesouthafrican.com/wp-content/uploads/2026/04/Lotto-and-Lotto-Plus-1-and-2-on-Wednesday-8-April-2026_2.jpg.optimal.jpg) <small>www.thesouthafrican.com</small>R99-million PAYDAY for Lotto and Lotto Plus 1 and 2 on Wednesday 8 ...

Lotto Results And Payouts &amp; Lotto Plus Best Sale | Www.cityofclovis.org
---------------------------------------------------------------------------

 ![Lotto Results And Payouts & Lotto Plus Best Sale | www.cityofclovis.org](https://media.citizen.co.za/wp-content/uploads/2018/12/Screenshot-2018-12-06-at-08.45.46.png) <small>www.cityofclovis.org</small>Lotto Results And Payouts &amp; Lotto Plus Best Sale | www.cityofclovis.org

Lotto Plus 1 Draw #2677 On September 2, 2026 — Results — South Africa
---------------------------------------------------------------------

 ![Lotto Plus 1 Draw #2677 on September 2, 2026 — Results — South Africa](https://statlotto.com/og/za/lotto-plus-1/result.png?locale=en) <small>statlotto.com</small>Lotto Plus 1 Draw #2677 on September 2, 2026 — Results — South Africa

Lotto Plus 1 And 2 Online
-------------------------

 ![Lotto plus 1 and 2 online](https://www.magiclotto.co.za/Assets/images/news/DIowyYzVYAEVvhD.jpg) <small>www.namibian.com.na</small>Lotto plus 1 and 2 online

10 Previous Lotto Results Online
--------------------------------

 ![10 previous lotto results online](https://www.saffarazzi.com/wp-content/uploads/2024/01/20240110-wednesday-south-africa-lotto-and-lotto-plus-results.webp) <small>www.namibian.com.na</small>10 previous lotto results online

Lotto plus 1 draw #2677 on september 2, 2026 — results — south africa. lotto plus two 1 july 2026 wednesday, results tonight, south africa. R98 million up for grabs: lotto and lotto plus 1 and 2 on wednesday 29
