---
title: "Lotto Plus 1 And Plus 2 - Lotto results 19 november 2025 – winning numbers, lotto plus 1 &amp; plus 2"
description: "Lotto results and payouts &amp; lotto plus best sale"
date: "2026-08-23"
categories:
- "Uncategorized"
images:
- "https://www.techchamp.co.za/wp-content/uploads/2025/11/Lotto-Lotto-Plus-1-and-Lotto-Plus-2-Results-for-Saturday-15-November-2025.jpg"
featuredImage: "https://www.thesouthafrican.com/wp-content/uploads/2026/04/Lotto-and-Lotto-Plus-1-and-2-on-Wednesday-29-April-2026_1-960x257.png"
featured_image: "https://i.pinimg.com/736x/b6/4f/3d/b64f3dfa01d82a81dd4fc7e3b3b85094.jpg"
image: "https://www.techchamp.co.za/wp-content/uploads/2025/11/Lotto-Lotto-Plus-1-and-Lotto-Plus-2-Results-for-Saturday-15-November-2025.jpg"
---

If you are searching about ALL you need to know about Daily Lotto, Lotto Plus and PowerBall draws you've visit to the right web. We have 34 Pictures about ALL you need to know about Daily Lotto, Lotto Plus and PowerBall draws like Lotto and Lotto Plus 1 and 2 on Saturday 7 February 2026 promises R41, BAD news for RESET Lotto and Lotto Plus 1 and 2 on Saturday 9 May 2026 and also R98 million UP for grabs: Lotto and Lotto Plus 1 and 2 on Wednesday 29. Here you go:

ALL You Need To Know About Daily Lotto, Lotto Plus And PowerBall Draws
----------------------------------------------------------------------

 ![ALL you need to know about Daily Lotto, Lotto Plus and PowerBall draws](https://www.thesouthafrican.com/wp-content/uploads/2025/04/Lotto.jpg.optimal.jpg) <small>www.thesouthafrican.com</small>ALL you need to know about Daily Lotto, Lotto Plus and PowerBall draws

South Africa Lotto, Lotto Plus 1, Lotto Plus 2 Results For Saturday
-------------------------------------------------------------------

 ![South Africa Lotto, Lotto Plus 1, Lotto Plus 2 Results for Saturday](https://www.businessnews.ph/wp-content/uploads/2021/02/lotto-Plus.png) <small>www.businessnews.ph</small>South Africa Lotto, Lotto Plus 1, Lotto Plus 2 Results for Saturday ...

How Does Super Lotto Plus Work At Mia Fortune Blog
--------------------------------------------------

 ![How Does Super Lotto Plus Work at Mia Fortune blog](https://www.lottery.co.za/images/lotto-plus.jpg) <small>storage.googleapis.com</small>How Does Super Lotto Plus Work at Mia Fortune blog

SA Lotto Plus 2 Summary - 2024-09-21
------------------------------------

 ![SA Lotto Plus 2 Summary - 2024-09-21](https://cdn.africanlottery.net/img/results/lotto-plus-2-results-no-2475.webp) <small>www.africanlottery.net</small>SA Lotto Plus 2 Summary - 2024-09-21

R89-million April FOOL’s For Lotto And Lotto Plus 1 And 2 On Wednesday
----------------------------------------------------------------------

 ![R89-million April FOOL’s for Lotto and Lotto Plus 1 and 2 on Wednesday](https://www.thesouthafrican.com/wp-content/uploads/2026/03/Lotto-and-Lotto-Plus-1-and-2-on-Wednesday-1-April-2026_1.png) <small>www.thesouthafrican.com</small>R89-million April FOOL’s for Lotto and Lotto Plus 1 and 2 on Wednesday ...

Lotto And Lotto Plus Results: Winning Numbers
---------------------------------------------

 ![Lotto and Lotto Plus Results: Winning Numbers](https://www.thesouthafrican.com/wp-content/uploads/2026/04/Lotto-and-Lotto-Plus-1-and-2-on-Saturday-2-May-2026_4-750x500.jpg.optimal.jpg) <small>www.thesouthafrican.com</small>Lotto and Lotto Plus Results: Winning Numbers

Lotto Draws: Numbers, Results, Payouts, Winner, Ithuba Lottery
--------------------------------------------------------------

 ![Lotto draws: Numbers, results, payouts, winner, ithuba lottery](https://www.thesouthafrican.com/wp-content/uploads/2024/09/image-1.png) <small>www.thesouthafrican.com</small>Lotto draws: Numbers, results, payouts, winner, ithuba lottery

LOTTO, LOTTO PLUS 1 AND LOTTO PLUS 2 DRAW 2136 (19 JUNE 2021) - YouTube
-----------------------------------------------------------------------

 ![LOTTO, LOTTO PLUS 1 AND LOTTO PLUS 2 DRAW 2136 (19 JUNE 2021) - YouTube](https://i.ytimg.com/vi/MgmDDaHM-Dc/maxresdefault.jpg?sqp=-oaymwEmCIAKENAF8quKqQMa8AEB-AHUBoAC4AOKAgwIABABGGUgYygSMA8=&rs=AOn4CLBYxwE1KsxUSCynYJ5P08WltB23BA) <small>www.youtube.com</small>LOTTO, LOTTO PLUS 1 AND LOTTO PLUS 2 DRAW 2136 (19 JUNE 2021) - YouTube

Lotto And Lotto Plus Results: Winning Numbers
---------------------------------------------

 ![Lotto and Lotto Plus Results: Winning Numbers](https://www.thesouthafrican.com/wp-content/uploads/2026/04/Lotto-and-Lotto-Plus-1-and-2-on-Saturday-4-April-2026_4-960x640.jpg.optimal.jpg) <small>www.thesouthafrican.com</small>Lotto and Lotto Plus Results: Winning Numbers

Lotto Plus 1 Plus 2 Results Online
----------------------------------

 ![Lotto plus 1 plus 2 results online](https://pbs.twimg.com/media/EOX9TJlUUAArL9n.png) <small>www.namibian.com.na</small>Lotto plus 1 plus 2 results online

Lotto Plus 1 And Lotto Plus 2 Online
------------------------------------

 ![Lotto plus 1 and lotto plus 2 online](https://media.citizen.co.za/wp-content/uploads/2021/10/LOTTO-PLUS-2-002.jpg) <small>www.namibian.com.na</small>Lotto plus 1 and lotto plus 2 online

Lotto And Lotto Plus 1 And 2 On Saturday 7 February 2026 Promises R41
---------------------------------------------------------------------

 ![Lotto and Lotto Plus 1 and 2 on Saturday 7 February 2026 promises R41](https://www.thesouthafrican.com/wp-content/uploads/2026/02/Lotto-and-Lotto-Plus-1-and-2.png) <small>www.thesouthafrican.com</small>Lotto and Lotto Plus 1 and 2 on Saturday 7 February 2026 promises R41 ...

LOTTO, LOTTO PLUS 1 AND LOTTO PLUS 2 DRAW 2446 - YouTube
--------------------------------------------------------

 ![LOTTO, LOTTO PLUS 1 AND LOTTO PLUS 2 DRAW 2446 - YouTube](https://i.ytimg.com/vi/d5a_Bbid_OA/maxresdefault.jpg?sqp=-oaymwEmCIAKENAF8quKqQMa8AEB-AH-CYAC0AWKAgwIABABGBggcigRMA8=&rs=AOn4CLBpENcKngdVqRZ3fgtg-evzPpL_ww) <small>www.youtube.com</small>LOTTO, LOTTO PLUS 1 AND LOTTO PLUS 2 DRAW 2446 - YouTube

LOTTO, LOTTO PLUS 1 AND LOTTO PLUS 2 DRAW 2636 - YouTube
--------------------------------------------------------

 ![LOTTO, LOTTO PLUS 1 AND LOTTO PLUS 2 DRAW 2636 - YouTube](https://i.ytimg.com/vi/sj1BBbe03IY/maxresdefault.jpg?sqp=-oaymwEmCIAKENAF8quKqQMa8AEB-AH-CYAC0AWKAgwIABABGCEgZSgcMA8=&rs=AOn4CLCpav6UzqtaoHdEsmoeCM-a7owrGw) <small>www.youtube.com</small>LOTTO, LOTTO PLUS 1 AND LOTTO PLUS 2 DRAW 2636 - YouTube

Lotto Plus 1 And 2 Online
-------------------------

 ![Lotto plus 1 and 2 online](https://www.magiclotto.co.za/Assets/images/news/DIowyYzVYAEVvhD.jpg) <small>www.namibian.com.na</small>Lotto plus 1 and 2 online

Lotto Plus 1 &amp; 2 Results 15 Nov 2025 | Live SA Numbers
----------------------------------------------------------

 ![Lotto Plus 1 & 2 Results 15 Nov 2025 | Live SA Numbers](https://www.techchamp.co.za/wp-content/uploads/2025/11/Lotto-Lotto-Plus-1-and-Lotto-Plus-2-Results-for-Saturday-15-November-2025.jpg) <small>www.techchamp.co.za</small>Lotto Plus 1 &amp; 2 Results 15 Nov 2025 | Live SA Numbers

R54-million Payday For Lotto And Lotto Plus 1 And 2 On Saturday 28
------------------------------------------------------------------

 ![R54-million payday for Lotto and Lotto Plus 1 and 2 on Saturday 28](https://www.thesouthafrican.com/wp-content/uploads/2026/02/Lotto-and-Lotto-Plus-1-and-2-on-Saturday-28-February-2026-.jpg.optimal.jpg) <small>www.thesouthafrican.com</small>R54-million payday for Lotto and Lotto Plus 1 and 2 on Saturday 28 ...

R98 Million UP For Grabs: Lotto And Lotto Plus 1 And 2 On Wednesday 29
----------------------------------------------------------------------

 ![R98 million UP for grabs: Lotto and Lotto Plus 1 and 2 on Wednesday 29](https://www.thesouthafrican.com/wp-content/uploads/2026/04/Lotto-and-Lotto-Plus-1-and-2-on-Wednesday-29-April-2026_1-960x257.png) <small>www.thesouthafrican.com</small>R98 million UP for grabs: Lotto and Lotto Plus 1 and 2 on Wednesday 29 ...

LOTTO, LOTTO PLUS 1 AND LOTTO PLUS 2 DRAW 2641 - YouTube
--------------------------------------------------------

 ![LOTTO, LOTTO PLUS 1 AND LOTTO PLUS 2 DRAW 2641 - YouTube](https://i.ytimg.com/vi/RApVgayG0LU/maxresdefault.jpg?sqp=-oaymwEmCIAKENAF8quKqQMa8AEB-AH-CYAC0AWKAgwIABABGHIgVigfMA8=&rs=AOn4CLBcOubn1iCAfallHYrj-jh9_Oz9DQ) <small>www.youtube.com</small>LOTTO, LOTTO PLUS 1 AND LOTTO PLUS 2 DRAW 2641 - YouTube

R67 Million On LINE For Lotto And Lotto Plus 1 And 2 On Saturday 14
-------------------------------------------------------------------

 ![R67 million on LINE for Lotto and Lotto Plus 1 and 2 on Saturday 14](https://www.thesouthafrican.com/wp-content/uploads/2026/03/Lotto-and-Lotto-Plus-1-and-2-on-Saturday-14-March-2026_5.jpg.optimal.jpg) <small>www.thesouthafrican.com</small>R67 million on LINE for Lotto and Lotto Plus 1 and 2 on Saturday 14 ...

Lotto Results And Payouts &amp; Lotto Plus Best Sale | Www.cityofclovis.org
---------------------------------------------------------------------------

 ![Lotto Results And Payouts & Lotto Plus Best Sale | www.cityofclovis.org](https://media.citizen.co.za/wp-content/uploads/2018/12/Screenshot-2018-12-06-at-08.45.46.png) <small>www.cityofclovis.org</small>Lotto Results And Payouts &amp; Lotto Plus Best Sale | www.cityofclovis.org

LOTTO, LOTTO PLUS 1 AND LOTTO PLUS 2 DRAW 2633 - YouTube
--------------------------------------------------------

 ![LOTTO, LOTTO PLUS 1 AND LOTTO PLUS 2 DRAW 2633 - YouTube](https://i.ytimg.com/vi/2kp1DmZ25G0/maxresdefault.jpg?sqp=-oaymwEmCIAKENAF8quKqQMa8AEB-AH-CYAC0AWKAgwIABABGE4gZSgqMA8=&rs=AOn4CLAOW61kj7NY8U3TXuD3hI-hViLaMQ) <small>www.youtube.com</small>LOTTO, LOTTO PLUS 1 AND LOTTO PLUS 2 DRAW 2633 - YouTube

Lotto Results Lotto Plus 1 And 2 Today New Arrivals
---------------------------------------------------

 ![Lotto results lotto plus 1 and 2 today new arrivals](https://www.saffarazzi.com/wp-content/uploads/2021/10/lotto-and-lotto-plus-results-saturday-south-africa.webp) <small>pediatrianorte.med.uchile.cl</small>Lotto results lotto plus 1 and 2 today new arrivals

BAD News For RESET Lotto And Lotto Plus 1 And 2 On Saturday 9 May 2026
----------------------------------------------------------------------

 ![BAD news for RESET Lotto and Lotto Plus 1 and 2 on Saturday 9 May 2026](https://www.thesouthafrican.com/wp-content/uploads/2026/05/Lotto-and-Lotto-Plus-1-and-2-on-Saturday-9-May-2026_2.png) <small>www.thesouthafrican.com</small>BAD news for RESET Lotto and Lotto Plus 1 and 2 on Saturday 9 May 2026

Lotto And Lotto Plus Results For Yesterday Online
-------------------------------------------------

 ![Lotto and lotto plus results for yesterday online](https://i.pinimg.com/736x/b6/4f/3d/b64f3dfa01d82a81dd4fc7e3b3b85094.jpg) <small>www.namibian.com.na</small>Lotto and lotto plus results for yesterday online

Lotto And Lotto Plus 1 And 2 On Saturday 7 February 2026 Promises R41
---------------------------------------------------------------------

 ![Lotto and Lotto Plus 1 and 2 on Saturday 7 February 2026 promises R41](https://www.thesouthafrican.com/wp-content/uploads/2026/02/Lotto-and-Lotto-Plus-1-and-2-on-Saturday-7-February-2026.jpg.optimal.jpg) <small>www.thesouthafrican.com</small>Lotto and Lotto Plus 1 and 2 on Saturday 7 February 2026 promises R41 ...

R44.5-million On The Line In Lotto And Lotto Plus 1 And 2 On Saturday
---------------------------------------------------------------------

 ![R44.5-million on the line in Lotto and Lotto Plus 1 and 2 on Saturday](https://www.thesouthafrican.com/wp-content/uploads/2026/02/Lotto-and-Lotto-Plus-1-and-2-on-Saturday-21-February-2026_1.png) <small>www.thesouthafrican.com</small>R44.5-million on the line in Lotto and Lotto Plus 1 and 2 on Saturday ...

Win R50 Million In Lotto And Lotto Plus 1 And 2 On Saturday 14 February
-----------------------------------------------------------------------

 ![Win R50 million in Lotto and Lotto Plus 1 and 2 on Saturday 14 February](https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA1WbTmw.img?w=1200&h=800&m=4&q=79) <small>www.msn.com</small>Win R50 million in Lotto and Lotto Plus 1 and 2 on Saturday 14 February ...

ITHUBA Confirms Lotto Plus 1 And Lotto Plus 2 Jackpots WON
----------------------------------------------------------

 ![ITHUBA confirms Lotto Plus 1 and Lotto Plus 2 jackpots WON](https://www.thesouthafrican.com/wp-content/uploads/2026/04/Lotto-and-Lotto-Plus-1-and-2-on-Wednesday-8-April-2026_1.jpg.optimal.jpg) <small>www.thesouthafrican.com</small>ITHUBA confirms Lotto Plus 1 and Lotto Plus 2 jackpots WON

ITHUBA Confirms Lotto Plus 1 And Lotto Plus 2 Jackpots WON
----------------------------------------------------------

 ![ITHUBA confirms Lotto Plus 1 and Lotto Plus 2 jackpots WON](https://www.thesouthafrican.com/wp-content/uploads/2026/04/image-28.png) <small>www.thesouthafrican.com</small>ITHUBA confirms Lotto Plus 1 and Lotto Plus 2 jackpots WON

Lotto Results 19 November 2025 – Winning Numbers, Lotto Plus 1 &amp; Plus 2
---------------------------------------------------------------------------

 ![Lotto Results 19 November 2025 – Winning Numbers, Lotto Plus 1 & Plus 2](https://www.techchamp.co.za/wp-content/uploads/2025/12/Lotto-Lotto-Plus-1-Lotto-Plus-2-Results-for-Saturday-05-December-2025.webp) <small>www.techchamp.co.za</small>Lotto Results 19 November 2025 – Winning Numbers, Lotto Plus 1 &amp; Plus 2 ...

R98 Million UP For Grabs: Lotto And Lotto Plus 1 And 2 On Wednesday 29
----------------------------------------------------------------------

 ![R98 million UP for grabs: Lotto and Lotto Plus 1 and 2 on Wednesday 29](https://www.thesouthafrican.com/wp-content/uploads/2026/04/Lotto-and-Lotto-Plus-1-and-2-on-Wednesday-29-April-2026_1-1200x321.png) <small>www.thesouthafrican.com</small>R98 million UP for grabs: Lotto and Lotto Plus 1 and 2 on Wednesday 29 ...

LOTTO, LOTTO PLUS 1 AND LOTTO PLUS 2 DRAW 2002 (07 MARCH 2020) - YouTube
------------------------------------------------------------------------

 ![LOTTO, LOTTO PLUS 1 AND LOTTO PLUS 2 DRAW 2002 (07 MARCH 2020) - YouTube](https://i.ytimg.com/vi/t3pRJt_pZmg/maxresdefault.jpg) <small>www.youtube.com</small>LOTTO, LOTTO PLUS 1 AND LOTTO PLUS 2 DRAW 2002 (07 MARCH 2020) - YouTube

‘Budget Speech’ Lotto And Lotto Plus 1 And 2 On Wednesday 25 February
---------------------------------------------------------------------

 ![‘Budget Speech’ Lotto and Lotto Plus 1 and 2 on Wednesday 25 February](https://www.thesouthafrican.com/wp-content/uploads/2026/02/Lotto-and-Lotto-Plus-1-and-2-on-Wednesday-25-February-2026-750x500.jpg.optimal.jpg) <small>www.thesouthafrican.com</small>‘Budget Speech’ Lotto and Lotto Plus 1 and 2 on Wednesday 25 February ...

Lotto and lotto plus 1 and 2 on saturday 7 february 2026 promises r41. lotto and lotto plus 1 and 2 on saturday 7 february 2026 promises r41 .... Lotto draws: numbers, results, payouts, winner, ithuba lottery
