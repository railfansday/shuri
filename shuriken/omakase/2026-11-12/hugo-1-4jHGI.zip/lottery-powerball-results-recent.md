---
title: "Lottery Powerball Results Recent - Powerball draws: numbers, results, payouts, ithuba, lottery winners"
description: "powerball winning numbers for saturday, april 12, 2025"
date: "2025-12-28"
categories:
- "Uncategorized"
images:
- "https://www.swisherpost.com/wp-content/uploads/2026/01/powerball-results-south-africa-2026.jpg"
featuredImage: "https://sundayguardianlive.com/wp-content/uploads/2026/06/powerball-results-today.jpg"
featured_image: "https://thegadgetscentral.com/wp-content/uploads/2026/01/online-lottery_1769597104.jpg"
image: "https://www.indystar.com/gcdn/-mm-/14f6a20ea46ef7239967ac8489f4a4c91147820c/c=0-243-2394-1596/local/-/media/2017/02/23/INGroup/Indianapolis/636234288375686944-3-Powerball.jpg?width=2394&amp;height=1353&amp;fit=crop&amp;format=pjpg&amp;auto=webp"
---

If you are looking for Powerball jackpot winning numbers for December 17 as prize climbs you've visit to the right web. We have 35 Images about Powerball jackpot winning numbers for December 17 as prize climbs like PowerBall draws: Numbers, results, payouts, ithuba, lottery winners, Powerball results: jackpot climbs to $747M after no one matched the and also LIVE | Lottery Powerball Winning Numbers June 6, 2026: $212 Million. Here you go:

Powerball Jackpot Winning Numbers For December 17 As Prize Climbs
-----------------------------------------------------------------

 ![Powerball jackpot winning numbers for December 17 as prize climbs](https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA1SB4sW.img?w=1920&h=1280&m=4&q=60) <small>www.msn.com</small>Powerball jackpot winning numbers for December 17 as prize climbs ...

Powerball Results: Jackpot Nears $800 Million Ahead Of Draw
-----------------------------------------------------------

 ![Powerball Results: Jackpot Nears $800 Million Ahead of Draw](https://thegadgetscentral.com/wp-content/uploads/2025/12/lottery-results-today_1764756006.jpg) <small>thegadgetscentral.com</small>Powerball Results: Jackpot Nears $800 Million Ahead of Draw

PowerBall And PowerBall Plus Results | 20 May 2025 - ENCA
---------------------------------------------------------

 ![PowerBall and PowerBall Plus Results | 20 May 2025 - eNCA](https://www.enca.com/sites/default/files/styles/banner_image/public/2023-07/etv_pb_results.jpg.webp?itok=6NASh8rZ) <small>www.enca.com</small>PowerBall and PowerBall Plus Results | 20 May 2025 - eNCA

Powerball Results: Jackpot Climbs To $747M After No One Matched The
-------------------------------------------------------------------

 ![Powerball results: jackpot climbs to $747M after no one matched the](https://cdn.abcotvs.com/dip/images/12773002_020523-wabc-powerball-img.jpg?w=1600) <small>abc7ny.com</small>Powerball results: jackpot climbs to $747M after no one matched the ...

The PowerBall And PowerBall XTRA Results For Friday, 3 July 2026
----------------------------------------------------------------

 ![The PowerBall and PowerBall XTRA results for Friday, 3 July 2026](https://www.thesouthafrican.com/wp-content/uploads/2026/06/PowerBall-jackpot-draw.jpg.optimal.jpg) <small>www.thesouthafrican.com</small>The PowerBall and PowerBall XTRA results for Friday, 3 July 2026

Powerball Jackpot Soars To $1 Billion After No Winning Ticket Is Sold
---------------------------------------------------------------------

 ![Powerball jackpot soars to $1 billion after no winning ticket is sold](https://media-cldnry.s-nbcnews.com/image/upload/t_fit-760w,f_auto,q_auto:best/rockcms/2023-07/20230717-powerball-winning-numbers-mc-a8b8c0-331db7.jpg) <small>www.nbcnews.com</small>Powerball jackpot soars to $1 billion after no winning ticket is sold

Powerball Numbers July 19: Lottery Ticket Wins $1.08 Billion Jackpot
--------------------------------------------------------------------

 ![Powerball numbers July 19: Lottery ticket wins $1.08 billion jackpot](https://images.axios.com/CchkR8MNYSA1nf6JnrxTo8gUNKM=/0x0:6722x3781/1920x1080/2023/07/19/1689776839956.jpg?w=1920) <small>www.axios.com</small>Powerball numbers July 19: Lottery ticket wins $1.08 billion jackpot

Powerball Results For Today - Lotto Powerball Results South African
-------------------------------------------------------------------

 ![Powerball Results For Today - Lotto Powerball Results South African](https://image.winudf.com/v2/image1/bmV0LmF6dXJld2Vic2l0ZXMuZHJvaWRpbm1vdGlvbi5ncmVlY2Vwb3dlcmJhbGxyZXN1bHRzX3NjcmVlbl8wXzE1NTMwNzEzMDlfMDMw/screen-0.jpg?fakeurl=1&type=.jpg) <small>fixedratevisacard.blogspot.com</small>Powerball Results For Today - Lotto Powerball Results South African ...

Powerball Lotto Result Today Sales
----------------------------------

 ![Powerball lotto result today sales](https://cf-images.ap-southeast-2.prod.boltdns.net/v1/jit/4761797480001/03a7d89a-96e0-4e0d-9405-96d06eebd02b/main/1280x720/1m4s650ms/match/image.jpg) <small>arquitectura.unam.mx</small>Powerball lotto result today sales

California Lottery Player Hits Massive $526.5 Million Powerball Jackpot
-----------------------------------------------------------------------

 ![California Lottery player hits massive $526.5 million Powerball jackpot](https://assets.lotteryusa.com/uploads/articles/1749573868178.jpg) <small>www.lotteryusa.com</small>California Lottery player hits massive $526.5 million Powerball jackpot

South Africa LOTTO Results 28 February 2026 Draw 2624 – R54 Million
-------------------------------------------------------------------

 ![South Africa LOTTO Results 28 February 2026 Draw 2624 – R54 Million](https://swikblog.com/wp-content/uploads/2026/03/powerball_ticket.webp) <small>swikblog.com</small>South Africa LOTTO Results 28 February 2026 Draw 2624 – R54 Million ...

Latest US Powerball Results •• | ••US-Powerball.com••
-----------------------------------------------------

 ![Latest US Powerball Results •• | ••US-Powerball.com••](https://us-powerball.com/wp-content/uploads/2022/10/Powerball-Results.png) <small>us-powerball.com</small>Latest US Powerball Results •• | ••US-Powerball.com••

Did Anyone Win The $1.27 Billion Powerball Jackpot Last Night?
--------------------------------------------------------------

 ![Did anyone win the $1.27 billion Powerball jackpot last night?](https://www.usatoday.com/gcdn/authoring/authoring-images/2025/12/04/USAT/87600845007-usatsi-26997579.jpg?crop=3394) <small>www.usatoday.com</small>Did anyone win the $1.27 billion Powerball jackpot last night?

Winning Powerball Numbers For The $593 Million Jackpot On Nov. 19, 2025
-----------------------------------------------------------------------

 ![Winning Powerball numbers for the $593 million jackpot on Nov. 19, 2025](https://media.wkyc.com/assets/WKYC/images/d1733901-7e41-468b-afab-66b6536c359e/20251216T102926/d1733901-7e41-468b-afab-66b6536c359e_1920x1080.jpg) <small>www.wkyc.com</small>Winning Powerball numbers for the $593 million jackpot on Nov. 19, 2025 ...

Powerball Winning Numbers For May 25, 2026 | LotteryCoast
---------------------------------------------------------

 ![Powerball Winning Numbers for May 25, 2026 | LotteryCoast](https://cdn.lotterycoast.com/static/lottery_results/img/og_meta/powerball_winning_numbers.webp) <small>lotterycoast.com</small>Powerball Winning Numbers for May 25, 2026 | LotteryCoast

PowerBall Draws: Numbers, Results, Payouts, Ithuba, Lottery Winners
-------------------------------------------------------------------

 ![PowerBall draws: Numbers, results, payouts, ithuba, lottery winners](https://www.thesouthafrican.com/wp-content/uploads/2025/04/IMG-20250409-WA0000.jpg.optimal.jpg) <small>www.thesouthafrican.com</small>PowerBall draws: Numbers, results, payouts, ithuba, lottery winners

PowerBall Results: Latest Winning Numbers, Payouts And Draw Updates For
-----------------------------------------------------------------------

 ![PowerBall results: Latest winning numbers, payouts and draw updates for](https://www.swisherpost.com/wp-content/uploads/2026/01/powerball-results-south-africa-2026.jpg) <small>www.swisherpost.com</small>PowerBall results: Latest winning numbers, payouts and draw updates for ...

What Are The Winning Powerball Numbers On Wednesday, Jan. 28, 2026
------------------------------------------------------------------

 ![What are the winning Powerball numbers on Wednesday, Jan. 28, 2026](https://img.asmedia.epimg.net/resizer/v2/ZLIFOQJ65VIIBBRTH5FXTYEPCA.jpg?auth=83dba5ff6a18eaee6a1777965efc74482acc744b01d0bbfb9b0e5bf06bad3638&width=1200&height=675&smart=true) <small>en.as.com</small>What are the winning Powerball numbers on Wednesday, Jan. 28, 2026 ...

Powerball Winning Numbers, Live Results For Saturday’s $207M Drawing
--------------------------------------------------------------------

 ![Powerball winning numbers, live results for Saturday’s $207M drawing](https://www.nj.com/resizer/v2/QG6PYOLQIJH5FAX6F2PSIJFOYA.jpg?auth=d84738061b3fffd0311241e4c7071935da29a447f58e36666ee020e7689edfc4&width=1280&quality=90) <small>www.nj.com</small>Powerball winning numbers, live results for Saturday’s $207M drawing ...

Powerball Winning Numbers For April 25, 2026: $118 Million Jackpot Results
--------------------------------------------------------------------------

 ![Powerball Winning Numbers for April 25, 2026: $118 Million Jackpot Results](https://swikblog.com/wp-content/uploads/2026/04/powerball_image-1.webp) <small>swikblog.com</small>Powerball Winning Numbers for April 25, 2026: $118 Million Jackpot Results

Latest Powerball Results - Australian Lottery
---------------------------------------------

 ![Latest Powerball Results - Australian Lottery](https://coinfellowship.com/wp-content/uploads/2025/12/powerball-results-9.jpeg) <small>coinfellowship.com</small>Latest Powerball Results - Australian Lottery

Powerball Winning Numbers History | Latest Draws, Odds &amp; Biggest Jackpots
-----------------------------------------------------------------------------

 ![Powerball Winning Numbers History | Latest Draws, Odds & Biggest Jackpots](https://scrowp.com/wp-content/uploads/2025/12/Powerball-winiing-numbers-scaled.jpg) <small>scrowp.com</small>Powerball Winning Numbers History | Latest Draws, Odds &amp; Biggest Jackpots

Winning Numbers For Today: Your Guide To The Latest Lottery Results
-------------------------------------------------------------------

 ![Winning Numbers For Today: Your Guide To The Latest Lottery Results](https://www.usatoday.com/gcdn/authoring/authoring-images/2024/03/09/USAT/72912946007-usatsi-20862411.jpg?crop=3949,2221,x0,y18&width=3200&height=1800&format=pjpg&auto=webp) <small>master.d3a9l43wbvawb2.amplifyapp.com</small>Winning Numbers For Today: Your Guide To The Latest Lottery Results ...

Powerball Winning Numbers For Saturday, Oct. 7, 2023 | 11alive.com
------------------------------------------------------------------

 ![Powerball winning numbers for Saturday, Oct. 7, 2023 | 11alive.com](https://media.11alive.com/assets/WXIA/images/e4b9c8c5-eb78-4478-a468-5569d0bf72d4/e4b9c8c5-eb78-4478-a468-5569d0bf72d4_1920x1080.jpg) <small>www.11alive.com</small>Powerball winning numbers for Saturday, Oct. 7, 2023 | 11alive.com

PowerBall And PowerBall Xtra Results 12 June: R153 Million SA Lottery Draw
--------------------------------------------------------------------------

 ![PowerBall and PowerBall Xtra Results 12 June: R153 Million SA Lottery Draw](https://swikblog.com/wp-content/uploads/2026/06/south-africa-powerball-feature-80kb.webp) <small>swikblog.com</small>PowerBall and PowerBall Xtra Results 12 June: R153 Million SA Lottery Draw

Powerball Winning Numbers For Saturday, April 12, 2025
------------------------------------------------------

 ![Powerball winning numbers for Saturday, April 12, 2025](https://www.beaconjournal.com/gcdn/presto/2023/07/15/PBRE/0cbb236e-8352-4e12-a621-ce08c1478ad4-870D536C-1E77-45DD-83DA-CCBAD07F72CC.jpeg?crop=4031,2267,x1,y0&width=3200&height=1800&format=pjpg&auto=webp) <small>www.beaconjournal.com</small>Powerball winning numbers for Saturday, April 12, 2025

LIVE | Lottery Powerball Winning Numbers June 6, 2026: $212 Million
-------------------------------------------------------------------

 ![LIVE | Lottery Powerball Winning Numbers June 6, 2026: $212 Million](https://sundayguardianlive.com/wp-content/uploads/2026/06/powerball-results-today.jpg) <small>sundayguardianlive.com</small>LIVE | Lottery Powerball Winning Numbers June 6, 2026: $212 Million ...

PowerBall And PowerBall Plus Results | 20 June 2025 - ENCA
----------------------------------------------------------

 ![PowerBall and PowerBall Plus Results | 20 June 2025 - eNCA](https://www.enca.com/sites/default/files/styles/banner_image/public/2025-02/pb_results-example 2.jpg.webp?itok=tQKYnMcc) <small>www.enca.com</small>PowerBall and PowerBall Plus Results | 20 June 2025 - eNCA

Powerball Winning Numbers April 22, 2026: $100M Results Released After
----------------------------------------------------------------------

 ![Powerball Winning Numbers April 22, 2026: $100M Results Released After](https://swikblog.com/wp-content/uploads/2026/03/powerball_feature.webp) <small>swikblog.com</small>Powerball Winning Numbers April 22, 2026: $100M Results Released After ...

Winning Powerball Numbers, Lottery Jackpot Results Last Night, May 2, 2026
--------------------------------------------------------------------------

 ![Winning Powerball numbers, lottery jackpot results last night, May 2, 2026](https://www.indystar.com/gcdn/-mm-/14f6a20ea46ef7239967ac8489f4a4c91147820c/c=0-243-2394-1596/local/-/media/2017/02/23/INGroup/Indianapolis/636234288375686944-3-Powerball.jpg?width=2394&height=1353&fit=crop&format=pjpg&auto=webp) <small>www.indystar.com</small>Winning Powerball numbers, lottery jackpot results last night, May 2, 2026

Powerball Winning Numbers From 9/1/25 | DraftKings Network
----------------------------------------------------------

 ![Powerball Winning Numbers from 9/1/25 | DraftKings Network](https://dknetwork.draftkings.com/wp-content/uploads/PB-29.png) <small>dknetwork.draftkings.com</small>Powerball Winning Numbers from 9/1/25 | DraftKings Network

Powerball Winning Numbers Drawing Results In No Winner; Lottery Jackpot
-----------------------------------------------------------------------

 ![Powerball winning numbers drawing results in no winner; lottery jackpot](https://cdn.abcotvs.com/dip/images/12430745_110822-cc-ap-powerball-ticket-file-img.jpeg?w=1600) <small>abc7news.com</small>Powerball winning numbers drawing results in no winner; lottery jackpot ...

Powerball Jackpot Soars To $815 Million For Wednesday; 7th Largest Ever
-----------------------------------------------------------------------

 ![Powerball jackpot soars to $815 million for Wednesday; 7th largest ever](https://images.foxtv.com/static.livenowfox.com/www.livenowfox.com/content/uploads/2025/08/932/524/gettyimages-2231384569-copy-scaled.jpg?ve=1&tl=1) <small>www.fox13seattle.com</small>Powerball jackpot soars to $815 million for Wednesday; 7th largest ever ...

Powerball Jackpot Climbing To $935M After No Tickets Sold Match All
-------------------------------------------------------------------

 ![Powerball jackpot climbing to $935M after no tickets sold match all](https://cdn.abcotvs.com/dip/images/14582134_032824-wpvi-powerball-winning-numbers-img.jpg) <small>abc7.com</small>Powerball jackpot climbing to $935M after no tickets sold match all ...

Powerball: Latest Numbers And Recent Multi-Million Dollar Winners
-----------------------------------------------------------------

 ![Powerball: Latest Numbers and Recent Multi-Million Dollar Winners](https://thegadgetscentral.com/wp-content/uploads/2026/01/online-lottery_1769597104.jpg) <small>thegadgetscentral.com</small>Powerball: Latest Numbers and Recent Multi-Million Dollar Winners

powerball results: jackpot nears $800 million ahead of draw. Powerball results: jackpot climbs to $747m after no one matched the. powerball jackpot soars to $815 million for wednesday; 7th largest ever ...
