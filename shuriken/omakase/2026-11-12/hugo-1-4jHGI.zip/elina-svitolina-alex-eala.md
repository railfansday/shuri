---
title: "Elina Svitolina Alex Eala - alex eala defeats svitolina, books dc open semifinal vs. osaka"
description: "Alex eala stuns elina svitolina again, reaches dc open semis"
date: "2026-01-15"
categories:
- "Uncategorized"
images:
- "https://images.gmanews.tv/webpics/2026/06/EALA_SVITOLINA_2026_06_19_15_01_06.jpg"
featuredImage: "https://newsko.com.ph/wp-content/uploads/2026/06/wta-1.jpg"
featured_image: "https://pbs.twimg.com/media/HLK7dApa4AA7VOV.jpg"
image: "https://lookaside.fbsbx.com/lookaside/crawler/media/?media_id=1316681143836573"
---

If you are looking for Alex Eala, panalo ulit sa kalaban sa Berlin Tennis Open; world No. 8 na you've came to the right web. We have 35 Images about Alex Eala, panalo ulit sa kalaban sa Berlin Tennis Open; world No. 8 na like BUONG NEW ZEALAND GINULAT! ALEXANDRA EALA NAKAHANAY VS WORLD #14 ELINA, Alex Eala thrilled to open 2026 with doubles win vs 'pioneers' Venus and also Alex Eala stuns world no. 8 Svitolina, enters Berlin Open semifinals. Read more:

Alex Eala, Panalo Ulit Sa Kalaban Sa Berlin Tennis Open; World No. 8 Na
-----------------------------------------------------------------------

 ![Alex Eala, panalo ulit sa kalaban sa Berlin Tennis Open; world No. 8 na](https://images.gmanews.tv/webpics/2026/06/EALA_SVITOLINA_2026_06_19_15_01_06.jpg) <small>www.gmanetwork.com</small>Alex Eala, panalo ulit sa kalaban sa Berlin Tennis Open; world No. 8 na ...

The News - Alex Eala Teams Up With Iva Jovic For ASB Classic Doubles
--------------------------------------------------------------------

 ![The News - Alex Eala Teams Up With Iva Jovic for ASB Classic Doubles](https://lookaside.fbsbx.com/lookaside/crawler/media/?media_id=122174666816389899) <small>www.facebook.com</small>The News - Alex Eala Teams Up With Iva Jovic for ASB Classic Doubles ...

LIVE: Alex Eala Vs Elina Svitolina Mubadala DC Open Quarterfinals
-----------------------------------------------------------------

 ![LIVE: Alex Eala vs Elina Svitolina Mubadala DC Open quarterfinals](https://sports.inquirer.net/files/2026/07/2026-08-01_Mubadala-DC-Open-Alex-Elina-copy-2048x1365.jpg) <small>sports.inquirer.net</small>LIVE: Alex Eala vs Elina Svitolina Mubadala DC Open quarterfinals

Alex Eala Vs Elina Svitolina | WTA Berlin 2026 Quarter-Final | Preview
----------------------------------------------------------------------

 ![Alex Eala vs Elina Svitolina | WTA Berlin 2026 Quarter-Final | Preview](https://i.ytimg.com/vi/8d3b2Hu6Iis/maxresdefault.jpg) <small>www.youtube.com</small>Alex Eala vs Elina Svitolina | WTA Berlin 2026 Quarter-Final | Preview ...

Alex Eala Stuns Elina Svitolina, Marches Into Berlin Semifinals - Edge
----------------------------------------------------------------------

 ![Alex Eala stuns Elina Svitolina, marches into Berlin semifinals - Edge](https://edgedavao.net/wp-content/uploads/2026/06/SPORTS-JUN-21-22_2026-IMG-Alex-Eala-upset-world-No.-8-Elina-Svitolina.jpg) <small>edgedavao.net</small>Alex Eala stuns Elina Svitolina, marches into Berlin semifinals - Edge ...

BUONG NEW ZEALAND GINULAT! ALEXANDRA EALA NAKAHANAY VS WORLD #14 ELINA
----------------------------------------------------------------------

 ![BUONG NEW ZEALAND GINULAT! ALEXANDRA EALA NAKAHANAY VS WORLD #14 ELINA](https://i.ytimg.com/vi/BSwX7NGa1N0/maxresdefault.jpg) <small>www.youtube.com</small>BUONG NEW ZEALAND GINULAT! ALEXANDRA EALA NAKAHANAY VS WORLD #14 ELINA ...

Alex Eala Vs World #8 Elina Svitolina! Can The Rybakina Slayer Do It
--------------------------------------------------------------------

 ![Alex Eala vs World #8 Elina Svitolina! Can the Rybakina Slayer Do It](https://i.ytimg.com/vi/WL9UVfNz9sk/maxresdefault.jpg) <small>www.youtube.com</small>Alex Eala vs World #8 Elina Svitolina! Can the Rybakina Slayer Do It ...

BPI - What A Debut For The Duo! 🙌🎾 Alex Eala Teamed Up With Iva Jovic
---------------------------------------------------------------------

 ![BPI - What a debut for the duo! 🙌🎾 Alex Eala teamed up with Iva Jovic](https://lookaside.fbsbx.com/lookaside/crawler/media/?media_id=1316681143836573) <small>www.facebook.com</small>BPI - What a debut for the duo! 🙌🎾 Alex Eala teamed up with Iva Jovic ...

One - STRONG START TO 2026 🎾 Tennis Duo Alex Eala And Iva Jovic
---------------------------------------------------------------

 ![One - STRONG START TO 2026 🎾 Tennis duo Alex Eala and Iva Jovic](https://lookaside.fbsbx.com/lookaside/crawler/media/?media_id=1463875181768719) <small>www.facebook.com</small>One - STRONG START TO 2026 🎾 Tennis duo Alex Eala and Iva Jovic ...

LIVE: Alex Eala Vs Elina Svitolina - Berlin Open - Quarterfinals
----------------------------------------------------------------

 ![LIVE: Alex Eala vs Elina Svitolina - Berlin Open - quarterfinals](https://sports.inquirer.net/files/2026/06/2026-06-19_Berlin-Open-QF-Alex-Elina-copy.jpg-1638x2048.jpeg) <small>sports.inquirer.net</small>LIVE: Alex Eala vs Elina Svitolina - Berlin Open - quarterfinals

Alex Eala Makakaharap Si World Number 8 Svitolina Sa Quarterfinals Ng
---------------------------------------------------------------------

 ![Alex Eala makakaharap si World Number 8 Svitolina sa quarterfinals ng](https://img.bomboradyo.com/newscenter/2026/06/SVITOLINA-VS-EALA.webp) <small>www.bomboradyo.com</small>Alex Eala makakaharap si World Number 8 Svitolina sa quarterfinals ng ...

LIVE: Alex Eala Vs Elina Svitolina - Berlin Open - Quarterfinals
----------------------------------------------------------------

 ![LIVE: Alex Eala vs Elina Svitolina - Berlin Open - quarterfinals](https://sports.inquirer.net/files/2026/06/2026-06-19_Berlin-Open-Live-QF-Alex-Elina-copy-scaled.jpg) <small>sports.inquirer.net</small>LIVE: Alex Eala vs Elina Svitolina - Berlin Open - quarterfinals

Alex Eala’s Remarkable Berlin Open Run Reaches Semifinals After Elina
---------------------------------------------------------------------

 ![Alex Eala’s remarkable Berlin Open run reaches semifinals after Elina](https://vcptennis.com/wp-content/uploads/2026/06/Alex-Ealas-remarkable-Berlin-Open-run-reaches-semifinals-after-Elina-1140x694.webp) <small>vcptennis.com</small>Alex Eala’s remarkable Berlin Open run reaches semifinals after Elina ...

Alex Eala Stuns Elina Svitolina Again, Reaches DC Open Semis
------------------------------------------------------------

 ![Alex Eala stuns Elina Svitolina again, reaches DC Open semis](https://cdn.tiebreakertimes.com.ph/wp-content/uploads/2026/08/2026-DC-Open-Alex-Eala-1024x576.jpg) <small>tiebreakertimes.com.ph</small>Alex Eala stuns Elina Svitolina again, reaches DC Open semis

Alex Eala Stuns World No. 8 Svitolina, Enters Berlin Open Semifinals
--------------------------------------------------------------------

 ![Alex Eala stuns world no. 8 Svitolina, enters Berlin Open semifinals](https://cebudailynews.inquirer.net/files/2026/06/AFP__20260610__B6LE6LE__v1__HighRes__TennisWtaGbrQueens-2048x1366.jpg) <small>cebudailynews.inquirer.net</small>Alex Eala stuns world no. 8 Svitolina, enters Berlin Open semifinals

What Alex Eala Had To Say About Next Opponent Elina Svitolina As Berlin
-----------------------------------------------------------------------

 ![What Alex Eala had to say about next opponent Elina Svitolina as Berlin](https://d2me2qg8dfiw8u.cloudfront.net/content/uploads/2026/06/Alex-Eala-with-inset-of-Elina-Svitolina.jpg) <small>www.tennis365.com</small>What Alex Eala had to say about next opponent Elina Svitolina as Berlin ...

Alex Eala's Remarkable Berlin Open Run Reaches Semifinals After Elina
---------------------------------------------------------------------

 ![Alex Eala's remarkable Berlin Open run reaches semifinals after Elina](https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA2666Vk.img?w=1296&h=729&m=4&q=79) <small>www.msn.com</small>Alex Eala's remarkable Berlin Open run reaches semifinals after Elina ...

Alex Eala Vs Elina Svitolina Semifinals
---------------------------------------

 ![Alex Eala Vs Elina Svitolina Semifinals](https://lookaside.instagram.com/seo/google_widget/crawler/?media_id=3825262455715121766) <small>www.instagram.com</small>Alex Eala Vs Elina Svitolina Semifinals

Alex Eala, Iva Jovic Defeat Veterans Venus Williams, Elina Svitolina In
-----------------------------------------------------------------------

 ![Alex Eala, Iva Jovic defeat veterans Venus Williams, Elina Svitolina in](https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA1TAjAU.img?w=1200&h=630&m=4&q=93) <small>www.msn.com</small>Alex Eala, Iva Jovic defeat veterans Venus Williams, Elina Svitolina in ...

Alex Eala Pasok Na Sa Semifinals; World No. 8 Elina Svitolina Pinatalsik
------------------------------------------------------------------------

 ![Alex Eala pasok na sa semifinals; world No. 8 Elina Svitolina pinatalsik](https://newsko.com.ph/wp-content/uploads/2026/06/wta-1.jpg) <small>newsko.com.ph</small>Alex Eala pasok na sa semifinals; world No. 8 Elina Svitolina pinatalsik

Alex Eala Stuns Elina Svitolina, Reaches Mubadala Open Semis
------------------------------------------------------------

 ![Alex Eala stuns Elina Svitolina, reaches Mubadala Open semis](https://fastbreak.com.ph/wp-content/uploads/2026/08/eala.png) <small>fastbreak.com.ph</small>Alex Eala stuns Elina Svitolina, reaches Mubadala Open semis

Alex Eala, Gipukan Ang World No. 8 Elina Svitolina, Sulod Na Sa Semis
---------------------------------------------------------------------

 ![Alex Eala, gipukan ang world No. 8 Elina Svitolina, sulod na sa semis](https://img.bomboradyo.com/cebu/2026/06/ALEX-EALA.webp) <small>cebu.bomboradyo.com</small>Alex Eala, gipukan ang world No. 8 Elina Svitolina, sulod na sa semis ...

Search For Doubles Success Continues As Alex Eala, Iva Jovic Overwhelm
----------------------------------------------------------------------

 ![Search for Doubles Success Continues as Alex Eala, Iva Jovic Overwhelm](https://files.rebanse.ph/sites/1/7c1c64d7-image-1068x618.jpg) <small>www.rebanse.ph</small>Search for Doubles Success Continues as Alex Eala, Iva Jovic Overwhelm ...

Alex Eala Defeats Svitolina, Books DC Open Semifinal Vs. Osaka
--------------------------------------------------------------

 ![Alex Eala defeats Svitolina, books DC Open semifinal vs. Osaka](https://cebudailynews.inquirer.net/files/2026/08/Alex-Eala-and-Elina-Svitolina-1024x576.jpg) <small>cebudailynews.inquirer.net</small>Alex Eala defeats Svitolina, books DC Open semifinal vs. Osaka

Alex Eala Thrilled To Open 2026 With Doubles Win Vs ‘pioneers’ Venus
--------------------------------------------------------------------

 ![Alex Eala thrilled to open 2026 with doubles win vs ‘pioneers’ Venus](https://conven.org/wp-content/uploads/2026/01/Alex-Eala-thrilled-to-open-2026-with-doubles-win-vs.jpg) <small>conven.org</small>Alex Eala thrilled to open 2026 with doubles win vs ‘pioneers’ Venus ...

Alex Eala Thrilled To Open 2026 With Doubles Win Vs 'pioneers' Venus
--------------------------------------------------------------------

 ![Alex Eala thrilled to open 2026 with doubles win vs 'pioneers' Venus](https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA1TBWBm.img?w=480&h=848&m=4&q=94) <small>www.msn.com</small>Alex Eala thrilled to open 2026 with doubles win vs 'pioneers' Venus ...

Alex Eala Thrilled To Open 2026 With Doubles Win Vs ‘pioneers’ Venus
--------------------------------------------------------------------

 ![Alex Eala thrilled to open 2026 with doubles win vs ‘pioneers’ Venus](https://i.headtopics.com/images/2026/1/4/mlastandard/eala-faces-tennis-legend-williams-in-asb-classic-eala-faces-tennis-legend-williams-in-asb-classic-40C45A4E987BAF27E0E7ABCD11D065B8.webp?w=640) <small>uk.headtopics.com</small>Alex Eala thrilled to open 2026 with doubles win vs ‘pioneers’ Venus ...

Alex Eala Beats World No. 10 Elina Svitolina, Reaches DC Open
-------------------------------------------------------------

 ![Alex Eala beats world No. 10 Elina Svitolina, reaches DC Open](https://images.gmanews.tv/webpics/2026/08/AFP__20260729__2288174864__v1__HighRes__MubadalaCitiDcOpen2026Day3_2026_08_01_08_48_44.jpeg) <small>www.gmanetwork.com</small>Alex Eala beats world No. 10 Elina Svitolina, reaches DC Open ...

Young Guns Alex Eala, Iva Jovic Stun Veterans Venus Williams, Elina
-------------------------------------------------------------------

 ![Young guns Alex Eala, Iva Jovic stun veterans Venus Williams, Elina](https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA1TA0Sj.img?w=1200&h=791&m=4&q=100) <small>www.msn.com</small>Young guns Alex Eala, Iva Jovic stun veterans Venus Williams, Elina ...

🎾 QUARTERFINALS | BERLIN OPEN 2026 🇵🇭 Alex Eala 🆚 🇺🇦 Elina Svitolina 🗓️
-----------------------------------------------------------------------

 ![🎾 QUARTERFINALS | BERLIN OPEN 2026 🇵🇭 Alex Eala 🆚 🇺🇦 Elina Svitolina 🗓️](https://pbs.twimg.com/media/HLK7dApa4AA7VOV.jpg) <small>x.com</small>🎾 QUARTERFINALS | BERLIN OPEN 2026 🇵🇭 Alex Eala 🆚 🇺🇦 Elina Svitolina 🗓️ ...

Elina Svitolina Vs Alex Eala, Berlin Tennis Open 2026 Quarterfinal Live
-----------------------------------------------------------------------

 ![Elina Svitolina vs Alex Eala, Berlin Tennis Open 2026 Quarterfinal Live](https://i.ytimg.com/vi/G41fj2G9J5A/maxresdefault.jpg) <small>www.youtube.com</small>Elina Svitolina vs Alex Eala, Berlin Tennis Open 2026 Quarterfinal Live ...

Road Gets Tougher As Alex Eala Faces Elina Svitolina In Berlin Tennis
---------------------------------------------------------------------

 ![Road Gets Tougher as Alex Eala Faces Elina Svitolina in Berlin Tennis](https://files.rebanse.ph/sites/1/8c94e64a-eala-vs-svitolina-grass-court.png) <small>www.rebanse.ph</small>Road Gets Tougher as Alex Eala Faces Elina Svitolina in Berlin Tennis ...

Panay - FIRST WIN OF 2026 🇵🇭🎾 Filipina Tennis Sensation Alex Eala And
---------------------------------------------------------------------

 ![Panay - FIRST WIN OF 2026 🇵🇭🎾 Filipina tennis sensation Alex Eala and](https://lookaside.fbsbx.com/lookaside/crawler/media/?media_id=1310150024477265) <small>www.facebook.com</small>Panay - FIRST WIN OF 2026 🇵🇭🎾 Filipina tennis sensation Alex Eala and ...

Alex Eala Knocks Off Elina Svitolina, Advances To Berlin Open Semis
-------------------------------------------------------------------

 ![Alex Eala knocks off Elina Svitolina, advances to Berlin Open semis](https://sports.inquirer.net/files/2026/06/727823775_1581535023605127_4484758511492674273_n-e1781891274633-2048x1384.jpeg) <small>sports.inquirer.net</small>Alex Eala knocks off Elina Svitolina, advances to Berlin Open semis

Alex Eala, Iva Jovic Tiniris Tambalan Nina Venus Williams, Elina Svitolina
--------------------------------------------------------------------------

 ![Alex Eala, Iva Jovic tiniris tambalan nina Venus Williams, Elina Svitolina](https://www.abante.com.ph/wp-content/uploads/elementor/thumbs/gwqe-rh7cgocz2wfcjzuy07tg2wwd0r2s5l69cxnbpxifmu.jpg) <small>www.abante.com.ph</small>Alex Eala, Iva Jovic tiniris tambalan nina Venus Williams, Elina Svitolina

Alex eala beats world no. 10 elina svitolina, reaches dc open. The news. Alex eala thrilled to open 2026 with doubles win vs 'pioneers' venus
