---
title: "Usman Nurmagomedov Next Fight - Mma fighter merab dvalishvili bleeds after brawl with usman ..."
description: "Umar nurmagomedov says usman is ready to fight ufc champions"
date: "2026-01-08"
categories:
- "Uncategorized"
images:
- "https://supabase-nf.next-fight.com/storage/v1/object/public/articles-media/2026-11/1794476697973-wpdcf59j.jpg"
featuredImage: "https://mmasucka.com/_next/image/?url=%2Fapi%2Fmedia%2Ffile%2FDaniel Cormier%2C Islam Makhachev%2C and Carlos Prates.webp&amp;w=3840&amp;q=75"
featured_image: "https://www.thesun.co.uk/wp-content/uploads/2026/11/shocking-moment-usman-nurmagomedov-attacks-1122409389.jpg?w=540"
image: "https://mmajunkie.usatoday.com/gcdn/authoring/images/smg/2025/01/27/SMGW/77983146007-91-2801005.jpeg?width=660&amp;height=372&amp;fit=crop&amp;format=pjpg&amp;auto=webp"
---

If you are searching about Op-ed: Usman Nurmagomedov, Makhachev and the Merab Dvalishvili hotel you've came to the right web. We have 35 Images about Op-ed: Usman Nurmagomedov, Makhachev and the Merab Dvalishvili hotel like Usman Nurmagomedov Rumored to Join UFC for Next Fight, Will Usman Nurmagomedov’s cowardly attack test the UFC’s moral compass and also Usman Nurmagomedov Faces Backlash After Alleged Attack On Merab. Here you go:

Op-ed: Usman Nurmagomedov, Makhachev And The Merab Dvalishvili Hotel
--------------------------------------------------------------------

 ![Op-ed: Usman Nurmagomedov, Makhachev and the Merab Dvalishvili hotel](https://supabase-nf.next-fight.com/storage/v1/object/public/articles-media/2026-11/1794476697973-wpdcf59j.jpg) <small>next-fight.com</small>Op-ed: Usman Nurmagomedov, Makhachev and the Merab Dvalishvili hotel ...

Usman Nurmagomedov Strikes Merab Dvalishvili In Abu Dhabi | FightRealm
----------------------------------------------------------------------

 ![Usman Nurmagomedov Strikes Merab Dvalishvili in Abu Dhabi | FightRealm](https://www.fightrealm.com/_next/image/?url=%2Fimg%2FFoundingMember.png&w=750&q=75) <small>www.fightrealm.com</small>Usman Nurmagomedov Strikes Merab Dvalishvili in Abu Dhabi | FightRealm

Usman Nurmagomedov Rumored To Join UFC For Next Fight
-----------------------------------------------------

 ![Usman Nurmagomedov Rumored to Join UFC for Next Fight](https://mmasucka.com/_next/image/?url=%2Fapi%2Fmedia%2Ffile%2Fimago1072218172h.webp&w=3840&q=75) <small>mmasucka.com</small>Usman Nurmagomedov Rumored to Join UFC for Next Fight

Shocking Moment Usman Nurmagomedov Attacks Merab In Hotel Lobby With
--------------------------------------------------------------------

 ![Shocking moment Usman Nurmagomedov attacks Merab in hotel lobby with](https://www.thesun.co.uk/wp-content/uploads/2026/11/shocking-moment-usman-nurmagomedov-attacks-1122409389.jpg?w=540) <small>www.thesun.ie</small>Shocking moment Usman Nurmagomedov attacks Merab in hotel lobby with ...

Usman Nurmagomedov Rumored To Join UFC For Next Fight
-----------------------------------------------------

 ![Usman Nurmagomedov Rumored to Join UFC for Next Fight](https://mmasucka.com/_next/image/?url=%2Fapi%2Fmedia%2Ffile%2Fimago1064962501h.webp&w=3840&q=75) <small>mmasucka.com</small>Usman Nurmagomedov Rumored to Join UFC for Next Fight

What Happened Between Merab Dvalishvili And Usman Nurmagomedov? UFC
-------------------------------------------------------------------

 ![What happened between Merab Dvalishvili and Usman Nurmagomedov? UFC](https://news-frontend.news.indazn.com/_next/image?url=https:%2F%2Fimages.daznservices.com%2Fdi%2Flibrary%2FDAZN_News%2F81%2F68%2Filia-topuria_17cqjk8y6kmi91mtdwrbn73wcd.jpg%3Ft%3D-1171917918&w=1200&q=75) <small>www.dazn.com</small>What happened between Merab Dvalishvili and Usman Nurmagomedov? UFC ...

Usman Nurmagomedov’s Manager Drops Blunt Truth On ‘False’ Promotion
-------------------------------------------------------------------

 ![Usman Nurmagomedov’s Manager Drops Blunt Truth on ‘False’ Promotion](https://img.particlenews.com/img/id/1832gG_1GywOn8r00) <small>www.newsbreak.com</small>Usman Nurmagomedov’s Manager Drops Blunt Truth on ‘False’ Promotion ...

Nurmagomedov Vs Hughes 2: Paul Hughes' Rematch With Usman Nurmagomedov
----------------------------------------------------------------------

 ![Nurmagomedov vs Hughes 2: Paul Hughes' rematch with Usman Nurmagomedov](https://ichef.bbci.co.uk/ace/standard/1920/cpsprodpb/8cd6/live/77829a00-7432-11f0-a975-cb151ca452f4.jpg) <small>www.bbc.com</small>Nurmagomedov vs Hughes 2: Paul Hughes' rematch with Usman Nurmagomedov ...

Islam Makhachev Backs Usman Nurmagomedov After Alleged Attack On Merab
----------------------------------------------------------------------

 ![Islam Makhachev Backs Usman Nurmagomedov After Alleged Attack On Merab](https://c.ndtvimg.com/2026-10/1kl5fmmk_why-islam-makhachev-turned-down-a-carlos-prates-fight_625x300_27_October_26.png?im=FaceCrop,algorithm=dnn,width=806,height=453&output-quality=80) <small>sports.ndtv.com</small>Islam Makhachev Backs Usman Nurmagomedov After Alleged Attack On Merab ...

Georgian UFC Champion Merab Dvalishvili Attacked By Daghestani Fighter
----------------------------------------------------------------------

 ![Georgian UFC champion Merab Dvalishvili attacked by Daghestani fighter](https://oc-media.org/_next/image/?url=https:%2F%2Fassets.bucket.fourthestate.app%2Foc-media-prod%2Fcontent%2Fimages%2F2026%2F11%2FBeFunky-collage_20261112-092945.jpg&w=3840&q=90) <small>oc-media.org</small>Georgian UFC champion Merab Dvalishvili attacked by Daghestani fighter ...

Usman Nurmagomedov Rumored To Join UFC For Next Fight
-----------------------------------------------------

 ![Usman Nurmagomedov Rumored to Join UFC for Next Fight](https://mmasucka.com/_next/image/?url=%2Fapi%2Fmedia%2Ffile%2FDaniel Cormier%2C Islam Makhachev%2C and Carlos Prates.webp&w=3840&q=75) <small>mmasucka.com</small>Usman Nurmagomedov Rumored to Join UFC for Next Fight

Usman Nurmagomedov Faces Backlash After Alleged Attack On Merab
---------------------------------------------------------------

 ![Usman Nurmagomedov Faces Backlash After Alleged Attack On Merab](https://c.ndtvimg.com/2026-10/gp0qrack_merab-dvalishvili-_625x300_22_October_26.png?im=FaceCrop,algorithm=dnn,width=1600,height=900&output-quality=80) <small>sports.ndtv.com</small>Usman Nurmagomedov Faces Backlash After Alleged Attack On Merab ...

Bloodied Merab Dvalishvili Accuses Usman Nurmagomedov
-----------------------------------------------------

 ![Bloodied Merab Dvalishvili Accuses Usman Nurmagomedov](https://mmasucka.com/_next/image/?url=%2Fapi%2Fmedia%2Ffile%2Fimago0859168059h.webp&w=3840&q=75) <small>mmasucka.com</small>Bloodied Merab Dvalishvili Accuses Usman Nurmagomedov

Usman Nurmagomedov And Merab Dvalishvili Fight In Hotel In Abu Dhabi
--------------------------------------------------------------------

 ![Usman Nurmagomedov and Merab Dvalishvili fight in hotel in Abu Dhabi](https://www.usatoday.com/gcdn/authoring/authoring-images/2026/11/12/USAT/92736115007-usman-nurmagomedov.jpg?crop=5989,3373,x0,y277&width=3200&height=1803&format=pjpg&auto=webp) <small>www.usatoday.com</small>Usman Nurmagomedov and Merab Dvalishvili fight in hotel in Abu Dhabi

Usman Magomedov Fight Khabib "the Eagle" Nurmagomedov Islam #MMM #
------------------------------------------------------------------

 ![Usman magomedov fight Khabib "the Eagle" Nurmagomedov Islam #MMM #](https://lookaside.fbsbx.com/lookaside/crawler/media/?media_id=2076546143173688) <small>www.facebook.com</small>Usman magomedov fight Khabib "the Eagle" Nurmagomedov Islam #MMM # ...

Umar Nurmagomedov Says Usman Is Ready To Fight UFC Champions
------------------------------------------------------------

 ![Umar Nurmagomedov Says Usman Is Ready to Fight UFC Champions](https://mmasucka.com/_next/image/?url=%2Fapi%2Fmedia%2Ffile%2FSean O'Malley-4.webp&w=3840&q=75) <small>mmasucka.com</small>Umar Nurmagomedov Says Usman Is Ready to Fight UFC Champions

Usman Nurmagomedov Warns Alfie Davis Ahead Of PFL Title Fight In Dubai
----------------------------------------------------------------------

 ![Usman Nurmagomedov warns Alfie Davis ahead of PFL title fight in Dubai](https://mmajunkie.usatoday.com/gcdn/authoring/authoring-images/2025/10/03/SMMA/86506189007-usman-nurmagomedov-def-paul-hughes-pfl-cs-dubai-24.jpg?crop=5468,3077,x0,y285&width=3200&height=1801&format=pjpg&auto=webp) <small>mmajunkie.usatoday.com</small>Usman Nurmagomedov warns Alfie Davis ahead of PFL title fight in Dubai

Umar Nurmagomedov Says Usman Is Ready To Fight UFC Champions
------------------------------------------------------------

 ![Umar Nurmagomedov Says Usman Is Ready to Fight UFC Champions](https://mmasucka.com/_next/image/?url=%2Fapi%2Fmedia%2Ffile%2FCosta-2.webp&w=3840&q=75) <small>mmasucka.com</small>Umar Nurmagomedov Says Usman Is Ready to Fight UFC Champions

Usman Nurmagomedov Strikes Merab Dvalishvili In Abu Dhabi | FightRealm
----------------------------------------------------------------------

 ![Usman Nurmagomedov Strikes Merab Dvalishvili in Abu Dhabi | FightRealm](https://www.fightrealm.com/_next/image/?url=https:%2F%2Fd2rppgzak84h35.cloudfront.net%2Fmedia%2Fimages%2Fmerab-article-cover-clean.min-500x1000.jpg&w=1920&q=75) <small>www.fightrealm.com</small>Usman Nurmagomedov Strikes Merab Dvalishvili in Abu Dhabi | FightRealm

Usman Nurmagomedov Condemned By UFC Fighters For 'jumping' Merab
----------------------------------------------------------------

 ![Usman Nurmagomedov condemned by UFC fighters for 'jumping' Merab](https://www.f4wonline.com/wp-content/uploads/2026/11/Merab-Dvalishvili-Attack-Usman-Abu-Dhabi.jpg?width=320&aspect_ratio=320:207) <small>www.f4wonline.com</small>Usman Nurmagomedov condemned by UFC fighters for 'jumping' Merab ...

Dvalishvili Says Usman Nurmagomedov Jumped Him In Abu Dhabi | Knockout Odds
---------------------------------------------------------------------------

 ![Dvalishvili Says Usman Nurmagomedov Jumped Him in Abu Dhabi | Knockout Odds](https://knockoutodds.com/_next/image?url=https:%2F%2Fyonfyutcpfzgahswaxzw.supabase.co%2Fstorage%2Fv1%2Fobject%2Fpublic%2Fnews%2F1794421918064-80dlyv.png&w=3840&q=75) <small>knockoutodds.com</small>Dvalishvili Says Usman Nurmagomedov Jumped Him in Abu Dhabi | Knockout Odds

Will Usman Nurmagomedov’s Cowardly Attack Test The UFC’s Moral Compass
----------------------------------------------------------------------

 ![Will Usman Nurmagomedov’s cowardly attack test the UFC’s moral compass](https://hermes.media.static.aol.com/media/2026/11/12/3ee619e4-e94e-376b-9912-4d51ce567459/0dea1eb1-db60-4b34-849a-2c996da4f296.jpg) <small>www.aol.com</small>Will Usman Nurmagomedov’s cowardly attack test the UFC’s moral compass ...

Usman Nurmagomedov Is Already Eager To Return To MMA
----------------------------------------------------

 ![Usman Nurmagomedov is already eager to return to MMA](https://mmasucka.com/_next/image/?url=%2Fapi%2Fmedia%2Ffile%2F3dbc8954ecc8c73a369f2548c05ad5e0-1.webp&w=3840&q=75) <small>mmasucka.com</small>Usman Nurmagomedov is already eager to return to MMA

MMA Fighter Merab Dvalishvili Bleeds After Brawl With Usman
-----------------------------------------------------------

 ![MMA Fighter Merab Dvalishvili Bleeds After Brawl With Usman](https://d3pc1xvrcw35tl.cloudfront.net/ln/images/1200x900/merab-dvalishvili-bleeds-in-fight-with-usman-nurmagomedov_2026111176920.jpeg) <small>www.lokmattimes.com</small>MMA Fighter Merab Dvalishvili Bleeds After Brawl With Usman ...

Usman Nurmagomedov Rumored To Join UFC For Next Fight
-----------------------------------------------------

 ![Usman Nurmagomedov Rumored to Join UFC for Next Fight](https://mmasucka.com/_next/image/?url=%2Fapi%2Fmedia%2Ffile%2Fimago1067390538h.webp&w=3840&q=75) <small>mmasucka.com</small>Usman Nurmagomedov Rumored to Join UFC for Next Fight

Video: Usman Nurmagomedov Vs. Paul Hughes: Best Fight In PFL History
--------------------------------------------------------------------

 ![Video: Usman Nurmagomedov vs. Paul Hughes: Best fight in PFL history](https://mmajunkie.usatoday.com/gcdn/authoring/images/smg/2025/01/27/SMGW/77983146007-91-2801005.jpeg?width=660&height=372&fit=crop&format=pjpg&auto=webp) <small>mmajunkie.usatoday.com</small>Video: Usman Nurmagomedov vs. Paul Hughes: Best fight in PFL history ...

Usman Nurmagomedov Rumored To Join UFC For Next Fight
-----------------------------------------------------

 ![Usman Nurmagomedov Rumored to Join UFC for Next Fight](https://mmasucka.com/api/media/file/usman-nurmagomedov-mauricio-ruffy.webp) <small>mmasucka.com</small>Usman Nurmagomedov Rumored to Join UFC for Next Fight

Usman Nurmagomedov Attacks Merab Dvalishvili In Abu Dhabi Hotel, Police
-----------------------------------------------------------------------

 ![Usman Nurmagomedov attacks Merab Dvalishvili in Abu Dhabi hotel, police](https://supabase-nf.next-fight.com/storage/v1/object/public/articles-media/2026-11/1794473289343-ssdmi9ck.jpg) <small>next-fight.com</small>Usman Nurmagomedov attacks Merab Dvalishvili in Abu Dhabi hotel, police ...

Usman Nurmagomedov Rumored To Join UFC For Next Fight
-----------------------------------------------------

 ![Usman Nurmagomedov Rumored to Join UFC for Next Fight](https://mmasucka.com/_next/image/?url=%2Fapi%2Fmedia%2Ffile%2Fstephen-thompson-1.webp&w=3840&q=75) <small>mmasucka.com</small>Usman Nurmagomedov Rumored to Join UFC for Next Fight

Usman Nurmagomedov Rumored To Join UFC For Next Fight
-----------------------------------------------------

 ![Usman Nurmagomedov Rumored to Join UFC for Next Fight](https://mmasucka.com/_next/image/?url=%2Fapi%2Fmedia%2Ffile%2FCarlos Prates-4.webp&w=3840&q=75) <small>mmasucka.com</small>Usman Nurmagomedov Rumored to Join UFC for Next Fight

Shocking Moment Usman Nurmagomedov Attacks Merab In Hotel Lobby With
--------------------------------------------------------------------

 ![Shocking moment Usman Nurmagomedov attacks Merab in hotel lobby with](https://www.thesun.ie/wp-content/uploads/sites/3/2026/11/JW-OP-UFC-BRAWL.jpg?quality=90&strip=all&w=1920&h=1080&crop=1) <small>www.thesun.ie</small>Shocking moment Usman Nurmagomedov attacks Merab in hotel lobby with ...

Umar Nurmagomedov Says Usman Is Ready To Fight UFC Champions
------------------------------------------------------------

 ![Umar Nurmagomedov Says Usman Is Ready to Fight UFC Champions](https://mmasucka.com/_next/image/?url=%2Fapi%2Fmedia%2Ffile%2Fimago0859166876h.webp&w=3840&q=75) <small>mmasucka.com</small>Umar Nurmagomedov Says Usman Is Ready to Fight UFC Champions

Umar Nurmagomedov Says Usman Is Ready To Fight UFC Champions
------------------------------------------------------------

 ![Umar Nurmagomedov Says Usman Is Ready to Fight UFC Champions](https://mmasucka.com/_next/image/?url=%2Fapi%2Fmedia%2Ffile%2FFotoJet (66).webp&w=3840&q=75) <small>mmasucka.com</small>Umar Nurmagomedov Says Usman Is Ready to Fight UFC Champions

Usman Nurmagomedov Is Already Eager To Return To MMA
----------------------------------------------------

 ![Usman Nurmagomedov is already eager to return to MMA](https://mmasucka.com/api/media/file/Usman Nurmagomedov-4.webp) <small>mmasucka.com</small>Usman Nurmagomedov is already eager to return to MMA

Usman Nurmagomedov Rumored To Join UFC For Next Fight
-----------------------------------------------------

 ![Usman Nurmagomedov Rumored to Join UFC for Next Fight](https://mmasucka.com/_next/image/?url=%2Fapi%2Fmedia%2Ffile%2FHokit - Cormier.webp&w=3840&q=75) <small>mmasucka.com</small>Usman Nurmagomedov Rumored to Join UFC for Next Fight

Usman nurmagomedov rumored to join ufc for next fight. Usman nurmagomedov’s manager drops blunt truth on ‘false’ promotion. Usman nurmagomedov is already eager to return to mma
