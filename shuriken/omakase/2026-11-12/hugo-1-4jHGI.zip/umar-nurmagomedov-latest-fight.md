---
title: "Umar Nurmagomedov Latest Fight - Ufc fight night 238 results: umar nurmagomedov survives knockdown, wins"
description: "Khabib&#039;s cousin umar nurmagomedov takes unbeaten record to 15 with ..."
date: "2026-11-05"
categories:
- "Uncategorized"
images:
- "https://www.sportsnet.ca/wp-content/uploads/2024/08/UFC-bantamweight-Umar-Nurmagomedov-1040x572.jpg"
featuredImage: "https://sportnews.az/storage/thumbs/aspect/d29b1d8c-dd78-49ed-9961-4aac2366bb4f.webp"
featured_image: "https://imageio.forbes.com/specials-images/imageserve/66b2107bee3284e776dec405/UFC-Fight-Night--Sandhagen-v-Nurmagomedov/0x0.jpg?width=960"
image: "https://media.mmanews.com/uploads/2026/01/Umar-Nurmagomedov.png"
---

If you are searching about Merab Dvalishvili Defeats Umar Nurmagomedov at UFC 311 you've visit to the right place. We have 35 Pictures about Merab Dvalishvili Defeats Umar Nurmagomedov at UFC 311 like Merab Dvalishvili Defeats Umar Nurmagomedov at UFC 311, Russia's Umar Nurmagomedov fight Mario Bautista of United States during and also UFC Fight Night 238 results: Umar Nurmagomedov survives knockdown, wins. Here it is:

Merab Dvalishvili Defeats Umar Nurmagomedov At UFC 311
------------------------------------------------------

 ![Merab Dvalishvili Defeats Umar Nurmagomedov at UFC 311](https://static0.givemesportimages.com/wordpress/wp-content/uploads/2025/01/mixcollage-19-jan-2025-05-42-am-5988.jpg) <small>www.givemesport.com</small>Merab Dvalishvili Defeats Umar Nurmagomedov at UFC 311

Russia's Umar Nurmagomedov Celebrates After Defeating Mario Bautista Of
-----------------------------------------------------------------------

 ![Russia's Umar Nurmagomedov celebrates after defeating Mario Bautista of](https://c8.alamy.com/comp/3D11N9N/russias-umar-nurmagomedov-celebrates-after-defeating-mario-bautista-of-united-states-during-the-bantamweight-bout-at-the-ufc-mixed-martial-arts-fight-night-in-abu-dhabi-united-arab-emirates-saturday-oct-25-2025-ap-photoaltaf-qadri-3D11N9N.jpg) <small>www.alamy.com</small>Russia's Umar Nurmagomedov celebrates after defeating Mario Bautista of ...

UFC Rankings: Umar Nurmagomedov Surges After Abu Dhabi Win
----------------------------------------------------------

 ![UFC Rankings: Umar Nurmagomedov Surges After Abu Dhabi Win](https://imageio.forbes.com/specials-images/imageserve/66b2107bee3284e776dec405/UFC-Fight-Night--Sandhagen-v-Nurmagomedov/0x0.jpg?width=960) <small>www.forbes.com</small>UFC Rankings: Umar Nurmagomedov Surges After Abu Dhabi Win

UFC 321: Umar Nurmagomedov Full Post-fight Interview
----------------------------------------------------

 ![UFC 321: Umar Nurmagomedov full post-fight interview](https://mmajunkie.usatoday.com/gcdn/authoring/authoring-images/2025/10/25/SMMA/86904866007-umar.jpg?crop=1919,1079,x0,y0&width=1919&height=1079&format=pjpg&auto=webp) <small>mmajunkie.usatoday.com</small>UFC 321: Umar Nurmagomedov full post-fight interview

Umar Nurmagomedov FIGHT Announcement By HIM | Khabib Statement On Umar
----------------------------------------------------------------------

 ![Umar Nurmagomedov FIGHT Announcement by HIM | Khabib Statement on Umar](https://i.ytimg.com/vi/4jR92GczTAs/maxresdefault.jpg) <small>www.youtube.com</small>Umar Nurmagomedov FIGHT Announcement by HIM | Khabib Statement on Umar ...

UFC Headliner Blows Shoulder Sparring, Replacement Set For Top
--------------------------------------------------------------

 ![UFC headliner blows shoulder sparring, replacement set for top](https://bloodyelbow.com/wp-content/uploads/1/2023/07/march-5-2022-las-vegas-1010404780-scaled.jpg) <small>bloodyelbow.com</small>UFC headliner blows shoulder sparring, replacement set for top ...

Umar Nurmagomedov On Yan-Dvalishvili Fight: "If Yan Can't Knock Him Out
-----------------------------------------------------------------------

 ![Umar Nurmagomedov on Yan-Dvalishvili fight: "If Yan can't knock him out](https://sportnews.az/storage/thumbs/aspect/d29b1d8c-dd78-49ed-9961-4aac2366bb4f.webp) <small>sportnews.az</small>Umar Nurmagomedov on Yan-Dvalishvili fight: "If Yan can't knock him out ...

Umar Nurmagomedov Vs Raoni Barcelos FULL FIGHT UFC Abu Dhabi - YouTube
----------------------------------------------------------------------

 ![Umar Nurmagomedov vs Raoni Barcelos FULL FIGHT UFC Abu Dhabi - YouTube](https://i.ytimg.com/vi/Btl2M66gJCw/maxresdefault.jpg?sqp=-oaymwEmCIAKENAF8quKqQMa8AEB-AH-CYAC0AWKAgwIABABGFIgYChlMA8=&rs=AOn4CLBw6YbLvRu2NQTfSlI7Vmw4XcLqgA) <small>www.youtube.com</small>Umar Nurmagomedov vs Raoni Barcelos FULL FIGHT UFC Abu Dhabi - YouTube

Umar Nurmagomedov: The Pressure Of Being Khabib's Cousin And His Thirst
-----------------------------------------------------------------------

 ![Umar Nurmagomedov: The pressure of being Khabib's cousin and his thirst](https://e00-xlk-ue-marca-en.uecdn.es/uploads/2026/04/20/17612391597123.jpeg) <small>www.marca.com</small>Umar Nurmagomedov: The pressure of being Khabib's cousin and his thirst ...

Umar Nurmagomedov Cruises To Clear Win Over Deiveson Figueiredo - UFC
---------------------------------------------------------------------

 ![Umar Nurmagomedov Cruises To Clear Win Over Deiveson Figueiredo - UFC](https://www.lowkickmma.com/wp-content/uploads/2026/01/MixCollage-24-Jan-2026-07-53-PM-9213.jpg) <small>www.lowkickmma.com</small>Umar Nurmagomedov Cruises To Clear Win Over Deiveson Figueiredo - UFC ...

UFC 324 Umar Nurmagomedov Vs DeivesonFigueiredo Full Fight Highlights
---------------------------------------------------------------------

 ![UFC 324 Umar Nurmagomedov vs DeivesonFigueiredo full fight Highlights](https://i.ytimg.com/vi/_TapQrXF8mc/hqdefault.jpg) <small>www.youtube.com</small>UFC 324 Umar Nurmagomedov vs DeivesonFigueiredo full fight Highlights ...

Umar Nurmagomedov Vs. David Martinez Co-headlines UFC Abu Dhabi - Yahoo
-----------------------------------------------------------------------

 ![Umar Nurmagomedov vs. David Martinez co-headlines UFC Abu Dhabi - Yahoo](https://s.yimg.com/ny/api/res/1.2/R7tb9iFAyl.GyI7Xy2NoGA--/YXBwaWQ9aGlnaGxhbmRlcjt3PTk2MDtoPTEyMDA7Y2Y9d2VicA--/https://media.zenfs.com/en/mma_junkie_usa_today_articles_344/df127ad008f42511c3089ba0325d62dd) <small>sports.yahoo.com</small>Umar Nurmagomedov vs. David Martinez co-headlines UFC Abu Dhabi - Yahoo ...

Umar Nurmagomedov : Les Images De Sa Blessure à L'entraînement
--------------------------------------------------------------

 ![Umar Nurmagomedov : les images de sa blessure à l'entraînement](https://lasueur.com/wp-content/uploads/2023/07/Umar-Nurmagomedov.jpg) <small>lasueur.com</small>Umar Nurmagomedov : les images de sa blessure à l'entraînement

Umar Nurmagomedov Calls For Title Shot After Shutting Down Cory
---------------------------------------------------------------

 ![Umar Nurmagomedov calls for title shot after shutting down Cory](https://cdn.vox-cdn.com/thumbor/r29Gk3fMJugK16wn5oRmgLgfR3I=/0x0:6586x4391/1520x1013/filters:focal(2059x569:3111x1621)/cdn.vox-cdn.com/uploads/chorus_image/image/73500204/2165153190.0.jpg) <small>www.mmafighting.com</small>Umar Nurmagomedov calls for title shot after shutting down Cory ...

Umar Nurmagomedov Releases First Statement Since UFC 311 Title Fight
--------------------------------------------------------------------

 ![Umar Nurmagomedov releases first statement since UFC 311 title fight](https://cdn.vox-cdn.com/thumbor/XffRRLhX-CgKlNu4UWXk4c7btjg=/0x0:4954x3303/1200x800/filters:focal(2489x668:3281x1460)/cdn.vox-cdn.com/uploads/chorus_image/image/73858109/2194645998.0.jpg) <small>www.mmafighting.com</small>Umar Nurmagomedov releases first statement since UFC 311 title fight ...

Umar Nurmagomedov On Marab Beef, Pressure &amp; His Next Fight With Mario
-------------------------------------------------------------------------

 ![Umar Nurmagomedov on Marab Beef, Pressure & His Next Fight with Mario](https://i.ytimg.com/vi/-mKraTYBT54/maxresdefault.jpg) <small>www.youtube.com</small>Umar Nurmagomedov on Marab Beef, Pressure &amp; His Next Fight with Mario ...

Umar Nurmagomedov Vs Mario Bautista FULL FIGHT HIGHLIGHTS RECAP UFC 321
-----------------------------------------------------------------------

 ![Umar Nurmagomedov vs Mario Bautista FULL FIGHT HIGHLIGHTS RECAP UFC 321](https://www.fogolf.com/wp-content/uploads/2025/10/1761625944_maxresdefault-1024x576.jpg) <small>www.fogolf.com</small>Umar Nurmagomedov vs Mario Bautista FULL FIGHT HIGHLIGHTS RECAP UFC 321 ...

Islam Makhachev Reacts To Umar Nurmagomedov's UFC 311 Title Loss: 'He's
-----------------------------------------------------------------------

 ![Islam Makhachev reacts to Umar Nurmagomedov's UFC 311 title loss: 'He's](https://mmajunkie.usatoday.com/gcdn/authoring/images/smg/2025/01/19/SMGW/77820045007-91-2799092.jpeg?width=660&height=435&fit=crop&format=pjpg&auto=webp) <small>mmajunkie.usatoday.com</small>Islam Makhachev reacts to Umar Nurmagomedov's UFC 311 title loss: 'He's ...

Islam Makhachev And Umar Nurmagomedov Urges New Champion Merab
--------------------------------------------------------------

 ![Islam Makhachev and Umar Nurmagomedov urges new champion Merab](https://firstsportz.com/wp-content/uploads/2024/09/Islam-Makhachev-and-Umar-Nurmagomedov-after-Merab-Dvalishvili-becomes-champion-1200x675.jpg) <small>firstsportz.com</small>Islam Makhachev and Umar Nurmagomedov urges new champion Merab ...

UFC Fight Night Results, Highlights: Umar Nurmagomedov Guts Out Win
-------------------------------------------------------------------

 ![UFC Fight Night results, highlights: Umar Nurmagomedov guts out win](https://sportshub.cbsistatic.com/i/r/2024/08/03/881bc391-104f-49ca-83c3-28feb085587d/thumbnail/1200x675/9284a65ed8bf816bb5b0c81bb3b48044/umar-nurmagomedov-sandhagen-kick.jpg) <small>www.cbssports.com</small>UFC Fight Night results, highlights: Umar Nurmagomedov guts out win ...

Merab Dvalishvili Vs Umar Nurmagomedov UFC 311 Result: Champion Talks
---------------------------------------------------------------------

 ![Merab Dvalishvili vs Umar Nurmagomedov UFC 311 result: Champion talks](https://bloodyelbow.com/wp-content/uploads/1/2025/01/GettyImages-2194647806-1536x1108.jpg) <small>bloodyelbow.com</small>Merab Dvalishvili vs Umar Nurmagomedov UFC 311 result: Champion talks ...

Umar Nurmagomedov Potentially Locks In Key Agreement With Dana White
--------------------------------------------------------------------

 ![Umar Nurmagomedov Potentially Locks In Key Agreement with Dana White](https://nyfights.com/wp-content/uploads/2025/10/USATSI_25224796-scaled.jpg) <small>nyfights.com</small>Umar Nurmagomedov Potentially Locks In Key Agreement with Dana White ...

Umar Nurmagomedov Beats Cory Sandhagen To Emerge As UFC Title Threat
--------------------------------------------------------------------

 ![Umar Nurmagomedov beats Cory Sandhagen to emerge as UFC title threat](https://www.sportsnet.ca/wp-content/uploads/2024/08/UFC-bantamweight-Umar-Nurmagomedov-1040x572.jpg) <small>www.sportsnet.ca</small>Umar Nurmagomedov beats Cory Sandhagen to emerge as UFC title threat

UFC Fight Night 238 Results: Umar Nurmagomedov Survives Knockdown, Wins
-----------------------------------------------------------------------

 ![UFC Fight Night 238 results: Umar Nurmagomedov survives knockdown, wins](https://mmajunkie.usatoday.com/gcdn/authoring/images/smg/2025/02/24/SMMA/80013311007-91-2720702.jpeg?width=660&height=441&fit=crop&format=pjpg&auto=webp) <small>mmajunkie.usatoday.com</small>UFC Fight Night 238 results: Umar Nurmagomedov survives knockdown, wins ...

“I Do Not Feel Good About This Guy Fighting Yan Or Merab” – Fans
----------------------------------------------------------------

 ![“I Do Not Feel Good About This Guy Fighting Yan Or Merab” – Fans](https://media.mmanews.com/uploads/2026/01/Umar-Nurmagomedov.png) <small>www.mmanews.com</small>“I Do Not Feel Good About This Guy Fighting Yan Or Merab” – Fans ...

Umar Nurmagomedov Convinced He Beat Merab Dvalishvili In UFC 311 Title
----------------------------------------------------------------------

 ![Umar Nurmagomedov convinced he beat Merab Dvalishvili in UFC 311 title](https://s.yimg.com/ny/api/res/1.2/mApeaXjHSLli7NhP9.fFyQ--/YXBwaWQ9aGlnaGxhbmRlcjt3PTEyMDA7aD04MDM-/https://media.zenfs.com/en/mma_junkie_usa_today_articles_344/db77ff2733c02ffa7b12654d586cc987) <small>au.sports.yahoo.com</small>Umar Nurmagomedov convinced he beat Merab Dvalishvili in UFC 311 title ...

Umar Nurmagomedov – Next Fight, News, Latest Fights, MMA Fight Record
---------------------------------------------------------------------

 ![Umar Nurmagomedov – Next fight, news, latest fights, MMA fight record](https://ringside24.com/media/cache/61/6a/616a8cc61e86eb0380544f4955757394.jpg) <small>ringside24.com</small>Umar Nurmagomedov – Next fight, news, latest fights, MMA fight record ...

Khabib's Cousin Umar Nurmagomedov Takes Unbeaten Record To 15 With
------------------------------------------------------------------

 ![Khabib's cousin Umar Nurmagomedov takes unbeaten record to 15 with](https://www.the-sun.com/wp-content/uploads/sites/6/2022/06/3592d9c4-0d5b-4904-a64d-f033284aba18.jpg?resize=717) <small>www.the-sun.com</small>Khabib's cousin Umar Nurmagomedov takes unbeaten record to 15 with ...

Umar Nurmagomedov Survives Knockdown To End Mario Bautista's 8-fight
--------------------------------------------------------------------

 ![Umar Nurmagomedov survives knockdown to end Mario Bautista's 8-fight](https://bloodyelbow.com/wp-content/uploads/1/2025/10/GettyImages-2243271776-scaled.jpg) <small>bloodyelbow.com</small>Umar Nurmagomedov survives knockdown to end Mario Bautista's 8-fight ...

Umar Nurmagomedov's Only UFC KO Saw Him Stop Fighter Who Recorded 2025
----------------------------------------------------------------------

 ![Umar Nurmagomedov's only UFC KO saw him stop fighter who recorded 2025](https://bloodyelbow.com/wp-content/uploads/1/2026/01/GettyImages-1456466744-1536x1048.jpg) <small>bloodyelbow.com</small>Umar Nurmagomedov's only UFC KO saw him stop fighter who recorded 2025 ...

Umar Nurmagomedov Fought With Broken Hand, But Didn't Tell Coach, In
--------------------------------------------------------------------

 ![Umar Nurmagomedov Fought With Broken Hand, But Didn't Tell Coach, In](https://assets.newsweek.com/wp-content/uploads/2025/08/2570659-umar-nurmagomedov.jpg?w=1360&quality=80&webp=1) <small>www.newsweek.com</small>Umar Nurmagomedov Fought With Broken Hand, But Didn't Tell Coach, In ...

Umar Nurmagomedov Survives Knockdown To End Mario Bautista's 8-fight
--------------------------------------------------------------------

 ![Umar Nurmagomedov survives knockdown to end Mario Bautista's 8-fight](https://bloodyelbow.com/wp-content/uploads/1/2025/10/GettyImages-2243273601-1536x1024.jpg) <small>bloodyelbow.com</small>Umar Nurmagomedov survives knockdown to end Mario Bautista's 8-fight ...

Russia's Umar Nurmagomedov Fight Mario Bautista Of United States During
-----------------------------------------------------------------------

 ![Russia's Umar Nurmagomedov fight Mario Bautista of United States during](https://c8.alamy.com/comp/3D11N3A/russias-umar-nurmagomedov-fight-mario-bautista-of-united-states-during-the-bantamweight-bout-at-the-ufc-mixed-martial-arts-fight-night-in-abu-dhabi-united-arab-emirates-saturday-oct-25-2025-ap-photoaltaf-qadri-3D11N3A.jpg) <small>www.alamy.com</small>Russia's Umar Nurmagomedov fight Mario Bautista of United States during ...

Mixed Martial Arts News, Video, Rankings, Results, And History - MMA - ESPN
---------------------------------------------------------------------------

 ![Mixed Martial Arts News, Video, Rankings, Results, and History - MMA - ESPN](https://a.espncdn.com/media/motion/2022/0626/dm_220625_DM_MMA_UFC_UMAR_KICK_TO_FACE17/dm_220625_DM_MMA_UFC_UMAR_KICK_TO_FACE17.jpg) <small>www.espn.com</small>Mixed Martial Arts News, Video, Rankings, Results, and History - MMA - ESPN

Umar Nurmagomedov Knocks Raoni Barcelos Out Cold With Slick Left Hand
---------------------------------------------------------------------

 ![Umar Nurmagomedov Knocks Raoni Barcelos Out Cold with Slick Left Hand](https://middleeasy.com/wp-content/uploads/2023/01/Collage-Maker-14-Jan-2023-04-25-PM.jpg) <small>middleeasy.com</small>Umar Nurmagomedov Knocks Raoni Barcelos Out Cold with Slick Left Hand ...

Umar nurmagomedov vs mario bautista full fight highlights recap ufc 321. umar nurmagomedov fight announcement by him. Umar nurmagomedov calls for title shot after shutting down cory
