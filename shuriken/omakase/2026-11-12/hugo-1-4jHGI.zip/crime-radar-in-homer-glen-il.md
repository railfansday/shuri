---
title: "Crime Radar In Homer Glen Il - Homer glen crime statistics: illinois (il)"
description: "Homer glen, il violent crime rates and maps"
date: "2026-06-21"
categories:
- "Uncategorized"
images:
- "https://www.cityrating.com/charts/illinois/homer-glen-violent-crime.png"
featuredImage: "https://www.weather-forecast.com/locationmaps/Homer-Glen.10.gif"
featured_image: "https://images.crimegrade.org/map/violence-rates/violent-crime-per-capita-map-homer-il.webp"
image: "https://s3.amazonaws.com/crime-maps-aws.neighborhoodscout.com/glen-ellyn-il-crime-map.png"
---

If you are looking for Homer Glen, IL Crime Map you've came to the right page. We have 35 Pictures about Homer Glen, IL Crime Map like Homer Glen Crime Rates and Statistics - NeighborhoodScout, Homer Glen, IL Violent Crime Rates and Maps | CrimeGrade.org and also Homewood, IL, 60430 Crime Rates and Crime Statistics - NeighborhoodScout. Here you go:

Homer Glen, IL Crime Map
------------------------

 ![Homer Glen, IL Crime Map](https://www.doorprofit.com/crime-map-images/2075.png) <small>www.doorprofit.com</small>Homer Glen, IL Crime Map

Women Targeted In Home Invasions In Homer Glen And Lemont - CBS Chicago
-----------------------------------------------------------------------

 ![Women targeted in home invasions in Homer Glen and Lemont - CBS Chicago](https://assets3.cbsnewsstatic.com/hub/i/r/2025/12/12/c1d75bba-9b32-4dac-9f5a-e7c9a93a899f/thumbnail/1200x630/4189c35b3d6c1b1d514fce147099d081/180607bec13c055087ac51956745f0c1-0-1765512678358.jpg) <small>www.cbsnews.com</small>Women targeted in home invasions in Homer Glen and Lemont - CBS Chicago

Homer, IL Violent Crime Rates And Maps | CrimeGrade.org
-------------------------------------------------------

 ![Homer, IL Violent Crime Rates and Maps | CrimeGrade.org](https://images.crimegrade.org/map/violence-rates/violent-crime-per-capita-map-homer-il.webp) <small>crimegrade.org</small>Homer, IL Violent Crime Rates and Maps | CrimeGrade.org

On The Lookout: Police Search For Gunman In Homer Shooting – WSYR
-----------------------------------------------------------------

 ![On the Lookout: Police search for gunman in Homer shooting – WSYR](https://c104216-ucdn.mp.lura.live/expiretime=2082787200/663453aa636ff27c070ffdebf02502c48526b4a7bb5379d089174e7fa6d0cb74/iupl_lin/581/AAD/581AAD4A999E21106833C550D3848A8F.jpg) <small>www.localsyr.com</small>On the Lookout: Police search for gunman in Homer shooting – WSYR

Homer Crime Statistics: Illinois (IL) - CityRating.com
------------------------------------------------------

 ![Homer Crime Statistics: Illinois (IL) - CityRating.com](https://www.cityrating.com/charts/illinois/homer-property-crime-per-capita.png) <small>www.cityrating.com</small>Homer Crime Statistics: Illinois (IL) - CityRating.com

Officers Check Address For Reported Stolen Vehicle, Chicago IL | CrimeRadar
---------------------------------------------------------------------------

 ![Officers check address for reported stolen vehicle, Chicago IL | CrimeRadar](https://ui.prt.news/cr_share_37360_1771963283_gltdprdv.jpeg) <small>www.uscrimeradar.com</small>Officers check address for reported stolen vehicle, Chicago IL | CrimeRadar

Homer Glen, Homer Glen Crime Rates And Safety Statistics
--------------------------------------------------------

 ![Homer Glen, Homer Glen crime rates and safety statistics](https://us1-photo.nextdoor.com/post_photos/88/1a/881a7ae078a272d140e82f75a466c66d) <small>nextdoor.com</small>Homer Glen, Homer Glen crime rates and safety statistics

Traffic Control Needed During Street Light Check At S Bell Rd, Homer
--------------------------------------------------------------------

 ![Traffic control needed during street light check at S Bell Rd, Homer](https://ui.prt.news/satellite41.63121,-87.92777.jpeg) <small>www.newsbreak.com</small>Traffic control needed during street light check at S Bell Rd, Homer ...

House Hit By Lightning With Smoke In Basement, Homer Glen IL | CrimeRadar
-------------------------------------------------------------------------

 ![House hit by lightning with smoke in basement, Homer Glen IL | CrimeRadar](https://ui.prt.news/cr_share_2324-33946_1774975132_fkxeysdl.jpeg) <small>www.uscrimeradar.com</small>House hit by lightning with smoke in basement, Homer Glen IL | CrimeRadar

Homer Glen Weather Forecast
---------------------------

 ![Homer Glen Weather Forecast](https://www.weather-forecast.com/locationmaps/Homer-Glen.12.gif) <small>www.weather-forecast.com</small>Homer Glen Weather Forecast

Wypadek W Homer Glen. Dwie Osoby Nie żyją A 3 Są W Krytycznym Stanie
--------------------------------------------------------------------

 ![Wypadek w Homer Glen. Dwie osoby nie żyją a 3 są w krytycznym stanie](https://polski.fm/wp-content/uploads/2022/06/Homer-wyadek-2.png) <small>polski.fm</small>Wypadek w Homer Glen. Dwie osoby nie żyją a 3 są w krytycznym stanie ...

Injury Crash At Roosevelt And South Park Boulevard, Glen Ellyn IL
-----------------------------------------------------------------

 ![Injury crash at Roosevelt and South Park Boulevard, Glen Ellyn IL](https://ui.prt.news/cr_share_31772_1774136693_dkwmkbov.jpeg) <small>www.uscrimeradar.com</small>Injury crash at Roosevelt and South Park Boulevard, Glen Ellyn IL ...

Man Reportedly Threatened Someone With A Gun, Chicago IL | CrimeRadar
---------------------------------------------------------------------

 ![Man reportedly threatened someone with a gun, Chicago IL | CrimeRadar](https://ui.prt.news/cr_share_37361_1774561614_jfpfwfhb.jpeg) <small>www.uscrimeradar.com</small>Man reportedly threatened someone with a gun, Chicago IL | CrimeRadar

Homer Glen Crime Statistics: Illinois (IL) - CityRating.com
-----------------------------------------------------------

 ![Homer Glen Crime Statistics: Illinois (IL) - CityRating.com](https://www.cityrating.com/charts/illinois/homer-glen-property-crime.png) <small>www.cityrating.com</small>Homer Glen Crime Statistics: Illinois (IL) - CityRating.com

CrimeRadar - Apps On Google Play
--------------------------------

 ![CrimeRadar - Apps on Google Play](https://play-lh.googleusercontent.com/Fs4MB4z4qfhRzOEKzSqOxHMEoyJRNgdi-u4KqAk3jboDBbw6nooPsmS3MhUMKjuYzDA=w526-h296) <small>play.google.com</small>CrimeRadar - Apps on Google Play

Homer Glen, IL Burglary Crime Rates And Maps | CrimeGrade.org
-------------------------------------------------------------

 ![Homer Glen, IL Burglary Crime Rates and Maps | CrimeGrade.org](https://images.crimegrade.org/map/burglary-rates/burglary-per-capita-map-homer-glen-il.webp) <small>crimegrade.org</small>Homer Glen, IL Burglary Crime Rates and Maps | CrimeGrade.org

Homer Glen News - ABC7 Chicago
------------------------------

 ![Homer Glen News - ABC7 Chicago](https://cdn.abcotvs.com/dip/images/18283168_121325-wls-home-invasion-charges-8a-vid.jpg) <small>abc7chicago.com</small>Homer Glen News - ABC7 Chicago

Homewood, IL, 60430 Crime Rates And Crime Statistics - NeighborhoodScout
------------------------------------------------------------------------

 ![Homewood, IL, 60430 Crime Rates and Crime Statistics - NeighborhoodScout](https://s3.amazonaws.com/crime-maps-aws.neighborhoodscout.com/homewood-il-crime-map.png) <small>www.neighborhoodscout.com</small>Homewood, IL, 60430 Crime Rates and Crime Statistics - NeighborhoodScout

July 25, 2007 Severe Weather Event
----------------------------------

 ![July 25, 2007 Severe Weather Event](https://www.weather.gov/images/lot/pastevents/2007/Jul25/Homer_vel.jpg) <small>www.weather.gov</small>July 25, 2007 Severe Weather Event

Glen Ellyn, 60137 Crime Rates And Crime Statistics - NeighborhoodScout
----------------------------------------------------------------------

 ![Glen Ellyn, 60137 Crime Rates and Crime Statistics - NeighborhoodScout](https://s3.amazonaws.com/crime-maps-aws.neighborhoodscout.com/glen-ellyn-il-crime-map.png) <small>www.neighborhoodscout.com</small>Glen Ellyn, 60137 Crime Rates and Crime Statistics - NeighborhoodScout

Homer Glen, IL Violent Crime Rates And Maps | CrimeGrade.org
------------------------------------------------------------

 ![Homer Glen, IL Violent Crime Rates and Maps | CrimeGrade.org](https://images.crimegrade.org/map/violence-rates/violent-crime-per-capita-map-homer-glen-il.webp) <small>crimegrade.org</small>Homer Glen, IL Violent Crime Rates and Maps | CrimeGrade.org

Radar For Homer Glen Il | Homer Glen, IL Weather Radar Map – SRDFQ
------------------------------------------------------------------

 ![Radar For Homer Glen Il | Homer Glen, IL Weather Radar Map – SRDFQ](https://patch.com/img/cdn20/users/22920555/20170622/100746/styles/raw/public/article_images/homer_glen_park-1498140244-463.jpg) <small>hu.gallounfair.com</small>Radar For Homer Glen Il | Homer Glen, IL Weather Radar Map – SRDFQ

Homer Glen Crime Statistics: Illinois (IL) - CityRating.com
-----------------------------------------------------------

 ![Homer Glen Crime Statistics: Illinois (IL) - CityRating.com](https://www.cityrating.com/charts/illinois/homer-glen-violent-crime.png) <small>www.cityrating.com</small>Homer Glen Crime Statistics: Illinois (IL) - CityRating.com

Illinois's Safest Cities Of 2026 | SafeWise
-------------------------------------------

 ![Illinois's Safest Cities of 2026 | SafeWise](https://www.safewise.com/app/uploads/2021/02/Homer-Glen-Illinois-225x225.jpg) <small>www.safewise.com</small>Illinois's Safest Cities of 2026 | SafeWise

Homer Glen Weather Forecast
---------------------------

 ![Homer Glen Weather Forecast](https://www.weather-forecast.com/locationmaps/Homer-Glen.10.gif) <small>www.weather-forecast.com</small>Homer Glen Weather Forecast

Glenview Crime Rates And Statistics - NeighborhoodScout
-------------------------------------------------------

 ![Glenview Crime Rates and Statistics - NeighborhoodScout](https://s3.amazonaws.com/crime-maps-aws.neighborhoodscout.com/glenview-il-crime-map.png) <small>www.neighborhoodscout.com</small>Glenview Crime Rates and Statistics - NeighborhoodScout

Homer Glen Crime Rates And Statistics - NeighborhoodScout
---------------------------------------------------------

 ![Homer Glen Crime Rates and Statistics - NeighborhoodScout](https://s3.amazonaws.com/crime-maps-aws.neighborhoodscout.com/homer-glen-il-crime-map.png) <small>api.locationinc.com</small>Homer Glen Crime Rates and Statistics - NeighborhoodScout

Glenwood, IL, 60425 Crime Rates And Crime Statistics - NeighborhoodScout
------------------------------------------------------------------------

 ![Glenwood, IL, 60425 Crime Rates and Crime Statistics - NeighborhoodScout](https://s3.amazonaws.com/crime-maps-aws.neighborhoodscout.com/glenwood-il-crime-map.png) <small>www.neighborhoodscout.com</small>Glenwood, IL, 60425 Crime Rates and Crime Statistics - NeighborhoodScout

Homer Glen, Illinois (IL 60467, 60491) Profile: Population, Maps, Real
----------------------------------------------------------------------

 ![Homer Glen, Illinois (IL 60467, 60491) profile: population, maps, real](https://pics4.city-data.com/sgraphs/fire/fire-indicent-types-Homer-Glen-IL.png) <small>www.city-data.com</small>Homer Glen, Illinois (IL 60467, 60491) profile: population, maps, real ...

Interactive Hail Maps - Hail Map For Glen Carbon, IL
----------------------------------------------------

 ![Interactive Hail Maps - Hail Map for Glen Carbon, IL](https://s3.amazonaws.com/content.interactivehailmaps.com/radar-images/radar-image-1349766.png) <small>www.interactivehailmaps.com</small>Interactive Hail Maps - Hail Map for Glen Carbon, IL

The Safest And Most Dangerous Places In Homer, IL: Crime Maps And
-----------------------------------------------------------------

 ![The Safest and Most Dangerous Places in Homer, IL: Crime Maps and](https://images.crimegrade.org/map/crime-rate-maps/safest-places-in-homer-il.webp) <small>crimegrade.org</small>The Safest and Most Dangerous Places in Homer, IL: Crime Maps and ...

News Flash • Homer Glen, IL
---------------------------

 ![News Flash • Homer Glen, IL](https://www.homerglenil.org/ImageRepository/Document?documentID=7381) <small>www.homerglenil.org</small>News Flash • Homer Glen, IL

Homer Glen, IL Landscaping From $29 | #1 Landscapers | Best Of 2020
-------------------------------------------------------------------

 ![Homer Glen, IL Landscaping from $29 | #1 Landscapers | Best of 2020](https://www.lawnstarter.com/cdn-cgi/image/width=250,height=250,fit=cover,dpr=1,gravity=center,quality=85,format=auto,onerror=redirect,metadata=keep,/https://s3.amazonaws.com/www.lawnstarter.com/service-area-maps/Homer-Glen-IL-service-area.png) <small>www.lawnstarter.com</small>Homer Glen, IL Landscaping from $29 | #1 Landscapers | Best of 2020

Where Do Homer Glen And Lockport Rank On Safest Towns List? | Homer
-------------------------------------------------------------------

 ![Where Do Homer Glen And Lockport Rank On Safest Towns List? | Homer](https://patch.com/img/cdn20/users/22920555/20180215/125349/styles/raw/public/processed_images/safeest_towns-1518616858-9047-1518717091-5759.jpg) <small>patch.com</small>Where Do Homer Glen And Lockport Rank On Safest Towns List? | Homer ...

Homer Glen Illinois Map: Chicago Suburb Neighborhoods
-----------------------------------------------------

 ![Homer Glen Illinois Map: Chicago Suburb Neighborhoods](http://www.homerglenil.org/ImageRepository/Document?documentID=832) <small>vectormap.info</small>Homer Glen Illinois Map: Chicago Suburb Neighborhoods

Glenwood, il, 60425 crime rates and crime statistics. Homer glen news. Glenwood, il, 60425 crime rates and crime statistics
