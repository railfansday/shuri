---
title: "Lotto Results Lotto Plus 1 And 2 - lotto results lotto plus 1 and 2 today new arrivals"
description: "R54-million payday for lotto and lotto plus 1 and 2 on saturday 28 ..."
date: "2025-12-01"
categories:
- "Uncategorized"
images:
- "https://www.thesouthafrican.com/wp-content/uploads/2026/03/Lotto-and-Lotto-Plus-1-and-2-on-Saturday-14-March-2026_7.jpg.optimal.jpg"
featuredImage: "https://www.techchamp.co.za/wp-content/uploads/2025/11/Lotto-Lotto-Plus-1-and-Lotto-Plus-2-Results-for-Saturday-15-November-2025.jpg"
featured_image: "https://www.techchamp.co.za/wp-content/uploads/2025/12/Lotto-Lotto-Plus-1-Lotto-Plus-2-Results-for-Wednesday-03-December-2025.webp"
image: "https://www.thesouthafrican.com/wp-content/uploads/2026/03/Lotto-and-Lotto-Plus-1-and-2-on-Saturday-14-March-2026_7.jpg.optimal.jpg"
---

If you are looking for Lotto plus 1 plus 2 results online you've visit to the right web. We have 30 Pics about Lotto plus 1 plus 2 results online like Lotto draws: Numbers, results, payouts, winner, ithuba lottery, Lotto plus 1 plus 2 results online and also Lotto and Lotto Plus Results: Winning Numbers. Here you go:

Lotto Plus 1 Plus 2 Results Online
----------------------------------

 ![Lotto plus 1 plus 2 results online](https://pbs.twimg.com/media/EOX9TJlUUAArL9n.png) <small>www.namibian.com.na</small>Lotto plus 1 plus 2 results online

The Lotto And Lotto Plus 1 And 2 Results For Saturday, 23 May 2026
------------------------------------------------------------------

 ![The Lotto and Lotto Plus 1 and 2 results for Saturday, 23 May 2026](https://www.thesouthafrican.com/wp-content/uploads/2025/04/Lotto.jpg.optimal.jpg) <small>www.thesouthafrican.com</small>The Lotto and Lotto Plus 1 and 2 results for Saturday, 23 May 2026

Siya Kolisi Reunites With Zozi Tunzi After THAT Viral Moment
------------------------------------------------------------

 ![Siya Kolisi reunites with Zozi Tunzi after THAT viral moment](https://www.thesouthafrican.com/wp-content/uploads/2026/03/Lotto-and-Lotto-Plus-1-and-2-on-Saturday-7-March-2026_4.jpg.optimal.jpg) <small>www.thesouthafrican.com</small>Siya Kolisi reunites with Zozi Tunzi after THAT viral moment

ITHUBA Confirms Lotto Plus 1 And Lotto Plus 2 Jackpots WON
----------------------------------------------------------

 ![ITHUBA confirms Lotto Plus 1 and Lotto Plus 2 jackpots WON](https://www.thesouthafrican.com/wp-content/uploads/2026/04/Lotto-and-Lotto-Plus-1-and-2-on-Wednesday-8-April-2026_1.jpg.optimal.jpg) <small>www.thesouthafrican.com</small>ITHUBA confirms Lotto Plus 1 and Lotto Plus 2 jackpots WON

Lotto Plus 1 And 2 Online
-------------------------

 ![Lotto plus 1 and 2 online](https://www.magiclotto.co.za/Assets/images/news/DIowyYzVYAEVvhD.jpg) <small>www.namibian.com.na</small>Lotto plus 1 and 2 online

R54-million Payday For Lotto And Lotto Plus 1 And 2 On Saturday 28
------------------------------------------------------------------

 ![R54-million payday for Lotto and Lotto Plus 1 and 2 on Saturday 28](https://www.thesouthafrican.com/wp-content/uploads/2026/02/Lotto-and-Lotto-Plus-1-and-2-on-Saturday-28-February-2026-.jpg.optimal.jpg) <small>www.thesouthafrican.com</small>R54-million payday for Lotto and Lotto Plus 1 and 2 on Saturday 28 ...

Lotto Plus Two 1 July 2026 Wednesday, Results Tonight, South Africa
-------------------------------------------------------------------

 ![Lotto Plus Two 1 July 2026 Wednesday, Results Tonight, South Africa](https://powerball.us.org/images/lottoplustwosa/1.webp) <small>powerball.us.org</small>Lotto Plus Two 1 July 2026 Wednesday, Results Tonight, South Africa

10 Previous Lotto Results Online
--------------------------------

 ![10 previous lotto results online](https://www.saffarazzi.com/wp-content/uploads/2024/01/20240110-wednesday-south-africa-lotto-and-lotto-plus-results.webp) <small>www.namibian.com.na</small>10 previous lotto results online

BAD News For RESET Lotto And Lotto Plus 1 And 2 On Saturday 9 May 2026
----------------------------------------------------------------------

 ![BAD news for RESET Lotto and Lotto Plus 1 and 2 on Saturday 9 May 2026](https://www.thesouthafrican.com/wp-content/uploads/2026/05/Lotto-and-Lotto-Plus-1-and-2-on-Saturday-9-May-2026_2.png) <small>www.thesouthafrican.com</small>BAD news for RESET Lotto and Lotto Plus 1 and 2 on Saturday 9 May 2026

Lotto Plus 1 &amp; 2 Results 15 Nov 2025 | Live SA Numbers
----------------------------------------------------------

 ![Lotto Plus 1 & 2 Results 15 Nov 2025 | Live SA Numbers](https://www.techchamp.co.za/wp-content/uploads/2025/11/Lotto-Lotto-Plus-1-and-Lotto-Plus-2-Results-for-Saturday-15-November-2025.jpg) <small>www.techchamp.co.za</small>Lotto Plus 1 &amp; 2 Results 15 Nov 2025 | Live SA Numbers

Lotto Results And Payouts &amp; Lotto Plus Best Sale | Www.cityofclovis.org
---------------------------------------------------------------------------

 ![Lotto Results And Payouts & Lotto Plus Best Sale | www.cityofclovis.org](https://media.citizen.co.za/wp-content/uploads/2018/12/Screenshot-2018-12-06-at-08.45.46.png) <small>www.cityofclovis.org</small>Lotto Results And Payouts &amp; Lotto Plus Best Sale | www.cityofclovis.org

Youtube Lotto Results Today | Ithuba National Lottery – KGZO
------------------------------------------------------------

 ![Youtube Lotto Results Today | Ithuba National Lottery – KGZO](https://speedraftaar.com/wp-content/uploads/2019/08/Lotto-and-Lotto-Plus-Results.jpg) <small>thetattooedteacher.com</small>Youtube Lotto Results Today | Ithuba National Lottery – KGZO

Lotto Draws: Numbers, Results, Payouts, Winner, Ithuba Lottery
--------------------------------------------------------------

 ![Lotto draws: Numbers, results, payouts, winner, ithuba lottery](https://www.thesouthafrican.com/wp-content/uploads/2024/09/image-1.png) <small>www.thesouthafrican.com</small>Lotto draws: Numbers, results, payouts, winner, ithuba lottery

ITHUBA Confirms Lotto Plus 1 And Lotto Plus 2 Jackpots WON
----------------------------------------------------------

 ![ITHUBA confirms Lotto Plus 1 and Lotto Plus 2 jackpots WON](https://www.thesouthafrican.com/wp-content/uploads/2026/04/image-28.png) <small>www.thesouthafrican.com</small>ITHUBA confirms Lotto Plus 1 and Lotto Plus 2 jackpots WON

R99-million PAYDAY For Lotto And Lotto Plus 1 And 2 On Wednesday 8
------------------------------------------------------------------

 ![R99-million PAYDAY for Lotto and Lotto Plus 1 and 2 on Wednesday 8](https://www.thesouthafrican.com/wp-content/uploads/2026/04/Lotto-and-Lotto-Plus-1-and-2-on-Wednesday-8-April-2026_2.jpg.optimal.jpg) <small>www.thesouthafrican.com</small>R99-million PAYDAY for Lotto and Lotto Plus 1 and 2 on Wednesday 8 ...

R67 Million On LINE For Lotto And Lotto Plus 1 And 2 On Saturday 14
-------------------------------------------------------------------

 ![R67 million on LINE for Lotto and Lotto Plus 1 and 2 on Saturday 14](https://www.thesouthafrican.com/wp-content/uploads/2026/03/Lotto-and-Lotto-Plus-1-and-2-on-Saturday-14-March-2026_7.jpg.optimal.jpg) <small>www.thesouthafrican.com</small>R67 million on LINE for Lotto and Lotto Plus 1 and 2 on Saturday 14 ...

Lotto Plus 2 Results, Prizes For 7 December 2024 (Saturday 07.12.2024)
----------------------------------------------------------------------

 ![Lotto Plus 2 results, Prizes for 7 December 2024 (Saturday 07.12.2024)](https://cdn.africanlottery.net/img/results/lotto-plus-2-results-no-2495.webp) <small>www.africanlottery.net</small>Lotto Plus 2 results, Prizes for 7 December 2024 (Saturday 07.12.2024)

Lotto And Lotto Plus Results: Winning Numbers
---------------------------------------------

 ![Lotto and Lotto Plus Results: Winning Numbers](https://www.thesouthafrican.com/wp-content/uploads/2026/04/Lotto-and-Lotto-Plus-1-and-2-on-Saturday-2-May-2026_4-750x500.jpg.optimal.jpg) <small>www.thesouthafrican.com</small>Lotto and Lotto Plus Results: Winning Numbers

R89-million April FOOL’s For Lotto And Lotto Plus 1 And 2 On Wednesday
----------------------------------------------------------------------

 ![R89-million April FOOL’s for Lotto and Lotto Plus 1 and 2 on Wednesday](https://www.thesouthafrican.com/wp-content/uploads/2026/03/Lotto-and-Lotto-Plus-1-and-2-on-Wednesday-1-April-2026_1.png) <small>www.thesouthafrican.com</small>R89-million April FOOL’s for Lotto and Lotto Plus 1 and 2 on Wednesday ...

Lotto And Lotto Plus Results: Saturday, 4 April 2026 | The Citizen
------------------------------------------------------------------

 ![Lotto and Lotto Plus results: Saturday, 4 April 2026 | The Citizen](https://media.citizen.co.za/wp-content/uploads/2026/04/Screenshot-2026-04-04-210307-1200x617.jpg) <small>www.citizen.co.za</small>Lotto and Lotto Plus results: Saturday, 4 April 2026 | The Citizen

R98 Million UP For Grabs: Lotto And Lotto Plus 1 And 2 On Wednesday 29
----------------------------------------------------------------------

 ![R98 million UP for grabs: Lotto and Lotto Plus 1 and 2 on Wednesday 29](https://www.thesouthafrican.com/wp-content/uploads/2026/04/Lotto-and-Lotto-Plus-1-and-2-on-Wednesday-29-April-2026_1-960x257.png) <small>www.thesouthafrican.com</small>R98 million UP for grabs: Lotto and Lotto Plus 1 and 2 on Wednesday 29 ...

Lotto Plus 1 And Lotto Plus 2 Online
------------------------------------

 ![Lotto plus 1 and lotto plus 2 online](https://media.citizen.co.za/wp-content/uploads/2021/10/LOTTO-PLUS-2-002.jpg) <small>www.namibian.com.na</small>Lotto plus 1 and lotto plus 2 online

Lotto Results Lotto Plus 1 And 2 Today New Arrivals
---------------------------------------------------

 ![Lotto results lotto plus 1 and 2 today new arrivals](https://www.saffarazzi.com/wp-content/uploads/2021/10/lotto-and-lotto-plus-results-saturday-south-africa.webp) <small>pediatrianorte.med.uchile.cl</small>Lotto results lotto plus 1 and 2 today new arrivals

Pin Op LOTTERY
--------------

 ![Pin op LOTTERY](https://i.pinimg.com/736x/b6/4f/3d/b64f3dfa01d82a81dd4fc7e3b3b85094.jpg) <small>www.pinterest.com</small>Pin op LOTTERY

Lotto Results 19 November 2025 – Winning Numbers, Lotto Plus 1 &amp; Plus 2
---------------------------------------------------------------------------

 ![Lotto Results 19 November 2025 – Winning Numbers, Lotto Plus 1 & Plus 2](https://www.techchamp.co.za/wp-content/uploads/2025/12/Lotto-Lotto-Plus-1-Lotto-Plus-2-Results-for-Wednesday-03-December-2025.webp) <small>www.techchamp.co.za</small>Lotto Results 19 November 2025 – Winning Numbers, Lotto Plus 1 &amp; Plus 2 ...

R98 Million UP For Grabs: Lotto And Lotto Plus 1 And 2 On Wednesday 29
----------------------------------------------------------------------

 ![R98 million UP for grabs: Lotto and Lotto Plus 1 and 2 on Wednesday 29](https://www.thesouthafrican.com/wp-content/uploads/2026/04/Lotto-and-Lotto-Plus-1-and-2-on-Wednesday-29-April-2026_1-1200x321.png) <small>www.thesouthafrican.com</small>R98 million UP for grabs: Lotto and Lotto Plus 1 and 2 on Wednesday 29 ...

Lotto Plus 1 Draw #2677 On September 2, 2026 — Results — South Africa
---------------------------------------------------------------------

 ![Lotto Plus 1 Draw #2677 on September 2, 2026 — Results — South Africa](https://statlotto.com/og/za/lotto-plus-1/result.png?locale=en) <small>statlotto.com</small>Lotto Plus 1 Draw #2677 on September 2, 2026 — Results — South Africa

R67 Million On LINE For Lotto And Lotto Plus 1 And 2 On Saturday 14
-------------------------------------------------------------------

 ![R67 million on LINE for Lotto and Lotto Plus 1 and 2 on Saturday 14](https://www.thesouthafrican.com/wp-content/uploads/2026/03/Lotto-and-Lotto-Plus-1-and-2-on-Saturday-14-March-2026_1.jpg.optimal.jpg) <small>www.thesouthafrican.com</small>R67 million on LINE for Lotto and Lotto Plus 1 and 2 on Saturday 14 ...

Lotto, Lotto Plus 1 And Lotto Plus 2 Results For Saturday, 25 October 2025
--------------------------------------------------------------------------

 ![Lotto, Lotto Plus 1 And Lotto Plus 2 Results for Saturday, 25 October 2025](https://www.quickread.co.za/wp-content/uploads/2019/04/Lotto-and-Lotto-Plus-results-1.png) <small>www.quickread.co.za</small>Lotto, Lotto Plus 1 And Lotto Plus 2 Results for Saturday, 25 October 2025

Irish Lotto Results - Numbers In For Saturday February 1 €2m Jackpot
--------------------------------------------------------------------

 ![Irish Lotto results - Numbers in for Saturday February 1 €2m jackpot](https://www.thesun.ie/wp-content/uploads/sites/3/2020/02/LottoSatFeb1.png?strip=all&w=960) <small>www.thesun.ie</small>Irish Lotto results - Numbers in for Saturday February 1 €2m jackpot ...

Ithuba confirms lotto plus 1 and lotto plus 2 jackpots won. R99-million payday for lotto and lotto plus 1 and 2 on wednesday 8. R98 million up for grabs: lotto and lotto plus 1 and 2 on wednesday 29
