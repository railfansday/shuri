---
title: "Lotto Results Lotto Plus 1 And 2 Yesterday - lotto plus 1 and lotto plus 2 online"
description: "Daily lotto result: one lucky winner of thursday&#039;s jackpot payouts"
date: "2025-12-11"
categories:
- "Uncategorized"
images:
- "https://www.thesouthafrican.com/wp-content/uploads/2025/04/Lotto.jpg.optimal.jpg"
featuredImage: "https://lookaside.fbsbx.com/lookaside/crawler/media/?media_id=122242780934048108"
featured_image: "https://media.citizen.co.za/wp-content/uploads/2021/10/LOTTO-PLUS-2-002.jpg"
image: "https://i.pinimg.com/736x/b6/4f/3d/b64f3dfa01d82a81dd4fc7e3b3b85094.jpg"
---

If you are looking for Lotto draws: Numbers, results, payouts, winner, ithuba lottery you've came to the right place. We have 34 Pictures about Lotto draws: Numbers, results, payouts, winner, ithuba lottery like Lotto and lotto plus results for yesterday online, Lotto Results And Payouts &amp; Lotto Plus Best Sale | www.cityofclovis.org and also Lotto Login, Lotto Sign In Guide. Here it is:

Lotto Draws: Numbers, Results, Payouts, Winner, Ithuba Lottery
--------------------------------------------------------------

 ![Lotto draws: Numbers, results, payouts, winner, ithuba lottery](https://www.thesouthafrican.com/wp-content/uploads/2024/09/image-1.png) <small>www.thesouthafrican.com</small>Lotto draws: Numbers, results, payouts, winner, ithuba lottery

Latest - 🇿🇦 SA Lotto, Lotto Plus 1 And Lotto Plus 2 Results On
--------------------------------------------------------------

 ![Latest - 🇿🇦 SA Lotto, Lotto Plus 1 and Lotto Plus 2 Results on](https://lookaside.fbsbx.com/lookaside/crawler/media/?media_id=122242780934048108) <small>www.facebook.com</small>Latest - 🇿🇦 SA Lotto, Lotto Plus 1 and Lotto Plus 2 Results on ...

ITHUBA Confirms Lotto Plus 1 And Lotto Plus 2 Jackpots WON
----------------------------------------------------------

 ![ITHUBA confirms Lotto Plus 1 and Lotto Plus 2 jackpots WON](https://www.thesouthafrican.com/wp-content/uploads/2026/04/image-28.png) <small>www.thesouthafrican.com</small>ITHUBA confirms Lotto Plus 1 and Lotto Plus 2 jackpots WON

R67 Million On LINE For Lotto And Lotto Plus 1 And 2 On Saturday 14
-------------------------------------------------------------------

 ![R67 million on LINE for Lotto and Lotto Plus 1 and 2 on Saturday 14](https://www.thesouthafrican.com/wp-content/uploads/2026/03/Lotto-and-Lotto-Plus-1-and-2-on-Saturday-14-March-2026_5.jpg.optimal.jpg) <small>www.thesouthafrican.com</small>R67 million on LINE for Lotto and Lotto Plus 1 and 2 on Saturday 14 ...

Lotto Plus 1 And 2 Online
-------------------------

 ![Lotto plus 1 and 2 online](https://www.magiclotto.co.za/Assets/images/news/DIowyYzVYAEVvhD.jpg) <small>www.namibian.com.na</small>Lotto plus 1 and 2 online

Lotto And Lotto Plus Results: Winning Numbers
---------------------------------------------

 ![Lotto and Lotto Plus Results: Winning Numbers](https://www.thesouthafrican.com/wp-content/uploads/2026/05/Lotto-and-Lotto-Plus-1-and-2-on-Saturday-16-May-2026_1-640x427.jpg.optimal.jpg) <small>www.thesouthafrican.com</small>Lotto and Lotto Plus Results: Winning Numbers

Lotto Login, Lotto Sign In Guide
--------------------------------

 ![Lotto Login, Lotto Sign In Guide](https://www.quickread.co.za/wp-content/uploads/2025/10/Lotto-Lotto-Plus-1-and-Lotto-Plus-2-Predictions-for-Today-350x350.jpg) <small>www.quickread.co.za</small>Lotto Login, Lotto Sign In Guide

R44.5-million On The Line In Lotto And Lotto Plus 1 And 2 On Saturday
---------------------------------------------------------------------

 ![R44.5-million on the line in Lotto and Lotto Plus 1 and 2 on Saturday](https://www.thesouthafrican.com/wp-content/uploads/2026/02/Lotto-and-Lotto-Plus-1-and-2-on-Saturday-21-February-2026_1.png) <small>www.thesouthafrican.com</small>R44.5-million on the line in Lotto and Lotto Plus 1 and 2 on Saturday ...

R94-million HOLY Saturday For Lotto And Lotto Plus 1 And 2 On Saturday
----------------------------------------------------------------------

 ![R94-million HOLY Saturday for Lotto and Lotto Plus 1 and 2 on Saturday](https://www.thesouthafrican.com/wp-content/uploads/2026/04/Lotto-and-Lotto-Plus-1-and-2-on-Saturday-4-April-2026_4-960x640.jpg.optimal.jpg) <small>www.thesouthafrican.com</small>R94-million HOLY Saturday for Lotto and Lotto Plus 1 and 2 on Saturday ...

Lotto Plus 1 And Lotto Plus 2 Online
------------------------------------

 ![Lotto plus 1 and lotto plus 2 online](https://media.citizen.co.za/wp-content/uploads/2021/10/LOTTO-PLUS-2-002.jpg) <small>www.namibian.com.na</small>Lotto plus 1 and lotto plus 2 online

R54-million Payday For Lotto And Lotto Plus 1 And 2 On Saturday 28
------------------------------------------------------------------

 ![R54-million payday for Lotto and Lotto Plus 1 and 2 on Saturday 28](https://www.thesouthafrican.com/wp-content/uploads/2026/02/Lotto-and-Lotto-Plus-1-and-2-on-Saturday-28-February-2026-.jpg.optimal.jpg) <small>www.thesouthafrican.com</small>R54-million payday for Lotto and Lotto Plus 1 and 2 on Saturday 28 ...

Tonight’s Lotto Results 02 May 2026💰 Lotto, Lotto Plus 1 &amp; Plus 2 - YouTube
-------------------------------------------------------------------------------

 ![Tonight’s Lotto Results 02 May 2026💰 Lotto, Lotto Plus 1 & Plus 2 - YouTube](https://i.ytimg.com/vi/WqZq3sTiu_o/maxresdefault.jpg) <small>www.youtube.com</small>Tonight’s Lotto Results 02 May 2026💰 Lotto, Lotto Plus 1 &amp; Plus 2 - YouTube

Yesterday Lotto Results And Lotto Plus Sales
--------------------------------------------

 ![Yesterday lotto results and lotto plus sales](https://miro.medium.com/v2/resize:fit:497/0*kSXJpcPW0izg9Ffg.png) <small>arquitectura.unam.mx</small>Yesterday lotto results and lotto plus sales

SA Lotto Plus 2 Summary - 2024-01-31
------------------------------------

 ![SA Lotto Plus 2 Summary - 2024-01-31](https://cdn.africanlottery.net/img/results/lotto-plus-2-results-no-2408.webp) <small>www.africanlottery.net</small>SA Lotto Plus 2 Summary - 2024-01-31

Daily Lotto Result: ONE Lucky Winner Of Thursday's Jackpot Payouts
------------------------------------------------------------------

 ![Daily Lotto result: ONE lucky winner of Thursday's jackpot payouts](https://www.thesouthafrican.com/wp-content/uploads/2023/02/09-feb-daily-lotto.jpeg) <small>www.sapeople.com</small>Daily Lotto result: ONE lucky winner of Thursday's jackpot payouts

Lotto Results And Payouts &amp; Lotto Plus Best Sale | Www.cityofclovis.org
---------------------------------------------------------------------------

 ![Lotto Results And Payouts & Lotto Plus Best Sale | www.cityofclovis.org](https://media.citizen.co.za/wp-content/uploads/2018/12/Screenshot-2018-12-06-at-08.45.46.png) <small>www.cityofclovis.org</small>Lotto Results And Payouts &amp; Lotto Plus Best Sale | www.cityofclovis.org

ITHUBA Confirms Lotto Plus 1 And Lotto Plus 2 Jackpots WON
----------------------------------------------------------

 ![ITHUBA confirms Lotto Plus 1 and Lotto Plus 2 jackpots WON](https://www.thesouthafrican.com/wp-content/uploads/2026/04/Lotto-and-Lotto-Plus-1-and-2-on-Wednesday-8-April-2026_1.jpg.optimal.jpg) <small>www.thesouthafrican.com</small>ITHUBA confirms Lotto Plus 1 and Lotto Plus 2 jackpots WON

Daily Lotto And Daily Lotto Plus Results
----------------------------------------

 ![Daily Lotto and Daily Lotto Plus results](https://media.citizen.co.za/wp-content/uploads/2025/12/Screenshot-2025-12-14-210217-1200x717.jpg) <small>www.citizen.co.za</small>Daily Lotto and Daily Lotto Plus results

Lotto And Lotto Plus Results: Winning Numbers
---------------------------------------------

 ![Lotto and Lotto Plus Results: Winning Numbers](https://www.thesouthafrican.com/wp-content/uploads/2026/04/Lotto-and-Lotto-Plus-1-and-2-on-Saturday-2-May-2026_4-750x500.jpg.optimal.jpg) <small>www.thesouthafrican.com</small>Lotto and Lotto Plus Results: Winning Numbers

Lotto And Lotto Plus Results For Yesterday Online
-------------------------------------------------

 ![Lotto and lotto plus results for yesterday online](https://i.pinimg.com/736x/b6/4f/3d/b64f3dfa01d82a81dd4fc7e3b3b85094.jpg) <small>www.namibian.com.na</small>Lotto and lotto plus results for yesterday online

R98 Million UP For Grabs: Lotto And Lotto Plus 1 And 2 On Wednesday 29
----------------------------------------------------------------------

 ![R98 million UP for grabs: Lotto and Lotto Plus 1 and 2 on Wednesday 29](https://www.thesouthafrican.com/wp-content/uploads/2026/04/Lotto-and-Lotto-Plus-1-and-2-on-Wednesday-29-April-2026_1-1200x321.png) <small>www.thesouthafrican.com</small>R98 million UP for grabs: Lotto and Lotto Plus 1 and 2 on Wednesday 29 ...

Anele Mdoda’s Husband Mgudlwa Breaks Silence Amid PPE Claims
------------------------------------------------------------

 ![Anele Mdoda’s husband Mgudlwa breaks silence amid PPE claims](https://www.thesouthafrican.com/wp-content/uploads/2025/04/Lotto.jpg.optimal.jpg) <small>www.thesouthafrican.com</small>Anele Mdoda’s husband Mgudlwa breaks silence amid PPE claims

R54-million Payday For Lotto And Lotto Plus 1 And 2 On Saturday 28
------------------------------------------------------------------

 ![R54-million payday for Lotto and Lotto Plus 1 and 2 on Saturday 28](https://www.thesouthafrican.com/wp-content/uploads/2026/02/Lotto-and-Lotto-Plus-1-and-2-on-Saturday-28-February-2026-.png) <small>www.thesouthafrican.com</small>R54-million payday for Lotto and Lotto Plus 1 and 2 on Saturday 28 ...

The Lotto And Lotto Plus 1 And 2 Results For Wednesday, 1 April 2026
--------------------------------------------------------------------

 ![The Lotto and Lotto Plus 1 and 2 results for Wednesday, 1 April 2026](https://miro.medium.com/v2/resize:fit:1358/1*8hsJQ8wmznkNEyY8GjNt6w.png) <small>www.afghanistanwatch.com</small>The Lotto and Lotto Plus 1 and 2 results for Wednesday, 1 April 2026 ...

Ithuba National Lottery Lotto Plus 2 Results
--------------------------------------------

 ![Ithuba National Lottery Lotto Plus 2 Results](https://www.gidblog.com/wp-content/uploads/2020/06/ss.gidapp.za_.lottop2.mobile.png) <small>www.gidblog.com</small>Ithuba National Lottery Lotto Plus 2 Results

GoalRush - 24 January 2026 RSA Lotto Results Saturday Here Are The
------------------------------------------------------------------

 ![GoalRush - 24 January 2026 RSA Lotto Results Saturday Here are the](https://lookaside.fbsbx.com/lookaside/crawler/media/?media_id=1490848349708193) <small>www.facebook.com</small>GoalRush - 24 January 2026 RSA Lotto Results Saturday Here are the ...

10 Previous Lotto Results Online
--------------------------------

 ![10 previous lotto results online](https://www.saffarazzi.com/wp-content/uploads/2024/01/20240110-wednesday-south-africa-lotto-and-lotto-plus-results.webp) <small>www.namibian.com.na</small>10 previous lotto results online

R89-million April FOOL’s For Lotto And Lotto Plus 1 And 2 On Wednesday
----------------------------------------------------------------------

 ![R89-million April FOOL’s for Lotto and Lotto Plus 1 and 2 on Wednesday](https://www.thesouthafrican.com/wp-content/uploads/2026/03/Lotto-and-Lotto-Plus-1-and-2-on-Wednesday-1-April-2026_1.png) <small>www.thesouthafrican.com</small>R89-million April FOOL’s for Lotto and Lotto Plus 1 and 2 on Wednesday ...

Lotto Plus 1 Plus 2 Results Online
----------------------------------

 ![Lotto plus 1 plus 2 results online](https://pbs.twimg.com/media/EOX9TJlUUAArL9n.png) <small>www.namibian.com.na</small>Lotto plus 1 plus 2 results online

Lotto Plus 1 &amp; 2 Results 15 Nov 2025 | Live SA Numbers
----------------------------------------------------------

 ![Lotto Plus 1 & 2 Results 15 Nov 2025 | Live SA Numbers](https://www.techchamp.co.za/wp-content/uploads/2025/11/Lotto-Lotto-Plus-1-Lotto-Plus-2-Results-for-Saturday-29-November-2025.webp) <small>www.techchamp.co.za</small>Lotto Plus 1 &amp; 2 Results 15 Nov 2025 | Live SA Numbers

Lotto Results Lotto Plus 1 And 2 Today New Arrivals
---------------------------------------------------

 ![Lotto results lotto plus 1 and 2 today new arrivals](https://www.saffarazzi.com/wp-content/uploads/2021/10/lotto-and-lotto-plus-results-saturday-south-africa.webp) <small>pediatrianorte.med.uchile.cl</small>Lotto results lotto plus 1 and 2 today new arrivals

BAD News For RESET Lotto And Lotto Plus 1 And 2 On Saturday 9 May 2026
----------------------------------------------------------------------

 ![BAD news for RESET Lotto and Lotto Plus 1 and 2 on Saturday 9 May 2026](https://www.thesouthafrican.com/wp-content/uploads/2026/05/Lotto-and-Lotto-Plus-1-and-2-on-Saturday-9-May-2026_2.png) <small>www.thesouthafrican.com</small>BAD news for RESET Lotto and Lotto Plus 1 and 2 on Saturday 9 May 2026

Lotto And Lotto Plus Results: Saturday, 2 September 2023 | The Citizen
----------------------------------------------------------------------

 ![Lotto and Lotto Plus results: Saturday, 2 September 2023 | The Citizen](https://media.citizen.co.za/wp-content/uploads/2023/08/lotto-plus-results-wednesday-6-august-2023.jpg) <small>www.citizen.co.za</small>Lotto and Lotto Plus results: Saturday, 2 September 2023 | The Citizen

R98 Million UP For Grabs: Lotto And Lotto Plus 1 And 2 On Wednesday 29
----------------------------------------------------------------------

 ![R98 million UP for grabs: Lotto and Lotto Plus 1 and 2 on Wednesday 29](https://www.thesouthafrican.com/wp-content/uploads/2026/04/Lotto-and-Lotto-Plus-1-and-2-on-Wednesday-29-April-2026_1-960x257.png) <small>www.thesouthafrican.com</small>R98 million UP for grabs: Lotto and Lotto Plus 1 and 2 on Wednesday 29 ...

Lotto plus 1 and lotto plus 2 online. Ithuba national lottery lotto plus 2 results. lotto draws: numbers, results, payouts, winner, ithuba lottery
