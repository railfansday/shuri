---
title: "Crime Map Houston - Far northeast-houston, houston, tx violent crime rates and maps"
description: "East end, houston, tx violent crime rates and maps"
date: "2026-04-19"
categories:
- "Uncategorized"
images:
- "https://images.crimegrade.org/map/overall-total/total-crime-map-houston-tx.webp"
featuredImage: "https://images.crimegrade.org/map/overall-total/total-crime-map-central-southwest-houston-tx.webp"
featured_image: "https://s3.amazonaws.com/crime-maps-aws.neighborhoodscout.com/houston-tx-crime-map.png"
image: "https://images.crimegrade.org/map/crime-rate-maps/safest-places-in-greater-memorial-houston-tx.webp"
---

If you are searching about East Houston, Houston, TX Violent Crime Rates and Maps | CrimeGrade.org you've came to the right page. We have 35 Pics about East Houston, Houston, TX Violent Crime Rates and Maps | CrimeGrade.org like The Safest and Most Dangerous Places in Houston, TX: Crime Maps and, Houston, TX Crime Rates and Statistics - NeighborhoodScout and also The Safest and Most Dangerous Places in Brays Oaks, Houston, TX: Crime. Here you go:

East Houston, Houston, TX Violent Crime Rates And Maps | CrimeGrade.org
-----------------------------------------------------------------------

 ![East Houston, Houston, TX Violent Crime Rates and Maps | CrimeGrade.org](https://images.crimegrade.org/map/violence-total/violent-crime-total-map-east-houston-houston-tx.webp) <small>crimegrade.org</small>East Houston, Houston, TX Violent Crime Rates and Maps | CrimeGrade.org

The Safest And Most Dangerous Places In Washington Avenue-Memorial Park
-----------------------------------------------------------------------

 ![The Safest and Most Dangerous Places in Washington Avenue-Memorial Park](https://images.crimegrade.org/map/overall-total/total-crime-map-washington-avenue-memorial-park-houston-tx.webp) <small>crimegrade.org</small>The Safest and Most Dangerous Places in Washington Avenue-Memorial Park ...

Houston Crime Statistics 2020 – Police-reported Crime Rates, Canada
-------------------------------------------------------------------

 ![Houston Crime Statistics 2020 – Police-reported crime rates, Canada](https://cdn.abcotvs.com/dip/images/7197177_102020-ktrk-houston-anti-crime-map-img.jpg) <small>milepost38modeltrains.com</small>Houston Crime Statistics 2020 – Police-reported crime rates, Canada ...

The Safest And Most Dangerous Places In Central Southwest, Houston, TX
----------------------------------------------------------------------

 ![The Safest and Most Dangerous Places in Central Southwest, Houston, TX](https://images.crimegrade.org/map/overall-total/total-crime-map-central-southwest-houston-tx.webp) <small>crimegrade.org</small>The Safest and Most Dangerous Places in Central Southwest, Houston, TX ...

The Safest And Most Dangerous Places In Galleria-Uptown, Houston, TX
--------------------------------------------------------------------

 ![The Safest and Most Dangerous Places in Galleria-Uptown, Houston, TX](https://images.crimegrade.org/map/overall-total/total-crime-map-galleria-uptown-houston-tx.webp) <small>crimegrade.org</small>The Safest and Most Dangerous Places in Galleria-Uptown, Houston, TX ...

The Safest And Most Dangerous Places In Greater Heights, Houston, TX
--------------------------------------------------------------------

 ![The Safest and Most Dangerous Places in Greater Heights, Houston, TX](https://images.crimegrade.org/map/crime-rate-maps/safest-places-in-greater-heights-houston-tx.webp) <small>crimegrade.org</small>The Safest and Most Dangerous Places in Greater Heights, Houston, TX ...

Macgregor Houston Crime At David Delarosa Blog
----------------------------------------------

 ![Macgregor Houston Crime at David Delarosa blog](https://media.khou.com/assets/KHOU/images/a95b9979-aec8-4c9f-9dc5-3a8a02049aee/a95b9979-aec8-4c9f-9dc5-3a8a02049aee_1140x641.jpg) <small>storage.googleapis.com</small>Macgregor Houston Crime at David Delarosa blog

Greater Fifth Ward, Houston, TX Violent Crime Rates And Maps
------------------------------------------------------------

 ![Greater Fifth Ward, Houston, TX Violent Crime Rates and Maps](https://images.crimegrade.org/map/violence-total/violent-crime-total-map-greater-fifth-ward-houston-tx.webp) <small>crimegrade.org</small>Greater Fifth Ward, Houston, TX Violent Crime Rates and Maps ...

Houston Crime Map - GIS Geography
---------------------------------

 ![Houston Crime Map - GIS Geography](https://gisgeography.com/wp-content/uploads/2023/07/Houston-Downtown-Crime-Map-1536x1536.jpg) <small>gisgeography.com</small>Houston Crime Map - GIS Geography

Houston, TX Crime Rates And Statistics - NeighborhoodScout
----------------------------------------------------------

 ![Houston, TX Crime Rates and Statistics - NeighborhoodScout](https://s3.amazonaws.com/crime-maps-aws.neighborhoodscout.com/houston-tx-crime-map.png) <small>www.neighborhoodscout.com</small>Houston, TX Crime Rates and Statistics - NeighborhoodScout

Houston Crime Rate 👮‍♂️ \[2025\] | Is Houston Safe?
---------------------------------------------------

 ![Houston Crime Rate 👮‍♂️ [2025] | Is Houston Safe?](https://pdxmovers.com/wp-content/uploads/2024/12/Screenshot-2024-12-17-at-7.35.02 PM-1024x580.png) <small>pdxmovers.com</small>Houston Crime Rate 👮‍♂️ \[2025\] | Is Houston Safe?

Acres Home, Houston, TX Violent Crime Rates And Maps | CrimeGrade.org
---------------------------------------------------------------------

 ![Acres Home, Houston, TX Violent Crime Rates and Maps | CrimeGrade.org](https://images.crimegrade.org/map/violence-total/violent-crime-total-map-acres-home-houston-tx.webp) <small>crimegrade.org</small>Acres Home, Houston, TX Violent Crime Rates and Maps | CrimeGrade.org

East End, Houston, TX Violent Crime Rates And Maps | CrimeGrade.org
-------------------------------------------------------------------

 ![East End, Houston, TX Violent Crime Rates and Maps | CrimeGrade.org](https://images.crimegrade.org/map/violence-rates/violent-crime-per-capita-map-east-end-houston-tx.webp) <small>crimegrade.org</small>East End, Houston, TX Violent Crime Rates and Maps | CrimeGrade.org

Crime Statistics By Zip Code Houston | Explora Madeira
------------------------------------------------------

 ![Crime Statistics By Zip Code Houston | Explora Madeira](https://www.movebuddha.com/wp-content/uploads/2018/08/Houston_Crime_Map.jpg) <small>www.exploramadeira.com</small>Crime Statistics By Zip Code Houston | Explora Madeira

The Safest And Most Dangerous Places In Southeast, Houston, TX: Crime
---------------------------------------------------------------------

 ![The Safest and Most Dangerous Places in Southeast, Houston, TX: Crime](https://images.crimegrade.org/map/crime-rate-maps/safest-places-in-southeast-houston-tx.webp) <small>crimegrade.org</small>The Safest and Most Dangerous Places in Southeast, Houston, TX: Crime ...

The Safest And Most Dangerous Places In Greater Fifth Ward, Houston, TX
-----------------------------------------------------------------------

 ![The Safest and Most Dangerous Places in Greater Fifth Ward, Houston, TX](https://images.crimegrade.org/map/crime-rate-maps/safest-places-in-greater-fifth-ward-houston-tx.webp) <small>crimegrade.org</small>The Safest and Most Dangerous Places in Greater Fifth Ward, Houston, TX ...

The Safest And Most Dangerous Places In Southbelt Ellington, Houston
--------------------------------------------------------------------

 ![The Safest and Most Dangerous Places in Southbelt Ellington, Houston](https://images.crimegrade.org/map/crime-rate-maps/safest-places-in-southbelt-ellington-houston-tx.webp) <small>crimegrade.org</small>The Safest and Most Dangerous Places in Southbelt Ellington, Houston ...

The Safest And Most Dangerous Places In Houston, TX: Crime Maps And
-------------------------------------------------------------------

 ![The Safest and Most Dangerous Places in Houston, TX: Crime Maps and](https://images.crimegrade.org/map/overall-total/total-crime-map-houston-tx.webp) <small>crimegrade.org</small>The Safest and Most Dangerous Places in Houston, TX: Crime Maps and ...

The Safest And Most Dangerous Places In Brays Oaks, Houston, TX: Crime
----------------------------------------------------------------------

 ![The Safest and Most Dangerous Places in Brays Oaks, Houston, TX: Crime](https://images.crimegrade.org/map/overall-total/total-crime-map-brays-oaks-houston-tx.webp) <small>crimegrade.org</small>The Safest and Most Dangerous Places in Brays Oaks, Houston, TX: Crime ...

Houston Crime Map - GIS Geography
---------------------------------

 ![Houston Crime Map - GIS Geography](https://gisgeography.com/wp-content/uploads/2023/07/Houston-Crime-Map-2048x1821.jpg) <small>gisgeography.com</small>Houston Crime Map - GIS Geography

The Safest And Most Dangerous Places In Houston County, GA: Crime Maps
----------------------------------------------------------------------

 ![The Safest and Most Dangerous Places in Houston County, GA: Crime Maps](https://images.crimegrade.org/map/crime-rate-maps/safest-places-in-houston-county-ga.webp) <small>crimegrade.org</small>The Safest and Most Dangerous Places in Houston County, GA: Crime Maps ...

Best Places To Live In Texas Low Crime At Bella Bright Blog
-----------------------------------------------------------

 ![Best Places To Live In Texas Low Crime at Bella Bright blog](https://secretmuseum.net/wp-content/uploads/2019/06/houston-texas-crime-map-houston-gang-map-crime-map-houston-smartsync-travel-maps-and-of-houston-texas-crime-map.jpg) <small>storage.googleapis.com</small>Best Places To Live In Texas Low Crime at Bella Bright blog

SpotCrime - The Public's Crime Map: Houston Crime Map New Data And
------------------------------------------------------------------

 ![SpotCrime - The Public's Crime Map: Houston Crime Map New Data and](http://1.bp.blogspot.com/_ZSuJiQ9ztA8/SmTEqx2T6bI/AAAAAAAABl0/ahY5n7d3A0c/s320/Houston+heat+map.jpg) <small>blog.spotcrime.com</small>SpotCrime - The Public's Crime Map: Houston Crime Map New Data and ...

The Safest And Most Dangerous Places In North, Houston, TX: Crime Maps
----------------------------------------------------------------------

 ![The Safest and Most Dangerous Places in North, Houston, TX: Crime Maps](https://images.crimegrade.org/map/overall-total/total-crime-map-north-houston-tx.webp) <small>crimegrade.org</small>The Safest and Most Dangerous Places in North, Houston, TX: Crime Maps ...

HPD Interactive Recent Crime Map
--------------------------------

 ![HPD Interactive Recent Crime Map](http://files.ctctcdn.com/89c3ff9d101/c14fb913-abfc-48a3-a69b-fa63e2560b9a.jpg?a=1123438326774) <small>archive.constantcontact.com</small>HPD Interactive Recent Crime Map

The Safest And Most Dangerous Places In Greater Memorial, Houston, TX
---------------------------------------------------------------------

 ![The Safest and Most Dangerous Places in Greater Memorial, Houston, TX](https://images.crimegrade.org/map/crime-rate-maps/safest-places-in-greater-memorial-houston-tx.webp) <small>crimegrade.org</small>The Safest and Most Dangerous Places in Greater Memorial, Houston, TX ...

Community Crime Map Hosted By LexisNexis.com
--------------------------------------------

 ![Community Crime Map hosted by LexisNexis.com](https://www.houstontx.gov/police/images/Community_Crime_Map.png) <small>www.houstontx.gov</small>Community Crime Map hosted by LexisNexis.com

Downtown Houston, Houston, TX Violent Crime Rates And Maps | CrimeGrade.org
---------------------------------------------------------------------------

 ![Downtown Houston, Houston, TX Violent Crime Rates and Maps | CrimeGrade.org](https://images.crimegrade.org/map/violence-total/violent-crime-total-map-downtown-houston-houston-tx.webp) <small>crimegrade.org</small>Downtown Houston, Houston, TX Violent Crime Rates and Maps | CrimeGrade.org

The Safest And Most Dangerous Places In Terra Del Sol, Houston, TX
------------------------------------------------------------------

 ![The Safest and Most Dangerous Places in Terra del Sol, Houston, TX](https://images.crimegrade.org/map/crime-rate-maps/safest-places-in-terra-del-sol-houston-tx.webp) <small>crimegrade.org</small>The Safest and Most Dangerous Places in Terra del Sol, Houston, TX ...

Houston Crime Map - GIS Geography
---------------------------------

 ![Houston Crime Map - GIS Geography](https://gisgeography.com/wp-content/uploads/2023/11/Houston-Crime-Map-425x425.jpg) <small>gisgeography.com</small>Houston Crime Map - GIS Geography

Houston, TX Property Crime Rates And Maps | CrimeGrade.org
----------------------------------------------------------

 ![Houston, TX Property Crime Rates and Maps | CrimeGrade.org](https://images.crimegrade.org/map/property-rates/property-crime-per-capita-map-houston-tx.webp) <small>crimegrade.org</small>Houston, TX Property Crime Rates and Maps | CrimeGrade.org

Southeast, Houston, TX Violent Crime Rates And Maps | CrimeGrade.org
--------------------------------------------------------------------

 ![Southeast, Houston, TX Violent Crime Rates and Maps | CrimeGrade.org](https://images.crimegrade.org/map/violence-total/violent-crime-total-map-southeast-houston-tx.webp) <small>crimegrade.org</small>Southeast, Houston, TX Violent Crime Rates and Maps | CrimeGrade.org

Far Northeast-Houston, Houston, TX Violent Crime Rates And Maps
---------------------------------------------------------------

 ![Far Northeast-Houston, Houston, TX Violent Crime Rates and Maps](https://images.crimegrade.org/map/violence-total/violent-crime-total-map-far-northeast-houston-houston-tx.webp) <small>crimegrade.org</small>Far Northeast-Houston, Houston, TX Violent Crime Rates and Maps ...

The Safest And Most Dangerous Places In Houston, TX: Crime Maps And
-------------------------------------------------------------------

 ![The Safest and Most Dangerous Places in Houston, TX: Crime Maps and](https://images.crimegrade.org/map/crime-rate-maps/safest-places-in-houston-tx.webp) <small>crimegrade.org</small>The Safest and Most Dangerous Places in Houston, TX: Crime Maps and ...

The Safest And Most Dangerous Places In East End, Houston, TX: Crime
--------------------------------------------------------------------

 ![The Safest and Most Dangerous Places in East End, Houston, TX: Crime](https://images.crimegrade.org/map/overall-total/total-crime-map-east-end-houston-tx.webp) <small>crimegrade.org</small>The Safest and Most Dangerous Places in East End, Houston, TX: Crime ...

The safest and most dangerous places in houston county, ga: crime maps. Houston crime rate 👮‍♂️ \[2025\]. Hpd interactive recent crime map
