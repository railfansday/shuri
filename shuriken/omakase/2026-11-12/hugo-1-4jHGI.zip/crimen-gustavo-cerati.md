---
title: "Crimen Gustavo Cerati - Salta la banca"
description: "Cifra club"
date: "2025-12-31"
categories:
- "Uncategorized"
images:
- "https://is1-ssl.mzstatic.com/image/thumb/Video128/v4/53/64/a8/5364a8da-8228-f618-cb1f-bdb39197e6fb/SonyBMG.363462254.00000000000009784992.CROPPED.mzi.fykaydgm.jpg/1200x630mv.jpg"
featuredImage: "https://i.ytimg.com/vi/N5qktY6AyrI/maxresdefault.jpg?sqp=-oaymwEmCIAKENAF8quKqQMa8AEB-AH-CYAC0AWKAgwIABABGGUgWyhZMA8=&amp;rs=AOn4CLDlizahuA_TE6iS-3Rn5IG0HvG9fg"
featured_image: "https://i.genius.com/d3023858ff954d71da0728eb6e7356c842123d53?url=https:%2F%2Fcdn-3.expansion.mx%2Fdims4%2Fdefault%2F52a035a%2F2147483647%2Fstrip%2Ftrue%2Fcrop%2F362x217%2B0%2B0%2Fresize%2F1200x719!%2Fquality%2F90%2F%3Furl%3Dhttps%253A%252F%252Fcherry-brightspot.s3.amazonaws.com%252Fmedia%252F2014%252F09%252F04%252Fcerati_2.jpg"
image: "https://i.ytimg.com/vi/TBkoT3pDeAQ/maxresdefault.jpg"
---

If you are searching about Gustavo Cerati - Crimen (Letra/Lyrics) - YouTube you've came to the right page. We have 35 Pictures about Gustavo Cerati - Crimen (Letra/Lyrics) - YouTube like Gustavo Cerati – Crimen Lyrics | Genius Lyrics, Gustavo Cerati "feat" Jorge Marino - crimen - YouTube and also Crimen (Gustavo Cerati) | Café contado. Here you go:

Gustavo Cerati - Crimen (Letra/Lyrics) - YouTube
------------------------------------------------

 ![Gustavo Cerati - Crimen (Letra/Lyrics) - YouTube](https://i.ytimg.com/vi/lPYaPM4-SYg/maxresdefault.jpg) <small>www.youtube.com</small>Gustavo Cerati - Crimen (Letra/Lyrics) - YouTube

‎Crimen - Music Video By Gustavo Cerati - Apple Music
-----------------------------------------------------

 ![‎Crimen - Music Video by Gustavo Cerati - Apple Music](https://is1-ssl.mzstatic.com/image/thumb/Video128/v4/53/64/a8/5364a8da-8228-f618-cb1f-bdb39197e6fb/SonyBMG.363462254.00000000000009784992.CROPPED.mzi.fykaydgm.jpg/1200x630mv.jpg) <small>music.apple.com</small>‎Crimen - Music Video by Gustavo Cerati - Apple Music

Crimen - Gustavo Cerati - YouTube
---------------------------------

 ![Crimen - Gustavo Cerati - YouTube](https://i.ytimg.com/vi/fDtKFDPJAgg/maxresdefault.jpg) <small>www.youtube.com</small>Crimen - Gustavo Cerati - YouTube

Crimen | Cerati Crimen, Fantasma Cerati, Gustavo Cerati Frases De Canciones
---------------------------------------------------------------------------

 ![Crimen | Cerati crimen, Fantasma cerati, Gustavo cerati frases de canciones](https://i.pinimg.com/736x/08/01/e4/0801e4a1857d43b22473e3d27234de6e.jpg) <small>www.pinterest.com</small>Crimen | Cerati crimen, Fantasma cerati, Gustavo cerati frases de canciones

Gustavo Cerati Acordes - Crimen Acordes Guitarra Letra Gustavo Cerati
---------------------------------------------------------------------

 ![Gustavo Cerati Acordes - Crimen Acordes Guitarra Letra Gustavo Cerati](https://s2.studylib.es/store/data/008791385_1-2f84944d515fedc10309c55ea1272e91.png) <small>rabbinicaljourney.blogspot.com</small>Gustavo Cerati Acordes - Crimen Acordes Guitarra Letra Gustavo Cerati ...

Crimen (Gustavo Cerati) | Café Contado
--------------------------------------

 ![Crimen (Gustavo Cerati) | Café contado](http://img.youtube.com/vi/tK0y3fDhSIg/0.jpg) <small>cafecontado.com</small>Crimen (Gustavo Cerati) | Café contado

Gustavo Cerati - Crimen \[MuchMusic\] \[1080p\] - YouTube
---------------------------------------------------------

 ![Gustavo Cerati - Crimen [MuchMusic] [1080p] - YouTube](https://i.ytimg.com/vi/FmFfvSxeYJI/maxresdefault.jpg) <small>www.youtube.com</small>Gustavo Cerati - Crimen \[MuchMusic\] \[1080p\] - YouTube

Gustavo Cerati – Crimen Lyrics | Genius Lyrics
----------------------------------------------

 ![Gustavo Cerati – Crimen Lyrics | Genius Lyrics](https://i.genius.com/d3023858ff954d71da0728eb6e7356c842123d53?url=https:%2F%2Fcdn-3.expansion.mx%2Fdims4%2Fdefault%2F52a035a%2F2147483647%2Fstrip%2Ftrue%2Fcrop%2F362x217%2B0%2B0%2Fresize%2F1200x719!%2Fquality%2F90%2F%3Furl%3Dhttps%253A%252F%252Fcherry-brightspot.s3.amazonaws.com%252Fmedia%252F2014%252F09%252F04%252Fcerati_2.jpg) <small>genius.com</small>Gustavo Cerati – Crimen Lyrics | Genius Lyrics

Crimen En La Casa Vecina Donde Vivió Gustavo Cerati: Piden Buscar Más
---------------------------------------------------------------------

 ![Crimen en la casa vecina donde vivió Gustavo Cerati: piden buscar más](https://media.lmneuquen.com/p/0530c7d96d0bc765b2cd61bf030d5728/adjuntos/195/imagenes/007/982/0007982713/1200x675/smart/vicitma-cerati.jpg) <small>www.lmneuquen.com</small>Crimen en la casa vecina donde vivió Gustavo Cerati: piden buscar más ...

Gustavo Cerati - Crimen - YouTube
---------------------------------

 ![Gustavo Cerati - Crimen - YouTube](https://i.ytimg.com/vi/oHGnxHfQ4IM/hqdefault.jpg?sqp=-oaymwEmCOADEOgC8quKqQMa8AEB-AH-BIAC4AOKAgwIABABGGUgSShIMA8=&rs=AOn4CLB2Zt4G0Q35Kq3TzyixKykiplsL0g) <small>www.youtube.com</small>Gustavo Cerati - Crimen - YouTube

Crimen Llega A Paraná Con Un Viaje Musical Por La Obra De Gustavo Cerati
------------------------------------------------------------------------

 ![Crimen llega a Paraná con un viaje musical por la obra de Gustavo Cerati](https://media.lacapital.com.ar/p/130099e08c4321ec01bd041131bd67a5/adjuntos/205/imagenes/102/680/0102680164/crimen-gustavo-cerati.jpg) <small>www.unoentrerios.com.ar</small>Crimen llega a Paraná con un viaje musical por la obra de Gustavo Cerati

Cifra Club - Gustavo Cerati - Crimen | PDF
------------------------------------------

 ![Cifra Club - Gustavo Cerati - Crimen | PDF](https://imgv2-1-f.scribdassets.com/img/document/779867571/original/361828e0c2/1?v=1) <small>www.scribd.com</small>Cifra Club - Gustavo Cerati - Crimen | PDF

Gustavo Cerati - Crimen (Lyric Video) - YouTube
-----------------------------------------------

 ![Gustavo Cerati - Crimen (Lyric Video) - YouTube](https://i.ytimg.com/vi/PAmWdwJVQQY/maxresdefault.jpg) <small>www.youtube.com</small>Gustavo Cerati - Crimen (Lyric Video) - YouTube

Gustavo Cerati "feat" Jorge Marino - Crimen - YouTube
-----------------------------------------------------

 ![Gustavo Cerati "feat" Jorge Marino - crimen - YouTube](https://i.ytimg.com/vi/wWgszeXuoaA/maxresdefault.jpg) <small>www.youtube.com</small>Gustavo Cerati "feat" Jorge Marino - crimen - YouTube

Crimen – Gustavo Cerati | Piano Para Cantar 🎹 - YouTube
-------------------------------------------------------

 ![Crimen – Gustavo Cerati | Piano para cantar 🎹 - YouTube](https://i.ytimg.com/vi/A9rz4sUeHng/maxresdefault.jpg) <small>www.youtube.com</small>Crimen – Gustavo Cerati | Piano para cantar 🎹 - YouTube

Crimen / Gustavo Cerati #cover #guitarra - YouTube
--------------------------------------------------

 ![crimen / Gustavo Cerati #cover #guitarra - YouTube](https://i.ytimg.com/vi/n3zS3oBBmgM/maxresdefault.jpg) <small>www.youtube.com</small>crimen / Gustavo Cerati #cover #guitarra - YouTube

Crimen - Gustavo Cerati Sheet Music For Piano, Flute, Clarinet In B
-------------------------------------------------------------------

 ![Crimen - Gustavo Cerati Sheet Music for Piano, Flute, Clarinet in b](https://cdn.ustatik.com/musescore/scoredata/g/16189d52a8189b0addaa5570bce70d38ab57e5e5/score_0.png@300x420?no-cache=1715707745&bgclr=ffffff&fmt=webp&qlt=80) <small>musescore.com</small>Crimen - Gustavo Cerati Sheet Music for Piano, Flute, Clarinet in b ...

Crimen - Gustavo Cerati | Piano Cover + Partitura Gratis / Free Sheet
---------------------------------------------------------------------

 ![Crimen - Gustavo Cerati | Piano Cover + Partitura Gratis / Free Sheet](https://i.ytimg.com/vi/N5qktY6AyrI/maxresdefault.jpg?sqp=-oaymwEmCIAKENAF8quKqQMa8AEB-AH-CYAC0AWKAgwIABABGGUgWyhZMA8=&rs=AOn4CLDlizahuA_TE6iS-3Rn5IG0HvG9fg) <small>www.youtube.com</small>Crimen - Gustavo Cerati | Piano Cover + Partitura Gratis / Free Sheet ...

CRIMEN | GUSTAVO CERATI| CANCIÓN FÁCIL PARA PIANO | TUTORIAL| Karaoke
---------------------------------------------------------------------

 ![CRIMEN | GUSTAVO CERATI| CANCIÓN FÁCIL PARA PIANO | TUTORIAL| Karaoke](https://i.ytimg.com/vi/HcmDw419IwE/maxresdefault.jpg) <small>www.youtube.com</small>CRIMEN | GUSTAVO CERATI| CANCIÓN FÁCIL PARA PIANO | TUTORIAL| Karaoke ...

Crimen - Gustavo Cerati (Sax Cover) (-.Hetziel G.) - YouTube
------------------------------------------------------------

 ![Crimen - Gustavo Cerati (Sax Cover) (-.Hetziel G.) - YouTube](https://i.ytimg.com/vi/q9E4_uE3Mfg/maxresdefault.jpg) <small>www.youtube.com</small>Crimen - Gustavo Cerati (Sax Cover) (-.Hetziel G.) - YouTube

Crimen, Una Letra De Gustavo Cerati - Rock.com.ar
-------------------------------------------------

 ![Crimen, una letra de Gustavo Cerati - Rock.com.ar](https://cdn.rock.com.ar/wp-content/uploads/2023/11/cerati-7.jpg) <small>rock.com.ar</small>Crimen, una letra de Gustavo Cerati - Rock.com.ar

Crimen - Gustavo Cerati - Piano Fácil Tutorial - YouTube
--------------------------------------------------------

 ![Crimen - Gustavo Cerati - Piano Fácil Tutorial - YouTube](https://i.ytimg.com/vi/OXmS2ZP5ieA/maxresdefault.jpg) <small>www.youtube.com</small>Crimen - Gustavo Cerati - Piano Fácil Tutorial - YouTube

Como Tocar "Crimen" (Gustavo Cerati) - Parte 3/3 - Final - YouTube
------------------------------------------------------------------

 ![Como tocar "Crimen" (Gustavo Cerati) - Parte 3/3 - Final - YouTube](https://i.ytimg.com/vi/imF3PEs88dA/maxresdefault.jpg) <small>www.youtube.com</small>Como tocar "Crimen" (Gustavo Cerati) - Parte 3/3 - Final - YouTube

Crimen,. Gustavo Cerati | Gustavo Cerati Dibujo, Gustavo Cerati Fondos
----------------------------------------------------------------------

 ![Crimen,. Gustavo Cerati | Gustavo cerati dibujo, Gustavo cerati fondos](https://i.pinimg.com/736x/4e/d1/ad/4ed1ad31ad8e581b68e54ed4de99c44c.jpg) <small>ar.pinterest.com</small>Crimen,. Gustavo Cerati | Gustavo cerati dibujo, Gustavo cerati fondos ...

Gustavo Cerati - Crimen - YouTube
---------------------------------

 ![Gustavo Cerati - Crimen - YouTube](https://i.ytimg.com/vi/Jk4J8E64GMw/maxresdefault.jpg) <small>www.youtube.com</small>Gustavo Cerati - Crimen - YouTube

Gustavo Cerati – Crimen Lyrics | Genius Lyrics
----------------------------------------------

 ![Gustavo Cerati – Crimen Lyrics | Genius Lyrics](https://images.genius.com/0f236b40d4dd42b3f7184226ce401a45.1000x1000x1.jpg) <small>genius.com</small>Gustavo Cerati – Crimen Lyrics | Genius Lyrics

Crimen - Song And Lyrics By Gustavo Cerati | Spotify
----------------------------------------------------

 ![Crimen - song and lyrics by Gustavo Cerati | Spotify](https://i.scdn.co/image/ab67616d0000b273d543f7c7de880da5370922c0) <small>open.spotify.com</small>Crimen - song and lyrics by Gustavo Cerati | Spotify

023 CRIMEN (Gustavo Cerati) - YouTube
-------------------------------------

 ![023 CRIMEN (Gustavo Cerati) - YouTube](https://i.ytimg.com/vi/fhtf8Blj3Wg/maxresdefault.jpg?sqp=-oaymwEmCIAKENAF8quKqQMa8AEB-AH-CYAC0AWKAgwIABABGFUgYChlMA8=&rs=AOn4CLAztzko3bcPlQypsortdzSFe_NNFg) <small>www.youtube.com</small>023 CRIMEN (Gustavo Cerati) - YouTube

Crimen : Gustavo Cerati (Video Oficial ) HTV - ETC - YouTube
------------------------------------------------------------

 ![Crimen : Gustavo Cerati (Video Oficial ) HTV - ETC - YouTube](https://i.ytimg.com/vi/LCpFkLlDiV0/hqdefault.jpg?sqp=-oaymwEmCOADEOgC8quKqQMa8AEB-AHeAoACiAKKAgwIABABGGEgZShPMA8=&rs=AOn4CLCNR0-rEy-cPFHVjxa_sq9TH2KU3Q) <small>www.youtube.com</small>Crimen : Gustavo Cerati (Video Oficial ) HTV - ETC - YouTube

Microhistorias: "Historia Detrás De Un Hit" - Crimen Gustavo Cerati
-------------------------------------------------------------------

 ![Microhistorias: "Historia detrás de un Hit" - Crimen Gustavo Cerati](https://i.ytimg.com/vi/TBkoT3pDeAQ/maxresdefault.jpg) <small>www.youtube.com</small>Microhistorias: "Historia detrás de un Hit" - Crimen Gustavo Cerati ...

Gustavo Cerati - Crimen // Letra // - YouTube
---------------------------------------------

 ![Gustavo Cerati - Crimen // Letra // - YouTube](https://i.ytimg.com/vi/gmlcNNRDojU/maxresdefault.jpg) <small>www.youtube.com</small>Gustavo Cerati - Crimen // Letra // - YouTube

Tutorial DEFINITIVO ¿Cómo Tocar Crimen De Gustavo Cerati? 🕵️ GUITARRA
---------------------------------------------------------------------

 ![Tutorial DEFINITIVO ¿Cómo tocar Crimen de Gustavo Cerati? 🕵️ GUITARRA](https://i.ytimg.com/vi/NluicPssqcE/maxresdefault.jpg) <small>www.youtube.com</small>Tutorial DEFINITIVO ¿Cómo tocar Crimen de Gustavo Cerati? 🕵️ GUITARRA ...

CRIMEN - Gustavo Cerati - LETRAS.COM
------------------------------------

 ![CRIMEN - Gustavo Cerati - LETRAS.COM](https://akamai.sscdn.co/uploadfile/letras/fotos/3/a/7/5/3a75246b960d609112b5578f5774b3fe.jpg) <small>www.letras.com</small>CRIMEN - Gustavo Cerati - LETRAS.COM

Gustavo Cerati - Crimen (Official VIdeo) - RimixRadio - Noticias Y
------------------------------------------------------------------

 ![Gustavo Cerati - Crimen (Official VIdeo) - RimixRadio - Noticias y](https://rimixradio.com/wp-content/uploads/2025/03/gustavao-cerati-crimen.jpg) <small>rimixradio.com</small>Gustavo Cerati - Crimen (Official VIdeo) - RimixRadio - Noticias y ...

Salta La Banca - Crimen (Cover Gustavo Cerati) - YouTube | Gustavo
------------------------------------------------------------------

 ![Salta La Banca - Crimen (Cover Gustavo Cerati) - YouTube | Gustavo](https://i.pinimg.com/736x/58/8d/3c/588d3c635dfec67fac38970c40c57d52.jpg) <small>ar.pinterest.com</small>Salta La Banca - Crimen (Cover Gustavo Cerati) - YouTube | Gustavo ...

Gustavo cerati "feat" jorge marino. gustavo cerati. gustavo cerati
