---
title: "Usman Nurmagomedov Vs Alfie Davis Live Stream - Usman nurmagomedov vs alfie davis recap: relive usman nurmagomedov&#039;s"
description: "Pfl road to dubai: usman nurmagomedov submits alfie davis"
date: "2026-03-22"
categories:
- "Uncategorized"
images:
- "https://ichef.bbci.co.uk/ace/standard/640/cpsprodpb/vivo/live/images/2026/2/7/4182f023-6644-49d1-9f7a-f3c2fc2d9d03.png.webp"
featuredImage: "https://i.ytimg.com/vi/9hO_Q5Jwxb0/maxresdefault.jpg"
featured_image: "https://www.thenationalnews.com/resizer/v2/YK5TYNHM2RFW3NRJ4YCVOK6CHQ.JPG?auth=f7ba41cfdd5635dcccb361c2d0c3c910445b0b7a0177d22cf0c52a90b51750a6"
image: "https://ichef.bbci.co.uk/ace/standard/640/cpsprodpb/vivo/live/images/2026/2/7/4182f023-6644-49d1-9f7a-f3c2fc2d9d03.png.webp"
---

If you are searching about Usman Nurmagomedov vs. Alfie Davis title bout headlines PFL: Road to Dubai you've visit to the right place. We have 35 Images about Usman Nurmagomedov vs. Alfie Davis title bout headlines PFL: Road to Dubai like Nurmagomedov vs Davis (Feb 7, 2026): How to Watch, Start Time, Usman Nurmagomedov Dominates and Submits Alfie Davis to Retain Title and also PFL: Usman Nurmagomedov defende cinturão contra Alfie Davis em 2026 | Ge. Read more:

Usman Nurmagomedov Vs. Alfie Davis Title Bout Headlines PFL: Road To Dubai
--------------------------------------------------------------------------

 ![Usman Nurmagomedov vs. Alfie Davis title bout headlines PFL: Road to Dubai](https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA1QOp88.img?w=768&h=511&m=6) <small>www.msn.com</small>Usman Nurmagomedov vs. Alfie Davis title bout headlines PFL: Road to Dubai

Usman Nurmagomedov Vs Alfie Davis RECAP: Relive Usman Nurmagomedov's
--------------------------------------------------------------------

 ![Usman Nurmagomedov vs Alfie Davis RECAP: Relive Usman Nurmagomedov's](https://ichef.bbci.co.uk/ace/standard/640/cpsprodpb/vivo/live/images/2026/2/7/89ee560a-05ad-4d89-8a2c-6d544736c055.jpg.webp) <small>www.bbc.co.uk</small>Usman Nurmagomedov vs Alfie Davis RECAP: Relive Usman Nurmagomedov's ...

Usman Nurmagomedov VS Alfie Davis | Full Fight In HD | PFL Light Weight
-----------------------------------------------------------------------

 ![Usman Nurmagomedov VS Alfie Davis | Full Fight in HD | PFL Light Weight](https://i.ytimg.com/vi/UQuwYxnWqbM/hqdefault.jpg) <small>www.youtube.com</small>Usman Nurmagomedov VS Alfie Davis | Full Fight in HD | PFL Light Weight ...

PFL Road To Dubai: Usman Nurmagomedov Submits Alfie Davis
---------------------------------------------------------

 ![PFL Road to Dubai: Usman Nurmagomedov submits Alfie Davis](https://mmajunkie.usatoday.com/gcdn/authoring/authoring-images/2026/02/07/SMMA/88570563007-usman-nurmagomedov-def-alfie-davis-pfl-road-to-dubai-15.JPG?crop=2399,1351,x0,y124&width=2399&height=1351&format=pjpg&auto=webp) <small>mmajunkie.usatoday.com</small>PFL Road to Dubai: Usman Nurmagomedov submits Alfie Davis

PFL Dubai Live Stream Nurmagomedov Vs Davis Live PFL Dubai Nurmagomedo
----------------------------------------------------------------------

 ![PFL Dubai Live Stream Nurmagomedov vs Davis Live PFL Dubai Nurmagomedo](https://www.tiktok.com/api/img/?itemId=7604212733650783502&location=0&aid=1988) <small>www.tiktok.com</small>PFL Dubai Live Stream Nurmagomedov vs Davis Live PFL Dubai Nurmagomedo ...

PFL: Usman Nurmagomedov Defende Cinturão Contra Alfie Davis Em 2026 | Ge
------------------------------------------------------------------------

 ![PFL: Usman Nurmagomedov defende cinturão contra Alfie Davis em 2026 | Ge](https://s2-ge.glbimg.com/_s5U9nUfu2mJebbpe4o6WY4MnXA=/1280x0/filters:format(jpeg)/https://s01.video.glbimg.com/x720/13984736.jpg) <small>ge.globo.com</small>PFL: Usman Nurmagomedov defende cinturão contra Alfie Davis em 2026 | Ge

Usman Nurmagomedov Vs Alfie Davis RECAP: Relive Usman Nurmagomedov's
--------------------------------------------------------------------

 ![Usman Nurmagomedov vs Alfie Davis RECAP: Relive Usman Nurmagomedov's](https://ichef.bbci.co.uk/ace/standard/640/cpsprodpb/vivo/live/images/2026/2/7/4182f023-6644-49d1-9f7a-f3c2fc2d9d03.png.webp) <small>www.bbc.co.uk</small>Usman Nurmagomedov vs Alfie Davis RECAP: Relive Usman Nurmagomedov's ...

Usman Nurmagomedov Dominates Alfie Davis To Retain PFL Lightweight
------------------------------------------------------------------

 ![Usman Nurmagomedov dominates Alfie Davis to retain PFL lightweight](https://www.thenationalnews.com/resizer/v2/YK5TYNHM2RFW3NRJ4YCVOK6CHQ.JPG?auth=f7ba41cfdd5635dcccb361c2d0c3c910445b0b7a0177d22cf0c52a90b51750a6) <small>www.thenationalnews.com</small>Usman Nurmagomedov dominates Alfie Davis to retain PFL lightweight ...

Usman Nurmagomedov Vs Alfie Davis RECAP: Relive Usman Nurmagomedov's
--------------------------------------------------------------------

 ![Usman Nurmagomedov vs Alfie Davis RECAP: Relive Usman Nurmagomedov's](https://ichef.bbci.co.uk/ace/standard/1024/cpsprodpb/be1f/live/52513350-0464-11f1-a12b-658d26b020a4.png) <small>www.bbc.com</small>Usman Nurmagomedov vs Alfie Davis RECAP: Relive Usman Nurmagomedov's ...

"Alfie Davis, Anytime, Anywhere." - Usman Nurmagomedov Gets His Wish A
----------------------------------------------------------------------

 !["Alfie Davis, Anytime, Anywhere." - Usman Nurmagomedov gets his wish a](https://www.tiktok.com/api/img/?itemId=7575538504147422494&location=0&aid=1988) <small>www.tiktok.com</small>"Alfie Davis, Anytime, Anywhere." - Usman Nurmagomedov gets his wish a ...

USMAN NURMAGOMEDOV Vs ALFIE DAVIS FULL FIGHT - YouTube
------------------------------------------------------

 ![USMAN NURMAGOMEDOV vs ALFIE DAVIS FULL FIGHT - YouTube](https://i.ytimg.com/vi/GQzrEFRq4ps/maxresdefault.jpg) <small>www.youtube.com</small>USMAN NURMAGOMEDOV vs ALFIE DAVIS FULL FIGHT - YouTube

PFL Dubai: Nurmagomedov Vs. Davis Final Faceoff | TikTok
--------------------------------------------------------

 ![PFL Dubai: Nurmagomedov vs. Davis Final Faceoff | TikTok](https://www.tiktok.com/api/img/?itemId=7603746068211272990&location=0&aid=1988) <small>www.tiktok.com</small>PFL Dubai: Nurmagomedov vs. Davis Final Faceoff | TikTok

USMAN NURMAGOMEDOV VS ALFIE DAVIS FULL FIGHT PFL DUBAI - YouTube
----------------------------------------------------------------

 ![USMAN NURMAGOMEDOV VS ALFIE DAVIS FULL FIGHT PFL DUBAI - YouTube](https://i.ytimg.com/vi/a9ZGVFYb46I/maxresdefault.jpg) <small>www.youtube.com</small>USMAN NURMAGOMEDOV VS ALFIE DAVIS FULL FIGHT PFL DUBAI - YouTube

Usman Nurmagomedov Vs Alfie Davis RECAP: Relive Usman Nurmagomedov's
--------------------------------------------------------------------

 ![Usman Nurmagomedov vs Alfie Davis RECAP: Relive Usman Nurmagomedov's](https://ichef.bbci.co.uk/ace/standard/640/cpsprodpb/vivo/live/images/2026/2/7/43e7fc32-f9e1-40aa-ab80-8c8cb164b129.png.webp) <small>www.bbc.com</small>Usman Nurmagomedov vs Alfie Davis RECAP: Relive Usman Nurmagomedov's ...

Usman Nurmagomedov Walkout Against Alfie Davis 🔥🦅 - YouTube
-----------------------------------------------------------

 ![Usman Nurmagomedov walkout against Alfie Davis 🔥🦅 - YouTube](https://i.ytimg.com/vi/VTrur2hesFg/oardefault.jpg?sqp=-oaymwEkCJUDENAFSFqQAgHyq4qpAxMIARUAAAAAJQAAyEI9AICiQ3gB&rs=AOn4CLDwppP9E14qdqLI6WLjcW4jLCMFXA&usqp=CCk) <small>www.youtube.com</small>Usman Nurmagomedov walkout against Alfie Davis 🔥🦅 - YouTube

PFL Dubai Full Card Revealed With Usman Nurmagomedov Vs. Alfie Davis In
-----------------------------------------------------------------------

 ![PFL Dubai full card revealed with Usman Nurmagomedov vs. Alfie Davis in](https://platform.mmafighting.com/wp-content/uploads/sites/109/2025/08/20250125221838-_JP13385_.jpg?quality=90&strip=all&crop=0%2C6.1497095545259%2C100%2C78.534031413613&w=1200) <small>www.mmafighting.com</small>PFL Dubai full card revealed with Usman Nurmagomedov vs. Alfie Davis in ...

PFL Dubai: Usman Nurmagomedov To Defend Title Against Alfie Davis In
--------------------------------------------------------------------

 ![PFL Dubai: Usman Nurmagomedov to defend title against Alfie Davis in](https://ichef.bbci.co.uk/ace/branded_sport/1200/cpsprodpb/c343/live/29feb5b0-c541-11f0-88be-3bc2aea1a256.png) <small>www.bbc.com</small>PFL Dubai: Usman Nurmagomedov to defend title against Alfie Davis in ...

Usman Nurmagomedov To Fight Alfie Davis In PFL Return To Dubai
--------------------------------------------------------------

 ![Usman Nurmagomedov to fight Alfie Davis in PFL return to Dubai](https://cdn1-m.alittihad.ae/store/archive/image/2025/11/20/af1174c7-7c34-46ff-9410-9cbad8a31ad9.jpeg?width=1300) <small>en.aletihad.ae</small>Usman Nurmagomedov to fight Alfie Davis in PFL return to Dubai ...

Usman Nurmagomedov Vs Alfie Davis RECAP: Relive Usman Nurmagomedov's
--------------------------------------------------------------------

 ![Usman Nurmagomedov vs Alfie Davis RECAP: Relive Usman Nurmagomedov's](https://ichef.bbci.co.uk/ace/standard/640/cpsprodpb/vivo/live/images/2026/2/7/7105d8ae-31d1-4417-bc67-84306cd42980.png.webp) <small>www.bbc.co.uk</small>Usman Nurmagomedov vs Alfie Davis RECAP: Relive Usman Nurmagomedov's ...

USMAN RETURNS!! 🔥 | Usman Nurmagomedov V Alfie Davis | Full Fight | PFL
-----------------------------------------------------------------------

 ![USMAN RETURNS!! 🔥 | Usman Nurmagomedov v Alfie Davis | Full Fight | PFL](https://i.ytimg.com/vi/hSd9BwDeZwg/maxresdefault.jpg) <small>www.youtube.com</small>USMAN RETURNS!! 🔥 | Usman Nurmagomedov v Alfie Davis | Full Fight | PFL ...

Usman Nurmagomedov Submits Alfie Davis At PFL #RoadToDubai | ESPN MMA
---------------------------------------------------------------------

 ![Usman Nurmagomedov submits Alfie Davis at PFL #RoadToDubai | ESPN MMA](https://i.ytimg.com/vi/S-TU52nNBPo/maxresdefault.jpg) <small>www.youtube.com</small>Usman Nurmagomedov submits Alfie Davis at PFL #RoadToDubai | ESPN MMA ...

ДИКИЙ РАЗНОС! Полный Бой Усман Нурмагомедов VS Алфи Дэвис PFL / Alfie
---------------------------------------------------------------------

 ![ДИКИЙ РАЗНОС! Полный Бой Усман Нурмагомедов VS Алфи Дэвис PFL / Alfie](https://i.ytimg.com/vi/9hO_Q5Jwxb0/maxresdefault.jpg) <small>www.youtube.com</small>ДИКИЙ РАЗНОС! Полный Бой Усман Нурмагомедов VS Алфи Дэвис PFL / Alfie ...

Usman Nurmagomedov Vs Alfie Davis RECAP: Relive Usman Nurmagomedov's
--------------------------------------------------------------------

 ![Usman Nurmagomedov vs Alfie Davis RECAP: Relive Usman Nurmagomedov's](https://ichef.bbci.co.uk/ace/standard/640/cpsprodpb/vivo/live/images/2026/2/7/dbf0662a-74a2-46e3-bb80-86be5a7fcd08.jpg.webp) <small>www.bbc.com</small>Usman Nurmagomedov vs Alfie Davis RECAP: Relive Usman Nurmagomedov's ...

Lightweight SHOWCASE! | Usman Nurmagomedov V Alfie Davis | Full Fight
---------------------------------------------------------------------

 ![Lightweight SHOWCASE! | Usman Nurmagomedov v Alfie Davis | Full Fight](https://i.ytimg.com/vi/SsmkBT-ZZlc/maxresdefault.jpg) <small>www.youtube.com</small>Lightweight SHOWCASE! | Usman Nurmagomedov v Alfie Davis | Full Fight ...

Usman Nurmagomedov Dominates And Submits Alfie Davis To Retain Title
--------------------------------------------------------------------

 ![Usman Nurmagomedov Dominates and Submits Alfie Davis to Retain Title](https://ichef.bbci.co.uk/ace/branded_sport/1200/cpsprodpb/3eed/live/2f776950-046c-11f1-96f5-2f82f674a667.jpg) <small>newsclip.com</small>Usman Nurmagomedov Dominates and Submits Alfie Davis to Retain Title ...

Nurmagomedov Vs Davis (Feb 7, 2026): How To Watch, Start Time
-------------------------------------------------------------

 ![Nurmagomedov vs Davis (Feb 7, 2026): How to Watch, Start Time](https://champinon.info/images/nurmagomedov-vs-davis.webp) <small>champinon.info</small>Nurmagomedov vs Davis (Feb 7, 2026): How to Watch, Start Time

PFL Dubai: Nurmagomedov Vs. Davis Live Updates, Results
-------------------------------------------------------

 ![PFL Dubai: Nurmagomedov vs. Davis live updates, results](https://mmajunkie.usatoday.com/gcdn/authoring/authoring-images/2026/02/06/SMMA/88552943007-usman-nurmagomedov-vs-alfie-davis-pfl-road-to-dubai-ceremonial-weighins-1.jpg?crop=1919,1081,x0,y99&width=1919&height=1081&format=pjpg&auto=webp) <small>mmajunkie.usatoday.com</small>PFL Dubai: Nurmagomedov vs. Davis live updates, results

PFL Dubai: Nurmagomedov Vs. Davis - Usman Nurmagomedov Vs. Alfie Davis
----------------------------------------------------------------------

 ![PFL Dubai: Nurmagomedov vs. Davis - Usman Nurmagomedov vs. Alfie Davis](https://bmyxlmhutpeswgoxuplj.supabase.co/storage/v1/object/public/event-posters/pfl-nurmagomedov-vs-davis/poster.webp?v=1775521668010) <small>kakuota.app</small>PFL Dubai: Nurmagomedov vs. Davis - Usman Nurmagomedov vs. Alfie Davis ...

Usman Nurmagomedov Dominates Alfie Davis To Retain PFL Lightweight
------------------------------------------------------------------

 ![Usman Nurmagomedov dominates Alfie Davis to retain PFL lightweight](https://www.thenationalnews.com/resizer/v2/YCXNSBSTUFCNBOKU5MCS5PY5EI.JPG?auth=976dda88cca9c69880074695c3b14926e26c6fc9d0e3a65f549bd7cab03620de) <small>www.thenationalnews.com</small>Usman Nurmagomedov dominates Alfie Davis to retain PFL lightweight ...

PFL Dubai Full Card Revealed With Usman Nurmagomedov Vs. Alfie Davis In
-----------------------------------------------------------------------

 ![PFL Dubai full card revealed with Usman Nurmagomedov vs. Alfie Davis in](https://platform.mmafighting.com/wp-content/uploads/sites/109/2026/02/PFL_20260208_JP1_0147.jpg?quality=90&strip=all&crop=16.666666666667%2C0%2C66.666666666667%2C100&w=1080) <small>www.mmafighting.com</small>PFL Dubai full card revealed with Usman Nurmagomedov vs. Alfie Davis in ...

Usman Nurmagomedov Vs Alfie Davis RECAP: Relive Usman Nurmagomedov's
--------------------------------------------------------------------

 ![Usman Nurmagomedov vs Alfie Davis RECAP: Relive Usman Nurmagomedov's](https://ichef.bbci.co.uk/ace/standard/640/cpsprodpb/vivo/live/images/2026/2/7/9dd9505f-b6d2-491d-b383-aa2131fd097b.png.webp) <small>www.bbc.co.uk</small>Usman Nurmagomedov vs Alfie Davis RECAP: Relive Usman Nurmagomedov's ...

Where To Watch PFL Dubai 2026: Nurmagomedov Vs. Davis Live Stream
-----------------------------------------------------------------

 ![Where to watch PFL Dubai 2026: Nurmagomedov vs. Davis Live stream](https://library.sportingnews.com/styles/twitter_card_120x120/s3/2024-08/1T6A3705.jpg?itok=a712uSVC) <small>www.sportingnews.com</small>Where to watch PFL Dubai 2026: Nurmagomedov vs. Davis Live stream ...

Lightweight Title On The Line!! | Usman Nurmagomedov V Alfie Davis
------------------------------------------------------------------

 ![Lightweight Title On The Line!! | Usman Nurmagomedov v Alfie Davis](https://i.ytimg.com/vi/UpXkvC1amj0/maxresdefault.jpg) <small>www.youtube.com</small>Lightweight Title On The Line!! | Usman Nurmagomedov v Alfie Davis ...

Usman Nurmagomedov Vs Alfie Davis — A Dominant Performance - YouTube
--------------------------------------------------------------------

 ![Usman Nurmagomedov vs Alfie Davis — A Dominant Performance - YouTube](https://i.ytimg.com/vi/iHUOjvEpzfU/oardefault.jpg?sqp=-oaymwEkCJUDENAFSFqQAgHyq4qpAxMIARUAAAAAJQAAyEI9AICiQ3gB&rs=AOn4CLDmylHPTGokOhKvYLnyxlpslk0PyA&usqp=CCk) <small>www.youtube.com</small>Usman Nurmagomedov vs Alfie Davis — A Dominant Performance - YouTube

PFL Dubai Results: Usman Nurmagomedov Defends Lightweight Title After
---------------------------------------------------------------------

 ![PFL Dubai Results: Usman Nurmagomedov Defends Lightweight Title After](https://middleeasy.com/wp-content/uploads/2026/02/Usman-Nurmagomedov.jpg) <small>middleeasy.com</small>PFL Dubai Results: Usman Nurmagomedov Defends Lightweight Title After ...

usman returns!! 🔥. Usman nurmagomedov to fight alfie davis in pfl return to dubai. Usman nurmagomedov vs alfie davis recap: relive usman nurmagomedov's
