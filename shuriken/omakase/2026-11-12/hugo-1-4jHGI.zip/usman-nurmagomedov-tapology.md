---
title: "Usman Nurmagomedov Tapology - usman nurmagomedov vs. archie colgan, pfl new york"
description: "usman nurmagomedov"
date: "2026-04-23"
categories:
- "Uncategorized"
images:
- "https://lasueur.com/wp-content/uploads/2023/10/Usman-Nurmagomedov.jpg"
featuredImage: "https://www.totalprosports.com/wp-content/uploads/2024/09/Khabib-Nurmagomedov-and-Usman-Nurmagomedov.jpg"
featured_image: "https://www.thenationalnews.com/resizer/v2/U2FCUNFAPRF25BZACFHECKACGM.jpg?auth=70773c6b29c05da0008b983da71eb337425d8b2a204af93e663530d5cc8160fa"
image: "https://bloodyelbow.com/wp-content/uploads/1/2026/02/Khabib-Usman-1140x622.png"
---

If you are searching about Usman Nurmagomedov vs. Paul Hughes II, PFL Champions Series 2 | MMA you've visit to the right page. We have 35 Pictures about Usman Nurmagomedov vs. Paul Hughes II, PFL Champions Series 2 | MMA like Usman Nurmagomedov | MMA Fighter Page | Tapology, Usman Nurmagomedov vs. Paul Hughes II, PFL Champions Series 2 | MMA and also Usman Nurmagomedov fotka. Read more:

Usman Nurmagomedov Vs. Paul Hughes II, PFL Champions Series 2 | MMA
-------------------------------------------------------------------

 ![Usman Nurmagomedov vs. Paul Hughes II, PFL Champions Series 2 | MMA](https://images.tapology.com/poster_images/132096/profile/OIMOUAs.jpg?1759291827) <small>www.tapology.com</small>Usman Nurmagomedov vs. Paul Hughes II, PFL Champions Series 2 | MMA ...

Usman Nurmagomedov Extends Perfect Record With 'amazing' Win Over Paul
----------------------------------------------------------------------

 ![Usman Nurmagomedov extends perfect record with 'amazing' win over Paul](https://www.thenationalnews.com/resizer/v2/U2FCUNFAPRF25BZACFHECKACGM.jpg?auth=70773c6b29c05da0008b983da71eb337425d8b2a204af93e663530d5cc8160fa) <small>www.thenationalnews.com</small>Usman Nurmagomedov extends perfect record with 'amazing' win over Paul ...

Usman Nurmagomedov Vs. Alexander Shabliy, Bellator Champions Series
-------------------------------------------------------------------

 ![Usman Nurmagomedov vs. Alexander Shabliy, Bellator Champions Series](https://images.tapology.com/poster_images/111173/profile/448535275_18439925020048134_6175435916473982330_n.jpg?1718741430) <small>www.tapology.com</small>Usman Nurmagomedov vs. Alexander Shabliy, Bellator Champions Series ...

Usman Nurmagomedov | Lightweight (155)
--------------------------------------

 ![Usman Nurmagomedov | Lightweight (155)](https://pflmma-prod.s3.amazonaws.com/fighters/bodyshots/4ccd8d6d39f4746f8722f23f13dd9d17-1-1.png) <small>pflmma.com</small>Usman Nurmagomedov | Lightweight (155)

Usman Nurmagomedov Pense Pouvoir Rivaliser Avec L'élite Des Combattants
-----------------------------------------------------------------------

 ![Usman Nurmagomedov pense pouvoir rivaliser avec l'élite des combattants](https://www.actumma.com/wp-content/uploads/2026/02/Usman-Nurmagomedov-affronte-Ilia-Topuria-Arman-Tsarukyan.jpg) <small>www.actumma.com</small>Usman Nurmagomedov pense pouvoir rivaliser avec l'élite des combattants ...

"They’re All On Steroids" - UFC Bantamweight Channels Inner Nate Diaz
---------------------------------------------------------------------

 !["They’re all on steroids" - UFC bantamweight channels inner Nate Diaz](https://staticg.sportskeeda.com/editor/2024/04/ae43b-17139713477627-1920.jpg) <small>www.sportskeeda.com</small>"They’re all on steroids" - UFC bantamweight channels inner Nate Diaz ...

File:UsmanNurmagomedov.png - Wikimedia Commons
----------------------------------------------

 ![File:UsmanNurmagomedov.png - Wikimedia Commons](https://upload.wikimedia.org/wikipedia/commons/thumb/5/52/UsmanNurmagomedov.png/500px-UsmanNurmagomedov.png) <small>commons.wikimedia.org</small>File:UsmanNurmagomedov.png - Wikimedia Commons

Usman Nurmagomedov | MMA Fighter Page | Tapology
------------------------------------------------

 ![Usman Nurmagomedov | MMA Fighter Page | Tapology](https://images.tapology.com/letterbox_images/194617/default/Screenshot.png?1732112169) <small>www.tapology.com</small>Usman Nurmagomedov | MMA Fighter Page | Tapology

Usman Nurmagomedov: Net Worth 2023, Stats, Age And More
-------------------------------------------------------

 ![Usman Nurmagomedov: Net worth 2023, stats, age and more](https://static0.givemesportimages.com/wordpress/wp-content/uploads/2023/01/Usman-Nurmagomedov-profile-picture.jpg) <small>www.givemesport.com</small>Usman Nurmagomedov: Net worth 2023, stats, age and more

PFL Dubai Results: Usman Nurmagomedov Defends Lightweight Title After
---------------------------------------------------------------------

 ![PFL Dubai Results: Usman Nurmagomedov Defends Lightweight Title After](https://middleeasy.com/wp-content/uploads/2026/02/Usman-Nurmagomedov-870x489.jpg) <small>middleeasy.com</small>PFL Dubai Results: Usman Nurmagomedov Defends Lightweight Title After ...

MMA - Le Bellator De Retour En France En 2024 Avec Usman Nurmagomedov
---------------------------------------------------------------------

 ![MMA - Le Bellator de retour en France en 2024 avec Usman Nurmagomedov](https://lasueur.com/wp-content/uploads/2023/10/Usman-Nurmagomedov.jpg) <small>lasueur.com</small>MMA - Le Bellator de retour en France en 2024 avec Usman Nurmagomedov

”We Can Change Everything” - Islam Makhachev Hailed The Best
------------------------------------------------------------

 ![”We can change everything” - Islam Makhachev hailed the best](https://staticg.sportskeeda.com/editor/2023/10/73ea0-16966791664893-1920.jpg) <small>www.sportskeeda.com</small>”We can change everything” - Islam Makhachev hailed the best ...

Ukaljan Obraz I čast Porodice Nurmagomedov - Katastrofalne Vijesti
------------------------------------------------------------------

 ![Ukaljan obraz i čast porodice Nurmagomedov - Katastrofalne vijesti](https://sportsport.ba/assets/pictures/article/491/usman-nurmagomedov.jpg) <small>sportsport.ba</small>Ukaljan obraz i čast porodice Nurmagomedov - Katastrofalne vijesti ...

Bellator San Diego: Usman Nurmagomedov Retains Lightweight Title By
-------------------------------------------------------------------

 ![Bellator San Diego: Usman Nurmagomedov retains lightweight title by](https://ichef.bbci.co.uk/ace/standard/3840/cpsprodpb/ca11/live/122e9360-6dc2-11ef-a713-d96a32d18a4e.jpg) <small>www.bbc.com</small>Bellator San Diego: Usman Nurmagomedov retains lightweight title by ...

Usman Nurmagomedov Vs. Ruslan Tuyakov, GFC 24 | MMA Bout | Tapology
-------------------------------------------------------------------

 ![Usman Nurmagomedov vs. Ruslan Tuyakov, GFC 24 | MMA Bout | Tapology](https://images.tapology.com/headshot_images/184291/large/Untitled4.jpg?1550678125) <small>www.tapology.com</small>Usman Nurmagomedov vs. Ruslan Tuyakov, GFC 24 | MMA Bout | Tapology

Bellator Champions Series: Usman Nurmagomedov Retains Lightweight Title
-----------------------------------------------------------------------

 ![Bellator Champions Series: Usman Nurmagomedov retains lightweight title](https://blogs.rdxsports.com/wp-content/uploads/2024/09/usman-nurmagomedov-2.jpg) <small>blogs.rdxsports.com</small>Bellator Champions Series: Usman Nurmagomedov retains lightweight title ...

Usman Nurmagomedov To Defend PFL Title Against…
-----------------------------------------------

 ![Usman Nurmagomedov to defend PFL title against…](https://images.inkl.com/s3/article/lead_image/22726672/Usman-Nurmagomedov.jpeg) <small>www.inkl.com</small>Usman Nurmagomedov to defend PFL title against…

Usman Nurmagomedov Vs Paul Hughes: Irishman Hughes Falls Short In
-----------------------------------------------------------------

 ![Usman Nurmagomedov vs Paul Hughes: Irishman Hughes falls short in](https://ichef.bbci.co.uk/ace/standard/3840/cpsprodpb/d88b/live/5f805cd0-db71-11ef-a991-65e04595f231.jpg) <small>www.bbc.com</small>Usman Nurmagomedov vs Paul Hughes: Irishman Hughes falls short in ...

Khabib Nurmagomedov Lauds Cousin Usman Nurmagomedov As "future Of This
----------------------------------------------------------------------

 ![Khabib Nurmagomedov lauds cousin Usman Nurmagomedov as "future of this](https://staticg.sportskeeda.com/editor/2024/09/2bccb-17256976097553-1920.jpg) <small>www.sportskeeda.com</small>Khabib Nurmagomedov lauds cousin Usman Nurmagomedov as "future of this ...

Usman Nurmagomedov Disagrees With Ilia Topuria Being Seen As #1
---------------------------------------------------------------

 ![Usman Nurmagomedov disagrees with Ilia Topuria being seen as #1](https://www.bjpenn.com/wp-content/uploads/2025/01/Khabib-Nurmagomedov-Paul-Hughes-Usman-Nurmagomedov.jpg) <small>www.bjpenn.com</small>Usman Nurmagomedov disagrees with Ilia Topuria being seen as #1 ...

Khabib Nurmagomedov Confident In Brother Usman’s Superiority After
------------------------------------------------------------------

 ![Khabib Nurmagomedov Confident In Brother Usman’s Superiority After](https://www.totalprosports.com/wp-content/uploads/2024/09/Khabib-Nurmagomedov-and-Usman-Nurmagomedov.jpg) <small>www.totalprosports.com</small>Khabib Nurmagomedov Confident In Brother Usman’s Superiority After ...

Usman Nurmagomedov Vs. Archie Colgan, PFL New York | MMA Bout | Tapology
------------------------------------------------------------------------

 ![Usman Nurmagomedov vs. Archie Colgan, PFL New York | MMA Bout | Tapology](https://images.tapology.com/poster_images/144072/profile/SnapInsta.to_707499178_18595727038013832_3534947330590306099_n.jpg?1779810333) <small>www.tapology.com</small>Usman Nurmagomedov vs. Archie Colgan, PFL New York | MMA Bout | Tapology

2025 CHAMPIONS SERIES: USMAN NURMAGOMEDOV VS PAUL HUGHES | Professional
-----------------------------------------------------------------------

 ![2025 CHAMPIONS SERIES: USMAN NURMAGOMEDOV VS PAUL HUGHES | Professional](https://pflmma-prod.s3.amazonaws.com/galleries/images/f6ef3fc8067e6e7feb95a2b1143c332d-1.jpg) <small>pflmma.com</small>2025 CHAMPIONS SERIES: USMAN NURMAGOMEDOV VS PAUL HUGHES | Professional ...

PFL: Usman Nurmagomedov Once Again Defeats Paul Hughes And Retains The
----------------------------------------------------------------------

 ![PFL: Usman Nurmagomedov once again defeats Paul Hughes and retains the](https://images.daznservices.com/di/library/DAZN_News/fe/9a/usman-nurmagomedov-10032025-ftr_ujwprztz0atd1793p065k2wxy.png?t=-1406537495) <small>www.dazn.com</small>PFL: Usman Nurmagomedov once again defeats Paul Hughes and retains the ...

Usman Nurmagomedov Fotka
------------------------

 ![Usman Nurmagomedov fotka](https://im.fights.cz/2021/08/01/1310200-usman-nurmagomedov-original.jpg?1627794577) <small>foto.fights.cz</small>Usman Nurmagomedov fotka

PFL Dubai: Usman Nurmagomedov Submits Alfie Davis In Third Round To
-------------------------------------------------------------------

 ![PFL Dubai: Usman Nurmagomedov submits Alfie Davis in third round to](https://ichef.bbci.co.uk/ace/standard/2560/cpsprodpb/3eed/live/2f776950-046c-11f1-96f5-2f82f674a667.jpg) <small>www.bbc.co.uk</small>PFL Dubai: Usman Nurmagomedov submits Alfie Davis in third round to ...

Crucial Admission From Team Khabib Could Destroy Myth Around
------------------------------------------------------------

 ![Crucial admission from Team Khabib could destroy myth around](https://media.firstsportz.com/wp-content/uploads/2025/01/28041034/Khabib-Nurmagomedov-and-Usman-Nurmagomedov-after-the-recent-Bellator-title-defense-1200x675.jpg) <small>firstsportz.com</small>Crucial admission from Team Khabib could destroy myth around ...

Usman Nurmagomedov Told He 'crossed A Line' By Dana White After UFC
-------------------------------------------------------------------

 ![Usman Nurmagomedov told he 'crossed a line' by Dana White after UFC](https://bloodyelbow.com/wp-content/uploads/1/2026/08/GettyImages-2292564700-scaled.jpg) <small>bloodyelbow.com</small>Usman Nurmagomedov told he 'crossed a line' by Dana White after UFC ...

Usman Nurmagomedov Mỉa Mai Thành Tích Của Ilia Topuria
------------------------------------------------------

 ![Usman Nurmagomedov mỉa mai thành tích của Ilia Topuria](https://563.congtyannhien.com/wp-content/uploads/2025/09/usman-nurmagomedov-face-off-1-scaled.jpg) <small>563.congtyannhien.com</small>Usman Nurmagomedov mỉa mai thành tích của Ilia Topuria

Usman Nurmagomedov | Lightweight (155)
--------------------------------------

 ![Usman Nurmagomedov | Lightweight (155)](https://pflmma-prod.s3.amazonaws.com/fighters/banners/1ed9fdda34774af72f2a1a4ccd50dc21-1.jpg) <small>pflmma.com</small>Usman Nurmagomedov | Lightweight (155)

Usman Nurmagomedov To Defend PFL Title Against Britain’s Alfie Davis
--------------------------------------------------------------------

 ![Usman Nurmagomedov to defend PFL title against Britain’s Alfie Davis](https://static.independent.co.uk/2025/11/20/14/59/Usman-Nurmagomedov.jpeg) <small>www.independent.co.uk</small>Usman Nurmagomedov to defend PFL title against Britain’s Alfie Davis ...

Bellator Champions Series: Usman Nurmagomedov Retains Lightweight Title
-----------------------------------------------------------------------

 ![Bellator Champions Series: Usman Nurmagomedov retains lightweight title](https://blogs.rdxsports.com/wp-content/uploads/2024/09/usman-nurmagomedov.jpg) <small>blogs.rdxsports.com</small>Bellator Champions Series: Usman Nurmagomedov retains lightweight title ...

Islam Makhachev Says The UFC's 'small Purses' Could Hold Up Usman
-----------------------------------------------------------------

 ![Islam Makhachev says the UFC's 'small purses' could hold up Usman](https://bloodyelbow.com/wp-content/uploads/1/2026/02/Khabib-Usman-1140x622.png) <small>bloodyelbow.com</small>Islam Makhachev says the UFC's 'small purses' could hold up Usman ...

UFC China: Usman Nurmagomedov Gera Polêmica Após Derrota Do Irmão - Ag
----------------------------------------------------------------------

 ![UFC China: Usman Nurmagomedov gera polêmica após derrota do irmão - Ag](https://cdn.agfight.com/wp-content/uploads/2025/01/usman-khabib-makhachev-pfl-1000x600.jpg) <small>agfight.com</small>UFC China: Usman Nurmagomedov gera polêmica após derrota do irmão - Ag ...

Usman Nurmagomedov Wraca Do Klatki. PFL Odsłania Pierwszą Walkę
---------------------------------------------------------------

 ![Usman Nurmagomedov wraca do klatki. PFL odsłania pierwszą walkę](https://inthecage.pl/wp-content/uploads/2025/11/Zrzut-ekranu-2025-11-20-204721.png) <small>inthecage.pl</small>Usman Nurmagomedov wraca do klatki. PFL odsłania pierwszą walkę ...

Usman nurmagomedov vs. paul hughes ii, pfl champions series 2. Usman nurmagomedov extends perfect record with 'amazing' win over paul. usman nurmagomedov
