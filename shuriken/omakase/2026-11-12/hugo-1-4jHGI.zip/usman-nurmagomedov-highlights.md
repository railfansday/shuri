---
title: "Usman Nurmagomedov Highlights - Can he remain undefeated?🤔"
description: "Usman nurmagomedov vs. paul hughes full fight video highlights"
date: "2026-09-08"
categories:
- "Uncategorized"
images:
- "https://cagesidepress.com/wp-content/uploads/2022/11/Usman-champ.jpg"
featuredImage: "https://www.thenationalnews.com/resizer/v2/U2FCUNFAPRF25BZACFHECKACGM.jpg?auth=70773c6b29c05da0008b983da71eb337425d8b2a204af93e663530d5cc8160fa"
featured_image: "https://ichef.bbci.co.uk/ace/standard/3840/cpsprodpb/d88b/live/5f805cd0-db71-11ef-a991-65e04595f231.jpg"
image: "https://middleeasy.com/wp-content/uploads/2025/10/Usman-Nurmagomedov--1140x641.jpg"
---

If you are looking for PFL Dubai Results: Usman Nurmagomedov Defends Lightweight Title After you've came to the right page. We have 35 Pictures about PFL Dubai Results: Usman Nurmagomedov Defends Lightweight Title After like Bellator 292 results, highlights: Usman Nurmagomedov shines to retain, Usman Nurmagomedov vs. Paul Hughes full fight video highlights | MMA and also 2025 CHAMPIONS SERIES: USMAN NURMAGOMEDOV VS PAUL HUGHES | Professional. Here it is:

PFL Dubai Results: Usman Nurmagomedov Defends Lightweight Title After
---------------------------------------------------------------------

 ![PFL Dubai Results: Usman Nurmagomedov Defends Lightweight Title After](https://middleeasy.com/wp-content/uploads/2026/02/Usman-Nurmagomedov-870x489.jpg) <small>middleeasy.com</small>PFL Dubai Results: Usman Nurmagomedov Defends Lightweight Title After ...

Bellator Champions Series: Usman Nurmagomedov Retains Lightweight Title
-----------------------------------------------------------------------

 ![Bellator Champions Series: Usman Nurmagomedov retains lightweight title](https://blogs.rdxsports.com/wp-content/uploads/2024/09/usman-nurmagomedov.jpg) <small>blogs.rdxsports.com</small>Bellator Champions Series: Usman Nurmagomedov retains lightweight title ...

Usman Nurmagomedov Vs. Paul Hughes Full Fight Video Highlights | MMA
--------------------------------------------------------------------

 ![Usman Nurmagomedov vs. Paul Hughes full fight video highlights | MMA](https://platform.mmafighting.com/wp-content/uploads/sites/109/chorus/uploads/chorus_asset/file/25846712/Screen_Shot_2025_01_25_at_4.01.52_PM.png?quality=90&strip=all&crop=0%2C1.0286284953396%2C100%2C95.718797275535&w=1200) <small>www.mmafighting.com</small>Usman Nurmagomedov vs. Paul Hughes full fight video highlights | MMA ...

Usman Nurmagomedov Vs. Paul Hughes 2: PFL Champions Series 3 Full
-----------------------------------------------------------------

 ![Usman Nurmagomedov vs. Paul Hughes 2: PFL Champions Series 3 full](https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA1NOQEw.img?w=768&h=432&m=6&x=322&y=109&s=171&d=171) <small>www.msn.com</small>Usman Nurmagomedov vs. Paul Hughes 2: PFL Champions Series 3 full ...

Highlights! Usman Nurmagomedov Wins Back-and-forth Bloody War Against
---------------------------------------------------------------------

 ![Highlights! Usman Nurmagomedov wins back-and-forth bloody war against](https://cdn.vox-cdn.com/thumbor/8wgDb9SUdQiaYlqJb8qWDMQ_sXM=/51x0:579x297/1600x900/cdn.vox-cdn.com/uploads/chorus_image/image/73868001/Screenshot_2025_01_25_at_14_35_08__1__PFL_on_X__AndSTILL_Bellator_Lightweight_Champion_USMAN_NURMAGOMEDOV___RoadToDubai_LIVE_NOW______MAX__________DAZN______OKKO_https___t.co_l45rwHW53C___X.0.png) <small>www.mmamania.com</small>Highlights! Usman Nurmagomedov wins back-and-forth bloody war against ...

Usman Nurmagomedov Vs Alfie Davis Highlights
--------------------------------------------

 ![Usman Nurmagomedov Vs Alfie Davis Highlights](https://lookaside.instagram.com/seo/google_widget/crawler/?media_id=3827508970144347224) <small>www.instagram.com</small>Usman Nurmagomedov Vs Alfie Davis Highlights

Bellator 292 Results, Highlights: Usman Nurmagomedov Shines To Retain
---------------------------------------------------------------------

 ![Bellator 292 results, highlights: Usman Nurmagomedov shines to retain](https://sportshub.cbsistatic.com/i/r/2023/03/11/79010398-08d3-4639-801e-0e317f77a987/thumbnail/1200x675/81013795cc4353ffd2923cf2065b777b/nurmagomedov-henderson-kick.jpg) <small>www.cbssports.com</small>Bellator 292 results, highlights: Usman Nurmagomedov shines to retain ...

Bellator 300 Results, Highlights: Usman Nurmagomedov Outclasses Brent
---------------------------------------------------------------------

 ![Bellator 300 results, highlights: Usman Nurmagomedov outclasses Brent](https://sportshub.cbsistatic.com/i/r/2023/10/08/d0f1284f-1902-48a4-8dde-170fdc92ebc1/thumbnail/1200x675/81e5b30cd2e30c1aa10b5e9961268017/usman-nurmagomedov-winner.jpg) <small>www.cbssports.com</small>Bellator 300 results, highlights: Usman Nurmagomedov outclasses Brent ...

Usman Nurmagomedov To Defend PFL Title Against Britain’s Alfie Davis
--------------------------------------------------------------------

 ![Usman Nurmagomedov to defend PFL title against Britain’s Alfie Davis](https://static.independent.co.uk/2025/11/20/14/59/Usman-Nurmagomedov.jpeg) <small>www.independent.co.uk</small>Usman Nurmagomedov to defend PFL title against Britain’s Alfie Davis ...

Usman Nurmagomedov Outpoints Paul Hughes Again At PFL Dubai In Grueling
-----------------------------------------------------------------------

 ![Usman Nurmagomedov Outpoints Paul Hughes Again at PFL Dubai in Grueling](https://middleeasy.com/wp-content/uploads/2025/10/Usman-Nurmagomedov--1140x641.jpg) <small>middleeasy.com</small>Usman Nurmagomedov Outpoints Paul Hughes Again at PFL Dubai in Grueling ...

Russia's Usman Nurmagomedov Celebrates After Winning The Road To
----------------------------------------------------------------

 ![Russia's Usman Nurmagomedov celebrates after winning the Road To](https://media.gettyimages.com/id/2195374020/photo/usman-nurmagomedov-vs-paul-hughe-road-to-dubai-lightweight-title-fight.jpg?s=1024x1024&w=gi&k=20&c=4iesuwZji-f1wltSjGDQgNP4wyNNykgMBC8nq7A5sKI=) <small>www.gettyimages.in</small>Russia's Usman Nurmagomedov celebrates after winning the Road To ...

Usman Nurmagomedov Vs Paul Hughes: Irishman Hughes Falls Short In
-----------------------------------------------------------------

 ![Usman Nurmagomedov vs Paul Hughes: Irishman Hughes falls short in](https://ichef.bbci.co.uk/ace/standard/3840/cpsprodpb/d88b/live/5f805cd0-db71-11ef-a991-65e04595f231.jpg) <small>www.bbc.com</small>Usman Nurmagomedov vs Paul Hughes: Irishman Hughes falls short in ...

2025 CHAMPIONS SERIES: USMAN NURMAGOMEDOV VS PAUL HUGHES | Professional
-----------------------------------------------------------------------

 ![2025 CHAMPIONS SERIES: USMAN NURMAGOMEDOV VS PAUL HUGHES | Professional](https://pflmma-prod.s3.amazonaws.com/galleries/images/f6ef3fc8067e6e7feb95a2b1143c332d-1.jpg) <small>pflmma.com</small>2025 CHAMPIONS SERIES: USMAN NURMAGOMEDOV VS PAUL HUGHES | Professional ...

Usman Nurmagomedov Extends Perfect Record With 'amazing' Win Over Paul
----------------------------------------------------------------------

 ![Usman Nurmagomedov extends perfect record with 'amazing' win over Paul](https://www.thenationalnews.com/resizer/v2/U2FCUNFAPRF25BZACFHECKACGM.jpg?auth=70773c6b29c05da0008b983da71eb337425d8b2a204af93e663530d5cc8160fa) <small>www.thenationalnews.com</small>Usman Nurmagomedov extends perfect record with 'amazing' win over Paul ...

Usman Nurmagomedov Vs. Paul Hughes 2 Full Fight Video Highlights | MMA
----------------------------------------------------------------------

 ![Usman Nurmagomedov vs. Paul Hughes 2 full fight video highlights | MMA](https://platform.mmafighting.com/wp-content/uploads/sites/109/2025/10/PFL_20251003_CK-8850_4577e3.jpg?quality=90&strip=all&crop=16.648381788261%2C0%2C66.703236423478%2C100&w=1200) <small>www.mmafighting.com</small>Usman Nurmagomedov vs. Paul Hughes 2 full fight video highlights | MMA ...

Usman Nurmagomedov Wins Another Instant Classic Against Paul Hughes In
----------------------------------------------------------------------

 ![Usman Nurmagomedov wins another instant classic against Paul Hughes in](https://platform.mmafighting.com/wp-content/uploads/sites/109/2025/10/PFL_20251003_CK-8466.jpg?quality=90&strip=all&crop=15.891350538261%2C0%2C66.703236423478%2C100&w=2048) <small>www.mmafighting.com</small>Usman Nurmagomedov wins another instant classic against Paul Hughes in ...

Usman Nurmagomedov Retains Lightweight Title With Dominant Decision
-------------------------------------------------------------------

 ![Usman Nurmagomedov Retains Lightweight Title with Dominant Decision](https://middleeasy.com/wp-content/uploads/2024/09/Usman-Nurmagomedov-vs-Alexander-Shabliy-Bellator-San-Diego-Results-Highlights.jpg) <small>middleeasy.com</small>Usman Nurmagomedov Retains Lightweight Title with Dominant Decision ...

Usman Nurmagomedov “The Road To Bellator” Usman Nurmagomedov Highlights
-----------------------------------------------------------------------

 ![Usman Nurmagomedov “The Road to Bellator” Usman Nurmagomedov highlights](https://i.ytimg.com/vi/ap9TVAMtVQM/maxresdefault.jpg) <small>www.youtube.com</small>Usman Nurmagomedov “The Road to Bellator” Usman Nurmagomedov highlights ...

Can He Remain UNDEFEATED?🤔 | Usman Nurmagomedov Highlights | Bellator
---------------------------------------------------------------------

 ![Can He Remain UNDEFEATED?🤔 | Usman Nurmagomedov Highlights | Bellator](https://i.ytimg.com/vi/Vdt6yPBHcfo/maxresdefault.jpg) <small>www.youtube.com</small>Can He Remain UNDEFEATED?🤔 | Usman Nurmagomedov Highlights | Bellator ...

Usman Nurmagomedov Vs. Paul Hughes 2 | PFL Dubai Fight Highlights - YouTube
---------------------------------------------------------------------------

 ![Usman Nurmagomedov vs. Paul Hughes 2 | PFL Dubai Fight Highlights - YouTube](https://i.ytimg.com/vi/temT8MRtW9U/maxresdefault.jpg) <small>www.youtube.com</small>Usman Nurmagomedov vs. Paul Hughes 2 | PFL Dubai Fight Highlights - YouTube

Bellator Champions Series: Usman Nurmagomedov Retains Lightweight Title
-----------------------------------------------------------------------

 ![Bellator Champions Series: Usman Nurmagomedov retains lightweight title](https://blogs.rdxsports.com/wp-content/uploads/2024/09/usman-nurmagomedov-2.jpg) <small>blogs.rdxsports.com</small>Bellator Champions Series: Usman Nurmagomedov retains lightweight title ...

Usman Nurmagomedov To Defend PFL Title Against Britain’s Alfie Davis
--------------------------------------------------------------------

 ![Usman Nurmagomedov to defend PFL title against Britain’s Alfie Davis](https://s.yimg.com/ny/api/res/1.2/nJ5J.gaYbHrGp.zqSsmWlA--/YXBwaWQ9aGlnaGxhbmRlcjt3PTk2MDtoPTY0MDtjZj13ZWJw/https://media.zenfs.com/en/the_independent_577/0708cee0ea909ae7ed50421002d302c7) <small>sports.yahoo.com</small>Usman Nurmagomedov to defend PFL title against Britain’s Alfie Davis ...

What Was Islam Makhachev’s Role In Usman Nurmagomedov’s Triumph Over
--------------------------------------------------------------------

 ![What was Islam Makhachev’s role in Usman Nurmagomedov’s triumph over](https://staticg.sportskeeda.com/editor/2023/03/411d0-16785562346783-1920.jpg) <small>www.sportskeeda.com</small>What was Islam Makhachev’s role in Usman Nurmagomedov’s triumph over ...

Usman Nurmagomedov Becomes 1st Dagestani Bellator Champ After
-------------------------------------------------------------

 ![Usman Nurmagomedov Becomes 1st Dagestani Bellator Champ After](https://middleeasy.com/wp-content/uploads/2022/11/Collage-Maker-18-Nov-2022-08-23-PM-870x489.jpg) <small>middleeasy.com</small>Usman Nurmagomedov Becomes 1st Dagestani Bellator Champ After ...

Bellator Announces Usman Nurmagomedov Vs. Paul Hughes For "Dagestan Vs
----------------------------------------------------------------------

 ![Bellator announces Usman Nurmagomedov vs. Paul Hughes for "Dagestan vs](https://www.bjpenn.com/wp-content/uploads/2024/09/Paul-Hughes-Usman-Nurmagomedov.jpg) <small>www.bjpenn.com</small>Bellator announces Usman Nurmagomedov vs. Paul Hughes for "Dagestan vs ...

Usman Nurmagomedov Secures Victory Over Paul Hughes In Bloody Clash At
----------------------------------------------------------------------

 ![Usman Nurmagomedov Secures Victory Over Paul Hughes in Bloody Clash at](https://middleeasy.com/wp-content/uploads/2025/01/Usman-Nurmagomedov-PFL-Dubai-870x489.jpg) <small>middleeasy.com</small>Usman Nurmagomedov Secures Victory Over Paul Hughes in Bloody Clash at ...

Usman Nurmagomedov Vs Paul Hughes - Bellator Lightweight Title Fight
--------------------------------------------------------------------

 ![Usman Nurmagomedov vs Paul Hughes - Bellator lightweight title fight](https://ichef.bbci.co.uk/ace/standard/1024/cpsprodpb/d9a9/live/9e928fc0-db70-11ef-902e-cf9b84dc1357.jpg) <small>www.bbc.co.uk</small>Usman Nurmagomedov vs Paul Hughes - Bellator lightweight title fight ...

PFL: Usman Nurmagomedov Once Again Defeats Paul Hughes And Retains The
----------------------------------------------------------------------

 ![PFL: Usman Nurmagomedov once again defeats Paul Hughes and retains the](https://images.daznservices.com/di/library/DAZN_News/fe/9a/usman-nurmagomedov-10032025-ftr_ujwprztz0atd1793p065k2wxy.png?t=-1406537495) <small>www.dazn.com</small>PFL: Usman Nurmagomedov once again defeats Paul Hughes and retains the ...

Bellator 292 Highlights: Usman Nurmagomedov Submits Benson Henderson
--------------------------------------------------------------------

 ![Bellator 292 Highlights: Usman Nurmagomedov submits Benson Henderson](https://i.ytimg.com/vi/zDp-fhS6RFk/maxresdefault.jpg) <small>www.youtube.com</small>Bellator 292 Highlights: Usman Nurmagomedov submits Benson Henderson ...

Usman Nurmagomedov Vs. Brent Primus Highlights – HYSK
-----------------------------------------------------

 ![Usman Nurmagomedov Vs. Brent Primus Highlights – HYSK](https://medias.lequipe.fr/img-photo-jpg/face-off-usman-nurmagomedov-left-vs-brent-primus-right-for-the-lightweight-world-grand-prix-alexis-g/1500000001844389/0:0,1332:1332-640-640-75/2f095.jpg) <small>dr-kappner.de</small>Usman Nurmagomedov Vs. Brent Primus Highlights – HYSK

Bellator San Diego: Usman Nurmagomedov Retains Lightweight Title By
-------------------------------------------------------------------

 ![Bellator San Diego: Usman Nurmagomedov retains lightweight title by](https://ichef.bbci.co.uk/ace/standard/3840/cpsprodpb/ca11/live/122e9360-6dc2-11ef-a713-d96a32d18a4e.jpg) <small>www.bbc.co.uk</small>Bellator San Diego: Usman Nurmagomedov retains lightweight title by ...

Nurmagomedov Vs Hughes 2: Watch MMA Highlights Of Usman Nurmagomedov's
----------------------------------------------------------------------

 ![Nurmagomedov vs Hughes 2: Watch MMA highlights of Usman Nurmagomedov's](https://ichef.bbci.co.uk/ace/standard/1024/cpsprodpb/e6a3/live/ddc9a210-a12b-11f0-928c-71dbb8619e94.jpg) <small>www.bbc.co.uk</small>Nurmagomedov vs Hughes 2: Watch MMA highlights of Usman Nurmagomedov's ...

Nurmagomedov Vs Shabliy Set For Sept 07 Event In San Diego
----------------------------------------------------------

 ![Nurmagomedov vs Shabliy Set for Sept 07 Event in San Diego](https://cagesidepress.com/wp-content/uploads/2022/11/Usman-champ.jpg) <small>cagesidepress.com</small>Nurmagomedov vs Shabliy Set for Sept 07 Event in San Diego

MMA: Usman Nurmagomedov 'didn't Want Rematch' - Paul Hughes - BBC Sport
-----------------------------------------------------------------------

 ![MMA: Usman Nurmagomedov 'didn't want rematch' - Paul Hughes - BBC Sport](https://ichef.bbci.co.uk/ace/standard/1024/cpsprodpb/ba35/live/9ad73700-7f67-11f0-9b45-d97edf6817de.jpg) <small>www.bbc.com</small>MMA: Usman Nurmagomedov 'didn't want rematch' - Paul Hughes - BBC Sport

Usman Nurmagomedov | Lightweight (155)
--------------------------------------

 ![Usman Nurmagomedov | Lightweight (155)](https://pflmma-prod.s3.amazonaws.com/videos/thumbnails/2756ae5eda44e1ff5aa82fa3676079a9.jpg) <small>pflmma.com</small>Usman Nurmagomedov | Lightweight (155)

Pfl dubai results: usman nurmagomedov defends lightweight title after. Bellator announces usman nurmagomedov vs. paul hughes for "dagestan vs. 2025 champions series: usman nurmagomedov vs paul hughes
