---
title: "Juventus Last 5 Matches - Italian giants juventus report loss of 2.5 million euros in first half"
description: "juventus hold off roma for victory in last game of 2023"
date: "2026-01-28"
categories:
- "Uncategorized"
images:
- "https://d4f7y6nbupj5z.cloudfront.net/wp-content/uploads/2022/10/Juventus-1-2.jpg"
featuredImage: "https://i.ytimg.com/vi/5YBKL_7KwwM/maxresdefault.jpg"
featured_image: "https://i.ytimg.com/vi/djaXvfT3N24/oar2.jpg?sqp=-oaymwEYCJwEENAFSFqQAgHyq4qpAwcIARUAAIhC&amp;rs=AOn4CLBJsb7iDYxh5aooKHnGwP76XlDNcQ"
image: "https://www.juventus.com/images/image/private/t_editorial_landscape_12_desktop/dev/qpafebut5xytkvkqg233.jpg"
---

If you are looking for Juventus - Bologna | The last match at the Allianz Stadium Video | Juventus you've came to the right page. We have 35 Pictures about Juventus - Bologna | The last match at the Allianz Stadium Video | Juventus like Juventus have picked up 11 points from their last five Serie A matches, Juventus Take Advantage of Atalanta Slip, Salernitana in Covid and also Juventus - Bologna | The last match at the Allianz Stadium Video | Juventus. Here it is:

Juventus - Bologna | The Last Match At The Allianz Stadium Video | Juventus
---------------------------------------------------------------------------

 ![Juventus - Bologna | The last match at the Allianz Stadium Video | Juventus](https://www.juventus.com/images/image/private/t_editorial_landscape_8_desktop_mobile/f_auto/v1661874635/dev/tgzsesvzsvazzqvsmred.jpg) <small>www.juventus.com</small>Juventus - Bologna | The last match at the Allianz Stadium Video | Juventus

Five Matches In Amsterdam - Juventus
------------------------------------

 ![Five matches in Amsterdam - Juventus](https://www.juventus.com/images/image/private/t_editorial_landscape_12_desktop/f_auto/dev/gcounywzl4qewrjd9dxt.jpg) <small>www.juventus.com</small>Five matches in Amsterdam - Juventus

Champions League: Juventus Vs Borussia Dortmund - Probable Line-ups And
-----------------------------------------------------------------------

 ![Champions League: Juventus vs Borussia Dortmund - probable line-ups and](https://icdn.football-italia.net/wp-content/uploads/2025/08/Kenan-Yildiz-and-Jonathan-David-celebrate-Juventus-Parma.jpg) <small>football-italia.net</small>Champions League: Juventus vs Borussia Dortmund - probable line-ups and ...

Juventus Have Picked Up 11 Points From Their Last Five Serie A Matches
----------------------------------------------------------------------

 ![Juventus have picked up 11 points from their last five Serie A matches](https://pictures.tribuna.com/image/1138a3d4-6ca9-41f8-bbfa-12107338ccb0?width=1920&quality=70) <small>tribuna.com</small>Juventus have picked up 11 points from their last five Serie A matches ...

Juventus' Serie A Title Hopes Fading After Draw. Napoli Winless In 5
--------------------------------------------------------------------

 ![Juventus' Serie A title hopes fading after draw. Napoli winless in 5](https://cdn.newsday.com/ace/c:ZDYxMDhmMDAtOTc4OS00:MDAtOTc4OS00Njc5NzVl/landscape/1280) <small>www.newsday.com</small>Juventus' Serie A title hopes fading after draw. Napoli winless in 5 ...

Juventus Claim First Win Of 2025 With Impressive Victory Over AC Milan
----------------------------------------------------------------------

 ![Juventus claim first win of 2025 with impressive victory over AC Milan](https://livesport-ott-images.ssl.cdn.cra.cz/r900xfq60/d5f56995-a183-41ef-a399-7e2fb1dd2d08.jpg) <small>www.flashscore.com</small>Juventus claim first win of 2025 with impressive victory over AC Milan ...

Juventus Vs AS Roma – Match Preview And Team News
-------------------------------------------------

 ![Juventus vs AS Roma – Match preview and team news](https://thefootballfaithful.com/wp-content/uploads/2025/11/BodoGlimt-vs-Juventus-–-Match-preview-and-team-news-scaled.jpg) <small>thefootballfaithful.com</small>Juventus vs AS Roma – Match preview and team news

News | Juventus.com
-------------------

 ![News | Juventus.com](https://www.juventus.com/images/image/private/t_editorial_landscape_12_desktop/dev/rrvbkryn9oxyvwnckrqf.jpg) <small>www.juventus.com</small>News | Juventus.com

Juventus Hold Off Roma For Victory In Last Game Of 2023 - Black &amp; White
---------------------------------------------------------------------------

 ![Juventus hold off Roma for victory in last game of 2023 - Black & White](https://cdn.vox-cdn.com/thumbor/aoxMQX8AZ6130DAKpIYeeDfvVdU=/0x0:3500x2334/1200x800/filters:focal(943x452:1503x1012)/cdn.vox-cdn.com/uploads/chorus_image/image/73011308/1895463594.0.jpg) <small>www.blackwhitereadallover.com</small>Juventus hold off Roma for victory in last game of 2023 - Black &amp; White ...

Last 5 Juventus - Barcelona Matches #calcio #messi #ronaldo #juventus #
-----------------------------------------------------------------------

 ![Last 5 Juventus - Barcelona matches #calcio #messi #ronaldo #juventus #](https://i.ytimg.com/vi/djaXvfT3N24/oar2.jpg?sqp=-oaymwEYCJwEENAFSFqQAgHyq4qpAwcIARUAAIhC&rs=AOn4CLBJsb7iDYxh5aooKHnGwP76XlDNcQ) <small>www.youtube.com</small>Last 5 Juventus - Barcelona matches #calcio #messi #ronaldo #juventus # ...

Serie A | Juventus-Udinese | Il Tabellino - Juventus
----------------------------------------------------

 ![Serie A | Juventus-Udinese | Il tabellino - Juventus](https://www.juventus.com/images/image/private/t_editorial_landscape_12_desktop/dev/jmm372q18gniy1dxjler.jpg) <small>www.juventus.com</small>Serie A | Juventus-Udinese | Il tabellino - Juventus

Official: Juventus Will Be Playing In Five Competitions Next Season
-------------------------------------------------------------------

 ![Official: Juventus will be playing in five competitions next season](https://i.redd.it/lch1zu1s720d1.jpeg) <small>www.reddit.com</small>Official: Juventus will be playing in five competitions next season ...

Every Possible Juventus, Roma And Lazio Outcome In Champions League
-------------------------------------------------------------------

 ![Every possible Juventus, Roma and Lazio outcome in Champions League](https://icdn.football-italia.net/wp-content/uploads/2025/05/juventus-v-udinese-serie-a.jpg) <small>football-italia.net</small>Every possible Juventus, Roma and Lazio outcome in Champions League ...

15 Years Ago, Nedved's Final Game For Juventus - Juventus
---------------------------------------------------------

 ![15 years ago, Nedved's final game for Juventus - Juventus](https://www.juventus.com/images/image/private/t_editorial_landscape_12_desktop/v1717146436/dev/do8fpodabdxzqsw4mc7s.jpg) <small>www.juventus.com</small>15 years ago, Nedved's final game for Juventus - Juventus

Best Juventus F.C. Posts - Reddit
---------------------------------

 ![Best Juventus F.C. Posts - Reddit](https://i.redd.it/gxkfsehzq41d1.jpeg) <small>www.reddit.com</small>Best Juventus F.C. Posts - Reddit

Cristiano Ronaldo ⚽ Last Match For Juventus - YouTube
-----------------------------------------------------

 ![Cristiano Ronaldo ⚽ Last Match for Juventus - YouTube](https://i.ytimg.com/vi/5YBKL_7KwwM/maxresdefault.jpg) <small>www.youtube.com</small>Cristiano Ronaldo ⚽ Last Match for Juventus - YouTube

Juventus Dominates PSV Eindhoven In UCL Opener - Juventus
---------------------------------------------------------

 ![Juventus dominates PSV Eindhoven in UCL opener - Juventus](https://www.juventus.com/images/image/private/t_editorial_landscape_12_desktop/dev/loyktnztfzljtoeyk0rz.jpg) <small>www.juventus.com</small>Juventus dominates PSV Eindhoven in UCL opener - Juventus

Serie A Preview: Roma Look To Cement Title Credentials At Juventus In
---------------------------------------------------------------------

 ![Serie A preview: Roma look to cement title credentials at Juventus in](https://i.dailymail.co.uk/1s/2022/08/26/16/61750763-11145357-Juventus_have_had_the_better_of_the_head_to_head_between_the_tea-a-5_1661528805420.jpg) <small>www.dailymail.com</small>Serie A preview: Roma look to cement title credentials at Juventus in ...

Serie A Champions League Race: Difficulty Rating For Remaining Juventus
-----------------------------------------------------------------------

 ![Serie A Champions League race: Difficulty rating for remaining Juventus](https://icdn.football-italia.net/wp-content/uploads/2025/04/Juventus-Lecce-hugs-1024x683.jpg) <small>football-italia.net</small>Serie A Champions League race: Difficulty rating for remaining Juventus ...

Real Madrid Vs Juventus: Five Classic Matches
---------------------------------------------

 ![Real Madrid vs Juventus: Five classic matches](https://thefootballfaithful.com/wp-content/uploads/2025/10/Real-Madrid-vs-Juventus-Five-classic-matches-scaled.jpg) <small>thefootballfaithful.com</small>Real Madrid vs Juventus: Five classic matches

Pre Season: Juventus Vs. Next Gen - Probable Line-ups And Where To
------------------------------------------------------------------

 ![Pre season: Juventus vs. Next Gen - Probable line-ups and where to](https://icdn.football-italia.net/wp-content/uploads/2025/06/Teun-Koopmeiners-celebrate-Juventus-Manchester-City.jpg) <small>football-italia.net</small>Pre season: Juventus vs. Next Gen - Probable line-ups and where to ...

A Season In 5 Matches - Juventus
--------------------------------

 ![A season in 5 matches - Juventus](https://www.juventus.com/images/image/private/t_editorial_landscape_12_desktop/dev/oi7pnfqk9eu2bn6ut1hf.jpg) <small>www.juventus.com</small>A season in 5 matches - Juventus

Top 5 Matches 2022/23 | Men's First Team - Juventus
---------------------------------------------------

 ![Top 5 Matches 2022/23 | Men's First Team - Juventus](https://www.juventus.com/images/image/private/t_editorial_landscape_12_desktop/dev/qpafebut5xytkvkqg233.jpg) <small>www.juventus.com</small>Top 5 Matches 2022/23 | Men's First Team - Juventus

Juventus-Como | Il Tabellino - Juventus
---------------------------------------

 ![Juventus-Como | Il tabellino - Juventus](https://www.juventus.com/images/image/private/t_editorial_landscape_12_desktop/dev/urdvlcxskl80xzylscp0.jpg) <small>www.juventus.com</small>Juventus-Como | Il tabellino - Juventus

News | Juventus.com
-------------------

 ![News | Juventus.com](https://www.juventus.com/images/image/private/t_portrait_mobile/f_auto/dev/iliyy7j01hi09gfy0iou.jpg) <small>www.juventus.com</small>News | Juventus.com

\#FlashbackFriday: The Five Last Games Between Juventus And Sassuolo
--------------------------------------------------------------------

 ![#FlashbackFriday: The Five Last Games Between Juventus and Sassuolo](https://www.juventus.com/images/image/private/t_editorial_landscape_12_desktop/dev/iliyy7j01hi09gfy0iou.jpg) <small>www.juventus.com</small>\#FlashbackFriday: The Five Last Games Between Juventus and Sassuolo ...

Juve Demolish Dortmund To Ease Into Last Eight - The Namibian
-------------------------------------------------------------

 ![Juve demolish Dortmund to ease into last eight - The Namibian](https://d4f7y6nbupj5z.cloudfront.net/wp-content/uploads/2022/10/Juventus-1-2.jpg) <small>www.namibian.com.na</small>Juve demolish Dortmund to ease into last eight - The Namibian

Juventus Take Advantage Of Atalanta Slip, Salernitana In Covid
--------------------------------------------------------------

 ![Juventus Take Advantage of Atalanta Slip, Salernitana in Covid](https://images.news18.com/ibnlive/uploads/2021/12/juventus-16401460344x3.jpg?impolicy=website&width=640&height=480) <small>www.news18.com</small>Juventus Take Advantage of Atalanta Slip, Salernitana in Covid ...

Italian Giants Juventus Report Loss Of 2.5 Million Euros In First Half
----------------------------------------------------------------------

 ![Italian giants Juventus report loss of 2.5 million euros in first half](https://livesport-ott-images.ssl.cdn.cra.cz/r900xfq60/b02cd1d1-0706-4f1f-93a2-aae7dc65390e.jpg) <small>www.tribalfootball.com</small>Italian giants Juventus report loss of 2.5 million euros in first half ...

Top 5 Matches 2023/24 - Juventus
--------------------------------

 ![Top 5 Matches 2023/24 - Juventus](https://www.juventus.com/images/image/private/t_editorial_landscape_12_desktop/v1715810870/dev/jx2ojs2gnybpqots8w2x.jpg) <small>www.juventus.com</small>Top 5 Matches 2023/24 - Juventus

What Juventus Need To Secure Champions League Play-off Spot After 3-2
---------------------------------------------------------------------

 ![What Juventus need to secure Champions League play-off spot after 3-2](https://icdn.football-italia.net/wp-content/uploads/2025/11/Juventus-celebrate-Fiorentina.jpg) <small>football-italia.net</small>What Juventus need to secure Champions League play-off spot after 3-2 ...

Juventus Vs Genoa, Formazioni Ufficiali: Allegri Ha Preso Una Decisione
-----------------------------------------------------------------------

 ![Juventus vs Genoa, formazioni ufficiali: Allegri ha preso una decisione](https://pictures.tribuna.com/image/ab2359a8-68c9-4593-b3cc-e010413b23b9?width=1920&quality=70) <small>tribuna.com</small>Juventus vs Genoa, formazioni ufficiali: Allegri ha preso una decisione ...

Juventus Score Twice In Last Five Minutes To Sink 10-man Inter
--------------------------------------------------------------

 ![Juventus score twice in last five minutes to sink 10-man Inter](https://img.onmanorama.com/content/dam/mm/en/sports/football/images/2018/4/29/juventus-milan.jpg) <small>www.onmanorama.com</small>Juventus score twice in last five minutes to sink 10-man Inter ...

Newspapers Give Damning Verdict Of Juventus After 5-2 Champions League
----------------------------------------------------------------------

 ![Newspapers give damning verdict of Juventus after 5-2 Champions League](https://icdn.football-italia.net/wp-content/uploads/2026/02/Juventus-XI.jpg) <small>football-italia.net</small>Newspapers give damning verdict of Juventus after 5-2 Champions League ...

Opinion: Ranking The Last Five Players To Wear The Number 5 At Juventus
-----------------------------------------------------------------------

 ![Opinion: Ranking the last five players to wear the number 5 at Juventus](https://www.juvefc.com/wp-content/uploads/2016/07/welcome.jpg) <small>www.juvefc.com</small>Opinion: Ranking the last five players to wear the number 5 at Juventus ...

Juve demolish dortmund to ease into last eight. Last 5 juventus. Juventus hold off roma for victory in last game of 2023
