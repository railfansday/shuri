---
title: "Usman Nurmagomedov Bellator - Usman nurmagomedov dominates primus to secure win at bellator 300"
description: "Bellator 300 results &amp; highlights: nurmagomedov dominates primus"
date: "2025-12-22"
categories:
- "Uncategorized"
images:
- "https://media.gettyimages.com/id/1713903474/photo/san-diego-ca-usman-nurmagomedov-speaks-with-the-media-at-the-bellator-300-post-fight-press.jpg?s=612x612&amp;w=gi&amp;k=20&amp;c=q1Dw0qdEKoEhC-Q9SZ-enmwvoAppaNi2wA27Ur_YSv8="
featuredImage: "https://mmajunkie.usatoday.com/gcdn/authoring/images/smg/2025/02/26/SMMA/80450940007-91-2685056.jpeg?crop=999,563,x0,y18&amp;width=999&amp;height=563&amp;format=pjpg&amp;auto=webp"
featured_image: "https://jitsmagazine.com/wp-content/uploads/2022/11/Usman-Nurmagomedov-Bellator-Champion-416x375.png"
image: "https://i.ytimg.com/vi/epmzsrsChD4/maxresdefault.jpg"
---

If you are searching about Usman Nurmagomedov not resting on his laurels after another flawless you've visit to the right page. We have 35 Images about Usman Nurmagomedov not resting on his laurels after another flawless like Bellator 300 Main Card Photo Gallery - MMAWeekly.com | UFC and MMA News, Bellator 300 Results: Usman Nurmagomedov defeats Brent Primus and also Bellator 300 date, time, channel, odds &amp; card for Usman Nurmagomedov vs. Here it is:

Usman Nurmagomedov Not Resting On His Laurels After Another Flawless
--------------------------------------------------------------------

 ![Usman Nurmagomedov not resting on his laurels after another flawless](https://mmajunkie.usatoday.com/gcdn/authoring/images/smg/2025/02/26/SMMA/80438125007-91-2686284.jpeg?crop=999,563,x0,y18&width=999&height=563&format=pjpg&auto=webp) <small>mmajunkie.usatoday.com</small>Usman Nurmagomedov not resting on his laurels after another flawless ...

Primo De Khabib, Usman Nurmagomedov Faz Luta Segura E Defende Título
--------------------------------------------------------------------

 ![Primo De Khabib, Usman Nurmagomedov Faz Luta Segura E Defende Título](https://www.superlutas.com.br/wp-content/uploads/2023/10/usman-nurmagomedov-1.jpg) <small>www.superlutas.com.br</small>Primo De Khabib, Usman Nurmagomedov Faz Luta Segura E Defende Título ...

PREVIEW 🔥🔥🔥 BELLATOR 300 | 🇷🇺 USMAN NURMAGOMEDOV VS 🇺🇸 BRENT PRIMUS | #
-----------------------------------------------------------------------

 ![PREVIEW 🔥🔥🔥 BELLATOR 300 | 🇷🇺 USMAN NURMAGOMEDOV VS 🇺🇸 BRENT PRIMUS | #](https://i.ytimg.com/vi/3NERAZ1UCJE/maxresdefault.jpg) <small>www.youtube.com</small>PREVIEW 🔥🔥🔥 BELLATOR 300 | 🇷🇺 USMAN NURMAGOMEDOV VS 🇺🇸 BRENT PRIMUS | # ...

Usman Nurmagomedov Vs. Brent Primus Highlights | Bellator 300 | ESPN
--------------------------------------------------------------------

 ![Usman Nurmagomedov vs. Brent Primus Highlights | Bellator 300 | ESPN](https://i.ytimg.com/vi/pi11QYc1zOs/maxresdefault.jpg) <small>www.youtube.com</small>Usman Nurmagomedov vs. Brent Primus Highlights | Bellator 300 | ESPN ...

Bellator 300 Results: Usman Nurmagomedov Defeats Brent Primus
-------------------------------------------------------------

 ![Bellator 300 Results: Usman Nurmagomedov defeats Brent Primus](https://www.bjpenn.com/wp-content/uploads/2023/08/Usman-Nurmagomedov-Bellator-300.jpg) <small>www.bjpenn.com</small>Bellator 300 Results: Usman Nurmagomedov defeats Brent Primus ...

Bellator 300 Results &amp; Highlights: Nurmagomedov Dominates Primus
--------------------------------------------------------------------

 ![Bellator 300 Results & Highlights: Nurmagomedov Dominates Primus](https://www.si.com/.image/t_share/MjAxMzE1MDQwNjg1NDY3NDgw/f7y0zjgauaa0fuq.jpg) <small>www.si.com</small>Bellator 300 Results &amp; Highlights: Nurmagomedov Dominates Primus ...

Usman Nurmagomedov Dominates Primus To Secure Win At Bellator 300
-----------------------------------------------------------------

 ![Usman Nurmagomedov dominates Primus to secure win at Bellator 300](https://calfkicker.com/wp-content/uploads/2023/10/a-30.jpg) <small>calfkicker.com</small>Usman Nurmagomedov dominates Primus to secure win at Bellator 300

Bellator 300 Main Card Photo Gallery - MMAWeekly.com | UFC And MMA News
-----------------------------------------------------------------------

 ![Bellator 300 Main Card Photo Gallery - MMAWeekly.com | UFC and MMA News](https://www.mmaweekly.com/.image/t_share/MjAxMzU0MjY0NzQyNzk5MzMz/usman-nurmagomedov-vs-brent-primus-bellator-300-16.jpg) <small>www.mmaweekly.com</small>Bellator 300 Main Card Photo Gallery - MMAWeekly.com | UFC and MMA News ...

Usman Nurmagomedov Vs Brent Primus (Lightweight Title Bout) | Bellator
----------------------------------------------------------------------

 ![Usman Nurmagomedov vs Brent Primus (Lightweight Title Bout) | Bellator](https://i.ytimg.com/vi/epmzsrsChD4/maxresdefault.jpg) <small>www.youtube.com</small>Usman Nurmagomedov vs Brent Primus (Lightweight Title Bout) | Bellator ...

Bellator 300 Date, Time, Channel, Odds &amp; Card For Usman Nurmagomedov Vs
---------------------------------------------------------------------------

 ![Bellator 300 date, time, channel, odds & card for Usman Nurmagomedov vs](https://library.sportingnews.com/styles/crop_style_16_9_desktop_webp/s3/2023-09/Usman Nurmagomedov - Bellator 09282023.jpg.webp?itok=i9WL3Uto) <small>www.sportingnews.com</small>Bellator 300 date, time, channel, odds &amp; card for Usman Nurmagomedov vs ...

Usman Nurmagomedov And Brent Primus Both Confident Of Victory Ahead Of
----------------------------------------------------------------------

 ![Usman Nurmagomedov and Brent Primus both confident of victory ahead of](https://www.fightersonlymag.com/wp-content/uploads/2023/10/usman-nurmagomedov-brent-primus.jpg) <small>www.fightersonlymag.com</small>Usman Nurmagomedov and Brent Primus both confident of victory ahead of ...

Bellator 300: Usman Nurmagomedov Outclasses Brent Primus To Retain
------------------------------------------------------------------

 ![Bellator 300: Usman Nurmagomedov outclasses Brent Primus to retain](https://ichef.bbci.co.uk/ace/branded_sport/1200/cpsprodpb/E5C0/production/_131361885_img_7523.jpg) <small>www.bbc.com</small>Bellator 300: Usman Nurmagomedov outclasses Brent Primus to retain ...

Usman Nurmagomedov Remains Undefeated With Domination Of Brent Primus
---------------------------------------------------------------------

 ![Usman Nurmagomedov Remains Undefeated With Domination Of Brent Primus](https://middleeasy.com/wp-content/uploads/2023/10/usman-win.jpg) <small>middleeasy.com</small>Usman Nurmagomedov Remains Undefeated With Domination Of Brent Primus ...

Usman Nurmagomedov Vs Brent Primus - MMA - Combat - Boxemag.com
---------------------------------------------------------------

 ![Usman Nurmagomedov vs Brent Primus - MMA - Combat - Boxemag.com](https://boxemag.ouest-france.fr/wp-content/uploads/2023/08/bellator-300-poster.jpg) <small>boxemag.ouest-france.fr</small>Usman Nurmagomedov vs Brent Primus - MMA - Combat - Boxemag.com

Bellator Champions Series: Usman Nurmagomedov Retains Lightweight Title
-----------------------------------------------------------------------

 ![Bellator Champions Series: Usman Nurmagomedov retains lightweight title](https://blogs.rdxsports.com/wp-content/uploads/2024/09/usman-nurmagomedov-1024x576.jpg) <small>blogs.rdxsports.com</small>Bellator Champions Series: Usman Nurmagomedov retains lightweight title ...

Usman Nurmagomedov Dominates Brent Primus In Bellator 300 Main Event
--------------------------------------------------------------------

 ![Usman Nurmagomedov Dominates Brent Primus In Bellator 300 Main Event](https://pbs.twimg.com/media/F7zODwdbwAAANlr?format=jpg&name=large) <small>www.fightsports.tv</small>Usman Nurmagomedov Dominates Brent Primus In Bellator 300 Main Event ...

San Diego, Ca, USA. 07th Oct, 2023. SAN DIEGO, CALIFORNIA - October 7
---------------------------------------------------------------------

 ![San Diego, Ca, USA. 07th Oct, 2023. SAN DIEGO, CALIFORNIA - October 7](https://c8.alamy.com/comp/2T0P4XP/san-diego-ca-usa-07th-oct-2023-san-diego-california-october-7-r-l-usman-nurmagomedov-defends-his-bellator-lightweight-title-and-advances-to-the-final-of-the-bellator-lightweight-grand-prix-san-diego-california-united-states-photo-by-matt-daviespximages-credit-px-imagesalamy-live-news-2T0P4XP.jpg) <small>www.alamy.com</small>San Diego, Ca, USA. 07th Oct, 2023. SAN DIEGO, CALIFORNIA - October 7 ...

Bellator 300 Video: Unbeaten Champion Usman Nurmagomedov Squares Off
--------------------------------------------------------------------

 ![Bellator 300 video: Unbeaten champion Usman Nurmagomedov squares off](https://mmajunkie.usatoday.com/gcdn/authoring/images/smg/2025/02/26/SMMA/80450940007-91-2685056.jpeg?crop=999,563,x0,y18&width=999&height=563&format=pjpg&auto=webp) <small>mmajunkie.usatoday.com</small>Bellator 300 video: Unbeaten champion Usman Nurmagomedov squares off ...

Bellator 292 Complete Results, Video Highlights: Nurmagomedov Submits
---------------------------------------------------------------------

 ![Bellator 292 complete results, video highlights: Nurmagomedov submits](https://bloodyelbow.com/wp-content/uploads/1/2024/01/october-7-2023-l-r-lightweight-1035338700-1-1024x682.jpg) <small>bloodyelbow.com</small>Bellator 292 complete results, video highlights: Nurmagomedov submits ...

New Exclusive: Usman Nurmagomedov Excited To Have Cain Velasquez Corner
-----------------------------------------------------------------------

 ![New Exclusive: Usman Nurmagomedov Excited to Have Cain Velasquez Corner](https://citizenside.com/wp-content/uploads/2023/10/new-exclusive-usman-nurmagomedov-excited-to-have-cain-velasquez-corner-bellator-300-fight-1696670122.jpg) <small>citizenside.com</small>New Exclusive: Usman Nurmagomedov Excited to Have Cain Velasquez Corner ...

MMA Community Reacts After Usman Nurmagomedov Defeats Brent Primus At
---------------------------------------------------------------------

 ![MMA community reacts after Usman Nurmagomedov defeats Brent Primus at](https://www.bjpenn.com/wp-content/uploads/2023/10/Usman-Nurmagomedov-Bellator-300-Bellator-MMA-768x476.jpg) <small>www.bjpenn.com</small>MMA community reacts after Usman Nurmagomedov defeats Brent Primus at ...

Bellator 300: Nurmagomedov Retiene Ante Primus | Superluchas
------------------------------------------------------------

 ![Bellator 300: Nurmagomedov retiene ante Primus | Superluchas](https://s3.superluchas.com/2022/11/Usman-Nurmagomedov-600x400.jpg) <small>superluchas.com</small>Bellator 300: Nurmagomedov retiene ante Primus | Superluchas

Bellator 300 Results, Highlights: Usman Nurmagomedov Outclasses Brent
---------------------------------------------------------------------

 ![Bellator 300 results, highlights: Usman Nurmagomedov outclasses Brent](https://sportshub.cbsistatic.com/i/r/2023/10/08/d0f1284f-1902-48a4-8dde-170fdc92ebc1/thumbnail/1200x675/81e5b30cd2e30c1aa10b5e9961268017/usman-nurmagomedov-winner.jpg) <small>www.cbssports.com</small>Bellator 300 results, highlights: Usman Nurmagomedov outclasses Brent ...

Video: Could Bellator Champ Usman Nurmagomedov Be…
--------------------------------------------------

 ![Video: Could Bellator champ Usman Nurmagomedov be…](https://images.inkl.com/s3/article/lead_image/19516074/bellator-300-usman-nurmagomedov-team-scaled.jpg) <small>www.inkl.com</small>Video: Could Bellator champ Usman Nurmagomedov be…

Bellator 300: 'Usman Vs. Primus' Live Results And Highlights | BJPenn.com
-------------------------------------------------------------------------

 ![Bellator 300: 'Usman vs. Primus' Live Results and Highlights | BJPenn.com](https://www.bjpenn.com/wp-content/uploads/2023/10/Bellator-300-Cris-Cyrbog-Umar-Nurmagomedov-Results.jpg) <small>www.bjpenn.com</small>Bellator 300: 'Usman vs. Primus' Live Results and Highlights | BJPenn.com

CSAC Suspends Bellator Champ Usman Nurmagomedov For…
----------------------------------------------------

 ![CSAC suspends Bellator champ Usman Nurmagomedov for…](https://images.inkl.com/s3/article/lead_image/19710491/bellator-300-usman-nurmagomedov-1-scaled.jpg) <small>www.inkl.com</small>CSAC suspends Bellator champ Usman Nurmagomedov for…

60 Usman Nurmagomedov Stock Photos, High-Res Pictures, And Images
-----------------------------------------------------------------

 ![60 Usman Nurmagomedov Stock Photos, High-Res Pictures, and Images](https://media.gettyimages.com/id/1713903474/photo/san-diego-ca-usman-nurmagomedov-speaks-with-the-media-at-the-bellator-300-post-fight-press.jpg?s=612x612&w=gi&k=20&c=q1Dw0qdEKoEhC-Q9SZ-enmwvoAppaNi2wA27Ur_YSv8=) <small>www.gettyimages.com</small>60 Usman Nurmagomedov Stock Photos, High-Res Pictures, and Images ...

Bellator 292 Video: Usman Nurmagomedov Subs Benson Henderson, Bendo Retires
---------------------------------------------------------------------------

 ![Bellator 292 video: Usman Nurmagomedov subs Benson Henderson, Bendo retires](https://bloodyelbow.com/wp-content/uploads/1/2024/01/october-7-2023-l-r-lightweight-1035338699.jpg) <small>bloodyelbow.com</small>Bellator 292 video: Usman Nurmagomedov subs Benson Henderson, Bendo retires

Bellator 300 - Victoire Facile D'Usman Nurmagomedov
---------------------------------------------------

 ![Bellator 300 - Victoire facile d'Usman Nurmagomedov](https://lasueur.com/wp-content/uploads/2023/10/victoire-facile-usman-nurmagomedov-1054x593.jpg) <small>lasueur.com</small>Bellator 300 - Victoire facile d'Usman Nurmagomedov

Usman Nurmagomedov Becomes New Bellator Lightweight Champion
------------------------------------------------------------

 ![Usman Nurmagomedov Becomes New Bellator Lightweight Champion](https://jitsmagazine.com/wp-content/uploads/2022/11/Usman-Nurmagomedov-Bellator-Champion-416x375.png) <small>jitsmagazine.com</small>Usman Nurmagomedov Becomes New Bellator Lightweight Champion ...

Usman Nurmagomedov Defeats Brent Primus By Unanimous Decision At
----------------------------------------------------------------

 ![Usman Nurmagomedov Defeats Brent Primus by Unanimous Decision at](https://legacymedia.sportsplatform.io/image/upload/x_376,y_94,w_654,h_434,c_crop/v1696740422/no1a2kjchzidoxe2qc0y.jpg) <small>bleacherreport.com</small>Usman Nurmagomedov Defeats Brent Primus by Unanimous Decision at ...

60 Usman Nurmagomedov Stock Photos, High-Res Pictures, And Images
-----------------------------------------------------------------

 ![60 Usman Nurmagomedov Stock Photos, High-Res Pictures, and Images](https://media.gettyimages.com/id/1713903093/photo/san-diego-ca-usman-nurmagomedov-speaks-with-the-media-at-the-bellator-300-post-fight-press.jpg?s=612x612&w=gi&k=20&c=t__3EplaI5XpbR0ndgyCZArbpxvcPZpVP3wh75DtR6o=) <small>www.gettyimages.com</small>60 Usman Nurmagomedov Stock Photos, High-Res Pictures, and Images ...

Bellator 300 Results: Nurmagomedov Vs. Primus - MMA Fighting
------------------------------------------------------------

 ![Bellator 300 Results: Nurmagomedov vs. Primus - MMA Fighting](https://cdn.vox-cdn.com/thumbor/azDEK9xJH-Rao1U1bEAu8yemtgI=/0x0:3600x2400/1220x813/filters:focal(1512x912:2088x1488)/cdn.vox-cdn.com/uploads/chorus_image/image/72730606/0078_Usman_Nurmagomedov_vs_Brent_Primus.0.jpg) <small>www.mmafighting.com</small>Bellator 300 Results: Nurmagomedov vs. Primus - MMA Fighting

Bellator Championship Series: Usman Nurmagomedov Retains Title After
--------------------------------------------------------------------

 ![Bellator Championship Series: Usman Nurmagomedov retains title after](https://images.daznservices.com/di/library/DAZN_News/4a/d2/usman-nurmagomedov-vs-alexander-shabliy_nc57ficgfln21c2dwqdvir2k1.jpg?t=-782614623) <small>www.dazn.com</small>Bellator Championship Series: Usman Nurmagomedov retains title after ...

Usman Nurmagomedov Med Mästerlig Insats På Bellator 300
-------------------------------------------------------

 ![Usman Nurmagomedov med mästerlig insats på Bellator 300](https://www.kimura.se/wp-content/uploads/2023/10/Usman-Nurmagomedov.jpg) <small>www.kimura.se</small>Usman Nurmagomedov med mästerlig insats på Bellator 300

Bellator 300 results, highlights: usman nurmagomedov outclasses brent. Bellator 292 video: usman nurmagomedov subs benson henderson, bendo retires. Bellator 300: 'usman vs. primus' live results and highlights
