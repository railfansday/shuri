---
title: "Usman Nurmagomedov Vs Alfie Davis Time - Дикий разнос! полный бой усман нурмагомедов vs алфи дэвис pfl / alfie"
description: "usman nurmagomedov dominates alfie davis to retain pfl lightweight ..."
date: "2025-12-19"
categories:
- "Uncategorized"
images:
- "https://ichef.bbci.co.uk/ace/standard/640/cpsprodpb/vivo/live/images/2026/2/7/9dd9505f-b6d2-491d-b383-aa2131fd097b.png.webp"
featuredImage: "https://ichef.bbci.co.uk/ace/standard/640/cpsprodpb/vivo/live/images/2026/2/7/7e490141-5209-4b04-9e32-034d317e02c1.png.webp"
featured_image: "https://www.thenationalnews.com/resizer/v2/YCXNSBSTUFCNBOKU5MCS5PY5EI.JPG?auth=976dda88cca9c69880074695c3b14926e26c6fc9d0e3a65f549bd7cab03620de"
image: "https://ichef.bbci.co.uk/ace/standard/640/cpsprodpb/vivo/live/images/2026/2/7/4182f023-6644-49d1-9f7a-f3c2fc2d9d03.png.webp"
---

If you are looking for Davis vs Usman Nurmagomedov Fight Card, Date, Venue, How To Watch you've visit to the right page. We have 35 Pictures about Davis vs Usman Nurmagomedov Fight Card, Date, Venue, How To Watch like Usman Nurmagomedov vs Alfie Davis RECAP: Relive Usman Nurmagomedov's, Usman Nurmagomedov vs Alfie Davis RECAP: Relive Usman Nurmagomedov's and also PFL full fight: Usman Nurmagomedov sleeps Alfie Davis in title defense. Here you go:

Davis Vs Usman Nurmagomedov Fight Card, Date, Venue, How To Watch
-----------------------------------------------------------------

 ![Davis vs Usman Nurmagomedov Fight Card, Date, Venue, How To Watch](https://ichef.bbci.co.uk/ace/standard/976/cpsprodpb/c343/live/29feb5b0-c541-11f0-88be-3bc2aea1a256.png.webp) <small>www.sportshistori.com</small>Davis vs Usman Nurmagomedov Fight Card, Date, Venue, How To Watch ...

Usman Nurmagomedov Vs Alfie Davis RECAP: Relive Usman Nurmagomedov's
--------------------------------------------------------------------

 ![Usman Nurmagomedov vs Alfie Davis RECAP: Relive Usman Nurmagomedov's](https://ichef.bbci.co.uk/ace/standard/640/cpsprodpb/vivo/live/images/2026/2/7/db246295-ad03-4b4c-a924-24db871c28e8.png.webp) <small>www.bbc.co.uk</small>Usman Nurmagomedov vs Alfie Davis RECAP: Relive Usman Nurmagomedov's ...

Usman Nurmagomedov Vs Alfie Davis RECAP: Relive Usman Nurmagomedov's
--------------------------------------------------------------------

 ![Usman Nurmagomedov vs Alfie Davis RECAP: Relive Usman Nurmagomedov's](https://ichef.bbci.co.uk/ace/standard/640/cpsprodpb/vivo/live/images/2026/2/7/dbf0662a-74a2-46e3-bb80-86be5a7fcd08.jpg.webp) <small>www.bbc.com</small>Usman Nurmagomedov vs Alfie Davis RECAP: Relive Usman Nurmagomedov's ...

ДИКИЙ РАЗНОС! Полный Бой Усман Нурмагомедов VS Алфи Дэвис PFL / Alfie
---------------------------------------------------------------------

 ![ДИКИЙ РАЗНОС! Полный Бой Усман Нурмагомедов VS Алфи Дэвис PFL / Alfie](https://i.ytimg.com/vi/9hO_Q5Jwxb0/maxresdefault.jpg) <small>www.youtube.com</small>ДИКИЙ РАЗНОС! Полный Бой Усман Нурмагомедов VS Алфи Дэвис PFL / Alfie ...

Usman Nurmagomedov To Defend PFL Title Against Britain’s Alfie Davis
--------------------------------------------------------------------

 ![Usman Nurmagomedov to defend PFL title against Britain’s Alfie Davis](https://static.independent.co.uk/2025/11/20/14/59/Usman-Nurmagomedov.jpeg?quality=75&width=640&auto=webp) <small>www.independent.co.uk</small>Usman Nurmagomedov to defend PFL title against Britain’s Alfie Davis ...

Usman Nurmagomedov Vs Alfie Davis RECAP: Relive Usman Nurmagomedov's
--------------------------------------------------------------------

 ![Usman Nurmagomedov vs Alfie Davis RECAP: Relive Usman Nurmagomedov's](https://ichef.bbci.co.uk/ace/standard/640/cpsprodpb/vivo/live/images/2026/2/7/43e7fc32-f9e1-40aa-ab80-8c8cb164b129.png.webp) <small>www.bbc.co.uk</small>Usman Nurmagomedov vs Alfie Davis RECAP: Relive Usman Nurmagomedov's ...

Usman Nurmagomedov Dominates Alfie Davis To Retain PFL Lightweight
------------------------------------------------------------------

 ![Usman Nurmagomedov dominates Alfie Davis to retain PFL lightweight](https://www.thenationalnews.com/resizer/v2/YK5TYNHM2RFW3NRJ4YCVOK6CHQ.JPG?auth=f7ba41cfdd5635dcccb361c2d0c3c910445b0b7a0177d22cf0c52a90b51750a6) <small>www.thenationalnews.com</small>Usman Nurmagomedov dominates Alfie Davis to retain PFL lightweight ...

Usman Nurmagomedov Vs Alfie Davis RECAP: Relive Usman Nurmagomedov's
--------------------------------------------------------------------

 ![Usman Nurmagomedov vs Alfie Davis RECAP: Relive Usman Nurmagomedov's](https://ichef.bbci.co.uk/ace/standard/1024/cpsprodpb/be1f/live/52513350-0464-11f1-a12b-658d26b020a4.png) <small>www.bbc.co.uk</small>Usman Nurmagomedov vs Alfie Davis RECAP: Relive Usman Nurmagomedov's ...

PFL Champions Series 5 - Nurmagomedov Vs. Davis - La Pesée : Résultats
----------------------------------------------------------------------

 ![PFL Champions Series 5 - Nurmagomedov vs. Davis - La pesée : résultats](https://www.ufc-fr.com/data/actualite/12440/large/pfl-champions-series-5-nurmagomedov-vs-davis-la-pesee-resultats-dubai-photo___ID_2026-02-06-11-40-02_12440.jpg) <small>www.ufc-fr.com</small>PFL Champions Series 5 - Nurmagomedov vs. Davis - La pesée : résultats ...

Usman Nurmagomedov Returns To Dubai To Defend PFL Title Against
---------------------------------------------------------------

 ![Usman Nurmagomedov returns to Dubai to defend PFL title against](https://www.thenationalnews.com/resizer/v2/536S45DL7ZD5ZA5AFLKBDN3JEU.jpg?auth=e827ffb16677555f7a175376c06f6e13ecfc7e2386cdec2c4f5836f306e4591e) <small>www.thenationalnews.com</small>Usman Nurmagomedov returns to Dubai to defend PFL title against ...

PFL Dubai Results: Usman Nurmagomedov Defends Lightweight Title After
---------------------------------------------------------------------

 ![PFL Dubai Results: Usman Nurmagomedov Defends Lightweight Title After](https://middleeasy.com/wp-content/uploads/2026/02/Usman-Nurmagomedov.jpg) <small>middleeasy.com</small>PFL Dubai Results: Usman Nurmagomedov Defends Lightweight Title After ...

Usman Nurmagomedov Dominates Alfie Davis To Retain PFL Lightweight
------------------------------------------------------------------

 ![Usman Nurmagomedov dominates Alfie Davis to retain PFL lightweight](https://www.thenationalnews.com/resizer/v2/YCXNSBSTUFCNBOKU5MCS5PY5EI.JPG?auth=976dda88cca9c69880074695c3b14926e26c6fc9d0e3a65f549bd7cab03620de) <small>www.thenationalnews.com</small>Usman Nurmagomedov dominates Alfie Davis to retain PFL lightweight ...

Usman Nurmagomedov Vs Alfie Davis RECAP: Relive Usman Nurmagomedov's
--------------------------------------------------------------------

 ![Usman Nurmagomedov vs Alfie Davis RECAP: Relive Usman Nurmagomedov's](https://ichef.bbci.co.uk/ace/standard/640/cpsprodpb/vivo/live/images/2026/2/7/9dd9505f-b6d2-491d-b383-aa2131fd097b.png.webp) <small>www.bbc.co.uk</small>Usman Nurmagomedov vs Alfie Davis RECAP: Relive Usman Nurmagomedov's ...

Usman Nurmagomedov Vs Alfie... - Dagestani Fighters Page | Facebook
-------------------------------------------------------------------

 ![Usman Nurmagomedov vs Alfie... - Dagestani fighters page | Facebook](https://lookaside.fbsbx.com/lookaside/crawler/media/?media_id=816840084215970) <small>www.facebook.com</small>Usman Nurmagomedov vs Alfie... - Dagestani fighters page | Facebook

Usman Nurmagomedov Vs Alfie Davis PFL Dubai Full Fight Recap - YouTube
----------------------------------------------------------------------

 ![Usman Nurmagomedov vs Alfie Davis PFL Dubai Full Fight Recap - YouTube](https://i.ytimg.com/vi/HNr_ilvc6TQ/maxresdefault.jpg?sqp=-oaymwEmCIAKENAF8quKqQMa8AEB-AH-CYAC0AWKAgwIABABGGUgZShlMA8=&rs=AOn4CLAyw755UnA3xSP2LNu3FQ4vH4ZOBw) <small>www.youtube.com</small>Usman Nurmagomedov vs Alfie Davis PFL Dubai Full Fight Recap - YouTube

Usman Nurmagomedov Vs Alfie Davis RECAP: Relive Usman Nurmagomedov's
--------------------------------------------------------------------

 ![Usman Nurmagomedov vs Alfie Davis RECAP: Relive Usman Nurmagomedov's](https://ichef.bbci.co.uk/ace/standard/640/cpsprodpb/vivo/live/images/2026/2/7/89ee560a-05ad-4d89-8a2c-6d544736c055.jpg.webp) <small>www.bbc.co.uk</small>Usman Nurmagomedov vs Alfie Davis RECAP: Relive Usman Nurmagomedov's ...

PFL Full Fight: Usman Nurmagomedov Sleeps Alfie Davis In Title Defense
----------------------------------------------------------------------

 ![PFL full fight: Usman Nurmagomedov sleeps Alfie Davis in title defense](https://mmajunkie.usatoday.com/gcdn/authoring/authoring-images/2026/02/07/SMMA/88570588007-usman-nurmagomedov-def-alfie-davis-pfl-road-to-dubai-32.JPG?crop=2399,1351,x0,y124&width=2399&height=1351&format=pjpg&auto=webp) <small>mmajunkie.usatoday.com</small>PFL full fight: Usman Nurmagomedov sleeps Alfie Davis in title defense

"Alfie Davis, Anytime, Anywhere." - Usman Nurmagomedov Gets His Wish A
----------------------------------------------------------------------

 !["Alfie Davis, Anytime, Anywhere." - Usman Nurmagomedov gets his wish a](https://www.tiktok.com/api/img/?itemId=7575538504147422494&location=0&aid=1988) <small>www.tiktok.com</small>"Alfie Davis, Anytime, Anywhere." - Usman Nurmagomedov gets his wish a ...

Usman Nurmagomedov Vs Alfie Davis RECAP: Relive Usman Nurmagomedov's
--------------------------------------------------------------------

 ![Usman Nurmagomedov vs Alfie Davis RECAP: Relive Usman Nurmagomedov's](https://ichef.bbci.co.uk/ace/standard/640/cpsprodpb/vivo/live/images/2026/2/7/b2462704-94c1-4bc4-90c5-b3a221214a96.png.webp) <small>www.bbc.co.uk</small>Usman Nurmagomedov vs Alfie Davis RECAP: Relive Usman Nurmagomedov's ...

PFL Road To Dubai: Usman Nurmagomedov Submits Alfie Davis
---------------------------------------------------------

 ![PFL Road to Dubai: Usman Nurmagomedov submits Alfie Davis](https://mmajunkie.usatoday.com/gcdn/authoring/authoring-images/2026/02/07/SMMA/88570563007-usman-nurmagomedov-def-alfie-davis-pfl-road-to-dubai-15.JPG?crop=2399,1351,x0,y124&width=2399&height=1351&format=pjpg&auto=webp) <small>mmajunkie.usatoday.com</small>PFL Road to Dubai: Usman Nurmagomedov submits Alfie Davis

Nurmagomedov Contra Davis (7 De Feb 2026): Transmisión En Vivo, Hora De
-----------------------------------------------------------------------

 ![Nurmagomedov contra Davis (7 de feb 2026): transmisión en vivo, hora de](https://champinon.info/images/nurmagomedov-vs-davis.webp) <small>champinon.info</small>Nurmagomedov contra Davis (7 de feb 2026): transmisión en vivo, hora de ...

Usman Nurmagomedov Dominates Alfie Davis To Retain PFL Lightweight
------------------------------------------------------------------

 ![Usman Nurmagomedov dominates Alfie Davis to retain PFL lightweight](https://www.thenationalnews.com/resizer/v2/XEFVPMHXW5BZNNCWDT2I6KJ4VE.JPG?auth=4f4f1c75eecfa65edc8f68a6b13ed1b77a7a53aa1ca828757c88a4a9a43c2f78) <small>www.thenationalnews.com</small>Usman Nurmagomedov dominates Alfie Davis to retain PFL lightweight ...

Usman Nurmagomedov Vs Alfie Davis RECAP: Relive Usman Nurmagomedov's
--------------------------------------------------------------------

 ![Usman Nurmagomedov vs Alfie Davis RECAP: Relive Usman Nurmagomedov's](https://ichef.bbci.co.uk/ace/standard/640/cpsprodpb/vivo/live/images/2026/2/7/1d69ae8c-a8c6-4c9a-a9f7-35cca9aecae8.jpg.webp) <small>www.bbc.co.uk</small>Usman Nurmagomedov vs Alfie Davis RECAP: Relive Usman Nurmagomedov's ...

Usman Nurmagomedov Vs Alfie Davis RECAP: Relive Usman Nurmagomedov's
--------------------------------------------------------------------

 ![Usman Nurmagomedov vs Alfie Davis RECAP: Relive Usman Nurmagomedov's](https://ichef.bbci.co.uk/ace/standard/640/cpsprodpb/vivo/live/images/2026/2/7/7105d8ae-31d1-4417-bc67-84306cd42980.png.webp) <small>www.bbc.co.uk</small>Usman Nurmagomedov vs Alfie Davis RECAP: Relive Usman Nurmagomedov's ...

PFL Road To Dubai: Usman Nurmagomedov V Alfie Davis | Full Fight
----------------------------------------------------------------

 ![PFL Road To Dubai: Usman Nurmagomedov v Alfie Davis | Full Fight](https://i.ytimg.com/vi/Zbiz-XEiPTY/maxresdefault.jpg) <small>www.youtube.com</small>PFL Road To Dubai: Usman Nurmagomedov v Alfie Davis | Full Fight ...

Usman Nurmagomedov Vs. Alfie Davis Title Bout Headlines PFL: Road To Dubai
--------------------------------------------------------------------------

 ![Usman Nurmagomedov vs. Alfie Davis title bout headlines PFL: Road to Dubai](https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA1QOp88.img?w=768&h=511&m=6) <small>www.msn.com</small>Usman Nurmagomedov vs. Alfie Davis title bout headlines PFL: Road to Dubai

Usman Nurmagomedov Vs Alfie Davis RECAP: Relive Usman Nurmagomedov's
--------------------------------------------------------------------

 ![Usman Nurmagomedov vs Alfie Davis RECAP: Relive Usman Nurmagomedov's](https://ichef.bbci.co.uk/ace/standard/640/cpsprodpb/vivo/live/images/2026/2/7/7e490141-5209-4b04-9e32-034d317e02c1.png.webp) <small>www.bbc.com</small>Usman Nurmagomedov vs Alfie Davis RECAP: Relive Usman Nurmagomedov's ...

Alfie Davis Competes Against Usman Nurmagomedov During Mixed Martial
--------------------------------------------------------------------

 ![Alfie Davis competes against Usman Nurmagomedov during mixed martial](https://media.gettyimages.com/id/2259851395/photo/road-to-dubai-championship-in-dubai.jpg?s=1024x1024&w=gi&k=20&c=LViA8lQZ7TYg-qyfe3ormPZAW7R55BCwD8yT1XBdV9g=) <small>www.gettyimages.in</small>Alfie Davis competes against Usman Nurmagomedov during mixed martial ...

PFL: Usman Nurmagomedov Defende Cinturão Contra Alfie Davis Em 2026 | Ge
------------------------------------------------------------------------

 ![PFL: Usman Nurmagomedov defende cinturão contra Alfie Davis em 2026 | Ge](https://s2-ge.glbimg.com/_s5U9nUfu2mJebbpe4o6WY4MnXA=/1280x0/filters:format(jpeg)/https://s01.video.glbimg.com/x720/13984736.jpg) <small>ge.globo.com</small>PFL: Usman Nurmagomedov defende cinturão contra Alfie Davis em 2026 | Ge

USMAN NURMAGOMEDOV VS ALFIE DAVIS FULL FIGHT PFL DUBAI - YouTube
----------------------------------------------------------------

 ![USMAN NURMAGOMEDOV VS ALFIE DAVIS FULL FIGHT PFL DUBAI - YouTube](https://i.ytimg.com/vi/a9ZGVFYb46I/maxresdefault.jpg) <small>www.youtube.com</small>USMAN NURMAGOMEDOV VS ALFIE DAVIS FULL FIGHT PFL DUBAI - YouTube

USMAN NURMAGOMEDOV Vs ALFIE DAVIS FULL FIGHT - YouTube
------------------------------------------------------

 ![USMAN NURMAGOMEDOV vs ALFIE DAVIS FULL FIGHT - YouTube](https://i.ytimg.com/vi/GQzrEFRq4ps/maxresdefault.jpg) <small>www.youtube.com</small>USMAN NURMAGOMEDOV vs ALFIE DAVIS FULL FIGHT - YouTube

Usman Nurmagomedov Vs Alfie Davis RECAP: Relive Usman Nurmagomedov's
--------------------------------------------------------------------

 ![Usman Nurmagomedov vs Alfie Davis RECAP: Relive Usman Nurmagomedov's](https://ichef.bbci.co.uk/ace/standard/640/cpsprodpb/vivo/live/images/2026/2/7/4182f023-6644-49d1-9f7a-f3c2fc2d9d03.png.webp) <small>www.bbc.co.uk</small>Usman Nurmagomedov vs Alfie Davis RECAP: Relive Usman Nurmagomedov's ...

Usman Nurmagomedov Dominates Alfie Davis To Retain PFL Lightweight
------------------------------------------------------------------

 ![Usman Nurmagomedov dominates Alfie Davis to retain PFL lightweight](https://www.thenationalnews.com/resizer/v2/VJWI62VJQFBGVA5SMZSMS74K2E.JPG?auth=100effa075e12ea7d33d6b0251d80f768a8f922034e5c68d94e9efeb3293236c) <small>www.thenationalnews.com</small>Usman Nurmagomedov dominates Alfie Davis to retain PFL lightweight ...

USMAN RETURNS!! 🔥 | Usman Nurmagomedov V Alfie Davis | Full Fight | PFL
-----------------------------------------------------------------------

 ![USMAN RETURNS!! 🔥 | Usman Nurmagomedov v Alfie Davis | Full Fight | PFL](https://i.ytimg.com/vi/hSd9BwDeZwg/maxresdefault.jpg) <small>www.youtube.com</small>USMAN RETURNS!! 🔥 | Usman Nurmagomedov v Alfie Davis | Full Fight | PFL ...

Usman Nurmagomedov Vs Alfie Davis - Full Fight Recap - YouTube
--------------------------------------------------------------

 ![Usman Nurmagomedov vs Alfie Davis - Full Fight Recap - YouTube](https://i.ytimg.com/vi/EoarzlC1krY/maxresdefault.jpg) <small>www.youtube.com</small>Usman Nurmagomedov vs Alfie Davis - Full Fight Recap - YouTube

Usman nurmagomedov returns to dubai to defend pfl title against. Pfl full fight: usman nurmagomedov sleeps alfie davis in title defense. Pfl champions series 5
