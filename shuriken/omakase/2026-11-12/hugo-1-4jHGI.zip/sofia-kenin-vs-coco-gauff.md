---
title: "Sofia Kenin Vs Coco Gauff - Wimbledon, england, 03/07/2023, sofia kenin (usa) versus coco gauff ..."
description: "Coco gauff kenin at mitzi mcclain blog"
date: "2026-03-13"
categories:
- "Uncategorized"
images:
- "https://firstsportz.com/wp-content/uploads/2025/01/Coco-Gauff-Sofia-Kenin.jpg"
featuredImage: "https://c8.alamy.com/comp/3A524PC/coco-gauff-left-shakes-hands-with-sofia-kenin-right-after-winning-their-match-at-the-miami-open-tennis-tournament-thursday-march-20-2025-in-miami-gardens-fla-ap-photolynne-sladky-3A524PC.jpg"
featured_image: "https://external-preview.redd.it/sports-sofia-kenin-stuns-coco-gauff-in-first-round-at-v0-84kzalm0E0vTEDtMDoNBg4WyEdlKc-9mA6UYdTljpJQ.jpg?auto=webp&amp;s=85611e86147f929e0f74e2c42fbdbfb663b0c9cc"
image: "https://c8.alamy.com/comp/3A524PC/coco-gauff-left-shakes-hands-with-sofia-kenin-right-after-winning-their-match-at-the-miami-open-tennis-tournament-thursday-march-20-2025-in-miami-gardens-fla-ap-photolynne-sladky-3A524PC.jpg"
---

If you are searching about Wimbledon 2023: Coco Gauff vs Sofia Kenin preview, head-to-head you've came to the right place. We have 35 Pics about Wimbledon 2023: Coco Gauff vs Sofia Kenin preview, head-to-head like Sofia Kenin stops Coco Gauff in Australian Open's 4th round - NBC Sports, Australian Open: Sofia Kenin defeats Coco Gauff in fourth round and also Coco Gauff vs Sofia Kenin: Where to watch, TV schedule, live streaming. Read more:

Wimbledon 2023: Coco Gauff Vs Sofia Kenin Preview, Head-to-head
---------------------------------------------------------------

 ![Wimbledon 2023: Coco Gauff vs Sofia Kenin preview, head-to-head](https://staticg.sportskeeda.com/editor/2023/06/bbaa4-16881235113084-1920.jpg) <small>www.sportskeeda.com</small>Wimbledon 2023: Coco Gauff vs Sofia Kenin preview, head-to-head ...

Coco Gauff Vs. Sofia Kenin | 2025 Second Round Miami | WTA Match
----------------------------------------------------------------

 ![Coco Gauff vs. Sofia Kenin | 2025 Second Round Miami | WTA Match](https://i.ytimg.com/vi/5xkcj4x3Rjg/maxresdefault.jpg) <small>www.youtube.com</small>Coco Gauff vs. Sofia Kenin | 2025 Second Round Miami | WTA Match ...

Sofia Kenin Surprises Coco Gauff In Highlight-filled, All-U.S. Match At
-----------------------------------------------------------------------

 ![Sofia Kenin surprises Coco Gauff in highlight-filled, all-U.S. match at](https://www.tsn.ca/resizer/v2/3LODC6MVZFDUKRLJUXVM3SBDWM.jpg?smart=true&auth=27b8e69507cbafb532df0a8ee40433c6cbe0d64ab254dae7eb4e14dcb9dc1f96&width=1600&height=899) <small>www.tsn.ca</small>Sofia Kenin surprises Coco Gauff in highlight-filled, all-U.S. match at ...

Coco Gauff Vs Sofia Kenin | Round One | Australian Open 2025 Highlights
-----------------------------------------------------------------------

 ![Coco Gauff vs Sofia Kenin | Round One | Australian Open 2025 Highlights](https://i.ytimg.com/vi/FPxfpxeBgwk/maxresdefault.jpg) <small>www.youtube.com</small>Coco Gauff vs Sofia Kenin | Round One | Australian Open 2025 Highlights ...

Sofia Kenin Stops Coco Gauff In Australian Open's 4th Round - NBC Sports
------------------------------------------------------------------------

 ![Sofia Kenin stops Coco Gauff in Australian Open's 4th round - NBC Sports](https://nbcsports.brightspotcdn.com/dims4/default/9b5e4cf/2147483647/strip/true/crop/2555x1437+0+157/resize/1440x810!/quality/90/?url=https:%2F%2Fnbc-sports-production-nbc-sports.s3.us-east-1.amazonaws.com%2Fbrightspot%2F1d%2F27%2F2c73a8e1b0c5fae027fe9ad5e2b0%2Fap-20026217881193.jpg) <small>www.nbcsports.com</small>Sofia Kenin stops Coco Gauff in Australian Open's 4th round - NBC Sports

395 David Kenin Stock Photos, High-Res Pictures, And Images - Getty Images
--------------------------------------------------------------------------

 ![395 David Kenin Stock Photos, High-Res Pictures, and Images - Getty Images](https://media.gettyimages.com/id/2193053819/photo/usas-coco-gauff-shakes-hands-with-compatriot-sofia-kenin-after-their-womens-singles-match-on.jpg?s=612x612&w=gi&k=20&c=KAskR0X1jZwfb18inaUUGEp-v9_A2fKPFL0NfiiLUkg=) <small>www.gettyimages.com</small>395 David Kenin Stock Photos, High-Res Pictures, and Images - Getty Images

Coco Gauff Vs Sofia Kenin - 2025 Miami Open | R2 Highlights | Tennis
--------------------------------------------------------------------

 ![Coco Gauff vs Sofia Kenin - 2025 Miami Open | R2 highlights | tennis](https://i.ytimg.com/vi/rtksirP7ukw/maxresdefault.jpg) <small>www.youtube.com</small>Coco Gauff vs Sofia Kenin - 2025 Miami Open | R2 highlights | tennis ...

Sofia Kenin Vs. Coco Gauff | Wimbledon Open 2023 | Wta Match - YouTube
----------------------------------------------------------------------

 ![Sofia Kenin Vs. Coco Gauff | wimbledon open 2023 | wta match - YouTube](https://i.ytimg.com/vi/AvSD72uQIYE/maxresdefault.jpg) <small>www.youtube.com</small>Sofia Kenin Vs. Coco Gauff | wimbledon open 2023 | wta match - YouTube

Coco Gauff Vs Sofia Kenin: Where To Watch, TV Schedule, Live Streaming
----------------------------------------------------------------------

 ![Coco Gauff vs Sofia Kenin: Where to watch, TV schedule, live streaming](https://staticg.sportskeeda.com/editor/2023/01/ddeb5-16728227656143-1920.jpg) <small>www.sportskeeda.com</small>Coco Gauff vs Sofia Kenin: Where to watch, TV schedule, live streaming ...

Sofia Kenin Stops Coco Gauff In Australian Open's 4th Round | Daily Sabah
-------------------------------------------------------------------------

 ![Sofia Kenin stops Coco Gauff in Australian Open's 4th round | Daily Sabah](https://iadsb.tmgrup.com.tr/70db5e/1200/627/0/30/1000/552?u=https://idsb.tmgrup.com.tr/2020/01/26/1580035058091.jpg) <small>www.dailysabah.com</small>Sofia Kenin stops Coco Gauff in Australian Open's 4th round | Daily Sabah

Photo: Coco Gauff Vs Sofia Kenin At Wimbledon 2023 - LON2023070370
------------------------------------------------------------------

 ![Photo: Coco Gauff vs Sofia Kenin at Wimbledon 2023 - LON2023070370](https://cdnph.upi.com/pv/upi/dbcc40a20a434e893085f4de9dd3e5c5/2023-WIMBLEDON-CHAMPIONSHIPS.jpg) <small>www.upi.com</small>Photo: Coco Gauff vs Sofia Kenin at Wimbledon 2023 - LON2023070370 ...

Sportskeeda Women - Coco Gauff Shines Bright In Miami Open 2025 #wta #
----------------------------------------------------------------------

 ![Sportskeeda Women - Coco Gauff shines bright in Miami Open 2025 #wta #](https://lookaside.fbsbx.com/lookaside/crawler/media/?media_id=640857275553373) <small>www.facebook.com</small>Sportskeeda Women - Coco Gauff shines bright in Miami Open 2025 #wta # ...

Australian Open 2020: Sofia Kenin Stops Coco Gauff, Petra Kvitova Comes
-----------------------------------------------------------------------

 ![Australian Open 2020: Sofia Kenin stops Coco Gauff, Petra Kvitova comes](https://images.firstpost.com/wp-content/uploads/2020/01/kenin-gauff-ap-825.jpg) <small>www.firstpost.com</small>Australian Open 2020: Sofia Kenin stops Coco Gauff, Petra Kvitova comes ...

"Now I'm Just Eager And Hungry To Get Back" - Sofia Kenin After
---------------------------------------------------------------

 !["Now I'm just eager and hungry to get back" - Sofia Kenin after](https://staticg.sportskeeda.com/editor/2023/07/55fb3-16884345532336-1920.jpg) <small>www.sportskeeda.com</small>"Now I'm just eager and hungry to get back" - Sofia Kenin after ...

Coco Gauff’s Journey Ends At The Hands Of Sofia Kenin – The Irish Times
-----------------------------------------------------------------------

 ![Coco Gauff’s journey ends at the hands of Sofia Kenin – The Irish Times](https://www.irishtimes.com/resizer/v2/PMEPZDQ7M3HOFHKKXUTKN7PVME.jpg?auth=bee97ac2fe7aae0bc46c9c486eabf3e7567cf865894c8db20527ab8370181d4d&smart=true&width=1024&height=576) <small>www.irishtimes.com</small>Coco Gauff’s journey ends at the hands of Sofia Kenin – The Irish Times

Coco Gauff Kenin At Mitzi Mcclain Blog
--------------------------------------

 ![Coco Gauff Kenin at Mitzi Mcclain blog](https://staticg.sportskeeda.com/editor/2023/01/d2e9e-16728224008690-1920.jpg) <small>storage.googleapis.com</small>Coco Gauff Kenin at Mitzi Mcclain blog

Gauff Survives Test Of Champions At Melbourne Park | Reuters
------------------------------------------------------------

 ![Gauff survives test of champions at Melbourne Park | Reuters](https://www.reuters.com/resizer/v2/4JHANNBRVBPHXHVUBZPOAB726E.jpg?auth=70ee6516ed777445ee35caf984ca19835573ba7b661cecb4c8e1e208f7cf0b7d&width=1080&quality=80) <small>www.reuters.com</small>Gauff survives test of champions at Melbourne Park | Reuters

'Didn't Do It For The Hype': Kenin Stops Coco In Australia - Bloomberg
----------------------------------------------------------------------

 !['Didn't Do It for the Hype': Kenin Stops Coco in Australia - Bloomberg](https://assets.bwbx.io/images/users/iqjWHBFdfxIU/ipTUdCnb9TC0/v1/-1x-1.webp) <small>www.bloomberg.com</small>'Didn't Do It for the Hype': Kenin Stops Coco in Australia - Bloomberg

Gauff Vs Kenin : Coco Gauff Vs Sofia Kenin – CLSA
-------------------------------------------------

 ![Gauff Vs Kenin : Coco Gauff vs Sofia Kenin – CLSA](https://i.ytimg.com/vi/xGubJfkqON0/maxresdefault.jpg) <small>pljandson.co.uk</small>Gauff Vs Kenin : Coco Gauff vs Sofia Kenin – CLSA

Coco Gauff V Sofia Kenin Extended Highlights | Australian Open 2025
-------------------------------------------------------------------

 ![Coco Gauff v Sofia Kenin Extended Highlights | Australian Open 2025](https://i.ytimg.com/vi/8GrzGP9hZ40/maxresdefault.jpg) <small>www.youtube.com</small>Coco Gauff v Sofia Kenin Extended Highlights | Australian Open 2025 ...

Photo: Coco Gauff Vs Sofia Kenin At Wimbledon 2023 - LON2023070371
------------------------------------------------------------------

 ![Photo: Coco Gauff vs Sofia Kenin at Wimbledon 2023 - LON2023070371](https://cdnph.upi.com/pv/upi/c92ff984db4c895dabbbaecad2ae982d/2023-WIMBLEDON-CHAMPIONSHIPS.jpg) <small>www.upi.com</small>Photo: Coco Gauff vs Sofia Kenin at Wimbledon 2023 - LON2023070371 ...

Sofia Kenin Celebrates Victory Over Coco Gauff On Day One Of The 2023
---------------------------------------------------------------------

 ![Sofia Kenin celebrates victory over Coco Gauff on day one of the 2023](https://c8.alamy.com/comp/2RAG1F4/sofia-kenin-celebrates-victory-over-coco-gauff-on-day-one-of-the-2023-wimbledon-championships-at-the-all-england-lawn-tennis-and-croquet-club-in-wimbledon-picture-date-monday-july-3-2023-2RAG1F4.jpg) <small>www.alamy.com</small>Sofia Kenin celebrates victory over Coco Gauff on day one of the 2023 ...

Wimbledon, England, 03/07/2023, Sofia Kenin (USA) Versus Coco Gauff
-------------------------------------------------------------------

 ![Wimbledon, England, 03/07/2023, Sofia Kenin (USA) versus Coco Gauff](https://c8.alamy.com/comp/2RAJ8GP/wimbledon-england-03072023-sofia-kenin-usa-versus-coco-gauff-usa-during-the-2023-wimbledon-championships-on-july-3-2023-at-all-england-lawn-tennis-croquet-club-in-wimbledon-england-2RAJ8GP.jpg) <small>www.alamy.com</small>Wimbledon, England, 03/07/2023, Sofia Kenin (USA) versus Coco Gauff ...

Coco Gauff Vs Sofia Kenin Picks &amp; Prediction - 3/20/25
----------------------------------------------------------

 ![Coco Gauff vs Sofia Kenin Picks & Prediction - 3/20/25](https://static.sportytrader.com/betting-tip-thumbnail/prod/254745.webp) <small>www.sportytrader.com</small>Coco Gauff vs Sofia Kenin Picks &amp; Prediction - 3/20/25

Coco Gauff Kenin At Mitzi Mcclain Blog
--------------------------------------

 ![Coco Gauff Kenin at Mitzi Mcclain blog](https://i.ytimg.com/vi/KX03JTTBAEc/maxresdefault.jpg) <small>storage.googleapis.com</small>Coco Gauff Kenin at Mitzi Mcclain blog

Coco Gauff ,left, Shakes Hands With Sofia Kenin, Right, After Winning
---------------------------------------------------------------------

 ![Coco Gauff ,left, shakes hands with Sofia Kenin, right, after winning](https://c8.alamy.com/comp/3A524PC/coco-gauff-left-shakes-hands-with-sofia-kenin-right-after-winning-their-match-at-the-miami-open-tennis-tournament-thursday-march-20-2025-in-miami-gardens-fla-ap-photolynne-sladky-3A524PC.jpg) <small>www.alamy.com</small>Coco Gauff ,left, shakes hands with Sofia Kenin, right, after winning ...

Sofia Kenin Upsets Coco Gauff In Thrilling 3-set Match - Stream The
-------------------------------------------------------------------

 ![Sofia Kenin upsets Coco Gauff in thrilling 3-set match - Stream the](https://media.video-cdn.espn.com/motion/2023/0703/dm_230703_Sofia_Kenin_upsets_Coco_Gauff/dm_230703_Sofia_Kenin_upsets_Coco_Gauff.jpg) <small>www.espn.com</small>Sofia Kenin upsets Coco Gauff in thrilling 3-set match - Stream the ...

WTA LIVE COCO GAUFF VS SOFIA KENIN WTA MIAMI OPEN 2025 TENNIS PREVIEW
---------------------------------------------------------------------

 ![WTA LIVE COCO GAUFF VS SOFIA KENIN WTA MIAMI OPEN 2025 TENNIS PREVIEW](https://i.ytimg.com/vi/8lNq6b84AeU/maxresdefault.jpg) <small>www.youtube.com</small>WTA LIVE COCO GAUFF VS SOFIA KENIN WTA MIAMI OPEN 2025 TENNIS PREVIEW ...

Coco Gauff Starts Australian Open With Straight-sets Win Over Sofia Kenin
-------------------------------------------------------------------------

 ![Coco Gauff starts Australian Open with straight-sets win over Sofia Kenin](https://www.tsn.ca/resizer/v2/EHSRFHGX3MQMONFLMMY2ZOJ6PA.jpg?smart=true&auth=07c7656230e8621220b6ac7744bf51997235b6a0c34953b30b989943ab3e265d&width=5844&height=3287) <small>www.tsn.ca</small>Coco Gauff starts Australian Open with straight-sets win over Sofia Kenin

\[Sports\] - Sofia Kenin Stuns Coco Gauff In First Round At Wimbledon : R
-------------------------------------------------------------------------

 ![[Sports] - Sofia Kenin stuns Coco Gauff in first round at Wimbledon : r](https://external-preview.redd.it/sports-sofia-kenin-stuns-coco-gauff-in-first-round-at-v0-84kzalm0E0vTEDtMDoNBg4WyEdlKc-9mA6UYdTljpJQ.jpg?auto=webp&s=85611e86147f929e0f74e2c42fbdbfb663b0c9cc) <small>www.reddit.com</small>\[Sports\] - Sofia Kenin stuns Coco Gauff in first round at Wimbledon : r ...

Coco Gauff, Sofia Kenin Join Kerber And Goerges To Play The Inaugural
---------------------------------------------------------------------

 ![Coco Gauff, Sofia Kenin join Kerber and Goerges to play the inaugural](https://tennistonic.com/wp-content/uploads/2020/03/Coco-Gauff-and-Sofia-Kenin.jpg) <small>tennistonic.com</small>Coco Gauff, Sofia Kenin join Kerber and Goerges to play the inaugural ...

Australian Open: Sofia Kenin Defeats Coco Gauff In Fourth Round
---------------------------------------------------------------

 ![Australian Open: Sofia Kenin defeats Coco Gauff in fourth round](https://www.si.com/.image/t_share/MTcwMDEwMDc4NDc5Mzk0Mzc3/coco-gauff-sofia-kenin.jpg) <small>www.si.com</small>Australian Open: Sofia Kenin defeats Coco Gauff in fourth round ...

ESPN - Coco Gauff Defeats Sofia Kenin This Time Around 👏...
-----------------------------------------------------------

 ![ESPN - Coco Gauff defeats Sofia Kenin this time around 👏...](https://lookaside.fbsbx.com/lookaside/crawler/media/?media_id=1483965756432357) <small>www.facebook.com</small>ESPN - Coco Gauff defeats Sofia Kenin this time around 👏...

Coco Gauff Reveals If She Felt Added Pressure And Expectation Playing
---------------------------------------------------------------------

 ![Coco Gauff reveals if she felt added pressure and expectation playing](https://firstsportz.com/wp-content/uploads/2025/01/Coco-Gauff-Sofia-Kenin.jpg) <small>firstsportz.com</small>Coco Gauff reveals if she felt added pressure and expectation playing ...

Photo: Coco Gauff Vs Sofia Kenin At Wimbledon 2023 - LON2023070366
------------------------------------------------------------------

 ![Photo: Coco Gauff vs Sofia Kenin at Wimbledon 2023 - LON2023070366](https://cdnph.upi.com/pv/upi/ca2b248a43d40510d45653dec05c3ffc/2023-WIMBLEDON-CHAMPIONSHIPS.jpg) <small>www.upi.com</small>Photo: Coco Gauff vs Sofia Kenin at Wimbledon 2023 - LON2023070366 ...

Coco gauff kenin at mitzi mcclain blog. coco gauff v sofia kenin extended highlights. Wta live coco gauff vs sofia kenin wta miami open 2025 tennis preview ...
