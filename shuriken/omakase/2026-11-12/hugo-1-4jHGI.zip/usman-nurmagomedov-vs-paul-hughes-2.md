---
title: "Usman Nurmagomedov Vs Paul Hughes 2 - Pfl champions series: usman nurmagomedov edges paul hughes, retains"
description: "paul hughes vs usman nurmagomedov 2: start time, fight card, and how to ..."
date: "2026-05-28"
categories:
- "Uncategorized"
images:
- "https://www.gannett-cdn.com/authoring/images/smg/2025/02/21/SMMA/79491279007-91-2768463.jpeg?auto=webp&amp;width=640&amp;quality=75"
featuredImage: "https://images.tapology.com/poster_images/132096/profile/OIMOUAs.jpg?1759291827"
featured_image: "https://blogs.rdxsports.com/wp-content/uploads/2025/01/RDX-Podcast-Thumbnail-v2-2.jpg"
image: "https://ichef.bbci.co.uk/ace/standard/640/cpsprodpb/vivo/live/images/2025/10/3/53058bd0-512c-4630-bcd8-25ce9f973a25.png.webp"
---

If you are looking for PFL Road to Dubai Champions Series: Nurmagomedov vs. Hughes to headline you've visit to the right web. We have 35 Pics about PFL Road to Dubai Champions Series: Nurmagomedov vs. Hughes to headline like Tim Elliott vs Kai Asakura - Head-to-Head Comparison &amp; Tale of the Tape, 2025 CHAMPIONS SERIES: USMAN NURMAGOMEDOV VS PAUL HUGHES | Professional and also 2025 CHAMPIONS SERIES: USMAN NURMAGOMEDOV VS PAUL HUGHES | Professional. Here it is:

PFL Road To Dubai Champions Series: Nurmagomedov Vs. Hughes To Headline
-----------------------------------------------------------------------

 ![PFL Road to Dubai Champions Series: Nurmagomedov vs. Hughes to headline](https://blogs.rdxsports.com/wp-content/uploads/2025/01/usman-nurmagomedov-paul-hughes-1.jpg) <small>blogs.rdxsports.com</small>PFL Road to Dubai Champions Series: Nurmagomedov vs. Hughes to headline ...

PFL Champions Series: Usman Nurmagomedov Vs. Paul Hughes 2 Weigh-In
-------------------------------------------------------------------

 ![PFL Champions Series: Usman Nurmagomedov vs. Paul Hughes 2 Weigh-In](https://media.mmanews.com/uploads/2025/10/PFL-Champions-Series_-Usman-Nurmagomedov-vs.-Paul-Hughes-2-Weigh-In-Results.png) <small>www.mmanews.com</small>PFL Champions Series: Usman Nurmagomedov vs. Paul Hughes 2 Weigh-In ...

Urmeaza Gala PFL Champions Series 1: Usman Nurmagomedov Vs. Paul Hughes
-----------------------------------------------------------------------

 ![Urmeaza gala PFL Champions Series 1: Usman Nurmagomedov vs. Paul Hughes](https://absoluto.ro/wp-content/uploads/2025/01/usman-1170x780.jpeg) <small>absoluto.ro</small>Urmeaza gala PFL Champions Series 1: Usman Nurmagomedov vs. Paul Hughes ...

Usman Nurmagomedov Vs. Paul Hughes Round-by-round Updates: PFL
--------------------------------------------------------------

 ![Usman Nurmagomedov vs. Paul Hughes round-by-round updates: PFL](https://staticg.sportskeeda.com/editor/2025/01/68090-17378193579943-1920.jpg) <small>www.sportskeeda.com</small>Usman Nurmagomedov vs. Paul Hughes round-by-round updates: PFL ...

Robbery Review: Usman Nurmagomedov Vs. Paul Hughes At PFL Dubai - MMA
---------------------------------------------------------------------

 ![Robbery Review: Usman Nurmagomedov vs. Paul Hughes at PFL Dubai - MMA](https://cdn.vox-cdn.com/thumbor/ZuLs6h2ovDE18BtGx_s7cU35jZ4=/0x0:6000x4000/1220x813/filters:focal(2116x637:3076x1597)/cdn.vox-cdn.com/uploads/chorus_image/image/73875478/20250125214141__JP18300_.0.jpg) <small>www.mmafighting.com</small>Robbery Review: Usman Nurmagomedov vs. Paul Hughes at PFL Dubai - MMA ...

2025 CHAMPIONS SERIES: USMAN NURMAGOMEDOV VS PAUL HUGHES | Professional
-----------------------------------------------------------------------

 ![2025 CHAMPIONS SERIES: USMAN NURMAGOMEDOV VS PAUL HUGHES | Professional](https://pflmma-prod.s3.amazonaws.com/galleries/images/61164f1739a5a3cb4ad50932036bde4f-1.jpg) <small>pflmma.com</small>2025 CHAMPIONS SERIES: USMAN NURMAGOMEDOV VS PAUL HUGHES | Professional ...

Podcast: PFL Champions Series Recap, Usman Nurmagomedov And Paul Hughes
-----------------------------------------------------------------------

 ![Podcast: PFL Champions Series recap, Usman Nurmagomedov and Paul Hughes](https://blogs.rdxsports.com/wp-content/uploads/2025/01/RDX-Podcast-Thumbnail-v2-2.jpg) <small>blogs.rdxsports.com</small>Podcast: PFL Champions Series recap, Usman Nurmagomedov and Paul Hughes ...

Usman Nurmagomedov Escapes With Win Vs. Paul Hughes At PFL Champions
--------------------------------------------------------------------

 ![Usman Nurmagomedov escapes with win vs. Paul Hughes at PFL Champions](https://www.sportsnet.ca/wp-content/uploads/2024/09/Bellator-MMA-lightweight-champion-Usman-Nurmagomedov.jpg) <small>www.sportsnet.ca</small>Usman Nurmagomedov escapes with win vs. Paul Hughes at PFL Champions ...

2025 CHAMPIONS SERIES: USMAN NURMAGOMEDOV VS PAUL HUGHES | Professional
-----------------------------------------------------------------------

 ![2025 CHAMPIONS SERIES: USMAN NURMAGOMEDOV VS PAUL HUGHES | Professional](https://pflmma-prod.s3.amazonaws.com/galleries/images/6fac0349d80926ec6a8d240572107d2b-1.jpg) <small>pflmma.com</small>2025 CHAMPIONS SERIES: USMAN NURMAGOMEDOV VS PAUL HUGHES | Professional ...

Tim Elliott Vs Kai Asakura - Head-to-Head Comparison &amp; Tale Of The Tape
---------------------------------------------------------------------------

 ![Tim Elliott vs Kai Asakura - Head-to-Head Comparison & Tale of the Tape](https://boxing-schedule.com/images/nurmagomedov-vs-hughes-2.webp) <small>boxing-schedule.com</small>Tim Elliott vs Kai Asakura - Head-to-Head Comparison &amp; Tale of the Tape

2025 CHAMPIONS SERIES: USMAN NURMAGOMEDOV VS PAUL HUGHES | Professional
-----------------------------------------------------------------------

 ![2025 CHAMPIONS SERIES: USMAN NURMAGOMEDOV VS PAUL HUGHES | Professional](https://pflmma-prod.s3.amazonaws.com/galleries/images/3b00787c5c5a9124e7f3ee80930828e1-1.jpg) <small>pflmma.com</small>2025 CHAMPIONS SERIES: USMAN NURMAGOMEDOV VS PAUL HUGHES | Professional ...

Usman Nurmagomedov Vs Paul Hughes 2 Live: Fight Result As Score Sparks
----------------------------------------------------------------------

 ![Usman Nurmagomedov vs Paul Hughes 2 live: Fight result as score sparks](https://static.independent.co.uk/2025/10/03/22/24/Hughes-vs-Nurmagomedov-2.jpeg) <small>www.independent.co.uk</small>Usman Nurmagomedov vs Paul Hughes 2 live: Fight result as score sparks ...

NO COMMS!! | Usman Nurmagomedov V Paul Hughes | Full Fight | PFL
----------------------------------------------------------------

 ![NO COMMS!! | Usman Nurmagomedov v Paul Hughes | Full Fight | PFL](https://i.ytimg.com/vi/OaPYfjLAaOU/maxresdefault.jpg) <small>www.youtube.com</small>NO COMMS!! | Usman Nurmagomedov v Paul Hughes | Full Fight | PFL ...

PFL Dubai Results: Usman Nurmagomedov Edges Paul Hughes In Foul-laden
---------------------------------------------------------------------

 ![PFL Dubai results: Usman Nurmagomedov edges Paul Hughes in foul-laden](https://s.yimg.com/uu/api/res/1.2/qHaKTM9HmGcUbuw6HKailw--~B/Zmk9c3RyaW07aD0zNjA7dz02NDA7c209MTthcHBpZD15dGFjaHlvbg--/https://s.yimg.com/os/creatr-uploaded-images/2025-10/33659b00-a075-11f0-8f3b-6d095a25c184) <small>sports.yahoo.com</small>PFL Dubai results: Usman Nurmagomedov edges Paul Hughes in foul-laden ...

Paul Hughes Vs Usman Nurmagomedov 2: Start Time, Card…
------------------------------------------------------

 ![Paul Hughes vs Usman Nurmagomedov 2: Start time, card…](https://static.independent.co.uk/2025/09/23/10/59/GettyImages-2195930583.jpeg?width=1200&auto=webp&crop=3%3A2) <small>www.inkl.com</small>Paul Hughes vs Usman Nurmagomedov 2: Start time, card…

Usman Nurmagomedov Vs. Paul Hughes 2: PFL Champions Series 3 Full
-----------------------------------------------------------------

 ![Usman Nurmagomedov vs. Paul Hughes 2: PFL Champions Series 3 full](https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA1NOQEw.img?w=768&h=432&m=6&x=322&y=109&s=171&d=171) <small>www.msn.com</small>Usman Nurmagomedov vs. Paul Hughes 2: PFL Champions Series 3 full ...

PFL Champions Series 2: Nurmagomedov Vs. Hughes 2 Results, Fight Card
---------------------------------------------------------------------

 ![PFL Champions Series 2: Nurmagomedov vs. Hughes 2 Results, Fight Card](https://www.gannett-cdn.com/authoring/images/smg/2025/02/21/SMMA/79491279007-91-2768463.jpeg?auto=webp&width=640&quality=75) <small>mmajunkie.usatoday.com</small>PFL Champions Series 2: Nurmagomedov vs. Hughes 2 Results, Fight Card ...

Paul Hughes Vs Usman Nurmagomedov 2 Start Time, TV Channel Information
----------------------------------------------------------------------

 ![Paul Hughes vs Usman Nurmagomedov 2 start time, TV channel information](https://i2-prod.belfastlive.co.uk/article32597648.ece/ALTERNATES/s1200f/0_PFL_20251002_MBR_9064JPG.jpg) <small>www.belfastlive.co.uk</small>Paul Hughes vs Usman Nurmagomedov 2 start time, TV channel information ...

Usman Nurmagomedov Vs Paul Hughes Result: PFL Dubai Grudge Fight Gets
---------------------------------------------------------------------

 ![Usman Nurmagomedov vs Paul Hughes result: PFL Dubai grudge fight gets](https://bloodyelbow.com/wp-content/uploads/1/2025/01/20250125221342-_JP12606_-scaled-e1737850915497-1140x746.jpg) <small>bloodyelbow.com</small>Usman Nurmagomedov vs Paul Hughes result: PFL Dubai grudge fight gets ...

How To Watch PFL – Usman Nurmagomedov Vs Paul Hughes 2 - Sidekick Boxing
------------------------------------------------------------------------

 ![How to Watch PFL – Usman Nurmagomedov vs Paul Hughes 2 - Sidekick Boxing](https://sidekickboxing.co.uk/wp-content/uploads/2025/09/IMG_8222-1536x838.png) <small>sidekickboxing.co.uk</small>How to Watch PFL – Usman Nurmagomedov vs Paul Hughes 2 - Sidekick Boxing

PFL Champions Series: Usman Nurmagomedov Edges Paul Hughes, Retains
-------------------------------------------------------------------

 ![PFL Champions Series: Usman Nurmagomedov edges Paul Hughes, retains](https://blogs.rdxsports.com/wp-content/uploads/2025/01/nurmagomedov-hughes-1024x576.jpg) <small>blogs.rdxsports.com</small>PFL Champions Series: Usman Nurmagomedov edges Paul Hughes, retains ...

2025 CHAMPIONS SERIES: USMAN NURMAGOMEDOV VS PAUL HUGHES | Professional
-----------------------------------------------------------------------

 ![2025 CHAMPIONS SERIES: USMAN NURMAGOMEDOV VS PAUL HUGHES | Professional](https://pflmma-prod.s3.amazonaws.com/galleries/images/a1d93d1d4bd8e95bfdcaf014ead7308c-1.jpg) <small>pflmma.com</small>2025 CHAMPIONS SERIES: USMAN NURMAGOMEDOV VS PAUL HUGHES | Professional ...

Usman Nurmagomedov Vs. Paul Hughes II, PFL Champions Series 2 | MMA
-------------------------------------------------------------------

 ![Usman Nurmagomedov vs. Paul Hughes II, PFL Champions Series 2 | MMA](https://images.tapology.com/poster_images/132096/profile/OIMOUAs.jpg?1759291827) <small>www.tapology.com</small>Usman Nurmagomedov vs. Paul Hughes II, PFL Champions Series 2 | MMA ...

Usman Nurmagomedov Vs Paul Hughes 2: Fans Rage At Scorecards As Russian
-----------------------------------------------------------------------

 ![Usman Nurmagomedov vs Paul Hughes 2: Fans rage at scorecards as Russian](https://static.independent.co.uk/2025/10/03/22/17/GettyImages-2239052540.jpg) <small>www.independent.co.uk</small>Usman Nurmagomedov vs Paul Hughes 2: Fans rage at scorecards as Russian ...

2025 CHAMPIONS SERIES: USMAN NURMAGOMEDOV VS PAUL HUGHES | Professional
-----------------------------------------------------------------------

 ![2025 CHAMPIONS SERIES: USMAN NURMAGOMEDOV VS PAUL HUGHES | Professional](https://pflmma-prod.s3.amazonaws.com/galleries/images/48e433d6ab263c72906f3329618fd0df-1.jpg) <small>pflmma.com</small>2025 CHAMPIONS SERIES: USMAN NURMAGOMEDOV VS PAUL HUGHES | Professional ...

Usman Nurmagomedov Wins PFL Title Against Paul Hughes In Another Classic
------------------------------------------------------------------------

 ![Usman Nurmagomedov Wins PFL Title Against Paul Hughes in Another Classic](https://images.ladbible.com/resize?type=webp&quality=70&width=2048&fit=contain&gravity=auto&url=https://images.ladbiblegroup.com/v3/assets/blta90d05ad41a54a71/blt0c80f75e066ad36c/68e0522c881c45742d3fd273/usman.jpeg) <small>www.sportbible.com</small>Usman Nurmagomedov Wins PFL Title Against Paul Hughes in Another Classic

Dubai Is Gearing Up For The Much-awaited Rematch Between Usman
--------------------------------------------------------------

 ![Dubai is gearing up for the much-awaited rematch between Usman](https://www.timeoutdubai.com/cloud/timeoutdubai/2025/09/22/Usman-Nurmagomedov-and-Paul-Hughes-1000x523.jpg) <small>www.timeoutdubai.com</small>Dubai is gearing up for the much-awaited rematch between Usman ...

Usman Nurmagomedov Vs Paul Hughes : Analyse Et Pronostic Du Choc Au PFL
-----------------------------------------------------------------------

 ![Usman Nurmagomedov vs Paul Hughes : Analyse et pronostic du choc au PFL](https://www.ufc-fr.com/data/combat_autre/1965/usman-nurmagomedov-vs-paul-hughes-2024-11-29-11-12-47__dbye__ID1965.jpg) <small>www.ufc-fr.com</small>Usman Nurmagomedov vs Paul Hughes : Analyse et pronostic du choc au PFL ...

USMAN NURMAGOMEDOV VS PAUL HUGHES 2 FULL FIGHT PFL DUBAI - YouTube
------------------------------------------------------------------

 ![USMAN NURMAGOMEDOV VS PAUL HUGHES 2 FULL FIGHT PFL DUBAI - YouTube](https://i.ytimg.com/vi/sg6tUmA46fA/maxresdefault.jpg) <small>www.youtube.com</small>USMAN NURMAGOMEDOV VS PAUL HUGHES 2 FULL FIGHT PFL DUBAI - YouTube

Usman Nurmagomedov Vs. Paul Hughes 2 PFL Champions Series: Road To
------------------------------------------------------------------

 ![Usman Nurmagomedov Vs. Paul Hughes 2 PFL Champions Series: Road To](https://www.lowkickmma.com/wp-content/uploads/2025/08/Usman-Nurmagomedov-vs.-Paul-Hughes-FL-Champions-Series-Road-to-Dubai-–October-3-with-Two-World-Title-Fights-1024x536.png) <small>www.lowkickmma.com</small>Usman Nurmagomedov Vs. Paul Hughes 2 PFL Champions Series: Road To ...

How To Watch &amp; More Details For Usman Nurmagomedov Vs Paul Hughes
---------------------------------------------------------------------

 ![How to Watch & More Details for Usman Nurmagomedov vs Paul Hughes](https://pflmma-prod.s3.amazonaws.com/articles/featured/26cf1f8a82442701713f7f6670a8a78f-1.jpg) <small>pflmena.com</small>How to Watch &amp; More Details for Usman Nurmagomedov vs Paul Hughes ...

Paul Hughes Vs Usman Nurmagomedov 2: Start Time, Fight Card, And How To
-----------------------------------------------------------------------

 ![Paul Hughes vs Usman Nurmagomedov 2: Start time, fight card, and how to](https://static.toiimg.com/thumb/msid-124274578,width-1070,height-580,imgsize-30162,resizemode-75,overlay-toi_sw,pt-32,y_pad-40/photo.jpg) <small>timesofindia.indiatimes.com</small>Paul Hughes vs Usman Nurmagomedov 2: Start time, fight card, and how to ...

2025 CHAMPIONS SERIES: USMAN NURMAGOMEDOV VS PAUL HUGHES | Professional
-----------------------------------------------------------------------

 ![2025 CHAMPIONS SERIES: USMAN NURMAGOMEDOV VS PAUL HUGHES | Professional](https://pflmma-prod.s3.amazonaws.com/galleries/images/f720a646caaa3801648dc4c693383b84-1.jpg) <small>pflmma.com</small>2025 CHAMPIONS SERIES: USMAN NURMAGOMEDOV VS PAUL HUGHES | Professional ...

Usman Nurmagomedov Vs Paul Hughes 2 RECAP: Reaction, Analysis, Khabib
---------------------------------------------------------------------

 ![Usman Nurmagomedov vs Paul Hughes 2 RECAP: Reaction, analysis, Khabib](https://ichef.bbci.co.uk/ace/standard/640/cpsprodpb/vivo/live/images/2025/10/3/53058bd0-512c-4630-bcd8-25ce9f973a25.png.webp) <small>www.bbc.co.uk</small>Usman Nurmagomedov vs Paul Hughes 2 RECAP: Reaction, analysis, Khabib ...

PFL : Nurmagomedov Vs. Hughes 2 - Tous Les Résultats
----------------------------------------------------

 ![PFL : Nurmagomedov vs. Hughes 2 - Tous les résultats](https://lasueur.com/wp-content/uploads/2025/09/Paul-Hughes-Usman-Nurmagomedov.jpg) <small>lasueur.com</small>PFL : Nurmagomedov vs. Hughes 2 - Tous les résultats

usman nurmagomedov vs. paul hughes 2: pfl champions series 3 full .... Usman nurmagomedov vs. paul hughes 2: pfl champions series 3 full. Pfl road to dubai champions series: nurmagomedov vs. hughes to headline
