---
title: "Usman Nurmagomedov Fight Time - Fight of the year contender! 🤯"
description: "186 usman nurmagomedov stock photos, high-res pictures, and images ..."
date: "2026-01-18"
categories:
- "Uncategorized"
images:
- "https://media.gettyimages.com/id/2195373730/photo/dubai-united-arab-emirates-russias-usman-nurmagomedov-fights-irelands-paul-hughes-during-the.jpg?s=612x612&amp;w=gi&amp;k=20&amp;c=mCWN2Ab18pYBIb3OWhqcewmJtSW5X-v4xXOt_a3xAII="
featuredImage: "https://media.gettyimages.com/id/2195369087/photo/dubai-united-arab-emirates-russias-usman-nurmagomedov-fights-irelands-paul-hughes-during-the.jpg?s=612x612&amp;w=gi&amp;k=20&amp;c=INjnwZokPRYMecNs1ncpgoC9nFcuvuhu6Y6RF25Mits="
featured_image: "https://media.gettyimages.com/id/2195369348/photo/dubai-united-arab-emirates-russias-usman-nurmagomedov-fights-irelands-paul-hughes-during-the.jpg?s=612x612&amp;w=gi&amp;k=20&amp;c=pXE1K4tAPrs1QVsnKNhlbdC75pM3kSJaaaEMQjaN8Vk="
image: "https://ichef.bbci.co.uk/ace/standard/640/cpsprodpb/vivo/live/images/2026/2/7/1d69ae8c-a8c6-4c9a-a9f7-35cca9aecae8.jpg.webp"
---

If you are searching about Usman Nurmagomedov vs Archie Colgan: Fight Overview you've visit to the right page. We have 35 Pics about Usman Nurmagomedov vs Archie Colgan: Fight Overview like Usman Nurmagomedov vs. Paul Hughes 2 full fight video highlights | MMA, Usman Nurmagomedov vs. Paul Hughes full fight video highlights | MMA and also Usman Nurmagomedov vs Alfie Davis RECAP: Relive Usman Nurmagomedov's. Here you go:

Usman Nurmagomedov Vs Archie Colgan: Fight Overview
---------------------------------------------------

 ![Usman Nurmagomedov vs Archie Colgan: Fight Overview](https://boxing-schedule.com/images/nurmagomedov-vs-colgan.webp) <small>boxing-schedule.com</small>Usman Nurmagomedov vs Archie Colgan: Fight Overview

Usman Nurmagomedov Vs. Paul Hughes Full Fight Video Highlights | MMA
--------------------------------------------------------------------

 ![Usman Nurmagomedov vs. Paul Hughes full fight video highlights | MMA](https://platform.mmafighting.com/wp-content/uploads/sites/109/chorus/uploads/chorus_asset/file/25846712/Screen_Shot_2025_01_25_at_4.01.52_PM.png?quality=90&strip=all&crop=0%2C1.0286284953396%2C100%2C95.718797275535&w=1200) <small>www.mmafighting.com</small>Usman Nurmagomedov vs. Paul Hughes full fight video highlights | MMA ...

Paul Hughes Vs Usman Nurmagomedov 2: Start Time, Card And How To Watch
----------------------------------------------------------------------

 ![Paul Hughes vs Usman Nurmagomedov 2: Start time, card and how to watch](https://s.yimg.com/ny/api/res/1.2/XxLh9.mrbMFZ34JdFg_hGQ--/YXBwaWQ9aGlnaGxhbmRlcjt3PTk2MDtoPTY0MDtjZj13ZWJw/https://media.zenfs.com/en/the_independent_us_sports_articles_270/ba4791d99fd7493a5a58e3475c01a160) <small>sports.yahoo.com</small>Paul Hughes vs Usman Nurmagomedov 2: Start time, card and how to watch ...

PFL Dubai Live Blog: Usman Nurmagomedov Vs. Paul Hughes - MMA Fighting
----------------------------------------------------------------------

 ![PFL Dubai live blog: Usman Nurmagomedov vs. Paul Hughes - MMA Fighting](https://cdn.vox-cdn.com/thumbor/sCXKX7g3QdPdIoGZPN8swt2JtRk=/0x0:1194x790/1200x800/filters:focal(500x103:690x293)/cdn.vox-cdn.com/uploads/chorus_image/image/73867913/Screen_Shot_2025_01_24_at_12.42.29_PM.0.png) <small>www.mmafighting.com</small>PFL Dubai live blog: Usman Nurmagomedov vs. Paul Hughes - MMA Fighting

186 Usman Nurmagomedov Stock Photos, High-Res Pictures, And Images
------------------------------------------------------------------

 ![186 Usman Nurmagomedov Stock Photos, High-Res Pictures, and Images](https://media.gettyimages.com/id/2195369216/photo/dubai-united-arab-emirates-russias-usman-nurmagomedov-fights-irelands-paul-hughes-during-the.jpg?s=612x612&w=gi&k=20&c=vOpgIsQyOEbvH0pBOYnb4I0RxsW5ap-n6IZnR276nBA=) <small>www.gettyimages.co.uk</small>186 Usman Nurmagomedov Stock Photos, High-Res Pictures, and Images ...

Usman Nurmagomedov Vs Paul Hughes Result: PFL Dubai Grudge Fight Gets
---------------------------------------------------------------------

 ![Usman Nurmagomedov vs Paul Hughes result: PFL Dubai grudge fight gets](https://bloodyelbow.com/wp-content/uploads/1/2025/01/20250125221342-_JP12606_-scaled-e1737850915497.jpg) <small>bloodyelbow.com</small>Usman Nurmagomedov vs Paul Hughes result: PFL Dubai grudge fight gets ...

FIGHT OF THE YEAR CONTENDER! 🤯 | Usman Nurmagomedov V Paul Hughes
-----------------------------------------------------------------

 ![FIGHT OF THE YEAR CONTENDER! 🤯 | Usman Nurmagomedov v Paul Hughes](https://i.ytimg.com/vi/e7k2C_uID8w/maxresdefault.jpg) <small>www.youtube.com</small>FIGHT OF THE YEAR CONTENDER! 🤯 | Usman Nurmagomedov v Paul Hughes ...

‘Worst Scorecard In MMA History’... Fans Trash Insane Score For Usman
---------------------------------------------------------------------

 ![‘Worst scorecard in MMA history’... Fans trash insane score for Usman](https://bloodyelbow.com/wp-content/uploads/1/2025/10/PFL_20251003_CK-8413-scaled.jpg) <small>bloodyelbow.com</small>‘Worst scorecard in MMA history’... Fans trash insane score for Usman ...

PFL Dubai Results: Usman Nurmagomedov Defends Lightweight Title After
---------------------------------------------------------------------

 ![PFL Dubai Results: Usman Nurmagomedov Defends Lightweight Title After](https://middleeasy.com/wp-content/uploads/2026/02/Usman-Nurmagomedov-870x489.jpg) <small>middleeasy.com</small>PFL Dubai Results: Usman Nurmagomedov Defends Lightweight Title After ...

186 Usman Nurmagomedov Stock Photos, High-Res Pictures, And Images
------------------------------------------------------------------

 ![186 Usman Nurmagomedov Stock Photos, High-Res Pictures, and Images](https://media.gettyimages.com/id/2195373842/photo/dubai-united-arab-emirates-russias-usman-nurmagomedov-fights-irelands-paul-hughes-during-the.jpg?s=612x612&w=gi&k=20&c=KHvobfGyMJnTEYXvwbbLBS7fw-eivBfl3Svv1sKwQhY=) <small>www.gettyimages.co.uk</small>186 Usman Nurmagomedov Stock Photos, High-Res Pictures, and Images ...

186 Usman Nurmagomedov Stock Photos, High-Res Pictures, And Images
------------------------------------------------------------------

 ![186 Usman Nurmagomedov Stock Photos, High-Res Pictures, and Images](https://media.gettyimages.com/id/2195366447/photo/dubai-united-arab-emirates-russias-usman-nurmagomedov-fights-irelands-paul-hughes-during-the.jpg?s=612x612&w=gi&k=20&c=npkficxz63E_5M_0htmSiUeJOJbIeuTQKq7Lr16-pCo=) <small>www.gettyimages.co.uk</small>186 Usman Nurmagomedov Stock Photos, High-Res Pictures, and Images ...

Islam Makhachev On 'perfect Time' For Usman Nurmagomedov To Join UFC
--------------------------------------------------------------------

 ![Islam Makhachev on 'perfect time' for Usman Nurmagomedov to join UFC](https://mmajunkie.usatoday.com/gcdn/authoring/authoring-images/2026/02/07/SMMA/88570600007-usman-nurmagomedov-def-alfie-davis-pfl-road-to-dubai-44.JPG?crop=2399,1351,x0,y124&width=2399&height=1351&format=pjpg&auto=webp) <small>mmajunkie.usatoday.com</small>Islam Makhachev on 'perfect time' for Usman Nurmagomedov to join UFC

186 Usman Nurmagomedov Stock Photos, High-Res Pictures, And Images
------------------------------------------------------------------

 ![186 Usman Nurmagomedov Stock Photos, High-Res Pictures, and Images](https://media.gettyimages.com/id/2195369348/photo/dubai-united-arab-emirates-russias-usman-nurmagomedov-fights-irelands-paul-hughes-during-the.jpg?s=612x612&w=gi&k=20&c=pXE1K4tAPrs1QVsnKNhlbdC75pM3kSJaaaEMQjaN8Vk=) <small>www.gettyimages.co.uk</small>186 Usman Nurmagomedov Stock Photos, High-Res Pictures, and Images ...

Paul Hughes Vs Usman Nurmagomedov 2 Start Time, TV Channel Information
----------------------------------------------------------------------

 ![Paul Hughes vs Usman Nurmagomedov 2 start time, TV channel information](https://i2-prod.belfastlive.co.uk/article32597648.ece/ALTERNATES/s1200d/0_PFL_20251002_MBR_9064JPG.jpg) <small>www.belfastlive.co.uk</small>Paul Hughes vs Usman Nurmagomedov 2 start time, TV channel information ...

Fans Rage At Usman Nurmagomedov Vs Paul Hughes Scorecards As Russian
--------------------------------------------------------------------

 ![Fans rage at Usman Nurmagomedov vs Paul Hughes scorecards as Russian](https://s.yimg.com/ny/api/res/1.2/Gr9eSYhJhdYMkHofurCK6g--/YXBwaWQ9aGlnaGxhbmRlcjt3PTEyNDI7aD04Mjg-/https://media.zenfs.com/en/aol_uk_the_independent_uk_182/8822fc1215a08ba1915dced69c98d0f0) <small>www.aol.co.uk</small>Fans rage at Usman Nurmagomedov vs Paul Hughes scorecards as Russian ...

Usman Nurmagomedov Vs Paul Hughes 2 Live: Fight Result As Score Sparks
----------------------------------------------------------------------

 ![Usman Nurmagomedov vs Paul Hughes 2 live: Fight result as score sparks](https://static.independent.co.uk/2025/10/03/22/24/Hughes-vs-Nurmagomedov-2.jpeg) <small>www.independent.co.uk</small>Usman Nurmagomedov vs Paul Hughes 2 live: Fight result as score sparks ...

Russia's Usman Nurmagomedov Celebrates After Winning The Road To
----------------------------------------------------------------

 ![Russia's Usman Nurmagomedov celebrates after winning the Road To](https://media.gettyimages.com/id/2195374020/photo/usman-nurmagomedov-vs-paul-hughe-road-to-dubai-lightweight-title-fight.jpg?s=1024x1024&w=gi&k=20&c=4iesuwZji-f1wltSjGDQgNP4wyNNykgMBC8nq7A5sKI=) <small>www.gettyimages.in</small>Russia's Usman Nurmagomedov celebrates after winning the Road To ...

PFL: Usman Nurmagomedov Once Again Defeats Paul Hughes And Retains The
----------------------------------------------------------------------

 ![PFL: Usman Nurmagomedov once again defeats Paul Hughes and retains the](https://images.daznservices.com/di/library/DAZN_News/fe/9a/usman-nurmagomedov-10032025-ftr_ujwprztz0atd1793p065k2wxy.png?t=-1406537495) <small>www.dazn.com</small>PFL: Usman Nurmagomedov once again defeats Paul Hughes and retains the ...

186 Usman Nurmagomedov Stock Photos, High-Res Pictures, And Images
------------------------------------------------------------------

 ![186 Usman Nurmagomedov Stock Photos, High-Res Pictures, and Images](https://media.gettyimages.com/id/2195366452/photo/dubai-united-arab-emirates-russias-usman-nurmagomedov-fights-irelands-paul-hughes-during-the.jpg?s=612x612&w=gi&k=20&c=ckzqvWk02ZeTb82BOI0WeNzd0rTYjFvrSYAkP-ANvWM=) <small>www.gettyimages.co.uk</small>186 Usman Nurmagomedov Stock Photos, High-Res Pictures, and Images ...

Usman Nurmagomedov Vs Alfie Davis RECAP: Relive Usman Nurmagomedov's
--------------------------------------------------------------------

 ![Usman Nurmagomedov vs Alfie Davis RECAP: Relive Usman Nurmagomedov's](https://ichef.bbci.co.uk/ace/standard/640/cpsprodpb/vivo/live/images/2026/2/7/89ee560a-05ad-4d89-8a2c-6d544736c055.jpg.webp) <small>www.bbc.co.uk</small>Usman Nurmagomedov vs Alfie Davis RECAP: Relive Usman Nurmagomedov's ...

Usman Nurmagomedov Vs Alfie Davis RECAP: Relive Usman Nurmagomedov's
--------------------------------------------------------------------

 ![Usman Nurmagomedov vs Alfie Davis RECAP: Relive Usman Nurmagomedov's](https://ichef.bbci.co.uk/ace/standard/640/cpsprodpb/vivo/live/images/2026/2/7/1d69ae8c-a8c6-4c9a-a9f7-35cca9aecae8.jpg.webp) <small>www.bbc.com</small>Usman Nurmagomedov vs Alfie Davis RECAP: Relive Usman Nurmagomedov's ...

Paul Hughes Vs Usman Nurmagomedov 2: Start Time, Card And How To Watch
----------------------------------------------------------------------

 ![Paul Hughes vs Usman Nurmagomedov 2: Start time, card and how to watch](https://s.yimg.com/ny/api/res/1.2/prOQ1nM9w01HTMypqhrGTg--/YXBwaWQ9aGlnaGxhbmRlcjt3PTk2MDtoPTY1NDtjZj13ZWJw/https://media.zenfs.com/en/the_independent_577/9a85eea26345cc89514d6975c945c95c) <small>sg.news.yahoo.com</small>Paul Hughes vs Usman Nurmagomedov 2: Start time, card and how to watch ...

186 Usman Nurmagomedov Stock Photos, High-Res Pictures, And Images
------------------------------------------------------------------

 ![186 Usman Nurmagomedov Stock Photos, High-Res Pictures, and Images](https://media.gettyimages.com/id/2195366409/photo/dubai-united-arab-emirates-russias-usman-nurmagomedov-fights-irelands-paul-hughes-during-the.jpg?s=612x612&w=gi&k=20&c=4hEoUs5GtetPP_PMqfYfNPYPnkf3m1E3gFzKzuyq72s=) <small>www.gettyimages.co.uk</small>186 Usman Nurmagomedov Stock Photos, High-Res Pictures, and Images ...

Paul Hughes Vs Usman Nurmagomedov 2: Start Time, TV Channel, Live
-----------------------------------------------------------------

 ![Paul Hughes vs Usman Nurmagomedov 2: Start time, TV channel, live](https://www.thesun.ie/wp-content/uploads/sites/3/2025/09/Paul-Hughes-punches-Usman-Nurmagomedov-1536x838-2.png) <small>www.thesun.ie</small>Paul Hughes vs Usman Nurmagomedov 2: Start time, TV channel, live ...

“Much Closer Than That” – Fans Blast Wide Judges’ Scorecards As Usman
---------------------------------------------------------------------

 ![“Much Closer Than That” – Fans Blast Wide Judges’ Scorecards As Usman](https://media.mmanews.com/uploads/2025/10/Usman-Nurmagomedov.png) <small>www.mmanews.com</small>“Much Closer Than That” – Fans Blast Wide Judges’ Scorecards As Usman ...

What Time Is The Usman Nurmagomedov Vs Paul Hughes Fight Tonight
----------------------------------------------------------------

 ![What time is the Usman Nurmagomedov vs Paul Hughes fight tonight](https://images.daznservices.com/di/library/DAZN_News/8b/a6/nurmagomedov-hughes-weigh-in02102025_sl5gs6kqvz661xoipcfinl6aa.jpg?t=-1425651463) <small>www.dazn.com</small>What time is the Usman Nurmagomedov vs Paul Hughes fight tonight ...

Usman Nurmagomedov Vs Paul Hughes - Bellator Lightweight Title Fight
--------------------------------------------------------------------

 ![Usman Nurmagomedov vs Paul Hughes - Bellator lightweight title fight](https://ichef.bbci.co.uk/ace/standard/640/cpsprodpb/vivo/live/images/2025/1/25/935ba430-dbee-4fe8-bb4e-044f4e0960b2.jpg.webp) <small>www.bbc.co.uk</small>Usman Nurmagomedov vs Paul Hughes - Bellator lightweight title fight ...

Usman Nurmagomedov Beats Alexander Shabliy To Retain Bellator
-------------------------------------------------------------

 ![Usman Nurmagomedov Beats Alexander Shabliy To Retain Bellator](https://www.fightsports.tv/wp-content/uploads/Screenshot-2024-09-08-at-16.43.34.png) <small>www.fightsports.tv</small>Usman Nurmagomedov Beats Alexander Shabliy To Retain Bellator ...

MMA: Usman Nurmagomedov 'didn't Want Rematch' - Paul Hughes - BBC Sport
-----------------------------------------------------------------------

 ![MMA: Usman Nurmagomedov 'didn't want rematch' - Paul Hughes - BBC Sport](https://ichef.bbci.co.uk/ace/branded_sport/1200/cpsprodpb/ba35/live/9ad73700-7f67-11f0-9b45-d97edf6817de.jpg) <small>www.bbc.co.uk</small>MMA: Usman Nurmagomedov 'didn't want rematch' - Paul Hughes - BBC Sport

Usman Nurmagomedov Wins Another Instant Classic Against Paul Hughes In
----------------------------------------------------------------------

 ![Usman Nurmagomedov wins another instant classic against Paul Hughes in](https://platform.mmafighting.com/wp-content/uploads/sites/109/2025/10/PFL_20251003_CK-8466.jpg?quality=90&strip=all&crop=15.891350538261%2C0%2C66.703236423478%2C100&w=2048) <small>www.mmafighting.com</small>Usman Nurmagomedov wins another instant classic against Paul Hughes in ...

186 Usman Nurmagomedov Stock Photos, High-Res Pictures, And Images
------------------------------------------------------------------

 ![186 Usman Nurmagomedov Stock Photos, High-Res Pictures, and Images](https://media.gettyimages.com/id/2195373730/photo/dubai-united-arab-emirates-russias-usman-nurmagomedov-fights-irelands-paul-hughes-during-the.jpg?s=612x612&w=gi&k=20&c=mCWN2Ab18pYBIb3OWhqcewmJtSW5X-v4xXOt_a3xAII=) <small>www.gettyimages.co.uk</small>186 Usman Nurmagomedov Stock Photos, High-Res Pictures, and Images ...

¡El Rematch Más Cabrón Del Año En MMA: Usman Nurmagomedov Contra Paul
---------------------------------------------------------------------

 ![¡El Rematch Más Cabrón del Año en MMA: Usman Nurmagomedov Contra Paul](https://ichef.bbci.co.uk/ace/standard/3840/cpsprodpb/d88b/live/5f805cd0-db71-11ef-a991-65e04595f231.jpg) <small>mmanoticiasmx.blogspot.com</small>¡El Rematch Más Cabrón del Año en MMA: Usman Nurmagomedov Contra Paul ...

Usman Nurmagomedov Vs. Paul Hughes 2 Full Fight Video Highlights | MMA
----------------------------------------------------------------------

 ![Usman Nurmagomedov vs. Paul Hughes 2 full fight video highlights | MMA](https://platform.mmafighting.com/wp-content/uploads/sites/109/2025/10/PFL_20251003_CK-8850_4577e3.jpg?quality=90&strip=all&crop=16.648381788261%2C0%2C66.703236423478%2C100&w=1200) <small>www.mmafighting.com</small>Usman Nurmagomedov vs. Paul Hughes 2 full fight video highlights | MMA ...

Paul Hughes Vs Usman Nurmagomedov 2: Start Time, Fight Card, And How To
-----------------------------------------------------------------------

 ![Paul Hughes vs Usman Nurmagomedov 2: Start time, fight card, and how to](https://static.toiimg.com/thumb/msid-124274578,width-1070,height-580,imgsize-30162,resizemode-75,overlay-toi_sw,pt-32,y_pad-40/photo.jpg) <small>timesofindia.indiatimes.com</small>Paul Hughes vs Usman Nurmagomedov 2: Start time, fight card, and how to ...

186 Usman Nurmagomedov Stock Photos, High-Res Pictures, And Images
------------------------------------------------------------------

 ![186 Usman Nurmagomedov Stock Photos, High-Res Pictures, and Images](https://media.gettyimages.com/id/2195369087/photo/dubai-united-arab-emirates-russias-usman-nurmagomedov-fights-irelands-paul-hughes-during-the.jpg?s=612x612&w=gi&k=20&c=INjnwZokPRYMecNs1ncpgoC9nFcuvuhu6Y6RF25Mits=) <small>www.gettyimages.co.uk</small>186 Usman Nurmagomedov Stock Photos, High-Res Pictures, and Images ...

Paul hughes vs usman nurmagomedov 2: start time, card and how to watch. “much closer than that” – fans blast wide judges’ scorecards as usman. ¡el rematch más cabrón del año en mma: usman nurmagomedov contra paul
