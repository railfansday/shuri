---
title: "Usman Nurmagomedov Record - Bellator champion usman nurmagomedov says khabib is still active in his"
description: "usman nurmagomedov"
date: "2026-11-09"
categories:
- "Uncategorized"
images:
- "https://mmajunkie.usatoday.com/gcdn/authoring/images/smg/2025/02/21/SMMA/79485022007-91-2769596.jpeg?crop=1919,1079,x0,y0&amp;width=1919&amp;height=1079&amp;format=pjpg&amp;auto=webp"
featuredImage: "https://www.lowkickmma.com/wp-content/uploads/2023/02/Usman-Nurmagomedov-khabib-Nurmagomedov-1024x536.png"
featured_image: "https://www1-cdn.sherdog.com/_images/headers/20240908124557_Screenshot_20240908_at_12_45_15AM.PNG"
image: "https://www.themycenaean.org/wp-content/uploads/2025/02/unnamed-93.png"
---

If you are searching about Usman Nurmagomedov extends perfect record with 'amazing' win over Paul you've visit to the right place. We have 35 Images about Usman Nurmagomedov extends perfect record with 'amazing' win over Paul like Bellator Champions Series: Usman Nurmagomedov retains lightweight title, Usman Nurmagomedov: "I have one goal” - Will Khabib Nurmagomedov’s and also Usman Nurmagomedov Becomes New Bellator Lightweight Champion. Here it is:

Usman Nurmagomedov Extends Perfect Record With 'amazing' Win Over Paul
----------------------------------------------------------------------

 ![Usman Nurmagomedov extends perfect record with 'amazing' win over Paul](https://www.thenationalnews.com/resizer/v2/MSS32J2R7VE3XF3FQTCJZSB7GQ.jpg?auth=4b1571d5aab542650990418df547c3070142283fdaefa852fabc90452035537e) <small>www.thenationalnews.com</small>Usman Nurmagomedov extends perfect record with 'amazing' win over Paul ...

Usman Nurmagomedov Continúa El Legado: Se Proclama Campeón De Bellator
----------------------------------------------------------------------

 ![Usman Nurmagomedov continúa el legado: se proclama campeón de Bellator](https://s3.sportstatics.com/relevo/www/multimedia/202211/19/media/cortadas/usman-nurmagomedov-Rwn44wQ0UjUq4OPIXZ0ZUFI-1200x648@Relevo.jpg?w=1200&h=648) <small>www.relevo.com</small>Usman Nurmagomedov continúa el legado: se proclama campeón de Bellator ...

Usman Nurmagomedov: Net Worth 2023, Stats, Age And More
-------------------------------------------------------

 ![Usman Nurmagomedov: Net worth 2023, stats, age and more](https://static0.givemesportimages.com/wordpress/wp-content/uploads/2023/01/Usman-Nurmagomedov-bloody-in-the-Bellator-cage.jpg) <small>www.givemesport.com</small>Usman Nurmagomedov: Net worth 2023, stats, age and more

Usman Nurmagomedov Vs Paul Hughes: Irishman Hughes Falls Short In
-----------------------------------------------------------------

 ![Usman Nurmagomedov vs Paul Hughes: Irishman Hughes falls short in](https://ichef.bbci.co.uk/ace/standard/3840/cpsprodpb/d88b/live/5f805cd0-db71-11ef-a991-65e04595f231.jpg) <small>www.bbc.com</small>Usman Nurmagomedov vs Paul Hughes: Irishman Hughes falls short in ...

Usman Nurmagomedov Retains Lightweight Title In Bellator San Diego Main
-----------------------------------------------------------------------

 ![Usman Nurmagomedov Retains Lightweight Title in Bellator San Diego Main](https://www1-cdn.sherdog.com/_images/headers/20240908124557_Screenshot_20240908_at_12_45_15AM.PNG) <small>www.sherdog.com</small>Usman Nurmagomedov Retains Lightweight Title in Bellator San Diego Main ...

60 Usman Nurmagomedov Stock Photos, High-Res Pictures, And Images
-----------------------------------------------------------------

 ![60 Usman Nurmagomedov Stock Photos, High-Res Pictures, and Images](https://media.gettyimages.com/id/1713903093/photo/san-diego-ca-usman-nurmagomedov-speaks-with-the-media-at-the-bellator-300-post-fight-press.jpg?s=612x612&w=gi&k=20&c=t__3EplaI5XpbR0ndgyCZArbpxvcPZpVP3wh75DtR6o=) <small>www.gettyimages.com</small>60 Usman Nurmagomedov Stock Photos, High-Res Pictures, and Images ...

Usman Nurmagomedov Keeps Undefeated Record Intact At Bellator Champions
-----------------------------------------------------------------------

 ![Usman Nurmagomedov Keeps Undefeated Record Intact at Bellator Champions](https://static.wixstatic.com/media/2f92be_42dfdbeb6a364e22a4275ec7cc9eb2bf~mv2.png/v1/fill/w_980,h_1307,al_c,q_90,usm_0.66_1.00_0.01,enc_avif,quality_auto/2f92be_42dfdbeb6a364e22a4275ec7cc9eb2bf~mv2.png) <small>www.blackbeltmag.com</small>Usman Nurmagomedov Keeps Undefeated Record Intact at Bellator Champions ...

Usman Nurmagomedov Aims To Extend Family Legacy As 'Future Bellator
-------------------------------------------------------------------

 ![Usman Nurmagomedov Aims to Extend Family Legacy as 'Future Bellator](https://www.si.com/.image/t_share/MTkxMDUxODYxMTkxNjMyNTM5/img_4504.jpg) <small>www.si.com</small>Usman Nurmagomedov Aims to Extend Family Legacy as 'Future Bellator ...

Usman Nurmagomedov Remains Undefeated With Domination Of Brent Primus
---------------------------------------------------------------------

 ![Usman Nurmagomedov Remains Undefeated With Domination Of Brent Primus](https://middleeasy.com/wp-content/uploads/2023/10/usman-win.jpg) <small>middleeasy.com</small>Usman Nurmagomedov Remains Undefeated With Domination Of Brent Primus ...

Usman Nurmagomedov | Lightweight (155)
--------------------------------------

 ![Usman Nurmagomedov | Lightweight (155)](https://pflmma-prod.s3.amazonaws.com/fighters/bodyshots/92437d563b321755000d20fc72aed614-1.png) <small>pflmma.com</small>Usman Nurmagomedov | Lightweight (155)

Usman Nurmagomedov | Lightweight (155)
--------------------------------------

 ![Usman Nurmagomedov | Lightweight (155)](https://pflmma-prod.s3.amazonaws.com/fighters/bodyshots/4ccd8d6d39f4746f8722f23f13dd9d17-1-1.png) <small>pflmma.com</small>Usman Nurmagomedov | Lightweight (155)

5 Opponents For Usman Nurmagomedov In Bellator
----------------------------------------------

 ![5 opponents for Usman Nurmagomedov in Bellator](https://staticc.sportskeeda.com/editor/2022/01/d329d-16425625016853-1920.jpg) <small>www.sportskeeda.com</small>5 opponents for Usman Nurmagomedov in Bellator

Bellator Champions Series: Usman Nurmagomedov Retains Lightweight Title
-----------------------------------------------------------------------

 ![Bellator Champions Series: Usman Nurmagomedov retains lightweight title](https://blogs.rdxsports.com/wp-content/uploads/2024/09/usman-nurmagomedov.jpg) <small>blogs.rdxsports.com</small>Bellator Champions Series: Usman Nurmagomedov retains lightweight title ...

PFL News: Usman Nurmagomedov Remains Undefeated With Majority Decision
----------------------------------------------------------------------

 ![PFL News: Usman Nurmagomedov Remains Undefeated With Majority Decision](https://d.newsweek.com/en/full/2573592/bellator-champion-usman-nurmagomedov.jpg) <small>www.newsweek.com</small>PFL News: Usman Nurmagomedov Remains Undefeated With Majority Decision ...

Usman Nurmagomedov Wants To Prove Khabib Nurmagomedov Right: "I Am The
----------------------------------------------------------------------

 ![Usman Nurmagomedov wants to prove Khabib Nurmagomedov right: "I am the](https://www.bjpenn.com/wp-content/uploads/2023/11/Usman-Nurmagomedov-1024x576.webp) <small>www.bjpenn.com</small>Usman Nurmagomedov wants to prove Khabib Nurmagomedov right: "I am the ...

The Unstoppable Legacy Of The Nurmagomedov Dynasty - The Mycenaean
------------------------------------------------------------------

 ![The Unstoppable Legacy of the Nurmagomedov Dynasty - The Mycenaean](https://www.themycenaean.org/wp-content/uploads/2025/02/unnamed-93.png) <small>www.themycenaean.org</small>The Unstoppable Legacy of the Nurmagomedov Dynasty - The Mycenaean

Usman Nurmagomedov: "I Have One Goal” - Will Khabib Nurmagomedov’s
------------------------------------------------------------------

 ![Usman Nurmagomedov: "I have one goal” - Will Khabib Nurmagomedov’s](https://staticg.sportskeeda.com/editor/2023/09/c2d37-16958099721227-1920.jpg) <small>www.sportskeeda.com</small>Usman Nurmagomedov: "I have one goal” - Will Khabib Nurmagomedov’s ...

60 Usman Nurmagomedov Stock Photos, High-Res Pictures, And Images
-----------------------------------------------------------------

 ![60 Usman Nurmagomedov Stock Photos, High-Res Pictures, and Images](https://media.gettyimages.com/id/1713903474/photo/san-diego-ca-usman-nurmagomedov-speaks-with-the-media-at-the-bellator-300-post-fight-press.jpg?s=612x612&w=gi&k=20&c=q1Dw0qdEKoEhC-Q9SZ-enmwvoAppaNi2wA27Ur_YSv8=) <small>www.gettyimages.co.uk</small>60 Usman Nurmagomedov Stock Photos, High-Res Pictures, and Images ...

Usman Nurmagomedov: I Was '50 Percent' In Bellator Title Win Over Paul
----------------------------------------------------------------------

 ![Usman Nurmagomedov: I was '50 percent' in Bellator title win over Paul](https://mmajunkie.usatoday.com/gcdn/authoring/images/smg/2025/01/25/SMGW/77950114007-91-2800607.jpeg?crop=5999,3375,x0,y0&width=3200&height=1801&format=pjpg&auto=webp) <small>mmajunkie.usatoday.com</small>Usman Nurmagomedov: I was '50 percent' in Bellator title win over Paul ...

Video: Where Does Bellator's Usman Nurmagomedov Rank Among The Best
-------------------------------------------------------------------

 ![Video: Where does Bellator's Usman Nurmagomedov rank among the best](https://mmajunkie.usatoday.com/gcdn/authoring/images/smg/2025/02/21/SMMA/79485022007-91-2769596.jpeg?crop=1919,1079,x0,y0&width=1919&height=1079&format=pjpg&auto=webp) <small>mmajunkie.usatoday.com</small>Video: Where does Bellator's Usman Nurmagomedov rank among the best ...

Usman Nurmagomedov: "I Have One Goal” - Will Khabib Nurmagomedov’s
------------------------------------------------------------------

 ![Usman Nurmagomedov: "I have one goal” - Will Khabib Nurmagomedov’s](https://img.youtube.com/vi/WtXajAF_5DM/sddefault.jpg) <small>www.sportskeeda.com</small>Usman Nurmagomedov: "I have one goal” - Will Khabib Nurmagomedov’s ...

Bellator Champion Usman Nurmagomedov Says Khabib Is Still Active In His
-----------------------------------------------------------------------

 ![Bellator Champion Usman Nurmagomedov Says Khabib Is Still Active In His](https://www.lowkickmma.com/wp-content/uploads/2023/02/Usman-Nurmagomedov-khabib-Nurmagomedov-1024x536.png) <small>www.lowkickmma.com</small>Bellator Champion Usman Nurmagomedov Says Khabib Is Still Active In His ...

Bellator Champions Series: Usman Nurmagomedov Retains Lightweight Title
-----------------------------------------------------------------------

 ![Bellator Champions Series: Usman Nurmagomedov retains lightweight title](https://blogs.rdxsports.com/wp-content/uploads/2024/09/usman-nurmagomedov-2.jpg) <small>blogs.rdxsports.com</small>Bellator Champions Series: Usman Nurmagomedov retains lightweight title ...

Bellator 300 - Victoire Facile D'Usman Nurmagomedov
---------------------------------------------------

 ![Bellator 300 - Victoire facile d'Usman Nurmagomedov](https://lasueur.com/wp-content/uploads/2023/10/victoire-facile-usman-nurmagomedov-1054x593.jpg) <small>lasueur.com</small>Bellator 300 - Victoire facile d'Usman Nurmagomedov

Usman Nurmagomedov Keeps Undefeated Record Intact At Bellator Champions
-----------------------------------------------------------------------

 ![Usman Nurmagomedov Keeps Undefeated Record Intact at Bellator Champions](https://static.wixstatic.com/media/0eb2e4_e4c03cc0bfff4c7eab7198c5ed00de1c~mv2.png/v1/fill/w_980,h_652,al_c,q_90,usm_0.66_1.00_0.01,enc_avif,quality_auto/0eb2e4_e4c03cc0bfff4c7eab7198c5ed00de1c~mv2.png) <small>www.blackbeltmag.com</small>Usman Nurmagomedov Keeps Undefeated Record Intact at Bellator Champions ...

Usman Nurmagomedov: Top 5 MMA Finishes - Kung-fu Kingdom
--------------------------------------------------------

 ![Usman Nurmagomedov: Top 5 MMA Finishes - Kung-fu Kingdom](https://kungfukingdom.com/wp-content/uploads/2023/05/Usman-Nurmagomedov-Top-5-MMA-Finishes-KUNG-FU-KINGDOM-770X472-767x469.jpg) <small>kungfukingdom.com</small>Usman Nurmagomedov: Top 5 MMA Finishes - Kung-fu Kingdom

Usman Nurmagomedov Headlines Bellator Paris On Return From Suspension
---------------------------------------------------------------------

 ![Usman Nurmagomedov headlines Bellator Paris on return from suspension](https://ichef.bbci.co.uk/ace/standard/1024/cpsprodpb/1572F/production/_132855878_1t6a4440.jpg) <small>www.bbc.com</small>Usman Nurmagomedov headlines Bellator Paris on return from suspension ...

10 Best MMA Fighters Out Of Dagestan
------------------------------------

 ![10 Best MMA Fighters Out Of Dagestan](https://static0.thesportsterimages.com/wordpress/wp-content/uploads/2023/12/usman-nurmagomedov-making-his-entrance.jpg?q=49&fit=crop&w=423&h=300&dpr=2) <small>www.thesportster.com</small>10 Best MMA Fighters Out Of Dagestan

MMA - Le Bellator De Retour En France En 2024 Avec Usman Nurmagomedov
---------------------------------------------------------------------

 ![MMA - Le Bellator de retour en France en 2024 avec Usman Nurmagomedov](https://lasueur.com/wp-content/uploads/2023/10/Usman-Nurmagomedov.jpg) <small>lasueur.com</small>MMA - Le Bellator de retour en France en 2024 avec Usman Nurmagomedov

Usman Nurmagomedov Extends Perfect Record With 'amazing' Win Over Paul
----------------------------------------------------------------------

 ![Usman Nurmagomedov extends perfect record with 'amazing' win over Paul](https://www.thenationalnews.com/resizer/v2/U2FCUNFAPRF25BZACFHECKACGM.jpg?auth=70773c6b29c05da0008b983da71eb337425d8b2a204af93e663530d5cc8160fa) <small>www.thenationalnews.com</small>Usman Nurmagomedov extends perfect record with 'amazing' win over Paul ...

Усман Нурмагомедов победил Пола Хьюза в бою за титул чемпиона PFL
-----------------------------------------------------------------

 ![Усман Нурмагомедов победил Пола Хьюза в бою за титул чемпиона PFL](https://s-cdn.sportbox.ru/images/styles/1920_1080/fp_fotos/e6/88/b83ae8150862483ed7f9c2f279fe580d618e3422ba053998545440.jpg) <small>news.sportbox.ru</small>Усман Нурмагомедов победил Пола Хьюза в бою за титул чемпиона PFL

Usman Nurmagomedov Outlines Future Pathway To The UFC Ahead Of Title
--------------------------------------------------------------------

 ![Usman Nurmagomedov outlines future pathway to the UFC ahead of title](https://bloodyelbow.com/wp-content/uploads/1/2024/10/GettyImages-2170781806.jpg) <small>bloodyelbow.com</small>Usman Nurmagomedov outlines future pathway to the UFC ahead of title ...

Usman Nurmagomedov (MMA): Next Fight, Last Fight Result, MMA Record (table)
---------------------------------------------------------------------------

 ![Usman Nurmagomedov (MMA): next fight, last fight result, MMA record (table)](https://champinon.info/images/nurmagomedov-vs-hughes.webp) <small>champinon.info</small>Usman Nurmagomedov (MMA): next fight, last fight result, MMA record (table)

Usman Nurmagomedov Becomes New Bellator Lightweight Champion
------------------------------------------------------------

 ![Usman Nurmagomedov Becomes New Bellator Lightweight Champion](https://jitsmagazine.com/wp-content/uploads/2022/11/Usman-Nurmagomedov-Bellator-Champion.png) <small>jitsmagazine.com</small>Usman Nurmagomedov Becomes New Bellator Lightweight Champion ...

Usman Nurmagomedov | Lightweight (155)
--------------------------------------

 ![Usman Nurmagomedov | Lightweight (155)](https://pflmma-prod.s3.amazonaws.com/articles/thumbnails/ca139c965ec31345f38d862714ba38e8-1.png) <small>pflmma.com</small>Usman Nurmagomedov | Lightweight (155)

usman nurmagomedov retains lightweight title in bellator san diego main .... usman nurmagomedov. 5 opponents for usman nurmagomedov in bellator
