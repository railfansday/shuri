---
title: "Usman Nurmagomedov Height - Usman nurmagomedov def. paul hughes at pfl dubai: best photos"
description: "usman nurmagomedov"
date: "2026-01-31"
categories:
- "Uncategorized"
images:
- "https://mmajunkie.usatoday.com/gcdn/authoring/authoring-images/2026/02/07/SMMA/88570571007-usman-nurmagomedov-def-alfie-davis-pfl-road-to-dubai-18.JPG?width=660&amp;height=441&amp;fit=crop&amp;format=pjpg&amp;auto=webp"
featuredImage: "https://mmajunkie.usatoday.com/gcdn/authoring/images/smg/2025/01/08/SMGW/77546964007-91-2796568.jpeg?crop=999,563,x0,y18&amp;width=999&amp;height=563&amp;format=pjpg&amp;auto=webp"
featured_image: "https://blogs.rdxsports.com/wp-content/uploads/2024/09/usman-nurmagomedov.jpg"
image: "https://mmajunkie.usatoday.com/gcdn/authoring/authoring-images/2025/12/11/SMMA/87710605007-usman.jpg?crop=1918,1078,x1,y0&amp;width=1918&amp;height=1078&amp;format=pjpg&amp;auto=webp"
---

If you are searching about Usman Nurmagomedov def. Paul Hughes at PFL Dubai: Best photos you've came to the right page. We have 35 Pictures about Usman Nurmagomedov def. Paul Hughes at PFL Dubai: Best photos like Usman Nurmagomedov Stats, Record &amp; Fight History | MMA Junkie, Usman Nurmagomedov | Lightweight (155) and also Here's Who A.I Thinks Are The 10 Best MMA Fighters Of All Time. Read more:

Usman Nurmagomedov Def. Paul Hughes At PFL Dubai: Best Photos
-------------------------------------------------------------

 ![Usman Nurmagomedov def. Paul Hughes at PFL Dubai: Best photos](https://mmajunkie.usatoday.com/gcdn/authoring/authoring-images/2025/10/03/SMMA/86506162007-usman-nurmagomedov-def-paul-hughes-pfl-cs-dubai-10.jpg?width=660&height=441&fit=crop&format=pjpg&auto=webp) <small>mmajunkie.usatoday.com</small>Usman Nurmagomedov def. Paul Hughes at PFL Dubai: Best photos

Umar Nurmagomedov Brothers: How Many Siblings Does He Have
----------------------------------------------------------

 ![Umar Nurmagomedov Brothers: How Many Siblings Does He Have](https://image-cdn.essentiallysports.com/wp-content/uploads/Untitled-design-90-6.png) <small>www.essentiallysports.com</small>Umar Nurmagomedov Brothers: How Many Siblings Does He Have ...

Here's Who A.I Thinks Are The 10 Best MMA Fighters Of All Time
--------------------------------------------------------------

 ![Here's Who A.I Thinks Are The 10 Best MMA Fighters Of All Time](https://static0.thesportsterimages.com/wordpress/wp-content/uploads/2024/08/khabib-nurmagomedov-age-height-wife-children-and-more.jpg) <small>www.thesportster.com</small>Here's Who A.I Thinks Are The 10 Best MMA Fighters Of All Time

The 11 Greatest Russian MMA Fighters Of All Time - Ranked - Lentedesportiva
---------------------------------------------------------------------------

 ![The 11 Greatest Russian MMA Fighters of All Time - Ranked - Lentedesportiva](https://lentedesportiva.com/wp-content/uploads/2025/08/UsmanNurmagomedov.png) <small>lentedesportiva.com</small>The 11 Greatest Russian MMA Fighters of All Time - Ranked - Lentedesportiva

Usman Nurmagomedov Stats, Record &amp; Fight History | MMA Junkie
-----------------------------------------------------------------

 ![Usman Nurmagomedov Stats, Record & Fight History | MMA Junkie](https://www.gannett-cdn.com/authoring/authoring-images/2026/02/06/SMMA/88552942007-usman-nurmagomedov-pfl-road-to-dubai-ceremonial-weighins-2.jpg?auto=webp&width=1080&quality=75) <small>mmajunkie.usatoday.com</small>Usman Nurmagomedov Stats, Record &amp; Fight History | MMA Junkie

Usman Nurmagomedov (MMA): Next Fight, Last Fight Result, MMA Record (table)
---------------------------------------------------------------------------

 ![Usman Nurmagomedov (MMA): next fight, last fight result, MMA record (table)](https://champinon.info/images/usman-nurmagomedov_b.webp) <small>champinon.info</small>Usman Nurmagomedov (MMA): next fight, last fight result, MMA record (table)

Usman Nurmagomedov MMA Stats, Pictures, News, Videos, Biography
---------------------------------------------------------------

 ![Usman Nurmagomedov MMA Stats, Pictures, News, Videos, Biography](https://www.sherdog.com/image_crop/200/300/_images/fighter/20221014020409_Usman_Nurmagomedov.JPEG) <small>www.sherdog.com</small>Usman Nurmagomedov MMA Stats, Pictures, News, Videos, Biography ...

Legendary UFC Champs Boldly Predict Usman Nurmagomedov’s Fate Against
---------------------------------------------------------------------

 ![Legendary UFC Champs Boldly Predict Usman Nurmagomedov’s Fate Against](https://image-cdn.essentiallysports.com/wp-content/uploads/Khabib-Nurmagomedov-Usman-Nurmagomedov-1.jpg) <small>www.essentiallysports.com</small>Legendary UFC Champs Boldly Predict Usman Nurmagomedov’s Fate Against ...

Usman Nurmagomedov | Lightweight (155)
--------------------------------------

 ![Usman Nurmagomedov | Lightweight (155)](https://pflmma-prod.s3.amazonaws.com/fighters/bodyshots/4ccd8d6d39f4746f8722f23f13dd9d17-1-1.png) <small>pflmma.com</small>Usman Nurmagomedov | Lightweight (155)

Usman Nurmagomedov Def. Alfie Davis At PFL: Road To Dubai: Best Photos
----------------------------------------------------------------------

 ![Usman Nurmagomedov def. Alfie Davis at PFL: Road to Dubai: Best photos](https://mmajunkie.usatoday.com/gcdn/authoring/authoring-images/2026/02/07/SMMA/88570571007-usman-nurmagomedov-def-alfie-davis-pfl-road-to-dubai-18.JPG?width=660&height=441&fit=crop&format=pjpg&auto=webp) <small>mmajunkie.usatoday.com</small>Usman Nurmagomedov def. Alfie Davis at PFL: Road to Dubai: Best photos

UFC China: Usman Nurmagomedov Gera Polêmica Após Derrota Do Irmão - Ag
----------------------------------------------------------------------

 ![UFC China: Usman Nurmagomedov gera polêmica após derrota do irmão - Ag](https://cdn.agfight.com/wp-content/uploads/2025/01/usman-khabib-makhachev-pfl-1000x600.jpg) <small>agfight.com</small>UFC China: Usman Nurmagomedov gera polêmica após derrota do irmão - Ag ...

Usman Nurmagomedov Net Worth In 2026 - Surprise Sports
------------------------------------------------------

 ![Usman Nurmagomedov Net Worth in 2026 - Surprise Sports](https://surprisesports.com/wp-content/uploads/2025/01/Usman-Nurmagomedov-Biography.jpg) <small>surprisesports.com</small>Usman Nurmagomedov Net Worth in 2026 - Surprise Sports

Team Khabib Aims To Turn Usman Nurmagomedov Into A Legend Like Muhammad Ali
---------------------------------------------------------------------------

 ![Team Khabib Aims To Turn Usman Nurmagomedov Into A Legend Like Muhammad Ali](https://www.totalprosports.com/wp-content/uploads/2026/01/Usman-Nurmagomedov-and-Muhammad-Ali.jpg) <small>www.totalprosports.com</small>Team Khabib Aims To Turn Usman Nurmagomedov Into A Legend Like Muhammad Ali

Usman Nurmagomedov – Next Fight, News, Latest Fights, MMA Fight Record
----------------------------------------------------------------------

 ![Usman Nurmagomedov – Next fight, news, latest fights, MMA fight record](https://ringside24.com/media/cache/86/c1/86c1d4f317ea317f5cf1c530adb985fd.jpg) <small>ringside24.com</small>Usman Nurmagomedov – Next fight, news, latest fights, MMA fight record ...

Usman Nurmagomedov Addresses Potential UFC Move As PFL Deal Winds Down
----------------------------------------------------------------------

 ![Usman Nurmagomedov addresses potential UFC move as PFL deal winds down](https://mmajunkie.usatoday.com/gcdn/authoring/authoring-images/2025/12/11/SMMA/87710605007-usman.jpg?crop=1918,1078,x1,y0&width=1918&height=1078&format=pjpg&auto=webp) <small>mmajunkie.usatoday.com</small>Usman Nurmagomedov addresses potential UFC move as PFL deal winds down

Umar Nurmagomedov On Brother Usman's UFC Future
-----------------------------------------------

 ![Umar Nurmagomedov on brother Usman's UFC future](https://mmajunkie.usatoday.com/gcdn/authoring/authoring-images/2026/08/01/SMMA/91130785007-usman-2.jpg?crop=1919,1079,x0,y0&width=1919&height=1079&format=pjpg&auto=webp) <small>mmajunkie.usatoday.com</small>Umar Nurmagomedov on brother Usman's UFC future

PBP - Bellator 292 - (GP Dpos Leves) Usman Nurmagomedov X Ben Henderson
-----------------------------------------------------------------------

 ![PBP - Bellator 292 - (GP dpos Leves) Usman Nurmagomedov x Ben Henderson](https://s2.glbimg.com/gQapb2UmRB89ddoVCHGP7NmZJ8c=/0x0:3850x2567/984x0/smart/filters:strip_icc()/i.s3.glbimg.com/v1/AUTH_bc8228b6673f488aa253bbcb03c80ec5/internal_photos/bs/2023/P/P/hOuq4KS0yzaINUKozRpQ/usman.jpeg) <small>forum.portaldovt.com.br</small>PBP - Bellator 292 - (GP dpos Leves) Usman Nurmagomedov x Ben Henderson ...

Islam Makhachev On 'perfect Time' For Usman Nurmagomedov To Join UFC
--------------------------------------------------------------------

 ![Islam Makhachev on 'perfect time' for Usman Nurmagomedov to join UFC](https://mmajunkie.usatoday.com/gcdn/authoring/authoring-images/2026/02/07/SMMA/88570600007-usman-nurmagomedov-def-alfie-davis-pfl-road-to-dubai-44.JPG?crop=2399,1351,x0,y124&width=2399&height=1351&format=pjpg&auto=webp) <small>mmajunkie.usatoday.com</small>Islam Makhachev on 'perfect time' for Usman Nurmagomedov to join UFC

Usman Nurmagomedov - Stats MMA Fighter, Rank, News &amp; Biography
------------------------------------------------------------------

 ![Usman Nurmagomedov - stats MMA fighter, Rank, News & Biography](https://gidstats.com/img/fighters/0/0/1-23.jpg) <small>gidstats.com</small>Usman Nurmagomedov - stats MMA fighter, Rank, News &amp; Biography ...

Usman Nurmagomedov Extends Perfect Record With 'amazing' Win Over Paul
----------------------------------------------------------------------

 ![Usman Nurmagomedov extends perfect record with 'amazing' win over Paul](https://www.thenationalnews.com/resizer/v2/U2FCUNFAPRF25BZACFHECKACGM.jpg?auth=70773c6b29c05da0008b983da71eb337425d8b2a204af93e663530d5cc8160fa) <small>www.thenationalnews.com</small>Usman Nurmagomedov extends perfect record with 'amazing' win over Paul ...

Усман нурмагомедов когда бой
----------------------------

 ![Усман нурмагомедов когда бой](https://static0.givemesportimages.com/wordpress/wp-content/uploads/2023/01/Usman-Nurmagomedov-net-worth-2023.jpg) <small>playbookpro.ru</small>Усман нурмагомедов когда бой

Usman Nurmagomedov Not Interested In Second PFL Belt After Dubai Win
--------------------------------------------------------------------

 ![Usman Nurmagomedov not interested in second PFL belt after Dubai win](https://mmajunkie.usatoday.com/gcdn/authoring/authoring-images/2026/02/07/SMMA/88570598007-usman-nurmagomedov-def-alfie-davis-pfl-road-to-dubai-42.JPG?crop=2399,1351,x0,y124&width=2399&height=1351&format=pjpg&auto=webp) <small>mmajunkie.usatoday.com</small>Usman Nurmagomedov not interested in second PFL belt after Dubai win

'Paul Hughes Is Legit': Fighters React To Usman Nurmagomedov's Title
--------------------------------------------------------------------

 !['Paul Hughes is legit': Fighters react to Usman Nurmagomedov's title](https://mmajunkie.usatoday.com/gcdn/authoring/images/smg/2025/01/25/SMGW/77950173007-91-2800606.jpeg?crop=5999,3375,x0,y312&width=3200&height=1801&format=pjpg&auto=webp) <small>mmajunkie.usatoday.com</small>'Paul Hughes is legit': Fighters react to Usman Nurmagomedov's title ...

Usman Nurmagomedov: Net Worth 2023, Stats, Age And More
-------------------------------------------------------

 ![Usman Nurmagomedov: Net worth 2023, stats, age and more](https://static0.givemesportimages.com/wordpress/wp-content/uploads/2023/01/Usman-Nurmagomedov-profile-picture.jpg) <small>www.givemesport.com</small>Usman Nurmagomedov: Net worth 2023, stats, age and more

Usman Nurmagomedov | Lightweight (155)
--------------------------------------

 ![Usman Nurmagomedov | Lightweight (155)](https://pflmma-prod.s3.amazonaws.com/fighters/bodyshots/92437d563b321755000d20fc72aed614-1.png) <small>pflmma.com</small>Usman Nurmagomedov | Lightweight (155)

'Dubai More Than A Second Home': Usman Nurmagomedov Retains PFL Belt
--------------------------------------------------------------------

 !['Dubai more than a second home': Usman Nurmagomedov retains PFL belt](https://imgengine.khaleejtimes.com/khaleejtimes-english/2026-02-08/8hfintk8/Usman-Title-defense?width=1200&height=630&q=60&format=auto&ogImage=true&mode=crop&rect=0,0,2400,1600) <small>www.khaleejtimes.com</small>'Dubai more than a second home': Usman Nurmagomedov retains PFL belt ...

¡El Rematch Más Cabrón Del Año En MMA: Usman Nurmagomedov Contra Paul
---------------------------------------------------------------------

 ![¡El Rematch Más Cabrón del Año en MMA: Usman Nurmagomedov Contra Paul](https://ichef.bbci.co.uk/ace/standard/3840/cpsprodpb/d88b/live/5f805cd0-db71-11ef-a991-65e04595f231.jpg) <small>mmanoticiasmx.blogspot.com</small>¡El Rematch Más Cabrón del Año en MMA: Usman Nurmagomedov Contra Paul ...

Usman Nurmagomedov Record: 22-0-0 — Stats &amp; Fights
------------------------------------------------------

 ![Usman Nurmagomedov Record: 22-0-0 — Stats & Fights](https://combat-edge.com/og/fighter/usman-nurmagomedov-9873.png?v=20260529) <small>combat-edge.com</small>Usman Nurmagomedov Record: 22-0-0 — Stats &amp; Fights

Usman Nurmagomedov To Defend PFL Title Against Britain’s Alfie Davis
--------------------------------------------------------------------

 ![Usman Nurmagomedov to defend PFL title against Britain’s Alfie Davis](https://static.independent.co.uk/2025/11/20/14/59/Usman-Nurmagomedov.jpeg) <small>www.independent.co.uk</small>Usman Nurmagomedov to defend PFL title against Britain’s Alfie Davis ...

Usman Nurmagomedov Makes Statement With Strong Performance To Claim PFL
-----------------------------------------------------------------------

 ![Usman Nurmagomedov makes statement with strong performance to claim PFL](https://pflmma-prod.s3.amazonaws.com/articles/thumbnails/0105ce73386d4a11d68166c3aa78d405-1-1.png) <small>pflmma.com</small>Usman Nurmagomedov makes statement with strong performance to claim PFL ...

Is Usman Nurmagomedov A Better And Improved Version Of Khabib Nurmagomedov?
---------------------------------------------------------------------------

 ![Is Usman Nurmagomedov a better and improved version of Khabib Nurmagomedov?](https://staticg.sportskeeda.com/editor/2022/12/0bbeb-16720865660279-1920.jpg) <small>www.sportskeeda.com</small>Is Usman Nurmagomedov a better and improved version of Khabib Nurmagomedov?

Russia's Usman Nurmagomedov Celebrates After Winning The Road To
----------------------------------------------------------------

 ![Russia's Usman Nurmagomedov celebrates after winning the Road To](https://media.gettyimages.com/id/2195374020/photo/usman-nurmagomedov-vs-paul-hughe-road-to-dubai-lightweight-title-fight.jpg?s=1024x1024&w=gi&k=20&c=4iesuwZji-f1wltSjGDQgNP4wyNNykgMBC8nq7A5sKI=) <small>www.gettyimages.in</small>Russia's Usman Nurmagomedov celebrates after winning the Road To ...

Usman Nurmagomedov 'more Stressed' For Brother Umar, Islam Makhachev At
-----------------------------------------------------------------------

 ![Usman Nurmagomedov 'more stressed' for brother Umar, Islam Makhachev at](https://mmajunkie.usatoday.com/gcdn/authoring/images/smg/2025/01/08/SMGW/77546964007-91-2796568.jpeg?crop=999,563,x0,y18&width=999&height=563&format=pjpg&auto=webp) <small>mmajunkie.usatoday.com</small>Usman Nurmagomedov 'more stressed' for brother Umar, Islam Makhachev at ...

Usman Nurmagomedov Stats, Record &amp; Fight History | MMA Junkie
-----------------------------------------------------------------

 ![Usman Nurmagomedov Stats, Record & Fight History | MMA Junkie](https://www.gannett-cdn.com/authoring/images/smg/2025/02/21/SMMA/79491279007-91-2768463.jpeg?auto=webp&width=1920&quality=75) <small>mmajunkie.usatoday.com</small>Usman Nurmagomedov Stats, Record &amp; Fight History | MMA Junkie

Bellator Champions Series: Usman Nurmagomedov Retains Lightweight Title
-----------------------------------------------------------------------

 ![Bellator Champions Series: Usman Nurmagomedov retains lightweight title](https://blogs.rdxsports.com/wp-content/uploads/2024/09/usman-nurmagomedov.jpg) <small>blogs.rdxsports.com</small>Bellator Champions Series: Usman Nurmagomedov retains lightweight title ...

Is usman nurmagomedov a better and improved version of khabib nurmagomedov?. usman nurmagomedov. Usman nurmagomedov record: 22-0-0 — stats &amp; fights
