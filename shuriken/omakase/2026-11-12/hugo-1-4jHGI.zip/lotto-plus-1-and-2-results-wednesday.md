---
title: "Lotto Plus 1 And 2 Results Wednesday - Lotto plus 1 &amp; 2 results 15 nov 2025"
description: "Bad news for reset lotto and lotto plus 1 and 2 on saturday 9 may 2026"
date: "2026-05-08"
categories:
- "Uncategorized"
images:
- "https://pbs.twimg.com/media/EOX9TJlUUAArL9n.png"
featuredImage: "https://www.thesouthafrican.com/wp-content/uploads/2026/04/Lotto-and-Lotto-Plus-1-and-2-on-Wednesday-15-April-2026_1-1200x319.png"
featured_image: "https://www.thesouthafrican.com/wp-content/uploads/2026/04/Lotto-and-Lotto-Plus-1-and-2-on-Wednesday-29-April-2026_1-960x257.png"
image: "https://www.thesouthafrican.com/wp-content/uploads/2026/02/Lotto-and-Lotto-Plus-1-and-2-on-Wednesday-25-February-2026_3.jpg.optimal.jpg"
---

If you are looking for R98 million UP for grabs: Lotto and Lotto Plus 1 and 2 on Wednesday 29 you've visit to the right page. We have 35 Pics about R98 million UP for grabs: Lotto and Lotto Plus 1 and 2 on Wednesday 29 like The Lotto and Lotto Plus 1 and 2 results for Wednesday, 1 April 2026, No winner of Wednesday’s Lotto jackpots: All the numbers and payouts and also The Lotto and Lotto Plus 1 and 2 results for Wednesday, 1 April 2026. Here you go:

R98 Million UP For Grabs: Lotto And Lotto Plus 1 And 2 On Wednesday 29
----------------------------------------------------------------------

 ![R98 million UP for grabs: Lotto and Lotto Plus 1 and 2 on Wednesday 29](https://www.thesouthafrican.com/wp-content/uploads/2026/04/Lotto-and-Lotto-Plus-1-and-2-on-Wednesday-29-April-2026_1.png) <small>www.thesouthafrican.com</small>R98 million UP for grabs: Lotto and Lotto Plus 1 and 2 on Wednesday 29 ...

Lotto Results Lotto Plus 1 And 2 Today New Arrivals
---------------------------------------------------

 ![Lotto results lotto plus 1 and 2 today new arrivals](https://www.saffarazzi.com/wp-content/uploads/2021/10/lotto-and-lotto-plus-results-saturday-south-africa.webp) <small>pediatrianorte.med.uchile.cl</small>Lotto results lotto plus 1 and 2 today new arrivals

R98 Million UP For Grabs: Lotto And Lotto Plus 1 And 2 On Wednesday 29
----------------------------------------------------------------------

 ![R98 million UP for grabs: Lotto and Lotto Plus 1 and 2 on Wednesday 29](https://www.thesouthafrican.com/wp-content/uploads/2026/04/Lotto-and-Lotto-Plus-1-and-2-on-Wednesday-29-April-2026_1-1200x321.png) <small>www.thesouthafrican.com</small>R98 million UP for grabs: Lotto and Lotto Plus 1 and 2 on Wednesday 29 ...

The Lotto And Lotto Plus 1 And 2 Results For Wednesday, 15 April 2026
---------------------------------------------------------------------

 ![The Lotto and Lotto Plus 1 and 2 results for Wednesday, 15 April 2026](https://www.thesouthafrican.com/wp-content/uploads/2025/04/Lotto.jpg.optimal.jpg) <small>www.thesouthafrican.com</small>The Lotto and Lotto Plus 1 and 2 results for Wednesday, 15 April 2026

R109 Million CALLING For Lotto And Lotto Plus 1 And 2 On Wednesday 15
---------------------------------------------------------------------

 ![R109 million CALLING for Lotto and Lotto Plus 1 and 2 on Wednesday 15](https://www.thesouthafrican.com/wp-content/uploads/2026/04/Lotto-and-Lotto-Plus-1-and-2-on-Wednesday-15-April-2026_1.png) <small>www.thesouthafrican.com</small>R109 million CALLING for Lotto and Lotto Plus 1 and 2 on Wednesday 15 ...

ITHUBA Confirms Lotto Plus 1 And Lotto Plus 2 Jackpots WON
----------------------------------------------------------

 ![ITHUBA confirms Lotto Plus 1 and Lotto Plus 2 jackpots WON](https://www.thesouthafrican.com/wp-content/uploads/2026/04/image-28.png) <small>www.thesouthafrican.com</small>ITHUBA confirms Lotto Plus 1 and Lotto Plus 2 jackpots WON

The Lotto And Lotto Plus 1 And 2 Results For Wednesday, 1 April 2026
--------------------------------------------------------------------

 ![The Lotto and Lotto Plus 1 and 2 results for Wednesday, 1 April 2026](https://miro.medium.com/v2/resize:fit:1358/1*8hsJQ8wmznkNEyY8GjNt6w.png) <small>www.afghanistanwatch.com</small>The Lotto and Lotto Plus 1 and 2 results for Wednesday, 1 April 2026 ...

Lotto Plus 1 Plus 2 Results Online
----------------------------------

 ![Lotto plus 1 plus 2 results online](https://pbs.twimg.com/media/EOX9TJlUUAArL9n.png) <small>www.namibian.com.na</small>Lotto plus 1 plus 2 results online

The Lotto And Lotto Plus 1 And 2 Results For Wednesday, 1 April 2026
--------------------------------------------------------------------

 ![The Lotto and Lotto Plus 1 and 2 results for Wednesday, 1 April 2026](https://www.lottery.co.za/images/logos/lotto-plus-2.jpg) <small>www.afghanistanwatch.com</small>The Lotto and Lotto Plus 1 and 2 results for Wednesday, 1 April 2026 ...

R29-million Lotto And Lotto Plus 1 And 2 On Wednesday 27 May 2026
-----------------------------------------------------------------

 ![R29-million Lotto and Lotto Plus 1 and 2 on Wednesday 27 May 2026](https://www.thesouthafrican.com/wp-content/uploads/2026/05/Wednesday-27-May-2026.png) <small>www.thesouthafrican.com</small>R29-million Lotto and Lotto Plus 1 and 2 on Wednesday 27 May 2026

Lotto Plus Two 1 July 2026 Wednesday, Results Tonight, South Africa
-------------------------------------------------------------------

 ![Lotto Plus Two 1 July 2026 Wednesday, Results Tonight, South Africa](https://powerball.us.org/images/lottoplustwosa/1.webp) <small>powerball.us.org</small>Lotto Plus Two 1 July 2026 Wednesday, Results Tonight, South Africa

SA Lotto Plus 2 Summary - 2024-01-10
------------------------------------

 ![SA Lotto Plus 2 Summary - 2024-01-10](https://cdn.africanlottery.net/img/results/lotto-plus-2-results-no-2402.webp) <small>www.africanlottery.net</small>SA Lotto Plus 2 Summary - 2024-01-10

Lotto And Lotto Plus Results: Wednesday, 2 April 2025 | The Citizen
-------------------------------------------------------------------

 ![Lotto and Lotto Plus results: Wednesday, 2 April 2025 | The Citizen](https://media.citizen.co.za/wp-content/uploads/2025/03/Lotto-and-Lotto-Plus-results-Wednesday-2-April-2025.jpg) <small>www.citizen.co.za</small>Lotto and Lotto Plus results: Wednesday, 2 April 2025 | The Citizen

R98 Million UP For Grabs: Lotto And Lotto Plus 1 And 2 On Wednesday 29
----------------------------------------------------------------------

 ![R98 million UP for grabs: Lotto and Lotto Plus 1 and 2 on Wednesday 29](https://www.thesouthafrican.com/wp-content/uploads/2026/04/Lotto-and-Lotto-Plus-1-and-2-on-Wednesday-29-April-2026_1-960x257.png) <small>www.thesouthafrican.com</small>R98 million UP for grabs: Lotto and Lotto Plus 1 and 2 on Wednesday 29 ...

Daily Lotto Results: Winning Numbers
------------------------------------

 ![Daily Lotto Results: Winning Numbers](https://www.thesouthafrican.com/wp-content/uploads/2026/04/Lotto-and-Lotto-Plus-1-and-2-on-Wednesday-8-April-2026_2.jpg.optimal.jpg) <small>www.thesouthafrican.com</small>Daily Lotto Results: Winning Numbers

‘Budget Speech’ Lotto And Lotto Plus 1 And 2 On Wednesday 25 February
---------------------------------------------------------------------

 ![‘Budget Speech’ Lotto and Lotto Plus 1 and 2 on Wednesday 25 February](https://www.thesouthafrican.com/wp-content/uploads/2026/02/Lotto-and-Lotto-Plus-1-and-2-on-Wednesday-25-February-2026_3.jpg.optimal.jpg) <small>www.thesouthafrican.com</small>‘Budget Speech’ Lotto and Lotto Plus 1 and 2 on Wednesday 25 February ...

Lotto And Lotto Plus Results: Winning Numbers
---------------------------------------------

 ![Lotto and Lotto Plus Results: Winning Numbers](https://www.thesouthafrican.com/wp-content/uploads/2026/05/Lotto-Plus-1-jackpot-winner-768x531.jpg.optimal.jpg) <small>www.thesouthafrican.com</small>Lotto and Lotto Plus Results: Winning Numbers

Back To R41 Million For Lotto And Lotto Plus 1 And 2 On Wednesday 18
--------------------------------------------------------------------

 ![Back to R41 million for Lotto and Lotto Plus 1 and 2 on Wednesday 18](https://www.thesouthafrican.com/wp-content/uploads/2026/02/Lotto-and-Lotto-Plus-1-and-2-on-Wednesday-18-February-2026-960x640.jpg.optimal.jpg) <small>www.thesouthafrican.com</small>Back to R41 million for Lotto and Lotto Plus 1 and 2 on Wednesday 18 ...

Lotto Plus 1 &amp; 2 Results 15 Nov 2025 | Live SA Numbers
----------------------------------------------------------

 ![Lotto Plus 1 & 2 Results 15 Nov 2025 | Live SA Numbers](https://www.techchamp.co.za/wp-content/uploads/2025/11/Lotto-Lotto-Plus-1-Lotto-Plus-2-Results-for-Saturday-29-November-2025.webp) <small>www.techchamp.co.za</small>Lotto Plus 1 &amp; 2 Results 15 Nov 2025 | Live SA Numbers

R54-million Payday For Lotto And Lotto Plus 1 And 2 On Saturday 28
------------------------------------------------------------------

 ![R54-million payday for Lotto and Lotto Plus 1 and 2 on Saturday 28](https://www.thesouthafrican.com/wp-content/uploads/2026/02/Lotto-and-Lotto-Plus-1-and-2-on-Saturday-28-February-2026-.jpg.optimal.jpg) <small>www.thesouthafrican.com</small>R54-million payday for Lotto and Lotto Plus 1 and 2 on Saturday 28 ...

ITHUBA Confirms Lotto Plus 1 And Lotto Plus 2 Jackpots WON
----------------------------------------------------------

 ![ITHUBA confirms Lotto Plus 1 and Lotto Plus 2 jackpots WON](https://www.thesouthafrican.com/wp-content/uploads/2026/04/Lotto-and-Lotto-Plus-1-and-2-on-Wednesday-8-April-2026_1.jpg.optimal.jpg) <small>www.thesouthafrican.com</small>ITHUBA confirms Lotto Plus 1 and Lotto Plus 2 jackpots WON

The Lotto And Lotto Plus 1 And 2 Results For Wednesday, 1 April 2026
--------------------------------------------------------------------

 ![The Lotto and Lotto Plus 1 and 2 results for Wednesday, 1 April 2026](https://www.lottery.co.za/images/lotto-plus.jpg) <small>www.afghanistanwatch.com</small>The Lotto and Lotto Plus 1 and 2 results for Wednesday, 1 April 2026 ...

BAD News For RESET Lotto And Lotto Plus 1 And 2 On Saturday 9 May 2026
----------------------------------------------------------------------

 ![BAD news for RESET Lotto and Lotto Plus 1 and 2 on Saturday 9 May 2026](https://www.thesouthafrican.com/wp-content/uploads/2026/05/Lotto-and-Lotto-Plus-1-and-2-on-Saturday-9-May-2026_2.png) <small>www.thesouthafrican.com</small>BAD news for RESET Lotto and Lotto Plus 1 and 2 on Saturday 9 May 2026

The Lotto And Lotto Plus 1 And 2 Results For Wednesday, 1 April 2026
--------------------------------------------------------------------

 ![The Lotto and Lotto Plus 1 and 2 results for Wednesday, 1 April 2026](https://www.gidblog.com/wp-content/uploads/2020/06/ss.gidapp.za_.lottop2.mobile.png) <small>www.afghanistanwatch.com</small>The Lotto and Lotto Plus 1 and 2 results for Wednesday, 1 April 2026 ...

The Lotto And Lotto Plus 1 And 2 Results For Wednesday, 1 April 2026
--------------------------------------------------------------------

 ![The Lotto and Lotto Plus 1 and 2 results for Wednesday, 1 April 2026](https://i.ytimg.com/vi/iHuj0dMq41Y/maxresdefault.jpg) <small>www.afghanistanwatch.com</small>The Lotto and Lotto Plus 1 and 2 results for Wednesday, 1 April 2026 ...

Lotto And Lotto Plus Results: Winning Numbers
---------------------------------------------

 ![Lotto and Lotto Plus Results: Winning Numbers](https://www.thesouthafrican.com/wp-content/uploads/2026/04/Lotto-and-Lotto-Plus-1-and-2-on-Saturday-2-May-2026_4-750x500.jpg.optimal.jpg) <small>www.thesouthafrican.com</small>Lotto and Lotto Plus Results: Winning Numbers

No Winner Of Wednesday’s Lotto Jackpots: All The Numbers And Payouts
--------------------------------------------------------------------

 ![No winner of Wednesday’s Lotto jackpots: All the numbers and payouts](https://www.thesouthafrican.com/wp-content/uploads/2023/03/29-mar-lotto-plus1.jpg) <small>www.whatsoninportelizabeth.com</small>No winner of Wednesday’s Lotto jackpots: All the numbers and payouts ...

R98 Million UP For Grabs: Lotto And Lotto Plus 1 And 2 On Wednesday 29
----------------------------------------------------------------------

 ![R98 million UP for grabs: Lotto and Lotto Plus 1 and 2 on Wednesday 29](https://www.thesouthafrican.com/wp-content/uploads/2026/04/Lotto-and-Lotto-Plus-1-and-2-on-Wednesday-29-April-2026_3.jpeg.optimal.jpeg) <small>www.thesouthafrican.com</small>R98 million UP for grabs: Lotto and Lotto Plus 1 and 2 on Wednesday 29 ...

R29-million Lotto And Lotto Plus 1 And 2 On Wednesday 27 May 2026
-----------------------------------------------------------------

 ![R29-million Lotto and Lotto Plus 1 and 2 on Wednesday 27 May 2026](https://www.thesouthafrican.com/wp-content/uploads/2026/05/Wednesday-27-May-2026_1.jpg.optimal.jpg) <small>www.thesouthafrican.com</small>R29-million Lotto and Lotto Plus 1 and 2 on Wednesday 27 May 2026

Lotto Results And Payouts &amp; Lotto Plus Best Sale | Www.cityofclovis.org
---------------------------------------------------------------------------

 ![Lotto Results And Payouts & Lotto Plus Best Sale | www.cityofclovis.org](https://media.citizen.co.za/wp-content/uploads/2018/12/Screenshot-2018-12-06-at-08.45.46.png) <small>www.cityofclovis.org</small>Lotto Results And Payouts &amp; Lotto Plus Best Sale | www.cityofclovis.org

Summer Of R69 Million For Lotto And Lotto Plus 1 And 2 On Wednesday 18
----------------------------------------------------------------------

 ![Summer of R69 million for Lotto and Lotto Plus 1 and 2 on Wednesday 18](https://www.thesouthafrican.com/wp-content/uploads/2026/03/Lotto-and-Lotto-Plus-1-and-2-on-Wednesday-18-March-2026_7-960x640.jpg.optimal.jpg) <small>www.thesouthafrican.com</small>Summer of R69 million for Lotto and Lotto Plus 1 and 2 on Wednesday 18 ...

R109 Million CALLING For Lotto And Lotto Plus 1 And 2 On Wednesday 15
---------------------------------------------------------------------

 ![R109 million CALLING for Lotto and Lotto Plus 1 and 2 on Wednesday 15](https://www.thesouthafrican.com/wp-content/uploads/2026/04/Lotto-and-Lotto-Plus-1-and-2-on-Wednesday-15-April-2026_1-1200x319.png) <small>www.thesouthafrican.com</small>R109 million CALLING for Lotto and Lotto Plus 1 and 2 on Wednesday 15 ...

Lotto &amp; Lotto Plus Results: R59.5 Million Jackpot – Saturday, 7 March
-------------------------------------------------------------------------

 ![Lotto & Lotto Plus Results: R59.5 Million Jackpot – Saturday, 7 March](https://www.thesouthafrican.com/wp-content/uploads/2026/03/Lotto-and-Lotto-Plus-1-and-2-on-Saturday-7-March-2026_4.jpg.optimal.jpg) <small>www.archyde.com</small>Lotto &amp; Lotto Plus Results: R59.5 Million Jackpot – Saturday, 7 March ...

Lucky 13 For Lotto And Lotto Plus 1 And 2 On Wednesday 13 May 2026?
-------------------------------------------------------------------

 ![Lucky 13 for Lotto and Lotto Plus 1 and 2 on Wednesday 13 May 2026?](https://www.thesouthafrican.com/wp-content/uploads/2026/05/Lotto-and-Lotto-Plus-1-and-2-on-Wednesday-13-May-2026_1.jpg.optimal.jpg) <small>www.thesouthafrican.com</small>Lucky 13 for Lotto and Lotto Plus 1 and 2 on Wednesday 13 May 2026?

The Lotto And Lotto Plus 1 And 2 Results For Wednesday, 1 April 2026
--------------------------------------------------------------------

 ![The Lotto and Lotto Plus 1 and 2 results for Wednesday, 1 April 2026](https://i.ytimg.com/vi/hQuxDKKzs5c/maxresdefault.jpg) <small>www.afghanistanwatch.com</small>The Lotto and Lotto Plus 1 and 2 results for Wednesday, 1 April 2026 ...

Bad news for reset lotto and lotto plus 1 and 2 on saturday 9 may 2026. Bad news for reset lotto and lotto plus 1 and 2 on saturday 9 may 2026. Lotto and lotto plus results: winning numbers
