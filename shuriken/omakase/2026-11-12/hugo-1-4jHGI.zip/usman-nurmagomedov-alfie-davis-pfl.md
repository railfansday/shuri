---
title: "Usman Nurmagomedov Alfie Davis Pfl - pfl champions series 5"
description: "Résumé pfl : un étranglement terrifiant entre le champion usman ..."
date: "2026-08-30"
categories:
- "Uncategorized"
images:
- "https://ichef.bbci.co.uk/ace/standard/640/cpsprodpb/vivo/live/images/2026/2/7/dbf0662a-74a2-46e3-bb80-86be5a7fcd08.jpg.webp"
featuredImage: "https://ichef.bbci.co.uk/ace/standard/2560/cpsprodpb/3eed/live/2f776950-046c-11f1-96f5-2f82f674a667.jpg"
featured_image: "https://www.thenationalnews.com/resizer/v2/XEFVPMHXW5BZNNCWDT2I6KJ4VE.JPG?auth=4f4f1c75eecfa65edc8f68a6b13ed1b77a7a53aa1ca828757c88a4a9a43c2f78"
image: "https://www.thenationalnews.com/resizer/v2/VJWI62VJQFBGVA5SMZSMS74K2E.JPG?auth=100effa075e12ea7d33d6b0251d80f768a8f922034e5c68d94e9efeb3293236c"
---

If you are searching about Résumé PFL : Un ÉTRANGLEMENT TERRIFIANT entre le champion Usman you've came to the right web. We have 35 Pics about Résumé PFL : Un ÉTRANGLEMENT TERRIFIANT entre le champion Usman like PFL: ROAD TO DUBAI RETURNS ON SAT 7 FEB AS USMAN NURMAGOMEDOV DEFENDS, Usman Nurmagomedov dominates Alfie Davis to retain PFL lightweight and also PFL: ROAD TO DUBAI RETURNS ON SAT 7 FEB AS USMAN NURMAGOMEDOV DEFENDS. Here it is:

Résumé PFL : Un ÉTRANGLEMENT TERRIFIANT Entre Le Champion Usman
---------------------------------------------------------------

 ![Résumé PFL : Un ÉTRANGLEMENT TERRIFIANT entre le champion Usman](https://images.bfmtv.com/hsvFE9wbneiq9-90-ZTi1UVBF60=/0x0:1280x720/images/Resume-PFL-Un-ETRANGLEMENT-TERRIFIANT-entre-le-champion-Usman-Nurmagomedov-et-Alfie-Davis-2231588.jpg) <small>rmcsport.bfmtv.com</small>Résumé PFL : Un ÉTRANGLEMENT TERRIFIANT entre le champion Usman ...

Usman Nurmagomedov Vs Alfie Davis RECAP: Relive Usman Nurmagomedov's
--------------------------------------------------------------------

 ![Usman Nurmagomedov vs Alfie Davis RECAP: Relive Usman Nurmagomedov's](https://ichef.bbci.co.uk/ace/standard/640/cpsprodpb/vivo/live/images/2026/2/7/43e7fc32-f9e1-40aa-ab80-8c8cb164b129.png.webp) <small>www.bbc.co.uk</small>Usman Nurmagomedov vs Alfie Davis RECAP: Relive Usman Nurmagomedov's ...

Usman Nurmagomedov To Defend PFL Title Against Britain’s Alfie Davis
--------------------------------------------------------------------

 ![Usman Nurmagomedov to defend PFL title against Britain’s Alfie Davis](https://s.yimg.com/ny/api/res/1.2/oATtsPulq9_sbHZROlwkjA--/YXBwaWQ9aGlnaGxhbmRlcjt3PTk2MDtoPTY1NjtjZj13ZWJw/https://media.zenfs.com/en/the_independent_577/ecc90c0a09eafd06cae6c1dc442a2b4d) <small>sports.yahoo.com</small>Usman Nurmagomedov to defend PFL title against Britain’s Alfie Davis ...

Usman Nurmagomedov Dominates Alfie Davis To Retain PFL Lightweight
------------------------------------------------------------------

 ![Usman Nurmagomedov dominates Alfie Davis to retain PFL lightweight](https://www.thenationalnews.com/resizer/v2/XEFVPMHXW5BZNNCWDT2I6KJ4VE.JPG?auth=4f4f1c75eecfa65edc8f68a6b13ed1b77a7a53aa1ca828757c88a4a9a43c2f78) <small>www.thenationalnews.com</small>Usman Nurmagomedov dominates Alfie Davis to retain PFL lightweight ...

Usman Nurmagomedov Dominates Alfie Davis To Retain PFL Lightweight
------------------------------------------------------------------

 ![Usman Nurmagomedov dominates Alfie Davis to retain PFL lightweight](https://www.thenationalnews.com/resizer/v2/YRXSLCWKGNBJTIHYQ76UNEVAUA.JPG?auth=def560589771fc22ab05dd3435f061a5c3d2866722939a1bb8576d5b495c38f0) <small>www.thenationalnews.com</small>Usman Nurmagomedov dominates Alfie Davis to retain PFL lightweight ...

Usman Nurmagomedov Kontra Alfie Davis Walką Wieczoru Pierwszej Gali PFL
-----------------------------------------------------------------------

 ![Usman Nurmagomedov kontra Alfie Davis walką wieczoru pierwszej gali PFL](https://www.mmarocks.pl/wp-content/uploads/2025/11/usmanpfl-1.jpg) <small>www.mmarocks.pl</small>Usman Nurmagomedov kontra Alfie Davis walką wieczoru pierwszej gali PFL ...

PFL Dubai: Alfie Davis Aims To Force Khabib Nurmagomedov's Return With
----------------------------------------------------------------------

 ![PFL Dubai: Alfie Davis aims to force Khabib Nurmagomedov's return with](https://s.yimg.com/ny/api/res/1.2/e8AdCEs6Xe3JH3HWJABldw--/YXBwaWQ9aGlnaGxhbmRlcjt3PTEyMDA7aD04MDA7Y2Y9d2VicA--/https://s.yimg.com/os/creatr-uploaded-images/2026-02/b8d7db10-02bb-11f1-adff-da08f0e5ca56) <small>sports.yahoo.com</small>PFL Dubai: Alfie Davis aims to force Khabib Nurmagomedov's return with ...

PFL: Usman Nurmagomedov Defende Cinturão Contra Alfie Davis Em 2026 | Ge
------------------------------------------------------------------------

 ![PFL: Usman Nurmagomedov defende cinturão contra Alfie Davis em 2026 | Ge](https://s2-ge.glbimg.com/_s5U9nUfu2mJebbpe4o6WY4MnXA=/1280x0/filters:format(jpeg)/https://s01.video.glbimg.com/x720/13984736.jpg) <small>ge.globo.com</small>PFL: Usman Nurmagomedov defende cinturão contra Alfie Davis em 2026 | Ge

Usman Nurmagomedov Maintains Chokehold On PFL Lightweight Title With
--------------------------------------------------------------------

 ![Usman Nurmagomedov maintains chokehold on PFL lightweight title with](https://media.alittihad.ae/store/archive/image/2026/2/8/633d1de9-e26c-4246-ad35-34b0a5c457a7.png?width=600) <small>en.aletihad.ae</small>Usman Nurmagomedov maintains chokehold on PFL lightweight title with ...

Usman Nurmagomedov Vs Alfie Davis RECAP: Relive Usman Nurmagomedov's
--------------------------------------------------------------------

 ![Usman Nurmagomedov vs Alfie Davis RECAP: Relive Usman Nurmagomedov's](https://ichef.bbci.co.uk/ace/standard/640/cpsprodpb/vivo/live/images/2026/2/7/99182994-708a-4479-a15c-fafe7fd11642.jpg.webp) <small>www.bbc.co.uk</small>Usman Nurmagomedov vs Alfie Davis RECAP: Relive Usman Nurmagomedov's ...

Usman Nurmagomedov Def. Alfie Davis At PFL: Road To Dubai: Best Photos
----------------------------------------------------------------------

 ![Usman Nurmagomedov def. Alfie Davis at PFL: Road to Dubai: Best photos](https://mmajunkie.usatoday.com/gcdn/authoring/authoring-images/2026/02/07/SMMA/88570571007-usman-nurmagomedov-def-alfie-davis-pfl-road-to-dubai-18.JPG?width=660&height=441&fit=crop&format=pjpg&auto=webp) <small>mmajunkie.usatoday.com</small>Usman Nurmagomedov def. Alfie Davis at PFL: Road to Dubai: Best photos

Usman Nurmagomedov, Alfie Davis Among PFL Stars To Visit Global Village
-----------------------------------------------------------------------

 ![Usman Nurmagomedov, Alfie Davis among PFL stars to visit Global Village](https://imgengine.khaleejtimes.com/khaleejtimes-english/2026-01-29/y0dizb45/Screenshot-2026-01-29-172949.png?width=800&height=600&q=60&format=auto) <small>www.khaleejtimes.com</small>Usman Nurmagomedov, Alfie Davis among PFL stars to visit Global Village ...

PFL Dubai: Usman Nurmagomedov Submits Alfie Davis In Third Round To
-------------------------------------------------------------------

 ![PFL Dubai: Usman Nurmagomedov submits Alfie Davis in third round to](https://ichef.bbci.co.uk/ace/standard/2560/cpsprodpb/3eed/live/2f776950-046c-11f1-96f5-2f82f674a667.jpg) <small>www.bbc.co.uk</small>PFL Dubai: Usman Nurmagomedov submits Alfie Davis in third round to ...

Usman Nurmagomedov Vs Alfie Davis RECAP: Relive Usman Nurmagomedov's
--------------------------------------------------------------------

 ![Usman Nurmagomedov vs Alfie Davis RECAP: Relive Usman Nurmagomedov's](https://ichef.bbci.co.uk/ace/standard/640/cpsprodpb/vivo/live/images/2026/2/7/9dd9505f-b6d2-491d-b383-aa2131fd097b.png.webp) <small>www.bbc.com</small>Usman Nurmagomedov vs Alfie Davis RECAP: Relive Usman Nurmagomedov's ...

Usman Nurmagomedov Dominates Alfie Davis To Retain PFL Lightweight
------------------------------------------------------------------

 ![Usman Nurmagomedov dominates Alfie Davis to retain PFL lightweight](https://www.thenationalnews.com/resizer/v2/7I34UE5LS5DD3CMOHAUVOAREEU.JPG?smart=true&auth=25b1c76a582bcb4d3afad440de42286afec19fcfb15aabe8aec1e68ea704e1c5&width=1200&height=630) <small>www.thenationalnews.com</small>Usman Nurmagomedov dominates Alfie Davis to retain PFL lightweight ...

PFL Full Fight: Usman Nurmagomedov Sleeps Alfie Davis In Title Defense
----------------------------------------------------------------------

 ![PFL full fight: Usman Nurmagomedov sleeps Alfie Davis in title defense](https://mmajunkie.usatoday.com/gcdn/authoring/authoring-images/2026/02/07/SMMA/88570588007-usman-nurmagomedov-def-alfie-davis-pfl-road-to-dubai-32.JPG?crop=2399,1351,x0,y124&width=2399&height=1351&format=pjpg&auto=webp) <small>mmajunkie.usatoday.com</small>PFL full fight: Usman Nurmagomedov sleeps Alfie Davis in title defense

Usman Nurmagomedov Somete A Davis Y Retiene El Cinturón En PFL Dubái
--------------------------------------------------------------------

 ![Usman Nurmagomedov somete a Davis y retiene el cinturón en PFL Dubái](https://objetos-xlk.estaticos-marca.com/uploads/2026/02/07/69879f13d4995.jpeg) <small>www.marca.com</small>Usman Nurmagomedov somete a Davis y retiene el cinturón en PFL Dubái

PFL Bringing Usman Nurmagomedov, Dakota Ditcheva To Long Island On Star
-----------------------------------------------------------------------

 ![PFL bringing Usman Nurmagomedov, Dakota Ditcheva to Long Island on star](https://s.yimg.com/lo/mysterio/api/366FA5512152AF6CD62CD1D2EFE66475C294CCA2FD32D04DD82BC638F28914E2/subgraphmysterio/resizefill_w976_h651;quality_80;format_webp/https://media.zenfs.com/en/aol_ny_post_us_news_articles_123/aa3479f74bd730c9442a7af262e4640b) <small>www.aol.com</small>PFL bringing Usman Nurmagomedov, Dakota Ditcheva to Long Island on star ...

PFL: Road To Dubai - Usman Nurmagomedov Submits Alfie Davis, Retains Title
--------------------------------------------------------------------------

 ![PFL: Road to Dubai - Usman Nurmagomedov Submits Alfie Davis, Retains Title](https://cagesidepress.com/wp-content/uploads/2026/02/NurmagomedovDavis.jpg) <small>cagesidepress.com</small>PFL: Road to Dubai - Usman Nurmagomedov Submits Alfie Davis, Retains Title

Usman Nurmagomedov Vs Alfie Davis Set To Headline PFL: Road To Dubai
--------------------------------------------------------------------

 ![Usman Nurmagomedov vs Alfie Davis Set to Headline PFL: Road to Dubai](https://mmauk.net/wp-content/uploads/2025/11/Usman-Nurmagomedov-vs-Alfie-Davis-Set-to-Headline-PFL-Road-to-Dubai-2026-500x262.jpg) <small>mmauk.net</small>Usman Nurmagomedov vs Alfie Davis Set to Headline PFL: Road to Dubai ...

PFL Dubai: Usman Nurmagomedov Submits Alfie Davis In Third Round To
-------------------------------------------------------------------

 ![PFL Dubai: Usman Nurmagomedov submits Alfie Davis in third round to](https://ichef.bbci.co.uk/ace/standard/927/cpsprodpb/5020/live/855a0d50-0467-11f1-a12b-658d26b020a4.png) <small>www.bbc.co.uk</small>PFL Dubai: Usman Nurmagomedov submits Alfie Davis in third round to ...

Usman Nurmagomedov Vs. Alfie Davis Headlines First PFL Card In 2026
-------------------------------------------------------------------

 ![Usman Nurmagomedov vs. Alfie Davis headlines first PFL card in 2026](https://platform.mmafighting.com/wp-content/uploads/sites/109/2025/08/20250125221838-_JP13385_.jpg?quality=90&strip=all&crop=0%2C6.1497095545259%2C100%2C78.534031413613&w=1200) <small>www.mmafighting.com</small>Usman Nurmagomedov vs. Alfie Davis headlines first PFL card in 2026 ...

Davis Vs Usman Nurmagomedov Fight Card, Date, Venue, How To Watch
-----------------------------------------------------------------

 ![Davis vs Usman Nurmagomedov Fight Card, Date, Venue, How To Watch](https://ichef.bbci.co.uk/ace/standard/976/cpsprodpb/c343/live/29feb5b0-c541-11f0-88be-3bc2aea1a256.png.webp) <small>www.sportshistori.com</small>Davis vs Usman Nurmagomedov Fight Card, Date, Venue, How To Watch ...

PFL Champions Series 5 - Nurmagomedov Vs. Davis - UFC Fans
----------------------------------------------------------

 ![PFL Champions Series 5 - Nurmagomedov vs. Davis - UFC Fans](https://www.ufc-fr.com/data/evenement_autre/600/pfl-road-to-dubai-champions-series-5-nurmagomedov-vs-davis-2025-11-21-01-06-30__zamc__ID600.jpg) <small>www.ufc-fr.com</small>PFL Champions Series 5 - Nurmagomedov vs. Davis - UFC Fans

Usman Nurmagomedov Vs Alfie Davis RECAP: Relive Usman Nurmagomedov's
--------------------------------------------------------------------

 ![Usman Nurmagomedov vs Alfie Davis RECAP: Relive Usman Nurmagomedov's](https://ichef.bbci.co.uk/ace/standard/640/cpsprodpb/vivo/live/images/2026/2/7/dbf0662a-74a2-46e3-bb80-86be5a7fcd08.jpg.webp) <small>www.bbc.com</small>Usman Nurmagomedov vs Alfie Davis RECAP: Relive Usman Nurmagomedov's ...

PFL Announces Nurmagomedov Vs. Davis As First 2026 Headliner
------------------------------------------------------------

 ![PFL announces Nurmagomedov vs. Davis as first 2026 headliner](https://mmajunkie.usatoday.com/gcdn/authoring/authoring-images/2025/11/19/SMMA/87359708007-usman-nurmagomedov-vs-alfie-daivs.jpg?crop=999,562,x0,y0&width=999&height=562&format=pjpg&auto=webp) <small>mmajunkie.usatoday.com</small>PFL announces Nurmagomedov vs. Davis as first 2026 headliner

PFL POUND-FOR-POUND KING USMAN NURMAGOMEDOV REIGNS SUPREME AT PFL ROAD
----------------------------------------------------------------------

 ![PFL POUND-FOR-POUND KING USMAN NURMAGOMEDOV REIGNS SUPREME AT PFL ROAD](https://pflmma-prod.s3.amazonaws.com/articles/featured/86515fe97165615aa702eedb4b4755f7-1-1.jpg) <small>pflmma.com</small>PFL POUND-FOR-POUND KING USMAN NURMAGOMEDOV REIGNS SUPREME AT PFL ROAD ...

PFL Road To Dubai: Usman Nurmagomedov Submits Alfie Davis
---------------------------------------------------------

 ![PFL Road to Dubai: Usman Nurmagomedov submits Alfie Davis](https://mmajunkie.usatoday.com/gcdn/authoring/authoring-images/2026/02/07/SMMA/88570563007-usman-nurmagomedov-def-alfie-davis-pfl-road-to-dubai-15.JPG?crop=2399,1351,x0,y124&width=2399&height=1351&format=pjpg&auto=webp) <small>mmajunkie.usatoday.com</small>PFL Road to Dubai: Usman Nurmagomedov submits Alfie Davis

Usman Nurmagomedov Vs Alfie Davis RECAP: Relive Usman Nurmagomedov's
--------------------------------------------------------------------

 ![Usman Nurmagomedov vs Alfie Davis RECAP: Relive Usman Nurmagomedov's](https://ichef.bbci.co.uk/ace/standard/640/cpsprodpb/vivo/live/images/2026/2/7/b2462704-94c1-4bc4-90c5-b3a221214a96.png.webp) <small>www.bbc.com</small>Usman Nurmagomedov vs Alfie Davis RECAP: Relive Usman Nurmagomedov's ...

PFL: ROAD TO DUBAI RETURNS ON SAT 7 FEB AS USMAN NURMAGOMEDOV DEFENDS
---------------------------------------------------------------------

 ![PFL: ROAD TO DUBAI RETURNS ON SAT 7 FEB AS USMAN NURMAGOMEDOV DEFENDS](https://pflmma-prod.s3.amazonaws.com/articles/thumbnails/cfb585668161a533fad2be3c21dc7e8c-1-1.jpg) <small>pflmma.com</small>PFL: ROAD TO DUBAI RETURNS ON SAT 7 FEB AS USMAN NURMAGOMEDOV DEFENDS ...

Usman Nurmagomedov Returns To Dubai To Defend PFL Title Against
---------------------------------------------------------------

 ![Usman Nurmagomedov returns to Dubai to defend PFL title against](https://www.thenationalnews.com/resizer/v2/536S45DL7ZD5ZA5AFLKBDN3JEU.jpg?auth=e827ffb16677555f7a175376c06f6e13ecfc7e2386cdec2c4f5836f306e4591e) <small>www.thenationalnews.com</small>Usman Nurmagomedov returns to Dubai to defend PFL title against ...

Usman Nurmagomedov Vs Alfie Davis RECAP: Relive Usman Nurmagomedov's
--------------------------------------------------------------------

 ![Usman Nurmagomedov vs Alfie Davis RECAP: Relive Usman Nurmagomedov's](https://ichef.bbci.co.uk/ace/standard/640/cpsprodpb/vivo/live/images/2026/2/7/89ee560a-05ad-4d89-8a2c-6d544736c055.jpg.webp) <small>www.bbc.com</small>Usman Nurmagomedov vs Alfie Davis RECAP: Relive Usman Nurmagomedov's ...

Usman Nurmagomedov Def. Alfie Davis At PFL: Road To Dubai: Best Photos
----------------------------------------------------------------------

 ![Usman Nurmagomedov def. Alfie Davis at PFL: Road to Dubai: Best photos](https://mmajunkie.usatoday.com/gcdn/authoring/authoring-images/2026/02/07/SMMA/88570603007-usman-nurmagomedov-def-alfie-davis-pfl-road-to-dubai-47.JPG?crop=2399,1351,x0,y124&width=2399&height=1351&format=pjpg&auto=webp) <small>mmajunkie.usatoday.com</small>Usman Nurmagomedov def. Alfie Davis at PFL: Road to Dubai: Best photos

Usman Nurmagomedov Def. Alfie Davis At PFL: Road To Dubai: Best Photos
----------------------------------------------------------------------

 ![Usman Nurmagomedov def. Alfie Davis at PFL: Road to Dubai: Best photos](https://mmajunkie.usatoday.com/gcdn/authoring/authoring-images/2026/02/07/SMMA/88570577007-usman-nurmagomedov-def-alfie-davis-pfl-road-to-dubai-22.JPG?width=1320&height=880&fit=crop&format=pjpg&auto=webp) <small>mmajunkie.usatoday.com</small>Usman Nurmagomedov def. Alfie Davis at PFL: Road to Dubai: Best photos

Usman Nurmagomedov Dominates Alfie Davis To Retain PFL Lightweight
------------------------------------------------------------------

 ![Usman Nurmagomedov dominates Alfie Davis to retain PFL lightweight](https://www.thenationalnews.com/resizer/v2/VJWI62VJQFBGVA5SMZSMS74K2E.JPG?auth=100effa075e12ea7d33d6b0251d80f768a8f922034e5c68d94e9efeb3293236c) <small>www.thenationalnews.com</small>Usman Nurmagomedov dominates Alfie Davis to retain PFL lightweight ...

pfl pound-for-pound king usman nurmagomedov reigns supreme at pfl road .... Usman nurmagomedov dominates alfie davis to retain pfl lightweight. usman nurmagomedov dominates alfie davis to retain pfl lightweight ...
