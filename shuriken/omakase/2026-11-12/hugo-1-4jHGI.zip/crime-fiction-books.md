---
title: "Crime Fiction Books - The best crime and thriller novels of the year so far"
description: "The best crime novels of 2025"
date: "2026-11-06"
categories:
- "Uncategorized"
images:
- "https://happymag.tv/wp-content/uploads/2021/10/penguin-sherlock-870x1205.jpg"
featuredImage: "https://i.pinimg.com/736x/c5/96/e2/c596e21fd579d032f2a62a523c205240.jpg"
featured_image: "https://m.media-amazon.com/images/I/819LE2LadyL._SL1500_.jpg"
image: "https://i.pinimg.com/736x/ea/56/db/ea56db6fbc81f1916fdf0237ea5dbff3.jpg"
---

If you are looking for 19 authors pick the best crime novels of 2019 you've visit to the right page. We have 34 Pictures about 19 authors pick the best crime novels of 2019 like Best detective series books of 2024, These crime novels will have you on the edge of your seat! Best Books and also 30 Best True Crime Books to Binge Read Right Away. Here you go:

19 Authors Pick The Best Crime Novels Of 2019
---------------------------------------------

 ![19 authors pick the best crime novels of 2019](https://www.deadgoodbooks.co.uk/wp-content/uploads/2019/11/Best-crime-novels-of-2019.jpg) <small>www.deadgoodbooks.co.uk</small>19 authors pick the best crime novels of 2019

Pin On Best Mystery / Thriller Books
------------------------------------

 ![Pin on Best Mystery / Thriller Books](https://i.pinimg.com/736x/ea/56/db/ea56db6fbc81f1916fdf0237ea5dbff3.jpg) <small>www.pinterest.com</small>Pin on Best Mystery / Thriller Books

The Best Crime And Thriller Novels Of The Year So Far | Tertulia
----------------------------------------------------------------

 ![The Best Crime and Thriller Novels of the Year So Far | Tertulia](https://images.ctfassets.net/dqfxe6p06j9z/6UTYZtU0Sio8AFvMR1LhLo/667ae22e2db6a9717512023be0ec9689/updated_crime_fiction_list_november.jpg) <small>tertulia.com</small>The Best Crime and Thriller Novels of the Year So Far | Tertulia

These Crime Novels Will Have You On The Edge Of Your Seat! Best Books
---------------------------------------------------------------------

 ![These crime novels will have you on the edge of your seat! Best Books](https://i.pinimg.com/736x/c5/96/e2/c596e21fd579d032f2a62a523c205240.jpg) <small>www.pinterest.com</small>These crime novels will have you on the edge of your seat! Best Books ...

The Best Cosy Crime Books And Murder Mysteries
----------------------------------------------

 ![The best cosy crime books and murder mysteries](https://www.deadgoodbooks.co.uk/wp-content/uploads/2024/02/Dead-Good-Cosy-crime-1701x1134-1-1536x1024.jpg) <small>www.deadgoodbooks.co.uk</small>The best cosy crime books and murder mysteries

19 Best Crime Thriller Books You Should Read Next
-------------------------------------------------

 ![19 Best Crime Thriller Books You Should Read Next](https://b2125522.smushcdn.com/2125522/wp-content/uploads/2022/12/Best-Crime-Thriller-Books.jpg?lossy=1&strip=1&webp=1) <small>www.tlbranson.com</small>19 Best Crime Thriller Books You Should Read Next

Twelve New Crime Fiction Novels Written By North East And Yorkshire
-------------------------------------------------------------------

 ![Twelve New Crime Fiction Novels Written by North East and Yorkshire](https://www.livingnorth.com/images/media/articles/things-to-do/staying-in/250 12 crime books/featured image 1.jpg?fm=pjpg&w=1300&q=95) <small>www.livingnorth.com</small>Twelve New Crime Fiction Novels Written by North East and Yorkshire ...

The Five Best Crime Books Of All Time - Books Of Brilliance
-----------------------------------------------------------

 ![The Five Best Crime Books of All Time - Books of Brilliance](https://i0.wp.com/booksofbrilliance.com/wp-content/uploads/2023/02/The-Five-Best-Crime-Books-of-All-Time.png?resize=1230%2C692&ssl=1) <small>booksofbrilliance.com</small>The Five Best Crime Books of All Time - Books of Brilliance

20 Best True Crime Books, According To A Pro Book Reviewer
----------------------------------------------------------

 ![20 Best True Crime Books, According to a Pro Book Reviewer](https://www.rd.com/wp-content/uploads/2025/02/20-Best-True-Crime-Books-for-Armchair-Detectives_FT.jpg) <small>www.rd.com</small>20 Best True Crime Books, According to a Pro Book Reviewer

16 Authors Pick The Best Crime Novels Of 2021
---------------------------------------------

 ![16 authors pick the best crime novels of 2021](https://www.deadgoodbooks.co.uk/wp-content/uploads/2021/12/Dead-Good-Best-of-2021-Headers-Books-Website-Banner-1.jpg) <small>www.deadgoodbooks.co.uk</small>16 authors pick the best crime novels of 2021

The Best Of Classic Crime Fiction Set Of 3 Books : Albert Camus, Fyodor
-----------------------------------------------------------------------

 ![The Best Of Classic Crime Fiction Set of 3 Books : Albert Camus, Fyodor](https://m.media-amazon.com/images/I/81fGbdoAmOL._SL1500_.jpg) <small>www.amazon.in</small>The Best Of Classic Crime Fiction Set of 3 Books : Albert Camus, Fyodor ...

Best Detective Series Books Of 2024
-----------------------------------

 ![Best detective series books of 2024](https://www.deadgoodbooks.co.uk/wp-content/uploads/2024/09/New-crime-series-to-start-–-DG-–-article-sizing.jpg) <small>www.deadgoodbooks.co.uk</small>Best detective series books of 2024

THE DETECTIVE SAM QUINN CRIME THRILLERS BOOKS 1–2 Two Absolutely
----------------------------------------------------------------

 ![THE DETECTIVE SAM QUINN CRIME THRILLERS BOOKS 1–2 two absolutely](https://m.media-amazon.com/images/I/819LE2LadyL._SL1500_.jpg) <small>www.amazon.ca</small>THE DETECTIVE SAM QUINN CRIME THRILLERS BOOKS 1–2 two absolutely ...

Crime &amp; Thriller Fiction Books | Readers Warehouse
------------------------------------------------------

 ![Crime & Thriller Fiction Books | Readers Warehouse](https://www.readerswarehouse.co.za/cdn/shop/collections/crime-thriller-fiction-books-192539.jpg?v=1751957790) <small>www.readerswarehouse.co.za</small>Crime &amp; Thriller Fiction Books | Readers Warehouse

17 Best New Crime Fiction And Thrillers This Autumn, Picked By A Book
---------------------------------------------------------------------

 ![17 best new crime fiction and thrillers this autumn, picked by a book](https://cdn.mos.cms.futurecdn.net/P25VZjx4ixMmrGcQUFoJmV-1280-80.jpg) <small>www.womanandhome.com</small>17 best new crime fiction and thrillers this autumn, picked by a book ...

The 7 Best Crime-series Novels Of Fall 2020 - Los Angeles Times
---------------------------------------------------------------

 ![The 7 best crime-series novels of fall 2020 - Los Angeles Times](https://ca-times.brightspotcdn.com/dims4/default/445971f/2147483647/strip/true/crop/1024x1024+0+0/resize/1200x1200!/quality/75/?url=https:%2F%2Fcalifornia-times-brightspot.s3.amazonaws.com%2F2f%2F69%2Ff643ebc24e6c9c1975775383bb00%2Fla-ca-crime-sidebar-books-0147.JPG) <small>www.latimes.com</small>The 7 best crime-series novels of fall 2020 - Los Angeles Times

New Thrillers And Crime Books For 2025
--------------------------------------

 ![New thrillers and crime books for 2025](https://www.deadgoodbooks.co.uk/wp-content/uploads/2024/12/Best-books-of-2025-DG-article-sizing-1.jpg) <small>www.deadgoodbooks.co.uk</small>New thrillers and crime books for 2025

THE C.I.D. ROOM CRIME THRILLERS BOOKS 1–7 Seven Totally Gripping
----------------------------------------------------------------

 ![THE C.I.D. ROOM CRIME THRILLERS BOOKS 1–7 seven totally gripping](https://m.media-amazon.com/images/I/81-OQeUn7dL._SL1500_.jpg) <small>www.amazon.com</small>THE C.I.D. ROOM CRIME THRILLERS BOOKS 1–7 seven totally gripping ...

True Crime Storytime: 84 Unforgettable &amp; Twisted True Crime Cases
---------------------------------------------------------------------

 ![True Crime Storytime: 84 Unforgettable & Twisted True Crime Cases](https://m.media-amazon.com/images/I/81+extDgF+L._SL1500_.jpg) <small>www.amazon.co.uk</small>True Crime Storytime: 84 Unforgettable &amp; Twisted True Crime Cases ...

The Top 5 Crime Fiction Books Of 2025 : The Indiependent
--------------------------------------------------------

 ![The Top 5 Crime Fiction Books Of 2025 : The Indiependent](https://www.indiependent.co.uk/wp-content/uploads/2025/12/Untitled-design162.jpg) <small>www.indiependent.co.uk</small>The Top 5 Crime Fiction Books Of 2025 : The Indiependent

9 Brilliantly Gritty Crime Novels Set In Glasgow, Scotland - GREAT
------------------------------------------------------------------

 ![9 Brilliantly Gritty Crime Novels Set in Glasgow, Scotland - GREAT](https://greatbritishbookclub.com/wp-content/uploads/2023/02/british-crime-novels-set-near-newcastle-uk.png) <small>greatbritishbookclub.com</small>9 Brilliantly Gritty Crime Novels Set in Glasgow, Scotland - GREAT ...

THE COMPLETE JEFFREY FLINT MURDER MYSTERIES BOOKS 1–5 Five Gripping
-------------------------------------------------------------------

 ![THE COMPLETE JEFFREY FLINT MURDER MYSTERIES BOOKS 1–5 five gripping](https://m.media-amazon.com/images/I/81zdStUkoHL._SL1500_.jpg) <small>www.amazon.com.au</small>THE COMPLETE JEFFREY FLINT MURDER MYSTERIES BOOKS 1–5 five gripping ...

30 Best True Crime Books To Binge Read Right Away
-------------------------------------------------

 ![30 Best True Crime Books to Binge Read Right Away](https://b2125522.smushcdn.com/2125522/wp-content/uploads/2022/12/Best-True-Crime-Books-1000x598.jpg?lossy=1&strip=1&webp=1) <small>www.tlbranson.com</small>30 Best True Crime Books to Binge Read Right Away

Crime Mystery Novels – Michael Hambling
---------------------------------------

 ![Crime Mystery Novels – Michael Hambling](https://michaelhambling.co.uk/wp-content/uploads/2022/10/1-Dark-Crimes-Cover-LoRes-1280x2048.jpg) <small>michaelhambling.co.uk</small>Crime Mystery Novels – Michael Hambling

The Best Crime Fiction Authors And Their Books - Student Expresso
-----------------------------------------------------------------

 ![The Best Crime Fiction Authors and Their Books - Student Expresso](https://studentexpresso.com/wp-content/uploads/2022/06/image-1-1320x679.png) <small>studentexpresso.com</small>The Best Crime Fiction Authors and Their Books - Student Expresso

Amazon | THE COMPLETE DETECTIVE INCH MYSTERIES BOOKS 1-7 Seven Classic
----------------------------------------------------------------------

 ![Amazon | THE COMPLETE DETECTIVE INCH MYSTERIES BOOKS 1-7 seven classic](https://m.media-amazon.com/images/I/81JUNq5KwFL._SL1500_.jpg) <small>www.amazon.co.jp</small>Amazon | THE COMPLETE DETECTIVE INCH MYSTERIES BOOKS 1-7 seven classic ...

Highest Goodreads-Rated Crime Novels In 2023 So Far | Novel Suspects
--------------------------------------------------------------------

 ![Highest Goodreads-Rated Crime Novels in 2023 So Far | Novel Suspects](https://www.novelsuspects.com/wp-content/uploads/2023/02/March2023_NovelSuspects_BooksCrimeFiction.png?resize=300) <small>www.novelsuspects.com</small>Highest Goodreads-Rated Crime Novels in 2023 So Far | Novel Suspects

31 Of The Best Crime Novels Of All Time
---------------------------------------

 ![31 of the best crime novels of all time](https://happymag.tv/wp-content/uploads/2021/10/penguin-sherlock-870x1205.jpg) <small>happymag.tv</small>31 of the best crime novels of all time

40 Of The Best Crime Fiction Books - Pan Macmillan
--------------------------------------------------

 ![40 of the best crime fiction books - Pan Macmillan](https://assets-eu-01.kc-usercontent.com/bcd02f72-b50c-0179-8b4b-5e44f5340bd4/c076b45e-e9db-4735-8df4-defb2104cae8/The Mysterious Affair at Styles book cover.jpg) <small>www.panmacmillan.com</small>40 of the best crime fiction books - Pan Macmillan

Crime &amp; Thriller Fiction Books Collection | Readers Warehouse
-----------------------------------------------------------------

 ![Crime & Thriller Fiction Books Collection | Readers Warehouse](https://www.readerswarehouse.co.za/cdn/shop/collections/crime-thriller-fiction-books-192539.jpg?v=1750249755) <small>www.readerswarehouse.co.za</small>Crime &amp; Thriller Fiction Books Collection | Readers Warehouse

The Best Crime Novels Of 2024 - Five Books Expert Recommendations
-----------------------------------------------------------------

 ![The Best Crime Novels of 2024 - Five Books Expert Recommendations](https://fivebooks.com/best-books/crime-novels-2024-sophie-roell/shareimage.jpg) <small>fivebooks.com</small>The Best Crime Novels of 2024 - Five Books Expert Recommendations

DETECTIVE DAVID MALLIN CRIME THRILLERS BOOKS 1–8 Eight Gripping British
-----------------------------------------------------------------------

 ![DETECTIVE DAVID MALLIN CRIME THRILLERS BOOKS 1–8 eight gripping British](https://m.media-amazon.com/images/I/814faCM8NdL._SL1500_.jpg) <small>www.amazon.co.uk</small>DETECTIVE DAVID MALLIN CRIME THRILLERS BOOKS 1–8 eight gripping British ...

The Best Crime Novels Of 2025 - Five Books Expert Recommendations
-----------------------------------------------------------------

 ![The Best Crime Novels of 2025 - Five Books Expert Recommendations](https://fivebooks.com/best-books/the-best-crime-novels-of-2025-sophie-roell/shareimage.jpg) <small>fivebooks.com</small>The Best Crime Novels of 2025 - Five Books Expert Recommendations

Most Highly Anticipated Crime Novels Of 2025
--------------------------------------------

 ![Most Highly Anticipated Crime Novels of 2025](https://mmbbookblog.com/wp-content/uploads/2024/12/anticipated-crime-novels-2025.png) <small>mmbbookblog.com</small>Most Highly Anticipated Crime Novels of 2025

The 7 best crime-series novels of fall 2020. The five best crime books of all time. 17 best new crime fiction and thrillers this autumn, picked by a book ...
